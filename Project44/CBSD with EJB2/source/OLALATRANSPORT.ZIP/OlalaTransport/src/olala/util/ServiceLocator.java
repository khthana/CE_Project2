package olala.util;

import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import javax.naming.*;

/**
 * Title:       Base Class of Service Locator
 * Description: This is a 'Smart Proxy' of Service Remote Object, It caches all
 *              Home Interfaces in the application. With caching, we can greatly
 *              improve performance, eliminating of looking up JNDI tree and
 *              Initial Context. It also encapsulate the use of Naming API
 *              and the JNDI looking up process.
 * Copyright:   Copyright (c) 2001
 * Company:     KMITL
 * @author      Prakit Engkakitti
 * @version 1.0
 */

public abstract class ServiceLocator {

  private Context ctx = null;
  public ServiceLocator() throws ServiceLocatorException {
	try {
	  ctx = new InitialContext();
	}
	catch (NamingException ne) {
	  ne.printStackTrace();
	  throw new ServiceLocatorException();
	}
  }

  // get the Context of Service locator ..
  public Context getContext() {
	return ctx;
  }

  // internal usage method , for lookup the Name using NameService
  protected EJBHome lookupByName(String name, Class homeclass)
  {
	EJBHome ejbHome = null;
	try {
	  Object objref = ctx.lookup(name);
	  ejbHome = (EJBHome) PortableRemoteObject.narrow(objref, homeclass);
	}
	catch (NamingException ne) {
	  ne.printStackTrace();
	}
	return ejbHome;
  }
}