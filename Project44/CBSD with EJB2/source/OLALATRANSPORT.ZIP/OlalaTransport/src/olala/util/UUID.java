package olala.util;

import java.rmi.*;
import javax.ejb.*;

public interface UUID extends EJBObject {
  public String getUUID() throws RemoteException;
  public String getUnformatedUUID() throws RemoteException;
}