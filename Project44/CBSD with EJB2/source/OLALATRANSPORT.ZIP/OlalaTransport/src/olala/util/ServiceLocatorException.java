package olala.util;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ServiceLocatorException extends Exception {

  public ServiceLocatorException() {
	super ("ServiceLocator Exception");
  }
  public ServiceLocatorException(String msg) {
	super(msg);
  }
}