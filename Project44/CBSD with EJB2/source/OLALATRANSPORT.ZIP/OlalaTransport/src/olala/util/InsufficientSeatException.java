package olala.util;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InsufficientSeatException extends Exception {
  public InsufficientSeatException() {
	super("Insuficient Seats");

  }
  public InsufficientSeatException(String msg) {
	super(msg);
  }
}