package olala.util;

/**
 * Title:         DuplicateEmailException.java
 * Description:   Thrown when email address already exist when trying to insert customer data
 * Copyright:     Copyright (c) 2001 - 2002
 * Company:       Kmit'L
 * @author        EJB Group
 * @version       1.0
 */

public class DuplicateEmailException extends Exception {

  public DuplicateEmailException() {
    super("Duplicate Email Address");
  }

  public DuplicateEmailException(String message) {
    super(message);
  }
}