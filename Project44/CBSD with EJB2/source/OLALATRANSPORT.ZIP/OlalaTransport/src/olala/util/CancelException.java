package olala.util;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CancelException extends Exception {
  public CancelException() {
	super("Cancel Exception");
  }
  public CancelException(String msg) {
	super(msg);
  }
}