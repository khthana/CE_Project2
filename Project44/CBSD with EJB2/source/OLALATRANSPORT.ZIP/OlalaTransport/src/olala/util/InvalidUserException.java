package olala.util;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidUserException extends Exception {

  public InvalidUserException() {
    super("Invalid User");
  }

  public InvalidUserException(String message) {
    super(message);
  }
}