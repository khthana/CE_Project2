package olala.util;
import java.util.Date;
public class convert
{

  public convert()
  {
  }
  public static String DateToString(java.util.Date idate)
  {
     int year=idate.getYear()+1900;
     int month=idate.getMonth() + 1;
     int date=idate.getDate();
     int hour=idate.getHours();
     int minute=idate.getMinutes();
     int second=idate.getSeconds();
     //format yyyy-dd-mm hh:mm:ss
     return (year+"-"+date+"-"+month+" "+hour+":"+minute+":"+second);
  }
  public static String TimeToString(java.sql.Time itime) {
	 return (itime.getHours() + ":"+itime.getMinutes() + ":"+itime.getSeconds());
  }
  public static java.util.Date StringToDate(String sDate)
  {
      sDate=sDate.trim();
      int endYear=sDate.indexOf("-");
      String syear=sDate.substring(0,endYear);
      int year=Integer.parseInt(syear)-1900;
      //System.out.println(syear);
      int endDate=sDate.indexOf("-",endYear+1);
      String sdate=sDate.substring(endYear+1,endDate);
      int date=Integer.parseInt(sdate);
      //System.out.println(sdate);
      int endMonth=sDate.indexOf(" ",endDate+1);
      String smonth=sDate.substring(endDate+1,endMonth);
      int month=Integer.parseInt(smonth);
      //System.out.println(smonth);
      int endHour=sDate.indexOf(":",endMonth+1);
      String shour=sDate.substring(endMonth+1,endHour);
      int hour=Integer.parseInt(shour);
      //System.out.println(shour);
      int endMinute=sDate.indexOf(":",endHour+1);
      String sminute=sDate.substring(endHour+1,endMinute);
      int minute=Integer.parseInt(sminute);
      //System.out.println(sminute);
      String ssecond=sDate.substring(endMinute+1);
      int second=Integer.parseInt(ssecond);
      //System.out.println(ssecond);
      java.util.Date d=new java.util.Date(year, month-1, date, hour, minute, second);
      //System.out.println(d.toString());

      return d;
  }

  public static java.sql.Time StringToTime(String strTime) {
	return java.sql.Time.valueOf(strTime);

  }
  public static void main(String args[])
  {
    java.util.Date d=new java.util.Date(System.currentTimeMillis());
    String sdate=convert.DateToString(d);
    System.out.println(d.toString());
    System.out.println(sdate);
    convert.StringToDate(sdate);


  }
}