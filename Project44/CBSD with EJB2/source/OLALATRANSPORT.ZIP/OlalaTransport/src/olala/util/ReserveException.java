package olala.util;
/**
 * Title: Reserve Exception Class
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
public class ReserveException extends Exception {
  public ReserveException() {
	super("Reservation Error");
  }
  public ReserveException(String msg) {
	super(msg);
  }
}