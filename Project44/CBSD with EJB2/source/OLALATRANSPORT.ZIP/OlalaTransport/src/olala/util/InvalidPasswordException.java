package olala.util;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidPasswordException extends Exception {

  public InvalidPasswordException() {
    super("Invalid Password");
  }

  public InvalidPasswordException(String message) {
    super(message);
  }
}