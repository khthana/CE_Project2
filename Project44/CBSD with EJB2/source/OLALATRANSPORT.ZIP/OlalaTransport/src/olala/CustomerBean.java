package olala;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CustomerBean implements EntityBean {
  EntityContext entityContext;
  public String firstName;
  public String lastName;
  public String gender;
  public String address;
  public String telephone;
  public String emailAddress;
  public String password;
  public boolean agency;
  public String customerID;

  public String ejbCreate(String customerID, String firstName, String lastName, String gender, String address, String telephone, String emailAddress, String password, boolean agency) throws CreateException, RemoteException {
    this.customerID = customerID;
    this.firstName = firstName;
    this.lastName = lastName;
    this.gender = gender;
    this.address = address;
    this.telephone = telephone;
    this.emailAddress = emailAddress;
    this.password = password;
    this.agency = agency;
    return null;
  }
  public String ejbCreate(String customerID) throws RemoteException, CreateException, RemoteException {
    return ejbCreate(customerID, null, null, null, null, null, null, null, false);
  }
  public void ejbPostCreate(String customerID, String firstName, String lastName, String gender, String address, String telephone, String emailAddress, String password, boolean agency) throws CreateException, RemoteException {
  }
  public void ejbPostCreate(String customerID) throws CreateException, RemoteException {
    ejbPostCreate(customerID, null, null, null, null, null, null, null, false);
  }
  public void ejbLoad() throws RemoteException {
  }
  public void ejbStore() throws RemoteException {
  }
  public void ejbRemove() throws RemoveException, RemoteException {
  }
  public void ejbActivate() throws RemoteException {
  }
  public void ejbPassivate() throws RemoteException {
  }
  public void setEntityContext(EntityContext entityContext) throws RemoteException {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() throws RemoteException {
    entityContext = null;
  }
  public String getCustomerID() {
    return customerID;
  }
  public String getFirstName() {
    return firstName;
  }
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  public String getLastName() {
    return lastName;
  }
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
  public String getGender() {
    return gender;
  }
  public void setGender(String gender) {
    this.gender = gender;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getTelephone() {
    return telephone;
  }
  public void setTelephone(String telephone) {
    this.telephone = telephone;
  }
  public String getEmailAddress() {
    return emailAddress;
  }
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public boolean getAgency() {
    return agency;
  }
  public void setAgency(boolean agency) {
    this.agency = agency;
  }
  public void setCustomer(CustomerVO cusVO) {
    this.firstName = cusVO.getFirstName();
    this.lastName = cusVO.getLastName();
    this.gender = cusVO.getGender();
    this.address = cusVO.getAddress();
    this.telephone = cusVO.getTelephone();
    this.emailAddress = cusVO.getEmailAddress();
    this.password = cusVO.getPassword();
    this.agency = cusVO.getAgency();
  }

  public CustomerVO getCustomer() {
    CustomerVO temp = new CustomerVO( customerID, firstName, lastName, gender,
									  address, telephone, emailAddress, password, agency);
    return(temp);
  }
}
