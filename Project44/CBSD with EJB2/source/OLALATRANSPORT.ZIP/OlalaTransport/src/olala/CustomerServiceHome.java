package olala;
import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface CustomerServiceHome extends EJBHome {
  public CustomerService create() throws RemoteException, CreateException;
}
