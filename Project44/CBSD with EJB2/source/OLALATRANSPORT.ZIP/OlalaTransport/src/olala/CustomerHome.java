package olala;
import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface CustomerHome extends EJBHome {
  public Customer create(String customerID, String firstName, String lastName, String gender, String address, String telephone, String emailAddress, String password, boolean agency) throws CreateException, RemoteException;
  public Customer create(String customerID) throws RemoteException, CreateException;
  public Customer findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
  public Collection findByEmailAddress(String emailAddress) throws RemoteException, FinderException;
}
