import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.rtf.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import javax.swing.undo.*;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.beans.*;

/*
  -------------------| Simple Text Editor example application using Java 1.3 with Swing |--------------
*/

public class SimpleTextEditor extends JPanel
 {
        private JTextPane textpane;
        private JMenuBar mb;
        private JFileChooser chooser,picChooser;
        private Hashtable actions;
        private JPopupMenu popup;
        private JMenuItem exit, newDoc, save, open, saveAs;
        //private About ab;

        private StyledEditorKit edkit;
        private RTFEditorKit rtfkit;

        private DefaultStyledDocument doc;
        private MyDocumentListener doclistener;
        private MyUndoableEditListener undolistener;

        // Useful variables
        private String filename="untitled1.txt",filetype=".txt";
        private File thisfile;
        protected String FileFormats[],FileDescriptions[],PicFileFormats[],PicFileDescriptions[];
        protected boolean DocumentIsUnedited=true, DocumentIsSaved=false;
        public static int SQUARE=0,TRIANGLE=1,CIRCLE=2;
        public String newline="\n";

        protected UndoManager undo ;
        protected UndoAction undoAction;
        protected RedoAction redoAction;

        // These are the actions used in the menus and on the toolbar
        protected Action bold, italic, underline, alignleft, alignright, aligncentre;
        protected Action  alignjustify, more, cut, copy, paste, tools[];

        public SimpleTextEditor()
        {
               // super("SimpleTextEditor - untitled1.rtf");
                this.setLocation(200,200);
               // this.setIconImage(getMyIcon("Icon.gif").getImage());
               // getContentPane().setLayout(new BorderLayout());

                undo = new UndoManager();

                //Set up the file formats and file choosers etc
                FileFormats = new String[]{".rtf",".txt",".java",".bat"};
                FileDescriptions = new String[]{"Rich Text Format Files","Text Files","Java Source Files","DOS Batch Files"};

                PicFileFormats = new String[]{".gif",".bmp",".jpg"};
                PicFileDescriptions = new String[]{"Gif Images","Bitmap Images","JPEG Images"};

                chooser = new JFileChooser();
                picChooser = new JFileChooser();
                picChooser.setAccessory(new ImagePreview(picChooser));

                javax.swing.filechooser.FileFilter defaultFilter = new SimpleFilter(FileFormats[0],FileDescriptions[0]);
                javax.swing.filechooser.FileFilter defaultPicFilter = new SimpleFilter(PicFileFormats[0],PicFileDescriptions[0]);

                for(int i=1;i<FileFormats.length;i++){
                        chooser.addChoosableFileFilter(new SimpleFilter(FileFormats[i],FileDescriptions[i]));
                }
                for(int i=1;i<PicFileFormats.length;i++){
                        picChooser.addChoosableFileFilter(new SimpleFilter(PicFileFormats[i],PicFileDescriptions[i]));
                }
                chooser.setFileFilter(defaultFilter);
                picChooser.setFileFilter(defaultPicFilter);

                File working = new File("C:/Documents");
                if(!working.exists()){
                        working= new File("C:/MyDocuments");
                        if(!working.exists()) working = new File("C:/");
                }

                if(working.exists()) {
                        chooser.setCurrentDirectory(working);
                        picChooser.setCurrentDirectory(working);
                }

                // Set up Document object and Editor kits
                doc = new DefaultStyledDocument();
                edkit = new StyledEditorKit();
                rtfkit = new RTFEditorKit();

                // Set up Listener objects
                doclistener= new MyDocumentListener();
                undolistener= new MyUndoableEditListener();
                doc.addDocumentListener(doclistener);
                doc.addUndoableEditListener(undolistener);

                // Set up main GUI content
                textpane=new JTextPane(doc);
                textpane.setPreferredSize(new Dimension(400,400));
                textpane.setMinimumSize(new Dimension(400,400));

                JScrollPane scroller=new JScrollPane(textpane);
                scroller.setPreferredSize(new Dimension(400,400));

                mb=new JMenuBar(); // Create a menu bar
                JMenu File=new JMenu("File");
                JMenu Help=new JMenu("Help");

                //Sort out Actions etc
                createActionTable(textpane);
                createToolbarActions();
                JMenu Style=createStyleMenu();
                undoAction = new UndoAction();
                redoAction = new RedoAction();

                //Create Style, Edit and Format menus + Toolbar
                JMenu Edit=createEditMenu();
                JMenu Format=createFormatMenu();
                JMenu Insert = createInsertMenu();
                JToolBar toolbar = createToolbar();
               // getContentPane().add("North",toolbar);


                // set up main menu items with ActionListeners

                newDoc=new JMenuItem("New");
                newDoc.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             newDoc();
                        }
                });
                exit=new JMenuItem("Exit");
                exit.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             exit();
                        }
                });
                save=new JMenuItem("Save");
                save.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             save();
                        }
                });
                saveAs=new JMenuItem("Save As...");
                saveAs.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             saveas();
                        }
                });
                open=new JMenuItem("Open...");
                open.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             open();
                        }
                });
                JMenuItem about=new JMenuItem("About");
                about.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                          //   ab=new About(SimpleTextEditor.this);
                          //   ab.show();
                          //   ab.setLocation(400,300);
                        }
                });

                // Create the popup menu
                popup = createEditMenu().getPopupMenu();
                popup.addSeparator();
                popup.add(createStyleMenu());
                popup.add(createFormatMenu());
                textpane.add(popup);

                // set up Help and File menus
                Help.add(about);
                File.add(newDoc);
                File.add(open);
                File.add(save);
                File.add(saveAs);
                File.addSeparator();
                File.add(exit);

                // add the menus to the menubar
                mb.add(File);
                mb.add(Edit);
                mb.add(Format);
                mb.add(Style);
                mb.add(Insert);
                mb.add(Help);

               toolbar.add(mb);

               // getContentPane().add("Center",scroller);

                // Add mouse Listener to the textpane for popup events
                textpane.addMouseListener(new MouseAdapter(){
                        public void mousePressed(MouseEvent e)
                        {
                              if(e.isPopupTrigger())
                              {
                                     popup.show(textpane, e.getX(), e.getY());
                                     e.consume();
                             }
                        }
                        public void mouseReleased(MouseEvent e)
                        {
                              if(e.isPopupTrigger())
                              {
                                      popup.show(textpane, e.getX(), e.getY());
                                      e.consume();
                              }
                        }
                });
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }


        }

        //-----------------| Main active methods |------------------

        public void exit()// Main Exit method
        {
             if(DocumentIsUnedited){//Check that document is saved/unedited etc
                   // dispose();
                    setVisible(false);
                    System.exit(0);
            }
            else{
                        switch(showNotSavedDialog("Exit")){
                                case JOptionPane.YES_OPTION: save(); exit(); break;
                                case JOptionPane.NO_OPTION: DocumentIsUnedited=true;exit();break;
                                case JOptionPane.CANCEL_OPTION: break;
                        }
           }
        }

        public void newDoc()//Method to create new documents
        {
                if(DocumentIsUnedited){
                        initDoc();
                        filename="untitled.txt";
                        filetype=".txt";
                        resetTitle();
                }
                else
                {
                        switch(showNotSavedDialog("New Document")){
                                case JOptionPane.YES_OPTION: save(); newDoc(); break;
                                case JOptionPane.NO_OPTION: DocumentIsUnedited=true;newDoc();break;
                                case JOptionPane.CANCEL_OPTION: break;
                        }
           }
        }

        private void initDoc()// Helper method to initialize a new document
        {
                doc = null;
                doc = (DefaultStyledDocument)edkit.createDefaultDocument();
                doc.addDocumentListener(doclistener);
                textpane.setStyledDocument(doc);
        }

        public void saveas()
        {
                int n = chooser.showSaveDialog(this);
                if(n==0){
                      filename=chooser.getSelectedFile().getName();
                      boolean ext = false;
                      setFiletype();
                      thisfile = new File(chooser.getCurrentDirectory(),filename);
                      DocumentIsSaved=true;
                      save();
                      resetTitle();
               }
               repaint();
        }

        public void save()// Save method. Used by "Save As..." as well
        {
                if( DocumentIsSaved)
                {
                        try
                        {
                                FileOutputStream out = new FileOutputStream(thisfile);
                                if((filetype.equals(".rtf"))||(filetype.equals(".doc"))){
                                        rtfkit.write(out,doc,0,doc.getLength());
                                }
                                else edkit.write(out,doc,0,doc.getLength());
                        }
                        catch(Exception e)
                        {
                                System.out.println(""+e.getMessage()+"");
                        }
                        DocumentIsUnedited=true;
                }
                else saveas();
        }



        public void open()// Find a file and read it into the document
        {
                if(DocumentIsUnedited){
                        int n = chooser.showOpenDialog(this); // get the outcome of the dialog
                        if(n==0){
                                File file = chooser.getSelectedFile();
                                filename=chooser.getName(file);
                                setFiletype();
                                resetTitle();
                                initDoc();
                                try
                                {
                                        FileInputStream in= new FileInputStream(file);
                                        if(filetype.equals(".rtf")){
                                          rtfkit.read(in,doc,0);
                                        }
                                        edkit.read(in,doc,0);
                                }
                                catch(Exception e)
                                {
                                        System.out.println(""+e.getMessage()+"");
                                }

                                thisfile= new File(chooser.getCurrentDirectory(),chooser.getSelectedFile().getName());
                                DocumentIsUnedited=true;
                                DocumentIsSaved=true;
                                resetTitle();
                        }
                        repaint();
                }
                else
                {
                        switch(showNotSavedDialog("Open")){
                                case JOptionPane.YES_OPTION: save(); open(); break;
                                case JOptionPane.NO_OPTION: DocumentIsUnedited=true; open(); break;
                                case JOptionPane.CANCEL_OPTION: break;
                        }
                }
        }

        private void setFiletype()// Helper method to get the filetype of saved/opened documents
        {
                filetype=null;
                for(int i=0;i<FileFormats.length;i++){

                        if(filename.toLowerCase().endsWith(FileFormats[i])) filetype = FileFormats[i];
                        else{
                                for(i=0;i<filename.length();i++){
                                        if(filename.toLowerCase().charAt(i)=='.')
                                        {
                                                filetype=filename.substring(i);
                                         }
                                 }
                         }
                         if(filetype==null) filetype=".txt";

                }
        }

        private void resetTitle()
        {
                //this.setTitle("SimpleTextEditor - "+filename);
        }

        private ImageIcon getMyIcon(String filename){
                ImageIcon pic = new ImageIcon("Images/"+filename);
                return pic;
        }

        private int showNotSavedDialog(String title)// Helper method to create "Save? Yes/No/Cancel" dialogs
        {
                int n = JOptionPane.showConfirmDialog(this,"The last document has not been saved. \nDo you want to save it first?",
                title,
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE);
                return n;
        }

        //-----------------| Listeners and Helper classes |----------------

        protected class MyDocumentListener implements DocumentListener
        {
                public void insertUpdate(DocumentEvent e) {
                        SimpleTextEditor.this.DocumentIsUnedited=false;
                 }
                public void removeUpdate(DocumentEvent e) {
                        SimpleTextEditor.this.DocumentIsUnedited=false;
                }
                public void changedUpdate(DocumentEvent e) {
                        SimpleTextEditor.this.DocumentIsUnedited=false;
                }


        }

        protected class MyUndoableEditListener implements UndoableEditListener {
                 public void undoableEditHappened(UndoableEditEvent e) {
               //Remember the edit and update the menus.
                        undo.addEdit(e.getEdit());
                        undoAction.updateUndoState();
                        redoAction.updateRedoState();
                }
        }


        //Helper class for FileFilter, allows a description to be assigned to a filetype
        protected class SimpleFilter extends javax.swing.filechooser.FileFilter
        {
                String type,des;
                public SimpleFilter(String type, String des)
                {
                        this.des=des;
                        this.type=type;
                }
                public boolean accept(File f){
                        if(f.isDirectory())return true;
                        else{
                                if(f.getName().toLowerCase().endsWith(type)) return true;
                                else return false;
                        }
                }
                public String getDescription(){
                        return des;
                }
        }

        //------------| Methods to help create menus and toolbar |--------------

        protected JMenu createStyleMenu()
        {
                JMenu menu = new JMenu("Style");
                menu.add(bold);
                menu.add(italic);
                menu.add(underline);

                menu.addSeparator();
                menu.add(new StyledEditorKit.FontSizeAction("12", 12));
                menu.add(new StyledEditorKit.FontSizeAction("14", 14));
                menu.add(new StyledEditorKit.FontSizeAction("18", 18));
                menu.addSeparator();
                menu.add(new StyledEditorKit.FontFamilyAction("Serif","Serif"));
                menu.add(new StyledEditorKit.FontFamilyAction("SansSerif","SansSerif"));
                menu.addSeparator();

                Action red = new StyledEditorKit.ForegroundAction("Red", new Color(255,0,0));
                red.putValue(Action.SMALL_ICON,getMyIcon("red.gif"));
                menu.add(red);

                Action green = new StyledEditorKit.ForegroundAction("Green", new Color(0,150,0));
                green.putValue(Action.SMALL_ICON,getMyIcon("green.gif"));
                menu.add(green);

                Action blue = new StyledEditorKit.ForegroundAction("Blue", new Color(0,50,150));
                blue.putValue(Action.SMALL_ICON,getMyIcon("blue.gif"));
                menu.add(blue);

                Action black = new StyledEditorKit.ForegroundAction("Black", new Color(0,0,0));
                black.putValue(Action.SMALL_ICON,getMyIcon("black.gif"));
                menu.add(black);
                menu.add(more);

                return menu;
        }

        protected JMenu createEditMenu() {
                JMenu menu = new JMenu("Edit");
                menu.add(undoAction);
                menu.add(redoAction);

                menu.addSeparator();
                menu.add(cut);
                menu.add(copy);
                menu.add(paste);

                menu.addSeparator();

                Action selectall=getActionByName(DefaultEditorKit.selectAllAction);
                selectall.putValue(Action.NAME, "Select All");
                menu.add(selectall);
                return menu;
        }

        protected JMenu createFormatMenu(){
                JMenu menu = new JMenu("Format");
                menu.add(alignleft);
                menu.add(alignright);
                menu.add(aligncentre);
                menu.add(alignjustify);
                return menu;
       }

       protected JMenu createInsertMenu(){
               JMenu menu = new JMenu("Insert");
               Action insertimage = new InsertImageAction(this);
               menu.add(insertimage);
               Action insertdate = new InsertDateAction();
               menu.add(insertdate);
               Action insertline = new InsertLineAction();
               menu.add(insertline);
               JMenu bullets =new JMenu("Bullet Points");
               bullets.add(new InsertBulletAction(CIRCLE,"Circle"));
               bullets.add(new InsertBulletAction(TRIANGLE,"Triangle"));
               bullets.add(new InsertBulletAction(SQUARE,"Square"));
               menu.add(bullets);
               return menu;
        }

        public JToolBar createToolbar(){
                JToolBar bar= new JToolBar();

                JButton newbutton=new JButton(getMyIcon("new.gif"));
                newbutton.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             newDoc();
                        }
                });
                bar.add(newbutton);

                JButton savebutton=new JButton(getMyIcon("save.gif"));
                savebutton.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             save();
                        }
                });
                bar.add(savebutton);
                JButton openbutton=new JButton(getMyIcon("open.gif"));
                openbutton.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                             open();
                        }
                });
                bar.add(openbutton);

                bar.addSeparator();
                for(int i=0;i<tools.length;i++){
                        JButton button=new JButton();
                        button.setAction(tools[i]);
                        button.setIcon(getMyIcon(tools[i].getValue(Action.NAME)+".gif"));
                        button.setText("");
                        bar.add(button);
                        if((i==2)||(i==6))bar.addSeparator();
                }
                return bar;
        }

        public void createToolbarActions(){

                bold = new StyledEditorKit.BoldAction();
                bold.putValue(Action.NAME, "Bold");
                italic = new StyledEditorKit.ItalicAction();
                italic.putValue(Action.NAME, "Italic");
                underline = new StyledEditorKit.UnderlineAction();
                underline.putValue(Action.NAME, "Underline");
                more = new MoreColorsAction();
                cut = getActionByName(DefaultEditorKit.cutAction);
                cut.putValue(Action.NAME, "Cut");
                copy = getActionByName(DefaultEditorKit.copyAction);
                copy.putValue(Action.NAME, "Copy");
                paste = getActionByName(DefaultEditorKit.pasteAction);
                paste.putValue(Action.NAME, "Paste");
                alignleft = new StyledEditorKit.AlignmentAction("Left Justify",StyleConstants.ALIGN_LEFT);
                alignright = new StyledEditorKit.AlignmentAction("Right Justify",StyleConstants.ALIGN_RIGHT);
                aligncentre = new StyledEditorKit.AlignmentAction("Align Centre",StyleConstants.ALIGN_CENTER);
                alignjustify = new StyledEditorKit.AlignmentAction("Fully Justify",StyleConstants.ALIGN_JUSTIFIED);
                tools = new Action[]{  cut, copy, paste, bold, italic, underline, more, alignleft, alignright, aligncentre, alignjustify };
        }

       // helper methods to enable menu creators to get their actions by name
        private void createActionTable(JTextComponent textComponent) {
                actions = new Hashtable();
                Action[] actionsArray = textComponent.getActions();
                for (int i = 0; i < actionsArray.length; i++) {
                        Action a = actionsArray[i];
                        actions.put(a.getValue(Action.NAME), a);
                }
        }

        private Action getActionByName(String name) {
                return (Action)(actions.get(name));
        }

        //----------------| Custom Actions |--------------------

        class InsertImageAction extends AbstractAction {
                protected SimpleTextEditor parent;

                public InsertImageAction(SimpleTextEditor parent){
                        super("Image...");
                        this.parent=parent;
                }

                public void actionPerformed(ActionEvent e) {
                        int n = parent.picChooser.showOpenDialog(parent);
                        if(n==0){
                                String filename=picChooser.getSelectedFile().getName();
                                File file = new File(picChooser.getCurrentDirectory(),filename);
                                Icon pic = new ImageIcon(file.getAbsolutePath());
                                textpane.insertIcon(pic);
                        }
                        SimpleTextEditor.this.repaint();

                }
        }

        class InsertDateAction extends AbstractAction {
                public InsertDateAction(){
                        super("Date");
                }
                public void actionPerformed(ActionEvent ble) {
                        Calendar c= Calendar.getInstance();
                        String[] months= new String[]{"01","02","03","04","05","06","07","08","09","10","11","12"};
                        textpane.replaceSelection(c.get(c.DAY_OF_MONTH)+"/"+months[c.get(c.MONTH)]+"/"+c.get(c.YEAR));
                }
        }

        class InsertLineAction extends AbstractAction {
                public InsertLineAction(){
                        super("Horizontal line");
                }
                public void actionPerformed(ActionEvent e) {
                        Icon pic = new ImageIcon("Images/line.gif");
                        textpane.insertIcon(pic);
                }
        }

        class InsertBulletAction extends AbstractAction {
                protected int type;

                protected String filenames[] = new String[]{"square.gif","triangle.gif","circle.gif"};

                public InsertBulletAction(int type,String name){
                        super(name);
                        this.type=type;
                        this.putValue(SMALL_ICON,new ImageIcon("Images/"+filenames[type]));
                }

                public void actionPerformed(ActionEvent e) {
                        Icon pic = new ImageIcon("Images/"+filenames[type]);
                        textpane.insertIcon(pic);
                        textpane.replaceSelection(" ");
                }
        }
        class MoreColorsAction extends AbstractAction {
                public MoreColorsAction(){
                        super("More Colors");
                }
                public void actionPerformed(ActionEvent e){
                        AttributeSet as = textpane.getCharacterAttributes();
                        SimpleAttributeSet sas = new SimpleAttributeSet(as);
                        Color newColor = JColorChooser.showDialog(
                          SimpleTextEditor.this,
                          "Choose Text Color",
                          doc.getForeground(as));
                        if(newColor!=null){
                                StyleConstants.setForeground(sas,newColor);
                                textpane.setCharacterAttributes(sas,true);
                         }
                        SimpleTextEditor.this.repaint();
              }
        }


        class UndoAction extends AbstractAction {
                public UndoAction() {
                        super("Undo");
                        setEnabled(false);
                }
                public void actionPerformed(ActionEvent e) {
                        try {
                                undo.undo();
                         }
                         catch (CannotUndoException ex) {
                                System.out.println("Unable to undo: " + ex);
                                ex.printStackTrace();
                        }
                        updateUndoState();
                        redoAction.updateRedoState();
                }

                protected void updateUndoState() {
                        if (undo.canUndo()) {
                                setEnabled(true);
                                putValue(Action.NAME, undo.getUndoPresentationName());
                                }
                       else {
                                setEnabled(false);
                                putValue(Action.NAME, "Undo");
                      }
                }
        }

        class RedoAction extends AbstractAction {
                        public RedoAction() {
                        super("Redo");
                        setEnabled(false);
                }

                public void actionPerformed(ActionEvent e) {
                         try {
                        undo.redo();
                        }
                        catch (CannotRedoException ex) {
                        System.out.println("Unable to redo: " + ex);
                        ex.printStackTrace();
                        }
                        updateRedoState();
                        undoAction.updateUndoState();
                }

                protected void updateRedoState() {
                        if (undo.canRedo()) {
                                setEnabled(true);
                                putValue(Action.NAME, undo.getRedoPresentationName());
                        }
                        else {
                                setEnabled(false);
                                putValue(Action.NAME, "Redo");
                        }
                }
        }

        //-------------| Very nice Image Previewer 'borrowed' from Sun's Java Tutorial

        class ImagePreview extends JComponent implements PropertyChangeListener
        {
                ImageIcon thumbnail = null;
                File file = null;

                public ImagePreview(JFileChooser fc) {
                        setPreferredSize(new Dimension(100, 50));
                        fc.addPropertyChangeListener(this);
                }

                public void loadImage() {
                        if (file == null) {
                                return;
                        }
                        ImageIcon tmpIcon = new ImageIcon(file.getPath());
                        if (tmpIcon.getIconWidth() > 90) {
                                thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(90, -1,
                                Image.SCALE_DEFAULT));
                        } else {
                                thumbnail = tmpIcon;
                        }
                }
                public void propertyChange(PropertyChangeEvent e) {
                        String prop = e.getPropertyName();
                        if (prop.equals(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)) {
                                file = (File) e.getNewValue();
                                if (isShowing()) {
                                        loadImage();
                                        repaint();
                                }
                        }
                }
                public void paintComponent(Graphics g) {
                        if (thumbnail == null) {
                                loadImage();
                        }
                        if (thumbnail != null) {
                                int x = getWidth()/2 - thumbnail.getIconWidth()/2;
                                int y = getHeight()/2 - thumbnail.getIconHeight()/2;
                                if (y < 0) {
                                        y = 0;
                                }
                                if (x < 5) {
                                        x = 5;
                                }
                                thumbnail.paintIcon(this, g, x, y);
                        }
                }
        }

/*
        // Obligatory main method...
        public static void main(String[] args)
        {
                final SimpleTextEditor f = new SimpleTextEditor();

                //make sure Window events are dealt with
                f.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                             f.exit();
                        }
                });
                f.pack();
                f.setVisible(true);
        }
*/
  private void jbInit() throws Exception {
   // this.getContentPane().setBackground(new Color(0, 233, 216));
  }

}



  //------------------| About dialog box |--------------

// external class - to make a change!
class About extends JDialog
{
        private JLabel by, date;
        JButton b;
        JPanel p, pan, d, outer;


        public About(Frame parent)
        {
                super(parent, "About SimpleTextEditor");
                this.setSize(200,100);
                outer=new JPanel();
                p=new JPanel();
                pan=new JPanel();
                d=new JPanel();
                b=new JButton("OK");
                by=new JLabel("By Simon Kelly");
                date=new JLabel("Jan 2001");
                b.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent e)
                        {
                        exit();
                        }
                });
                this.addWindowListener(new WindowAdapter(){
                        public void windowClosing(WindowEvent e)
                        {
                        exit();
                        }
                });

                p.add(by);
                d.add(date);
                pan.add(b);
                outer.add(p);
                outer.add(d);
                outer.add(pan);
                this.getContentPane().add(outer);
        }

        public void exit()
        {
                this.dispose();
                setVisible(false);
        }

}