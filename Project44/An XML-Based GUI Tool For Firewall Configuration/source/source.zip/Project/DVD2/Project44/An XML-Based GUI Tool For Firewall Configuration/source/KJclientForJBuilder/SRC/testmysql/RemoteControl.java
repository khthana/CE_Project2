package testmysql;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.swing.*;
import javax.crypto.*;
import com.borland.jbcl.layout.*;
import org.bouncycastle.jce.provider.*;
import javax.swing.border.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */
public class RemoteControl extends JPanel {

  String configcmdNames[] = { "hosts","network","ethers","route","ifconfig","protocols","services","hostname","netstat","network config"};
  String iptablescmdNames[]= { "View list","View more list","View INPUT chain","View OUTPUT chain","View FORWARD chain","Clear Rule"};

  public static final String strTerminate = "disconnect";
  public static final String strRemoteCtrl = "remoteControl";
  private static ObjectOutputStream output;
  private Socket client;
  private static ObjectInputStream input;

  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  XYLayout xYLayout3 = new XYLayout();
  JPanel displayareaPanel = new JPanel();
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout5 = new XYLayout();
  JTextArea displayArea = new JTextArea();
  JScrollPane scrollPane = new JScrollPane();
  JPanel jPanel4 = new JPanel();
  XYLayout xYLayout6 = new XYLayout();
  JTextField commandTextField = new JTextField();
  JLabel commandLabel = new JLabel();
  Border border1;
  TitledBorder titledBorder1;
  Border border2;
  TitledBorder titledBorder2;
  JComboBox configcmdComboBox = new JComboBox(configcmdNames);
  JComboBox historycmdComboBox = new JComboBox();
  JComboBox iptablescmdComboBox = new JComboBox(iptablescmdNames);
  JButton execmdButton = new JButton(new ImageIcon("images/exec.png"));
  JLabel iptablescmdLabel = new JLabel();
  JLabel historycmdLabel = new JLabel();
  JLabel configcmdLabel = new JLabel();
  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout4 = new XYLayout();
  JLabel logoLabel = new JLabel();
  JButton execmdButton1 = new JButton(new ImageIcon("images/exec.png"));
  JButton connectButton = new JButton(new ImageIcon("images/exec.png"));

  public RemoteControl() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

    configcmdComboBox.addItemListener(new selectedConfigCmd());
    iptablescmdComboBox.addItemListener(new selectediptablesCmd());
    historycmdComboBox.addItemListener(new selectedHistoryCmd());
    commandLabel.setIcon(new ImageIcon("./Images/cmd.gif"));

    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder1 = new TitledBorder(border1,"Select Command");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder2 = new TitledBorder(border2,"Display Area");
    this.setBackground(new Color(236, 233, 230));
    this.setLayout(xYLayout1);
    xYLayout1.setWidth(575);
    xYLayout1.setHeight(432);
    jPanel1.setLayout(xYLayout2);

    displayareaPanel.setBackground(new Color(236, 233, 230));
    displayareaPanel.setBorder(titledBorder2);
    displayareaPanel.setLayout(xYLayout3);
    jPanel1.setBackground(new Color(236, 233, 230));

    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(titledBorder1);
    jPanel3.setLayout(xYLayout5);
    displayArea.setLineWrap(true);
    displayArea.setWrapStyleWord(true);
    displayArea.setBackground(Color.white);
    displayArea.setMinimumSize(new Dimension(0, 0));
    scrollPane.setMinimumSize(new Dimension(0, 0));
    scrollPane.setPreferredSize(new Dimension(300, 18));

    jPanel4.setLayout(xYLayout6);
    jPanel4.setBackground(new Color(236, 233, 230));
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    configcmdComboBox.setBackground(new Color(236, 233, 230));
    iptablescmdComboBox.setBackground(new Color(236, 233, 230));
    historycmdComboBox.setBackground(new Color(236, 233, 230));
    execmdButton.setBackground(new Color(236, 233, 230));
    execmdButton.setBorder(BorderFactory.createEtchedBorder());
    execmdButton.setActionCommand("Ok");
    execmdButton.setHorizontalTextPosition(SwingConstants.LEFT);
    execmdButton.setText("EXE");
    execmdButton.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent e) {
        execmdButton_actionPerformed(e);
      }
    });


    historycmdLabel.setHorizontalAlignment(SwingConstants.CENTER);
    iptablescmdLabel.setHorizontalAlignment(SwingConstants.CENTER);
    configcmdLabel.setHorizontalAlignment(SwingConstants.CENTER);
    commandLabel.setHorizontalAlignment(SwingConstants.CENTER);
    commandLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    jPanel2.setLayout(xYLayout4);
    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    logoLabel.setIcon(new ImageIcon("./Images/RemoteControl.gif"));
    connectButton.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent e) {
        connectButton_actionPerformed(e);
      }
    });
    connectButton.setText("Connect");
    connectButton.setHorizontalTextPosition(SwingConstants.LEFT);
    connectButton.setActionCommand("Ok");
    connectButton.setBorder(BorderFactory.createEtchedBorder());
    connectButton.setBackground(new Color(236, 233, 230));
    jPanel4.add(commandLabel, new XYConstraints(5, 8, 67, 26));
    jPanel4.add(commandTextField,  new XYConstraints(73, 11, 295, 22));
    jPanel4.add(execmdButton,   new XYConstraints(396, 6, 79, 31));
    jPanel1.add(displayareaPanel,  new XYConstraints(24, 148, 500, 196));
    displayareaPanel.add(scrollPane, new XYConstraints(4, 0, 480, 166));
    jPanel1.add(jPanel2,         new XYConstraints(26, 9, 495, 70));
    scrollPane.getViewport().add(displayArea, null);
    jPanel1.add(jPanel3, new XYConstraints(24, 79, 500, -1));
    jPanel3.add(historycmdComboBox, new XYConstraints(342, 17, 124, -1));
    jPanel3.add(configcmdComboBox, new XYConstraints(24, 18, 124, -1));
    jPanel3.add(iptablescmdComboBox, new XYConstraints(187, 18, 124, -1));
    jPanel3.add(configcmdLabel, new XYConstraints(28, 0, 114, 20));
    jPanel3.add(iptablescmdLabel, new XYConstraints(192, 0, 114, 20));
    jPanel3.add(historycmdLabel, new XYConstraints(346, 0, 114, 20));
    jPanel1.add(jPanel4,  new XYConstraints(26, 347, 499, 51));
    this.add(jPanel1,      new XYConstraints(18, 17, 538, 406));
    jPanel2.add(logoLabel,     new XYConstraints(86, 0, 279, 63));
    jPanel2.add(connectButton,    new XYConstraints(406, 17, 79, 31));
    configcmdLabel.setIcon( new ImageIcon("./Images/configcmd.gif"));
    iptablescmdLabel.setIcon(new ImageIcon("./Images/iptablescmd.gif"));
    historycmdLabel.setIcon(new ImageIcon("./Images/historycmd.gif"));

    setEnabledExe(false);
    configcmdComboBox.addItemListener(new selectedConfigCmd());
    iptablescmdComboBox.addItemListener(new selectediptablesCmd());
    historycmdComboBox.addItemListener(new selectedHistoryCmd());

  }
  class selectedConfigCmd implements ItemListener {
   public void itemStateChanged(ItemEvent even) {

        if(even.getStateChange() == ItemEvent.SELECTED)
      if(configcmdComboBox.getSelectedItem().toString().equals("hosts"))
          commandTextField.setText("cat /etc/hosts");
       else if (configcmdComboBox.getSelectedItem().toString().equals("network"))
          commandTextField.setText("cat /etc/networks");
       else if (configcmdComboBox.getSelectedItem().toString().equals("ethers"))
          commandTextField.setText("cat /etc/ethers");
       else if (configcmdComboBox.getSelectedItem().toString().equals("route"))
           commandTextField.setText("route");
       else if (configcmdComboBox.getSelectedItem().toString().equals("ifconfig"))
           commandTextField.setText("ifconfig -a");
       else if (configcmdComboBox.getSelectedItem().toString().equals("protocals"))
           commandTextField.setText("cat /etc/protocal |more");
       else if (configcmdComboBox.getSelectedItem().toString().equals("services"))
           commandTextField.setText("cat /etc/services |more");
       else if (configcmdComboBox.getSelectedItem().toString().equals("hostname"))
            commandTextField.setText("hostname");
       else if (configcmdComboBox.getSelectedItem().toString().equals("netstat"))
            commandTextField.setText("netstat");
       else if(configcmdComboBox.getSelectedItem().toString().equals("network config"))
            commandTextField.setText("cat /etc/sysconfig/network");


    }
  }

  class selectediptablesCmd implements ItemListener {
   public void itemStateChanged(ItemEvent even) {

        if(even.getStateChange() == ItemEvent.SELECTED)
          if(iptablescmdComboBox.getSelectedItem().toString().equals("View list"))
              commandTextField.setText("iptables -L");
          if(iptablescmdComboBox.getSelectedItem().toString().equals("View more list"))
              commandTextField.setText("iptables -L -v");
          if(iptablescmdComboBox.getSelectedItem().toString().equals("View INPUT chain"))
              commandTextField.setText("iptables -v -L INPUT");
          if(iptablescmdComboBox.getSelectedItem().toString().equals("View OUTPUT chain"))
              commandTextField.setText("iptables -v -L OUTPUT");
          if(iptablescmdComboBox.getSelectedItem().toString().equals("View FORWARD chain"))
              commandTextField.setText("iptables -v -L FORWARD");
          if(iptablescmdComboBox.getSelectedItem().toString().equals("Clear Rule"))
              commandTextField.setText("iptables -X");

   }
  }

  class selectedHistoryCmd implements ItemListener {
   public void itemStateChanged(ItemEvent even) {
        if(even.getStateChange() == ItemEvent.SELECTED)
         commandTextField.setText(historycmdComboBox.getSelectedItem().toString());

   }
  }
  private void getStreams() throws IOException
  { output = new ObjectOutputStream(client.getOutputStream());
    output.flush();
    input = new ObjectInputStream(client.getInputStream());
    setEnabledExe(true);
  }
  private void connectToServer()
  { try { displayArea.removeAll();
          displayArea.setText("attempting connection\n");
          displayArea.setCaretPosition(displayArea.getText().length());
          client = new Socket(InetAddress.getByName(Password.JKserverAddr), 7123);
          displayArea.append("connected to: " + client.getInetAddress().getHostName());
          displayArea.setCaretPosition(displayArea.getText().length());
          connectButton.setText("Disconnect");
    }
    catch(IOException e)  { displayArea.append("error connection");
                            displayArea.setCaretPosition(displayArea.getText().length());
                            connectButton.setText("Connect");
    }
  }
  private void closeConnection() throws IOException
  { displayArea.append("\nclosing connection");
    displayArea.setCaretPosition(displayArea.getText().length());
    output.close();
    input.close();
    client.close();
    setEnabledExe(false);
    connectButton.setText("Connect");
  }
  private void sendData(String message)
  { try { byte[] messageB = message.getBytes();
            String temp = new String(message);
            String cmdStatus = new String("");
            temp = temp.toLowerCase();
            if(temp.equals(strTerminate))
            { displayArea.append("\nexecute: " + message + " <<<remote control is terminated");
              displayArea.setCaretPosition(displayArea.getText().length());
              closeConnection();
            }
            else  if(!message.equals(""))
                  { displayArea.append("\nexecute: " + message);
                    displayArea.setCaretPosition(displayArea.getText().length());
                  }

            output.write(messageB);
            output.flush();

            if(!message.equals(""))
              try { cmdStatus = (String)input.readObject();
              }
              catch(Exception e)
              { displayArea.append("\nread execute status error");
                displayArea.setCaretPosition(displayArea.getText().length());
                closeConnection();
              }
            if(!cmdStatus.equals("")) // connection already be closed by unusual reason
              if(cmdStatus.equals("failed"))  // failed
              { displayArea.append(" <<<unexecutable command");
                displayArea.setCaretPosition(displayArea.getText().length());
              }
              else
                try { String is = (String)input.readObject(); // read stdin
                        if((is = is.trim()).length() != 0)
                          is = "\n" + is;
                        is = "\n" + is;
                        String es = (String)input.readObject(); // read stderr
                        if((es = es.trim()).length() != 0)
                          es = es + "\n";
                        es = "\n"+es;
                        if(!(es.equals("\n") && is.equals("\n")))
                        { displayArea.append(is);
                          displayArea.setCaretPosition(displayArea.getText().length());
                          displayArea.append(es);
                          displayArea.setCaretPosition(displayArea.getText().length());
                        }
                }
              catch(Exception e)  { // do nothing
              }
    }
    catch(IOException ioException)
    { displayArea.append("\nwrite error");
      displayArea.setCaretPosition(displayArea.getText().length());
      try { closeConnection();
      }
      catch(IOException e)  { // do nothing
      }
    }
  }

  void execmdButton_actionPerformed(ActionEvent e) {
    historycmdComboBox.addItem(commandTextField.getText().toString());
    sendData(commandTextField.getText());
    commandTextField.setText("");
  }

  void shutButton_actionPerformed(ActionEvent e) {
    commandTextField.setText(strTerminate);
  }
  void setEnabledExe(boolean boo)
  { displayArea.setEnabled(boo);
    commandTextField.setEnabled(boo);
    execmdButton.setEnabled(boo);
  }

  void reButton_actionPerformed(ActionEvent e) {
    commandTextField.setText("shutdown -r now");
  }

  void getButton_actionPerformed(ActionEvent e) {
    displayArea.append("\nget log button is clicked");
    commandTextField.setText("");
  }
  public static void sendService(String str, ObjectOutputStream o)
  { try { o.writeObject(str);
          o.flush();
    }
    catch(IOException e)  {
    }
  }
  void connectButton_actionPerformed(ActionEvent e) {
    if(connectButton.getText().equals("Connect"))
    { try { connectToServer();
              getStreams();
              sendService(strRemoteCtrl, output);
      }
      catch(EOFException eofException)
      { System.out.println("server terminated connection");
      }
      catch(IOException ioException)
      { ioException.printStackTrace();
      }
    }
    else  { try { closeConnection();
                }
                catch(Exception ex)  { System.out.println("RemoteControl - can't close connection");
                }
    }
  }
}