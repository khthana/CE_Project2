import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import javax.swing.text.*;
import javax.swing.event.*;
import com.borland.jbcl.layout.*;
import java.sql.*;


public class TextEditPanel extends JPanel {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  public static final String strTextEdit = "textEdit";
  public static final String stdFile = "stdReport.txt";
  private Socket client;
  private ObjectOutputStream output;
  private ObjectInputStream input;
  // for load to db
  String table, cmd, chain, rulenum, target, new_chain_name, protocol_, protocol, saddr_, saddr, daddr_, daddr, jump = new String("");
  String inif_, inif, outif_, outif, frag, syn, frag_, syn_, sport_, sport, dport_, dport, flagmark_, flagmark, flagcomp = new String("");
  String tcp_op_, tcp_op, icmptype_, icmptype, match, msource_, msource, limit, limitrate, limitB, limitBnum = new String("");
  String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
  String setmark, rejecttype, settos, to, tosource, todes, toport, mul_sport, mul_dport = new String("");
  boolean multiport = false;

  JMenuBar menuBar1 = new JMenuBar();
  JMenu menuFile = new JMenu();
  JMenuItem menuFileExit = new JMenuItem();
  JPanel mainpanel = new JPanel();
  JToolBar toolBar = new JToolBar();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  ImageIcon image1;
  ImageIcon image2;
  ImageIcon image3;
  JLabel statusBar = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextArea editArea = new JTextArea();
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  JMenuItem jMenuItem3 = new JMenuItem();
  JMenuItem jMenuItem4 = new JMenuItem();
  JPanel contentPane = new JPanel();
  JMenu jMenu1 = new JMenu();
  JMenuItem jMenuItem6 = new JMenuItem();
  JMenuItem jMenuItem7 = new JMenuItem();
  JFileChooser jFileChooser1 = new JFileChooser();
  String currFileName = null;  // Full path with filename. null means new/untitled.
  boolean dirty = false;
  Document document1;
  XYLayout xYLayout1 = new XYLayout();
 XYLayout xYLayout2 = new XYLayout();
  JLabel logoLabel = new JLabel();
  JPanel buttonPanel = new JPanel();
  JButton loadtodbButton = new JButton();
  JButton analyButton = new JButton();
  XYLayout xYLayout3 = new XYLayout();
  XYLayout xYLayout4 = new XYLayout();
  JToolBar menutoolBar = new JToolBar();

  //Construct the frame
  public TextEditPanel() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      updateCaption();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception  {

    analyButton.setIcon(new ImageIcon("./Images/Swap.gif"));
    loadtodbButton.setIcon(new ImageIcon("./Images/dataStore.png"));

    jMenu1.setBackground(new Color(236,233,230));
    menuFile.setBackground(new Color(236,233,230));
    jMenuItem1.setBackground(new Color(236,233,230));
    jMenuItem2.setBackground(new Color(236,233,230));
    jMenuItem3.setBackground(new Color(236,233,230));
    jMenuItem4.setBackground(new Color(236,233,230));
    menuFileExit.setBackground(new Color(236,233,230));
    jMenuItem6.setBackground(new Color(236,233,230));
    jMenuItem7.setBackground(new Color(236,233,230));

    logoLabel.setIcon(new ImageIcon("./Images/TextEditor.gif"));
    image1 = new ImageIcon(TextEditPanel.class.getResource("openFile.png"));
    image2 = new ImageIcon(TextEditPanel.class.getResource("closeFile.gif"));
    image3 = new ImageIcon(TextEditPanel.class.getResource("help.gif"));

    document1 = editArea.getDocument();
    contentPane.setLayout(xYLayout4);
    statusBar.setBackground(new Color(236, 233, 230));
    statusBar.setOpaque(true);
    statusBar.setPreferredSize(new Dimension(3, 20));
    statusBar.setText(" statusBar");
    menuFile.setText("File");
    menuFileExit.setText("Exit");
    menuFileExit.addActionListener(new TextEditFrame_menuFileExit_ActionAdapter(this));

    jButton1.setIcon(image1);
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton1.addActionListener(new TextEditFrame_jButton1_actionAdapter(this));
    jButton1.setBackground(new Color(236, 233, 230));
    jButton1.setToolTipText("Open File");
    jButton2.setIcon(image2);
    jButton2.addActionListener(new TextEditFrame_jButton2_actionAdapter(this));
    jButton2.setBackground(new Color(236, 233, 230));
    jButton2.setToolTipText("Close File");
    editArea.setLineWrap(true);
    editArea.setWrapStyleWord(true);
    editArea.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyTyped(KeyEvent e) {
        editArea_keyTyped(e);
      }
    });
    editArea.setBackground(Color.white);
    editArea.setMinimumSize(new Dimension(0, 0));
    jMenuItem1.setText("New");
    jMenuItem1.addActionListener(new TextEditFrame_jMenuItem1_actionAdapter(this));
    jMenuItem2.setText("Open");
    jMenuItem2.addActionListener(new TextEditFrame_jMenuItem2_actionAdapter(this));
    jMenuItem3.setText("Save");
    jMenuItem3.addActionListener(new TextEditFrame_jMenuItem3_actionAdapter(this));
    jMenuItem4.setText("Save As");
    jMenuItem4.addActionListener(new TextEditFrame_jMenuItem4_actionAdapter(this));
    jMenu1.setText("Edit");
    jMenuItem6.setText("Foreground Color");
    jMenuItem6.addActionListener(new TextEditFrame_jMenuItem6_actionAdapter(this));
    jMenuItem7.setText("Background Color");
    jMenuItem7.addActionListener(new TextEditFrame_jMenuItem7_actionAdapter(this));
    document1.addDocumentListener(new TextEditFrame_document1_documentAdapter(this));
    jScrollPane1.setMinimumSize(new Dimension(0, 0));
    contentPane.setBackground(new Color(236, 233, 230));
    contentPane.setBorder(BorderFactory.createEtchedBorder());
    mainpanel.setLayout(xYLayout1);
    mainpanel.setBackground(new Color(236, 233, 230));
    mainpanel.setMaximumSize(new Dimension(800, 800));
    mainpanel.setPreferredSize(new Dimension(800, 800));
    this.setBackground(new Color(236, 233, 230));
    this.setMaximumSize(new Dimension(800, 800));
    this.setLayout(xYLayout2);
    logoLabel.setBorder(BorderFactory.createEtchedBorder());
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    buttonPanel.setBackground(new Color(236, 233, 230));
    buttonPanel.setBorder(BorderFactory.createEtchedBorder());
    buttonPanel.setLayout(xYLayout3);
    loadtodbButton.setBackground(new Color(236, 233, 230));
    loadtodbButton.setEnabled(false);
    loadtodbButton.setHorizontalTextPosition(SwingConstants.LEFT);
    loadtodbButton.setText("Load to Program");
    loadtodbButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loadtodbButton_actionPerformed(e);
      }
    });
    analyButton.setBackground(new Color(236, 233, 230));
    analyButton.setEnabled(false);
    analyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    analyButton.setText("Analysis");
    analyButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        analyButton_actionPerformed(e);
      }
    });
    xYLayout2.setWidth(630);
    xYLayout2.setHeight(427);
    toolBar.setBackground(new Color(236, 233, 230));
    menutoolBar.setBackground(new Color(236, 233, 230));
    menuBar1.setBackground(new Color(236, 233, 230));
    toolBar.add(jButton1);
    toolBar.add(jButton2);
    mainpanel.add(buttonPanel,        new XYConstraints(42, 343, 536, 55));
    mainpanel.add(logoLabel,     new XYConstraints(44, 8, 534, 72));
    toolBar.setBackground(new Color(236,233,230));

    menuFile.add(jMenuItem1);
    menuFile.add(jMenuItem2);
    menuFile.add(jMenuItem3);
    menuFile.add(jMenuItem4);
    menuFile.addSeparator();
    menuFile.add(menuFileExit);

    menuBar1.add(menuFile);
    menuBar1.add(jMenu1);

    contentPane.add(menutoolBar,  new XYConstraints(-1, 0, 530, 22));
    contentPane.add(jScrollPane1, new XYConstraints(3, 56, 524, 169));
    contentPane.add(statusBar, new XYConstraints(0, 225, 530, -1));
    contentPane.add(toolBar, new XYConstraints(0, 23, 530, 30));
    jScrollPane1.getViewport().add(editArea, null);
    menutoolBar.add(menuBar1);

    jMenu1.add(jMenuItem6);
    jMenu1.add(jMenuItem7);

    buttonPanel.add(loadtodbButton, new XYConstraints(257, 7, 158, 34));
    buttonPanel.add(analyButton, new XYConstraints(125, 7, 129, 34));
    mainpanel.add(contentPane, new XYConstraints(43, 85, 535, -1));
    this.add(mainpanel, new XYConstraints(0, 5, -1, -1));

   	// Database section
	db = new DBUtil();
	con = db.Establish();

  }// end jbinit();

  // Display the About box.
  void helpAbout() {
    TextEdit_AboutBox dlg = new TextEdit_AboutBox();
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.show();
  }

  // Handle the File|Open menu or button, invoking okToAbandon and openFile
  // as needed.
  void fileOpen() {
    if (!okToAbandon()) {
      return;
    }
    // Use the OPEN version of the dialog, test return for Approve/Cancel
    if (JFileChooser.APPROVE_OPTION == jFileChooser1.showOpenDialog(this)) {
      // Call openFile to attempt to load the text from file into TextArea
      openFile(jFileChooser1.getSelectedFile().getPath());
    }
    setAnalyButtonEnabled(true);
    this.repaint();
  }

  // Open named file; read text from file into jTextArea1; report to statusBar.
  void openFile(String fileName)  {
    try
    {
      // Open a file of the given name.
      File file = new File(fileName);

      // Get the size of the opened file.
      int size = (int)file.length();

      // Set to zero a counter for counting the number of
      // characters that have been read from the file.
      int chars_read = 0;

      // Create an input reader based on the file, so we can read its data.
      // FileReader handles international character encoding conversions.
      FileReader in = new FileReader(file);

      // Create a character array of the size of the file,
      // to use as a data buffer, into which we will read
      // the text data.
      char[] data = new char[size];

      // Read all available characters into the buffer.
      while(in.ready()) {
        // Increment the count for each character read,
        // and accumulate them in the data buffer.
        chars_read += in.read(data, chars_read, size - chars_read);
      }
      in.close();

      // Create a temporary string containing the data,
      // and set the string into the JTextArea.
      editArea.setText(new String(data, 0, chars_read));

      // Cache the currently opened filename for use at save time...
      this.currFileName = fileName;
      // ...and mark the edit session as being clean
      this.dirty = false;

      // Display the name of the opened directory+file in the statusBar.
      statusBar.setText("Opened "+fileName);
      updateCaption();
    }
    catch (IOException e)
    {
      statusBar.setText("Error opening "+fileName);
    }
  }

    // Save current file; handle not yet having a filename; report to statusBar.
  boolean saveFile() {

    // Handle the case where we don't have a file name yet.
    if (currFileName == null) {
      return saveAsFile();
    }

    try
    { // Open a file of the current name.
      File file = new File (currFileName);

      // Create an output writer that will write to that file.
      // FileWriter handles international characters encoding conversions.
      FileWriter out = new FileWriter(file);
      String text = editArea.getText();
      out.write(text);
      out.close();
      this.dirty = false;

      // Display the name of the saved directory+file in the statusBar.
      statusBar.setText("Saved to " + currFileName);
      updateCaption();
      return true;
    }
    catch (IOException e) {
      statusBar.setText("Error saving " + currFileName);
    }
    return false;
  }
  // Save current file, asking user for new destination name.
  // Report to statuBar.
  boolean saveAsFile() {
    this.repaint();
    // Use the SAVE version of the dialog, test return for Approve/Cancel
    if (JFileChooser.APPROVE_OPTION == jFileChooser1.showSaveDialog(this)) {
      // Set the current file name to the user's selection,
      // then do a regular saveFile
      currFileName = jFileChooser1.getSelectedFile().getPath();
      //repaints menu after item is selected
      this.repaint();
      return saveFile();
    }
    else {
      this.repaint();
      return false;
    }
  }
  // Check if file is dirty.
  // If so get user to make a "Save? yes/no/cancel" decision.
  boolean okToAbandon() {
    if (!dirty) {
      return true;
    }
    int value =  JOptionPane.showConfirmDialog(this, "Save changes?",
                                         "Text Edit", JOptionPane.YES_NO_CANCEL_OPTION) ;
    switch (value) {
       case JOptionPane.YES_OPTION:
         // yes, please save changes
         return saveFile();
       case JOptionPane.NO_OPTION:
         // no, abandon edits
         // i.e. return true without saving
         return true;
       case JOptionPane.CANCEL_OPTION:
       default:
         // cancel
         return false;
    }
  }
    // Update the caption of the application to show the filename and its dirty state.
  void updateCaption() {
    String caption;

    if (currFileName == null) {
       // synthesize the "Untitled" name if no name yet.
       caption = "Untitled";
    }
    else {
      caption = currFileName;
    }

    // add a "*" in the caption if the file is dirty.
    if (dirty) {
      caption = "* " + caption;
    }
    caption = "Text Editor - " + caption;
   // this.setTitle(caption);
  }

  //File | Exit action performed
  public void fileExit_actionPerformed(ActionEvent e) {
    if (okToAbandon()) {
      System.exit(0);
    }
  }

  //Help | About action performed
  public void helpAbout_actionPerformed(ActionEvent e) {
    helpAbout();
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
   // super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      fileExit_actionPerformed(null);
    }
  }

  void jMenuItem6_actionPerformed(ActionEvent e) {
    // Handle the "Foreground Color" menu item
    Color color = JColorChooser.showDialog(this,"Foreground Color",editArea.getForeground());
    if (color != null) {
      editArea.setForeground(color);
    }
    //repaints menu after item is selected
    this.repaint();
  }

  void jMenuItem7_actionPerformed(ActionEvent e) {
    // Handle the "Background Color" menu item
    Color color = JColorChooser.showDialog(this,"Background Color",editArea.getBackground());
    if (color != null) {
     editArea.setBackground(color);
    }
    //repaints menu after item is selected
    this.repaint();
  }

  void jMenuItem1_actionPerformed(ActionEvent e) {
    // Handle the File|New menu item.
    if (okToAbandon()) {
      // clears the text of the TextArea
      editArea.setText("");
      // clear the current filename and set the file as clean:
      currFileName = null;
      dirty = false;
      updateCaption();
    }
  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    //Handle the File|Open menu item.
    fileOpen();
  }

  void jMenuItem3_actionPerformed(ActionEvent e) {
    //Handle the File|Save menu item.
    saveFile();
  }

  void jMenuItem4_actionPerformed(ActionEvent e) {
    //Handle the File|Save As menu item.
    saveAsFile();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    //Handle tool bar Open button
    fileOpen();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    //Handle tool bar Save button
    saveFile();
  }

  void jButton3_actionPerformed(ActionEvent e) {
   //Handle tool bar About button
   helpAbout();
  }

  void document1_changedUpdate(DocumentEvent e) {
    if (!dirty) {
      dirty = true;
      updateCaption();
    }
  }

  void document1_insertUpdate(DocumentEvent e) {
    if (!dirty) {
      dirty = true;
      updateCaption();
    }
  }

  void document1_removeUpdate(DocumentEvent e) {
    if (!dirty) {
      dirty = true;
      updateCaption();
    }
  }

  void analyButton_actionPerformed(ActionEvent e) {
    runClient();
  }
  public void runClient()
  { try { connectToServer();
          getStreams();
          RemoteControl.sendService(strTextEdit, output);
          processConnection();
          closeConnection();
        }
    catch(EOFException eofException)
    { System.out.println("server terminated connection");
    }
    catch(IOException ioException)
    { ioException.printStackTrace();
    }
  }
  private void connectToServer()
  { try { statusBar.setText("attempting connection");
          client = new Socket(InetAddress.getByName(Password.JKserverAddr), 7123);
          statusBar.setText("connected to: " + client.getInetAddress().getHostName());
    }
    catch(IOException e)  { statusBar.setText("error connection");
    }
  }
  private void getStreams() throws IOException
  { output = new ObjectOutputStream(client.getOutputStream());
    output.flush();
    input = new ObjectInputStream(client.getInputStream());
  }
  private void processConnection() throws IOException
  { ////////////////////////////////////////////////////////////////////////////
    String strHeader = new String("modprobe -r ipchains\n" +
                                  "modprobe ip_tables\n" +
                                  "modprobe iptable_filter\n" +
                                  "modprobe iptable_nat\n" +
                                  "modprobe ip_conntrack\n" +
                                  "modprobe ip_conntrack_ftp\n\n");
    String strCloser = new String("\niptables -X" +
                                  "\niptables -F" +
                                  "\niptables -Z");
    try { ResultSet rsVar, rsChain;
          final String sqlSelectVar = new String("SELECT * FROM definevar order by ID");
          final String sqlSelectChain = new String("SELECT * FROM definechain order by ID");
          String varName = new String("");
          String varVal = new String("");
          String chainName = new String("");
          rsVar = db.SQLRetrive(sqlSelectVar);
          if(rsVar.first())
          { while(rsVar.next())
            { rsVar.previous();
              varName = rsVar.getString("Name");
              varVal = rsVar.getString("Value");
              strHeader += varName + "=\"" + varVal + "\"\n";
              rsVar.next();
            }
          }
          if(rsVar.last())
          { varName = rsVar.getString("Name");
            varVal = rsVar.getString("Value");
            strHeader += varName + "=\"" + varVal + "\"\n";
          }
          rsChain = db.SQLRetrive(sqlSelectChain);
          if(rsChain.first())
          { while(rsChain.next())
            { rsChain.previous();
              chainName = rsChain.getString("Name");
              if(!chainName.equals("INPUT") && !chainName.equals("OUTPUT") && !chainName.equals("FORWARD"))
                strHeader += "iptables -N " + chainName + "\n";
              rsChain.next();
            }
          }
          if(rsChain.last())
          { chainName = rsChain.getString("Name");
            if(!chainName.equals("INPUT") && !chainName.equals("OUTPUT") && !chainName.equals("FORWARD"))
                strHeader += "iptables -N " + chainName + "\n";
          }
    }
    catch(SQLException se)  { System.out.println("TextEdit - sql error");
                              System.out.println(se);
    }
    ////////////////////////////////////////////////////////////////////////////
    // send data in editArea
    System.out.println(strHeader + editArea.getText() + strCloser);
    output.writeObject(strHeader + editArea.getText() + strCloser);
    output.flush();
    statusBar.setText("sending data");
    // get exe status
    String exeStatus = new String("");
    try { exeStatus = (String)input.readObject();
      if(exeStatus.equals("ok"))
      { String mss = new String("");
        String is = (String)input.readObject();
        if(!is.equals(""))  // stdin
          mss = "STDIN:\n" + is.trim() + "\n\n";
        String es = (String)input.readObject();
        if(!es.equals(""))  // stderr
          mss = mss + "STDERR:\n" + es.trim();
        if(mss.equals(""))  // code is ok
        { statusBar.setText("this code is ok >>> please load to db");
          setAnalyButtonEnabled(false);
        }
        else  { FileWriter stdFileWriter = new FileWriter(stdFile);
                    stdFileWriter.write(mss);
                    stdFileWriter.close();
                    Runtime.getRuntime().exec("wordpad " + stdFile);
                    statusBar.setText("this code is error >>> please read \"" + stdFile + "\"");
        }
      }
      else  { statusBar.setText("can't analyze this code >>> please try again");
                  closeConnection();
      }
    }
    catch(Exception e)  { statusBar.setText("error >>> connection will be closed");
                                          closeConnection();
    }
  }
  private String sepCode(String code)
  { String sep = new String("");
    while((code.length() != 0) && (!code.regionMatches(0, " -", 0, 2)) && (!code.regionMatches(0, " ! -", 0, 4)))
    { sep = sep + code.charAt(0);
      code = code.substring(1);
      if(sep.equals("!"))
      { code = code.substring(1);
        code = "*" + code;
      }
    }
    return sep;
  }
  private void interp(String s)
  { s = s + " ";  // for string has not " "
    String para = s.substring(0, s.indexOf(" "));
    String value = s.substring(s.indexOf(" ")).trim();

    // t
    if(para.equals("-t"))
      table = value;
    // ANXLFZ
    if(para.equals("-A") || para.equals("--append") ||
      para.equals("-C") || para.equals("--check") ||
      para.equals("-N") || para.equals("--new-chain") ||
      para.equals("-X") || para.equals("--delete-chain") ||
      para.equals("-L") || para.equals("--list") || // LFZ >>> chain maybe is a ""
      para.equals("-F") || para.equals("--flush") ||
      para.equals("-Z") || para.equals("--zero"))
    { cmd = para;
      chain = value;
    }
    // commands
    // DRI
    if(para.equals("-D") || para.equals("--delete") ||
      para.equals("-R") || para.equals("--replace") ||
      para.equals("-I") || para.equals("--insert"))
    { cmd = para;
      value = value + " ";
      chain = value.substring(0, value.indexOf(" "));
      rulenum = value.substring(value.indexOf(" ")).trim();
    }
    // P
    if(para.equals("-P") || para.equals("--policy"))
    { cmd = para;
      value = value + " ";
      chain = value.substring(0, value.indexOf(" "));
      target = value.substring(value.indexOf(" ")).trim();
    }
    // E
    if(para.equals("-E") || para.equals("--rename-chain"))
    { cmd = para;
      value = value + " ";
      chain = value.substring(0, value.indexOf(" "));
      new_chain_name = value.substring(value.indexOf(" ")).trim();
    }
    if(para.equals("-h") || para.equals("--help"))
      cmd = para;
    // parameters make up rule specifications
    // p
    if(para.equals("-p") || para.equals("--proto"))
    { if(value.startsWith("!"))
      { protocol_ = "!";
        value = value.replace('!', ' ');
      }
      protocol = value.trim();
    }
    // s
    if(para.equals("-s") || para.equals("--source") || para.equals("--src"))
    { if(value.startsWith("!"))
      { saddr_ = "!";
        value = value.replace('!', ' ');
      }
      saddr = value.trim();
    }
    // d
    if(para.equals("-d") || para.equals("--destination") || para.equals("--dst"))
    { if(value.startsWith("!"))
      { daddr_ = "!";
        value = value.replace('!', ' ');
      }
      daddr = value.trim();
    }
    // j
    if(para.equals("-j") || para.equals("--jump"))
    { jump = para;
      target = value;
    }
    // i
    if(para.equals("-i") || para.equals("--in-interface"))
    { if(value.startsWith("!"))
      { inif_ = "!";
        value = value.replace('!', ' ');
      }
      inif = value.trim();
    }
    // o
    if(para.equals("-o") || para.equals("--out-interface"))
    { if(value.startsWith("!"))
      { outif_ = "!";
        value = value.replace('!', ' ');
      }
      outif = value.trim();
    }
    // f
    if(para.equals("-f") || para.endsWith("--fragment"))
      frag = para;
    // syn
    if(para.equals("--syn"))
      syn = para;
    // start by "!"
    if(para.startsWith("!"))
    { para = para.replace('!', ' ');
      para = para.replace('*', ' ');
      para = para.trim();
      if(para.equals("-f") || para.equals("--fragment"))
      { frag_ = "!";
        frag = para;
      }
      if(para.equals("--syn"))
      { syn_ = "!";
        syn = para;
      }
    }
    // sport
    if(para.equals("--sport") || para.equals("--source-port"))
    { if(value.startsWith("!"))
      { sport_ = "!";
        value = value.replace('!', ' ');
      }
      if(multiport)
      { mul_sport = value.trim();
        multiport = false;
      }
      else  sport = value.trim();
    }
    // dport
    if(para.equals("--dport") || para.equals("--destination-port"))
    { if(value.startsWith("!"))
      { dport_ = "!";
        value = value.replace('!', ' ');
      }
      if(multiport)
      { mul_dport = value.trim();
        multiport = false;
      }
      else  dport = value.trim();
    }
    // tcp-flags
    if(para.equals("--tcp-flags"))
    { if(value.startsWith("!"))
      { flagmark_ = "!";
        value = value.replace('!', ' ');
        value = value.trim();
      }
      flagmark = value.substring(0, value.indexOf(" "));
      flagcomp = value.substring(value.indexOf(" ")).trim();
    }
    // tcp-option
    if(para.equals("--tcp-option"))
    { if(value.startsWith("!"))
      { tcp_op_ = "!";
        value = value.replace('!', ' ');
      }
      tcp_op = value.trim();
    }
    // icmp-type
    if(para.equals("--icmp-type"))
    { if(value.startsWith("!"))
      { icmptype_ = "!";
        value = value.replace('!', ' ');
      }
      icmptype = value.trim();
    }
    // m
    if(para.equals("-m") || para.equals("--match"))
    { match = match + " " + value;
      match = match.trim();
      if(value.trim().equals("multiport"))
        multiport = true;
    }
    // mac-source
    if(para.equals("--mac-source"))
    { if(value.startsWith("!"))
      { msource_ = "!";
        value = value.replace('!', ' ');
      }
      msource = value.trim();
    }
    // limit
    if(para.equals("--limit"))
    { limit = para;
      limitrate = value;
    }
    // limit-burst
    if(para.equals("--limit-burst"))
    { limitB = para;
      limitBnum = value;
    }
    // port
    if(para.equals("--port"))
      sdport = value;
    // mark
    if(para.equals("--mark"))
      markvalue = value;
    // ower
    if(para.equals("--uid-owner"))
      userid = value;
    if(para.equals("--gid-owner"))
      groupid = value;
    if(para.equals("--pid-owner"))
      processid = value;
    if(para.equals("--sid-owner"))
      sessionid = value;
    // state
    if(para.equals("--state"))
      state = value;
    // tos
    if(para.equals("--tos"))
      tos = value;
    // log-level
    if(para.equals("--log-level"))
      level = value;
    // log-prefix
    if(para.equals("--log-prefix"))
      prefix = value;
    // log-tcp-sequence
    if(para.equals("--log-tcp-sequence"))
      logseq = para;
    // log-tcp-options
    if(para.equals("--log-tcp-options"))
      logop = para;
    // log-ip-options
    if(para.equals("--log-ip-options"))
      logipop = para;
    // set-mark
    if(para.equals("--set-mark"))
      setmark = value;
    // reject-with
    if(para.equals("--reject-with"))
      rejecttype = value;
    // set-tos
    if(para.equals("--set-tos"))
      settos = value;
    // to
    if(para.equals("--to"))
      to = value;
    // to-source
    if(para.equals("--to-source"))
      tosource = value;
    // to-destination
    if(para.equals("--to-destination"))
      todes = value;
    // to-port
    if(para.equals("--to-ports"))
      toport = value;
  }
  private void closeConnection() throws IOException
  { output.close();
    input.close();
    client.close();
  }
  private void setAnalyButtonEnabled(boolean b)
  { analyButton.setEnabled(b);
    loadtodbButton.setEnabled(!b);
  }

  void editArea_keyTyped(KeyEvent e) {
    setAnalyButtonEnabled(true);
  }
  private void resetDbPara()
  { table = cmd = chain = rulenum = target = new_chain_name = protocol_ = protocol = saddr_ = saddr = daddr_ = daddr = jump = "";
    inif_ = inif = outif_ = outif = frag = syn = frag_ = syn_ = sport_ = sport = dport_ = dport = flagmark_ = flagmark = flagcomp = "";
    tcp_op_ = tcp_op = icmptype_ = icmptype = match = msource_ = msource = limit = limitrate = limitB = limitBnum = "";
    sdport = markvalue = userid = groupid = processid = sessionid = state = tos = level = prefix = logseq = logop = logipop = "";
    setmark = rejecttype = settos = to = tosource = todes = toport = mul_sport = mul_dport = "";
    multiport = false;
  }
  private void systemOutDbPara()
  { if(!table.equals(""))
      System.out.println("table: " + table);
    if(!cmd.equals(""))
      System.out.println("cmd: " + cmd);
    if(!chain.equals(""))
      System.out.println("chain: " + chain);
    if(!rulenum.equals(""))
      System.out.println("rulenum: " + rulenum);
    if(!target.equals(""))
      System.out.println("target: " + target);
    if(!new_chain_name.equals(""))
      System.out.println("new_chain_name: " + new_chain_name);
    if(!protocol_.equals(""))
      System.out.println("protocol_: " + protocol_);
    if(!protocol.equals(""))
      System.out.println("protocol: " + protocol);
    if(!saddr_.equals(""))
      System.out.println("saddr_: " + saddr_);
    if(!saddr.equals(""))
      System.out.println("saddr: " + saddr);
    if(!daddr_.equals(""))
      System.out.println("daddr_: " + daddr_);
    if(!daddr.equals(""))
      System.out.println("daddr: " + daddr);
    if(!jump.equals(""))
      System.out.println("jump: " + jump);
    if(!inif_.equals(""))
      System.out.println("inif_: " + inif_);
    if(!inif.equals(""))
      System.out.println("inif: " + inif);
    if(!outif_.equals(""))
      System.out.println("outif_: " + outif_);
    if(!outif.equals(""))
      System.out.println("outif: " + outif);
    if(!frag.equals(""))
      System.out.println("frag: " + frag);
    if(!syn.equals(""))
      System.out.println("syn: " + syn);
    if(!frag_.equals(""))
      System.out.println("frag_: " + frag_);
    if(!syn_.equals(""))
      System.out.println("syn_: " + syn_);
    if(!sport_.equals(""))
      System.out.println("sport_: " + sport_);
    if(!sport.equals(""))
      System.out.println("sport: " + sport);
    if(!dport_.equals(""))
      System.out.println("dport_: " + dport_);
    if(!dport.equals(""))
      System.out.println("dport: " + dport);
    if(!flagmark_.equals(""))
      System.out.println("flagmark_: " + flagmark_);
    if(!flagmark.equals(""))
      System.out.println("flagmark: " + flagmark);
    if(!flagcomp.equals(""))
      System.out.println("flagcomp: " + flagcomp);
    if(!tcp_op_.equals(""))
      System.out.println("tcp_op_: " + tcp_op_);
    if(!tcp_op.equals(""))
      System.out.println("tcp_op: " + tcp_op);
    if(!icmptype_.equals(""))
      System.out.println("icmptype_: " + icmptype_);
    if(!icmptype.equals(""))
      System.out.println("icmptype: " + icmptype);
    if(!match.equals(""))
      System.out.println("match: " + match);
    if(!msource.equals(""))
      System.out.println("msource: " + msource);
    if(!limit.equals(""))
      System.out.println("limit: " + limit);
    if(!limitrate.equals(""))
      System.out.println("limitrate: " + limitrate);
    if(!limitB.equals(""))
      System.out.println("limitB: " + limitB);
    if(!limitBnum.equals(""))
      System.out.println("limitBnum: " + limitBnum);
    if(!sdport.equals(""))
      System.out.println("sdport: " + sdport);
    if(!markvalue.equals(""))
      System.out.println("markvalue: " + markvalue);
    if(!userid.equals(""))
      System.out.println("userid: " + userid);
    if(!groupid.equals(""))
      System.out.println("groupid: " + groupid);
    if(!processid.equals(""))
      System.out.println("processid: " + processid);
    if(!sessionid.equals(""))
      System.out.println("sessionid: " + sessionid);
    if(!state.equals(""))
      System.out.println("state: " + state);
    if(!tos.equals(""))
      System.out.println("tos: " + tos);
    if(!level.equals(""))
      System.out.println("level: " + level);
        if(!prefix.equals(""))
      System.out.println("prefix: " + prefix);
    if(!logseq.equals(""))
      System.out.println("logseq: " + logseq);
    if(!logop.equals(""))
      System.out.println("logop: " + logop);
    if(!logipop.equals(""))
      System.out.println("logipop: " + logipop);
    if(!setmark.equals(""))
      System.out.println("setmark: " + setmark);
    if(!rejecttype.equals(""))
      System.out.println("rejecttype: " + rejecttype);
    if(!settos.equals(""))
      System.out.println("settos: " + settos);
    if(!to.equals(""))
      System.out.println("to: " + to);
    if(!tosource.equals(""))
      System.out.println("tosource: " + tosource);
    if(!todes.equals(""))
      System.out.println("todes: " + todes);
    if(!toport.equals(""))
      System.out.println("toport: " + toport);
    if(!mul_sport.equals(""))
      System.out.println("mul_sport: " + mul_sport);
    if(!mul_dport.equals(""))
      System.out.println("mul_dport: " + mul_dport);
  }
  public void loadToDB()  {
    String field="",value="",SQL="";
  SQL = "INSERT INTO confige ";

  field = "tablename,Chain,Action,notprotocal,protocal,notsrcip,src_ip,notdesip,des_ip,jump,"+
          "notsrcdevice,src_device,notdesdevice,des_device,frag,syn,notfrag,notsyn,notsrcport,src_port,notdesport,des_port,notflagmark,flagmark,flagcomp,"+
          "sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop,"+
          "nottcp_op,tcp_op,noticmptype,icmptype,matchs,notmsource,msource,limits,limitrate,limitB,limitBnum,"+
          "setmark,rejecttype,settos,natto,tosource,todes,toport, mul_sport, mul_dport";

  value = "'" + table + "', '" + chain + "', '" + target + "', '" + protocol_ + "', '" + protocol.toUpperCase() + "', '" + saddr_ + "', '" + saddr + "', '" + daddr_ + "', '" + daddr + "', '" + jump + "', '" +
                inif_ + "', '" + inif + "', '" + outif_ + "', '" + outif + "', '" + frag + "', '" + syn + "', '" + frag_ + "', '" + syn_ + "', '" + sport_ + "', '" + sport + "', '" + dport_ + "', '" + dport + "', '" + flagmark_ + "', '" + flagmark + "', '" + flagcomp + "', '" +
                sdport + "', '" + markvalue + "', '" + userid + "', '" + groupid + "', '" + processid + "', '" + sessionid + "', '" + state + "', '" + tos + "', '" + level + "', '" + prefix + "', '" + logseq + "', '" + logop + "', '" + logipop + "', '" +
                tcp_op_ + "', '" + tcp_op + "', '" + icmptype_ + "', '" + icmptype + "', '" + match + "', '" + msource_ + "', '" + msource + "', '" + limit + "', '" + limitrate + "', '" + limitB + "', '" + limitBnum + "', '" +
                setmark + "', '" + rejecttype + "', '" + settos + "', '" + to + "', '" + tosource + "', '" + todes + "', '" + toport + "', '" + mul_sport + "', '" +mul_dport + "'";

      SQL = SQL + "(" + field + ") VALUES (" + value + ")";
      System.out.println(SQL);
      db.SQLExecute(SQL);

       try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

  }
  public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }
  void loadtodbButton_actionPerformed(ActionEvent e) {
    try { statusBar.setText("please wait >>> loading to database");
           StringReader sr = new StringReader(editArea.getText());
           BufferedReader buffReader = new BufferedReader(sr);
           String codeLine = new String("");
           while((codeLine = buffReader.readLine()) != null)
           { codeLine = codeLine.trim();
             if(!codeLine.equals(""))
             { if(codeLine.startsWith("iptables"))
               { while(codeLine.endsWith("\\"))
                 { codeLine = (codeLine.replace('\\', ' ')).trim() + " ";
                   String moreLine = buffReader.readLine();
                   moreLine = moreLine.trim();
                   codeLine = codeLine + moreLine;
                 }
                 System.out.println("#################################");
                 System.out.println(codeLine);
                 String tcLine = new String(codeLine); // temp code line
                 tcLine = tcLine.substring(new String("iptables").length());  // cut "iptables"
                 tcLine = tcLine.trim();
                 resetDbPara();
                 while(!tcLine.equals(""))
                 { String sep = sepCode(tcLine); // separate
                   tcLine = tcLine.substring(sep.length()).trim();
                   interp(sep);  // interprete
                 }
                 systemOutDbPara();
                 // load to db here
                 loadToDB();
                 loadtodbButton.setEnabled(false);
               }
             }
           }
    }
    catch(Exception ex)  { System.out.println(ex);
    }
  }
}
class TextEditFrame_menuFileExit_ActionAdapter implements ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_menuFileExit_ActionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.fileExit_actionPerformed(e);
  }
}

class TextEditFrame_menuHelpAbout_ActionAdapter implements ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_menuHelpAbout_ActionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.helpAbout_actionPerformed(e);
  }
}

class TextEditFrame_jMenuItem6_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jMenuItem6_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem6_actionPerformed(e);
  }
}

class TextEditFrame_jMenuItem7_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jMenuItem7_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem7_actionPerformed(e);
  }
}

class TextEditFrame_jMenuItem1_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jMenuItem1_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem1_actionPerformed(e);
  }
}

class TextEditFrame_jMenuItem2_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jMenuItem2_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem2_actionPerformed(e);
  }
}

class TextEditFrame_jMenuItem3_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jMenuItem3_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem3_actionPerformed(e);
  }
}

class TextEditFrame_jMenuItem4_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jMenuItem4_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem4_actionPerformed(e);
  }
}

class TextEditFrame_jButton1_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jButton1_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class TextEditFrame_jButton2_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jButton2_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class TextEditFrame_jButton3_actionAdapter implements java.awt.event.ActionListener {
  TextEditPanel adaptee;

  TextEditFrame_jButton3_actionAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class TextEditFrame_document1_documentAdapter implements javax.swing.event.DocumentListener {
  TextEditPanel adaptee;

  TextEditFrame_document1_documentAdapter(TextEditPanel adaptee) {
    this.adaptee = adaptee;
  }

  public void changedUpdate(DocumentEvent e) {
    adaptee.document1_changedUpdate(e);
  }

  public void insertUpdate(DocumentEvent e) {
    adaptee.document1_insertUpdate(e);
  }

  public void removeUpdate(DocumentEvent e) {
    adaptee.document1_removeUpdate(e);
  }
}//end class
