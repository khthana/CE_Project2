import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.sql.*;
import java.net.InetAddress;


public class LockPassword extends JFrame {
  DBUtil db;
  Connection con;
  ResultSet rs;
 // Frame2 frame;
  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  XYLayout xYLayout2 = new XYLayout();
  JLabel loginLabel = new JLabel();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  JPasswordField LockPasswordTextField = new JPasswordField();
  JLabel usernameLabel = new JLabel();
  JTextField usernameTextField = new JTextField();
  JLabel passwdLabel = new JLabel();
  JLabel ImageLabel = new JLabel();
  JButton okButton = new JButton();
  JPasswordField passwordTextField = new JPasswordField();
  String username,dpassword="";

  public LockPassword() {

    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
      //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    //setVisible(true);

  }

  void jbInit() throws Exception {
    try {
              InetAddress myhost = InetAddress.getLocalHost();
              myhostLabel.setText("Host Name : "+myhost.getHostName()+"  IP Address : "+myhost.getHostAddress());
    }
    catch(Exception e)
    {
        System.out.println("Failed to find myHost");
        e.printStackTrace();
    }

    panel1.setLayout(xYLayout2);
    this.getContentPane().setLayout(xYLayout1);
    xYLayout1.setWidth(390);
    xYLayout1.setHeight(244);
    panel1.setBackground(new Color(236, 233, 230));
    loginLabel.setBackground(new Color(236, 233, 226));
    loginLabel.setBorder(BorderFactory.createEtchedBorder());
    loginLabel.setDisplayedMnemonic('0');
    loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
    loginLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    this.getContentPane().setBackground(new Color(236, 233, 230));
    this.setTitle("");
    jPanel1.setBackground(new Color(236, 233, 226));
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(xYLayout3);
    usernameLabel.setText("User name");
    usernameLabel.setIcon(new ImageIcon("./Images/User.png"));
    usernameTextField.setText("admin");
    passwdLabel.setText("Password");
    passwdLabel.setIcon(new ImageIcon("./Images/Key.png"));
    ImageLabel.setBorder(BorderFactory.createEtchedBorder());
    ImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    ImageLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    ImageLabel.setIcon(new ImageIcon("./Images/firewall_login.png"));
    okButton.setBackground(new Color(236, 233, 230));
    okButton.setText("OK");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    //okButton.addActionListener(new clickedOk());
    myhostLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    myhostLabel.setHorizontalTextPosition(SwingConstants.LEFT);
    jPanel1.add(okButton, new XYConstraints(178, 111, 89, 29));
    jPanel1.add(usernameLabel, new XYConstraints(113, 32, 90, 31));
    jPanel1.add(passwdLabel, new XYConstraints(112, 73, 90, 28));
    jPanel1.add(passwordTextField, new XYConstraints(206, 76, 136, 21));
    jPanel1.add(usernameTextField, new XYConstraints(207, 36, 135, 23));
    jPanel1.add(ImageLabel,    new XYConstraints(12, 26, 84, 110));
    jPanel1.add(myhostLabel,   new XYConstraints(15, 149, 346, 19));
    panel1.add(loginLabel,     new XYConstraints(9, 8, 367, 34));
    panel1.add(jPanel1, new XYConstraints(9, 47, 368, 175));
    this.getContentPane().add(panel1,      new XYConstraints(1, 6, 389, 228));
    jPanel1.add(passwordTextField, new XYConstraints(208, 75, 134, 21));
    loginLabel.setIcon(new ImageIcon("./Images/Lock.gif"));

       db = new DBUtil();
       con = db.Establish();

    ImageIcon icon = new ImageIcon(("images/Lock.png"));
    this.setIconImage(icon.getImage());
    this.setTitle("Login");

  }// end jbinit()
 /*class clickedOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       String SQL="";

              SQL = "SELECT * FROM user";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

         try {
                  rs.next();
                  username = rs.getString("username");
                  dpassword = rs.getString("password");

                  System.out.println("username : "+username);
                  System.out.println("dpassword : "+dpassword);

               }
          catch (SQLException ex) {
                     System.out.println(ex.getMessage());
          }
    if(username.equalsIgnoreCase(usernameTextField.getText().trim())) {
    if (isPasswordCorrect()) {
	JOptionPane.showMessageDialog(null,"Success! You typed the right password.",
	    "Success!",JOptionPane.INFORMATION_MESSAGE);

             Application1.frame.setEnabled(true);
             dispose();
             hide();

        passwordTextField.setText("");

    } else {

	JOptionPane.showMessageDialog(null,
	    "Invalid password. Try again.",
	    "Error Message",
	    JOptionPane.ERROR_MESSAGE);
    }
    }
    else{
           JOptionPane.showMessageDialog(null,
	    "Invalid password. Try again.",
	    "Error Message",
	    JOptionPane.ERROR_MESSAGE);

    }

      }
    }//////////end clickedOk*/

    boolean isPasswordCorrect() {
    char[] password = passwordTextField.getPassword();

        if(password.length != dpassword.length())
            return false;
        for(int i=0;i<password.length;i++)
         if(  password[i] != (dpassword.charAt(i)))
             return false;
        return true;
    }
  JLabel myhostLabel = new JLabel();

  void okButton_actionPerformed(ActionEvent e) {
    //byte[] loginByte = (usernameTextField.getText() + "@" + passwordTextField.getPassword().
    char[] c = passwordTextField.getPassword();
    String j = new String(c);
    byte[] b = new byte[passwordTextField.getPassword().length];
    for(int i = 0; i < passwordTextField.getPassword().length; i++) {
      b[i] = (byte)c[i];
      //j = j + (String)c[i];
    }
    System.out.println(j);
  }

  }// end class
