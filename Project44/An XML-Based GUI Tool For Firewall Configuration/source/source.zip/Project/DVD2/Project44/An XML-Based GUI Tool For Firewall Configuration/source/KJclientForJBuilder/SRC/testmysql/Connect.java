package testmysql;

import java.awt.*;
import java.net.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
import java.awt.event.*;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.crypto.*;
import org.bouncycastle.*;
import org.bouncycastle.jce.provider.*;
import org.w3c.dom.*;
import org.apache.xerces.parsers.DOMParser;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class Connect extends JFrame {

  DBUtil db;
  Connection con;
  public static ResultSet rs, rsDefineVar, rsNat, rsOptions, rsBlacklist, rsChain;

  String match_mac = new String("");
  String match_limit = new String("");
  String match_mul = new String("");
  String match_state = new String("");
  String match_unclean = new String("");
  String match_tos = new String("");
  String displayRule = new String("");
  final String xmlFile = new String("firewallconfig.xml");
  private static final String strSendXML = new String("sendXML");
  private static final String strReceiveXML = new String("recXML");
  private Socket client;
  private ObjectOutputStream output;
  private ObjectInputStream input;
  private String strScriptFile = new String("");
  private String strCode = new String("");
  private final String privFileName = new String("privKey.dec");
  private String encryptedFile = new String("xmlEncrypted.txt");

  String table, cmd, chain, rulenum, target, new_chain_name, protocol_, protocol, saddr_, saddr, daddr_, daddr, jump = new String("");
  String inif_, inif, outif_, outif, frag, syn, frag_, syn_, sport_, sport, dport_, dport, flagmark_, flagmark, flagcomp = new String("");
  String tcp_op_, tcp_op, icmptype_, icmptype, match, msource_, msource, limit, limitrate, limitB, limitBnum = new String("");
  String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
  String setmark, rejecttype, settos, to, tosource, todes, toport, mul_sport, mul_dport = new String("");
  boolean multiport = false;

  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JButton activateButton = new JButton(new ImageIcon("images/Upload.png"));
  JButton deactivateButton = new JButton(new ImageIcon("images/Download.png"));
  int value,NoLastRow;
  JComboBox comboBlacklist = new JComboBox();

  public Connect() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void getMatch(String match)  {
    String temp = new String("");
    match_mac = match_limit = match_mul = match_state = match_unclean = match_tos = "";
    match = match.trim();
    match = match + " ";  // set match to format "match1 match2 ... matchN "
    while(match.length() != 0)
    { temp = match.substring(0, match.indexOf(" ")).trim();
      match = match.substring(match.indexOf(" ")+1);
      if(temp.equals("mac"))
        match_mac = temp;
      if(temp.equals("limit"))
        match_limit = temp;
      if(temp.equals("multiport"))
        match_mul = temp;
      if(temp.equals("state"))
        match_state = temp;
      if(temp.equals("unclean"))
        match_unclean = temp;
      if(temp.equals("tos"))
        match_tos = temp;
    }
  }
  private String nodeValue(String value)
  { String str = new String("");
    if(value.equals("null"))
      str = "";
    else  str = value;
    return str;
  }
  private String genPara(String value, String para)
  { String str = new String("");
    if(value.equals(""))
      str = "";
    else  str = " " + para + " " +value;
    return str;
  }
  private void compileXML_(Node node)
  { switch(node.getNodeType())
    { case  Node.ELEMENT_NODE:
        String nodeName = node.getNodeName();
        if(nodeName.equals("VAR"))  // get var's name
        { NamedNodeMap attr = node.getAttributes();
          String varName = nodeValue(attr.item(0).getNodeValue());
          String varValue = nodeValue(node.getFirstChild().getFirstChild().getNodeValue());
          String varComment = nodeValue(node.getFirstChild().getNextSibling().getFirstChild().getNodeValue());
          String field = "Name, Value, Comment";
          String value = "'" + varName + "', '" + varValue + "', '" + varComment + "'";
          String sqlInsertVar = "INSERT INTO definevar (" + field + ") VALUES (" + value + ")";
          System.out.println(sqlInsertVar);
          db.SQLExecute(sqlInsertVar);
          try { db.con.commit();
          }
          catch(SQLException e) { System.out.println("compileXML_ - VAR - insert to db error");
                                  System.out.println(e.getMessage());
          }
        }
        if(nodeName.equals("CHAIN"))
        { NamedNodeMap attr = node.getAttributes();
          String chainName = nodeValue(attr.item(0).getNodeValue());
          String chainPolicy = nodeValue(node.getFirstChild().getFirstChild().getNodeValue());
          String chainComment = nodeValue(node.getFirstChild().getNextSibling().getFirstChild().getNodeValue());
          String field = "Name, Comment, policy";
          String value = "'" + chainName + "', '" + chainComment + "', '" + chainPolicy + "'";
          String sqlInsertChain = "INSERT INTO definechain (" + field + ") VALUES (" + value + ")";
          System.out.println(sqlInsertChain);
          db.SQLExecute(sqlInsertChain);
          try { db.con.commit();
          }
          catch(SQLException e) { System.out.println("compileXML_ - CHAIN - insert to db error");
                                  System.out.println(e.getMessage());
          }
        }
        if(nodeName.equals("BL"))
        { String blacklistAddr = nodeValue(node.getFirstChild().getFirstChild().getNodeValue());
          String blacklistStatus = nodeValue(node.getFirstChild().getNextSibling().getFirstChild().getNodeValue());
          String field = "HostAddr, Status";
          String value = "'" + blacklistAddr + "', '" + blacklistStatus + "'";
          String sqlInsertBlacklist = "INSERT INTO blacklist (" + field + ") VALUES (" + value + ")";
          System.out.println(sqlInsertBlacklist);
          db.SQLExecute(sqlInsertBlacklist);
          try { db.con.commit();
          }
          catch(SQLException e) { System.out.println("compileXML_ - BL - insert to db error");
                                  System.out.println(e.getMessage());
          }
        }
        if(nodeName.equals("OPTIONS"))
        { NodeList kids = node.getChildNodes();
          String opDisBroadcasts = nodeValue(kids.item(0).getFirstChild().getNodeValue());
          String opDisPings = nodeValue(kids.item(1).getFirstChild().getNodeValue());
          String opDisIcmpRedirect = nodeValue(kids.item(2).getFirstChild().getNodeValue());
          String opEnProtection = nodeValue(kids.item(3).getFirstChild().getNodeValue());
          String opDisSpoofing = nodeValue(kids.item(4).getFirstChild().getNodeValue());
          String opEnSynCookies = nodeValue(kids.item(5).getFirstChild().getNodeValue());
          String opDisSRouting = nodeValue(kids.item(6).getFirstChild().getNodeValue());
          String opLogMartians = nodeValue(kids.item(7).getFirstChild().getNodeValue());
          String opDyDrop = nodeValue(kids.item(8).getFirstChild().getNodeValue());
          String sqlUpdateOptions = "UPDATE options drespping = '" + opDisPings + "', drespbroad = '" + opDisBroadcasts +
                                    "', drespicmpredi = '" + opDisIcmpRedirect + "', enbaderror = '" + opEnProtection +
                                    "', dipspoof = '" + opDisSpoofing + "', entcpsyn = '" + opEnSynCookies +
                                    "', dsrcrouting = '" + opDisSRouting + "', logmar = '" + opLogMartians +
                                    "', dydrop = '" + opDyDrop + "' WHERE ID = 1";
          db.SQLExecute(sqlUpdateOptions);
          System.out.println(sqlUpdateOptions);
          try { db.con.commit();
          }
          catch(SQLException e) { System.out.println("compileXML_ - OPTIONS - insert to db error");
                                  System.out.println(e.getMessage());
          }
        }
        if(nodeName.equals("RULE"))
          strCode += "iptables";
        if(nodeName.equals("PROTOCOL"))
          strCode += " -p";
        if(nodeName.equals("SRC_PORT"))
          strCode += " --sport";
        if(nodeName.equals("DES_PORT"))
          strCode += " --dport";
        if(nodeName.equals("TCP_FLAG"))
          strCode += " --tcp-flags";
        //if(nodeName.equals("SYN"))
        if(nodeName.equals("TCP_OP"))
          strCode += " --tcp-option";
        if(nodeName.equals("ICMP_TYPE"))
          strCode += " --icmp-type";
        if(nodeName.equals("SRC"))
          strCode += " -s";
        if(nodeName.equals("DES"))
          strCode += " -d";
        if(nodeName.equals("IN_IF"))
          strCode += " -i";
        if(nodeName.equals("OUT_IF"))
          strCode += " -o";
        //if(nodeName.equals("FRAGMENT"))
        //if(nodeName.equals("MATCH"))
        if(nodeName.equals("MAC") || nodeName.equals("LIMIT") || nodeName.equals("MULTIPORT") || nodeName.equals("STATE") ||
          nodeName.equals("TOS"))
          strCode += " -m";
        if(nodeName.equals("SOURCE"))
          strCode += " --mac-source";
        if(!nodeName.equals("VAR") && !nodeName.equals("CHAIN") && !nodeName.equals("BL") && !nodeName.equals("OPTIONS"))
        { NodeList kids = node.getChildNodes();
          if(kids != null)
            for(int j = 0; j < kids.getLength(); j++)
              compileXML_(kids.item(j));
        }
        break;
      case  Node.TEXT_NODE:
        String parentName = node.getParentNode().getNodeName();
        String nodeVal = nodeValue(node.getNodeValue());
        if(parentName.equals("VALUE") && node.getParentNode().getParentNode().getNodeName().equals("VAR"))
          strCode += "\"" + nodeVal + "\"";
        if(parentName.equals("POLICY") || parentName.equals("NOT") ||
          (parentName.equals("VALUE") && !node.getParentNode().getParentNode().getNodeName().equals("VAR")) ||
          parentName.equals("COMP") )
          if(!nodeVal.equals(""))
            strCode += " " + nodeVal;
        if(parentName.equals("COMMENT"))
          strCode += " # " + nodeVal + "\n";
        if(parentName.equals("ADDR")) // blacklist
          strCode += "iptables -A INPUT -s " + nodeVal + "/32 -m limit --limit 1/second -j LOG --log-prefix \"BLACKLIST: \"\n" +
                                      "iptables -A INPUT -s " + nodeVal + "/32 -j DROP\n" +
                                      "iptables -A FORWARD -s " + nodeVal + "/32 -m limit --limit 1/second -j LOG --log-prefix \"BLACKLIST: \"\n" +
                                      "iptables -A FORWARD -s " + nodeVal + "/32 -j DROP\n";
        if(parentName.equals("STATUS"))
          if(nodeVal.equals("Alert"))
            comboBlacklist.addItem(node.getParentNode().getPreviousSibling().getFirstChild().getNodeValue());
        if(parentName.equals("TABLE"))
          strCode += genPara(nodeVal, "-t");
        if(parentName.equals("CHAIN_NAME"))
          strCode += genPara(nodeVal, "-A");
        if(parentName.equals("RATE"))
          strCode += genPara(nodeVal, "--limit");
        if(parentName.equals("BURST"))
          strCode += genPara(nodeVal, "--limit-burst");
        if(parentName.equals("SPORT"))
          strCode += genPara(nodeVal, "--sport");
        if(parentName.equals("DPORT"))
          strCode += genPara(nodeVal, "--dport");
        if(parentName.equals("PORT"))
          strCode += genPara(nodeVal, "--port");
        if(parentName.equals("STATE_LIST"))
          strCode += genPara(nodeVal, "--state");
        if(parentName.equals("UNCLEAN"))
          strCode += genPara(nodeVal, "-m");
        if(parentName.equals("TYPE"))
          strCode += genPara(nodeVal, "--tos");
        if(parentName.equals("MARK"))
          strCode += genPara(nodeVal, "--mark");
        if(parentName.equals("UID_OWNER"))
          strCode += genPara(nodeVal, "--uid-owner");
        if(parentName.equals("GID_OWNER"))
          strCode += genPara(nodeVal, "--gid-owner");
        if(parentName.equals("PID_OWNER"))
          strCode += genPara(nodeVal, "--pid-owner");
        if(parentName.equals("SID_OWNER"))
          strCode += genPara(nodeVal, "--sid-owner");
        if(parentName.equals("JUMP_TARGET"))
          strCode += genPara(nodeVal, "-j");
        if(parentName.equals("LOG_LEVEL"))
          strCode += genPara(nodeVal, "--log-level");
        if(parentName.equals("LOG_PREFIX"))
          strCode += genPara(nodeVal, "--log-prefix");
        if(parentName.equals("LOG_TCP_SEQ"))
          strCode += genPara(nodeVal, "--log-tcp-sequence");
        if(parentName.equals("LOG_TCP_OPT"))
          strCode += genPara(nodeVal, "--log-tcp-options");
        if(parentName.equals("LOG_IP_OPT"))
          strCode += genPara(nodeVal, "--log-ip-options");
        if(parentName.equals("SET_MARK"))
          strCode += genPara(nodeVal, "--set-mark");
        if(parentName.equals("REJECT_WITH"))
          strCode += genPara(nodeVal, "--reject-with");
        if(parentName.equals("SET_TOS"))
          strCode += genPara(nodeVal, "--set-tos");
        if(parentName.equals("TO"))
          strCode += genPara(nodeVal, "--to");
        if(parentName.equals("TO_SRC"))
          strCode += genPara(nodeVal, "--to-source");
        if(parentName.equals("TO_DES"))
          strCode += genPara(nodeVal, "--to-destination");
        if(parentName.equals("TO_PORT"))
          strCode += genPara(nodeVal, "--to-ports");
        if(parentName.equals("DISABLE_BROADCASTS") || parentName.equals("DISABLE_PINGS") ||
          parentName.equals("DISABLE_ICMP_REDIRECT") || parentName.equals("ENABLE_PROTECTION") ||
          parentName.equals("DISABLE_SPOOFING") || parentName.equals("ENABLE_SYN_COOKIES") ||
          parentName.equals("DISABLE_SROUTING") || parentName.equals("LOG_MARTIANS") || parentName.equals("DY_DROP"))
          strCode += nodeVal + "\n";
        break;
      default:
        System.out.println("compileXML_ - default");
        System.out.println(node.getNodeType());
    }
  }
  private Document getXMLdoc(String file)
  { try { DOMParser parser = new DOMParser();
          parser.setIncludeIgnorableWhitespace(false);
          parser.parse(xmlFile);
          Document document = parser.getDocument();
          return document;
    }
    catch(Exception e)  { e.printStackTrace(System.err);
                          return null;
    }
  }
  private String xmlNode(String name, String value)
  { if(value.equals(""))
      value = "null";
    String temp = "<" + name + ">" + value + "</" + name + ">\n";
    return temp;
  }
  private void connectToServer() throws IOException
  { System.out.println("send xml - attempting connection");
    client = new Socket(InetAddress.getByName(Password.JKserverAddr), 7123);
    System.out.println("send xml - connected to: " + client.getInetAddress().getHostName());
  }
  private void getStreams() throws IOException
  { output = new ObjectOutputStream(client.getOutputStream());
    output.flush();
    input = new ObjectInputStream(client.getInputStream());
    System.out.println("send xml - got i/o streams");
  }
  private PrivateKey getPrivateKey()
  { try { FileInputStream privFile = new FileInputStream(privFileName);
          byte[] bytePrivKey = new byte[privFile.available()];
          privFile.read(bytePrivKey);
          privFile.close();
          PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(bytePrivKey);
          KeyFactory keyFac = KeyFactory.getInstance("RSA", "BC");
          PrivateKey privKey = keyFac.generatePrivate(keySpec);
          return privKey;
    }
    catch(Exception e)  { System.out.println("getPrivateKey - get privKey from file error");
                          return null;
    }
  }
  private void processConnection_()
  { String xmlData = new String("");
    String EncryptedData = new String("");
    Security.addProvider(new  BouncyCastleProvider());
    try { byte[] byteEncryptedLine = new byte[1152];
          int len = input.read(byteEncryptedLine);
          String strDone = new String(byteEncryptedLine).substring(0, 11);
          while(!strDone.equals("$$$done$$$$"))
          { EncryptedData += new String(byteEncryptedLine) + "\n";
            PrivateKey privKey = getPrivateKey();
            Cipher decCipher = Cipher.getInstance("RSA", "BC");
            decCipher.init(Cipher.DECRYPT_MODE, privKey);
            System.out.println("decrypt");
            System.out.println(new String(byteEncryptedLine));
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int k = (((RSAPrivateKey)privKey).getModulus().bitLength() + 7) >>> 3;
            int inOff = 0;
            while(true) { int leftToDo = len - inOff;
                          if(leftToDo <= 0) { break;
                          }
                          int chunkSize = (leftToDo > k ? k: leftToDo);
                          decCipher.update(byteEncryptedLine, inOff, chunkSize);
                          baos.write(decCipher.doFinal());
                          inOff += chunkSize;
            }
            byte[] byteXmlLine = baos.toByteArray();
            baos.flush();
            String strXmlLine = new String(byteXmlLine);
            System.out.println(strXmlLine);
            xmlData += strXmlLine + "\n";
            len = input.read(byteEncryptedLine);
            strDone = new String(byteEncryptedLine).substring(0, 11);
          }
          FileWriter xmlF = new FileWriter(xmlFile);
          xmlF.write(xmlData);
          xmlF.close();
          FileWriter encF = new FileWriter(encryptedFile);
          encF.write(EncryptedData);
          encF.close();
    }
    catch(Exception ee) { System.out.println("processConnectin_ - get xml file from server error");
                          System.out.println(ee);
    }

    String sqlDelete = "DELETE FROM ";
    //db.SQLExecute(sqlDelete + "options");
    db.SQLExecute(sqlDelete + "definevar");
    db.SQLExecute(sqlDelete + "definechain");
    db.SQLExecute(sqlDelete + "blacklist");
    db.SQLExecute(sqlDelete + "confige");

    Node firewall_conf = getXMLdoc(xmlFile).getDocumentElement();
    Node op_node = firewall_conf.getFirstChild();
    Node var_node = op_node.getNextSibling();
    Node chain_node = var_node.getNextSibling();
    Node black_node = chain_node.getNextSibling();
    Node conf_chain_node = black_node.getNextSibling();

    strCode = "";
    compileXML_(op_node);
    //compileXML_(var_node);
    NodeList var_list = var_node.getChildNodes();
    if(var_list != null)
      for(int i = 0; i < var_list.getLength(); i++)
        compileXML_(var_list.item(i));
    //compileXML_(chain_node);
    NodeList chain_list = chain_node.getChildNodes();
    if(chain_list != null)
      for(int i = 0; i < chain_list.getLength(); i++)
        compileXML_(chain_list.item(i));
    //compileXML_(black_node);
    NodeList black_list = black_node.getChildNodes();
    if(black_list != null)
      for(int i = 0; i < black_list.getLength(); i++)
        compileXML_(black_list.item(i));
    //compileXML_(conf_chain_node);
    NodeList rule_list = conf_chain_node.getChildNodes();
    if(rule_list != null)
      for(int i = 0; i < rule_list.getLength(); i++)
      { compileXML_(rule_list.item(i));
        strCode += "\n";
      }
    System.out.println(strCode);
    try { StringReader sr = new StringReader(strCode);
          BufferedReader buff = new BufferedReader(sr);
          String codeLine = new String("");
          while((codeLine = buff.readLine()) != null)
          { codeLine = codeLine.trim();
            if(!codeLine.equals(""))
            { if(codeLine.startsWith("iptables"))
              { while(codeLine.endsWith("\\"))
                { codeLine = (codeLine.replace('\\', ' ')).trim() + " ";
                  String moreLine = buff.readLine();
                  codeLine = codeLine = moreLine;
                }
                System.out.println("#################################");
                System.out.println(codeLine);
                String tcLine = new String(codeLine);
                tcLine = tcLine.substring(new String("iptables").length());
                tcLine = tcLine.trim();
                resetDbPara();
                while(!tcLine.equals(""))
                { String sep = sepCode(tcLine);
                  tcLine = tcLine.substring(sep.length()).trim();
                  interp(sep);
                }
                systemOutDbPara();
                loadToDB();
              }
            }
          }
    }
    catch(Exception ex)  {  System.out.println("processConnection_ - load to db error");
                            System.out.println(ex);
    }
  }
  private void systemOutDbPara()
  { if(!table.equals(""))
      System.out.println("table: " + table);
    if(!cmd.equals(""))
      System.out.println("cmd: " + cmd);
    if(!chain.equals(""))
      System.out.println("chain: " + chain);
    if(!rulenum.equals(""))
      System.out.println("rulenum: " + rulenum);
    if(!target.equals(""))
      System.out.println("target: " + target);
    if(!new_chain_name.equals(""))
      System.out.println("new_chain_name: " + new_chain_name);
    if(!protocol_.equals(""))
      System.out.println("protocol_: " + protocol_);
    if(!protocol.equals(""))
      System.out.println("protocol: " + protocol);
    if(!saddr_.equals(""))
      System.out.println("saddr_: " + saddr_);
    if(!saddr.equals(""))
      System.out.println("saddr: " + saddr);
    if(!daddr_.equals(""))
      System.out.println("daddr_: " + daddr_);
    if(!daddr.equals(""))
      System.out.println("daddr: " + daddr);
    if(!jump.equals(""))
      System.out.println("jump: " + jump);
    if(!inif_.equals(""))
      System.out.println("inif_: " + inif_);
    if(!inif.equals(""))
      System.out.println("inif: " + inif);
    if(!outif_.equals(""))
      System.out.println("outif_: " + outif_);
    if(!outif.equals(""))
      System.out.println("outif: " + outif);
    if(!frag.equals(""))
      System.out.println("frag: " + frag);
    if(!syn.equals(""))
      System.out.println("syn: " + syn);
    if(!frag_.equals(""))
      System.out.println("frag_: " + frag_);
    if(!syn_.equals(""))
      System.out.println("syn_: " + syn_);
    if(!sport_.equals(""))
      System.out.println("sport_: " + sport_);
    if(!sport.equals(""))
      System.out.println("sport: " + sport);
    if(!dport_.equals(""))
      System.out.println("dport_: " + dport_);
    if(!dport.equals(""))
      System.out.println("dport: " + dport);
    if(!flagmark_.equals(""))
      System.out.println("flagmark_: " + flagmark_);
    if(!flagmark.equals(""))
      System.out.println("flagmark: " + flagmark);
    if(!flagcomp.equals(""))
      System.out.println("flagcomp: " + flagcomp);
    if(!tcp_op_.equals(""))
      System.out.println("tcp_op_: " + tcp_op_);
    if(!tcp_op.equals(""))
      System.out.println("tcp_op: " + tcp_op);
    if(!icmptype_.equals(""))
      System.out.println("icmptype_: " + icmptype_);
    if(!icmptype.equals(""))
      System.out.println("icmptype: " + icmptype);
    if(!match.equals(""))
      System.out.println("match: " + match);
    if(!msource.equals(""))
      System.out.println("msource: " + msource);
    if(!limit.equals(""))
      System.out.println("limit: " + limit);
    if(!limitrate.equals(""))
      System.out.println("limitrate: " + limitrate);
    if(!limitB.equals(""))
      System.out.println("limitB: " + limitB);
    if(!limitBnum.equals(""))
      System.out.println("limitBnum: " + limitBnum);
    if(!sdport.equals(""))
      System.out.println("sdport: " + sdport);
    if(!markvalue.equals(""))
      System.out.println("markvalue: " + markvalue);
    if(!userid.equals(""))
      System.out.println("userid: " + userid);
    if(!groupid.equals(""))
      System.out.println("groupid: " + groupid);
    if(!processid.equals(""))
      System.out.println("processid: " + processid);
    if(!sessionid.equals(""))
      System.out.println("sessionid: " + sessionid);
    if(!state.equals(""))
      System.out.println("state: " + state);
    if(!tos.equals(""))
      System.out.println("tos: " + tos);
    if(!level.equals(""))
      System.out.println("level: " + level);
        if(!prefix.equals(""))
      System.out.println("prefix: " + prefix);
    if(!logseq.equals(""))
      System.out.println("logseq: " + logseq);
    if(!logop.equals(""))
      System.out.println("logop: " + logop);
    if(!logipop.equals(""))
      System.out.println("logipop: " + logipop);
    if(!setmark.equals(""))
      System.out.println("setmark: " + setmark);
    if(!rejecttype.equals(""))
      System.out.println("rejecttype: " + rejecttype);
    if(!settos.equals(""))
      System.out.println("settos: " + settos);
    if(!to.equals(""))
      System.out.println("to: " + to);
    if(!tosource.equals(""))
      System.out.println("tosource: " + tosource);
    if(!todes.equals(""))
      System.out.println("todes: " + todes);
    if(!toport.equals(""))
      System.out.println("toport: " + toport);
    if(!mul_sport.equals(""))
      System.out.println("mul_sport: " + mul_sport);
    if(!mul_dport.equals(""))
      System.out.println("mul_dport: " + mul_dport);
  }
  public void loadToDB()
  { String field = "tablename,Chain,Action,notprotocal,protocal,notsrcip,src_ip,notdesip,des_ip,jump,"+
                    "notsrcdevice,src_device,notdesdevice,des_device,frag,syn,notfrag,notsyn,notsrcport,src_port,notdesport,des_port,notflagmark,flagmark,flagcomp,"+
                    "sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop,"+
                    "nottcp_op,tcp_op,noticmptype,icmptype,matchs,notmsource,msource,limits,limitrate,limitB,limitBnum,"+
                    "setmark,rejecttype,settos,natto,tosource,todes,toport, mul_sport, mul_dport";
    String  value = "'" + table + "', '" + chain + "', '" + target + "', '" + protocol_ + "', '" + protocol + "', '" + saddr_ + "', '" + saddr + "', '" + daddr_ + "', '" + daddr + "', '" + jump + "', '" +
                    inif_ + "', '" + inif + "', '" + outif_ + "', '" + outif + "', '" + frag + "', '" + syn + "', '" + frag_ + "', '" + syn_ + "', '" + sport_ + "', '" + sport + "', '" + dport_ + "', '" + dport + "', '" + flagmark_ + "', '" + flagmark + "', '" + flagcomp + "', '" +
                    sdport + "', '" + markvalue + "', '" + userid + "', '" + groupid + "', '" + processid + "', '" + sessionid + "', '" + state + "', '" + tos + "', '" + level + "', '" + prefix + "', '" + logseq + "', '" + logop + "', '" + logipop + "', '" +
                    tcp_op_ + "', '" + tcp_op + "', '" + icmptype_ + "', '" + icmptype + "', '" + match + "', '" + msource_ + "', '" + msource + "', '" + limit + "', '" + limitrate + "', '" + limitB + "', '" + limitBnum + "', '" +
                    setmark + "', '" + rejecttype + "', '" + settos + "', '" + to + "', '" + tosource + "', '" + todes + "', '" + toport + "', '" + mul_sport + "', '" +mul_dport + "'";
    String sqlInsertRule = "INSERT INTO confige (" + field + ") VALUES (" + value + ")";
    System.out.println(sqlInsertRule);
    db.SQLExecute(sqlInsertRule);
    try { db.con.commit();
    }
    catch(SQLException e) { System.out.println(e.getMessage());
    }
  }
  private void interp(String s)
  { s = s + " ";  // for string has not " "
    String para = s.substring(0, s.indexOf(" "));
    String value = s.substring(s.indexOf(" ")).trim();

    // t
    if(para.equals("-t"))
      table = value;
    // ANXLFZ
    if(para.equals("-A") || para.equals("--append") ||
      para.equals("-C") || para.equals("--check") ||
      para.equals("-N") || para.equals("--new-chain") ||
      para.equals("-X") || para.equals("--delete-chain") ||
      para.equals("-L") || para.equals("--list") || // LFZ >>> chain maybe is a ""
      para.equals("-F") || para.equals("--flush") ||
      para.equals("-Z") || para.equals("--zero"))
    { cmd = para;
      chain = value;
    }
    // commands
    // DRI
    if(para.equals("-D") || para.equals("--delete") ||
      para.equals("-R") || para.equals("--replace") ||
      para.equals("-I") || para.equals("--insert"))
    { cmd = para;
      value = value + " ";
      chain = value.substring(0, value.indexOf(" "));
      rulenum = value.substring(value.indexOf(" ")).trim();
    }
    // P
    if(para.equals("-P") || para.equals("--policy"))
    { cmd = para;
      value = value + " ";
      chain = value.substring(0, value.indexOf(" "));
      target = value.substring(value.indexOf(" ")).trim();
    }
    // E
    if(para.equals("-E") || para.equals("--rename-chain"))
    { cmd = para;
      value = value + " ";
      chain = value.substring(0, value.indexOf(" "));
      new_chain_name = value.substring(value.indexOf(" ")).trim();
    }
    if(para.equals("-h") || para.equals("--help"))
      cmd = para;
    // parameters make up rule specifications
    // p
    if(para.equals("-p") || para.equals("--proto"))
    { if(value.startsWith("!"))
      { protocol_ = "!";
        value = value.replace('!', ' ');
      }
      protocol = value.trim();
    }
    // s
    if(para.equals("-s") || para.equals("--source") || para.equals("--src"))
    { if(value.startsWith("!"))
      { saddr_ = "!";
        value = value.replace('!', ' ');
      }
      saddr = value.trim();
    }
    // d
    if(para.equals("-d") || para.equals("--destination") || para.equals("--dst"))
    { if(value.startsWith("!"))
      { daddr_ = "!";
        value = value.replace('!', ' ');
      }
      daddr = value.trim();
    }
    // j
    if(para.equals("-j") || para.equals("--jump"))
    { jump = para;
      target = value;
    }
    // i
    if(para.equals("-i") || para.equals("--in-interface"))
    { if(value.startsWith("!"))
      { inif_ = "!";
        value = value.replace('!', ' ');
      }
      inif = value.trim();
    }
    // o
    if(para.equals("-o") || para.equals("--out-interface"))
    { if(value.startsWith("!"))
      { outif_ = "!";
        value = value.replace('!', ' ');
      }
      outif = value.trim();
    }
    // f
    if(para.equals("-f") || para.endsWith("--fragment"))
      frag = para;
    // syn
    if(para.equals("--syn"))
      syn = para;
    // start by "!"
    if(para.startsWith("!"))
    { para = para.replace('!', ' ');
      para = para.replace('*', ' ');
      para = para.trim();
      if(para.equals("-f") || para.equals("--fragment"))
      { frag_ = "!";
        frag = para;
      }
      if(para.equals("--syn"))
      { syn_ = "!";
        syn = para;
      }
    }
    // sport
    if(para.equals("--sport") || para.equals("--source-port"))
    { if(value.startsWith("!"))
      { sport_ = "!";
        value = value.replace('!', ' ');
      }
      if(multiport)
      { mul_sport = value.trim();
        multiport = false;
      }
      else  sport = value.trim();
    }
    // dport
    if(para.equals("--dport") || para.equals("--destination-port"))
    { if(value.startsWith("!"))
      { dport_ = "!";
        value = value.replace('!', ' ');
      }
      if(multiport)
      { mul_dport = value.trim();
        multiport = false;
      }
      else  dport = value.trim();
    }
    // tcp-flags
    if(para.equals("--tcp-flags"))
    { if(value.startsWith("!"))
      { flagmark_ = "!";
        value = value.replace('!', ' ');
        value = value.trim();
      }
      flagmark = value.substring(0, value.indexOf(" "));
      flagcomp = value.substring(value.indexOf(" ")).trim();
    }
    // tcp-option
    if(para.equals("--tcp-option"))
    { if(value.startsWith("!"))
      { tcp_op_ = "!";
        value = value.replace('!', ' ');
      }
      tcp_op = value.trim();
    }
    // icmp-type
    if(para.equals("--icmp-type"))
    { if(value.startsWith("!"))
      { icmptype_ = "!";
        value = value.replace('!', ' ');
      }
      icmptype = value.trim();
    }
    // m
    if(para.equals("-m") || para.equals("--match"))
    { match = match + " " + value;
      match = match.trim();
      if(value.trim().equals("multiport"))
        multiport = true;
    }
    // mac-source
    if(para.equals("--mac-source"))
    { if(value.startsWith("!"))
      { msource_ = "!";
        value = value.replace('!', ' ');
      }
      msource = value.trim();
    }
    // limit
    if(para.equals("--limit"))
    { limit = para;
      limitrate = value;
    }
    // limit-burst
    if(para.equals("--limit-burst"))
    { limitB = para;
      limitBnum = value;
    }
    // port
    if(para.equals("--port"))
      sdport = value;
    // mark
    if(para.equals("--mark"))
      markvalue = value;
    // ower
    if(para.equals("--uid-owner"))
      userid = value;
    if(para.equals("--gid-owner"))
      groupid = value;
    if(para.equals("--pid-owner"))
      processid = value;
    if(para.equals("--sid-owner"))
      sessionid = value;
    // state
    if(para.equals("--state"))
      state = value;
    // tos
    if(para.equals("--tos"))
      tos = value;
    // log-level
    if(para.equals("--log-level"))
      level = value;
    // log-prefix
    if(para.equals("--log-prefix"))
      prefix = value;
    // log-tcp-sequence
    if(para.equals("--log-tcp-sequence"))
      logseq = para;
    // log-tcp-options
    if(para.equals("--log-tcp-options"))
      logop = para;
    // log-ip-options
    if(para.equals("--log-ip-options"))
      logipop = para;
    // set-mark
    if(para.equals("--set-mark"))
      setmark = value;
    // reject-with
    if(para.equals("--reject-with"))
      rejecttype = value;
    // set-tos
    if(para.equals("--set-tos"))
      settos = value;
    // to
    if(para.equals("--to"))
      to = value;
    // to-source
    if(para.equals("--to-source"))
      tosource = value;
    // to-destination
    if(para.equals("--to-destination"))
      todes = value;
    // to-port
    if(para.equals("--to-ports"))
      toport = value;
  }
  private String sepCode(String code)
  { String sep = new String("");
    while((code.length() != 0) && (!code.regionMatches(0, " -", 0, 2)) && (!code.regionMatches(0, " ! -", 0, 4)))
    { sep = sep + code.charAt(0);
      code = code.substring(1);
      if(sep.equals("!"))
      { code = code.substring(1);
        code = "*" + code;
      }
    }
    return sep;
  }
  private void resetDbPara()
  { table = cmd = chain = rulenum = target = new_chain_name = protocol_ = protocol = saddr_ = saddr = daddr_ = daddr = jump = "";
    inif_ = inif = outif_ = outif = frag = syn = frag_ = syn_ = sport_ = sport = dport_ = dport = flagmark_ = flagmark = flagcomp = "";
    tcp_op_ = tcp_op = icmptype_ = icmptype = match = msource_ = msource = limit = limitrate = limitB = limitBnum = "";
    sdport = markvalue = userid = groupid = processid = sessionid = state = tos = level = prefix = logseq = logop = logipop = "";
    setmark = rejecttype = settos = to = tosource = todes = toport = mul_sport = mul_dport = "";
    multiport = false;
  }
  private void processConnection()
  { try { BufferedReader buff = new BufferedReader(new StringReader(displayRule));
          String strXmlLine = new String("");
          while((strXmlLine = buff.readLine()) != null)
          { byte[] byteXmlLine = strXmlLine.getBytes();
            Security.addProvider(new BouncyCastleProvider());
            PublicKey pubKey = Password.getPublicKey();
            // create cipher which used to encrypt
            Cipher encCipher = Cipher.getInstance("RSA", "BC");
            encCipher.init(Cipher.ENCRYPT_MODE, pubKey);
            // encrypt
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int k = (((RSAPublicKey)pubKey).getModulus().bitLength() + 7) >>> 3;
            int maxSize = k - 11;
            int inOff = 0;
            while(true) { int leftToDo = byteXmlLine.length - inOff;
                                  if(leftToDo <= 0) { break;
                                  }
                                  int chunkSize = (leftToDo > maxSize ? maxSize: leftToDo);
                                  encCipher.update(byteXmlLine, inOff, chunkSize);
                                  baos.write(encCipher.doFinal());
                                  inOff += chunkSize;
            }
            byte[] byteEncryptedLine = baos.toByteArray();
            baos.flush();
            // send to server
            output.write(byteEncryptedLine);
            output.flush();
          }
          // send string to server for tell "it's done"
          String strDone = new String("$$$done$$$$");
          output.write(strDone.getBytes());
          output.flush();
    }
    catch(Exception e)  { System.out.println("send xml - processConnection");
    }
  }
  private void closeConnection()
  { System.out.println("send xml - closing connection");
    try { output.close();
          input.close();
          client.close();
    }
    catch(Exception e)  { System.out.println("send xml - close connection error");
    }
  }
  private void receiveFileFromServer()
  { try { connectToServer();
          getStreams();
          RemoteControl.sendService(strReceiveXML, output);
          processConnection_();
          closeConnection();
    }
    catch(Exception e)
    { System.out.println("server terminated connection");
    }
  }
  private void sendFileToServer()
  { try { connectToServer();
          getStreams();
          RemoteControl.sendService(strSendXML, output);
          processConnection();
          closeConnection();
    }
    catch(EOFException eofException)
    { System.out.println("server terminated connection");
    }
    catch(IOException ioException)
    { System.out.println("error - can't connect");
      ioException.printStackTrace();
    }
  }
  private void jbInit() throws Exception {

   this.getContentPane().setBackground(new Color(236, 233, 230));
    this.setSize(new Dimension(411, 231));

   Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);


    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel1.setLayout(xYLayout1);
    jPanel2.setLayout(xYLayout2);
    activateButton.setBackground(new Color(236, 233, 230));
    activateButton.setBorder(BorderFactory.createEtchedBorder());
    activateButton.setHorizontalTextPosition(SwingConstants.LEFT);
    activateButton.setText("Upload to Server");
    activateButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        activateButton_actionPerformed(e);
      }
    });
    deactivateButton.setBackground(new Color(236, 233, 230));
    deactivateButton.setBorder(BorderFactory.createEtchedBorder());
    deactivateButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deactivateButton.setText("Load from Server");
    deactivateButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deactivateButton_actionPerformed(e);
      }
    });

    jPanel2.setBackground(new Color(236, 233, 230));
    comboBlacklist.setEnabled(false);
    comboBlacklist.setVisible(false);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel2.add(deactivateButton,  new XYConstraints(158, 8, 147, 73));
    jPanel2.add(activateButton, new XYConstraints(16, 8, 141, 72));
    jPanel1.add(comboBlacklist, new XYConstraints(136, 224, 163, 20));
    jPanel1.add(jPanel2,                           new XYConstraints(43, 65, 324, 93));

    ImageIcon icon = new ImageIcon(("images/Workstation.gif"));
    this.setIconImage(icon.getImage());
    this.setTitle("Select Upload or Load ... ");

        // Database section
        db = new DBUtil();
        con = db.Establish();
    this.setVisible(true);
  }

  class clickedConnect implements ActionListener  {
    public void actionPerformed(ActionEvent e) {
    }
  }
 void ConverttoXML() {
        displayRule = "";
        value=0;
        new ProgressDialog();
        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,notprotocal,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice="",notDesIP,notDesPort,notDesDevice,sRuleNo="";
        int RuleNo;
        ResultSet tmprs;
        String Service="",en_dis="";

  String tablename,frag,syn, notfrag, notsyn,  notflagmark, flagmark, flagcomp = new String("");
  String nottcp_op, tcp_op, noticmptype, icmptype, match, notmsource, msource, limit, limitrate, limitB, limitBnum = new String("");
  String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
  String setmark, rejecttype, settos, to, tosource, todes, toport, mul_sport, mul_dport = new String("");

    /////////// Options /////////////
           String sqlSelectOptions = new String("");
           String opDisBroadcasts, opDisPings, opDisIcmpRedirect, opEnProtection, opDisSpoofing, opEnSynCookies, opDisSRouting, opLogMartians, opDyDrop;
           String inputd,outputd,forwardd;
    // ===============================

    /////////// nat /////////////
           String SQLNat,IdNat,src_IPnat,src_Portnat,out_Device,snat_Protocal,snat_toIP,snat_toPort;
           String des_IPnat,des_Portnat, in_Device,dnat_Protocal,dnat_toIP,dnat_toPort;
           String en_disnat="";
    // ===============================

    /////////// defineVar /////////////
          String SQLDefineVar,IdDefineVar,Name,Value,Type,Comment;
    // ===============================

    /////// chain' s detail ///////
      String SQLchain, chain_id, chain_name, chain_policy, chain_comment;

    /////////// BlackList /////////////
          String SQLblacklist, bl_id, bl_addr, bl_status;
    // ===============================

           displayRule += "<FIREWALL_CONFIG>\n";
            int no;

           //SQLConfige="SELECT * FROM confige order by ID";
           SQL="SELECT * FROM confige order by ID";
           sqlSelectOptions = "SELECT * FROM options order by ID";
           SQLNat = "SELECT * FROM nat order by ID";
           SQLDefineVar = "SELECT * FROM definevar order by ID";
           SQLblacklist = "SELECT * FROM blacklist order by ID";
           SQLchain = "SELECT * FROM definechain order by ID";

              try {
                      FileWriter fout = new FileWriter(xmlFile);

                      rsOptions = db.SQLRetrive(sqlSelectOptions);
                      displayRule += "<OPTIONS>\n";
                      rsOptions.first();
                      opDisBroadcasts = rsOptions.getString("drespbroad");
                      if(opDisBroadcasts == null)
                        opDisBroadcasts = "/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts";
                      opDisPings = rsOptions.getString("drespping");
                      if(opDisPings == null)
                        opDisPings = "/bin/echo \"0\" > /proc/sys/net/ipv4/icmp_ignore_all";
                      opDisIcmpRedirect = rsOptions.getString("drespicmpredi");
                      if(opDisIcmpRedirect == null)
                        opDisIcmpRedirect = "/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_redirects";
                      opEnProtection = rsOptions.getString("enbaderror");
                      if(opEnProtection == null)
                        opEnProtection = "/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses";
                      opDisSpoofing = rsOptions.getString("dipspoof");
                      if(opDisSpoofing == null)
                        opDisSpoofing = "/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/rp_filter";
                      opEnSynCookies = rsOptions.getString("entcpsyn");
                      if(opEnSynCookies == null)
                        opEnSynCookies = "/bin/echo \"1\" > /proc/sys/net/ipv4/tcp_syncookies";
                      opDisSRouting = rsOptions.getString("dsrcrouting");
                      if(opDisSRouting == null)
                        opDisSRouting = "/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_source_route";
                      opLogMartians = rsOptions.getString("logmar");
                      if(opLogMartians == null)
                        opLogMartians = "/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/log_martians";
                      opDyDrop = rsOptions.getString("dydrop");
                      if(opDyDrop == null)
                        opDyDrop = "iptables -A INPUT -m unclean -m limit --limit 1/second -j LOG --log-prefix \"DY-DROP: \"\niptables -A INPUT -m unclean -j DROP\n" +
                                    "iptables -A FORWARD -m unclean -m limit --limit 1/second -j LOG --log-prefix \"DY-DROP: \"\niptables -A FORWARD -m unclean -j DROP";
                      displayRule += xmlNode("DISABLE_BROADCASTS", opDisBroadcasts) +
                                        xmlNode("DISABLE_PINGS", opDisPings) +
                                        xmlNode("DISABLE_ICMP_REDIRECT", opDisIcmpRedirect) +
                                        xmlNode("ENABLE_PROTECTION", opEnProtection) +
                                        xmlNode("DISABLE_SPOOFING", opDisSpoofing) +
                                        xmlNode("ENABLE_SYN_COOKIES", opEnSynCookies) +
                                        xmlNode("DISABLE_SROUTING", opDisSRouting) +
                                        xmlNode("LOG_MARTIANS", opLogMartians) +
                                        xmlNode("DY_DROP", opDyDrop);
                      displayRule += "</OPTIONS>\n";

                      rsDefineVar = db.SQLRetrive(SQLDefineVar);
                      displayRule += "<VAR_LIST>\n";
                      if(rsDefineVar.first()) {

                      while (rsDefineVar.next()) {
                          rsDefineVar.previous();
                          Name = rsDefineVar.getString("Name");
                          //Name = Name.substring(1,Name.length());
                          Value = rsDefineVar.getString("Value");
                          Type = rsDefineVar.getString("Type");
                          Comment = rsDefineVar.getString("Comment");

                      displayRule += "<VAR name=\"" + Name + "\">\n" +
                                                    xmlNode("VALUE", Value) +
                                                    xmlNode("COMMENT", Comment) +
                                                  "</VAR>\n";

                          rsDefineVar.next();
                      }
                     }
                       if(rsDefineVar.last()) {
                          Name = rsDefineVar.getString("Name");
                          //Name = Name.substring(1,Name.length());
                          Value = rsDefineVar.getString("Value");
                          Type = rsDefineVar.getString("Type");
                          Comment = rsDefineVar.getString("Comment");

                      displayRule += "<VAR name=\"" + Name + "\">\n" +
                                                    xmlNode("VALUE", Value) +
                                                    xmlNode("COMMENT", Comment) +
                                                  "</VAR>\n";
                        }
                        displayRule = displayRule + "</VAR_LIST>\n";

                      rsChain = db.SQLRetrive(SQLchain);
                      displayRule += "<CHAIN_LIST>\n";
                      if(rsChain.first())
                      { while(rsChain.next())
                        { rsChain.previous();
                          chain_id = rsChain.getString("ID");
                          chain_name = rsChain.getString("Name");
                          chain_comment = rsChain.getString("Comment");
                          chain_policy = rsChain.getString("policy");

                          displayRule += "<CHAIN name=\"" + chain_name + "\">\n" +
                                                        xmlNode("POLICY", chain_policy) +
                                                        xmlNode("COMMENT", chain_comment) +
                                                      "</CHAIN>\n";
                          rsChain.next();
                        }
                      }
                      if(rsChain.last())
                      { chain_id = rsChain.getString("ID");
                        chain_name = rsChain.getString("Name");
                        chain_comment = rsChain.getString("Comment");
                        chain_policy = rsChain.getString("policy");

                        displayRule += "<CHAIN name=\"" + chain_name + "\">\n" +
                                                      xmlNode("POLICY", chain_policy) +
                                                      xmlNode("COMMENT", chain_comment) +
                                                    "</CHAIN>\n";
                      }
                      displayRule += "</CHAIN_LIST>\n";

                      rsBlacklist = db.SQLRetrive(SQLblacklist);
                      displayRule += "<BLACK_LIST>\n";

                      if(rsBlacklist.first())
                      { while(rsBlacklist.next())
                        { rsBlacklist.previous();
                          bl_id = rsBlacklist.getString("ID");
                          bl_addr = rsBlacklist.getString("HostAddr");
                          bl_status = rsBlacklist.getString("Status");

                          displayRule += "<BL number=\"" + bl_id + "\">\n" +
                                                        xmlNode("ADDR", bl_addr) +
                                                        xmlNode("STATUS", bl_status) +
                                                      "</BL>\n";
                          rsBlacklist.next();
                        }
                      }
                      if(rsBlacklist.last())
                      { bl_id = rsBlacklist.getString("ID");
                        bl_addr = rsBlacklist.getString("HostAddr");
                        bl_status = rsBlacklist.getString("Status");

                        displayRule += "<BL number=\"" + bl_id + "\">\n" +
                                                      xmlNode("ADDR", bl_addr) +
                                                      xmlNode("STATUS", bl_status) +
                                                    "</BL>\n";
                      }
                      displayRule += "</BLACK_LIST>\n";

  // *********************************************************************************************//
  // *********************************************************************************************//

                      //rs = db.SQLRetrive(SQLConfige);
                      //rs = db.SQLRetrive(SQL);
                      rs = db.SQLRetrive(SQL);
                      NoLastRow = rs.getRow();
                      displayRule = displayRule + "<CONFIG_CHAIN>\n";
                 if(rs.first()) {
                     while (rs.next())
                          {
                        rs.previous();

                        Id = rs.getString("ID");

                        tablename = rs.getString("tablename");
                        if (tablename == null)
                          tablename = "";

                        Chain = rs.getString("Chain");
                        if(Chain == null)
                          Chain = "";

                        notprotocal = rs.getString("notprotocal");
                        if(notprotocal == null)
                          notprotocal = "";
                        if(notprotocal.equals("YES"))
                          notprotocal = "";
                        if(notprotocal.equals("NO"))
                          notprotocal = "!";

                        Protocal = rs.getString("Protocal");
                        if(Protocal == null)
                          Protocal ="";
                        if(Protocal.equals("TCP"))
                            Protocal = "tcp";
                        if(Protocal.equals("UDP"))
                            Protocal = "udp";
                        if(Protocal.equals("ICMP"))
                            Protocal = "icmp";

                        notSrcIP = rs.getString("notSrcIP");
                        if(notSrcIP == null)
                          notSrcIP = "";
                        if(notSrcIP.equals("YES"))
                          notSrcIP = "";
                        if(notSrcIP.equals("NO"))
                          notSrcIP = "!";

                        src_IP = rs.getString("src_IP");
                        if (src_IP == null)
                            src_IP = "";
                        if (src_IP.equals("ANY"))
                            src_IP = "";

                        notSrcPort = rs.getString("notSrcPort");
                        if(notSrcPort == null)
                          notSrcPort = "";
                        if(notSrcPort.equals("YES"))
                          notSrcPort = "";
                        if(notSrcPort.equals("NO"))
                          notSrcPort = "!";

                        src_Port = rs.getString("src_Port");
                        if (src_Port == null)
                            src_Port = "";
                        if(src_Port.equals("ANY"))
                            src_Port = "";

                        notSrcDevice = rs.getString("notSrcDevice");
                        if(notSrcDevice == null)
                            notSrcDevice = "";
                        if(notSrcDevice.equals("YES"))
                          notSrcDevice = "";
                        if(notSrcDevice.equals("NO"))
                          notSrcDevice = "!";

                        src_Device = rs.getString("src_Device");

                        if (src_Device == null)
                            src_Device = "";
                        if(src_Device.equals("ANY"))
                            src_Device = "";

                        notDesIP = rs.getString("notDesIP");
                        if(notDesIP == null)
                            notDesIP = "";
                        if(notDesIP.equals("YES"))
                          notDesIP = "";
                        if(notDesIP.equals("NO"))
                          notDesIP = "!";

                        des_IP = rs.getString("des_IP");

                        if (des_IP == null)
                            des_IP = "";
                        if(des_IP.equals("ANY"))
                            des_IP = "";
                        notDesPort = rs.getString("notDesPort");
                        if(notDesPort == null)
                            notDesPort = "";
                        if(notDesPort.equals("YES"))
                          notDesPort = "";
                        if(notDesPort.equals("NO"))
                          notDesPort = "!";

                        des_Port = rs.getString("des_Port");

                        if (des_Port == null)
                            des_Port = "";
                        if (des_Port.equals("ANY"))
                            des_Port = "";

                        notDesDevice = rs.getString("notDesDevice");
                        if (notDesDevice == null)
                            notDesDevice = "";
                        if(notDesDevice.equals("YES"))
                          notDesDevice = "";
                        if(notDesDevice.equals("NO"))
                          notDesDevice = "!";

                        des_Device = rs.getString("des_Device");

                        if (des_Device == null)
                            des_Device = "";
                        if (des_Device.equals("ANY"))
                            des_Device = "";
                        Action = rs.getString("Action");
                        if(Action == null)
                            Action = "";
                        frag = rs.getString("frag");
                          if(frag == null)
                            frag = "";
                        syn = rs.getString("syn");
                          if(syn == null)
                            syn = "";
                        notfrag = rs.getString("notfrag");
                           if(notfrag == null)
                            notfrag = "";
                        notsyn = rs.getString("notsyn");
                           if(notsyn == null)
                            notsyn = "";
                        notflagmark = rs.getString("notflagmark");
                           if(notflagmark == null)
                            notflagmark = "";
                        flagmark = rs.getString("flagmark");
                           if (flagmark == null)
                             flagmark = "";
                        flagcomp = rs.getString("flagcomp");
                           if (flagcomp == null)
                             flagcomp = "";
                        nottcp_op = rs.getString("nottcp_op");
                           if (nottcp_op == null)
                             nottcp_op = "";
                        tcp_op = rs.getString("tcp_op");
                           if (tcp_op == null)
                              tcp_op = "";
                        noticmptype = rs.getString("noticmptype");
                           if (noticmptype == null)
                              noticmptype = "";
                        icmptype = rs.getString("icmptype");
                           if (icmptype == null)
                              icmptype = "";
                        match = rs.getString("matchs");
                           if (match == null)
                              match = "";
                       sdport = rs.getString("sdport");
                           if(sdport == null)
                              sdport = "";
                       markvalue = rs.getString("markvalue");
                            if(markvalue == null)
                              markvalue = "";
                       userid = rs.getString("userid");
                            if(userid == null)
                              userid = "";
                       groupid = rs.getString("groupid");
                            if(groupid == null)
                              groupid = "";
                       processid = rs.getString("processid");
                            if(processid == null)
                              processid = "";
                       sessionid = rs.getString("sessionid");
                            if(sessionid == null)
                              sessionid = "";
                       state = rs.getString("state");
                            if(state == null)
                              state = "";
                       tos = rs.getString("tos");
                            if(tos == null)
                              tos = "";
                       level = rs.getString("level");
                            if(level == null)
                              level = "";
                       prefix = rs.getString("prefix");
                            if(prefix == null)
                              prefix = "";
                       logseq = rs.getString("logseq");
                            if(logseq == null)
                              logseq = "";
                       logop = rs.getString("logop");
                            if (logop == null)
                              logop = "";
                       logipop = rs.getString("logipop");
                            if (logipop == null)
                              logipop = "";
                       notmsource = rs.getString("notmsource");
                            if(notmsource == null)
                              notmsource = "";
                       msource = rs.getString("msource");
                            if(msource == null)
                              msource = "";
                       limit = rs.getString("limits");
                            if(limit == null)
                              limit = "";
                       limitrate = rs.getString("limitrate");
                            if(limitrate == null)
                              limitrate = "";
                       limitB = rs.getString("limitB");
                            if(limitB == null)
                              limitB = "";
                       limitBnum = rs.getString("limitBnum");
                            if(limitBnum == null)
                              limitBnum = "";
                       setmark = rs.getString("setmark");
                            if(setmark == null)
                              setmark = "";
                       rejecttype = rs.getString("rejecttype");
                            if(rejecttype == null)
                              rejecttype = "";
                       settos = rs.getString("settos");
                            if(settos == null)
                               settos = "";
                       to = rs.getString("natto");
                            if(to == null)
                              to = "";
                       tosource = rs.getString("tosource");
                            if(tosource == null)
                              tosource = "";
                            if(tosource.equals("ANY"))
                              tosource = "";
                       todes = rs.getString("todes");
                            if(todes == null)
                              todes = "";
                            if(todes.equals("ANY"))
                              todes = "";

                       toport = rs.getString("toport");
                            if(toport == null)
                              toport = "";
                            if(toport.equals("ANY"))
                              toport = "";
                       mul_sport = rs.getString("mul_sport");
                            if(mul_sport == null)
                              mul_sport = "";
                       mul_dport = rs.getString("mul_dport");
                            if(mul_dport == null)
                              mul_dport = "";

                       // analyze match here
                       getMatch(match);

                       // gen XML code
              if(!Chain.equals("") && !Action.equals(""))   {

                      displayRule += "<RULE n=\"" +Id + "\">\n";
                      if(!tablename.equals(""))
                        displayRule +=   xmlNode("TABLE", tablename);
                      ///////////////// edit By Keng ///////////////////
                      if(!Chain.equals(""))
                        displayRule +=     xmlNode("CHAIN_NAME", Chain);
                      //////////////////////////////////////////////////
                      if(!Protocal.equals(""))  {
                        displayRule +=   "<PROTOCOL>\n" +
                                                        xmlNode("NOT", notprotocal) +
                                                        xmlNode("VALUE", Protocal);
                        if(!src_Port.equals(""))  {
                          displayRule +=  "<SRC_PORT>\n" +
                                                        xmlNode("NOT", notSrcPort) +
                                                        xmlNode("VALUE", src_Port) +
                                                        "</SRC_PORT>\n";  }
                        if(!des_Port.equals(""))  {
                          displayRule +=  "<DES_PORT>\n" +
                                                          xmlNode("NOT", notDesPort) +
                                                          xmlNode("VALUE", des_Port) +
                                                        "</DES_PORT>\n";  }
                       if(!flagmark.equals("") || !flagcomp.equals(""))  {
                        displayRule +=     "<TCP_FLAG>\n" +
                                                          "<MASK>\n" +
                                                            xmlNode("NOT", notflagmark) +
                                                            xmlNode("VALUE", flagmark) +
                                                          "</MASK>\n" +
                                                            xmlNode("COMP", flagcomp) +
                                                        "</TCP_FLAG>\n";  }
                      if(!syn.equals("")) {
                        displayRule +=      "<SYN>\n" +
                                                          xmlNode("NOT", notsyn) +
                                                          xmlNode("VALUE", syn) +
                                                        "</SYN>\n"; }
                      if(!tcp_op.equals(""))  {
                        displayRule +=    "<TCP_OP>\n" +
                                                          xmlNode("NOT", nottcp_op) +
                                                          xmlNode("VALUE", tcp_op) +
                                                      "</TCP_OP>\n";  }
                      if(!icmptype.equals(""))  {
                        displayRule +=    "<ICMP_TYPE>\n" +
                                                          xmlNode("NOT", noticmptype) +
                                                          xmlNode("VALUE", icmptype) +
                                                        "</ICMP_TYPE>\n"; }
                      displayRule +=     "</PROTOCOL>\n";  }
                    if(!src_IP.equals(""))  {
                      displayRule +=    "<SRC>\n" +
                                                        xmlNode("NOT", notSrcIP) +
                                                        xmlNode("VALUE", src_IP) +
                                                      "</SRC>\n"; }
                    if(!des_IP.equals(""))  {
                      displayRule +=    "<DES>\n" +
                                                        xmlNode("NOT", notDesIP) +
                                                        xmlNode("VALUE", des_IP) +
                                                      "</DES>\n"; }
                    if(!src_Device.equals(""))  {
                      displayRule +=     "<IN_IF>\n" +
                                                        xmlNode("NOT", notSrcDevice) +
                                                        xmlNode("VALUE", src_Device) +
                                                      "</IN_IF>\n"; }
                    if(!des_Device.equals(""))  {
                      displayRule +=     "<OUT_IF>\n" +
                                                        xmlNode("NOT", notDesDevice) +
                                                        xmlNode("VALUE", des_Device) +
                                                      "</OUT_IF>\n";  }
                    if(!frag.equals(""))  {
                      displayRule +=    "<FRAGMENT>\n" +
                                                        xmlNode("NOT", notfrag) +
                                                        xmlNode("VALUE", frag) +
                                                      "</FRAGMENT>\n";  }
                    if(!match_mac.equals("") || !match_limit.equals("") || !match_mul.equals("") || !match_state.equals("") || !match_unclean.equals("") ||
                      !match_unclean.equals(""))  {
                      displayRule +=    "<MATCH>\n";
                      if(!match_mac.equals(""))  {
                        displayRule +=    "<MAC>\n" +
                                                          xmlNode("VALUE", match_mac) +
                                                          "<SOURCE>\n" +
                                                            xmlNode("NOT", notmsource) +
                                                            xmlNode("VALUE", msource) +
                                                          "</SOURCE>\n" +
                                                        "</MAC>\n"; }
                      if(!match_limit.equals("")) {
                        displayRule +=    "<LIMIT>\n" +
                                                          xmlNode("VALUE", match_limit);
                        if(!limitrate.equals("")) {
                          displayRule +=     xmlNode("RATE", limitrate); }
                        if(!limitBnum.equals("")) {
                          displayRule +=    xmlNode("BURST", limitBnum);  }
                        displayRule +=    "</LIMIT>\n"; }
                      if(!match_mul.equals("")) {
                        displayRule +=    "<MULTIPORT>\n" +
                                                          xmlNode("VALUE", match_mul) +
                                                          xmlNode("SPORT", mul_sport) +
                                                          xmlNode("DPORT", mul_dport) +
                                                          xmlNode("PORT", sdport) +
                                                        "</MULTIPORT>\n"; }
                      if(!match_state.equals("")) {
                        displayRule +=    "<STATE>\n" +
                                                          xmlNode("VALUE", match_state) +
                                                          xmlNode("STATE_LIST", state) +
                                                        "</STATE>\n"; }
                      if(!match_unclean.equals("")) {
                        displayRule +=    xmlNode("UNCLEAN", match_unclean);  }
                      if(!match_tos.equals("")) {
                        displayRule +=     "<TOS>\n" +
                                                          xmlNode("VALUE", match_tos) +
                                                          xmlNode("TYPE", tos) +
                                                        "</TOS>\n"; }
                      displayRule +=     "</MATCH>\n"; }
                    if(!markvalue.equals("")) {
                      displayRule +=     xmlNode("MARK", markvalue);  }
                    if(!userid.equals(""))  {
                      displayRule +=     xmlNode("UID_OWNER", userid);  }
                    if(!groupid.equals("")) {
                      displayRule +=     xmlNode("GID_OWNER", groupid); }
                    if(!processid.equals("")) {
                      displayRule +=     xmlNode("PID_OWNER", processid); }
                    if(!sessionid.equals("")) {
                      displayRule +=     xmlNode("SID_OWNER", sessionid); }
///////////////// edit By Keng ///////////////////
                    if(!Action.equals(""))
                    displayRule +=       xmlNode("JUMP_TARGET", Action);
//////////////////////////////////////////////////
                    if(!level.equals("") || !prefix.equals("") || !logseq.equals("") || !logop.equals("") || !logipop.equals("") || setmark.equals("") ||
                      !rejecttype.equals("") || !settos.equals("") || !to.equals("") || !tosource.equals("") || !todes.equals("") || toport.equals("")) {
                      displayRule +=     "<TARGET_EXT>\n";
                      if(!level.equals("")) {
                        displayRule +=     xmlNode("LOG_LEVEL", level); }
                      if(!prefix.equals(""))  {
                        displayRule +=     xmlNode("LOG_PREFIX", prefix); }
                      if(!logseq.equals(""))  {
                        displayRule +=     xmlNode("LOG_TCP_SEQ", logseq);  }
                      if(!logop.equals("")) {
                        displayRule +=     xmlNode("LOG_TCP_OPT", logop); }
                      if(!logipop.equals("")) {
                        displayRule +=     xmlNode("LOG_IP_OPT", logipop);  }
                      if(!setmark.equals("")) {
                        displayRule +=     xmlNode("SET_MARK", setmark);  }
                      if(!rejecttype.equals(""))  {
                        displayRule +=     xmlNode("REJECT_WITH", rejecttype);  }
                      if(!settos.equals(""))  {
                        displayRule +=     xmlNode("SET_TOS", settos);  }
                      if(!to.equals(""))  {
                        displayRule +=     xmlNode("TO", to); }
                      if(!tosource.equals(""))  {
                        displayRule +=     xmlNode("TO_SRC", tosource); }
                      if(!todes.equals("")) {
                        displayRule +=     xmlNode("TO_DES", todes);  }
                      if(!to.equals(""))  {
                        displayRule +=     xmlNode("TO_PORT", toport);  }
                      displayRule +=     "</TARGET_EXT>\n";  }
                    displayRule +=     "</RULE>\n";
            }
                           value=value+1;
                           pgBar();
                           rs.next();
                     }
                    }
                          if(rs.last()) {

                        Id = rs.getString("ID");

                        tablename = rs.getString("tablename");
                        if (tablename == null)
                          tablename = "";

                        Chain = rs.getString("Chain");
                        if(Chain == null)
                          Chain = "";

                        notprotocal = rs.getString("notprotocal");
                        if(notprotocal == null)
                          notprotocal = "";
                        if(notprotocal.equals("YES"))
                          notprotocal = "";
                        if(notprotocal.equals("NO"))
                          notprotocal = "!";

                        Protocal = rs.getString("Protocal");
                        if(Protocal == null)
                          Protocal ="";
                        if(Protocal.equals("TCP"))
                            Protocal = "tcp";
                        if(Protocal.equals("UDP"))
                            Protocal = "udp";
                        if(Protocal.equals("ICMP"))
                            Protocal = "icmp";

                        notSrcIP = rs.getString("notSrcIP");
                        if(notSrcIP == null)
                          notSrcIP = "";
                        if(notSrcIP.equals("YES"))
                          notSrcIP = "";
                        if(notSrcIP.equals("NO"))
                          notSrcIP = "!";

                        src_IP = rs.getString("src_IP");
                        if (src_IP == null)
                            src_IP = "";
                        if (src_IP.equals("ANY"))
                            src_IP = "";

                        notSrcPort = rs.getString("notSrcPort");
                        if(notSrcPort == null)
                          notSrcPort = "";
                        if(notSrcPort.equals("YES"))
                          notSrcPort = "";
                        if(notSrcPort.equals("NO"))
                          notSrcPort = "!";

                        src_Port = rs.getString("src_Port");
                        if (src_Port == null)
                            src_Port = "";
                        if(src_Port.equals("ANY"))
                            src_Port = "";

                        notSrcDevice = rs.getString("notSrcDevice");
                        if(notSrcDevice == null)
                            notSrcDevice = "";
                        if(notSrcDevice.equals("YES"))
                          notSrcDevice = "";
                        if(notSrcDevice.equals("NO"))
                          notSrcDevice = "!";

                        src_Device = rs.getString("src_Device");

                        if (src_Device == null)
                            src_Device = "";
                        if(src_Device.equals("ANY"))
                            src_Device = "";

                        notDesIP = rs.getString("notDesIP");
                        if(notDesIP == null)
                            notDesIP = "";
                        if(notDesIP.equals("YES"))
                          notDesIP = "";
                        if(notDesIP.equals("NO"))
                          notDesIP = "!";

                        des_IP = rs.getString("des_IP");

                        if (des_IP == null)
                            des_IP = "";
                        if(des_IP.equals("ANY"))
                            des_IP = "";
                        notDesPort = rs.getString("notDesPort");
                        if(notDesPort == null)
                            notDesPort = "";
                        if(notDesPort.equals("YES"))
                          notDesPort = "";
                        if(notDesPort.equals("NO"))
                          notDesPort = "!";

                        des_Port = rs.getString("des_Port");

                        if (des_Port == null)
                            des_Port = "";
                        if (des_Port.equals("ANY"))
                            des_Port = "";

                        notDesDevice = rs.getString("notDesDevice");
                        if (notDesDevice == null)
                            notDesDevice = "";
                        if(notDesDevice.equals("YES"))
                          notDesDevice = "";
                        if(notDesDevice.equals("NO"))
                          notDesDevice = "!";

                        des_Device = rs.getString("des_Device");

                        if (des_Device == null)
                            des_Device = "";
                        if (des_Device.equals("ANY"))
                            des_Device = "";
                        Action = rs.getString("Action");
                        if(Action == null)
                            Action = "";
                        frag = rs.getString("frag");
                          if(frag == null)
                            frag = "";
                        syn = rs.getString("syn");
                          if(syn == null)
                            syn = "";
                        notfrag = rs.getString("notfrag");
                           if(notfrag == null)
                            notfrag = "";
                        notsyn = rs.getString("notsyn");
                           if(notsyn == null)
                            notsyn = "";
                        notflagmark = rs.getString("notflagmark");
                           if(notflagmark == null)
                            notflagmark = "";
                        flagmark = rs.getString("flagmark");
                           if (flagmark == null)
                             flagmark = "";
                        flagcomp = rs.getString("flagcomp");
                           if (flagcomp == null)
                             flagcomp = "";
                        nottcp_op = rs.getString("nottcp_op");
                           if (nottcp_op == null)
                             nottcp_op = "";
                        tcp_op = rs.getString("tcp_op");
                           if (tcp_op == null)
                              tcp_op = "";
                        noticmptype = rs.getString("noticmptype");
                           if (noticmptype == null)
                              noticmptype = "";
                        icmptype = rs.getString("icmptype");
                           if (icmptype == null)
                              icmptype = "";
                        match = rs.getString("matchs");
                           if (match == null)
                              match = "";
                       sdport = rs.getString("sdport");
                           if(sdport == null)
                              sdport = "";
                       markvalue = rs.getString("markvalue");
                            if(markvalue == null)
                              markvalue = "";
                       userid = rs.getString("userid");
                            if(userid == null)
                              userid = "";
                       groupid = rs.getString("groupid");
                            if(groupid == null)
                              groupid = "";
                       processid = rs.getString("processid");
                            if(processid == null)
                              processid = "";
                       sessionid = rs.getString("sessionid");
                            if(sessionid == null)
                              sessionid = "";
                       state = rs.getString("state");
                            if(state == null)
                              state = "";
                       tos = rs.getString("tos");
                            if(tos == null)
                              tos = "";
                       level = rs.getString("level");
                            if(level == null)
                              level = "";
                       prefix = rs.getString("prefix");
                            if(prefix == null)
                              prefix = "";
                       logseq = rs.getString("logseq");
                            if(logseq == null)
                              logseq = "";
                       logop = rs.getString("logop");
                            if (logop == null)
                              logop = "";
                       logipop = rs.getString("logipop");
                            if (logipop == null)
                              logipop = "";
                       notmsource = rs.getString("notmsource");
                            if(notmsource == null)
                              notmsource = "";
                       msource = rs.getString("msource");
                            if(msource == null)
                              msource = "";
                       limit = rs.getString("limits");
                            if(limit == null)
                              limit = "";
                       limitrate = rs.getString("limitrate");
                            if(limitrate == null)
                              limitrate = "";
                       limitB = rs.getString("limitB");
                            if(limitB == null)
                              limitB = "";
                       limitBnum = rs.getString("limitBnum");
                            if(limitBnum == null)
                              limitBnum = "";
                       setmark = rs.getString("setmark");
                            if(setmark == null)
                              setmark = "";
                       rejecttype = rs.getString("rejecttype");
                            if(rejecttype == null)
                              rejecttype = "";
                       settos = rs.getString("settos");
                            if(settos == null)
                               settos = "";
                       to = rs.getString("natto");
                            if(to == null)
                              to = "";
                       tosource = rs.getString("tosource");
                            if(tosource == null)
                              tosource = "";
                            if(tosource.equals("ANY"))
                              tosource = "";
                       todes = rs.getString("todes");
                            if(todes == null)
                              todes = "";
                            if(todes.equals("ANY"))
                              todes = "";

                       toport = rs.getString("toport");
                            if(toport == null)
                              toport = "";
                            if(toport.equals("ANY"))
                              toport = "";
                       mul_sport = rs.getString("mul_sport");
                            if(mul_sport == null)
                              mul_sport = "";
                       mul_dport = rs.getString("mul_dport");
                            if(mul_dport == null)
                              mul_dport = "";

                       // analyze match here
                       getMatch(match);
                       // gen XML code

              if(!Chain.equals("") && !Action.equals(""))   {
                      displayRule += "<RULE n=\"" +Id + "\">\n";
                      if(!tablename.equals(""))
                        displayRule +=   xmlNode("TABLE", tablename);
///////////////// edit By Keng ///////////////////
                      if (!Chain.equals(""))
                      displayRule +=     xmlNode("CHAIN_NAME", Chain);
///////////////////////////////////////////////////
                      if(!Protocal.equals(""))  {
                        displayRule +=   "<PROTOCOL>\n" +
                                                        xmlNode("NOT", notprotocal) +
                                                        xmlNode("VALUE", Protocal);
                        if(!src_Port.equals(""))  {
                          displayRule +=  "<SRC_PORT>\n" +
                                                        xmlNode("NOT", notSrcPort) +
                                                        xmlNode("VALUE", src_Port) +
                                                        "</SRC_PORT>\n";  }
                        if(!des_Port.equals(""))  {
                          displayRule +=  "<DES_PORT>\n" +
                                                          xmlNode("NOT", notDesPort) +
                                                          xmlNode("VALUE", des_Port) +
                                                        "</DES_PORT>\n";  }
                       if(!flagmark.equals("") || !flagcomp.equals(""))  {
                        displayRule +=     "<TCP_FLAG>\n" +
                                                          "<MASK>\n" +
                                                            xmlNode("NOT", notflagmark) +
                                                            xmlNode("VALUE", flagmark) +
                                                          "</MASK>\n" +
                                                            xmlNode("COMP", flagcomp) +
                                                        "</TCP_FLAG>\n";  }
                      if(!syn.equals("")) {
                        displayRule +=      "<SYN>\n" +
                                                          xmlNode("NOT", notsyn) +
                                                          xmlNode("VALUE", syn) +
                                                        "</SYN>\n"; }
                      if(!tcp_op.equals(""))  {
                        displayRule +=    "<TCP_OP>\n" +
                                                          xmlNode("NOT", nottcp_op) +
                                                          xmlNode("VALUE", tcp_op) +
                                                      "</TCP_OP>\n";  }
                      if(!icmptype.equals(""))  {
                        displayRule +=    "<ICMP_TYPE>\n" +
                                                          xmlNode("NOT", noticmptype) +
                                                          xmlNode("VALUE", icmptype) +
                                                        "</ICMP_TYPE>\n"; }
                      displayRule +=     "</PROTOCOL>\n";  }
                    if(!src_IP.equals(""))  {
                      displayRule +=    "<SRC>\n" +
                                                        xmlNode("NOT", notSrcIP) +
                                                        xmlNode("VALUE", src_IP) +
                                                      "</SRC>\n"; }
                    if(!des_IP.equals(""))  {
                      displayRule +=    "<DES>\n" +
                                                        xmlNode("NOT", notDesIP) +
                                                        xmlNode("VALUE", des_IP) +
                                                      "</DES>\n"; }
                    if(!src_Device.equals(""))  {
                      displayRule +=     "<IN_IF>\n" +
                                                        xmlNode("NOT", notSrcDevice) +
                                                        xmlNode("VALUE", src_Device) +
                                                      "</IN_IF>\n"; }
                    if(!des_Device.equals(""))  {
                      displayRule +=     "<OUT_IF>\n" +
                                                        xmlNode("NOT", notDesDevice) +
                                                        xmlNode("VALUE", des_Device) +
                                                      "</OUT_IF>\n";  }
                    if(!frag.equals(""))  {
                      displayRule +=    "<FRAGMENT>\n" +
                                                        xmlNode("NOT", notfrag) +
                                                        xmlNode("VALUE", frag) +
                                                      "</FRAGMENT>\n";  }
                    if(!match_mac.equals("") || !match_limit.equals("") || !match_mul.equals("") || !match_state.equals("") || !match_unclean.equals("") ||
                      !match_unclean.equals(""))  {
                      displayRule +=    "<MATCH>\n";
                      if(!match_mac.equals(""))  {
                        displayRule +=    "<MAC>\n" +
                                                          xmlNode("VALUE", match_mac) +
                                                          "<SOURCE>\n" +
                                                            xmlNode("NOT", notmsource) +
                                                            xmlNode("VALUE", msource) +
                                                          "</SOURCE>\n" +
                                                        "</MAC>\n"; }
                      if(!match_limit.equals("")) {
                        displayRule +=    "<LIMIT>\n" +
                                                          xmlNode("VALUE", match_limit);
                        if(!limitrate.equals("")) {
                          displayRule +=     xmlNode("RATE", limitrate); }
                        if(!limitBnum.equals("")) {
                          displayRule +=    xmlNode("BURST", limitBnum);  }
                        displayRule +=    "</LIMIT>\n"; }
                      if(!match_mul.equals("")) {
                        displayRule +=    "<MULTIPORT>\n" +
                                                          xmlNode("VALUE", match_mul) +
                                                          xmlNode("SPORT", mul_sport) +
                                                          xmlNode("DPORT", mul_dport) +
                                                          xmlNode("PORT", sdport) +
                                                        "</MULTIPORT>\n"; }
                      if(!match_state.equals("")) {
                        displayRule +=    "<STATE>\n" +
                                                          xmlNode("VALUE", match_state) +
                                                          xmlNode("STATE_LIST", state) +
                                                        "</STATE>\n"; }
                      if(!match_unclean.equals("")) {
                        displayRule +=    xmlNode("UNCLEAN", match_unclean);  }
                      if(!match_tos.equals("")) {
                        displayRule +=     "<TOS>\n" +
                                                          xmlNode("VALUE", match_tos) +
                                                          xmlNode("TYPE", tos) +
                                                        "</TOS>\n"; }
                      displayRule +=     "</MATCH>\n"; }
                    if(!markvalue.equals("")) {
                      displayRule +=     xmlNode("MARK", markvalue);  }
                    if(!userid.equals(""))  {
                      displayRule +=     xmlNode("UID_OWNER", userid);  }
                    if(!groupid.equals("")) {
                      displayRule +=     xmlNode("GID_OWNER", groupid); }
                    if(!processid.equals("")) {
                      displayRule +=     xmlNode("PID_OWNER", processid); }
                    if(!sessionid.equals("")) {
                      displayRule +=     xmlNode("SID_OWNER", sessionid); }
/////////////////// edit By Keng //////////////////////////////
                    if(!Action.equals(""))
                    displayRule +=       xmlNode("JUMP_TARGET", Action);
///////////////////////////////////////////////////////////////
                    if(!level.equals("") || !prefix.equals("") || !logseq.equals("") || !logop.equals("") || !logipop.equals("") || setmark.equals("") ||
                      !rejecttype.equals("") || !settos.equals("") || !to.equals("") || !tosource.equals("") || !todes.equals("") || toport.equals("")) {
                      displayRule +=     "<TARGET_EXT>\n";
                      if(!level.equals("")) {
                        displayRule +=     xmlNode("LOG_LEVEL", level); }
                      if(!prefix.equals(""))  {
                        displayRule +=     xmlNode("LOG_PREFIX", prefix); }
                      if(!logseq.equals(""))  {
                        displayRule +=     xmlNode("LOG_TCP_SEQ", logseq);  }
                      if(!logop.equals("")) {
                        displayRule +=     xmlNode("LOG_TCP_OPT", logop); }
                      if(!logipop.equals("")) {
                        displayRule +=     xmlNode("LOG_IP_OPT", logipop);  }
                      if(!setmark.equals("")) {
                        displayRule +=     xmlNode("SET_MARK", setmark);  }
                      if(!rejecttype.equals(""))  {
                        displayRule +=     xmlNode("REJECT_WITH", rejecttype);  }
                      if(!settos.equals(""))  {
                        displayRule +=     xmlNode("SET_TOS", settos);  }
                      if(!to.equals(""))  {
                        displayRule +=     xmlNode("TO", to); }
                      if(!tosource.equals(""))  {
                        displayRule +=     xmlNode("TO_SRC", tosource); }
                      if(!todes.equals("")) {
                        displayRule +=     xmlNode("TO_DES", todes);  }
                      if(!to.equals(""))  {
                        displayRule +=     xmlNode("TO_PORT", toport);  }
                      displayRule +=     "</TARGET_EXT>\n";  }
                    displayRule +=     "</RULE>\n";
                        }
                        displayRule = displayRule + "</CONFIG_CHAIN>\n";
                      displayRule  = displayRule+"</FIREWALL_CONFIG>";
                }
                      System.out.println("=====================  displayRule =====================");
                      System.out.println(displayRule);
                      System.out.println("=====================  displayRule =====================");

    final String dtdXML = "<?xml version=\"1.0\"?>\n" +
                          "<!DOCTYPE FIREWALL_CONFIG [\n" +
                          "<!ELEMENT FIREWALL_CONFIG (OPTIONS,VAR_LIST*,CHAIN_LIST*,BLACK_LIST*,CONFIG_CHAIN*)>\n" +
                          "<!ELEMENT OPTIONS (DISABLE_BROADCASTS,DISABLE_PINGS,DISABLE_ICMP_REDIRECT,ENABLE_PROTECTION,DISABLE_SPOOFING,ENABLE_SYN_COOKIES,DISABLE_SROUTING,LOG_MARTIANS,DY_DROP)>\n" +
                          "<!ELEMENT DISABLE_BROADCASTS (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_PINGS (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_ICMP_REDIRECT (#PCDATA)>\n" +
                          "<!ELEMENT ENABLE_PROTECTION (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_SPOOFING (#PCDATA)>\n" +
                          "<!ELEMENT ENABLE_SYN_COOKIES (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_SROUTING (#PCDATA)>\n" +
                          "<!ELEMENT LOG_MARTIANS (#PCDATA)>\n" +
                          "<!ELEMENT DY_DROP (#PCDATA)>\n" +
                          "<!ELEMENT VAR_LIST (VAR*)>\n" +
                          "<!ELEMENT VAR (VALUE,COMMENT)>\n" +
                          "<!ELEMENT VALUE (#PCDATA)>\n" +
                          "<!ELEMENT COMMENT (#PCDATA)>\n" +
                          "<!ELEMENT CHAIN_LIST (CHAIN*)>\n" +
                          "<!ELEMENT CHAIN (POLICY,COMMENT)>\n" +
                          "<!ELEMENT POLICY (#PCDATA)>\n" +
                          "<!ELEMENT BLACK_LIST (BL*)>\n" +
                          "<!ELEMENT BL (ADDR,STATUS)>\n" +
                          "<!ELEMENT ADDR (#PCDATA)>\n" +
                          "<!ELEMENT STATUS (#PCDATA)>\n" +
                          "<!ELEMENT CONFIG_CHAIN (RULE*)>\n" +
                          "<!ELEMENT RULE (TABLE?,CHAIN_NAME,PROTOCOL?,SRC?,DES?,IN_IF?,OUT_IF?,FRAGMENT?,MATCH?,MARK?,UID_OWNER?,GID_OWNER?,PID_OWNER?,SID_OWNER?,JUMP_TARGET,TARGET_EXT?)>\n" +
                          "<!ELEMENT TABLE (#PCDATA)>\n" +
                          "<!ELEMENT CHAIN_NAME (#PCDATA)>\n" +
                          "<!ELEMENT PROTOCOL (NOT,VALUE,SRC_PORT?,DES_PORT?,TCP_FLAG?,SYN?,TCP_OP?,ICMP_TYPE?)>\n" +
                          "<!ELEMENT NOT (#PCDATA)>\n" +
                          "<!ELEMENT SRC_PORT (NOT,VALUE)>\n" +
                          "<!ELEMENT DES_PORT (NOT,VALUE)>\n" +
                          "<!ELEMENT TCP_FLAG (MASK,COMP)>\n" +
                          "<!ELEMENT MASK (NOT,VALUE)>\n" +
                          "<!ELEMENT SYN (NOT,VALUE)>\n" +
                          "<!ELEMENT TCP_OP (NOT,VALUE)>\n" +
                          "<!ELEMENT ICMP_TYPE (NOT,VALUE)>\n" +
                          "<!ELEMENT SRC (NOT,VALUE)>\n" +
                          "<!ELEMENT DES (NOT,VALUE)>\n" +
                          "<!ELEMENT IN_IF (NOT,VALUE)>\n" +
                          "<!ELEMENT OUT_IF (NOT,VALUE)>\n" +
                          "<!ELEMENT FRAGMENT (NOT,VALUE)>\n" +
                          "<!ELEMENT MATCH (MAC?,LIMIT?,MULTIPORT?,STATE?,UNCLEAN?,TOS?)>\n" +
                          "<!ELEMENT MAC (VALUE, SOURCE)>\n" +
                          "<!ELEMENT SOURCE (NOT ,VALUE)>\n" +
                          "<!ELEMENT LIMIT (VALUE, RATE?, BURST?)>\n" +
                          "<!ELEMENT RATE (#PCDATA)>\n" +
                          "<!ELEMENT BURST (#PCDATA)>\n" +
                          "<!ELEMENT MULTIPORT (VALUE, SPORT, DPORT, PORT)>\n" +
                          "<!ELEMENT SPORT (#PCDATA)>\n" +
                          "<!ELEMENT DPORT (#PCDATA)>\n" +
                          "<!ELEMENT PORT (#PCDATA)>\n" +
                          "<!ELEMENT STATE (VALUE, STATE_LIST)>\n" +
                          "<!ELEMENT STATE_LIST (#PCDATA)>\n" +
                          "<!ELEMENT UNCLEAN (#PCDATA)>\n" +
                          "<!ELEMENT TOS (VALUE,TYPE)>\n" +
                          "<!ELEMENT TYPE (#PCDATA)>\n" +
                          "<!ELEMENT MARK (#PCDATA)>\n" +
                          "<!ELEMENT UID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT GID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT PID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT SID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT JUMP_TARGET (#PCDATA)>\n" +
                          "<!ELEMENT TARGET_EXT (LOG_LEVEL?,LOG_PREFIX?,LOG_TCP_SEQ?,LOG_TCP_OPT?,LOG_IP_OPT?,SET_MARK?,REJECT_WITH?,SET_TOS?,TO?,TO_SRC?,TO_DES?,TO_PORT?)>\n" +
                          "<!ELEMENT LOG_LEVEL (#PCDATA)>\n" +
                          "<!ELEMENT LOG_PREFIX (#PCDATA)>\n" +
                          "<!ELEMENT LOG_TCP_OPT (#PCDATA)>\n" +
                          "<!ELEMENT LOG_IP_OPT (#PCDATA)>\n" +
                          "<!ELEMENT SET_MARK (#PCDATA)>\n" +
                          "<!ELEMENT REJECT_WITH (#PCDATA)>\n" +
                          "<!ELEMENT SET_TOS (#PCDATA)>\n" +
                          "<!ELEMENT TO (#PCDATA)>\n" +
                          "<!ELEMENT TO_SRC (#PCDATA)>\n" +
                          "<!ELEMENT TO_DES (#PCDATA)>\n" +
                          "<!ELEMENT TO_PORT (#PCDATA)>\n" +
                          "<!ATTLIST BL\n" +
                            "number CDATA #IMPLIED>\n" +
                          "<!ATTLIST RULE\n" +
                            "n CDATA #IMPLIED>\n" +
                          "]>\n";

                            fout.write(dtdXML + displayRule);
                            fout.write('\n');

                             rs.close();
                             fout.close();
              }
                           catch(SQLException ex) {
                               System.out.println(ex.getMessage());
                       }

                        catch (IOException ie) {
                              System.out.println(ie.getMessage());
                           }

          System.out.println("Complete generate XML");
 }//end ConverttoXML

        void pgBar() {


                                  try {
                                        int min = 0; int max=ManagePanel.rs.getRow();

                                        ProgressDialog.progressBar.setValue(min);
					ProgressDialog.progressBar.setMinimum(min);
					ProgressDialog.progressBar.setMaximum(max);

					for (min=0; value<=max; value++) {
						try {
							new Robot().delay(100);

						} catch (Exception ex) {
							// Ignore Exception
						}

                                System.out.println(value);
                                ProgressDialog.progressBar.setValue(value);
                        	ProgressDialog.progressBar.paint(ProgressDialog.progressBar.getGraphics());
                                ProgressDialog.messageLabel.setText(displayRule);
                                ProgressDialog.messageLabel.setText("Sucesssfull !!!");




      }
                                      }
                                  catch(Exception ex) {

                                      }


        }


  void deactivateButton_actionPerformed(ActionEvent e) {
    if(JOptionPane.showConfirmDialog(null, "All data in client's database will be lost. Are you sure?", "Are you sure", JOptionPane.YES_NO_OPTION) == 0)
    { receiveFileFromServer();
    }
  }

  void activateButton_actionPerformed(ActionEvent e) {
    if  (JOptionPane.showConfirmDialog(null,"Do you want to apply all rules to server?","Apply?",JOptionPane.YES_NO_OPTION) == 0 )
      {   ConverttoXML();
          sendFileToServer();
      }
  }
//////////////end pgBar

}//end class