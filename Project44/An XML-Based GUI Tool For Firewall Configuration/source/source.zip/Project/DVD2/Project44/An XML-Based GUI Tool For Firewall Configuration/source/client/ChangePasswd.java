import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import com.borland.jbcl.layout.*;
import java.net.InetAddress;

public class ChangePasswd extends JFrame {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  XYLayout xYLayout2 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  JLabel newpasswdLabel = new JLabel();
  JLabel newpasswdaLabel = new JLabel();
  JLabel oldpasswdLabel = new JLabel();
  JButton okButton = new JButton();
  JPasswordField oldpasswdTextField = new JPasswordField();
  JPasswordField newpasswdaTextField = new JPasswordField();
  JLabel ImageLabel = new JLabel();
  JLabel changeLabel = new JLabel();
  JPasswordField newpasswdTextField = new JPasswordField();
  String username,dpassword="";

  public ChangePasswd() {
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
          //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    //setVisible(true);
  }

  void jbInit() throws Exception {

      try {
              InetAddress myhost = InetAddress.getLocalHost();
              myhostLabel.setText("Host Name : "+myhost.getHostName()+"  IP Address : "+myhost.getHostAddress());
    }
    catch(Exception e)
    {
        System.out.println("Failed to find myHost");
        e.printStackTrace();
    }

    changeLabel.setIcon(new ImageIcon("./Images/change.gif"));
    ImageLabel.setIcon(new ImageIcon("./Images/firewall_login.png"));
    ImageLabel.setBorder(BorderFactory.createEtchedBorder());
    ImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    ImageLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    panel1.setLayout(xYLayout1);
    this.getContentPane().setLayout(xYLayout2);
    xYLayout2.setWidth(392);
    xYLayout2.setHeight(240);
    panel1.setBackground(new Color(236, 233, 230));
    panel1.setMaximumSize(new Dimension(300, 400));
    panel1.setMinimumSize(new Dimension(100, 150));
    jPanel1.setLayout(xYLayout3);
    newpasswdLabel.setText("New Password");
    newpasswdaLabel.setText("New Password Again");
    oldpasswdLabel.setToolTipText("");
    oldpasswdLabel.setText("Old Password");
    okButton.setBackground(new Color(236, 233, 230));
    okButton.setText("OK");
    this.getContentPane().setBackground(new Color(236, 233, 230));
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    changeLabel.setBorder(BorderFactory.createEtchedBorder());
    changeLabel.setHorizontalAlignment(SwingConstants.CENTER);
    changeLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    myhostLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    myhostLabel.setHorizontalTextPosition(SwingConstants.LEFT);
    this.getContentPane().add(panel1,  new XYConstraints(4, 5, 390, 242));
    jPanel1.add(okButton, new XYConstraints(180, 121, 88, 29));
    jPanel1.add(newpasswdaTextField,   new XYConstraints(235, 83, 123, -1));
    jPanel1.add(oldpasswdLabel, new XYConstraints(106, 13, 90, 30));
    jPanel1.add(newpasswdLabel, new XYConstraints(103, 48, 108, 27));
    jPanel1.add(newpasswdaLabel, new XYConstraints(103, 84, 127, 27));
    jPanel1.add(ImageLabel,   new XYConstraints(8, 17, 86, 108));
    jPanel1.add(newpasswdTextField,    new XYConstraints(235, 51, 123, -1));
    jPanel1.add(oldpasswdTextField, new XYConstraints(235, 18, 123, -1));
    jPanel1.add(myhostLabel,    new XYConstraints(16, 151, 346, 19));
    panel1.add(changeLabel,    new XYConstraints(5, 7, 372, 37));
    panel1.add(jPanel1,         new XYConstraints(4, 50, 373, 178));

    okButton.addActionListener(new clickedOk());

    // Database section
	db = new DBUtil();
	con = db.Establish();

   ImageIcon icon = new ImageIcon(("images/User.png"));
    this.setIconImage(icon.getImage());
    this.setTitle("Change Password");

  }////// end jbinit()

    class clickedOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       String SQL="";

              SQL = "SELECT * FROM user";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

         try {
                  rs.next();
                  username = rs.getString("username");
                  dpassword = rs.getString("password");

                  System.out.println("username : "+username);
                  System.out.println("dpassword : "+dpassword);

               }
          catch (SQLException ex) {
                     System.out.println(ex.getMessage());
          }



    if (isPasswordCorrect() && isnewPasswordCorrect() ) {

        SQL="update user set password ='"+newpasswdTextField.getPassword()+"' where Id=1";
        System.out.println(SQL);
        db.SQLExecute(SQL);

	JOptionPane.showMessageDialog(null,"Success! You can change password.",
	    "Success!",JOptionPane.INFORMATION_MESSAGE);

             Application1.frame.setEnabled(true);
             dispose();
             hide();

    } else {

	JOptionPane.showMessageDialog(null,
	    "Invalid change password. Try again.",
	    "Error Message",
	    JOptionPane.ERROR_MESSAGE);
    }
      }
    }//////////end clickedOk


    boolean isPasswordCorrect() {

     char[] password = oldpasswdTextField.getPassword();

        if(password.length != dpassword.length())
            return false;
        for(int i=0;i<password.length;i++)
         if(  password[i] != (dpassword.charAt(i)))
             return false;


        return true;
    }

    boolean isnewPasswordCorrect() {

     char[] password =  newpasswdTextField.getPassword();
     char[] passworda = newpasswdaTextField.getPassword();

        if(password.length != passworda.length)
            return false;
        for(int i=0;i<passworda.length;i++)
         if(  password[i] != passworda[i])
             return false;


        return true;
    }
  JLabel myhostLabel = new JLabel();



}//end class
