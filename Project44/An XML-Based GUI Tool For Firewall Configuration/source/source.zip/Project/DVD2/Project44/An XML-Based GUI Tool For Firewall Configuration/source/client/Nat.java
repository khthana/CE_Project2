import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.util.*;
import java.sql.*;
import java.text.*;
import javax.swing.JTable;
import java.lang.String;
import javax.swing.table.AbstractTableModel;

public class Nat extends JPanel {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;
  JLabel label2;

  String url, user, password, retriveSQL, tableName;

  public static JTable table;

  public static String protocalNames[]= { "TCP","UDP","ICMP"};

   public static final String EMPTY = "";
   public static final String NEW = "NEW";
   public static final String UPDATE = "UPDATE";
   public static final String PK = "PK";

  public String status;
  int ReturnRowSelect;




  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JLabel ftptcpLabel = new JLabel();
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  Border border1;
  Border border2;
  Border border3;
  TitledBorder titledBorder1;
  Border border4;
  JPanel dnatPanel = new JPanel();


  JLabel des_IPLabel = new JLabel();
  JTextField des_ipTextField = new JTextField();
  JLabel dnat_toIPLabel = new JLabel();
  JTextField in_deviceTextField = new JTextField();
  JTextField dnat_toipTextField = new JTextField();
  JLabel in_deviceLabel = new JLabel();
  XYLayout xYLayout6 = new XYLayout();
  Border border5;
  Border border6;
  XYLayout xYLayout7 = new XYLayout();
  JPanel controlPanel = new JPanel();
  XYLayout xYLayout9 = new XYLayout();
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  JButton addButton = new JButton(new ImageIcon("images/Add.png"));
  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  JButton clearButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JPanel jPanel4 = new JPanel();
  XYLayout xYLayout4 = new XYLayout();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel9 = new JPanel();
  XYLayout xYLayout11 = new XYLayout();
  XYLayout xYLayout10 = new XYLayout();
  Border border7;
  TitledBorder titledBorder2;
  JPanel jPanel6 = new JPanel();
  XYLayout xYLayout8 = new XYLayout();
  JPanel tablePanel = new JPanel();
  Border border8;


  Border border9;
  XYLayout xYLayout12 = new XYLayout();
  JTextField dnat_toportTextField = new JTextField();
  JButton dnat_okButton = new JButton(new ImageIcon("Images/Ok.png"));
  Border border10;
  Border border11;
  TitledBorder titledBorder3;
  JLabel iptablesLabel = new JLabel();
  JLabel tcpLabel = new JLabel();
  JRadioButton enableRadioButton = new JRadioButton();
  JRadioButton disableRadioButton = new JRadioButton();
  JLabel enableLabel = new JLabel();
  JLabel disableLabel = new JLabel();
  JLabel plusplusLabel = new JLabel();
  JLabel dnat_toportLabel = new JLabel();
  JLabel statusLabel = new JLabel();
  JButton activateButton = new JButton(new ImageIcon("images/CheckAll.gif"));
  JComboBox dnat_protocalComboBox = new JComboBox(protocalNames);
  JLabel protocalLabel = new JLabel();
  JLabel des_PortLabel = new JLabel();
  JTextField des_portTextField = new JTextField();
  XYLayout xYLayout5 = new XYLayout();
  JRadioButton snatRadioButton = new JRadioButton();
  JRadioButton dnatRadioButton = new JRadioButton();
  XYLayout xYLayout14 = new XYLayout();
  JPanel selectnatPanel = new JPanel();
  JTextField out_deviceTextField = new JTextField();
  XYLayout xYLayout13 = new XYLayout();
  JLabel src_PortLabel = new JLabel();
  JLabel snat_toportLabel = new JLabel();
  JLabel snat_toIPLabel = new JLabel();
  JLabel out_deviceLabel = new JLabel();
  JTextField snat_toipTextField = new JTextField();
  JTextField snat_toportTextField = new JTextField();
  JTextField src_ipTextField = new JTextField();
  JPanel snatPanel = new JPanel();
  JComboBox snat_protocalComboBox = new JComboBox(protocalNames);
  JLabel src_IPLabel = new JLabel();
  JLabel protocalLabel1 = new JLabel();
  JButton snat_okButton = new JButton(new ImageIcon("Images/Ok.png"));
  JTextField src_portTextField = new JTextField();
  Border border12;
  TitledBorder titledBorder4;

  public Nat() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

    user="admin";
    password="";
    tableName="confige";
    retriveSQL="SELECT * FROM nat";


Object[][] data = {
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
            {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""}, {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "" ,""},
   };


String[] columnNames = {
                         "select",
                         "rule no.",
                         "src ip",
                         "src port",
                         "out device",
                         "snat Protocal",
                         "snat toIP",
                         "snat toport",
                         "des ip",
                         "des Port",
                         "in device",
                         "dnat protocal",
                         "dnat toIP",
                         "dnat toPort"
                                                };

  table = new JTable(data,columnNames)
  {
			public TableCellRenderer getCellRenderer(int row, int column) {
				TableColumn tableColumn = getColumnModel().getColumn(column);
				TableCellRenderer renderer = tableColumn.getCellRenderer();
				if (renderer == null) {
					Class c = getColumnClass(column);
					if( c.equals(Object.class) )
					{
						Object o = getValueAt(row,column);
						if( o != null )
					c = getValueAt(row,column).getClass();
					}
					renderer = getDefaultRenderer(c);
				}
				return renderer;
			}

                                                                                          public TableCellEditor getCellEditor(int row, int column) {
				TableColumn tableColumn = getColumnModel().getColumn(column);
				TableCellEditor editor = tableColumn.getCellEditor();
				if (editor == null) {
					Class c = getColumnClass(column);
					if( c.equals(Object.class) )
					{
						Object o = getValueAt(row,column);
						if( o != null )
					c = getValueAt(row,column).getClass();
					}
					editor = getDefaultEditor(c);
				}
				return editor;
			}

                 public void clearData() {
                for(int i=0; i<table.getRowCount(); i++)
		  for(int j=0; j<table.getColumnCount(); j++)
		if (j<=20)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
      }

		};


     border12 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder4 = new TitledBorder(border12,"POSTROUTING");
    ftptcpLabel.setIcon(new ImageIcon("./Images/Nat.gif"));
     iptablesLabel.setIcon(new ImageIcon("./Images/iptables.gif"));
     tcpLabel.setIcon(new ImageIcon("./Images/Tcp.gif"));
    enableLabel.setIcon(new ImageIcon("./Images/Enable.png"));
    disableLabel.setIcon(new ImageIcon("./Images/Disable.png"));
    plusplusLabel.setIcon(new ImageIcon("./Images/plusplus.png"));


  border11 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161)),"Options");
    table.setDefaultRenderer( JComponent.class, new JComponentCellRenderer() );
  table.setDefaultEditor( JComponent.class, new JComponentCellEditor() );


  JScrollPane scrollPane = new JScrollPane(table);
  border10 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));


    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border7 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(border7,"Options");
    border8 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border9 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    this.setLayout(xYLayout7);
    controlPanel.setLayout(xYLayout9);
    applyButton.setBackground(new Color(236, 233, 230));
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setText("Aplly");
    addButton.setBackground(new Color(236, 233, 230));
    addButton.setBorder(BorderFactory.createEtchedBorder());
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setText("Add");
    editButton.setBackground(new Color(236, 233, 230));
    editButton.setBorder(BorderFactory.createEtchedBorder());
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    editButton.setText("Edit");
    clearButton.setBackground(new Color(236, 233, 230));
    clearButton.setBorder(BorderFactory.createEtchedBorder());
    clearButton.setHorizontalTextPosition(SwingConstants.LEFT);
    clearButton.setText("Clear");
    jPanel4.setLayout(xYLayout4);
    jPanel10.setLayout(xYLayout11);
    jPanel10.setBackground(new Color(236, 233, 230));
    jPanel10.setBorder(titledBorder3);
    jPanel9.setLayout(xYLayout10);
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"Options");
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border5 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"PREROUTING");
    ftptcpLabel.setBorder(BorderFactory.createEtchedBorder());
    ftptcpLabel.setPreferredSize(new Dimension(20, 30));
    ftptcpLabel.setHorizontalAlignment(SwingConstants.CENTER);
    ftptcpLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"Chain");
    jPanel1.setLayout(xYLayout1);
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel1.setPreferredSize(new Dimension(400, 200));
    jPanel2.setLayout(xYLayout2);
    jPanel3.setLayout(xYLayout3);
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(border1);
    des_IPLabel.setText("des IP");
    dnat_toIPLabel.setText("to IP");
    in_deviceLabel.setText("in Device");

    dnatPanel.setLayout(xYLayout6);
    dnatPanel.setBackground(new Color(236, 233, 230));
    dnatPanel.setBorder(border5);
    jPanel6.setLayout(xYLayout8);
    tablePanel.setLayout(xYLayout12);
    tablePanel.setBackground(new Color(236, 233, 230));
    tablePanel.setBorder(border8);

    scrollPane.setViewportBorder(BorderFactory.createEtchedBorder());
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setAutoscrolls(true);
    scrollPane.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.setDoubleBuffered(true);
    scrollPane.setPreferredSize(new Dimension(400, 200));

    xYLayout7.setWidth(651);
    xYLayout7.setHeight(455);
    dnat_okButton.setBackground(new Color(236, 233, 230));
    dnat_okButton.setBorder(BorderFactory.createEtchedBorder());
    dnat_okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    dnat_okButton.setText("OK");
    this.setBackground(new Color(236, 233, 230));
    this.setMaximumSize(new Dimension(800, 600));
    this.setMinimumSize(new Dimension(200, 300));
    this.setPreferredSize(new Dimension(500, 300));
    jPanel9.setBackground(new Color(236, 233, 230));
    controlPanel.setBackground(new Color(236, 233, 230));
    jPanel6.setBackground(new Color(236, 233, 230));
    jPanel2.setBackground(new Color(236, 233, 230));
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.setGridColor(Color.lightGray);
    table.setIntercellSpacing(new Dimension(2, 2));
    table.setSelectionBackground(new Color(255, 255, 239));
    jPanel4.setBackground(new Color(236, 233, 230));
    iptablesLabel.setHorizontalAlignment(SwingConstants.CENTER);
    iptablesLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    enableRadioButton.setBackground(new Color(236, 233, 230));
    enableRadioButton.setHorizontalTextPosition(SwingConstants.RIGHT);
    enableRadioButton.setText("Enable");
    disableRadioButton.setBackground(new Color(236, 233, 230));
    disableRadioButton.setHorizontalTextPosition(SwingConstants.RIGHT);
    disableRadioButton.setText("Disable");
    plusplusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    plusplusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    dnat_toportLabel.setText("to Port");
    statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    statusLabel.setHorizontalTextPosition(SwingConstants.LEFT);
    statusLabel.setText("status :");
    activateButton.addActionListener(new clickedActivate());
    activateButton.setText("Activate");
    activateButton.setHorizontalTextPosition(SwingConstants.LEFT);
    activateButton.setBorder(BorderFactory.createEtchedBorder());
    activateButton.setBackground(new Color(236, 233, 230));
    protocalLabel.setText("Protocal");
    des_PortLabel.setText("des Port");
    dnat_protocalComboBox.setBackground(new Color(236, 233, 230));



    dnat_okButton.setText("OK");
    dnat_okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    dnat_okButton.setBorder(BorderFactory.createEtchedBorder());
    dnat_okButton.setBackground(new Color(236, 233, 230));

    snatRadioButton.setBackground(new Color(236, 233, 230));
    snatRadioButton.setFont(new java.awt.Font("Dialog", 1, 10));
    snatRadioButton.setText("SNAT");
    dnatRadioButton.setBackground(new Color(236, 233, 230));
    dnatRadioButton.setFont(new java.awt.Font("Dialog", 1, 10));
    dnatRadioButton.setHorizontalTextPosition(SwingConstants.RIGHT);
    dnatRadioButton.setText("DNAT");
    selectnatPanel.setBackground(new Color(236, 233, 230));
    selectnatPanel.setBorder(BorderFactory.createEtchedBorder());
    selectnatPanel.setLayout(xYLayout14);
    src_PortLabel.setText("src Port");
    snat_toportLabel.setText("to Port");
    snat_toIPLabel.setText("to IP");
    out_deviceLabel.setText("out Device");
    snatPanel.setVisible(true);
    snatPanel.setBorder(titledBorder4);
    snatPanel.setBackground(new Color(236, 233, 230));
    snatPanel.setLayout(xYLayout13);
    snat_protocalComboBox.setBackground(new Color(236, 233, 230));
    src_IPLabel.setText("src IP");
    protocalLabel1.setText("Protocal");
    snat_okButton.setBackground(new Color(236, 233, 230));
    snat_okButton.setBorder(BorderFactory.createEtchedBorder());
    snat_okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    snat_okButton.setText("OK");
    snat_okButton.setText("OK");
    snat_okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    snat_okButton.setBorder(BorderFactory.createEtchedBorder());
    snat_okButton.setBackground(new Color(236, 233, 230));
    dnatPanel.add(des_IPLabel,  new XYConstraints(4, 4, 45, -1));
    dnatPanel.add(des_PortLabel, new XYConstraints(3, 28, 53, 18));
    dnatPanel.add(in_deviceLabel, new XYConstraints(3, 52, 62, -1));
    dnatPanel.add(protocalLabel, new XYConstraints(4, 75, 53, 20));
    dnatPanel.add(dnat_toportTextField, new XYConstraints(216, 27, 87, 21));
    dnatPanel.add(dnat_toportLabel,  new XYConstraints(163, 30, 47, 15));
    dnatPanel.add(dnat_toIPLabel, new XYConstraints(163, 6, 57, -1));
    dnatPanel.add(dnat_toipTextField, new XYConstraints(215, 3, 88, -1));
    dnatPanel.add(dnat_protocalComboBox, new XYConstraints(72, 78, 83, 21));
    dnatPanel.add(des_ipTextField, new XYConstraints(72, 3, 85, -1));
    dnatPanel.add(des_portTextField, new XYConstraints(72, 28, 83, -1));
    dnatPanel.add(in_deviceTextField, new XYConstraints(72, 53, 84, -1));
    dnatPanel.add(dnat_okButton, new XYConstraints(219, 61, 76, 28));
    jPanel3.add(snatPanel,      new XYConstraints(146, 11, 319, 132));
    jPanel3.add(controlPanel,  new XYConstraints(63, 7, -1, 142));
    selectnatPanel.add(dnatRadioButton,   new XYConstraints(1, 32, 51, -1));
    selectnatPanel.add(snatRadioButton,  new XYConstraints(0, 10, 52, -1));
    this.add(jPanel2,      new XYConstraints(3, 5, -1, 443));
    jPanel2.add(jPanel1,                          new XYConstraints(-3, 4, 592, 452));
    jPanel1.add(jPanel6, new XYConstraints(-22, 212, 609, -1));
    jPanel6.add(tablePanel,     new XYConstraints(31, 6, 576, 206));
    tablePanel.add(scrollPane,    new XYConstraints(7, 6, 558, 191));
    jPanel1.add(jPanel3,                  new XYConstraints(9, 54, 577, 155));
    jPanel1.add(ftptcpLabel, new XYConstraints(9, 0, 576, 48));
    jPanel1.add(plusplusLabel,          new XYConstraints(155, 6, 46, 35));
    jPanel1.add(tcpLabel,           new XYConstraints(426, 19, 92, 26));
    jPanel1.add(statusLabel, new XYConstraints(501, 27, 76, 17));
    this.add(iptablesLabel,    new XYConstraints(600, 9, 38, 423));
    controlPanel.add(clearButton,          new XYConstraints(1, 104, 80, 31));
    controlPanel.add(addButton,       new XYConstraints(2, 10, 78, 32));
    controlPanel.add(applyButton,              new XYConstraints(1, 43, 79, 30));
    controlPanel.add(editButton,      new XYConstraints(1, 73, 79, 31));
    jPanel3.add(selectnatPanel,        new XYConstraints(6, 15, 57, 127));
    jPanel3.add(jPanel4,       new XYConstraints(463, 8, 108, -1));
    jPanel4.add(jPanel10,                     new XYConstraints(4, 0, -1, 135));
    jPanel10.add(jPanel9,         new XYConstraints(-3, 0, 93, 102));
    jPanel9.add(enableRadioButton,    new XYConstraints(4, 11, 57, 15));
    jPanel9.add(disableRadioButton,   new XYConstraints(5, 35, 63, 13));
    jPanel9.add(disableLabel, new XYConstraints(70, 30, 23, 24));
    jPanel9.add(enableLabel,    new XYConstraints(70, 8, 26, 25));
    jPanel9.add(activateButton,         new XYConstraints(8, 61, 78, 32));
    snatPanel.add(src_IPLabel, new XYConstraints(4, 4, 45, -1));
    snatPanel.add(src_PortLabel, new XYConstraints(3, 28, 53, 18));
    snatPanel.add(out_deviceLabel, new XYConstraints(3, 52, 62, -1));
    snatPanel.add(protocalLabel1, new XYConstraints(4, 75, 53, 20));
    snatPanel.add(snat_toportTextField, new XYConstraints(216, 27, 87, 21));
    snatPanel.add(snat_toportLabel, new XYConstraints(163, 30, 47, 15));
    snatPanel.add(snat_toIPLabel, new XYConstraints(163, 6, 57, -1));
    snatPanel.add(snat_toipTextField, new XYConstraints(215, 3, 88, -1));
    snatPanel.add(snat_protocalComboBox, new XYConstraints(72, 78, 83, 21));
    snatPanel.add(src_ipTextField, new XYConstraints(72, 3, 85, -1));
    snatPanel.add(src_portTextField, new XYConstraints(72, 28, 83, -1));
    snatPanel.add(out_deviceTextField, new XYConstraints(72, 53, 84, -1));
    snatPanel.add(snat_okButton, new XYConstraints(219, 61, 76, 28));
    jPanel3.add(dnatPanel,   new XYConstraints(146, 11, 319, 132));


    ButtonGroup rbg = new ButtonGroup();
        rbg.add(enableRadioButton);
        rbg.add(disableRadioButton);

 ButtonGroup rbg2 = new ButtonGroup();


    // Database section
	db = new DBUtil();
	con = db.Establish();

    snatRadioButton.addMouseListener(new clickedsnat());
    dnatRadioButton.addMouseListener(new clickeddnat());


    addButton.addActionListener(new clickedAdd());
    applyButton.addActionListener(new clickedApply());
    editButton.addActionListener(new clickedEdit());
    clearButton.addActionListener(new clickedClear());

    snat_okButton.addActionListener(new clickedSnatOk());
    dnat_okButton.addActionListener(new clickedDnatOk());



    table.addMouseListener(new clickedTable());

    TableColumn column=null;
    column=table.getColumnModel().getColumn(1);
    column.setMaxWidth(150);
    column.setMinWidth(0);
    column.setWidth(150);

    statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));

    table.setRowHeight(40);

         try {
          rs.last();
            }
        catch(Exception ex)
          {
            System.out.println(ex.getMessage());
          }

    refreshRecordTable();

    controlPanel.setVisible(false);

    snatPanel.setVisible(false);
    snatPanel.disable();
    dnatPanel.setVisible(false);
    dnatPanel.disable();

    rbg2.add(snatRadioButton);
    rbg2.add(dnatRadioButton);
  }////////////end jbinit()

 class clickedTable extends MouseAdapter {
  public void mouseClicked(MouseEvent e) {
    System.out.println("Table ................................");
    System.out.println("getRwoCount :> "+table.getRowCount());


     for(int row=0;row<table.getRowCount();row++) {
        table.setValueAt(new Boolean(false),row,0);
        System.out.println(row);
    }

        int selectRow = table.getSelectedRow();
        table.setValueAt(new Boolean(true),selectRow,0);
  }
 }

  class clickedsnat extends MouseAdapter {
      public void mouseClicked(MouseEvent e) {
          System.out.println("snatPanel.setVisible(true);");
          controlPanel.setVisible(true);
          dnatPanel.setVisible(false);
          dnatPanel.disable();
     }
  }

 class clickeddnat extends MouseAdapter {
      public void mouseClicked(MouseEvent e) {
          System.out.println("dnatPanel.setVisible(true);");
          controlPanel.setVisible(true);
          snatPanel.setVisible(false);
          snatPanel.disable();
     }
  }

  class clickedActivate implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          String SQL="",en_dis="";

          if(enableRadioButton.isSelected() == true)
              en_dis = "ENABLE";
          else
              en_dis = "DISABLE";

                    SQL = "UPDATE nat SET en_dis =  '"+en_dis+ "' ";
                    db.SQLExecute(SQL);
                    System.out.println(SQL);
     }
  }

  class clickedSnatOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {
              snatPanel.disable();
              updateSnatRecord();
              statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
              clearField();
              snatPanel.setVisible(false);
     }
  }

  class clickedDnatOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {
              dnatPanel.disable();
              updateDnatRecord();
              statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
              clearField();
              dnatPanel.setVisible(false);

     }
  }
  class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {
      status = "ADD";
      statusLabel.setIcon(new ImageIcon("./Images/Add.gif"));
      clearField();

      if (snatRadioButton.isSelected()) {
          dnatPanel.setVisible(false);
          snatPanel.setVisible(true);
          snatPanel.setEnabled(true);
      }
      else {
          dnatPanel.setVisible(true);
          dnatPanel.setEnabled(true);
          snatPanel.setVisible(false);
      }

    }
  }
  void clearField() {

      src_ipTextField.setText("");
      src_portTextField.setText("");
      out_deviceTextField.setText("");
      snat_protocalComboBox.setSelectedIndex(0);
      snat_toipTextField.setText("");
      snat_toportTextField.setText("");

      des_ipTextField.setText("");
      des_portTextField.setText("");
      in_deviceTextField.setText("");
      dnat_protocalComboBox.setSelectedIndex(0);
      dnat_toipTextField.setText("");
      dnat_toportTextField.setText("");

  }

  class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          try {
                  db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

    }
  }

  class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          status = "UPDATE";
          statusLabel.setIcon(new ImageIcon("./Images/Edit.gif"));
          clearField();
          setEdit();
    }
  }

  class clickedClear implements ActionListener {
      public void actionPerformed(ActionEvent e) {

                               int Id;
                                String SQL="",Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;

                                       ReturnRowSelect = table.getSelectedRow();
                                       System.out.println("ReturnRowSelect : "+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getInt("ID");
	                             SQL = "DELETE FROM confige"+ " WHERE ";
                                                           SQL = SQL +  "ID =  "+Id+" ";
		db.SQLExecute(SQL);
		System.out.println(SQL);

                                    }
                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                refreshRecordTable();
    }
  }


  public   void setEdit() {
               String SQL="",Id;
               String src_IP,src_Port,out_Device,snat_Protocal,snat_toIP,snat_toPort,des_IP,des_Port,in_Device,dnat_Protocal,dnat_toIP,dnat_toPort;

               String tmp;

                   ReturnRowSelect = table.getSelectedRow();
                  System.out.println("ReturnRowSelect : "+ReturnRowSelect);
                   try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++){
                      rs.next();
                    }
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  out_Device = rs.getString("des_Device");
                                  snat_Protocal = rs.getString("Protocal");
                                  snat_toIP = rs.getString("tosource");
                                  snat_toPort = rs.getString("toport");

                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  in_Device = rs.getString("src_Device");
                                  dnat_Protocal = rs.getString("Protocal");
                                  dnat_toIP = rs.getString("todes");
                                  dnat_toPort = rs.getString("toport");

                                  src_ipTextField.setText(src_IP);
                                  src_portTextField.setText(src_Port);
                                  out_deviceTextField.setText(out_Device);
                                  snat_toipTextField.setText(snat_toIP);
                                  snat_toportTextField.setText(snat_toPort);

                                  des_ipTextField.setText(des_IP);
                                  des_portTextField.setText(des_Port);
                                  in_deviceTextField.setText(in_Device);
                                  dnat_toipTextField.setText(dnat_toIP);
                                  dnat_toportTextField.setText(dnat_toPort);

                           if ((src_IP != null) && (!src_IP.equals(""))) {
                                  snatPanel.setVisible(true);
                                  dnatPanel.setVisible(false);
                                  if (snat_Protocal.equalsIgnoreCase("TCP"))
                                        snat_protocalComboBox.setSelectedIndex(0);
                                  else if (snat_Protocal.equalsIgnoreCase("UDP"))
                                        snat_protocalComboBox.setSelectedIndex(1);
                                  else if (snat_Protocal.equalsIgnoreCase("FORWARD"))
                                        snat_protocalComboBox.setSelectedIndex(2);
                          }
                            else {
                                  snatPanel.setVisible(false);
                                  dnatPanel.setVisible(true);

                                  if (dnat_Protocal.equalsIgnoreCase("TCP"))
                                        dnat_protocalComboBox.setSelectedIndex(0);
                                  else if (dnat_Protocal.equalsIgnoreCase("UDP"))
                                        dnat_protocalComboBox.setSelectedIndex(1);
                                  else if (dnat_Protocal.equalsIgnoreCase("FORWARD"))
                                        dnat_protocalComboBox.setSelectedIndex(2);
                          }

                  }
                                   catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }

  }//end setEdit

public static void refreshRecordTable() {
        String SQL="",Id,src_IP,src_Port,out_Device,snat_Protocal,snat_toIP,snat_toPort
        ,des_IP,des_Port,in_Device,dnat_Protocal,dnat_toIP,dnat_toPort;

        if(con!=null)
        {
          try {


          SQL = "SELECT * FROM Confige Where tablename = 'nat' order by ID" ;
          System.out.println(SQL);
          rs = db.SQLRetrive(SQL);

          rs.first();


                for(int i=0; i<table.getRowCount(); i++)
                    for(int j=1; j<table.getColumnCount(); j++)
		if (j<=20)
		  table.setValueAt("", i, j);
		else
                table.setValueAt(new Boolean(false), i, j);

              int row =0;

                             while (rs.next()) {
                                  rs.previous();
                                  Id = rs.getString("ID");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  out_Device = rs.getString("des_Device");
                                  snat_Protocal = rs.getString("Protocal");
                                  snat_toIP = rs.getString("tosource");
                                  snat_toPort = rs.getString("toport");

                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  in_Device = rs.getString("src_Device");
                                  dnat_Protocal = rs.getString("Protocal");
                                  dnat_toIP = rs.getString("todes");
                                  dnat_toPort = rs.getString("toport");

   JLabel ProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("pTcp.gif")),JLabel.CENTER);

   JLabel  SrcIPLabel = new JLabel(src_IP, new ImageIcon( table.getClass().getResource("SourceCom.png")),JLabel.CENTER);
   JLabel  DesIPLabel = new JLabel(des_IP, new ImageIcon( table.getClass().getResource("DesCom.png")),JLabel.CENTER);

   JLabel  SrcPortLabel = new JLabel(src_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);
   JLabel  DesPortLabel = new JLabel(des_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);

   JLabel  tcpProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("pTcp.gif")),JLabel.CENTER);
   JLabel   udpProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("Udp.gif")),JLabel.CENTER);
   JLabel   icmpProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("Icmp.gif")),JLabel.CENTER);


   JLabel  OutDeviceLabel = new JLabel(out_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);
   JLabel  InDeviceLabel = new JLabel(in_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);

   JLabel  AnyLabel = new JLabel("ANY", new ImageIcon( table.getClass().getResource("Any.png")),JLabel.CENTER);

   JLabel  snat_toIPLabel = new JLabel(snat_toIP, new ImageIcon( table.getClass().getResource("Computer.png")),JLabel.CENTER);
   JLabel   snat_toPortLabel = new JLabel(snat_toPort, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);

   JLabel  dnat_toIPLabel = new JLabel(dnat_toIP, new ImageIcon( table.getClass().getResource("Computer.png")),JLabel.CENTER);
   JLabel   dnat_toPortLabel = new JLabel(dnat_toPort, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);


                                  table.setValueAt(Id,row,1);

                      if ( (src_IP != null) && (!src_IP.equals(""))) {

                               if (src_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,2);
                                  else
                                      table.setValueAt(SrcIPLabel,row,2);

                                 if (src_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,3);
                                  else
                                      table.setValueAt(SrcPortLabel,row,3);

                                 if (out_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,4);
                                  else
                                      table.setValueAt(OutDeviceLabel,row,4);


                                  if (snat_Protocal.equals("TCP"))
                                      table.setValueAt(tcpProtocalLabel,row,5);
                                  else
                                      if (snat_Protocal.equals("UDP"))
                                          table.setValueAt(udpProtocalLabel,row,5);
                                      else
                                          table.setValueAt(icmpProtocalLabel,row,5);

                                   if (snat_toIP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,6);
                                  else
                                      table.setValueAt(snat_toIPLabel,row,6);

                                  if (snat_toPort.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,7);
                                  else
                                      table.setValueAt(snat_toPortLabel,row,7);
  }
   else  {
                                  if (des_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,8);
                                  else
                                      table.setValueAt(DesIPLabel,row,8);

                                 if (des_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,9);
                                  else
                                      table.setValueAt(DesPortLabel,row,9);

                                 if (in_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,10);
                                  else
                                      table.setValueAt(InDeviceLabel,row,10);


                                  if (dnat_Protocal.equals("TCP"))
                                      table.setValueAt(tcpProtocalLabel,row,11);
                                  else
                                      if (dnat_Protocal.equals("UDP"))
                                          table.setValueAt(udpProtocalLabel,row,11);
                                      else
                                          table.setValueAt(icmpProtocalLabel,row,11);

                                   if (dnat_toIP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,12);
                                  else
                                      table.setValueAt(dnat_toIPLabel,row,12);

                                  if (dnat_toPort.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,13);
                                  else
                                      table.setValueAt(dnat_toPortLabel,row,13);
            }
                                   row += 1;

/////////////////////////////////////////////////////////////////// *****
                                   rs.next();
/////////////////////////////////////////////////////////////////// *****
                                  }//while

                                  Id = rs.getString("ID");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  out_Device = rs.getString("des_Device");
                                  snat_Protocal = rs.getString("Protocal");
                                  snat_toIP = rs.getString("tosource");
                                  snat_toPort = rs.getString("toport");

                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  in_Device = rs.getString("src_Device");
                                  dnat_Protocal = rs.getString("Protocal");
                                  dnat_toIP = rs.getString("todes");
                                  dnat_toPort = rs.getString("toport");

                                  JLabel ProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("pTcp.gif")),JLabel.CENTER);

                                  JLabel  SrcIPLabel = new JLabel(src_IP, new ImageIcon( table.getClass().getResource("SourceCom.png")),JLabel.CENTER);
                                  JLabel  DesIPLabel = new JLabel(des_IP, new ImageIcon( table.getClass().getResource("DesCom.png")),JLabel.CENTER);

                                  JLabel  SrcPortLabel = new JLabel(src_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);
                                  JLabel  DesPortLabel = new JLabel(des_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);

                                  JLabel  tcpProtocalLabel = new JLabel(src_Port, new ImageIcon( table.getClass().getResource("pTcp.gif")),JLabel.CENTER);
                                  JLabel   udpProtocalLabel = new JLabel(des_Port, new ImageIcon( table.getClass().getResource("Udp.gif")),JLabel.CENTER);
                                  JLabel   icmpProtocalLabel = new JLabel(des_Port, new ImageIcon( table.getClass().getResource("Icmp.gif")),JLabel.CENTER);


                                 JLabel  OutDeviceLabel = new JLabel(out_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);
                                 JLabel  InDeviceLabel = new JLabel(in_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);

                                 JLabel  AnyLabel = new JLabel("ANY", new ImageIcon( table.getClass().getResource("Any.png")),JLabel.CENTER);

                                   JLabel  snat_toIPLabel = new JLabel(snat_toIP, new ImageIcon( table.getClass().getResource("Computer.png")),JLabel.CENTER);
                                  JLabel   snat_toPortLabel = new JLabel(snat_toPort, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);

                                  JLabel  dnat_toIPLabel = new JLabel(dnat_toIP, new ImageIcon( table.getClass().getResource("Computer.png")),JLabel.CENTER);
                                  JLabel   dnat_toPortLabel = new JLabel(dnat_toPort, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);


                                  table.setValueAt(Id,row,1);

                      if ( (src_IP != null) && (!src_IP.equals(""))) {

                                if (src_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,2);
                                  else
                                      table.setValueAt(SrcIPLabel,row,2);

                                 if (src_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,3);
                                  else
                                      table.setValueAt(SrcPortLabel,row,3);

                                 if (out_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,4);
                                  else
                                      table.setValueAt(OutDeviceLabel,row,4);


                                  if (snat_Protocal.equals("TCP"))
                                      table.setValueAt(tcpProtocalLabel,row,5);
                                  else
                                      if (snat_Protocal.equals("UDP"))
                                          table.setValueAt(udpProtocalLabel,row,5);
                                      else
                                          table.setValueAt(icmpProtocalLabel,row,5);

                                   if (snat_toIP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,6);
                                  else
                                      table.setValueAt(snat_toIPLabel,row,6);

                                  if (snat_toPort.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,7);
                                  else
                                      table.setValueAt(snat_toPort,row,7);
  }
   else  {
                                  if (des_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,8);
                                  else
                                      table.setValueAt(DesIPLabel,row,8);

                                 if (des_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,9);
                                  else
                                      table.setValueAt(DesPortLabel,row,9);

                                 if (in_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,10);
                                  else
                                      table.setValueAt(InDeviceLabel,row,10);


                                  if (dnat_Protocal.equals("TCP"))
                                      table.setValueAt(tcpProtocalLabel,row,11);
                                  else
                                      if (dnat_Protocal.equals("UDP"))
                                          table.setValueAt(udpProtocalLabel,row,11);
                                      else
                                          table.setValueAt(icmpProtocalLabel,row,11);

                                   if (dnat_toIP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,12);
                                  else
                                      table.setValueAt(dnat_toIPLabel,row,12);

                                  if (dnat_toPort.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,13);
                                  else
                                      table.setValueAt(dnat_toPort,row,13);
            }
                  }//try

                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }

                }//if
          }//refresh

     public static void Reset() {
         try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
                  refreshRecordTable();
                 System.out.println("Reset");
    }
    public static void Apply() {

          try {
                  db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

    }

              public void updateSnatRecord() {
              String SQL, field = "";
              String  src_IP = "",value, src_Port = "", out_Device = "", snat_Protocal = "", snat_toIP = "", snat_toPort = "", des_IP = "", des_Port = "", in_Device = "", dnat_Protocal = "", dnat_toIP = "", dnat_toPort = "";
              String stringPK="";
              int ID=0;

        System.out.println("use updateRecord");

    if (status.equals("ADD")) {
    SQL = "INSERT INTO confige" ;

         if (src_ipTextField.getText().trim().length()== 0)
              src_IP = "ANY";
        else
              src_IP = src_ipTextField.getText().trim();

         if (src_portTextField.getText().trim().length()== 0)
              src_Port = "ANY";
        else
              src_Port = src_portTextField.getText().trim();

         if (out_deviceTextField.getText().trim().length() == 0)
              out_Device = "ANY";
         else
              out_Device = out_deviceTextField.getText().trim();


         if (snat_toportTextField.getText().trim().length() == 0)
              snat_toPort = "ANY";
        else
              snat_toPort = snat_toportTextField.getText().trim();


         if (snat_toipTextField.getText().trim().length() == 0)
              snat_toIP = "ANY";
         else
              snat_toIP = snat_toipTextField.getText().trim();


            field = "tablename,Chain,Action, src_IP, src_Port, des_Device, Protocal, tosource, toport ";
            value = " 'nat','PREROUTING','SNAT','" + src_IP + "'  , '" +src_Port+ "' , '" +out_Device+ "' ,'"+protocalNames[snat_protocalComboBox.getSelectedIndex()]+"' , '" +snat_toIP+ "' , '" +snat_toPort+ "'   ";

      SQL = SQL + "(" + field + ") VALUES (" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

                   System.out.println("Test Return Row Select : " + ManagePanel.ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                     }
                         ID = rs.getInt("ID");
                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }


         if (src_ipTextField.getText().trim().length()== 0)
              src_IP = "ANY";
        else
              src_IP = src_ipTextField.getText().trim();

         if (src_portTextField.getText().trim().length() == 0)
              src_Port = "";
        else
              src_Port = src_portTextField.getText().trim();

         if (out_deviceTextField.getText().trim().length() == 0)
              out_Device = "ANY";
         else
              out_Device = out_deviceTextField.getText().trim();

         if (snat_toipTextField.getText().trim().length() == 0)
              snat_toIP = "ANY";
         else
              snat_toIP = snat_toipTextField.getText().trim();

         if (snat_toportTextField.getText().trim().length() == 0)
              snat_toPort = "ANY";
         else
              snat_toPort = snat_toportTextField.getText().trim();




      SQL = "UPDATE " + tableName + " SET ";

      field = field + " src_IP = '"+src_IP+"' , src_Port = '" +src_Port+ "'  , des_Device = '" +out_Device+ "' ,Protocal = '"+protocalNames[dnat_protocalComboBox.getSelectedIndex()]+"', tosource = '"+snat_toIP+"',toport = '"+snat_toPort+"' ";

          stringPK = " ID = "+ID+" ";
          SQL = SQL + field + " WHERE"+stringPK;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }


          refreshRecordTable();


  }
           public void updateDnatRecord() {
              String SQL, field = "";
              String  src_IP = "",value, src_Port = "", out_Device = "", snat_Protocal = "", snat_toIP = "", snat_toPort = "", des_IP = "", des_Port = "", in_Device = "", dnat_Protocal = "", dnat_toIP = "", dnat_toPort = "";
              String stringPK="";
              int ID=0;

        System.out.println("use updateRecord");

    if (status.equals("ADD")) {
    SQL = "INSERT INTO confige" ;

////////////////////////////////

         if (des_ipTextField.getText().trim().length()== 0)
              des_IP = "ANY";
        else
              des_IP = des_ipTextField.getText().trim();

         if (des_portTextField.getText().trim().length()== 0)
              des_Port = "ANY";
        else
              des_Port = des_portTextField.getText().trim();

         if (in_deviceTextField.getText().trim().length() == 0)
              in_Device = "ANY";
         else
              in_Device = in_deviceTextField.getText().trim();

         if (dnat_toipTextField.getText().trim().length() == 0)
              dnat_toIP = "ANY";
         else
              dnat_toIP = dnat_toipTextField.getText().trim();

         if (dnat_toportTextField.getText().trim().length() == 0)
              dnat_toPort = "ANY";
         else
              dnat_toPort = dnat_toportTextField.getText().trim();


            field = "tablename,Chain,Action,des_IP, des_Port, src_Device, Protocal, todes, toport ";
            value = " 'nat','PREROUTING','DNAT','" + des_IP + "'  , '" +des_Port+ "' , '" +in_Device+ "' ,'"+protocalNames[dnat_protocalComboBox.getSelectedIndex()]+"'  , '" +dnat_toIP+ "' , '" +dnat_toPort+ "' ";

      SQL = SQL + "(" + field + ") VALUES (" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

                   System.out.println("Test Return Row Select : " + ManagePanel.ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                     }
                         ID = rs.getInt("ID");
                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }


         if (des_ipTextField.getText().trim().length()== 0)
              des_IP = "ANY";
        else
              des_IP = des_ipTextField.getText().trim();

         if (des_portTextField.getText().trim().length() == 0)
              des_Port = "";
        else
              des_Port = des_portTextField.getText().trim();

         if (in_deviceTextField.getText().trim().length() == 0)
              in_Device = "ANY";
         else
              in_Device = in_deviceTextField.getText().trim().trim();

         if (dnat_toipTextField.getText().trim().length() == 0)
              dnat_toIP = "ANY";
         else
              dnat_toIP = dnat_toipTextField.getText().trim();

        if (dnat_toportTextField.getText().trim().length() == 0)
              dnat_toPort = "ANY";
         else
              dnat_toPort = dnat_toportTextField.getText().trim();




              SQL = "UPDATE " + tableName + " SET ";


       field = field + " des_IP = '"+des_IP+"' , des_Port = '" +des_Port+ "'  , src_Device = '" +in_Device+ "' ,Protocal = '"+protocalNames[dnat_protocalComboBox.getSelectedIndex()]+"', todes = '"+dnat_toIP+"',toport = '"+dnat_toPort+"' ";

          stringPK = " ID = "+ID+" ";
          SQL = SQL + field + " WHERE"+stringPK;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }


          refreshRecordTable();


  }
} //end class