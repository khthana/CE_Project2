import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.sql.*;

public class OptionsPanel extends JPanel {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;
  JPanel bgPanel = new JPanel();
  JPanel jPanel8 = new JPanel();
  JPanel logoPanel = new JPanel();
  JPanel jPanel5 = new JPanel();
  JCheckBox drespbroadCheckBox = new JCheckBox();
  JCheckBox dresppingCheckBox = new JCheckBox();
  JCheckBox drespicmprediCheckBox = new JCheckBox();
  JCheckBox dipspoofCheckBox = new JCheckBox();
  Border border1;
  TitledBorder titledBorder1;
  Border border2;
  TitledBorder titledBorder2;
  Border border3;
  TitledBorder titledBorder3;
  JLabel OptionlogoLabel = new JLabel();
  XYLayout xYLayout3 = new XYLayout();
  XYLayout xYLayout5 = new XYLayout();
  XYLayout xYLayout6 = new XYLayout();
  XYLayout xYLayout7 = new XYLayout();
  XYLayout xYLayout2 = new XYLayout();
  JLabel disablelogoLabel = new JLabel();
  JCheckBox enbaderrorCheckBox = new JCheckBox();
  JCheckBox entcpsynCheckBox = new JCheckBox();
  JCheckBox dsrcroutingCheckBox = new JCheckBox();
  JCheckBox logmarCheckBox = new JCheckBox();
  JButton defaultButton = new JButton(new ImageIcon("images/Edit.png"));
  JButton applyButton = new JButton(new ImageIcon("images/Add.png"));
  XYLayout xYLayout9 = new XYLayout();
  JButton resetButton = new JButton(new ImageIcon("images/Apply.png"));
  JPanel jPanel10 = new JPanel();
  JCheckBox dydropCheckBox = new JCheckBox();

  public OptionsPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {


    OptionlogoLabel.setIcon(new ImageIcon("./Images/Optionsm.gif"));



    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder1 = new TitledBorder(border1,"iptables");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(border2,"Disable");
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder3 = new TitledBorder(border3,"Options");
    bgPanel.setLayout(xYLayout3);
    bgPanel.setBackground(new Color(236, 233, 230));
    bgPanel.setPreferredSize(new Dimension(550, 600));
    jPanel8.setBackground(new Color(236, 233, 230));
    jPanel8.setMaximumSize(new Dimension(500, 500));
    jPanel8.setPreferredSize(new Dimension(271, 50));
    jPanel8.setLayout(xYLayout5);
    jPanel5.setLayout(xYLayout6);
    jPanel5.setPreferredSize(new Dimension(261, 50));
    jPanel5.setBackground(new Color(236, 233, 230));
    jPanel5.setBorder(BorderFactory.createEtchedBorder());
    drespbroadCheckBox.setBackground(new Color(236, 233, 230));
    drespbroadCheckBox.setSelected(true);
    drespbroadCheckBox.setText("Disable response to broadcasts");
    dresppingCheckBox.setBackground(new Color(236, 233, 230));
    dresppingCheckBox.setActionCommand("Disable respone to pings");
    dresppingCheckBox.setText("Disable respone to pings");
    dresppingCheckBox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dresppingCheckBox_actionPerformed(e);
      }
    });
    drespicmprediCheckBox.setBackground(new Color(236, 233, 230));
    drespicmprediCheckBox.setSelected(true);
    drespicmprediCheckBox.setText("Disable ICMP redirect acceptance");
    dipspoofCheckBox.setBackground(new Color(236, 233, 230));
    dipspoofCheckBox.setSelected(true);
    dipspoofCheckBox.setText("Disable IP Spoofing attacks");
    logoPanel.setBackground(new Color(236, 233, 230));
    logoPanel.setBorder(BorderFactory.createEtchedBorder());
    logoPanel.setPreferredSize(new Dimension(51, 40));
    logoPanel.setLayout(xYLayout7);
    this.setBackground(new Color(236, 233, 230));
    this.setBorder(BorderFactory.createEtchedBorder());
    this.setLayout(xYLayout2);
    OptionlogoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    OptionlogoLabel.setHorizontalTextPosition(SwingConstants.CENTER);




 	// Database section
	db = new DBUtil();
	con = db.Establish();
    xYLayout2.setWidth(500);
    xYLayout2.setHeight(430);
    disablelogoLabel.setIcon(new ImageIcon("./Images/Disable.png"));
    disablelogoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    disablelogoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    enbaderrorCheckBox.setBackground(new Color(236, 233, 230));
    enbaderrorCheckBox.setSelected(true);
    enbaderrorCheckBox.setText("Enable bad error message protection");
    entcpsynCheckBox.setBackground(new Color(236, 233, 230));
    entcpsynCheckBox.setSelected(true);
    entcpsynCheckBox.setText("Enable TCP SYN cookies");
    dsrcroutingCheckBox.setBackground(new Color(236, 233, 230));
    dsrcroutingCheckBox.setSelected(true);
    dsrcroutingCheckBox.setText("Disable source routing");
    logmarCheckBox.setBackground(new Color(236, 233, 230));
    logmarCheckBox.setSelected(true);
    logmarCheckBox.setText("Log martians (packets with impossible addresses)");
    defaultButton.addActionListener(new clickedDefault());
    defaultButton.setText("Default");
    defaultButton.setHorizontalTextPosition(SwingConstants.LEFT);
    defaultButton.setBorder(BorderFactory.createEtchedBorder());
    defaultButton.setBackground(new Color(236, 233, 230));
    applyButton.addActionListener(new clickedApply());
    applyButton.setText("Apply");
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setBackground(new Color(236, 233, 230));
    resetButton.addActionListener(new clickedReset());
    resetButton.setText("Reset");
    resetButton.setHorizontalTextPosition(SwingConstants.LEFT);
    resetButton.setBorder(BorderFactory.createEtchedBorder());
    resetButton.setBackground(new Color(236, 233, 230));
    jPanel10.setBackground(new Color(236, 233, 230));
    jPanel10.setLayout(xYLayout9);
    dydropCheckBox.setText("Dynamic Drop (source which sent unclean packet)");
    dydropCheckBox.setBackground(new Color(236, 233, 230));
    logoPanel.add(OptionlogoLabel, new XYConstraints(132, 2, 227, 62));
    logoPanel.add(disablelogoLabel,  new XYConstraints(101, 17, 36, 30));
    bgPanel.add(jPanel8,                new XYConstraints(5, 106, 492, 288));
    jPanel8.add(jPanel5,               new XYConstraints(2, 0, 483, 285));
    this.add(bgPanel,              new XYConstraints(-1, 0, 502, 412));
    jPanel5.add(drespbroadCheckBox,    new XYConstraints(115, 5, 207, -1));
    jPanel5.add(dresppingCheckBox,     new XYConstraints(115, 30, 165, -1));
    jPanel5.add(drespicmprediCheckBox,    new XYConstraints(115, 55, 212, -1));
    jPanel5.add(enbaderrorCheckBox,   new XYConstraints(115, 80, 234, 21));
    jPanel5.add(dipspoofCheckBox,    new XYConstraints(115, 105, 184, -1));
    jPanel5.add(jPanel10,   new XYConstraints(110, 231, 258, 46));
    jPanel10.add(applyButton, new XYConstraints(8, 6, 78, 32));
    jPanel10.add(resetButton, new XYConstraints(88, 6, 79, 31));
    jPanel10.add(defaultButton, new XYConstraints(169, 6, 79, 31));
    jPanel5.add(entcpsynCheckBox,   new XYConstraints(115, 130, 175, 21));
    jPanel5.add(dsrcroutingCheckBox,     new XYConstraints(115, 155, 168, 20));
    jPanel5.add(logmarCheckBox,   new XYConstraints(115, 180, 313, 21));
    jPanel5.add(dydropCheckBox,     new XYConstraints(115, 205, 313, 21));
    bgPanel.add(logoPanel,    new XYConstraints(5, 24, 484, 70));

    loadPreviousCheck();

  }//end jbinit();

   void loadPreviousCheck() {
        String SQL="",drespping="",drespbroad="",drespicmpredi="",enbaderror="",dipspoof="",entcpsyn="",dsrcrouting="",logmar="",dydrop = "";
        String field="",value="";

              SQL = "SELECT * FROM options WHERE ID = 1" ;
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

   try {
              rs.first();
              drespping = rs.getString("drespping");
              drespbroad = rs.getString("drespbroad");
              drespicmpredi = rs.getString("drespicmpredi");
              enbaderror = rs.getString("enbaderror");
              dipspoof  = rs.getString("dipspoof");
              entcpsyn  = rs.getString("entcpsyn");
              dsrcrouting = rs.getString("dsrcrouting");
              logmar = rs.getString("logmar");
              dydrop = rs.getString("dydrop");
       }
   catch(SQLException ex){ System.out.println(ex);
        System.out.println("ERROR");
   }

        if (drespping.equals("/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_echo_ignore_all"))
              dresppingCheckBox.setSelected(true);
        else
              dresppingCheckBox.setSelected(false);

        if (drespbroad.equals("/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts"))
            drespbroadCheckBox.setSelected(true);
        else
            drespbroadCheckBox.setSelected(false);

       if (drespicmpredi.equals("/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_redirects"))
           drespicmprediCheckBox.setSelected(true);
        else
           drespicmprediCheckBox.setSelected(false);

       if (enbaderror.equals("/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses"))
            enbaderrorCheckBox.setSelected(true);
       else
            enbaderrorCheckBox.setSelected(false);

       if (dipspoof.equals("/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/rp_filter"))
            dipspoofCheckBox.setSelected(true);
       else
            dipspoofCheckBox.setSelected(false);

       if  (entcpsyn.equals("/bin/echo \"1\" > /proc/sys/net/ipv4/tcp_syncookies"))
            entcpsynCheckBox.setSelected(true);
       else
            entcpsynCheckBox.setSelected(false);

       if (dsrcrouting.equals("/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_source_route"))
            dsrcroutingCheckBox.setSelected(true);
       else
            dsrcroutingCheckBox.setSelected(false);

       if (logmar.equals("/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/log_martians"))
            logmarCheckBox.setSelected(true);
       else
            logmarCheckBox.setSelected(false);

    if(dydrop.equals(""))
      dydropCheckBox.setSelected(false);
    else
      dydropCheckBox.setSelected(true);
  }
  public static void Reset() {
         try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

                 System.out.println("Reset OptionsPanel");
    }

    public static void Apply() {
         try {
                  db.con.commit();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
                 System.out.println("Apply OptionsPanel");
    }

  class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        String SQL="",drespping="",drespbroad="",drespicmpredi="",enbaderror="",dipspoof="",entcpsyn="",dsrcrouting="",logmar="", dydrop = "";
        String field="",value="";

        if (dresppingCheckBox.isSelected())
            drespping = "/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_echo_ignore_all";
        else
            drespping = "/bin/echo \"0\" > /proc/sys/net/ipv4/icmp_echo_ignore_all";

        if (drespbroadCheckBox.isSelected())
            drespbroad = "/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts";
        else
            drespbroad = "/bin/echo \"0\" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts";

       if (drespicmprediCheckBox.isSelected())
           drespicmpredi = "/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_redirects";
        else
           drespicmpredi = "/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/accept_redirects";

       if (enbaderrorCheckBox.isSelected())
            enbaderror = "/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses";
       else
            enbaderror = "/bin/echo \"0\" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses";

       if (dipspoofCheckBox.isSelected())
            dipspoof = "/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/rp_filter";
       else
            dipspoof = "/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/rp_filter";

       if  (entcpsynCheckBox.isSelected())
            entcpsyn = "/bin/echo \"1\" > /proc/sys/net/ipv4/tcp_syncookies";
       else
            entcpsyn = "/bin/echo \"0\" > /proc/sys/net/ipv4/tcp_syncookies";

       if (dsrcroutingCheckBox.isSelected())
            dsrcrouting = "/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_source_route";
       else
            dsrcrouting = "/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/accept_source_route";

       if (logmarCheckBox.isSelected())
            logmar = "/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/log_martians";
       else
            logmar = "/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/log_martians";

  if(dydropCheckBox.isSelected())
    dydrop = "iptables -A INPUT -m unclean -m limit --limit 1/second -j LOG --log-prefix \"DY-DROP: \"\niptables -A INPUT -m unclean -j DROP\n" +
              "iptables -A FORWARD -m unclean -m limit --limit 1/second -j LOG --log-prefix \"DY-DROP: \"\niptables -A FORWARD -m unclean -j DROP";
  else  dydrop = "";


  value =" drespping ='"+drespping+"' ,drespbroad='"+drespbroad+"',drespicmpredi='"+drespicmpredi+"',enbaderror='"+enbaderror+"',dipspoof='"+dipspoof+"',entcpsyn='"+entcpsyn+"',dsrcrouting='"+dsrcrouting+"',logmar='"+logmar+"',dydrop='"+dydrop+"'";
  SQL = "UPDATE options SET" +value+ " WHERE Id = 1";
      System.out.println(SQL);
      db.SQLExecute(SQL);
      Apply();

    }
  }

  class clickedReset implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
              }
                 System.out.println("Reset OptionsPanel");

        loadPreviousCheck();
    }
  }
  class clickedDefault implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        dresppingCheckBox.setSelected(false);
        drespbroadCheckBox.setSelected(true);
        drespicmprediCheckBox.setSelected(true);
        enbaderrorCheckBox.setSelected(true);
        dipspoofCheckBox.setSelected(true);
        entcpsynCheckBox.setSelected(true);
        dsrcroutingCheckBox.setSelected(true);
        logmarCheckBox.setSelected(true);
        dydropCheckBox.setSelected(false);
    }
  }

  void dresppingCheckBox_actionPerformed(ActionEvent e) {

  }


}//end class


