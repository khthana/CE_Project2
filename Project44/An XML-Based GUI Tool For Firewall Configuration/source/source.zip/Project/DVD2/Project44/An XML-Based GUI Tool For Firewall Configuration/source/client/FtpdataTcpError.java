import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import java.awt.image.*;

public class FtpdataTcpError extends JFrame {
  JPanel panel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  public static JLabel src_deviceLabel = new JLabel();
  public static JLabel src_portLabel = new JLabel();
  public static JLabel des_ipLabel = new JLabel();
  public static JLabel des_portLabel = new JLabel();
  public static JLabel src_ipLabel = new JLabel();
  public static JLabel des_deviceLabel = new JLabel();
  public static JLabel csrc_ipLabel = new JLabel();
  public static JLabel csrc_portLabel = new JLabel();
  public static JLabel csrc_deviceLabel = new JLabel();
  public static JLabel cdes_ipLabel = new JLabel();
  public static JLabel cdes_portLabel = new JLabel();
  public static JLabel cdes_deviceLabel = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JButton closeButton = new JButton(new ImageIcon("images/ExitDoor.gif"));
  JLabel cannaddLabel = new JLabel();
  JLabel stopLabel = new JLabel();

  public FtpdataTcpError() {
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {

    this.setSize(new Dimension(375, 389));

   Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    panel1.setLayout(borderLayout1);
    jPanel1.setLayout(xYLayout1);
    jPanel2.setLayout(xYLayout2);
    src_deviceLabel.setBackground(new Color(236, 233, 230));
    src_deviceLabel.setHorizontalAlignment(SwingConstants.LEFT);
    src_deviceLabel.setHorizontalTextPosition(SwingConstants.LEFT);

    src_portLabel.setBackground(new Color(236, 233, 230));
    src_portLabel.setHorizontalAlignment(SwingConstants.LEFT);
    src_portLabel.setHorizontalTextPosition(SwingConstants.LEFT);

    des_ipLabel.setBackground(new Color(236, 233, 230));
    des_ipLabel.setHorizontalAlignment(SwingConstants.LEFT);
    des_ipLabel.setHorizontalTextPosition(SwingConstants.LEFT);

    des_portLabel.setBackground(new Color(236, 233, 230));
    des_portLabel.setHorizontalAlignment(SwingConstants.LEFT);
    des_portLabel.setHorizontalTextPosition(SwingConstants.LEFT);

    src_ipLabel.setBackground(new Color(236, 233, 230));
    src_ipLabel.setHorizontalAlignment(SwingConstants.LEFT);
    src_ipLabel.setHorizontalTextPosition(SwingConstants.LEFT);

    des_deviceLabel.setBackground(new Color(236, 233, 230));
    des_deviceLabel.setHorizontalAlignment(SwingConstants.LEFT);
    des_deviceLabel.setHorizontalTextPosition(SwingConstants.LEFT);

    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());


    csrc_ipLabel.setBackground(new Color(236, 233, 230));
    csrc_ipLabel.setHorizontalAlignment(SwingConstants.CENTER);
    csrc_ipLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    csrc_portLabel.setBackground(new Color(236, 233, 230));
    csrc_portLabel.setHorizontalAlignment(SwingConstants.CENTER);
    csrc_portLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    csrc_deviceLabel.setBackground(new Color(236, 233, 230));
    csrc_deviceLabel.setHorizontalAlignment(SwingConstants.CENTER);
    csrc_deviceLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    cdes_ipLabel.setBackground(new Color(236, 233, 230));
    cdes_ipLabel.setHorizontalAlignment(SwingConstants.CENTER);
    cdes_ipLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    cdes_portLabel.setBackground(new Color(236, 233, 230));
    cdes_portLabel.setHorizontalAlignment(SwingConstants.CENTER);
    cdes_portLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    cdes_deviceLabel.setBackground(new Color(236, 233, 230));
    cdes_deviceLabel.setHorizontalAlignment(SwingConstants.CENTER);
    cdes_deviceLabel.setHorizontalTextPosition(SwingConstants.CENTER);

    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel1.setPreferredSize(new Dimension(371, 378));
    jLabel1.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel1.setText("Source IP");
    jLabel2.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel2.setText("Source Port");
    jLabel3.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel3.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel3.setText("Source Device");
    jLabel4.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel4.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel4.setText("Destination IP");
    jLabel5.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel5.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel5.setText("Destination Port");
    jLabel6.setHorizontalAlignment(SwingConstants.LEFT);
    jLabel6.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel6.setText("Destination Device");
    closeButton.setBackground(new Color(236, 233, 230));
    closeButton.setBorder(BorderFactory.createEtchedBorder());
    closeButton.setActionCommand("Ok");
    closeButton.setHorizontalTextPosition(SwingConstants.LEFT);
    closeButton.setText("Close");


    cannaddLabel.setHorizontalAlignment(SwingConstants.CENTER);
    cannaddLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    stopLabel.setHorizontalAlignment(SwingConstants.CENTER);
    stopLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    getContentPane().add(panel1);
    panel1.add(jPanel1, BorderLayout.CENTER);
    jPanel2.add(cdes_ipLabel, new XYConstraints(15, 138, 59, 33));
    jPanel2.add(csrc_deviceLabel,  new XYConstraints(15, 97, 60, 32));
    jPanel2.add(csrc_portLabel,   new XYConstraints(15, 58, 58, 32));
    jPanel2.add(cdes_portLabel,   new XYConstraints(15, 179, 59, 31));
    jPanel2.add(cdes_deviceLabel, new XYConstraints(15, 220, 62, 34));
    jPanel2.add(csrc_ipLabel, new XYConstraints(15, 17, 58, 36));
    jPanel2.add(jLabel1,        new XYConstraints(90, 22, 66, 25));
    jPanel2.add(jLabel3,  new XYConstraints(90, 97, 94, 29));
    jPanel2.add(jLabel5,  new XYConstraints(90, 179, 103, 25));
    jPanel2.add(src_portLabel,     new XYConstraints(210, 60, 137, 26));
    jPanel2.add(des_portLabel,  new XYConstraints(210, 175, 122, 31));
    jPanel2.add(jLabel4,  new XYConstraints(90, 138, 86, 28));
    jPanel2.add(jLabel6,   new XYConstraints(90, 223, 129, 24));
    jPanel2.add(src_ipLabel,   new XYConstraints(210, 22, 122, 31));
    jPanel2.add(des_ipLabel,  new XYConstraints(210, 137, 112, 30));
    jPanel2.add(des_deviceLabel,  new XYConstraints(210, 220, 96, 29));
    jPanel2.add(jLabel2,   new XYConstraints(90, 60, 72, 23));
    jPanel2.add(src_deviceLabel,  new XYConstraints(210, 100, 102, 25));
    jPanel1.add(closeButton, new XYConstraints(138, 341, 79, 31));
    jPanel1.add(jPanel2,    new XYConstraints(2, 66, 365, 267));
    jPanel1.add(stopLabel,    new XYConstraints(15, 17, 58, 36));
    jPanel1.add(cannaddLabel,    new XYConstraints(81, 14, 223, 45));

    csrc_ipLabel.setIcon(new ImageIcon("./Images/Ok.png"));
    csrc_portLabel.setIcon(new ImageIcon("./Images/Ok.png"));
    csrc_deviceLabel.setIcon(new ImageIcon("./Images/Ok.png"));
    cdes_ipLabel.setIcon(new ImageIcon("./Images/Ok.png"));
    cdes_portLabel.setIcon(new ImageIcon("./Images/Ok.png"));
    cdes_deviceLabel.setIcon(new ImageIcon("./Images/Ok.png"));
    stopLabel.setIcon(new ImageIcon("./Images/Stop.png"));
    cannaddLabel.setIcon(new ImageIcon("./Images/CannAdd.gif"));

    src_ipLabel.setForeground(new Color(102,102,153));
    src_portLabel.setForeground(new Color(102,102,153));
    src_deviceLabel.setForeground(new Color(102,102,153));
    des_ipLabel.setForeground(new Color(102,102,153));
    des_portLabel.setForeground(new Color(102,102,153));
    des_deviceLabel.setForeground(new Color(102,102,153));

    this.setVisible(true);

    if (FtpdataTcp.src_ipTextField.getText().trim().equals(""))
         src_ipLabel.setText("ANY");
    else
        src_ipLabel.setText(FtpdataTcp.src_ipTextField.getText().trim());

    if (FtpdataTcp.src_portTextField.getText().trim().equals(""))
         src_portLabel.setText("ANY");
    else
        src_portLabel.setText(FtpdataTcp.src_portTextField.getText());

    if (FtpdataTcp.src_deviceTextField.getText().trim().equals(""))
         src_deviceLabel.setText("ANY");
    else
        src_deviceLabel.setText(FtpdataTcp.src_deviceTextField.getText().trim());

    if (FtpdataTcp.des_ipTextField.getText().trim().equals(""))
         des_ipLabel.setText("ANY");
    else
         des_ipLabel.setText(FtpdataTcp.des_ipTextField.getText().trim());

    if (FtpdataTcp.des_portTextField.getText().trim().equals(""))
         des_portLabel.setText("ANY");
    else
         des_portLabel.setText(FtpdataTcp.des_portTextField.getText().trim());

    if (FtpdataTcp.des_deviceTextField.getText().trim().equals(""))
         des_deviceLabel.setText("ANY");
    else
         des_deviceLabel.setText(FtpdataTcp.des_deviceTextField.getText().trim());

         closeButton.addActionListener(new clickedClose());

    if(FtpdataTcp.src_ipError){
         System.out.println("UpdatePanel.src_ipError");
         csrc_ipLabel.setIcon(new ImageIcon("./Images/Error.png"));
         src_ipLabel.setForeground(Color.red);
    }
    if(FtpdataTcp.src_portError){
         System.out.println("UpdatePanel.src_portError");
         csrc_portLabel.setIcon(new ImageIcon("./Images/Error.png"));
         src_portLabel.setForeground(Color.red);
    }

    if(FtpdataTcp.src_deviceError){
         System.out.println("UpdatePanel.src_deviceError");
         csrc_deviceLabel.setIcon(new ImageIcon("./Images/Error.png"));
         src_deviceLabel.setForeground(Color.red);
    }

    if(FtpdataTcp.des_ipError){
         System.out.println("UpdatePanel.des_ipError");
         cdes_ipLabel.setIcon(new ImageIcon("./Images/Error.png"));
         des_ipLabel.setForeground(Color.red);
    }

    if(FtpdataTcp.des_portError){
         System.out.println("UpdatePanel.des_portError");
         cdes_portLabel.setIcon(new ImageIcon("./Images/Error.png"));
         des_portLabel.setForeground(Color.red);
    }

    if(FtpdataTcp.des_deviceError){
         System.out.println("UpdatePanel.des_deviceError");
         cdes_deviceLabel.setIcon(new ImageIcon("./Images/Error.png"));
         des_deviceLabel.setForeground(Color.red);
    }

    ImageIcon icon = new ImageIcon(("images/Caution.gif"));
    this.setIconImage(icon.getImage());

    this.setTitle("This Rule Has Error, Please Check Rule !!");

  }//end jbinit()

    class clickedClose implements ActionListener  {
       public void actionPerformed(ActionEvent e){
            dispose();
            hide();
     }
    }

}//end class