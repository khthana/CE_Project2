import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class TextEdit extends JPanel {
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel textEditPanel = new JPanel();
  TextEditPanel textedit = new TextEditPanel();
//  SimpleTextEditFrame frame    = new SimpleTextEditFrame();
  XYLayout xYLayout2 = new XYLayout();
  XYLayout xYLayout3 = new XYLayout();

  public TextEdit() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

    this.setLayout(xYLayout2);
    jPanel1.setLayout(xYLayout1);
    textEditPanel.setLayout(xYLayout3);
    xYLayout2.setWidth(613);
    xYLayout2.setHeight(414);
    this.setBackground(new Color(236, 233, 230));
    jPanel1.setBackground(new Color(236, 233, 230));
    textEditPanel.setBackground(new Color(236, 233, 230));
    this.add(jPanel1,                       new XYConstraints(1, 5, 609, 403));
    jPanel1.add(textEditPanel,                     new XYConstraints(0, 0, 608, 640));
    textEditPanel.add(textedit,            new XYConstraints(-3, 0, 689, 408));
  }
}