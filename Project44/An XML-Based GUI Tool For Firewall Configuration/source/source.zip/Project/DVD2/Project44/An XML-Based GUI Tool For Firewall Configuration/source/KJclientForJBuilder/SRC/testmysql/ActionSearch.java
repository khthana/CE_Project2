//package main;
package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.border.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import javax.swing.JTable.*;
import javax.swing.table.*;
import com.borland.jbcl.layout.*;

public class ActionSearch extends JPanel {
 // JScrollPane scrollPane = new JScrollPane(table);

  public static ResultSet rs;
  public static Connection con;
  public static DBUtil db;

  String url, user, password, retriveSQL, tableName;

  public static String ChainOldValue, src_IPOldValue, src_PortOldValue,  src_DeviceOldValue, des_IPOldValue,  des_PortOldValue,  des_DeviceOldValue;
  public static String  ProtocalOldValue,ActionOldValue,  notSrcIPOldValue , notSrcPortOldValue, notSrcDeviceOldValue, notDesIPOldValue, notDesPortOldValue,  notDesDeviceOldValue;

  public static boolean seteditActionSearch = false ;
  public static int ReturnRowSelect;
  public static boolean clickedEdit;
  public static boolean setStatusNew;
  public static boolean setStatusUpdate;
  boolean statusChange = false;
  public static boolean backSearch=false;

  String actionNames[] = {"ACCEPT","DROP","REJECT"};
    ListSearchModel listModel;
  public static JTable table;

  JPanel jPanel9 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JButton searchButton = new JButton(new ImageIcon("images/SearchButton.png"));
  JPanel jPanel3 = new JPanel();

  JPanel jPanel2 = new JPanel();
  JPanel jPanel1 = new JPanel();
  JPanel tablePanel = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  BorderLayout borderLayout1 = new BorderLayout();
  JComboBox actionComboBox = new JComboBox(actionNames);
  BorderLayout borderLayout3 = new BorderLayout();
  TitledBorder titledBorder1;
  Border border1;
  TitledBorder titledBorder2;
  Border border2;
  Border border3;
  JPanel jPanel8 = new JPanel();
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  XYLayout xYLayout9 = new XYLayout();
  JButton addButton = new JButton(new ImageIcon("images/Add.png"));
  JButton deleteButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JPanel jPanel10 = new JPanel();
  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  XYLayout xYLayout1 = new XYLayout();
  JButton resetButton = new JButton(new ImageIcon("images/Reset.png"));

  public ActionSearch() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {

    url ="jdbc:odbc:dbConfige";
    user="admin";
    password="";
    tableName="Confige";
    retriveSQL="SELECT * FROM Confige";

   JPanel tablePane = new JPanel();
   listModel = new ListSearchModel();
   table = new JTable(listModel);
  /*  table = new JTable(listModel)
			{
				public Component prepareRenderer(TableCellRenderer renderer, int row, int column)
				{
					Component c = super.prepareRenderer( renderer, row, column);
					// We want renderer component to be transparent so background image is visible
					if( c instanceof JComponent )
						((JComponent)c).setOpaque(false);
					return c;
				}

				// Hard coded value. In your sub-class add a function for this.
				ImageIcon image = new ImageIcon( "C2.gif" );

				public void paint( Graphics g )
				{
					// First draw the background image - tiled
					Dimension d = getSize();
					for( int x = 0; x < d.width; x += image.getIconWidth() )
						for( int y = 0; y < d.height; y += image.getIconHeight() )
							g.drawImage( image.getImage(), x, y, null, null );
					// Now let the regular paint code do it's work
					super.paint(g);
				}

			};
     m,                   //////////////////

*/

   table.setOpaque(false);
  JScrollPane scrollPane = new JScrollPane(table);
  //table.setAutoResizeMode(3);
   table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
   titledBorder1 = new TitledBorder("");
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder("");
    border2 = BorderFactory.createBevelBorder(BevelBorder.LOWERED,Color.white,Color.white,new Color(142, 142, 142),new Color(99, 99, 99));
    border3 = BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.lightGray,Color.white,new Color(142, 142, 142),new Color(99, 99, 99));
    table.setPreferredScrollableViewportSize(new Dimension(500,300));
    tablePanel.setBackground(new Color(236, 233, 230));
    tablePanel.setBorder(border1);
    tablePanel.setPreferredSize(new Dimension(410, 270));
    scrollPane.setViewportBorder(border1);
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setAutoscrolls(true);
    scrollPane.setBorder(null);
    scrollPane.setPreferredSize(new Dimension(504, 255));
    jPanel2.setPreferredSize(new Dimension(530, 364));
    actionComboBox.setBackground(new Color(236, 233, 230));
    actionComboBox.setPreferredSize(new Dimension(120, 25));
    searchButton.setBackground(new Color(236, 233, 230));
    searchButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    searchButton.setPreferredSize(new Dimension(110, 27));
    searchButton.setHorizontalTextPosition(SwingConstants.LEFT);
    jPanel6.setBackground(new Color(236, 233, 230));
    jPanel6.setPreferredSize(new Dimension(250, 37));
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setLayout(xYLayout1);
    jPanel4.setBackground(new Color(236, 233, 230));
    this.setBackground(new Color(236, 233, 230));
    jPanel8.setBackground(new Color(236, 233, 230));
    jPanel8.setPreferredSize(new Dimension(10, 20));
    //addButton.addActionListener(new clickedOk());
    //resetButton.addActionListener(new clickedExit());
    applyButton.addActionListener(new clickedApply());
    applyButton.setText("Aplly");
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setBackground(new Color(236, 233, 230));
    addButton.addActionListener(new clickedAdd());
    addButton.setText("Add");
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setBorder(BorderFactory.createEtchedBorder());
    addButton.setBackground(new Color(236, 233, 230));
    deleteButton.addActionListener(new clickedDelete());
    deleteButton.setText("Delete");
    deleteButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deleteButton.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setBackground(new Color(236, 233, 230));
    jPanel10.setBorder(BorderFactory.createEtchedBorder());
    jPanel10.setBackground(new Color(236, 233, 230));
    jPanel10.setLayout(xYLayout9);
    editButton.setBackground(new Color(236, 233, 230));
    editButton.setBorder(BorderFactory.createEtchedBorder());
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    editButton.setText("Edit");
    editButton.addActionListener(new clickedEdit());
    resetButton.setBackground(new Color(236, 233, 230));
    resetButton.setBorder(BorderFactory.createEtchedBorder());
    resetButton.setHorizontalTextPosition(SwingConstants.LEFT);
    resetButton.setText("Reset");
    resetButton.addActionListener(new clickedReset());
    tablePane.add(scrollPane);

//  setBorder(new EmptyBorder(5,5,5,5));
    jPanel7.setLayout(gridLayout1);
    searchButton.setText("Search");
    jPanel2.setLayout(borderLayout2);
    jPanel1.setLayout(borderLayout1);
    jPanel9.setLayout(borderLayout3);
    this.add(jPanel9, null);
    jPanel9.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(tablePanel, BorderLayout.CENTER);
    tablePanel.add(scrollPane);
    jPanel10.add(addButton, new XYConstraints(18, 5, 78, 32));
    jPanel10.add(editButton, new XYConstraints(98, 5, 80, 31));
    jPanel10.add(resetButton,  new XYConstraints(429, 5, 79, 30));
    jPanel10.add(applyButton, new XYConstraints(348, 5, 79, 30));
    jPanel10.add(deleteButton, new XYConstraints(180, 5, 79, 31));
    jPanel2.add(jPanel6, BorderLayout.NORTH);

    //tablePanel.add(scrollPane);
    jPanel6.add(actionComboBox, null);
    jPanel6.add(jPanel7, null);
    jPanel6.add(searchButton, null);
    jPanel2.add(jPanel4, BorderLayout.SOUTH);
    jPanel4.add(jPanel3, null);
    jPanel3.add(jPanel10,             new XYConstraints(2, 4, 530, 45));
    jPanel9.add(jPanel8, BorderLayout.NORTH);

   // table.columnSelectionChanged(new clickedChainColumn());
//    table.columnSelectionChanged();
      //table.addMouseListener(new clickedChainColumn111());

      //table.addMouseListener(new clickedChainColumn111());

	// Database section
	db = new DBUtil();
	con = db.Establish();

   searchButton.addActionListener(new clickedSearch());

  }//end jbinit

    class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {

       ChainOldValue="";src_IPOldValue=""; src_PortOldValue=""  ;
       src_DeviceOldValue=""; des_IPOldValue="";  des_PortOldValue="";
       des_DeviceOldValue="";ProtocalOldValue="";ActionOldValue="";
       notSrcIPOldValue="";notSrcPortOldValue=""; notSrcDeviceOldValue="";
       notDesIPOldValue=""; notDesPortOldValue="";  notDesDeviceOldValue="";

              statusChange = true;
              SearchUpdatePanel.status = "ADD";

              SearchUpdatePanel.updatelogoLabel.setIcon(new ImageIcon("./Images/AddRule.gif"));


              SearchUpdatePanel.notsrcipCheckBox.setSelected(false);
              SearchUpdatePanel.notsrcportCheckBox.setSelected(false);
              SearchUpdatePanel.notsrcdeviceCheckBox.setSelected(false);
              SearchUpdatePanel.notdesipCheckBox.setSelected(false);
              SearchUpdatePanel.notdesportCheckBox.setSelected(false);
              SearchUpdatePanel.notdesdeviceCheckBox.setSelected(false);

              SearchUpdatePanel.src_ipTextField.setText("");
              SearchUpdatePanel.src_portTextField.setText("");
              SearchUpdatePanel.src_deviceTextField.setText("");
              SearchUpdatePanel.des_ipTextField.setText("");
              SearchUpdatePanel.des_portTextField.setText("");
              SearchUpdatePanel.des_deviceTextField.setText("");

              Frame2.tabbedPaneSearch.setSelectedIndex(5);
              backSearch = true;
      }
    }

      class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       statusChange = true;
       clickedEdit = true;
       setStatusUpdate = true;
       String stmp="";
       int tmp;
       ReturnRowSelect=table.getSelectedRow();
       System.out.println(stmp.valueOf(ReturnRowSelect));
       Frame2.tabbedPaneSearch.setSelectedIndex(5);
       setEdit();
      }
    }

  public  void setEdit() {
               String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
               String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice,notprotocol;

                   SearchUpdatePanel.status = "UPDATE";
                   SearchUpdatePanel.updatelogoLabel.setIcon(new ImageIcon("./Images/EditRule.gif"));

                   try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                    }
                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");


                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  notprotocol = rs.getString("notprotocal");

                                  ChainOldValue = Chain;
                                  src_IPOldValue = src_IP;
                                  src_PortOldValue= src_Port;
                                  src_DeviceOldValue = src_Device;
                                  des_IPOldValue = des_IP;
                                  des_PortOldValue = des_Port;
                                  des_DeviceOldValue = des_Device;
                                  ProtocalOldValue = Protocal;
                                  ActionOldValue = Action;

                                  notSrcIPOldValue = notSrcIP;
                                  notSrcPortOldValue = notSrcPort;
                                  notSrcDeviceOldValue = notSrcDevice;
                                  notDesIPOldValue = notDesIP;
                                  notDesPortOldValue = notDesPort;
                                  notDesDeviceOldValue = notDesDevice;


                                  if (notSrcIP.equals("NO"))
                                        SearchUpdatePanel.notsrcipCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notsrcipCheckBox.setSelected(false);
                                  if (notSrcPort.equals("NO"))
                                        SearchUpdatePanel.notsrcportCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notsrcportCheckBox.setSelected(false);
                                  if (notSrcDevice.equals("NO"))
                                        SearchUpdatePanel.notsrcdeviceCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notsrcdeviceCheckBox.setSelected(false);

                                  if (notDesIP.equals("NO"))
                                        SearchUpdatePanel.notdesipCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notdesipCheckBox.setSelected(false);
                                  if (notDesPort.equals("NO"))
                                        SearchUpdatePanel.notdesportCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notdesportCheckBox.setSelected(false);
                                  if (notDesDevice.equals("NO"))
                                        SearchUpdatePanel.notdesdeviceCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notdesdeviceCheckBox.setSelected(false);

                                  if(notprotocol.equals("NO"))
                                        SearchUpdatePanel.notprotocolCheckBox.setSelected(true);
                                  else
                                        SearchUpdatePanel.notprotocolCheckBox.setSelected(false);

                                  SearchUpdatePanel.chainComboBox.setSelectedItem(Chain);
                                  SearchUpdatePanel.protocalComboBox.setSelectedItem(Protocal);
                                  SearchUpdatePanel.actionComboBox.setSelectedItem(Action);


                                  SearchUpdatePanel.src_ipTextField.setText(src_IP);
                                  SearchUpdatePanel.src_portTextField.setText(src_Port);
                                  SearchUpdatePanel.src_deviceTextField.setText(src_Device);
                                  SearchUpdatePanel.des_ipTextField.setText(des_IP);
                                  SearchUpdatePanel.des_portTextField.setText(des_Port);
                                  SearchUpdatePanel.des_deviceTextField.setText(des_Device);

                                  seteditActionSearch = true;


                  }
                                  catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }
  }//end setEdit

      public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }

    class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
            Apply();
      }
    }


class clickedReset implements ActionListener {
      public void actionPerformed(ActionEvent e) {

            try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

                  refreshRecordTable();
                 System.out.println("Reset");
      }
    }

        class clickedSearch implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                  SearchRecord();
            }
          }

      //class clickedChainColumn111 implements MouseListener {
            public void mouseExited(MouseEvent e) {
                  String SQL="";
                  SQL ="SELECT * FROM Config ORDER BY Action";
                  System.out.println(SQL);
                  db.SQLExecute(SQL);
                  refreshRecordTable();
           }
  //      }



     public void SearchRecord() {
                 String SQL="";
              //    SQL =  "SELECT * FROM Confige Where Chain =   '"+chainNames[chainComboBox.getSelectedIndex()]+ "'  " ;
                  System.out.println(SQL);
                 // db.SQLExecute(SQL);
                  refreshRecordTable();
    }

     class clickedDelete implements ActionListener {
                        public void actionPerformed(ActionEvent e) {
                                int Id;
                                String SQL="",Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;

                                       ReturnRowSelect=table.getSelectedRow();
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getInt("ID");
                                    Chain = rs.getString("Chain");
                                    src_IP = rs.getString("src_IP");
                                    src_Port = rs.getString("src_Port");
                                    src_Device = rs.getString("src_Device");
                                    des_IP = rs.getString("des_IP");
                                    des_Port = rs.getString("des_Port");
                                    des_Device = rs.getString("des_Device");
                                    Protocal = rs.getString("Protocal");
                                    Action = rs.getString("Action");

                                        	// Get previous or next for bookmark
		//boolean combineKey = false;
		// Make SQL
		SQL = "DELETE FROM " + tableName + " WHERE ";

                                                            SQL = SQL +  "ID =  "+Id+" ";//+"    AND Chain =  '" +Chain+ "'   AND src_IP =  '"+src_IP+"' "+
                                                                                 //   " AND src_Port =  '"+src_Port+"'   AND src_Device =   '"+src_Device+"'  " +
                                                                                   // " AND des_IP =  '"+des_IP+"'   AND des_Port =  '"+src_Port+"'   AND des_Device =  '"+des_Device+"'  "+
                                                                                   // " AND Protocal =  '"+Protocal+"'   AND Action =  '"+Action+"' ";

		db.SQLExecute(SQL);
		System.out.println(SQL);

                                      }

                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                listModel.clearData();
                                refreshRecordTable();

                                }
                          }//end delete record



    class clickedCancel implements ActionListener {
      public void actionPerformed(ActionEvent e) {

      if (statusChange) {
            if  (JOptionPane.showConfirmDialog(null,"Do you want to Confirm Update Database ?","Confirm",JOptionPane.YES_NO_OPTION) == 0 )
              {
                 db.not_ok_confirm = false;
                 db.SQLExecute("");
                 System.out.println("YES");
                 System.exit(0);
            }
              else  {
          try {
                 db.not_ok_confirm = true;
                 System.out.println(db.not_ok_confirm+"No");
                 System.exit(0);
                 db.con.setAutoCommit(true);
             }
        catch(SQLException ex) {
                System.out.println(ex.getMessage());
            }
          }
}// if statusChange
      else {
            System.exit(0);
      }

      } //end public void
    } //end clickedCancel

    public void refreshRecordTable() {
        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice,notprotocol;
        ResultSet tmprs;
        if(con!=null)
        {
          try {
              SQL =  "SELECT * FROM Confige Where Action =   '"+actionComboBox.getSelectedItem().toString()+ "'  " ;
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

                         listModel.clearData();
              int row =0;
                            rs.first();
                             while (rs.next()) {

                                  rs.previous();
                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  notprotocol = rs.getString("notprotocal");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Chain,row,1);
                                  listModel.setValueAt(notprotocol,row,2);
                                  listModel.setValueAt(Protocal,row,3);
                                  listModel.setValueAt(notSrcIP,row,4);
                                  listModel.setValueAt(src_IP,row,5);
                                  listModel.setValueAt(notSrcPort,row,6);
                                  listModel.setValueAt(src_Port,row,7);
                                  listModel.setValueAt(notSrcDevice,row,8);
                                  listModel.setValueAt(src_Device,row,9);
                                  listModel.setValueAt(notDesIP,row,10);
                                  listModel.setValueAt(des_IP,row,11);
                                  listModel.setValueAt(notDesPort,row,12);
                                  listModel.setValueAt(des_Port,row,13);
                                  listModel.setValueAt(notDesDevice,row,14);
                                  listModel.setValueAt(des_Device,row,15);
                                  listModel.setValueAt(Action,row,16);

                                  rs.next();

                                  row += 1;
                                  }//while

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  notprotocol = rs.getString("notprotocal");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Chain,row,1);
                                  listModel.setValueAt(notprotocol,row,2);
                                  listModel.setValueAt(Protocal,row,3);
                                  listModel.setValueAt(notSrcIP,row,4);
                                  listModel.setValueAt(src_IP,row,5);
                                  listModel.setValueAt(notSrcPort,row,6);
                                  listModel.setValueAt(src_Port,row,7);
                                  listModel.setValueAt(notSrcDevice,row,8);
                                  listModel.setValueAt(src_Device,row,9);
                                  listModel.setValueAt(notDesIP,row,10);
                                  listModel.setValueAt(des_IP,row,11);
                                  listModel.setValueAt(notDesPort,row,12);
                                  listModel.setValueAt(des_Port,row,13);
                                  listModel.setValueAt(notDesDevice,row,14);
                                  listModel.setValueAt(des_Device,row,15);
                                  listModel.setValueAt(Action,row,16);

                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh


      class ListSearchModel extends AbstractTableModel {
                	String[] columnNames = {
			      "rule no.",
			"chain",
                        "use protocol",
                        "protocol",
			"use src ip",
                        "src ip",
                        "use src port",
			"src port",
                        "not src device",
                        "src device",
                        "use des ip",
                        "des ip",
                        "use des port",
                        "use Port",
                        "use des Device",
                        "des device",
                        "action"};

		Object[][] data = {
			{"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""} ,
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},{"","", "","", "","","","","","","","","","","","",""},
                   };

                              public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;
	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
	}

/*	public Class getColumnClass(int c) {
		return getValueAt(0, c).getClass();
	}
*/
	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}

	public void clearData() {
                                                          for(int i=0; i<data.length; i++)
		  for(int j=0; j<columnNames.length; j++)
		if (j<=20)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
	}



  }//////////////////////////////////////////////////////////// end ListSearchModel



  }