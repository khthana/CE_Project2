import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class ChatPanel extends JPanel {
  XYLayout xYLayout1 = new XYLayout();
  JLabel chatLabel = new JLabel();

  public ChatPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    chatLabel.setHorizontalAlignment(SwingConstants.CENTER);
    chatLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    chatLabel.setIcon(new ImageIcon("./Images/Chat.gif"));
    this.setLayout(xYLayout1);
    xYLayout1.setWidth(487);
    xYLayout1.setHeight(397);
    this.setBackground(new Color(236, 233, 230));
    this.add(chatLabel, new XYConstraints(119, 24, 227, 48));
  }
}