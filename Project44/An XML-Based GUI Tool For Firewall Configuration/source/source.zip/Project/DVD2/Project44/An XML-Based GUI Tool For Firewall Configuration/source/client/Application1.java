import javax.swing.UIManager;
import java.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

 class SplashWindow extends JWindow  {

   public SplashWindow(Frame f, int waitTime) {
      super(f);
      JLabel l = new JLabel(new ImageIcon("images/SplashWindow.gif"));    // ���ҧ���ŷ�����ٻ
      getContentPane().add(l, BorderLayout.CENTER);   // �á���ź�����ǹ��ҧ
      pack(); // ��˹���Ҵ����������
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();   // ��ҹ��Ҵ�ͷ����ҹ
      Dimension labelSize = l.getPreferredSize();      // ��ҹ��Ҵ����
      setLocation(screenSize.width/2 - (labelSize.width/2),
      screenSize.height/2 - (labelSize.height/2));      // ������������ҧ��
      addMouseListener(new MouseAdapter() { // �ѡ�ѧ�����
                                       public void mousePressed(MouseEvent e)
                                       { // �ҡ������ԡ��������Դ Splash Screen
                                          setVisible(false);
                                          dispose();   }
                                       });
      final int pause = waitTime; // �����ʴ��ͧ Splash Screen
      // �������������èҡ����� (��ԡ�����) ����͵������ pause �Թҷ�
      final Runnable closerRunner = new Runnable() // Thread �ͧ��ǹ�Դ
          {   public void run() {
                  setVisible(false);
                  dispose();
               }
           };
      Runnable waitRunner = new Runnable() //  Thread �ͧ��ǹ��
           {  public void run() {
                   try {   Thread.sleep(pause);
                              SwingUtilities.invokeAndWait(closerRunner);
                         }
                   catch(Exception e) {  e.printStackTrace(); }
               }
            };
      setVisible(true);
      Thread splashThread = new Thread(waitRunner,"SplashThread");
      splashThread.start();
    }
}

public class Application1 {
  boolean packFrame = false;
  public static Frame2 frame = new Frame2();

  /**Construct the application*/
  public Application1() {
    //Validate frames that have preset sizes
    //Pack frames that have useful preferred size info, e.g. from their layout
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

      new Password();
      new SplashWindow(frame,10000);
    frame.setVisible(true);
  }// end jbinit();

  /**Main method*/
  public static void main(String[] args) {
    try {
    //  UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
  //  UIManager.setLookAndFeel(new com.sun.java.swing.plaf.motif.MotifLookAndFeel());

    }
    catch(Exception e) {
      e.printStackTrace();
    }
   new Application1();
 //  new BlackList();
   new FullViewRule();
  }
}

