import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.table.AbstractTableModel;
import java.sql.*;
import java.util.*;
import java.text.*;
import javax.swing.JTable.*;
import javax.swing.table.*;
import com.borland.jbcl.layout.*;
import java.lang.*;

public class ManagePanel extends JPanel{


  String url, user, password, retriveSQL, tableName;
  public static ListSearchModel listModel;
  // Database Component

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;
  JTable table;
  public int CountRow=0;

  	// Create your own sub-class of JTable rather than using anonymous class
        // Set the table transparent

  public static int ReturnRowSelect;
  public static boolean clickedEdit;
  public static boolean setStatusNew;
  public static boolean setStatusUpdate;
  boolean statusChange = false;

//  public Object[][] data = ;
  public int NoLastRow=1;
 // Object[][] data = new Object[20][16];

  public static String ChainOldValue, src_IPOldValue, src_PortOldValue,  src_DeviceOldValue, des_IPOldValue,  des_PortOldValue,  des_DeviceOldValue;
  public static String  ProtocalOldValue,ActionOldValue,  notSrcIPOldValue , notSrcPortOldValue, notSrcDeviceOldValue, notDesIPOldValue, notDesPortOldValue,  notDesDeviceOldValue;

  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  JButton deleteButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  public static JButton refreshButton = new JButton(new ImageIcon("images/Refresh.png"));
  JButton cancelButton = new JButton(new ImageIcon("images/Cancel.png"));
  JButton okButton = new JButton(new ImageIcon("images/Ok.png"));

  JButton addButton = new JButton(new ImageIcon("images/Add.png"));

  JButton exitButton = new JButton(new ImageIcon("images/ExitDoor.gif"));
  JButton resetButton = new JButton(new ImageIcon("images/Reset.png"));
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  JButton clearButton = new JButton(new ImageIcon("images/Clear.png"));

  Frame2 frame2 ;//= new Frame2();
  UpdatePanel uppanel  ;//= new UpdatePanel();
  JPanel contentPane;
  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  Border border1;
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  Border border2;
  TitledBorder titledBorder3;
  Border border3;
  TitledBorder titledBorder4;
  JPanel jPanel3 = new JPanel();
  JLabel mainlogoLabel = new JLabel();
  TitledBorder titledBorder5;
  Border border4;
  JTable jTable = new JTable();
  Border border5;
  TitledBorder titledBorder6;
  TitledBorder titledBorder7;
  TitledBorder titledBorder8;
  TitledBorder titledBorder9;
  JPanel jPanel4 = new JPanel();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel12 = new JPanel();
  JLabel jLabel100 = new JLabel();
  JPanel jPanel13 = new JPanel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel jPanel8 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel2 = new JPanel();
  TitledBorder titledBorder10;
  TitledBorder titledBorder11;
  TitledBorder titledBorder12;
  TitledBorder titledBorder13;
  TitledBorder titledBorder14;
  GridBagLayout gridBagLayout6 = new GridBagLayout();
  GridLayout gridLayout1 = new GridLayout();
  GridLayout gridLayout2 = new GridLayout();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  GridLayout gridLayout4 = new GridLayout();
  GridLayout gridLayout5 = new GridLayout();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  Border border6;
  XYLayout xYLayout1 = new XYLayout();
  JButton upRecordButton = new JButton(new ImageIcon("images/MoveRowUp.png"));
  JButton downRecordButton = new JButton(new ImageIcon("images/MoveRowDown.png"));
  XYLayout xYLayout2 = new XYLayout();



  /**Construct the frame*/
  public ManagePanel() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  protected void jbInit() throws Exception  {
    url ="jdbc:odbc:dbConfige";
    user="admin";
    password="";
    tableName="Confige";
    retriveSQL="SELECT * FROM Confige";

    JPanel jtablePanel = new JPanel();
    listModel = new ListSearchModel();
    //table  = new JTable(listModel);
    ///////////////
    table = new JTable(listModel);

    table.setOpaque(false);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

    mainlogoLabel.setIcon(new ImageIcon("./Images/mainlogo.gif"));
    JScrollPane scrollPane = new JScrollPane(table);
    titledBorder10 = new TitledBorder("");
    titledBorder11 = new TitledBorder("");
    titledBorder12 = new TitledBorder("");
    titledBorder13 = new TitledBorder("");
    titledBorder14 = new TitledBorder("");
    scrollPane.setViewportBorder(BorderFactory.createEtchedBorder());
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setFont(new java.awt.Font("SansSerif", 1, 12));
    scrollPane.setForeground(Color.lightGray);
    scrollPane.setAutoscrolls(true);
    scrollPane.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.setDoubleBuffered(true);
    scrollPane.setPreferredSize(new Dimension(453, 300));
    scrollPane.setToolTipText("");

    editButton.setActionCommand("Edit");
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    border1 = BorderFactory.createLineBorder(Color.white,1);
    titledBorder1 = new TitledBorder(BorderFactory.createEmptyBorder(),"");
    titledBorder2 = new TitledBorder("");
    border2 = BorderFactory.createCompoundBorder(new EtchedBorder(EtchedBorder.RAISED,Color.lightGray,new Color(142, 142, 142)),BorderFactory.createEmptyBorder(4,4,4,4));
    titledBorder3 = new TitledBorder("");
    border3 = new MatteBorder(null);
    titledBorder4 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"");
    titledBorder5 = new TitledBorder("");
    border4 = BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(142, 142, 142),new Color(99, 99, 99));
    border5 = BorderFactory.createLineBorder(Color.lightGray,2);
    titledBorder6 = new TitledBorder("");
    titledBorder7 = new TitledBorder("");
    titledBorder8 = new TitledBorder("");
    titledBorder9 = new TitledBorder("");
    this.setForeground(Color.blue);
    this.setSize(new Dimension(659, 410));
    this.setBackground(new Color(236, 233, 230));
    setEnabled(true);
    setFont(new java.awt.Font("SansSerif", 0, 14));
    setBorder(titledBorder1);
    setToolTipText("");
    jPanel1.setLayout(borderLayout1);
    mainlogoLabel.setFont(new java.awt.Font("SansSerif", 1, 12));
    mainlogoLabel.setForeground(new Color(79, 72, 236));
    mainlogoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    mainlogoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    jPanel4.setLayout(gridBagLayout6);
    applyButton.setText("Apply");
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setBorder(titledBorder4);


    addButton.setPreferredSize(new Dimension(70, 29));
    deleteButton.setPreferredSize(new Dimension(50, 29));
    editButton.setPreferredSize(new Dimension(50, 29));

    applyButton.setPreferredSize(new Dimension(45, 10));
    editButton.setPreferredSize(new Dimension(50, 29));
    refreshButton.setPreferredSize(new Dimension(50, 29));

    cancelButton.setMaximumSize(new Dimension(50, 29));
    cancelButton.setPreferredSize(new Dimension(35, 39));


    applyButton.setBackground(new Color(236, 233, 230));
    applyButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    jPanel9.setLayout(gridLayout4);
    jPanel11.setLayout(gridBagLayout2);
    exitButton.setBackground(new Color(236, 233, 230));
    exitButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    exitButton.setBorder(titledBorder4);
    exitButton.setPreferredSize(new Dimension(45, 29));
    exitButton.setHorizontalTextPosition(SwingConstants.LEFT);
    exitButton.setText("Exit");
    resetButton.setBackground(new Color(236, 233, 230));
    resetButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    resetButton.setBorder(titledBorder4);
    resetButton.setPreferredSize(new Dimension(45, 29));
    resetButton.setHorizontalTextPosition(SwingConstants.LEFT);
    resetButton.setText("Reset");
    jPanel6.setLayout(gridBagLayout1);
    jPanel10.setLayout(gridLayout5);
    jPanel12.setBackground(new Color(236, 233, 230));
    jPanel12.setAlignmentX((float) 10.0);
    jPanel12.setAlignmentY((float) 20.0);
    jPanel12.setPreferredSize(new Dimension(50, 50));
    jPanel12.setLayout(xYLayout1);
    jPanel9.setMaximumSize(new Dimension(165, 29));
    jPanel9.setPreferredSize(new Dimension(100, 29));
    jPanel9.setToolTipText("");
    jPanel6.setBackground(new Color(236, 233, 230));
    jPanel6.setPreferredSize(new Dimension(200, 39));
    jPanel10.setMinimumSize(new Dimension(120, 29));
    jPanel10.setPreferredSize(new Dimension(180, 29));
    addButton.setMaximumSize(new Dimension(37, 29));


    clearButton.setText("Clear All");
    clearButton.setBorder(titledBorder4);
    clearButton.setMaximumSize(new Dimension(37, 29));
    clearButton.setMinimumSize(new Dimension(37, 29));
    clearButton.setPreferredSize(new Dimension(70, 29));
    clearButton.setHorizontalTextPosition(SwingConstants.LEFT);
    clearButton.setBackground(new Color(236, 233, 230));
    clearButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    editButton.setText("Edit");
    editButton.setBorder(titledBorder4);

    editButton.setBackground(new Color(236, 233, 230));
    editButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    jPanel13.setBackground(new Color(236, 233, 230));
    jPanel13.setPreferredSize(new Dimension(83, 100));
    jPanel13.setLayout(borderLayout2);
    refreshButton.setText("Refresh ");
    refreshButton.setBorder(titledBorder4);
    refreshButton.setMaximumSize(new Dimension(37, 29));
    refreshButton.setMinimumSize(new Dimension(37, 29));

    refreshButton.setHorizontalTextPosition(SwingConstants.LEFT);
    refreshButton.setBackground(new Color(236, 233, 230));
    refreshButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    deleteButton.setText("Delete");
    deleteButton.setBorder(titledBorder4);
    deleteButton.setMaximumSize(new Dimension(37, 29));
    deleteButton.setMinimumSize(new Dimension(37, 29));

    deleteButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deleteButton.setBackground(new Color(236, 233, 230));
    deleteButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    jPanel8.setBackground(Color.lightGray);
    jPanel8.setToolTipText("");
    jPanel8.setLayout(gridLayout1);
    addButton.setText("Add");
    addButton.setMnemonic('0');
    addButton.setBorder(titledBorder4);
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setBackground(new Color(236, 233, 230));
    addButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    jPanel5.setBackground(Color.lightGray);
    jPanel5.setPreferredSize(new Dimension(70, 58));
    jPanel5.setLayout(gridLayout2);
    jPanel2.setLayout(gridBagLayout3);
    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel2.setBorder(titledBorder4);
    jPanel2.setPreferredSize(new Dimension(115, 280));
    jPanel11.setBackground(new Color(236, 233, 230));
    jPanel11.setPreferredSize(new Dimension(300, 39));
    cancelButton.setText("Cancel");
    cancelButton.setHorizontalTextPosition(SwingConstants.LEFT);
    cancelButton.setBorder(titledBorder4);
    cancelButton.setBackground(new Color(236, 233, 230));
    cancelButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    cancelButton.addActionListener(new clickedCancel());
    okButton.setBackground(new Color(236, 233, 230));
    okButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    okButton.setBorder(titledBorder4);
    okButton.setPreferredSize(new Dimension(40, 29));
    okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    okButton.setText("OK");
    okButton.addActionListener(new clickedOk());

    upRecordButton.addActionListener(new clickedMoveUp());
    downRecordButton.addActionListener(new clickedMoveDown());

    jPanel4.setBackground(new Color(236, 233, 230));
    jPanel4.setPreferredSize(new Dimension(619, 40));
    gridLayout1.setRows(3);
    gridLayout1.setColumns(1);
    gridLayout2.setRows(2);
    gridLayout2.setColumns(1);
    gridLayout4.setColumns(3);
    gridLayout5.setColumns(2);
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setLayout(xYLayout2);
    downRecordButton.setBackground(new Color(236, 233, 230));
    downRecordButton.setBorder(null);
    downRecordButton.setHorizontalTextPosition(SwingConstants.CENTER);
    upRecordButton.setBackground(new Color(236, 233, 230));
    upRecordButton.setBorder(null);
    upRecordButton.setHorizontalTextPosition(SwingConstants.CENTER);
    jPanel1.add(jPanel3,  BorderLayout.NORTH);
    jPanel3.add(mainlogoLabel,        new XYConstraints(178, 5, 290, 35));
    jPanel1.add(jPanel12,  BorderLayout.EAST);
    jPanel12.add(upRecordButton, new XYConstraints(6, 11, 37, 31));
    jPanel12.add(downRecordButton, new XYConstraints(6, 38, 37, 36));
    jPanel1.add(jPanel2,  BorderLayout.WEST);
    jPanel8.add(addButton, null);
    jPanel8.add(editButton, null);
    jPanel8.add(deleteButton, null);
    jPanel1.add(scrollPane, BorderLayout.CENTER);
    jPanel2.add(jPanel13,       new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 5, 0, 5), 0, 0));
    jPanel2.add(jPanel5,          new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(0, 5, 5, 5), 13, 0));
    jPanel2.add(jPanel8,                new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 14, 0, 9), 10, 10));
    jPanel5.add(clearButton, null);
    jPanel5.add(refreshButton, null);

    jPanel4.add(jPanel6,     new GridBagConstraints(1, 0, 1, 2, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(1, 0, 0, 0), 100, 0));
    jPanel6.add(jPanel10,        new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 58, 0, 0), 0, 3));
    jPanel10.add(resetButton, null);
    jPanel10.add(exitButton, null);
    jPanel4.add(jPanel11,        new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 0, 0, 19), -60, -4));
    jPanel11.add(jPanel9,            new GridBagConstraints(0, 0, 1, 2, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 200, -1));
    jPanel9.add(okButton, null);
    jPanel9.add(cancelButton, null);
    jPanel9.add(applyButton, null);

    add(jPanel1, BorderLayout.CENTER);
    add(jPanel4, BorderLayout.SOUTH);

    addButton.addActionListener(new clickedAdd());
    editButton.addActionListener(new clickedEdit());
    deleteButton.addActionListener(new clickedDelete());
    applyButton.addActionListener(new clickedApply());
    resetButton.addActionListener(new clickedReset());
    clearButton.addActionListener(new clickedClearRecordAll());
    refreshButton.addActionListener(new clickedRefresh());
    exitButton.addActionListener(new clickedExit());

    table.setAlignmentX(10);
    table.setAlignmentY(20);
	// Database section
	db = new DBUtil();
	con = db.Establish();

        String SQL="";
        rs = db.SQLRetrive("SELECT * from confige where Service = 'icmpinputdrop'");
     if(!rs.first()) {

        SQL = "insert into confige (Service) values ('icmpinputdrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpforwarddrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpechoinput')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpechoinputdrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpechoforward')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpechoforwarddrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmptimeinput')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmptimeinputdrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmptimeforward')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmptimeforwarddrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpotherinput')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpotherinputdrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpotherforward')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();

        SQL = "insert into confige (Service) values ('icmpotherforwarddrop')";
        System.out.println(SQL);
        db.SQLExecute(SQL);
        db.con.commit();
     }

        UpdatePanel.status = "ADD";
        UpdatePanel.updatelogoLabel.setIcon(new ImageIcon("./Images/AddRule.gif"));



       rs = db.SQLRetrive("SELECT * FROM definechain");
       if(!rs.first()) {
            db.SQLExecute("insert into definechain (Name,policy,Comment) values ('INPUT','DROP','input-chain')");
            db.SQLExecute("insert into definechain (Name,policy,Comment) values ('OUTPUT','ACCEPT','output-chain')");
            db.SQLExecute("insert into definechain (Name,policy,Comment) values ('FORWARD','DROP','forward-chain')");
            db.con.commit();
        }

       rs = db.SQLRetrive("SELECT * FROM user");
       String username,password;
        if(!rs.first()) {
              username="Admin";
              password="Admin";
              db.SQLExecute("insert into user (username,password) values ('"+username+"','"+password+"')");
        }

  rs = db.SQLRetrive("SELECT * FROM options");
  String field,value,drespping="",drespbroad="",drespicmpredi="",enbaderror="",dipspoof="",entcpsyn="",dsrcrouting="",logmar="";

  field = "drespping,drespbroad,drespicmpredi,enbaderror,dipspoof,entcpsyn,dsrcrouting,logmar";
  drespping="/bin/echo \"0\" > /proc/sys/net/ipv4/icmp_echo_ignore_all";
  drespbroad="/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts";
  drespicmpredi="/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_redirects";
  enbaderror="/bin/echo \"1\" > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses";
  dipspoof="/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/rp_filter";
  entcpsyn="/bin/echo \"1\" > /proc/sys/net/ipv4/tcp_syncookies";
  dsrcrouting="/bin/echo \"0\" > /proc/sys/net/ipv4/conf/all/accept_source_route";
  logmar="/bin/echo \"1\" > /proc/sys/net/ipv4/conf/all/log_martians";

  value =" '"+drespping+"' ,'"+drespbroad+"','"+drespicmpredi+"','"+enbaderror+"','"+dipspoof+"','"+entcpsyn+"','"+dsrcrouting+"','"+logmar+"'";

          if(!rs.first()) {
            SQL = "insert into options ("+ field +") values ("+value+")";
            System.out.println("insert into options ("+ field +") values ('"+value+"')");
            db.SQLExecute(SQL);
            db.con.commit();
        }

   refreshRecordTable();
   }// end jbinit

    class clickedClearRecordAll implements ActionListener {
      public void actionPerformed(ActionEvent e) {
                    String SQL="";
          if  (JOptionPane.showConfirmDialog(null,"Do you want to Clear Record All ?","Confirm",JOptionPane.YES_NO_OPTION) == 0 )
              {
                    SQL ="DELETE FROM Confige";
                    db.SQLExecute(SQL);
                    System.out.println(SQL);
                    refreshRecordTable();
              }

         else {

              }

        }
      }

    class clickedMoveUp implements ActionListener {
          public void actionPerformed(ActionEvent e) {
            moveUpRecord();
      }
    }
    class clickedMoveDown implements ActionListener {
          public void actionPerformed(ActionEvent e) {
            moveDownRecord();
      }
    }
    class clickedRefresh implements ActionListener {
      public void actionPerformed(ActionEvent e) {
                    refreshRecordTable();
        }
      }

   class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       Frame2.tabbedPaneMain.setEnabledAt(1,true);

       ChainOldValue="";src_IPOldValue=""; src_PortOldValue=""  ;
       src_DeviceOldValue=""; des_IPOldValue="";  des_PortOldValue="";
       des_DeviceOldValue="";ProtocalOldValue="";ActionOldValue="";
       notSrcIPOldValue="";notSrcPortOldValue=""; notSrcDeviceOldValue="";
       notDesIPOldValue=""; notDesPortOldValue="";  notDesDeviceOldValue="";

              statusChange = true;
              UpdatePanel.status = "ADD";

              UpdatePanel.updatelogoLabel.setIcon(new ImageIcon("./Images/AddRule.gif"));


              UpdatePanel.notsrcipCheckBox.setSelected(false);
              UpdatePanel.notsrcportCheckBox.setSelected(false);
              UpdatePanel.notsrcdeviceCheckBox.setSelected(false);
              UpdatePanel.notdesipCheckBox.setSelected(false);
              UpdatePanel.notdesportCheckBox.setSelected(false);
              UpdatePanel.notdesdeviceCheckBox.setSelected(false);

              UpdatePanel.src_ipTextField.setText("");
              UpdatePanel.src_portTextField.setText("");
              UpdatePanel.src_deviceTextField.setText("");
              UpdatePanel.des_ipTextField.setText("");
              UpdatePanel.des_portTextField.setText("");
              UpdatePanel.des_deviceTextField.setText("");

              UpdatePanel.updatelogoLabel.setIcon(new ImageIcon("./Images/AddRule.gif"));
              Frame2.tabbedPaneMain.setSelectedIndex(1);
              Frame2.tabbedPaneMain.setEnabledAt(0,false);
              Frame2.tabbedPaneMain.setEnabledAt(1,true);

      }
    }

    class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       Frame2.tabbedPaneMain.setEnabledAt(0,false);
       Frame2.tabbedPaneMain.setEnabledAt(1,true);
       UpdatePanel.updatelogoLabel.setIcon(new ImageIcon("./Images/EditRule.gif"));
       statusChange = true;
       clickedEdit = true;
       setStatusUpdate = true;

       String stmp="";
       int tmp;
       ReturnRowSelect=table.getSelectedRow();
       System.out.println(stmp.valueOf(ReturnRowSelect));
       Frame2.tabbedPaneMain.setSelectedIndex(1);
       setEdit();
      }
    }

  public void writeFile()
  {
      String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
      String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice;
      String stringWrite="",stringFirstWrite="";
      String mpiptables="",mipconntrack="",drespping="",drespbroad="",drespicmpredi="",turnonfor="",inputd="",outputd="",forwardd="";


                      try {
              SQL = "SELECT * FROM options";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

            int row = 0;

                             while (rs.next()) {

                                  Id = rs.getString("Id");
                                  mpiptables = rs.getString("mpiptables");
                                  mipconntrack = rs.getString("mipconntrack");
                                  drespping = rs.getString("drespping");
                                  drespbroad = rs.getString("drespbroad");
                                  drespicmpredi = rs.getString("drespicmpredi");
                                  turnonfor = rs.getString("turnonfor");
                                  inputd = rs.getString("inputd");
                                  outputd = rs.getString("outputd");
                                  forwardd = rs.getString("forwardd");

                                  row += 1;


                                  }//while
                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }

                  if (mpiptables == "")
                      mpiptables = "";
                  if (mipconntrack == "")
                      mipconntrack = "";
                  if (drespping == "");
                      drespping = "";
                  if (drespicmpredi == "")
                      drespicmpredi = "";
                  if (turnonfor == "")
                      turnonfor = "";
                  if (inputd == "")
                      inputd = "";
                  if (outputd == "")
                      outputd = "";
                  if (forwardd == "")
                      forwardd = "";


                stringFirstWrite += "# http://www.cs.princeton.edu/~jns/security/iptables/index.html\n"+
                                "# Prepared by Niwat & JoeL \n"+
                                "# sendtokeng@hotmail.com \n"+
                                "#!/bin/bash \n"+
                                "# Load appropriate modules. \n"+
                                mpiptables +"\n"+
                                mipconntrack + "\n"+
                                drespping + "\n"+
                                drespicmpredi + "\n"+
                                turnonfor +"\n"+
                                inputd +"\n"+
                                outputd +"\n"+
                                forwardd +"\n";


          if(con!=null)
        {
          try {
              SQL = "SELECT * FROM confige";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);
              int row =0;

                FileWriter fout = new FileWriter("iptablesRule.firewall");
                             while (rs.next()) {

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                if (src_IP == "")
                   src_IP = " ";
                 else
                   src_IP = " -s " + src_IP;

                if (src_Port == "")
                    src_Port = " ";
                 else
                    src_Port = " -sport " + src_Port;

                 if (src_Device == "")
                     src_Device = " ";
                 else
                      src_Device = " -i " + src_Device;

                 if (des_IP == "")
                      des_IP = "";
                 else
                      des_IP = " -i " + des_IP;

                 if (des_Port == "")
                      des_Port = " ";
                 else
                      des_Port = " -dport " + des_Port;

                 if (des_Device == "")
                      des_Device = " ";
                 else
                      des_Device = " -o " + des_Device;

                 Chain = "- A " + Chain;
                 Action = " -j " + Action;
                 Protocal = " -p " + Protocal;





             stringWrite += "iptables " + Action + src_Device + Protocal +
                src_IP + src_Port + des_Device + des_IP + des_Port +
                Action + "\n";

                  row += 1;
                 }//while

               System.out.println(stringFirstWrite);
               System.out.println(stringWrite);
               fout.write(stringFirstWrite);
               fout.write('\n');
               fout.write(stringWrite);
               fout.write('\n');
               rs.close();
               fout.close();


                  }//try

                           catch(Exception ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if

  }

  public static void setEdit() {
               String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
               String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice,notprotocol;
                   UpdatePanel.status = "UPDATE";
                   try {
                     rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                    }

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");


                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  notprotocol = rs.getString("notprotocal");

                                  ChainOldValue = Chain;
                                  src_IPOldValue = src_IP;
                                  src_PortOldValue= src_Port;
                                  src_DeviceOldValue = src_Device;
                                  des_IPOldValue = des_IP;
                                  des_PortOldValue = des_Port;
                                  des_DeviceOldValue = des_Device;
                                  ProtocalOldValue = Protocal;
                                  ActionOldValue = Action;

                                  notSrcIPOldValue = notSrcIP;
                                  notSrcPortOldValue = notSrcPort;
                                  notSrcDeviceOldValue = notSrcDevice;
                                  notDesIPOldValue = notDesIP;
                                  notDesPortOldValue = notDesPort;
                                  notDesDeviceOldValue = notDesDevice;



                                  UpdatePanel.chainComboBox.setSelectedItem(Chain);

                                  if (notSrcIP.equals("NO"))
                                        UpdatePanel.notsrcipCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notsrcipCheckBox.setSelected(false);

                                  if (notSrcPort.equals("NO"))
                                        UpdatePanel.notsrcportCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notsrcportCheckBox.setSelected(false);

                                  if (notSrcDevice.equals("NO"))
                                        UpdatePanel.notsrcdeviceCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notsrcdeviceCheckBox.setSelected(false);

                                  if (notDesIP.equals("NO"))
                                        UpdatePanel.notdesipCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notdesipCheckBox.setSelected(false);
                                  if (notDesPort.equals("NO"))
                                        UpdatePanel.notdesportCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notdesportCheckBox.setSelected(false);
                                  if (notDesDevice.equals("NO"))
                                        UpdatePanel.notdesdeviceCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notdesdeviceCheckBox.setSelected(false);


                                  if(!notprotocol.equals(""))
                                  if(notprotocol.equals("NO"))
                                        UpdatePanel.notprotocolCheckBox.setSelected(true);
                                  else
                                        UpdatePanel.notprotocolCheckBox.setSelected(false);

                                  UpdatePanel.src_ipTextField.setText(src_IP);
                                  UpdatePanel.src_portTextField.setText(src_Port);
                                  UpdatePanel.src_deviceTextField.setText(src_Device);
                                  UpdatePanel.des_ipTextField.setText(des_IP);
                                  UpdatePanel.des_portTextField.setText(des_Port);
                                  UpdatePanel.des_deviceTextField.setText(des_Device);

                                  if (Protocal.equals("TCP"))
                                        UpdatePanel.protocalComboBox.setSelectedIndex(0);
                                  else if (Protocal.equals("UDP"))
                                        UpdatePanel.protocalComboBox.setSelectedIndex(1);
                                  else if (Protocal.equals("ICMP"))
                                        UpdatePanel.protocalComboBox.setSelectedIndex(2);

                                  if (Action.equals("ACCEPT"))
                                        UpdatePanel.actionComboBox.setSelectedIndex(0);
                                  else if (Action.equals("DROP"))
                                        UpdatePanel.actionComboBox.setSelectedIndex(1);
                                  else if (Action.equals("REJECT"))
                                        UpdatePanel.actionComboBox.setSelectedIndex(2);


                  }
                                  catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }
  }//end setEdit

    class clickedCancel implements ActionListener {
      public void actionPerformed(ActionEvent e) {

      if (statusChange) {
            if  (JOptionPane.showConfirmDialog(null,"Do you want to Confirm Update Database ?","Confirm",JOptionPane.YES_NO_OPTION) == 0 )
              {
                 db.not_ok_confirm = false;
                 db.SQLExecute("");
                 System.out.println("YES");
                 System.exit(0);
            }
              else  {
          try {
                 db.not_ok_confirm = true;
                 System.exit(0);
                 db.con.setAutoCommit(true);
             }
        catch(SQLException ex) {
                System.out.println(ex.getMessage());
            }
          }
}// if statusChange
      else {
            System.exit(0);
      }

      } //end public void
    } //end clickedCancel


    class clickedOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {

      if  (JOptionPane.showConfirmDialog(null,"Do you want to Confirm Update Database ?","Confirm",JOptionPane.YES_NO_OPTION) == 0 )
              {
                 db.not_ok_confirm = false;
                 db.SQLExecute("");
                 System.out.println("YES");
                 System.exit(0);
            }
            else {
      try {
                  db.not_ok_confirm = true;
                  System.out.println(db.not_ok_confirm+"No");
                  System.exit(0);
                  db.con.setAutoCommit(true);
             }
      catch(SQLException ex) {
                  System.out.println(ex.getMessage());
      }
    }

      }
    }

       class clickedExit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
              System.exit(0);
      }
    }

    public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }

    class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
            Apply();
      }
    }

    public static void Reset() {
       try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

                  refreshRecordTable();
                 System.out.println("Reset");
    }
      class clickedReset implements ActionListener {
      public void actionPerformed(ActionEvent e) {

            try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

                  refreshRecordTable();
                 System.out.println("Reset");
      }
    }

    class ListSearchModel extends AbstractTableModel {

//      public ListSearchModel() {
//        setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
//       }

        	int LastRow=0;


                   	String[] columnNames = {
                	"rule no.",
			"chain",
                        "use protocol",
                        "protocol",
			"use src ip",
                        "src ip",
                        "use src port",
			"src port",
                        "not src device",
                        "src device",
                        "use des ip",
                        "des ip",
                        "use des port",
                        "use Port",
                        "use des Device",
                        "des device",
                        "action"};


                //Object[][] data = new Object[LastRow][columnNames.length];

                Object[][] data = {
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                        {"","","","", "","","","","","","","","","","","",""},{"","","", "","","","","","","","","","","","","",""},{"","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},{ "","", "","","","","","","","","","","","","","",""},
                           		};



        public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;

	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
                //return new Integer(row*col);
	}

//	public Class getColumnClass(int c) {/
//		return getValueAt(0, c).getClass();
//	}

	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}

	public void clearData() {
        for(int i=0; i<data.length; i++)
		  for(int j=0; j<columnNames.length; j++)
		if (j<=20)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
	}
        }

 public void moveDownRecord() {

        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,notprotocal,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice="",notDesIP,notDesPort,notDesDevice,sRuleNo="";
        String tablename,frag,syn, notfrag, notsyn,  notflagmark, flagmark, flagcomp = new String("");
        String nottcp_op, tcp_op, noticmptype, icmptype, match, notmsource, msource, limit, limitrate, limitB, limitBnum = new String("");
        String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
        String setmark, rejecttype, settos, to, tosource, todes, toport,mul_sport,mul_dport = new String("");


        String belowId,belowChain,belowAction,belowsrc_IP,belowsrc_Port,belowsrc_Device,belowdes_IP,belowdes_Port,belowdes_Device,belownotprotocal,belowProtocal;
        String belownotSrcIP,belownotSrcPort,belownotSrcDevice="",belownotDesIP,belownotDesPort,belownotDesDevice,belowsRuleNo="";
        String belowtablename,belowfrag,belowsyn, belownotfrag, belownotsyn,  belownotflagmark, belowflagmark, belowflagcomp = new String("");
        String belownottcp_op, belowtcp_op, belownoticmptype, belowicmptype, belowmatch, belownotmsource, belowmsource, belowlimit, belowlimitrate, belowlimitB, belowlimitBnum = new String("");
        String belowsdport, belowmarkvalue, belowuserid, belowgroupid, belowprocessid, belowsessionid, belowstate, belowtos, belowlevel, belowprefix, belowlogseq, belowlogop, belowlogipop = new String("");
        String belowsetmark, belowrejecttype, belowsettos, belowto, belowtosource, belowtodes, belowtoport,belowmul_sport,belowmul_dport = new String("");


        String PK;

                if(con!=null)
        {
          try {
              //SQL = "SELECT * FROM confige order by ID";
              SQL = "SELECT * FROM confige Where Service not in ('icmpinputdrop','icmpforwarddrop','icmpechoinput','icmpechoinputdrop','icmpechoforward','icmpechoforwarddrop','icmptimeinput','icmptimeinputdrop','icmptimeforward','icmptimeforwarddrop','icmpotherinput','icmpotherinputdrop','icmpotherforward','icmpotherforwarddrop') or Service is null order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);


           ReturnRowSelect=table.getSelectedRow();
              int row =0;

                            rs.first();
                              for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                  row += 1;
                                }

                        Id = rs.getString("ID");
                        tablename = rs.getString("tablename");
                        Chain = rs.getString("Chain");
                        notprotocal = rs.getString("notprotocal");
                        Protocal = rs.getString("Protocal");
                        notSrcIP = rs.getString("notSrcIP");
                        src_IP = rs.getString("src_IP");
                        notSrcPort = rs.getString("notSrcPort");
                        src_Port = rs.getString("src_Port");
                        notSrcPort = rs.getString("notSrcPort");
                        notSrcDevice = rs.getString("notSrcDevice");
                        src_Device = rs.getString("src_Device");
                        notDesIP = rs.getString("notDesIP");
                        des_IP = rs.getString("des_IP");
                        notDesPort = rs.getString("notDesPort");
                        des_Port = rs.getString("des_Port");
                        notDesDevice = rs.getString("notDesDevice");
                        des_Device = rs.getString("des_Device");
                        Action = rs.getString("Action");

                        frag = rs.getString("frag");
                        syn = rs.getString("syn");

                        notfrag = rs.getString("notfrag");
                        notsyn = rs.getString("notsyn");
                        notflagmark = rs.getString("notflagmark");
                        flagmark = rs.getString("flagmark");
                        flagcomp = rs.getString("flagcomp");
                        nottcp_op = rs.getString("nottcp_op");
                        tcp_op = rs.getString("tcp_op");
                        noticmptype = rs.getString("noticmptype");
                        icmptype = rs.getString("icmptype");
                        match = rs.getString("matchs");

                       sdport = rs.getString("sdport");
                       markvalue = rs.getString("markvalue");
                       userid = rs.getString("userid");
                       groupid = rs.getString("groupid");
                       processid = rs.getString("processid");
                       sessionid = rs.getString("sessionid");
                       state = rs.getString("state");
                       tos = rs.getString("tos");
                       level = rs.getString("level");
                       prefix = rs.getString("prefix");

                       logseq = rs.getString("logseq");
                       logop = rs.getString("logop");
                       logipop = rs.getString("frag");
                       notmsource = rs.getString("notmsource");
                       msource = rs.getString("msource");
                       limit = rs.getString("limits");
                       limitrate = rs.getString("limitrate");
                       limitB = rs.getString("limitB");
                       limitBnum = rs.getString("limitBnum");
                       setmark = rs.getString("setmark");

                       rejecttype = rs.getString("rejecttype");
                       settos = rs.getString("settos");
                       to = rs.getString("natto");
                       tosource = rs.getString("tosource");
                       todes = rs.getString("todes");
                       toport = rs.getString("toport");
                       mul_sport = rs.getString("mul_sport");
                       mul_dport = rs.getString("mul_dport");



                        rs.next();

                        belowId = rs.getString("ID");
                        belowtablename = rs.getString("tablename");
                        belowChain = rs.getString("Chain");
                        belownotprotocal = rs.getString("notprotocal");
                        belowProtocal = rs.getString("Protocal");
                        belownotSrcIP = rs.getString("notSrcIP");
                        belowsrc_IP = rs.getString("src_IP");
                        belownotSrcPort = rs.getString("notSrcPort");
                        belowsrc_Port = rs.getString("src_Port");
                        belownotSrcPort = rs.getString("notSrcPort");
                        belownotSrcDevice = rs.getString("notSrcDevice");
                        belowsrc_Device = rs.getString("src_Device");
                        belownotDesIP = rs.getString("notDesIP");
                        belowdes_IP = rs.getString("des_IP");
                        belownotDesPort = rs.getString("notDesPort");
                        belowdes_Port = rs.getString("des_Port");
                        belownotDesDevice = rs.getString("notDesDevice");
                        belowdes_Device = rs.getString("des_Device");
                        belowAction = rs.getString("Action");

                        belowfrag = rs.getString("frag");
                        belowsyn = rs.getString("syn");

                        belownotfrag = rs.getString("notfrag");
                        belownotsyn = rs.getString("notsyn");
                        belownotflagmark = rs.getString("notflagmark");
                        belowflagmark = rs.getString("flagmark");
                        belowflagcomp = rs.getString("flagcomp");
                        belownottcp_op = rs.getString("nottcp_op");
                        belowtcp_op = rs.getString("tcp_op");
                        belownoticmptype = rs.getString("noticmptype");
                        belowicmptype = rs.getString("icmptype");
                        belowmatch = rs.getString("matchs");

                       belowsdport = rs.getString("sdport");
                       belowmarkvalue = rs.getString("markvalue");
                       belowuserid = rs.getString("userid");
                       belowgroupid = rs.getString("groupid");
                       belowprocessid = rs.getString("processid");
                       belowsessionid = rs.getString("sessionid");
                       belowstate = rs.getString("state");
                       belowtos = rs.getString("tos");
                       belowlevel = rs.getString("level");
                       belowprefix = rs.getString("prefix");

                       belowlogseq = rs.getString("logseq");
                       belowlogop = rs.getString("logop");
                       belowlogipop = rs.getString("frag");
                       belownotmsource = rs.getString("notmsource");
                       belowmsource = rs.getString("msource");
                       belowlimit = rs.getString("limits");
                       belowlimitrate = rs.getString("limitrate");
                       belowlimitB = rs.getString("limitB");
                       belowlimitBnum = rs.getString("limitBnum");
                       belowsetmark = rs.getString("setmark");

                       belowrejecttype = rs.getString("rejecttype");
                       belowsettos = rs.getString("settos");
                       belowto = rs.getString("natto");
                       belowtosource = rs.getString("tosource");
                       belowtodes = rs.getString("todes");
                       belowtoport = rs.getString("toport");
                       belowmul_sport = rs.getString("mul_sport");
                       belowmul_dport = rs.getString("mul_dport");



   //Update Top Row




          SQL = "UPDATE confige SET ";

          PK = " ID = "+Id+" ";

        SQL = SQL + " Chain='"+belowChain+"',Action='"+belowAction+"',src_IP='"+belowsrc_IP+"',src_Port='"+belowsrc_Port+"',src_Device='"+belowsrc_Device+"',des_IP='"+belowdes_IP+"',des_Device='"+belowdes_Device+"',notprotocal='"+belownotprotocal+"',Protocal='"+belowProtocal+"' "+
        ", notSrcIP='"+belownotSrcIP+"',notSrcPort='"+belownotSrcPort+"',notSrcDevice='"+belownotSrcDevice+"' ,notDesIP='"+belownotDesIP+"',notDesPort='"+belownotDesPort+"',notDesDevice='"+belownotDesDevice+"'" +
        ", tablename = '"+belowtablename+"',frag='"+belowfrag+"',syn='"+belowsyn+"',notfrag='"+belownotfrag+"',notsyn='"+belownotsyn+"',notflagmark='"+belownotflagmark+"',flagmark='"+belowflagmark+"',flagcomp='"+belowflagcomp+"' "+
        ", nottcp_op = '"+belownottcp_op+"',tcp_op='"+belowtcp_op+"',noticmptype='"+belownoticmptype+"',icmptype='"+belownoticmptype+"',matchs='"+belowmatch+"' ,notmsource='"+belownotmsource+"',msource='"+belowmsource+"',limits='"+belowlimit+"',limitrate='"+belowlimitrate+"',limitB='"+belowlimitB+"',limitBnum='"+belowlimitBnum+"' "+
        ", sdport = '"+belowsdport+"',markvalue='"+belowmarkvalue+"',userid='"+belowuserid+"',groupid='"+belowgroupid+"',processid='"+belowprocessid+"',sessionid='"+belowsessionid+"',state='"+belowstate+"',tos='"+belowtos+"',level='"+belowlevel+"',prefix='"+belowprefix+"',logseq='"+belowlogseq+"',logop='"+belowlogop+"',logipop='"+belowlogipop+"' "+
        ", setmark = '"+belowsetmark+"',rejecttype='"+belowrejecttype+"',settos='"+belowsettos+"',natto='"+belowto+"',tosource='"+belowtosource+"',todes='"+belowtodes+"',toport='"+belowtoport+"' ";

          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);

          //Update Row is Selected
          SQL="";
          SQL = "UPDATE confige SET ";

           SQL = SQL + " Chain='"+Chain+"',Action='"+Action+"',src_IP='"+src_IP+"',src_Port='"+src_Port+"',src_Device='"+src_Device+"',des_IP='"+des_IP+"',des_Device='"+des_Device+"',notprotocal='"+notprotocal+"',Protocal='"+Protocal+"' "+
           ", notSrcIP='"+notSrcIP+"',notSrcPort='"+notSrcPort+"',notSrcDevice='"+notSrcDevice+"' ,notDesIP='"+notDesIP+"',notDesPort='"+notDesPort+"',notDesDevice='"+notDesDevice+"'" +
           ", tablename = '"+tablename+"',frag='"+frag+"',syn='"+syn+"',notfrag='"+notfrag+"',notsyn='"+notsyn+"',notflagmark='"+notflagmark+"',flagmark='"+flagmark+"',flagcomp='"+flagcomp+"' "+
           ", nottcp_op = '"+nottcp_op+"',tcp_op='"+tcp_op+"',noticmptype='"+noticmptype+"',icmptype='"+noticmptype+"',matchs='"+match+"' ,notmsource='"+notmsource+"',msource='"+msource+"',limits='"+limit+"',limitrate='"+limitrate+"',limitB='"+limitB+"',limitBnum='"+limitBnum+"' "+
           ", sdport = '"+sdport+"',markvalue='"+markvalue+"',userid='"+userid+"',groupid='"+groupid+"',processid='"+processid+"',sessionid='"+sessionid+"',state='"+state+"',tos='"+tos+"',level='"+level+"',prefix='"+prefix+"',logseq='"+logseq+"',logop='"+logop+"',logipop='"+logipop+"' "+
           ", setmark = '"+setmark+"',rejecttype='"+rejecttype+"',settos='"+settos+"',natto='"+to+"',tosource='"+tosource+"',todes='"+todes+"',toport='"+toport+"' ";

          PK = " ID = "+belowId+" ";
          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);






          }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }

                }//if
                table.setRowSelectionInterval(ReturnRowSelect+1,ReturnRowSelect+1);
                refreshRecordTable();


      }

      public void moveUpRecord() {

        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,notprotocal,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice,sRuleNo="";
        String tablename,frag,syn, notfrag, notsyn,  notflagmark, flagmark, flagcomp = new String("");
        String nottcp_op, tcp_op, noticmptype, icmptype, match, notmsource, msource, limit, limitrate, limitB, limitBnum = new String("");
        String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
        String setmark, rejecttype, settos, to, tosource, todes, toport,mul_sport,mul_dport = new String("");

        String topId,topChain,topAction,topsrc_IP,topsrc_Port,topsrc_Device,topdes_IP,topdes_Port,topdes_Device,topnotprotocal,topProtocal;
        String topnotSrcIP,topnotSrcPort,topnotSrcDevice,topnotDesIP,topnotDesPort,topnotDesDevice,topsRuleNo="";
        String toptablename,topfrag,topsyn, topnotfrag, topnotsyn,  topnotflagmark, topflagmark, topflagcomp = new String("");
        String topnottcp_op, toptcp_op, topnoticmptype, topicmptype, topmatch, topnotmsource, topmsource, toplimit, toplimitrate, toplimitB, toplimitBnum = new String("");
        String topsdport, topmarkvalue, topuserid, topgroupid, topprocessid, topsessionid, topstate, toptos, toplevel, topprefix, toplogseq, toplogop, toplogipop = new String("");
        String topsetmark, toprejecttype, topsettos, topto, toptosource, toptodes, toptoport ,topmul_sport,topmul_dport= new String("");

        String PK;

        if(con!=null)        {
          try {
              //SQL = "SELECT * FROM confige order by ID";
              SQL = "SELECT * FROM confige Where Service not in ('icmpinputdrop','icmpforwarddrop','icmpechoinput','icmpechoinputdrop','icmpechoforward','icmpechoforwarddrop','icmptimeinput','icmptimeinputdrop','icmptimeforward','icmptimeforwarddrop','icmpotherinput','icmpotherinputdrop','icmpotherforward','icmpotherforwarddrop') or Service is null order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

           ReturnRowSelect=table.getSelectedRow();

              int row =0;
                            rs.first();

                              for (int i=0;i<ReturnRowSelect-1;i++){
                                  rs.next();
                                  row += 1;
                                }

                        topId = rs.getString("ID");
                        toptablename = rs.getString("tablename");
                        topChain = rs.getString("Chain");
                        topnotprotocal = rs.getString("notprotocal");
                        topProtocal = rs.getString("Protocal");
                        topnotSrcIP = rs.getString("notSrcIP");
                        topsrc_IP = rs.getString("src_IP");
                        topnotSrcPort = rs.getString("notSrcPort");
                        topsrc_Port = rs.getString("src_Port");
                        topnotSrcPort = rs.getString("notSrcPort");
                        topnotSrcDevice = rs.getString("notSrcDevice");
                        topsrc_Device = rs.getString("src_Device");
                        topnotDesIP = rs.getString("notDesIP");
                        topdes_IP = rs.getString("des_IP");
                        topnotDesPort = rs.getString("notDesPort");
                        topdes_Port = rs.getString("des_Port");
                        topnotDesDevice = rs.getString("notDesDevice");
                        topdes_Device = rs.getString("des_Device");
                        topAction = rs.getString("Action");

                        topfrag = rs.getString("frag");
                        topsyn = rs.getString("syn");

                        topnotfrag = rs.getString("notfrag");
                        topnotsyn = rs.getString("notsyn");
                        topnotflagmark = rs.getString("notflagmark");
                        topflagmark = rs.getString("flagmark");
                        topflagcomp = rs.getString("flagcomp");
                        topnottcp_op = rs.getString("nottcp_op");
                        toptcp_op = rs.getString("tcp_op");
                        topnoticmptype = rs.getString("noticmptype");
                        topicmptype = rs.getString("icmptype");
                        topmatch = rs.getString("matchs");

                       topsdport = rs.getString("sdport");
                       topmarkvalue = rs.getString("markvalue");
                       topuserid = rs.getString("userid");
                       topgroupid = rs.getString("groupid");
                       topprocessid = rs.getString("processid");
                       topsessionid = rs.getString("sessionid");
                       topstate = rs.getString("state");
                       toptos = rs.getString("tos");
                       toplevel = rs.getString("level");
                       topprefix = rs.getString("prefix");

                       toplogseq = rs.getString("logseq");
                       toplogop = rs.getString("logop");
                       toplogipop = rs.getString("logipop");
                       topnotmsource = rs.getString("notmsource");
                       topmsource = rs.getString("msource");
                       toplimit = rs.getString("limits");
                       toplimitrate = rs.getString("limitrate");
                       toplimitB = rs.getString("limitB");
                       toplimitBnum = rs.getString("limitBnum");
                       topsetmark = rs.getString("setmark");

                       toprejecttype = rs.getString("rejecttype");
                       topsettos = rs.getString("settos");
                       topto = rs.getString("natto");
                       toptosource = rs.getString("tosource");
                       toptodes = rs.getString("todes");
                       toptoport = rs.getString("toport");
                       topmul_sport = rs.getString("mul_sport");
                       topmul_dport = rs.getString("mul_dport");


                                  rs.next();
                        Id = rs.getString("ID");
                        tablename = rs.getString("tablename");
                        Chain = rs.getString("Chain");
                        notprotocal = rs.getString("notprotocal");
                        Protocal = rs.getString("Protocal");
                        notSrcIP = rs.getString("notSrcIP");
                        src_IP = rs.getString("src_IP");
                        notSrcPort = rs.getString("notSrcPort");
                        src_Port = rs.getString("src_Port");
                        notSrcPort = rs.getString("notSrcPort");
                        notSrcDevice = rs.getString("notSrcDevice");
                        src_Device = rs.getString("src_Device");
                        notDesIP = rs.getString("notDesIP");
                        des_IP = rs.getString("des_IP");
                        notDesPort = rs.getString("notDesPort");
                        des_Port = rs.getString("des_Port");
                        notDesDevice = rs.getString("notDesDevice");
                        des_Device = rs.getString("des_Device");
                        Action = rs.getString("Action");

                        frag = rs.getString("frag");
                        syn = rs.getString("syn");

                        notfrag = rs.getString("notfrag");
                        notsyn = rs.getString("notsyn");
                        notflagmark = rs.getString("notflagmark");
                        flagmark = rs.getString("flagmark");
                        flagcomp = rs.getString("flagcomp");
                        nottcp_op = rs.getString("nottcp_op");
                        tcp_op = rs.getString("tcp_op");
                        noticmptype = rs.getString("noticmptype");
                        icmptype = rs.getString("icmptype");
                        match = rs.getString("matchs");

                       sdport = rs.getString("sdport");
                       markvalue = rs.getString("markvalue");
                       userid = rs.getString("userid");
                       groupid = rs.getString("groupid");
                       processid = rs.getString("processid");
                       sessionid = rs.getString("sessionid");
                       state = rs.getString("state");
                       tos = rs.getString("tos");
                       level = rs.getString("level");
                       prefix = rs.getString("prefix");

                       logseq = rs.getString("logseq");
                       logop = rs.getString("logop");
                       logipop = rs.getString("logipop");
                       notmsource = rs.getString("notmsource");
                       msource = rs.getString("msource");
                       limit = rs.getString("limits");
                       limitrate = rs.getString("limitrate");
                       limitB = rs.getString("limitB");
                       limitBnum = rs.getString("limitBnum");
                       setmark = rs.getString("setmark");

                       rejecttype = rs.getString("rejecttype");
                       settos = rs.getString("settos");
                       to = rs.getString("natto");
                       tosource = rs.getString("tosource");
                       todes = rs.getString("todes");
                       toport = rs.getString("toport");
                       mul_sport = rs.getString("mul_sport");
                       mul_dport = rs.getString("mul_dport");


          //Update Top Row
          SQL = "UPDATE confige SET ";
           SQL = SQL + " Chain='"+topChain+"',Action='"+topAction+"',src_IP='"+topsrc_IP+"',src_Port='"+topsrc_Port+"',src_Device='"+topsrc_Device+"',des_IP='"+topdes_IP+"',des_Device='"+topdes_Device+"',notprotocal='"+topnotprotocal+"',Protocal='"+topProtocal+"' "+
        ", notSrcIP='"+topnotSrcIP+"',notSrcPort='"+topnotSrcPort+"',notSrcDevice='"+topnotSrcDevice+"' ,notDesIP='"+topnotDesIP+"',notDesPort='"+topnotDesPort+"',notDesDevice='"+topnotDesDevice+"'" +
        ", tablename = '"+toptablename+"',frag='"+topfrag+"',syn='"+topsyn+"',notfrag='"+topnotfrag+"',notsyn='"+topnotsyn+"',notflagmark='"+topnotflagmark+"',flagmark='"+topflagmark+"',flagcomp='"+topflagcomp+"' "+
        ", nottcp_op = '"+topnottcp_op+"',tcp_op='"+toptcp_op+"',noticmptype='"+topnoticmptype+"',icmptype='"+topnoticmptype+"',matchs='"+topmatch+"' ,notmsource='"+topnotmsource+"',msource='"+topmsource+"',limits='"+toplimit+"',limitrate='"+toplimitrate+"',limitB='"+toplimitB+"',limitBnum='"+toplimitBnum+"' "+
        ", sdport = '"+topsdport+"',markvalue='"+topmarkvalue+"',userid='"+topuserid+"',groupid='"+topgroupid+"',processid='"+topprocessid+"',sessionid='"+topsessionid+"',state='"+topstate+"',tos='"+toptos+"',level='"+toplevel+"',prefix='"+topprefix+"',logseq='"+toplogseq+"',logop='"+toplogop+"',logipop='"+toplogipop+"' "+
        ", setmark = '"+topsetmark+"',rejecttype='"+toprejecttype+"',settos='"+topsettos+"',natto='"+topto+"',tosource='"+toptosource+"',todes='"+toptodes+"',toport='"+toptoport+"',mul_sport='"+topmul_sport+"',mul_dport='"+topmul_dport+"' ";
          PK = " ID = "+Id+" ";
          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);

          //Update Row is Selected
          SQL="";
          SQL = "UPDATE confige SET ";

           SQL = SQL + " Chain='"+Chain+"',Action='"+Action+"',src_IP='"+src_IP+"',src_Port='"+src_Port+"',src_Device='"+src_Device+"',des_IP='"+des_IP+"',des_Device='"+des_Device+"',notprotocal='"+notprotocal+"',Protocal='"+Protocal+"' "+
           ", notSrcIP='"+notSrcIP+"',notSrcPort='"+notSrcPort+"',notSrcDevice='"+notSrcDevice+"' ,notDesIP='"+notDesIP+"',notDesPort='"+notDesPort+"',notDesDevice='"+notDesDevice+"'" +
           ", tablename = '"+tablename+"',frag='"+frag+"',syn='"+syn+"',notfrag='"+notfrag+"',notsyn='"+notsyn+"',notflagmark='"+notflagmark+"',flagmark='"+flagmark+"',flagcomp='"+flagcomp+"' "+
           ", nottcp_op = '"+nottcp_op+"',tcp_op='"+tcp_op+"',noticmptype='"+noticmptype+"',icmptype='"+noticmptype+"',matchs='"+match+"' ,notmsource='"+notmsource+"',msource='"+msource+"',limits='"+limit+"',limitrate='"+limitrate+"',limitB='"+limitB+"',limitBnum='"+limitBnum+"' "+
           ", sdport = '"+sdport+"',markvalue='"+markvalue+"',userid='"+userid+"',groupid='"+groupid+"',processid='"+processid+"',sessionid='"+sessionid+"',state='"+state+"',tos='"+tos+"',level='"+level+"',prefix='"+prefix+"',logseq='"+logseq+"',logop='"+logop+"',logipop='"+logipop+"' "+
           ", setmark = '"+setmark+"',rejecttype='"+rejecttype+"',settos='"+settos+"',natto='"+to+"',tosource='"+tosource+"',todes='"+todes+"',toport='"+toport+"',mul_sport='"+mul_sport+"',mul_dport='"+mul_dport+"' ";

          PK = " ID = "+topId+" ";
          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);


                                  //row += 1;
				 //rs.next();
                                //  }//while
                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }

                }//if
                table.setRowSelectionInterval(ReturnRowSelect-1,ReturnRowSelect-1);
                refreshRecordTable();

      }


       public static void refreshRecordTable() {
        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice,sRuleNo="",notprotocol;
        int RuleNo;
        ResultSet tmprs;


        if(con!=null)
        {
          try {
              SQL = "SELECT * FROM confige Where Service not in ('icmpinputdrop','icmpforwarddrop','icmpechoinput','icmpechoinputdrop','icmpechoforward','icmpechoforwarddrop','icmptimeinput','icmptimeinputdrop','icmptimeforward','icmptimeforwarddrop','icmpotherinput','icmpotherinputdrop','icmpotherforward','icmpotherforwarddrop') or Service is null order by ID";
              //SQL = "SELECT * FROM Confige Where Service is null order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);


         listModel.clearData();
              int row =0;

                            rs.first();

                             while (rs.next()) {
                                  rs.previous();
                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  notprotocol = rs.getString("notprotocal");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Chain,row,1);
                                  listModel.setValueAt(notprotocol,row,2);
                                  listModel.setValueAt(Protocal,row,3);
                                  listModel.setValueAt(notSrcPort,row,4);
                                  listModel.setValueAt(src_IP,row,5);
                                  listModel.setValueAt(notSrcPort,row,6);
                                  listModel.setValueAt(src_Port,row,7);
                                  listModel.setValueAt(notSrcDevice,row,8);
                                  listModel.setValueAt(src_Device,row,9);
                                  listModel.setValueAt(notDesIP,row,10);
                                  listModel.setValueAt(des_IP,row,11);
                                  listModel.setValueAt(notDesPort,row,12);
                                  listModel.setValueAt(des_Port,row,13);
                                  listModel.setValueAt(notDesDevice,row,14);
                                  listModel.setValueAt(des_Device,row,15);
                                  listModel.setValueAt(Action,row,16);

                                  row += 1;
                                  rs.next();
                                  }//while

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  notprotocol = rs.getString("notprotocal");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Chain,row,1);
                                  listModel.setValueAt(notprotocol,row,2);
                                  listModel.setValueAt(Protocal,row,3);
                                  listModel.setValueAt(notSrcPort,row,4);
                                  listModel.setValueAt(src_IP,row,5);
                                  listModel.setValueAt(notSrcPort,row,6);
                                  listModel.setValueAt(src_Port,row,7);
                                  listModel.setValueAt(notSrcDevice,row,8);
                                  listModel.setValueAt(src_Device,row,9);
                                  listModel.setValueAt(notDesIP,row,10);
                                  listModel.setValueAt(des_IP,row,11);
                                  listModel.setValueAt(notDesPort,row,12);
                                  listModel.setValueAt(des_Port,row,13);
                                  listModel.setValueAt(notDesDevice,row,14);
                                  listModel.setValueAt(des_Device,row,15);
                                  listModel.setValueAt(Action,row,16);

                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh

                    class clickedDelete implements ActionListener {
                        public void actionPerformed(ActionEvent e) {

                                statusChange = true;
                                int Id;
                                String SQL="",Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;

                                       ReturnRowSelect= table.getSelectedRow();
                                       System.out.println("Return Row ......."+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getInt("ID");
                                    Chain = rs.getString("Chain");
                                    src_IP = rs.getString("src_IP");
                                    src_Port = rs.getString("src_Port");
                                    src_Device = rs.getString("src_Device");
                                    des_IP = rs.getString("des_IP");
                                    des_Port = rs.getString("des_Port");
                                    des_Device = rs.getString("des_Device");
                                    Protocal = rs.getString("Protocal");
                                    Action = rs.getString("Action");

		                SQL = "DELETE FROM " + tableName + " WHERE ";

                                                            SQL = SQL +  "ID =  "+Id+" ";

		db.SQLExecute(SQL);
		System.out.println(SQL);

                                      }

                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                listModel.clearData();
                                refreshRecordTable();

                                }
                          }//end delete record


  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
  //  super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
     System.exit(0);
    }
  }
  }// end class