package testmysql;

import java.sql.*;

public class DBUtil {

	private String ODBCName = null;
	public static Connection con = null;
	public static ResultSet rs = null;
                             public static boolean f_rollback=true;
                             public static boolean not_ok_confirm=true;
                             public static int loadfirst=1;




	public String ErrMessage;

	DBUtil()  {
	//	JDBCType = type;
//		try {

try {
    Class.forName("org.gjt.mm.mysql.Driver").newInstance();
} catch(Exception e) {
    e.printStackTrace();
}
	}

	public Connection Establish() {
		try {
			 //con = DriverManager.getConnection(s, u, p);
			 con = DriverManager.getConnection("jdbc:mysql://localhost/proj?user=root&password=kengss228");
			return con;
		} catch (Exception e) {
				e.printStackTrace();
			return null;
		}
	}

	public boolean SQLExecute(String query) {
		int i=0;
                                                  try {
                                                                if (loadfirst==1) {
                                                                   //con = DriverManager.getConnection(seturl,setuser,setpassword);
                                                                   con = DriverManager.getConnection("jdbc:mysql://localhost/proj?user=root&password=kengss228");

                                                                  loadfirst = 0;
                                                                 }

                	                                      PreparedStatement stmt = con.prepareStatement(query);

                                                                    if (not_ok_confirm) {
                                                                          con.setAutoCommit(false);
                                                                        //  SET AUTOCOMMIT=1;

                                                                          //SET AUTOCOMMIT=0;
                                                                        i = stmt.executeUpdate();
                                                                    }
                                                                    else {
                                                                        con.commit();
                                                                     }
                                                                                        stmt.close();
                                                                                              if (i>0)
                                                                                                  return true;
			else
		                                        return false;
		} catch (SQLException E) {
			System.out.println("SQLException: " + E.getMessage());
            System.out.println("SQLState:     " + E.getSQLState());
            System.out.println("VendorError:  " + E.getErrorCode());
			return false;
		}
	}

	public ResultSet SQLRetrive(String query) {
 		try {
			Statement stmt = con.createStatement();
			 rs = stmt.executeQuery(query);
			return rs;
		} catch (SQLException ex) {
			ErrMessage = ex.getMessage();
			System.out.println(ErrMessage);
			return null;
		}
	}

	public void Close() {
		try {
		 con.close();
		} catch (SQLException ex) {
			ErrMessage = ex.getMessage();
			System.out.println(ErrMessage);
		}
	}
}