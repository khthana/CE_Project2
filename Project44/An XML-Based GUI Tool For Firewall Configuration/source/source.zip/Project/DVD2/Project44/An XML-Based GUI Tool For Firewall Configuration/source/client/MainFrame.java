import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.crypto.interfaces.*;
import org.bouncycastle.jce.provider.*;

public class MainFrame extends JFrame {

  private ObjectOutputStream output;
  private ObjectInputStream input;
  private ServerSocket server;
  private Socket connection;
  private int counter = 1;

  JPanel contentPane;
  XYLayout xYLayout1 = new XYLayout();
  JTextArea displayArea = new JTextArea();
  JTextField enterField = new JTextField();

  /**Construct the frame*/
  public MainFrame() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(MainFrame.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    displayArea.setFont(new java.awt.Font("SansSerif", 0, 12));
    displayArea.setBorder(null);
    displayArea.setText("diaplayArea");
    contentPane.setFont(new java.awt.Font("SansSerif", 0, 12));
    contentPane.setLayout(xYLayout1);
    this.setSize(new Dimension(400, 300));
    this.setTitle("Server Main Frame");
    enterField.setBorder(null);
    enterField.setText("enterField");
    enterField.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        enterField_actionPerformed(e);
      }
    });
    contentPane.add(displayArea, new XYConstraints(16, 15, 368, 178));
    contentPane.add(enterField,  new XYConstraints(15, 209, 370, 25));
  }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
    // set up and run server
  public void runServer()
  {
    displayArea.append("joel");
    // set up server to receive connection
    // process connections
    try {
      // step 1: create a serversocket
      server = new ServerSocket(7123, 1);
      while(true) {
        // step 2: wait for a connection
        waitForConnection();
        // step 3: get input and output streams
        getStreams();
        // step 4: process connection
        processConnection();
        // step 5: close connection
        closeConnection();

        ++counter;
        }
      }
      // process eofexception when client colsed connection
      catch(EOFException eofException)  {
        System.out.println("client terminated connection");
      }
      // process problems with i/o
      catch(IOException ioException)  {
        ioException.printStackTrace();
      }
    }
    // wait for connection to arrive, then display connection info
    private void waitForConnection() throws IOException
    {
      displayArea.setText("waiting for connection\n");
      // allow server to accept a connection
      connection = server.accept();
      displayArea.append("connection "+counter+" received from: "+connection.getInetAddress().getHostName());
    }
    // get streams to send and receive data
    private void getStreams() throws IOException
    {
      // set up output stream for objects
      output = new ObjectOutputStream(connection.getOutputStream());
      // flush output buffer to send header information
      output.flush();
      // set up input stream for objects
      input = new ObjectInputStream(connection.getInputStream());

      displayArea.append("\ngot i/o streams\n");
    }
    // process connection with client
    private void processConnection() throws IOException
    {
      // send connection successful message to client
      String message = "server>>> connection successful";
      //output.writeObject(message);
      //output.flush();
      // enable enterfield so server user can send messages
      enterField.setEnabled(true);
      //process messages sent from client
      do  {
        // read message and display it
        try {
          message = (String)input.readObject();
          displayArea.append("\n"+message);
          displayArea.setCaretPosition(displayArea.getText().length());
        }
        // catch problem reading from client
        catch(ClassNotFoundException classNotFoundException) {
          displayArea.append("\nunknown object type received");
        }
      } while (!message.equals("client>>> terminate"));
    }
    // close streams and socket
    private void closeConnection() throws IOException
    {
      displayArea.append("\nuser terminated connection");
      enterField.setEnabled(false);
      output.close();
      input.close();
      connection.close();
    }
  void enterField_actionPerformed(ActionEvent e) {
    sendData(e.getActionCommand());
  }
  // send message to client
  private void sendData(String message)
  { Security.addProvider(new  BouncyCastleProvider());
    byte[] secDataB = message.getBytes();
    try {
      // get public key from file
      FileInputStream	fis = new	FileInputStream("pubKey.enc");
      byte[]	pubKeyB = new	byte[fis.available()];
      fis.read(pubKeyB);
      fis.close();
      X509EncodedKeySpec	keySpec = new	X509EncodedKeySpec(pubKeyB);
      KeyFactory	keyFac = KeyFactory.getInstance("RSA", "BC");
      PublicKey pubKey = keyFac.generatePublic(keySpec);
      // create cipher which used to encrypt
      Cipher  encCipher = Cipher.getInstance("RSA", "BC");
      encCipher.init(Cipher.ENCRYPT_MODE, pubKey);
      // encrypt message
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      int k = (((RSAPublicKey)pubKey).getModulus().bitLength()+7) >>> 3;
      int maxSize = k -11;
      int inOff = 0;
      while(true){
        int leftToDo = secDataB.length - inOff;
        if(leftToDo <= 0)	{
          break;
        }
        int chunkSize = (leftToDo > maxSize ? maxSize: leftToDo);
        encCipher.update(secDataB, inOff, chunkSize);
        baos.write(encCipher.doFinal());
        inOff += chunkSize;
      }
      // get data from buffer
      byte[] encDataB = baos.toByteArray();
      baos.flush();
      System.out.println("Encrypted Data: ");
      System.out.println((new String(encDataB)) + "***");
      System.out.println(encDataB.length);
      // send encrypted data to client
      output.write(encDataB);
      output.flush();
      displayArea.append("\n server>>> " + message);
    }
    catch(Exception ex) { System.out.println("caught exception: " + ex);
    }
  }
}