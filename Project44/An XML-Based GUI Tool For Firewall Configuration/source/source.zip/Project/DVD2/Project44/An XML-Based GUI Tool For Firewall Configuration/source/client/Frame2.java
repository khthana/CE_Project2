import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import javax.swing.plaf.*;
import java.awt.image.*;
import java.awt.Frame;
import com.borland.jbcl.layout.*;
import java.util.EventObject;
import javax.swing.border.*;
import java.sql.*;

public class Frame2 extends JFrame {

  ManagePanel manpanel = new ManagePanel();
  LockPassword lockpasswd = new LockPassword();
  ChangePasswd changepasswd = new ChangePasswd();
  public static JPanel contentPane;
  public static boolean nextcard = false;
  TreePanel tpanel = new TreePanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel mainPanel = new JPanel();
  JPanel selectPanel = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  public static JPanel cardPanel = new JPanel();
  public static CardLayout cardLayout1 = new CardLayout();

 JPanel n1cardPanel = new JPanel();
 JPanel n2cardPanel = new JPanel();

 JPanel updateSearchPanel = new JPanel();
 JPanel updatePanelp = new JPanel();

 JPanel ftptcpPanel = new JPanel();
 JPanel ftpdatatcpPanel = new JPanel();
 JPanel telnettcpPanel = new JPanel();
 JPanel sshtcpPanel = new JPanel();
 JPanel dnstcpPanel = new JPanel();
 JPanel httptcpPanel = new JPanel();
 JPanel smtptcpPanel = new JPanel();
 JPanel pop3tcpPanel = new JPanel();

 JPanel ftpudpPanel = new JPanel();
 JPanel ftpdataudpPanel = new JPanel();
 JPanel telnetudpPanel = new JPanel();
 JPanel sshudpPanel = new JPanel();
 JPanel dnsudpPanel = new JPanel();
 JPanel httpudpPanel = new JPanel();
 JPanel smtpudpPanel = new JPanel();
 JPanel pop3udpPanel = new JPanel();

  JPanel natPanel = new JPanel();
  JPanel texteditorPanel = new JPanel();
  JPanel chatPanel = new JPanel();
  JPanel remotecontrolPanel = new JPanel();
  JPanel optionspanelP = new JPanel();

  JPanel definechainPanel = new JPanel();
  JPanel definevarPanel = new JPanel();
  JPanel icmpPanel = new JPanel();


  OptionsPanel  optionspanel = new OptionsPanel();
  DBConverttoXML dbtoxml = new DBConverttoXML();
  jXml jxml = new jXml();

  Nat nat = new Nat();

  FtpTcp ftptcp = new FtpTcp();
  FtpdataTcp ftpdatatcp = new FtpdataTcp();
  TelnetTcp telnettcp = new   TelnetTcp();
  SshTcp sshtcp = new SshTcp();
  DnsTcp dnstcp = new DnsTcp();
  HttpTcp httptcp = new HttpTcp();
  SmtpTcp smtptcp = new SmtpTcp();
  pop3Tcp pop3tcp = new pop3Tcp();

  FtpUdp ftpudp = new FtpUdp();
  FtpdataUdp ftpdataudp = new FtpdataUdp();
  TelnetUdp telnetudp = new   TelnetUdp();
  SshUdp sshudp = new SshUdp();
  DnsUdp dnsudp = new DnsUdp();
  HttpUdp httpudp = new HttpUdp();
  SmtpUdp smtpudp = new SmtpUdp();
  pop3Udp pop3udp = new pop3Udp();

  Icmp icmp = new Icmp();


  RemoteControl remotecontrol = new RemoteControl();
  ClientChat clientchat = new ClientChat("127.0.0.1");



  DefineVar definevar = new DefineVar();
  DefineChain definechain = new DefineChain();


   TextEdit textedit = new TextEdit();

   SearchUpdatePanel updatesearch = new SearchUpdatePanel();
   UpdatePanel updatePanel = new UpdatePanel();

  public  static JTabbedPane tabbedPaneMain = new JTabbedPane();
  public  static JTabbedPane tabbedPaneSearch = new JTabbedPane();
  public  static JTabbedPane tabbedPane1 = new JTabbedPane();

 JButton tbLockButton = new JButton(new ImageIcon("images/Lock.png"));
 JButton tbUnLockButton = new JButton(new ImageIcon("images/UnLock.png"));
 JButton tbPlugButton = new JButton(new ImageIcon("images/Plug.png"));
 JButton tbUnPlugButton = new JButton(new ImageIcon("images/UnPlug.png"));
 JButton tbSaveDBButton = new JButton(new ImageIcon("images/SaveDB.png"));
 JButton tbUserButton = new JButton(new ImageIcon("images/User.png"));
 JButton tbRefreshButton = new JButton(new ImageIcon("images/Refresh.png"));
 JButton tbResetButton = new JButton(new ImageIcon("images/Reset.png"));
 JButton tbApplyButton = new JButton(new ImageIcon("images/Apply.png"));
 JButton tbSearchButton = new JButton(new ImageIcon("images/Search.png"));
 JButton tbOptionsButton = new JButton(new ImageIcon("images/Options.gif"));
 JButton tbChatButton = new JButton(new ImageIcon("images/ChatIcon.gif"));
 JButton tbDefineVarButton = new JButton(new ImageIcon("images/DefineVar.png"));
 JButton tbTextEditorButton = new JButton(new ImageIcon("images/TextEdit.png"));
 JButton tbRemoteButton = new JButton(new ImageIcon("images/Remote.gif"));
 JButton tbBlackListButton = new JButton(new ImageIcon("images/BlackList.gif"));
 JButton tbFullScreenButton = new JButton(new ImageIcon("images/FullScreen.gif"));


  Color color[] = {Color.gray,null};
  String tabsImagesMain[] = {"images/Sheet.png","images/UpdateSheet.png"};
  String tabsMain[] = {"All Rule       ","Update         "};
  String tabsImagesSearch ="images/SearchRow.gif";
  String tabsSearch[] = {"Action      ","Chain       ","IP          ","Port        ","Protocal    ","Update      "};
  JPanel tabsPaneSearch[] = {new ActionSearch(),new ChainSearch(),new IPSearch(),new PortSearch(),new ProtocalSearch(),updateSearchPanel};

  JPanel tabsPaneMain[] = {new ManagePanel(),updatePanelp};
  JToolBar toolBar = new JToolBar();
  FlowLayout flowLayout1 = new FlowLayout();
  BorderLayout borderLayout3 = new BorderLayout();
  TitledBorder titledBorder1;
  BorderLayout borderLayout5 = new BorderLayout();
  BorderLayout borderLayout4 = new BorderLayout();

  /**Construct the frame*/
  public Frame2() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception  {

    titledBorder1 = new TitledBorder("");
    UIManager.put("JTabbedPane.selected", Color.green);
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame2.class.getResource("images/Add.png")));

    toolBar.setBackground(new Color(236, 233, 230));
    updateSearchPanel.setBackground(new Color(236,233,230));


    selectPanel.setLayout(borderLayout4);
    selectPanel.setBackground(Color.white);
   // toolBar.add(tbApplyButton);
   // toolBar.add(tbLockButton);
   // toolBar.add(tbUnLockButton);
    toolBar.add(tbPlugButton);
  //  toolBar.add(tbUnPlugButton);
  //  toolBar.add(tbSaveDBButton);
  //  toolBar.add(tbUserButton);
    toolBar.add(tbRefreshButton);
    toolBar.add(tbResetButton);
    toolBar.add(tbApplyButton);
    toolBar.add(tbSearchButton);
    toolBar.add(tbOptionsButton);
    toolBar.add(tbChatButton);
    toolBar.add(tbDefineVarButton);
    toolBar.add(tbTextEditorButton);
    toolBar.add(tbRemoteButton);
    toolBar.add(tbBlackListButton);
    toolBar.add(tbFullScreenButton);

    tbLockButton.setToolTipText("Lock Password");
    tbPlugButton.setToolTipText("Connect");
    tbUnPlugButton.setToolTipText("Disconnect");
    tbSaveDBButton.setToolTipText("Load to Program");
    tbUserButton.setToolTipText("Change User&Password");
    tbRefreshButton.setToolTipText("Refresh");
    tbResetButton.setToolTipText("Reset");
    tbApplyButton.setToolTipText("Apply");
    tbSearchButton.setToolTipText("Search");
    tbOptionsButton.setToolTipText("Options");
    tbChatButton.setToolTipText("Chat");
    tbDefineVarButton.setToolTipText("Define Var");
    tbTextEditorButton.setToolTipText("Text Editor");
    tbRemoteButton.setToolTipText("Remote Control");
    tbBlackListButton.setToolTipText("BlackList");
    tbFullScreenButton.setToolTipText("FullScreen");

    tbFullScreenButton.setBackground(new Color(236,233,230));

    ImageIcon icon = new ImageIcon(("images/Workstation.gif"));
    this.setIconImage(icon.getImage());

    TreePanel tree = new TreePanel();
    JPanel treeselect =new JPanel();

    JPanel treePanel = new JPanel();

    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.getContentPane().setBackground(Color.lightGray);
    this.setSize(new Dimension(853, 533));


    icmp.setLayout(flowLayout1);
    icmpPanel.setLayout(new BorderLayout());
    icmpPanel.add(icmp,BorderLayout.CENTER);

    definechain.setLayout(flowLayout1);
    definechainPanel.setLayout(new BorderLayout());
    definechainPanel.add(definechain,BorderLayout.CENTER) ;

    definevar.setLayout(flowLayout1);
    definevarPanel.setLayout(new BorderLayout());
    definevarPanel.add(definevar,BorderLayout.CENTER) ;

    textedit.setLayout(flowLayout1);
    texteditorPanel.setLayout(new BorderLayout());
    texteditorPanel.add(textedit,  BorderLayout.CENTER);

    optionspanel.setLayout(flowLayout1);
    optionspanelP.setLayout(new BorderLayout());
    optionspanelP.add(optionspanel,  BorderLayout.CENTER);

    nat.setLayout(flowLayout1);
    natPanel.setLayout(new BorderLayout());
    natPanel.add(nat,  BorderLayout.CENTER);

    ftptcp.setLayout(flowLayout1);
    ftptcpPanel.setLayout(new BorderLayout());
    ftptcpPanel.add(ftptcp,  BorderLayout.CENTER);

    ftpdatatcp.setLayout(flowLayout1);
    ftpdatatcpPanel.setLayout(new BorderLayout());
    ftpdatatcpPanel.add(ftpdatatcp,  BorderLayout.CENTER);

    telnettcp.setLayout(flowLayout1);
    telnettcpPanel.setLayout(new BorderLayout());
    telnettcpPanel.add(telnettcp,  BorderLayout.CENTER);

    sshtcp.setLayout(flowLayout1);
    sshtcpPanel.setLayout(new BorderLayout());
    sshtcpPanel.add(sshtcp,  BorderLayout.CENTER);

    dnstcp.setLayout(flowLayout1);
    dnstcpPanel.setLayout(new BorderLayout());
    dnstcpPanel.add(dnstcp,  BorderLayout.CENTER);

    httptcp.setLayout(flowLayout1);
    httptcpPanel.setLayout(new BorderLayout());
    httptcpPanel.add(httptcp,  BorderLayout.CENTER);

    smtptcp.setLayout(flowLayout1);
    smtptcpPanel.setLayout(new BorderLayout());
    smtptcpPanel.add(smtptcp,  BorderLayout.CENTER);

    pop3tcp.setLayout(flowLayout1);
    pop3tcpPanel.setLayout(new BorderLayout());
    pop3tcpPanel.add(pop3tcp,  BorderLayout.CENTER);

    ftpudp.setLayout(flowLayout1);
    ftpudpPanel.setLayout(new BorderLayout());
    ftpudpPanel.add(ftpudp,  BorderLayout.CENTER);

    ftpdataudp.setLayout(flowLayout1);
    ftpdataudpPanel.setLayout(new BorderLayout());
    ftpdataudpPanel.add(ftpdataudp,  BorderLayout.CENTER);

    telnetudp.setLayout(flowLayout1);
    telnetudpPanel.setLayout(new BorderLayout());
    telnetudpPanel.add(telnetudp,  BorderLayout.CENTER);

    sshudp.setLayout(flowLayout1);
    sshudpPanel.setLayout(new BorderLayout());
    sshudpPanel.add(sshudp,  BorderLayout.CENTER);

    dnsudp.setLayout(flowLayout1);
    dnsudpPanel.setLayout(new BorderLayout());
    dnsudpPanel.add(dnsudp,  BorderLayout.CENTER);

    httpudp.setLayout(flowLayout1);
    httpudpPanel.setLayout(new BorderLayout());
    httpudpPanel.add(httpudp,  BorderLayout.CENTER);

    smtpudp.setLayout(flowLayout1);
    smtpudpPanel.setLayout(new BorderLayout());
    smtpudpPanel.add(smtpudp,  BorderLayout.CENTER);

    pop3udp.setLayout(flowLayout1);
    pop3udpPanel.setLayout(new BorderLayout());
    pop3udpPanel.add(pop3udp,  BorderLayout.CENTER);

    clientchat.setLayout(flowLayout1);
    chatPanel.setLayout(new BorderLayout());
    chatPanel.add(clientchat,  BorderLayout.CENTER);


    remotecontrol.setLayout(flowLayout1);
    remotecontrolPanel.setLayout(new BorderLayout());
    remotecontrolPanel.add(remotecontrol,BorderLayout.CENTER);

    this.setTitle("KJ iptables Firewall Builder");

    mainPanel.setLayout(borderLayout2);
    n1cardPanel.setLayout(new BorderLayout());
    n2cardPanel.setLayout(new BorderLayout());
    cardPanel.setLayout(cardLayout1);
    cardPanel.setBorder(BorderFactory.createEtchedBorder());
    contentPane.setBorder(BorderFactory.createEtchedBorder());
    selectPanel.setBorder(BorderFactory.createEtchedBorder());
    selectPanel.setPreferredSize(new Dimension(180, 538));
    treePanel.setLayout(borderLayout5);
    treePanel.setPreferredSize(new Dimension(130, 200));


    updateSearchPanel.add(updatesearch,BorderLayout.CENTER);
    updatePanelp.add(updatePanel,BorderLayout.CENTER);
    updatePanelp.setBackground(new Color(236,233,230));

   for(int i=0;i<tabsMain.length;i++) {
        tabbedPaneMain.addTab(tabsMain[i],new ImageIcon(tabsImagesMain[i]),tabsPaneMain[i]);
        tabbedPaneMain.setBackgroundAt(i,color[i]);
  }



  for(int i=0;i<tabsSearch.length;i++) {
        tabbedPaneSearch.addTab(tabsSearch[i],new ImageIcon(tabsImagesSearch),tabsPaneSearch[i]);
  }

    tabbedPaneSearch.setBackground(new Color(236,233,230));
    //contentPane.add(new UpdatePanel());
    tabbedPaneMain.setBackground(new Color(236, 233, 230));
    n1cardPanel.setBackground(new Color(236,233,230));
    n2cardPanel.setBackground(new Color(236, 233, 230));
    contentPane.add(mainPanel, BorderLayout.CENTER);

    mainPanel.add(selectPanel,  BorderLayout.WEST);
    selectPanel.add(treePanel, BorderLayout.CENTER);
    treePanel.add(tpanel, null);

    n1cardPanel.add(tabbedPaneMain,BorderLayout.CENTER);
    n2cardPanel.add(tabbedPaneSearch,BorderLayout.CENTER);


   cardPanel.add("main",n1cardPanel);
   cardPanel.add("search",n2cardPanel);
   cardPanel.add("textedit",texteditorPanel);
   cardPanel.add("options",optionspanelP);
   cardPanel.add("four",dbtoxml);

   cardPanel.add("chat",chatPanel);
  // cardPanel.add("connection",jxml);

   cardPanel.add("ftpTcp",ftptcpPanel);
   cardPanel.add("ftpdataTcp",ftpdatatcpPanel);
   cardPanel.add("telnetTcp",telnettcpPanel);
   cardPanel.add("sshTcp",sshtcpPanel);
   cardPanel.add("dnsTcp",dnstcpPanel);
   cardPanel.add("httpTcp",httptcpPanel);
   cardPanel.add("smtpTcp",smtptcpPanel);
   cardPanel.add("pop3Tcp",pop3tcpPanel);

   cardPanel.add("ftpUdp",ftpudpPanel);
   cardPanel.add("ftpdataUdp",ftpdataudpPanel);
   cardPanel.add("telnetUdp",telnetudpPanel);
   cardPanel.add("sshUdp",sshudpPanel);
   cardPanel.add("dnsUdp",dnsudpPanel);
   cardPanel.add("httpUdp",httpudpPanel);
   cardPanel.add("smtpUdp",smtpudpPanel);
   cardPanel.add("pop3Udp",pop3udpPanel);

   cardPanel.add("remotecontrol",remotecontrolPanel);
   cardPanel.add("icmp",icmpPanel);

   cardPanel.add("Nat",natPanel);



   cardPanel.add("definechain",definechainPanel);
   cardPanel.add("definevar",definevarPanel);
   contentPane.add(toolBar, BorderLayout.NORTH);

   tbApplyButton.addActionListener(new clickedtbApplyButton());
   tbLockButton.addActionListener(new clickedtbLockButton());
   tbUnLockButton.addActionListener(new clickedtbUnLockButton());
   tbPlugButton.addActionListener(new clickedtbPlugButton());
   tbUnPlugButton.addActionListener(new clickedtbUnPlugButton());
   tbSaveDBButton.addActionListener(new clickedtbSaveDBButton());
   tbUserButton.addActionListener(new clickedtbUserButton());
   tbRefreshButton.addActionListener(new clickedtbRefreshButton());
   tbResetButton.addActionListener(new clickedtbResetButton());
   tbSearchButton.addActionListener(new clickedtbSearchButton());
   tbOptionsButton.addActionListener(new clickedtbOptionsButton());
   tbChatButton.addActionListener(new clickedtbChatButton());
   tbDefineVarButton.addActionListener(new clickedtbDefineVarButton());
   tbTextEditorButton.addActionListener(new clickedtbTextEditorButton());
   tbRemoteButton.addActionListener(new clickedtbRemoteButton());
   tbBlackListButton.addActionListener(new clickedtbBlackListButton());
   tbFullScreenButton.addActionListener(new clickedtbFullScreenButton());

   tbApplyButton.setBackground(new Color(236,233,230));
   tbLockButton.setBackground(new Color(236,233,230));
   tbUnLockButton.setBackground(new Color(236,233,230));
   tbPlugButton.setBackground(new Color(236,233,230));
   tbUnPlugButton.setBackground(new Color(236,233,230));
   tbSaveDBButton.setBackground(new Color(236,233,230));
   tbUserButton.setBackground(new Color(236,233,230));
   tbRefreshButton.setBackground(new Color(236,233,230));
   tbResetButton.setBackground(new Color(236,233,230));
   tbSearchButton.setBackground(new Color(236,233,230));
   tbOptionsButton.setBackground(new Color(236,233,230));
   tbChatButton.setBackground(new Color(236,233,230));
   tbDefineVarButton.setBackground(new Color(236,233,230));
   tbTextEditorButton.setBackground(new Color(236,233,230));
   tbRemoteButton.setBackground(new Color(236,233,230));
   tbBlackListButton.setBackground(new Color(236,233,230));

    mainPanel.add(cardPanel, BorderLayout.CENTER);
    setJMenuBar(new Menu());

   this.setEnabled(false);
   this.setResizable(false);


   DefineChain.refreshDefineChaintComboBox();

   tabbedPaneMain.setEnabledAt(1,false);
   tabbedPaneMain.setBackgroundAt(0,new Color(236,233,230));
   tabbedPaneMain.setBackgroundAt(1,new Color(236,233,230));
   tabbedPaneMain.setForeground(Color.blue);

  }// end jbinit

    JPanel createPane(String s) {
    JPanel p = new JPanel();
    p.add(new JLabel(s));
    return p;
  }

  class clickedtbFullScreenButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        new FullViewRule();
   }
  }
  class clickedtbBlackListButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        new BlackList();
   }
  }
  class clickedtbSearchButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        cardLayout1.show(cardPanel,"search");
   }
  }
  class clickedtbOptionsButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        cardLayout1.show(cardPanel,"options");
   }
  }
  class clickedtbChatButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        cardLayout1.show(cardPanel,"chat");
   }
  }
  class clickedtbDefineVarButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        cardLayout1.show(cardPanel,"definevar");
   }
  }
  class clickedtbTextEditorButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        cardLayout1.show(cardPanel,"textedit");
   }
  }
  class clickedtbRemoteButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        cardLayout1.show(cardPanel,"remotecontrol");
   }
  }

    class clickedtbResetButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          System.out.println("tbReset");

          ManagePanel.Reset();
          FtpTcp.clickedReset();
          FtpdataTcp.clickedReset();
          TelnetTcp.clickedReset();
          DnsTcp.clickedReset();
          SshTcp.clickedReset();
          HttpTcp.clickedReset();
          SmtpTcp.clickedReset();
          pop3Tcp.clickedReset();

          DefineVar.Reset();
          Nat.Reset();
          OptionsPanel.Reset();
          BlackList.Reset();
       }
      }

    class clickedtbRefreshButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {

          ManagePanel.refreshRecordTable();

          FtpTcp.refreshRecordTable();
          FtpdataTcp.refreshRecordTable();
          TelnetTcp.refreshRecordTable();
          HttpTcp.refreshRecordTable();
          SshTcp.refreshRecordTable();
          DnsTcp.refreshRecordTable();
          pop3Tcp.refreshRecordTable();
          SmtpTcp.refreshRecordTable();

          FtpUdp.refreshRecordTable();
          FtpdataUdp.refreshRecordTable();
          TelnetUdp.refreshRecordTable();
          HttpUdp.refreshRecordTable();
          SshUdp.refreshRecordTable();
          DnsUdp.refreshRecordTable();
          pop3Udp.refreshRecordTable();
          SmtpUdp.refreshRecordTable();
       }
      }

    class clickedtbApplyButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {

          System.out.println("ManagePanel.Apply();");
          System.out.println("Icmp.Apply();");
          System.out.println("DefineVar.Apply();");
          System.out.println("DefineChain.Apply();");
          System.out.println("Nat.Apply();");
          System.out.println("BlackList.Apply();");
          System.out.println("OptionsPanel.Apply();");

          System.out.println("FtpTcp.Apply();");
          System.out.println("FtpdataTcp.Apply();");
          System.out.println("TelnetTcp.Apply();");
          System.out.println("HttpTcp.Apply();");
          System.out.println("SshTcp.Apply();");
          System.out.println("DnsTcp.Apply();");
          System.out.println("pop3Tcp.Apply();");
          System.out.println("SmtpTcp.Apply();");

          System.out.println("FtpUdp.Apply();");
          System.out.println("FtpdataUdp.Apply();");
          System.out.println("TelnetUdp.Apply();");
          System.out.println("HttpUdp.Apply();");
          System.out.println("SshUdp.Apply();");
          System.out.println("DnsUdp.Apply();");
          System.out.println("pop3Udp.Apply();");
          System.out.println("SmtpUdp.Apply();");




          ManagePanel.Apply();
          Icmp.Apply();
          DefineVar.Apply();
          DefineChain.Apply();
          Nat.Apply();
          BlackList.Apply();
          OptionsPanel.Apply();

          FtpTcp.Apply();
          FtpdataTcp.Apply();
          TelnetTcp.Apply();
          HttpTcp.Apply();
          SshTcp.Apply();
          DnsTcp.Apply();
          pop3Tcp.Apply();
          SmtpTcp.Apply();

          FtpUdp.Apply();
          FtpdataUdp.Apply();
          TelnetUdp.Apply();
          HttpUdp.Apply();
          SshUdp.Apply();
          DnsUdp.Apply();
          pop3Udp.Apply();
          SmtpUdp.Apply();


      }
    }

   class clickedtbUnLockButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        System.out.println("tbApply");
   }
   }

   class clickedtbLockButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        System.out.println("tbLock");

        Application1.frame.setEnabled(false);
        lockpasswd.setVisible(true);
   }
   }
      class clickedtbSaveDBButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        System.out.println("tbSaveDB");
        manpanel.writeFile();

   }
   }

    class clickedtbPlugButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        System.out.println("tbPlug");
        new Connect();

   }
   }

     class clickedtbUnPlugButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        System.out.println("tbUnPlug");

   }
   }
     class clickedtbUserButton implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        System.out.println("tbUnPlug");
        changepasswd.setVisible(true);

   }
   }


   //   public void
//=====================================================================================================

public class IconNode extends DefaultMutableTreeNode  {

  protected Icon   icon;
  protected String iconName;

  public IconNode() {
    this(null);
  }

  public IconNode(Object userObject) {
    this(userObject, true, null);
  }

  public IconNode(Object userObject, boolean allowsChildren
		       , Icon icon) {
    super(userObject, allowsChildren);
    this.icon = icon;
  }

  public void setIcon(Icon icon) {
    this.icon = icon;
  }

  public Icon getIcon() {
    return icon;
  }

  public String getIconName() {
    if (iconName != null) {
      return iconName;
    } else {
      String str = userObject.toString();
      int index = str.lastIndexOf(".");
      if (index != -1) {
        return str.substring(++index);
      } else {
        return null;
      }
    }
  }

  public void setIconName(String name) {
    iconName = name;
  }

}

public class IconNodeRenderer extends DefaultTreeCellRenderer {

  public Component getTreeCellRendererComponent(JTree tree, Object value,
      boolean sel, boolean expanded, boolean leaf,
      int row, boolean hasFocus) {

    super.getTreeCellRendererComponent(tree, value,
       sel, expanded, leaf, row, hasFocus);

    Icon icon = ((IconNode)value).getIcon();

    if (icon == null) {
      Hashtable icons = (Hashtable)tree.getClientProperty("JTree.icons");
      String name = ((IconNode)value).getIconName();
      if ((icons != null) && (name != null)) {
        icon = (Icon)icons.get(name);
        if (icon != null) {
          setIcon(icon);
        }
      }
    } else {
      setIcon(icon);
    }

    return this;
  }
}

public class TreePanel extends JPanel {
DefaultMutableTreeNode top =new DefaultMutableTreeNode("iptables Firewall Builder");

	JTree tree = new JTree();



	public TreePanel() {

	   String[] strs = {"Main Firewall",                       // 0

        	      "Services",                        // 1
		        "Tcp",                               // 2
		        "ftp",                           // 3
		      "ftp_data",                   // 4
		        "telnet",                      // 5
		        "ssh",                         // 6
		        "dns",                          // 7
                        "http" ,                          // 8
               	        "smtp",                         // 10
          	        "pop-3",                        // 11
                        "Udp"           ,                        // 12
                        "ftp",                              // 13
		      "ftp_data",                      // 14
		        "telnet",                          // 15
		        "ssh",                             // 16
		        "dns"   ,                           //  17
        	        "http"    ,                           // 18
           	        "smtp"   ,                            // 20
          	        "pop-3"   ,                           // 21
                        "icmp"              ,                        // 22
                        "Firewall"          ,                        // 23
                        "iptables"           ,                       // 24
                        "nat"                     ,                      // 25
                        "Options"             ,                      // 26
                        "Search"               ,                       // 27
                        "Options" ,                     // 28
                        "Chat",
                        "Define Chain",
                        "Define Var",
                        "Text Edit",
                        "Remote Control"
                        };

    IconNode[] nodes = new IconNode[strs.length];
    for (int i=0;i<strs.length;i++) {
      nodes[i] = new IconNode(strs[i]);
    }

                                          /*         nodes[0].add(nodes[1]);
                                                  nodes[0].add(nodes[23]);
                                                  nodes[0].add(nodes[26]);

                                                 nodes[1].add(nodes[2]);
                                                  nodes[1].add(nodes[12]);
                                                  nodes[1].add(nodes[22]);
*/

                                                  nodes[0].add(nodes[1]);
                                                  nodes[0].add(nodes[21]);
                                                  nodes[0].add(nodes[24]);

                                                 nodes[1].add(nodes[2]);
                                                  nodes[1].add(nodes[11]);
                                                  nodes[1].add(nodes[20]);

                                                  nodes[2].add(nodes[3]);
                                                  nodes[2].add(nodes[4]);
                                                  nodes[2].add(nodes[5]);
                                                  nodes[2].add(nodes[6]);
                                                  nodes[2].add(nodes[7]);
                                                  nodes[2].add(nodes[8]);
                                                  nodes[2].add(nodes[9]);
                                                  nodes[2].add(nodes[10]);
                                              //    nodes[2].add(nodes[11]);

                                                  nodes[11].add(nodes[12]);
                                                  nodes[11].add(nodes[13]);
                                                  nodes[11].add(nodes[14]);
                                                  nodes[11].add(nodes[15]);
                                                  nodes[11].add(nodes[16]);
                                                  nodes[11].add(nodes[17]);
                                                  nodes[11].add(nodes[18]);
                                                  nodes[11].add(nodes[19]);
                                                 // nodes[11].add(nodes[20]);

                                                  nodes[21].add(nodes[22]);
                                                  nodes[21].add(nodes[23]);

                                                  nodes[24].add(nodes[25]);
                                                  nodes[24].add(nodes[26]);
                                                  nodes[24].add(nodes[27]);
                                                  nodes[24].add(nodes[28]);
                                                  nodes[24].add(nodes[29]);
                                                  nodes[24].add(nodes[30]);
                                                  nodes[24].add(nodes[31]);


                                      /*         nodes[0].add(nodes[1]);
                                                  nodes[0].add(nodes[23]);
                                                  nodes[0].add(nodes[26]);

                                                 nodes[1].add(nodes[2]);
                                                  nodes[1].add(nodes[12]);
                                                  nodes[1].add(nodes[22]);

                                                  nodes[2].add(nodes[3]);
                                                  nodes[2].add(nodes[4]);
                                                  nodes[2].add(nodes[5]);
                                                  nodes[2].add(nodes[6]);
                                                  nodes[2].add(nodes[7]);
                                                  nodes[2].add(nodes[8]);
                                                  nodes[2].add(nodes[9]);
                                                  nodes[2].add(nodes[10]);
                                                  nodes[2].add(nodes[11]);

                                                  nodes[12].add(nodes[13]);
                                                  nodes[12].add(nodes[14]);
                                                  nodes[12].add(nodes[15]);
                                                  nodes[12].add(nodes[16]);
                                                  nodes[12].add(nodes[17]);
                                                  nodes[12].add(nodes[18]);
                                                  nodes[12].add(nodes[19]);
                                                  nodes[12].add(nodes[20]);
                                                  nodes[12].add(nodes[21]);

                                                  nodes[23].add(nodes[24]);
                                                  nodes[23].add(nodes[25]);

                                                  nodes[26].add(nodes[27]);
                                                  nodes[26].add(nodes[28]);
                                                  nodes[26].add(nodes[29]);
                                                  nodes[26].add(nodes[30]);
                                                  nodes[26].add(nodes[31]);
                                                  nodes[26].add(nodes[32]);

                                         */
                                                  nodes[0].setIcon(new ImageIcon("images/Home.png"));
                                                  nodes[1].setIcon(new ImageIcon("images/Plus.png"));
                                                  nodes[2].setIcon(new ImageIcon("images/Laptop.png"));
                                                  nodes[3].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[4].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[5].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[6].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[7].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[8].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[9].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[10].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[11].setIcon(new ImageIcon("images/Laptop.png"));
                                                  nodes[12].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[13].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[14].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[15].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[16].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[17].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[18].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[19].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[20].setIcon(new ImageIcon("images/Laptop.png"));
                                                  nodes[21].setIcon(new ImageIcon("images/Laptop.png"));
                                                  nodes[22].setIcon(new ImageIcon("images/Computer.png"));
                                                  nodes[23].setIcon(new ImageIcon("images/Linux.gif"));
                                                  nodes[24].setIcon(new ImageIcon("images/Laptop.png"));
                                                  nodes[25].setIcon(new ImageIcon("images/Search.png"));
                                                  nodes[26].setIcon(new ImageIcon("images/Options.gif"));
                                                  nodes[27].setIcon(new ImageIcon("images/ChatIcon.gif"));
                                                  nodes[28].setIcon(new ImageIcon("images/Chain.gif"));
                                                  nodes[29].setIcon(new ImageIcon("images/DefineVar.png"));
                                                  nodes[30].setIcon(new ImageIcon("images/TextEdit.png"));
                                                  nodes[31].setIcon(new ImageIcon("images/remote.gif"));
                                                  //nodes[32].setIcon(new ImageIcon("images/Computer.png"));

                                                      tree = new JTree(nodes[0]);
                                                           //    tree.setOpaque(false);
                                                       tree.setCellRenderer( new IconNodeRenderer());
	                        //  setImageObserver(tree, nodes);

                                                          setLayout(new BorderLayout());
		JScrollPane treeView = new JScrollPane(tree);
		add(treeView, BorderLayout.CENTER);

                                                        //    DefaultTreeCellRenderer cr = new DefaultTreeCellRenderer();
                                               //              cr.setClosedIcon(new ImageIcon("images/Laptop.png"));
                                                 //           cr.setOpenIcon(new ImageIcon("images/C1.gif"));
                                                   //         cr.setLeafIcon(new ImageIcon("images/Computer.png"));
                                                   //         cr.setIconTextGap(5);
                                                            //cr.setForeground(Color.blue);
                                                   //         cr.setTextNonSelectionColor(Color.blue);
                                                     //       cr.setTextSelectionColor(Color.red);
                                                 //           tree.setCellRenderer(cr);
                                //    getContentPane().add(new JScrollPane(tree));
                             tree.putClientProperty("JTree.lineStyle", "Angled");

                                    tree.setEditable(true);

                                    tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
                                    tree.setShowsRootHandles(true);

    tree.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
       tree_valueChanged(e);
      }
    });
    }

          void tree_valueChanged(TreeSelectionEvent e) {

    DefaultMutableTreeNode nodes = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();

          System.out.println("hi");

          //nodes.setAllowsChildren(true);

    TreePath pathnode = (TreePath)tree.getLeadSelectionPath();

     if (tree.isVisible(pathnode)) {

          System.out.println("Tessssssssssssssssssssst");

      //    System.out.println("Depth"+nodes.getDepth());

        //  System.out.println("First Left  > " +nodes.getFirstLeaf().toString());
          //System.out.println("Parent > "+nodes.getParent().toString());
          //System.out.println("Path > "+nodes.getPath().toString());
          //System.out.println("Child Cound > " + nodes.getChildCount());
          //System.out.println("Depth      > "+ nodes.getDepth());

          //System.out.println("First Child Node      > "+ nodes.getFirstChild());



              if ( (nodes.getFirstLeaf().toString() == "ftp") && (nodes.getDepth() == 3) ) {
                     System.out.println("main");
                      cardLayout1.show(cardPanel,"main");
              }

             else if ( (nodes.getFirstLeaf().toString() == "ftp") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("ftpTcp");
                     cardLayout1.show(cardPanel,"ftpTcp");

              }

              else if ( (nodes.getFirstLeaf().toString() == "ftp_data") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("ftp_dataTcp");
                     cardLayout1.show(cardPanel,"ftpdataTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "telnet") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("telnetTcp");
                     cardLayout1.show(cardPanel,"telnetTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "ssh") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("sshTcp");
                     cardLayout1.show(cardPanel,"sshTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "dns") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("dnsTcp");
                     cardLayout1.show(cardPanel,"dnsTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "http") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("httpTcp");
                     cardLayout1.show(cardPanel,"httpTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "https") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("httpsTcp");
                     cardLayout1.show(cardPanel,"httpsTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "smtp") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("smtpTcp");
                     cardLayout1.show(cardPanel,"smtpTcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "pop-3") && (nodes.getParent().toString() == "Tcp") ) {
                     System.out.println("pop-3Tcp");
                     cardLayout1.show(cardPanel,"pop3Tcp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "ftp") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("ftp");
                     cardLayout1.show(cardPanel,"ftpUdp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "ftp_data") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("ftp_data");
                     cardLayout1.show(cardPanel,"ftpdataUdp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "telnet") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("telnet");
                     cardLayout1.show(cardPanel,"telnetUdp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "ssh") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("ssh");
                     cardLayout1.show(cardPanel,"sshUdp");
              }
              else if ( (nodes.getFirstLeaf().toString() == "dns") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("dns");
                     cardLayout1.show(cardPanel,"dnsUdp");
              }
              else if ( (nodes.getFirstLeaf().toString() == "http") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("http");
                     cardLayout1.show(cardPanel,"httpUdp");
              }
              else if ( (nodes.getFirstLeaf().toString() == "https") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("https");
                     cardLayout1.show(cardPanel,"httpsUdp");
              }
              else if ( (nodes.getFirstLeaf().toString() == "smtp") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("smtp");
                     cardLayout1.show(cardPanel,"smtpUdp");
              }
              else if ( (nodes.getFirstLeaf().toString() == "pop-3") && (nodes.getParent().toString() == "Udp") ) {
                     System.out.println("pop3");
                     cardLayout1.show(cardPanel,"pop3Udp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "icmp") && (nodes.getParent().toString() == "Services") ) {
                     System.out.println("icmp");
                     cardLayout1.show(cardPanel,"icmp");
              }

              else if ( (nodes.getFirstLeaf().toString() == "iptables") && (nodes.getParent().toString() == "Firewall") ) {
                     System.out.println("iptables");
                     cardLayout1.show(cardPanel,"iptables");
              }

              else if ( (nodes.getFirstLeaf().toString() == "nat") && (nodes.getParent().toString() == "Firewall") ) {
                     System.out.println("Nat");
                     cardLayout1.show(cardPanel,"Nat");
              }

              else if ( (nodes.getFirstLeaf().toString() == "Search") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("search");
                     cardLayout1.show(cardPanel,"search");
              }

              else if ( (nodes.getFirstLeaf().toString() == "Options") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("Normal Rule");
                     cardLayout1.show(cardPanel,"options");
              }
              else if ( (nodes.getFirstLeaf().toString() == "Chat") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("Chat");
                     cardLayout1.show(cardPanel,"chat");
              }
               else if ( (nodes.getFirstLeaf().toString() == "Define Chain") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("Define Chain");
                     cardLayout1.show(cardPanel,"definechain");
              }
               else if ( (nodes.getFirstLeaf().toString() == "Define Var") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("Define Var");
                     cardLayout1.show(cardPanel,"definevar");
              }
               else if ( (nodes.getFirstLeaf().toString() == "Text Edit") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("Text Edit");
                     cardLayout1.show(cardPanel,"textedit");
              }
               else if ( (nodes.getFirstLeaf().toString() == "Remote Control") && (nodes.getParent().toString() == "Options") ) {
                     System.out.println("Remote Control");
                     cardLayout1.show(cardPanel,"remotecontrol");
              }


     }//end if tree path
   } //end valueChanged

	private void createNodes(DefaultMutableTreeNode top) {
		DefaultMutableTreeNode servicesCategory = null;
		DefaultMutableTreeNode tcp = null,udp=null,icmp=null;
                                                           DefaultMutableTreeNode ftp_dataTcp = null,ftpTcp=null,sshTcp=null,telnetTcp=null,dnsTcp=null,httpTcp=null,httpsTcp=null,pop3Tcp=null;
                                                           DefaultMutableTreeNode ftp_dataUdp = null,ftpUdp=null,sshUdp=null,telnetUdp=null,dnsUdp=null,httpUdp=null,httpsUdp=null,pop3Udp=null;


                                                          servicesCategory = new DefaultMutableTreeNode("Services");
		top.add(servicesCategory);
		tcp = new DefaultMutableTreeNode("tcp");
		servicesCategory.add(tcp);
		udp = new DefaultMutableTreeNode("udp");
		servicesCategory.add(udp);
		icmp = new DefaultMutableTreeNode("icmp");
		servicesCategory.add(icmp);

                                                      /// tcp
		ftp_dataTcp = new DefaultMutableTreeNode("ftp-data");
		tcp.add(ftp_dataTcp);
		ftpTcp = new DefaultMutableTreeNode("ftp");
		tcp.add(ftpTcp);
		sshTcp = new DefaultMutableTreeNode("ssh");
		tcp.add(sshTcp);
		telnetTcp = new DefaultMutableTreeNode("telnet");
		tcp.add(telnetTcp);
		dnsTcp = new DefaultMutableTreeNode("dns");
		tcp.add(dnsTcp);
		httpTcp = new DefaultMutableTreeNode("http");
		tcp.add(httpTcp);
                		httpsTcp = new DefaultMutableTreeNode("https");
		tcp.add(httpsTcp);
                		pop3Tcp = new DefaultMutableTreeNode("pop-3");
		tcp.add(httpsTcp);

                                                    //ftp
		ftp_dataUdp = new DefaultMutableTreeNode("ftp-data");
		udp.add(ftp_dataUdp);
		ftpUdp = new DefaultMutableTreeNode("ftp");
		udp.add(ftpUdp);
		sshUdp = new DefaultMutableTreeNode("ssh");
		udp.add(sshUdp);
		telnetUdp = new DefaultMutableTreeNode("telnet");
		udp.add(telnetUdp);
		dnsUdp = new DefaultMutableTreeNode("dns");
		udp.add(dnsUdp);
		httpUdp = new DefaultMutableTreeNode("http");
		udp.add(httpUdp);
                		httpsUdp = new DefaultMutableTreeNode("https");
		udp.add(httpsUdp);
                		pop3Udp = new DefaultMutableTreeNode("pop-3");
		udp.add(httpsUdp);

                                                          DefaultMutableTreeNode firewallCategory = null;
                                                          DefaultMutableTreeNode iptables = null,nat=null;

                                                           firewallCategory = new DefaultMutableTreeNode("Firewalls");
		top.add(firewallCategory);
                                                         	iptables = new DefaultMutableTreeNode("iptables");
		firewallCategory.add(iptables);
		nat = new DefaultMutableTreeNode("NAT");
		firewallCategory.add(nat);

                                                          DefaultMutableTreeNode optionsCategory = null;
                                                          DefaultMutableTreeNode search = null;

                                                          optionsCategory = new DefaultMutableTreeNode("Options");
		top.add(optionsCategory);
                                                         	search = new DefaultMutableTreeNode("search");
		optionsCategory.add(search);
	}
     }

     //==================================================================================================
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
        System.exit(0);

    }
  }

}// end frame2