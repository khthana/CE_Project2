//package main;
package testmysql;

import javax.swing.UIManager;
import java.awt.*;

public class mainProgram {
  boolean packFrame = false;

  /**Construct the application*/
  public mainProgram() {
    Frame2 frame = new Frame2();
    //Validate frames that have preset sizes
    //Pack frames that have useful preferred size info, e.g. from their layout
    if (packFrame) {
      frame.pack();
    }
    else {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    frame.repaint(200,200,200,200);
    frame.setVisible(true);
    frame.setResizable(false);
  }

  /**Main method*/
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      //  UIManager.setLookAndFeel(new com.sun.java.swing.plaf.motif.MotifLookAndFeel());


    }
    catch(Exception e) {
      e.printStackTrace();
    }
   new mainProgram();
   new BlackList();
   //new SimpleTextEditClass();
  }
}