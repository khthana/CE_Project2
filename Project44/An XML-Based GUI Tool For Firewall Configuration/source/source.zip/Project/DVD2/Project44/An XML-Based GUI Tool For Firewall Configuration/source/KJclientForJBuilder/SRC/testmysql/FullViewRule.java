package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.JTable.*;
import javax.swing.table.*;
import javax.swing.table.AbstractTableModel;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class FullViewRule extends JFrame {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  int ReturnRowSelect;

  JPanel jPanel1 = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel tablePanel = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();

  public static ListSearchModel listModel;
  JTable table;
  JScrollPane scrollPane;
  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JButton deleteButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JButton refreshButton = new JButton(new ImageIcon("images/Refresh.png"));
  JButton downRecordButton = new JButton(new ImageIcon("images/MoveRowDown.png"));
  JButton upRecordButton = new JButton(new ImageIcon("images/MoveRowUp.png"));

  public FullViewRule() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
  listModel = new ListSearchModel();
  table = new JTable(listModel);
  scrollPane = new JScrollPane(table);

    this.setSize(new Dimension(546, 443));

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);




    this.getContentPane().setBackground(new Color(236, 233, 230));
    jPanel1.setLayout(borderLayout1);
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setMinimumSize(new Dimension(100, 37));
    jPanel3.setPreferredSize(new Dimension(100, 100));
   // applyButton.addActionListener(new clickedApply());
    //addButton.addActionListener(new clickedAdd());
    //editButton.addActionListener(new clickedEdit());
   // deleteButton.addActionListener(new clickedDelete());
    jPanel4.setBackground(Color.black);
    jPanel6.setBackground(new Color(0, 0, 33));
    tablePanel.setLayout(borderLayout2);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    jPanel2.setLayout(xYLayout2);
    deleteButton.setBackground(new Color(236, 233, 230));
    deleteButton.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deleteButton.setText("Delete");
    deleteButton.addActionListener(new clickedDelete());
    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel5.setBackground(Color.black);
    refreshButton.setText("Refresh");
    refreshButton.setHorizontalTextPosition(SwingConstants.LEFT);
    refreshButton.setActionCommand("Ok");
    refreshButton.setBorder(BorderFactory.createEtchedBorder());
    refreshButton.setBackground(new Color(236, 233, 230));
    downRecordButton.addActionListener(new clickedMoveDown());
    downRecordButton.setBackground(new Color(236, 233, 230));
    downRecordButton.setBorder(null);
    downRecordButton.setHorizontalTextPosition(SwingConstants.CENTER);
    upRecordButton.addActionListener(new clickedMoveUp());
    upRecordButton.setBackground(new Color(236, 233, 230));
    upRecordButton.setBorder(null);
    upRecordButton.setHorizontalTextPosition(SwingConstants.CENTER);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(tablePanel, BorderLayout.CENTER);
    tablePanel.add(scrollPane, BorderLayout.CENTER);
    jPanel2.add(downRecordButton, new XYConstraints(302, 29, 37, 36));
    jPanel2.add(upRecordButton, new XYConstraints(302, 2, 37, 31));
    jPanel2.add(deleteButton, new XYConstraints(87, 16, 80, 31));
    jPanel2.add(refreshButton, new XYConstraints(169, 16, 79, 31));
    jPanel1.add(jPanel4,  BorderLayout.WEST);
    jPanel1.add(jPanel5,  BorderLayout.EAST);
    jPanel1.add(jPanel6, BorderLayout.NORTH);
    jPanel1.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(jPanel2, null);

   ImageIcon icon = new ImageIcon(("images/FullScreen.gif"));
    this.setIconImage(icon.getImage());
    this.setTitle("Full Screen");

    	// Database section
	db = new DBUtil();
	con = db.Establish();

    this.setVisible(true);
    refreshRecordTable();

    refreshButton.addActionListener(new clickedRefresh());


  }
    class clickedDelete implements ActionListener {
      public void actionPerformed(ActionEvent e) {
           int Id;
                                String SQL="",Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;

                                       ReturnRowSelect= table.getSelectedRow();
                                       System.out.println("Return Row ......."+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getInt("ID");


		                SQL = "DELETE FROM confige WHERE ";

                                     SQL = SQL +  "ID =  "+Id+" ";

		db.SQLExecute(SQL);
		System.out.println(SQL);

                                      }

                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                listModel.clearData();
                                refreshRecordTable();



  }
}
    class clickedRefresh implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          refreshRecordTable();
    }
   }

  public static void refreshRecordTable() {
        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,notprotocal,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice="",notDesIP,notDesPort,notDesDevice,sRuleNo="";
        String tablename,frag,syn, notfrag, notsyn,  notflagmark, flagmark, flagcomp = new String("");
        String nottcp_op, tcp_op, noticmptype, icmptype, match, notmsource, msource, limit, limitrate, limitB, limitBnum = new String("");
        String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
        String setmark, rejecttype, settos, to, tosource, todes, toport,mul_sport,mul_dport = new String("");



        if(con!=null)
        {
          try {
              SQL = "SELECT * FROM Confige order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);


         listModel.clearData();
              int row =0;

                            rs.first();


                             while (rs.next()) {
                             rs.previous();

                        Id = rs.getString("ID");
                        tablename = rs.getString("tablename");
                        Chain = rs.getString("Chain");
                        notprotocal = rs.getString("notprotocal");
                        Protocal = rs.getString("Protocal");
                        notSrcIP = rs.getString("notSrcIP");
                        src_IP = rs.getString("src_IP");
                        notSrcPort = rs.getString("notSrcPort");
                        src_Port = rs.getString("src_Port");
                        notSrcPort = rs.getString("notSrcPort");
                        notSrcDevice = rs.getString("notSrcDevice");

                        src_Device = rs.getString("src_Device");
                        notDesIP = rs.getString("notDesIP");
                        des_IP = rs.getString("des_IP");
                        notDesPort = rs.getString("notDesPort");
                        des_Port = rs.getString("des_Port");
                        notDesDevice = rs.getString("notDesDevice");
                        des_Device = rs.getString("des_Device");
                        Action = rs.getString("Action");
                        frag = rs.getString("frag");
                        syn = rs.getString("syn");

                        notfrag = rs.getString("notfrag");
                        notsyn = rs.getString("notsyn");
                        notflagmark = rs.getString("notflagmark");
                        flagmark = rs.getString("flagmark");
                        flagcomp = rs.getString("flagcomp");
                        nottcp_op = rs.getString("nottcp_op");
                        tcp_op = rs.getString("tcp_op");
                        noticmptype = rs.getString("noticmptype");
                        icmptype = rs.getString("icmptype");
                        match = rs.getString("matchs");

                        sdport = rs.getString("sdport");
                        markvalue = rs.getString("markvalue");
                        userid = rs.getString("userid");
                        groupid = rs.getString("groupid");
                        processid = rs.getString("processid");
                        sessionid = rs.getString("sessionid");
                        state = rs.getString("state");
                        tos = rs.getString("tos");
                        level = rs.getString("level");
                        prefix = rs.getString("prefix");

                        logseq = rs.getString("logseq");
                        logop = rs.getString("logop");
                        logipop = rs.getString("frag");
                        notmsource = rs.getString("notmsource");
                        msource = rs.getString("msource");
                        limit = rs.getString("limits");
                        limitrate = rs.getString("limitrate");
                        limitB = rs.getString("limitB");
                        limitBnum = rs.getString("limitBnum");
                        setmark = rs.getString("setmark");

                       rejecttype = rs.getString("rejecttype");
                       settos = rs.getString("settos");
                       to = rs.getString("natto");
                       tosource = rs.getString("tosource");
                       todes = rs.getString("todes");
                       toport = rs.getString("toport");
                       mul_sport = rs.getString("mul_sport");
                       mul_dport = rs.getString("mul_dport");



                       listModel.setValueAt(Id,row,0);
                       listModel.setValueAt(tablename,row,1);
                       listModel.setValueAt(Chain,row,2);
                       listModel.setValueAt(notprotocal,row,3);
                       listModel.setValueAt(Protocal,row,4);
                       listModel.setValueAt(notSrcIP,row,5);
                       listModel.setValueAt(src_IP,row,6);
                       listModel.setValueAt(notSrcPort,row,7);
                       listModel.setValueAt(src_Port,row,8);
                       listModel.setValueAt(notSrcDevice,row,9);
                       listModel.setValueAt(src_Device,row,10);

                       listModel.setValueAt(notDesIP,row,11);
                       listModel.setValueAt(des_IP,row,12);
                       listModel.setValueAt(notDesPort,row,13);
                       listModel.setValueAt(des_Port,row,14);
                       listModel.setValueAt(notDesDevice,row,15);
                       listModel.setValueAt(des_Device,row,16);
                       listModel.setValueAt(Action,row,17);
                       listModel.setValueAt(frag,row,18);
                       listModel.setValueAt(syn,row,19);
                       listModel.setValueAt(notfrag,row,20);

                       listModel.setValueAt(notsyn,row,21);
                       listModel.setValueAt(notflagmark,row,22);
                       listModel.setValueAt(flagmark,row,23);
                       listModel.setValueAt(flagcomp,row,24);
                       listModel.setValueAt(nottcp_op,row,25);
                       listModel.setValueAt(tcp_op,row,26);
                       listModel.setValueAt(noticmptype,row,27);
                       listModel.setValueAt(icmptype,row,28);
                       listModel.setValueAt(match,row,29);
                       listModel.setValueAt(sdport,row,30);
                       listModel.setValueAt(markvalue,row,31);
                       listModel.setValueAt(userid,row,32);
                       listModel.setValueAt(groupid,row,33);
                       listModel.setValueAt(processid,row,34);
                       listModel.setValueAt(sessionid,row,35);
                       listModel.setValueAt(state,row,36);
                       listModel.setValueAt(tos,row,37);
                       listModel.setValueAt(level,row,38);
                       listModel.setValueAt(prefix,row,39);
                       listModel.setValueAt(logseq,row,40);

                       listModel.setValueAt(logop,row,41);
                       listModel.setValueAt(logipop,row,42);
                       listModel.setValueAt(notmsource,row,43);
                       listModel.setValueAt(msource,row,44);
                       listModel.setValueAt(limit,row,45);
                       listModel.setValueAt(limitrate,row,46);
                       listModel.setValueAt(limitB,row,47);
                       listModel.setValueAt(limitBnum,row,48);
                       listModel.setValueAt(setmark,row,49);
                       listModel.setValueAt(rejecttype,row,50);
                       listModel.setValueAt(settos,row,51);
                       listModel.setValueAt(to,row,52);
                       listModel.setValueAt(tosource,row,53);
                       listModel.setValueAt(todes,row,54);
                       listModel.setValueAt(toport,row,55);
                       listModel.setValueAt(mul_sport,row,56);
                       listModel.setValueAt(mul_dport,row,57);

                                  row += 1;
                                  rs.next();
                                  }//while

                        Id = rs.getString("ID");
                        tablename = rs.getString("tablename");
                        Chain = rs.getString("Chain");
                        notprotocal = rs.getString("notprotocal");
                        Protocal = rs.getString("Protocal");
                        notSrcIP = rs.getString("notSrcIP");
                        src_IP = rs.getString("src_IP");
                        notSrcPort = rs.getString("notSrcPort");
                        src_Port = rs.getString("src_Port");
                        notSrcPort = rs.getString("notSrcPort");
                        notSrcDevice = rs.getString("notSrcDevice");

                        src_Device = rs.getString("src_Device");
                        notDesIP = rs.getString("notDesIP");
                        des_IP = rs.getString("des_IP");
                        notDesPort = rs.getString("notDesPort");
                        des_Port = rs.getString("des_Port");
                        notDesDevice = rs.getString("notDesDevice");
                        des_Device = rs.getString("des_Device");
                        Action = rs.getString("Action");
                        frag = rs.getString("frag");
                        syn = rs.getString("syn");

                        notfrag = rs.getString("notfrag");
                        notsyn = rs.getString("notsyn");
                        notflagmark = rs.getString("notflagmark");
                        flagmark = rs.getString("flagmark");
                        flagcomp = rs.getString("flagcomp");
                        nottcp_op = rs.getString("nottcp_op");
                        tcp_op = rs.getString("tcp_op");
                        noticmptype = rs.getString("noticmptype");
                        icmptype = rs.getString("icmptype");
                        match = rs.getString("matchs");


                        sdport = rs.getString("sdport");
                        markvalue = rs.getString("markvalue");
                        userid = rs.getString("userid");
                        groupid = rs.getString("groupid");
                        processid = rs.getString("processid");
                        sessionid = rs.getString("sessionid");
                        state = rs.getString("state");
                        tos = rs.getString("tos");
                        level = rs.getString("level");

                        prefix = rs.getString("prefix");
                        logseq = rs.getString("logseq");
                        logop = rs.getString("logop");
                        logipop = rs.getString("logipop");
                        notmsource = rs.getString("notmsource");
                        msource = rs.getString("msource");
                        limit = rs.getString("limits");
                        limitrate = rs.getString("limitrate");
                        limitB = rs.getString("limitB");
                        limitBnum = rs.getString("limitBnum");
                        setmark = rs.getString("setmark");

                       rejecttype = rs.getString("rejecttype");
                       settos = rs.getString("settos");
                       to = rs.getString("natto");
                       tosource = rs.getString("tosource");
                       todes = rs.getString("todes");
                       toport = rs.getString("toport");
                       mul_sport = rs.getString("mul_sport");
                       mul_dport = rs.getString("mul_dport");


                       listModel.setValueAt(Id,row,0);
                       listModel.setValueAt(tablename,row,1);
                       listModel.setValueAt(Chain,row,2);
                       listModel.setValueAt(notprotocal,row,3);
                       listModel.setValueAt(Protocal,row,4);
                       listModel.setValueAt(notSrcIP,row,5);
                       listModel.setValueAt(src_IP,row,6);
                       listModel.setValueAt(notSrcPort,row,7);
                       listModel.setValueAt(src_Port,row,8);
                       listModel.setValueAt(notSrcDevice,row,9);
                       listModel.setValueAt(src_Device,row,10);
                       listModel.setValueAt(notDesIP,row,11);
                       listModel.setValueAt(des_IP,row,12);
                       listModel.setValueAt(notDesPort,row,13);
                       listModel.setValueAt(des_Port,row,14);
                       listModel.setValueAt(notDesDevice,row,15);
                       listModel.setValueAt(des_Device,row,16);
                       listModel.setValueAt(Action,row,17);

                       listModel.setValueAt(frag,row,18);
                       listModel.setValueAt(syn,row,19);
                       listModel.setValueAt(notfrag,row,20);
                       listModel.setValueAt(notsyn,row,21);
                       listModel.setValueAt(notflagmark,row,22);
                       listModel.setValueAt(flagmark,row,23);
                       listModel.setValueAt(flagcomp,row,24);
                       listModel.setValueAt(nottcp_op,row,25);
                       listModel.setValueAt(tcp_op,row,26);
                       listModel.setValueAt(noticmptype,row,27);
                       listModel.setValueAt(icmptype,row,28);
                       listModel.setValueAt(match,row,29);
                       listModel.setValueAt(sdport,row,30);
                       listModel.setValueAt(markvalue,row,31);
                       listModel.setValueAt(userid,row,32);
                       listModel.setValueAt(groupid,row,33);
                       listModel.setValueAt(processid,row,34);
                       listModel.setValueAt(sessionid,row,35);
                       listModel.setValueAt(state,row,36);
                       listModel.setValueAt(tos,row,37);
                       listModel.setValueAt(level,row,38);
                       listModel.setValueAt(prefix,row,39);
                       listModel.setValueAt(logseq,row,40);
                       listModel.setValueAt(logop,row,41);
                       listModel.setValueAt(logipop,row,42);
                       listModel.setValueAt(notmsource,row,43);
                       listModel.setValueAt(msource,row,44);
                       listModel.setValueAt(limit,row,45);
                       listModel.setValueAt(limitrate,row,46);
                       listModel.setValueAt(limitB,row,47);
                       listModel.setValueAt(limitBnum,row,48);
                       listModel.setValueAt(setmark,row,49);
                       listModel.setValueAt(rejecttype,row,50);
                       listModel.setValueAt(settos,row,51);
                       listModel.setValueAt(to,row,52);
                       listModel.setValueAt(tosource,row,53);
                       listModel.setValueAt(todes,row,54);
                       listModel.setValueAt(toport,row,55);
                       listModel.setValueAt(mul_sport,row,56);
                       listModel.setValueAt(mul_dport,row,57);



                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh

      class clickedMoveDown implements ActionListener {
          public void actionPerformed(ActionEvent e) {
            moveDownRecord();
      }
    }
    class clickedMoveUp implements ActionListener {
      public void actionPerformed(ActionEvent e) {
                    moveUpRecord();
        }
      }

   public void moveDownRecord() {

        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,notprotocal,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice="",notDesIP,notDesPort,notDesDevice,sRuleNo="";
        String tablename,frag,syn, notfrag, notsyn,  notflagmark, flagmark, flagcomp = new String("");
        String nottcp_op, tcp_op, noticmptype, icmptype, match, notmsource, msource, limit, limitrate, limitB, limitBnum = new String("");
        String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
        String setmark, rejecttype, settos, to, tosource, todes, toport,mul_sport,mul_dport = new String("");


        String belowId,belowChain,belowAction,belowsrc_IP,belowsrc_Port,belowsrc_Device,belowdes_IP,belowdes_Port,belowdes_Device,belownotprotocal,belowProtocal;
        String belownotSrcIP,belownotSrcPort,belownotSrcDevice="",belownotDesIP,belownotDesPort,belownotDesDevice,belowsRuleNo="";
        String belowtablename,belowfrag,belowsyn, belownotfrag, belownotsyn,  belownotflagmark, belowflagmark, belowflagcomp = new String("");
        String belownottcp_op, belowtcp_op, belownoticmptype, belowicmptype, belowmatch, belownotmsource, belowmsource, belowlimit, belowlimitrate, belowlimitB, belowlimitBnum = new String("");
        String belowsdport, belowmarkvalue, belowuserid, belowgroupid, belowprocessid, belowsessionid, belowstate, belowtos, belowlevel, belowprefix, belowlogseq, belowlogop, belowlogipop = new String("");
        String belowsetmark, belowrejecttype, belowsettos, belowto, belowtosource, belowtodes, belowtoport,belowmul_sport,belowmul_dport = new String("");


        String PK;

                if(con!=null)
        {
          try {
              SQL = "SELECT * FROM confige order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);


           ReturnRowSelect=table.getSelectedRow();
              int row =0;

                            rs.first();
                              for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                  row += 1;
                                }

                        Id = rs.getString("ID");
                        tablename = rs.getString("tablename");
                        Chain = rs.getString("Chain");
                        notprotocal = rs.getString("notprotocal");
                        Protocal = rs.getString("Protocal");
                        notSrcIP = rs.getString("notSrcIP");
                        src_IP = rs.getString("src_IP");
                        notSrcPort = rs.getString("notSrcPort");
                        src_Port = rs.getString("src_Port");
                        notSrcPort = rs.getString("notSrcPort");
                        notSrcDevice = rs.getString("notSrcDevice");
                        src_Device = rs.getString("src_Device");
                        notDesIP = rs.getString("notDesIP");
                        des_IP = rs.getString("des_IP");
                        notDesPort = rs.getString("notDesPort");
                        des_Port = rs.getString("des_Port");
                        notDesDevice = rs.getString("notDesDevice");
                        des_Device = rs.getString("des_Device");
                        Action = rs.getString("Action");

                        frag = rs.getString("frag");
                        syn = rs.getString("syn");

                        notfrag = rs.getString("notfrag");
                        notsyn = rs.getString("notsyn");
                        notflagmark = rs.getString("notflagmark");
                        flagmark = rs.getString("flagmark");
                        flagcomp = rs.getString("flagcomp");
                        nottcp_op = rs.getString("nottcp_op");
                        tcp_op = rs.getString("tcp_op");
                        noticmptype = rs.getString("noticmptype");
                        icmptype = rs.getString("icmptype");
                        match = rs.getString("matchs");

                       sdport = rs.getString("sdport");
                       markvalue = rs.getString("markvalue");
                       userid = rs.getString("userid");
                       groupid = rs.getString("groupid");
                       processid = rs.getString("processid");
                       sessionid = rs.getString("sessionid");
                       state = rs.getString("state");
                       tos = rs.getString("tos");
                       level = rs.getString("level");
                       prefix = rs.getString("prefix");

                       logseq = rs.getString("logseq");
                       logop = rs.getString("logop");
                       logipop = rs.getString("frag");
                       notmsource = rs.getString("notmsource");
                       msource = rs.getString("msource");
                       limit = rs.getString("limits");
                       limitrate = rs.getString("limitrate");
                       limitB = rs.getString("limitB");
                       limitBnum = rs.getString("limitBnum");
                       setmark = rs.getString("setmark");

                       rejecttype = rs.getString("rejecttype");
                       settos = rs.getString("settos");
                       to = rs.getString("natto");
                       tosource = rs.getString("tosource");
                       todes = rs.getString("todes");
                       toport = rs.getString("toport");
                       mul_sport = rs.getString("mul_sport");
                       mul_dport = rs.getString("mul_dport");



                        rs.next();

                        belowId = rs.getString("ID");
                        belowtablename = rs.getString("tablename");
                        belowChain = rs.getString("Chain");
                        belownotprotocal = rs.getString("notprotocal");
                        belowProtocal = rs.getString("Protocal");
                        belownotSrcIP = rs.getString("notSrcIP");
                        belowsrc_IP = rs.getString("src_IP");
                        belownotSrcPort = rs.getString("notSrcPort");
                        belowsrc_Port = rs.getString("src_Port");
                        belownotSrcPort = rs.getString("notSrcPort");
                        belownotSrcDevice = rs.getString("notSrcDevice");
                        belowsrc_Device = rs.getString("src_Device");
                        belownotDesIP = rs.getString("notDesIP");
                        belowdes_IP = rs.getString("des_IP");
                        belownotDesPort = rs.getString("notDesPort");
                        belowdes_Port = rs.getString("des_Port");
                        belownotDesDevice = rs.getString("notDesDevice");
                        belowdes_Device = rs.getString("des_Device");
                        belowAction = rs.getString("Action");

                        belowfrag = rs.getString("frag");
                        belowsyn = rs.getString("syn");

                        belownotfrag = rs.getString("notfrag");
                        belownotsyn = rs.getString("notsyn");
                        belownotflagmark = rs.getString("notflagmark");
                        belowflagmark = rs.getString("flagmark");
                        belowflagcomp = rs.getString("flagcomp");
                        belownottcp_op = rs.getString("nottcp_op");
                        belowtcp_op = rs.getString("tcp_op");
                        belownoticmptype = rs.getString("noticmptype");
                        belowicmptype = rs.getString("icmptype");
                        belowmatch = rs.getString("matchs");

                       belowsdport = rs.getString("sdport");
                       belowmarkvalue = rs.getString("markvalue");
                       belowuserid = rs.getString("userid");
                       belowgroupid = rs.getString("groupid");
                       belowprocessid = rs.getString("processid");
                       belowsessionid = rs.getString("sessionid");
                       belowstate = rs.getString("state");
                       belowtos = rs.getString("tos");
                       belowlevel = rs.getString("level");
                       belowprefix = rs.getString("prefix");

                       belowlogseq = rs.getString("logseq");
                       belowlogop = rs.getString("logop");
                       belowlogipop = rs.getString("frag");
                       belownotmsource = rs.getString("notmsource");
                       belowmsource = rs.getString("msource");
                       belowlimit = rs.getString("limits");
                       belowlimitrate = rs.getString("limitrate");
                       belowlimitB = rs.getString("limitB");
                       belowlimitBnum = rs.getString("limitBnum");
                       belowsetmark = rs.getString("setmark");

                       belowrejecttype = rs.getString("rejecttype");
                       belowsettos = rs.getString("settos");
                       belowto = rs.getString("natto");
                       belowtosource = rs.getString("tosource");
                       belowtodes = rs.getString("todes");
                       belowtoport = rs.getString("toport");
                       belowmul_sport = rs.getString("mul_sport");
                       belowmul_dport = rs.getString("mul_dport");



   //Update Top Row




          SQL = "UPDATE confige SET ";

          PK = " ID = "+Id+" ";

        SQL = SQL + " Chain='"+belowChain+"',Action='"+belowAction+"',src_IP='"+belowsrc_IP+"',src_Port='"+belowsrc_Port+"',src_Device='"+belowsrc_Device+"',des_IP='"+belowdes_IP+"',des_Device='"+belowdes_Device+"',notprotocal='"+belownotprotocal+"',Protocal='"+belowProtocal+"' "+
        ", notSrcIP='"+belownotSrcIP+"',notSrcPort='"+belownotSrcPort+"',notSrcDevice='"+belownotSrcDevice+"' ,notDesIP='"+belownotDesIP+"',notDesPort='"+belownotDesPort+"',notDesDevice='"+belownotDesDevice+"'" +
        ", tablename = '"+belowtablename+"',frag='"+belowfrag+"',syn='"+belowsyn+"',notfrag='"+belownotfrag+"',notsyn='"+belownotsyn+"',notflagmark='"+belownotflagmark+"',flagmark='"+belowflagmark+"',flagcomp='"+belowflagcomp+"' "+
        ", nottcp_op = '"+belownottcp_op+"',tcp_op='"+belowtcp_op+"',noticmptype='"+belownoticmptype+"',icmptype='"+belownoticmptype+"',matchs='"+belowmatch+"' ,notmsource='"+belownotmsource+"',msource='"+belowmsource+"',limits='"+belowlimit+"',limitrate='"+belowlimitrate+"',limitB='"+belowlimitB+"',limitBnum='"+belowlimitBnum+"' "+
        ", sdport = '"+belowsdport+"',markvalue='"+belowmarkvalue+"',userid='"+belowuserid+"',groupid='"+belowgroupid+"',processid='"+belowprocessid+"',sessionid='"+belowsessionid+"',state='"+belowstate+"',tos='"+belowtos+"',level='"+belowlevel+"',prefix='"+belowprefix+"',logseq='"+belowlogseq+"',logop='"+belowlogop+"',logipop='"+belowlogipop+"' "+
        ", setmark = '"+belowsetmark+"',rejecttype='"+belowrejecttype+"',settos='"+belowsettos+"',natto='"+belowto+"',tosource='"+belowtosource+"',todes='"+belowtodes+"',toport='"+belowtoport+"' ";

          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);

          //Update Row is Selected
          SQL="";
          SQL = "UPDATE confige SET ";

           SQL = SQL + " Chain='"+Chain+"',Action='"+Action+"',src_IP='"+src_IP+"',src_Port='"+src_Port+"',src_Device='"+src_Device+"',des_IP='"+des_IP+"',des_Device='"+des_Device+"',notprotocal='"+notprotocal+"',Protocal='"+Protocal+"' "+
           ", notSrcIP='"+notSrcIP+"',notSrcPort='"+notSrcPort+"',notSrcDevice='"+notSrcDevice+"' ,notDesIP='"+notDesIP+"',notDesPort='"+notDesPort+"',notDesDevice='"+notDesDevice+"'" +
           ", tablename = '"+tablename+"',frag='"+frag+"',syn='"+syn+"',notfrag='"+notfrag+"',notsyn='"+notsyn+"',notflagmark='"+notflagmark+"',flagmark='"+flagmark+"',flagcomp='"+flagcomp+"' "+
           ", nottcp_op = '"+nottcp_op+"',tcp_op='"+tcp_op+"',noticmptype='"+noticmptype+"',icmptype='"+noticmptype+"',matchs='"+match+"' ,notmsource='"+notmsource+"',msource='"+msource+"',limits='"+limit+"',limitrate='"+limitrate+"',limitB='"+limitB+"',limitBnum='"+limitBnum+"' "+
           ", sdport = '"+sdport+"',markvalue='"+markvalue+"',userid='"+userid+"',groupid='"+groupid+"',processid='"+processid+"',sessionid='"+sessionid+"',state='"+state+"',tos='"+tos+"',level='"+level+"',prefix='"+prefix+"',logseq='"+logseq+"',logop='"+logop+"',logipop='"+logipop+"' "+
           ", setmark = '"+setmark+"',rejecttype='"+rejecttype+"',settos='"+settos+"',natto='"+to+"',tosource='"+tosource+"',todes='"+todes+"',toport='"+toport+"' ";

          PK = " ID = "+belowId+" ";
          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);






          }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }

                }//if
                table.setRowSelectionInterval(ReturnRowSelect+1,ReturnRowSelect+1);
                refreshRecordTable();


      }

      public void moveUpRecord() {

        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,notprotocal,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice,sRuleNo="";
        String tablename,frag,syn, notfrag, notsyn,  notflagmark, flagmark, flagcomp = new String("");
        String nottcp_op, tcp_op, noticmptype, icmptype, match, notmsource, msource, limit, limitrate, limitB, limitBnum = new String("");
        String sdport, markvalue, userid, groupid, processid, sessionid, state, tos, level, prefix, logseq, logop, logipop = new String("");
        String setmark, rejecttype, settos, to, tosource, todes, toport,mul_sport,mul_dport = new String("");

        String topId,topChain,topAction,topsrc_IP,topsrc_Port,topsrc_Device,topdes_IP,topdes_Port,topdes_Device,topnotprotocal,topProtocal;
        String topnotSrcIP,topnotSrcPort,topnotSrcDevice,topnotDesIP,topnotDesPort,topnotDesDevice,topsRuleNo="";
        String toptablename,topfrag,topsyn, topnotfrag, topnotsyn,  topnotflagmark, topflagmark, topflagcomp = new String("");
        String topnottcp_op, toptcp_op, topnoticmptype, topicmptype, topmatch, topnotmsource, topmsource, toplimit, toplimitrate, toplimitB, toplimitBnum = new String("");
        String topsdport, topmarkvalue, topuserid, topgroupid, topprocessid, topsessionid, topstate, toptos, toplevel, topprefix, toplogseq, toplogop, toplogipop = new String("");
        String topsetmark, toprejecttype, topsettos, topto, toptosource, toptodes, toptoport ,topmul_sport,topmul_dport= new String("");

        String PK;

        if(con!=null)        {
          try {
              SQL = "SELECT * FROM confige order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

           ReturnRowSelect=table.getSelectedRow();

              int row =0;
                            rs.first();

                              for (int i=0;i<ReturnRowSelect-1;i++){
                                  rs.next();
                                  row += 1;
                                }

                        topId = rs.getString("ID");
                        toptablename = rs.getString("tablename");
                        topChain = rs.getString("Chain");
                        topnotprotocal = rs.getString("notprotocal");
                        topProtocal = rs.getString("Protocal");
                        topnotSrcIP = rs.getString("notSrcIP");
                        topsrc_IP = rs.getString("src_IP");
                        topnotSrcPort = rs.getString("notSrcPort");
                        topsrc_Port = rs.getString("src_Port");
                        topnotSrcPort = rs.getString("notSrcPort");
                        topnotSrcDevice = rs.getString("notSrcDevice");
                        topsrc_Device = rs.getString("src_Device");
                        topnotDesIP = rs.getString("notDesIP");
                        topdes_IP = rs.getString("des_IP");
                        topnotDesPort = rs.getString("notDesPort");
                        topdes_Port = rs.getString("des_Port");
                        topnotDesDevice = rs.getString("notDesDevice");
                        topdes_Device = rs.getString("des_Device");
                        topAction = rs.getString("Action");

                        topfrag = rs.getString("frag");
                        topsyn = rs.getString("syn");

                        topnotfrag = rs.getString("notfrag");
                        topnotsyn = rs.getString("notsyn");
                        topnotflagmark = rs.getString("notflagmark");
                        topflagmark = rs.getString("flagmark");
                        topflagcomp = rs.getString("flagcomp");
                        topnottcp_op = rs.getString("nottcp_op");
                        toptcp_op = rs.getString("tcp_op");
                        topnoticmptype = rs.getString("noticmptype");
                        topicmptype = rs.getString("icmptype");
                        topmatch = rs.getString("matchs");

                       topsdport = rs.getString("sdport");
                       topmarkvalue = rs.getString("markvalue");
                       topuserid = rs.getString("userid");
                       topgroupid = rs.getString("groupid");
                       topprocessid = rs.getString("processid");
                       topsessionid = rs.getString("sessionid");
                       topstate = rs.getString("state");
                       toptos = rs.getString("tos");
                       toplevel = rs.getString("level");
                       topprefix = rs.getString("prefix");

                       toplogseq = rs.getString("logseq");
                       toplogop = rs.getString("logop");
                       toplogipop = rs.getString("logipop");
                       topnotmsource = rs.getString("notmsource");
                       topmsource = rs.getString("msource");
                       toplimit = rs.getString("limits");
                       toplimitrate = rs.getString("limitrate");
                       toplimitB = rs.getString("limitB");
                       toplimitBnum = rs.getString("limitBnum");
                       topsetmark = rs.getString("setmark");

                       toprejecttype = rs.getString("rejecttype");
                       topsettos = rs.getString("settos");
                       topto = rs.getString("natto");
                       toptosource = rs.getString("tosource");
                       toptodes = rs.getString("todes");
                       toptoport = rs.getString("toport");
                       topmul_sport = rs.getString("mul_sport");
                       topmul_dport = rs.getString("mul_dport");


                                  rs.next();
                        Id = rs.getString("ID");
                        tablename = rs.getString("tablename");
                        Chain = rs.getString("Chain");
                        notprotocal = rs.getString("notprotocal");
                        Protocal = rs.getString("Protocal");
                        notSrcIP = rs.getString("notSrcIP");
                        src_IP = rs.getString("src_IP");
                        notSrcPort = rs.getString("notSrcPort");
                        src_Port = rs.getString("src_Port");
                        notSrcPort = rs.getString("notSrcPort");
                        notSrcDevice = rs.getString("notSrcDevice");
                        src_Device = rs.getString("src_Device");
                        notDesIP = rs.getString("notDesIP");
                        des_IP = rs.getString("des_IP");
                        notDesPort = rs.getString("notDesPort");
                        des_Port = rs.getString("des_Port");
                        notDesDevice = rs.getString("notDesDevice");
                        des_Device = rs.getString("des_Device");
                        Action = rs.getString("Action");

                        frag = rs.getString("frag");
                        syn = rs.getString("syn");

                        notfrag = rs.getString("notfrag");
                        notsyn = rs.getString("notsyn");
                        notflagmark = rs.getString("notflagmark");
                        flagmark = rs.getString("flagmark");
                        flagcomp = rs.getString("flagcomp");
                        nottcp_op = rs.getString("nottcp_op");
                        tcp_op = rs.getString("tcp_op");
                        noticmptype = rs.getString("noticmptype");
                        icmptype = rs.getString("icmptype");
                        match = rs.getString("matchs");

                       sdport = rs.getString("sdport");
                       markvalue = rs.getString("markvalue");
                       userid = rs.getString("userid");
                       groupid = rs.getString("groupid");
                       processid = rs.getString("processid");
                       sessionid = rs.getString("sessionid");
                       state = rs.getString("state");
                       tos = rs.getString("tos");
                       level = rs.getString("level");
                       prefix = rs.getString("prefix");

                       logseq = rs.getString("logseq");
                       logop = rs.getString("logop");
                       logipop = rs.getString("logipop");
                       notmsource = rs.getString("notmsource");
                       msource = rs.getString("msource");
                       limit = rs.getString("limits");
                       limitrate = rs.getString("limitrate");
                       limitB = rs.getString("limitB");
                       limitBnum = rs.getString("limitBnum");
                       setmark = rs.getString("setmark");

                       rejecttype = rs.getString("rejecttype");
                       settos = rs.getString("settos");
                       to = rs.getString("natto");
                       tosource = rs.getString("tosource");
                       todes = rs.getString("todes");
                       toport = rs.getString("toport");
                       mul_sport = rs.getString("mul_sport");
                       mul_dport = rs.getString("mul_dport");


          //Update Top Row
          SQL = "UPDATE confige SET ";
           SQL = SQL + " Chain='"+topChain+"',Action='"+topAction+"',src_IP='"+topsrc_IP+"',src_Port='"+topsrc_Port+"',src_Device='"+topsrc_Device+"',des_IP='"+topdes_IP+"',des_Device='"+topdes_Device+"',notprotocal='"+topnotprotocal+"',Protocal='"+topProtocal+"' "+
        ", notSrcIP='"+topnotSrcIP+"',notSrcPort='"+topnotSrcPort+"',notSrcDevice='"+topnotSrcDevice+"' ,notDesIP='"+topnotDesIP+"',notDesPort='"+topnotDesPort+"',notDesDevice='"+topnotDesDevice+"'" +
        ", tablename = '"+toptablename+"',frag='"+topfrag+"',syn='"+topsyn+"',notfrag='"+topnotfrag+"',notsyn='"+topnotsyn+"',notflagmark='"+topnotflagmark+"',flagmark='"+topflagmark+"',flagcomp='"+topflagcomp+"' "+
        ", nottcp_op = '"+topnottcp_op+"',tcp_op='"+toptcp_op+"',noticmptype='"+topnoticmptype+"',icmptype='"+topnoticmptype+"',matchs='"+topmatch+"' ,notmsource='"+topnotmsource+"',msource='"+topmsource+"',limits='"+toplimit+"',limitrate='"+toplimitrate+"',limitB='"+toplimitB+"',limitBnum='"+toplimitBnum+"' "+
        ", sdport = '"+topsdport+"',markvalue='"+topmarkvalue+"',userid='"+topuserid+"',groupid='"+topgroupid+"',processid='"+topprocessid+"',sessionid='"+topsessionid+"',state='"+topstate+"',tos='"+toptos+"',level='"+toplevel+"',prefix='"+topprefix+"',logseq='"+toplogseq+"',logop='"+toplogop+"',logipop='"+toplogipop+"' "+
        ", setmark = '"+topsetmark+"',rejecttype='"+toprejecttype+"',settos='"+topsettos+"',natto='"+topto+"',tosource='"+toptosource+"',todes='"+toptodes+"',toport='"+toptoport+"',mul_sport='"+topmul_sport+"',mul_dport='"+topmul_dport+"' ";
          PK = " ID = "+Id+" ";
          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);

          //Update Row is Selected
          SQL="";
          SQL = "UPDATE confige SET ";

           SQL = SQL + " Chain='"+Chain+"',Action='"+Action+"',src_IP='"+src_IP+"',src_Port='"+src_Port+"',src_Device='"+src_Device+"',des_IP='"+des_IP+"',des_Device='"+des_Device+"',notprotocal='"+notprotocal+"',Protocal='"+Protocal+"' "+
           ", notSrcIP='"+notSrcIP+"',notSrcPort='"+notSrcPort+"',notSrcDevice='"+notSrcDevice+"' ,notDesIP='"+notDesIP+"',notDesPort='"+notDesPort+"',notDesDevice='"+notDesDevice+"'" +
           ", tablename = '"+tablename+"',frag='"+frag+"',syn='"+syn+"',notfrag='"+notfrag+"',notsyn='"+notsyn+"',notflagmark='"+notflagmark+"',flagmark='"+flagmark+"',flagcomp='"+flagcomp+"' "+
           ", nottcp_op = '"+nottcp_op+"',tcp_op='"+tcp_op+"',noticmptype='"+noticmptype+"',icmptype='"+noticmptype+"',matchs='"+match+"' ,notmsource='"+notmsource+"',msource='"+msource+"',limits='"+limit+"',limitrate='"+limitrate+"',limitB='"+limitB+"',limitBnum='"+limitBnum+"' "+
           ", sdport = '"+sdport+"',markvalue='"+markvalue+"',userid='"+userid+"',groupid='"+groupid+"',processid='"+processid+"',sessionid='"+sessionid+"',state='"+state+"',tos='"+tos+"',level='"+level+"',prefix='"+prefix+"',logseq='"+logseq+"',logop='"+logop+"',logipop='"+logipop+"' "+
           ", setmark = '"+setmark+"',rejecttype='"+rejecttype+"',settos='"+settos+"',natto='"+to+"',tosource='"+tosource+"',todes='"+todes+"',toport='"+toport+"',mul_sport='"+mul_sport+"',mul_dport='"+mul_dport+"' ";

          PK = " ID = "+topId+" ";
          SQL = SQL + "WHERE"+PK;

          db.SQLExecute(SQL);
          System.out.println(SQL);


                                  //row += 1;
				 //rs.next();
                                //  }//while
                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }

                }//if
                table.setRowSelectionInterval(ReturnRowSelect-1,ReturnRowSelect-1);
                refreshRecordTable();

      }


  class ListSearchModel extends AbstractTableModel {



        	int LastRow=0;


                   	String[] columnNames = {
                	"rule no.",
			"table name",
                        "chain",
                        "notprotocal",
                        "protocal",
			"use src ip",
                        "src ip",
                        "use src port",
			"src port",
                        "not src device",

                        "src device",
                        "not des ip",
                        "des ip",
                        "use des port",
                        "des port",
                        "use des device",
                        "des device",
                        "action",
                        "frag",
                        "syn",

          "notfrag",
          "notsyn",
          "notflagmark",
          "flagmark",
          "flagcomp",
          "nottcp_op",
          "tcp_op",
          "noticmptype",
          "icmptype",
          "matchs",

          "sdport",
          "markvalue",
          "userid",
          "groupid",
          "processid",
          "sessionid",
          "state",
          "tos",
          "level",
          "prefix",

          "logseq",
          "logop",
          "logipop",
          "notmsource",
          "msource",
          "limits",
          "limitrate",
          "limitB",
          "limitBnum",
          "setmark",

          "rejecttype",
          "settos",
          "natto",
          "tosource",
          "todes",
          "toport",
          "mul_sport",
          "mul_dport"
                        };


                //Object[][] data = new Object[LastRow][columnNames.length];

                Object[][] data = {

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},


     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},
     {"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","","","",""    ,"","","","","","","","","","",   "","","","","","","","","","",   "","","","","","","",""},

       		};



        public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;

	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
                //return new Integer(row*col);
	}

//	public Class getColumnClass(int c) {/
//		return getValueAt(0, c).getClass();
//	}

	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}

	public void clearData() {
        for(int i=0; i<data.length; i++)
		  for(int j=0; j<columnNames.length; j++)
		if (j<=60)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
	}
        }

 /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
    //    dispose();
     //   hide();

    }
  }




}// end class