//package main;
package testmysql;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.UIManager;

class Menu extends JMenuBar {
  public JMenuItem item;
  JFrame frame;


  public Menu() {

    JMenu file = new JMenu ("File");
    file.setBackground(new Color(236,233,230));

    Icon ExitDoor = new ImageIcon("images/ExitDoor.gif");

    file.add (item = new JMenuItem ("Exit",ExitDoor));
    item.setHorizontalTextPosition(JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    add (file);

    JMenu options = new JMenu ("Options");

    JMenu winman = new JMenu ("Windows manager");
    winman.setMnemonic('M');

    winman.setBackground(new Color(236,233,230));

    Icon Sheet = new ImageIcon("images/Sheet.png");
    winman.add (item = new JMenuItem ("Main Manage", Sheet));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());

    options.add (item = new JMenuItem ("Search"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));

    options.add (item = new JMenuItem ("Options"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));

    options.add (item = new JMenuItem ("Chat"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));

    options.add (item = new JMenuItem ("Define Chain"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));

    options.add (item = new JMenuItem ("Define Var"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));

    options.add (item = new JMenuItem ("Text Editor"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));

    options.add (item = new JMenuItem ("Remote Control"));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());
    options.setBackground(new Color(236,233,230));



    winman.add(options);
    add (winman);

    JMenu help = new JMenu ("Help");
    help.setMnemonic('H');

    help.setBackground(new Color(236,233,230));

 //   Icon Help = new ImageIcon("images/Help.png");
 //   help.add (item = new JMenuItem ("Help topic", Help));
 //   item.setHorizontalTextPosition (JMenuItem.LEFT);
 //   item.addActionListener(new menuSelect());

//    Icon iptables = new ImageIcon("images/Inform.png");
//    help.add (item = new JMenuItem ("Howto iptables ...", iptables));
//    item.setHorizontalTextPosition (JMenuItem.LEFT);
 //   item.addActionListener(new menuSelect());

    Icon About = new ImageIcon("images/Inform.png");
    help.add (item = new JMenuItem ("About ...", About));
    item.setHorizontalTextPosition (JMenuItem.LEFT);
    item.addActionListener(new menuSelect());

    add (help);




    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }


    class menuSelect implements ActionListener {
      public void actionPerformed(ActionEvent e) {

        CardLayout card;
        System.out.println (e.getActionCommand());

        if (e.getActionCommand().equals("Exit")) {
               System.out.println("Exit");
               System.exit(0);
       }

        if (e.getActionCommand().equals("Main Manage")) {
               System.out.println("Main Manage");
               Frame2.cardLayout1.show(Frame2.cardPanel,"main");
       }

         if (e.getActionCommand().equals("Search")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"search");
       }

         if (e.getActionCommand().equals("Options")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"options");
       }

         if (e.getActionCommand().equals("Chat")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"chat");
       }

         if (e.getActionCommand().equals("Define Chain")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"definechain");
       }

         if (e.getActionCommand().equals("Define Var")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"definevar");
       }

         if (e.getActionCommand().equals("Text Editor")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"textedit");
       }

         if (e.getActionCommand().equals("Remote Control")) {
               Frame2.cardLayout1.show(Frame2.cardPanel,"remotecontrol");
       }



        if (e.getActionCommand().equals("Windows")) {
               System.out.println("Windows");
               try {
                      UIManager.setLookAndFeel(new com.sun.java.swing.plaf.windows.WindowsLookAndFeel());
                      SwingUtilities.updateComponentTreeUI(Frame2.contentPane);
                }
             catch(Exception ex) {
                     System.out.println(ex.getMessage());
              }
       }


       if (e.getActionCommand().equals("About ...")) {
               System.out.println("About ...");
               //Frame2.cardLayout1.show(Frame2.cardPanel,"main");
                new AboutDialog();
              //  new Dialog1();
       }

       if (e.getActionCommand().equals("Howto iptables ...")) {
          try {
                //String command = "D:\\execute.htm";
                String cmds[] = new String[2];
                //cmds[0] = "dir"; // replace with "ls" on UNIX
                cmds[0] = "c:"; // replace with "/" on UNIX

                String command = "C:\\windows\\command.com";
                System.out.println("execute :> 1");
                Process child = Runtime.getRuntime().exec(command);
                Runtime.getRuntime().exec("dir");


                System.out.println("execute :> 2");

                }

          catch(IOException ex) {
                System.out.println(ex.getMessage());
          }
      }
    }// end M

}
  private void jbInit() throws Exception {
    this.setBackground(new Color(236, 233, 223));

  } //end menuSelect

  } // ����� -------------------------------------------------


