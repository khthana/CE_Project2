import java.awt.*;
import javax.swing.JPanel;

public class Query extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();

  public Query() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);

  add(new ActionSearch());
  add(new ChainSearch());
  add(new IPSearch());
  add(new PortSearch());
  add(new ProtocalSearch());


  }


}//end Query

