package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.table.AbstractTableModel;
import java.sql.*;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class BlackList extends JFrame {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  int ReturnRowSelect;

  ButtonGroup rbg1 = new ButtonGroup();
  ButtonGroup rbg2 = new ButtonGroup();

  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel2 = new JPanel();
  Border border1;
  TitledBorder titledBorder1;
  JRadioButton alertallRadioButton = new JRadioButton();
  JRadioButton disableallRadioButton = new JRadioButton();
  XYLayout xYLayout2 = new XYLayout();
  Border border2;
  TitledBorder titledBorder2;
  JPanel ActionPanel = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  Border border3;
  TitledBorder titledBorder3;
  JTextField hostaddrTextField = new JTextField();
  JLabel jLabel1 = new JLabel();
  JRadioButton alertRadioButton = new JRadioButton();
  JRadioButton notalertRadioButton = new JRadioButton();

  public static String status = "";

  public static ListSearchModel listModel;
  JTable table;
  JScrollPane scrollPane;

  JPanel tablePanel = new JPanel();
  XYLayout xYLayout4 = new XYLayout();
  JPanel jPanel4 = new JPanel();
  Border border4;
  XYLayout xYLayout5 = new XYLayout();
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  JButton addButton = new JButton(new ImageIcon("images/Add.png"));
  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  JButton deleteButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JButton closeButton = new JButton(new ImageIcon("images/Apply.png"));
  JLabel statusLabel = new JLabel();
  JButton applyallButton = new JButton(new ImageIcon("images/Apply.png"));
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout6 = new XYLayout();
  JLabel logoLabel = new JLabel();

  public BlackList() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
     //Center the window

  }
  private void jbInit() throws Exception {

    this.setSize(new Dimension(546, 443));

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);



    this.setFont(new java.awt.Font("Serif", 0, 12));
    statusLabel.setFont(new java.awt.Font("SansSerif", 1, 12));
    statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    statusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    applyallButton.addActionListener(new clickedApplyAll());
    applyallButton.setText("Aplly");
    applyallButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyallButton.setBorder(BorderFactory.createEtchedBorder());
    applyallButton.setBackground(new Color(236, 233, 230));
    hostaddrTextField.setBackground(Color.white);
    jPanel1.setPreferredSize(new Dimension(522, 445));
    jPanel3.setLayout(xYLayout6);
    logoLabel.setBackground(new Color(236, 233, 230));
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    rbg1.add(alertRadioButton);
    rbg1.add(notalertRadioButton);

    rbg2.add(alertallRadioButton);
    rbg2.add(disableallRadioButton);

    listModel = new ListSearchModel();
    table = new JTable(listModel);
    scrollPane = new JScrollPane(table);

    border1 = BorderFactory.createEmptyBorder();
    titledBorder1 = new TitledBorder(border1,"Default Alert");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(border2,"Default Alert");
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder3 = new TitledBorder(border3,"Specific Action");
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    jPanel1.setLayout(xYLayout1);
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel2.setBorder(titledBorder2);
    jPanel2.setLayout(xYLayout2);
    alertallRadioButton.setBackground(new Color(236, 233, 230));
    alertallRadioButton.setText("Alert All");
    disableallRadioButton.setBackground(new Color(236, 233, 230));
    disableallRadioButton.setText("Disable All");
    ActionPanel.setLayout(xYLayout3);
    ActionPanel.setBackground(new Color(236, 233, 230));
    ActionPanel.setBorder(titledBorder3);
    jLabel1.setBackground(new Color(236, 233, 230));
    jLabel1.setText("Host Address");
    alertRadioButton.setBackground(new Color(236, 233, 230));
    alertRadioButton.setText("Alert");
    notalertRadioButton.setBackground(new Color(236, 233, 230));
    notalertRadioButton.setText("not Alert");
    tablePanel.setLayout(xYLayout4);
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setBorder(BorderFactory.createEtchedBorder());
    tablePanel.setBackground(new Color(236, 233, 230));
    tablePanel.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setBackground(new Color(236, 233, 230));
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    jPanel4.setLayout(xYLayout5);
    applyButton.setBackground(new Color(236, 233, 230));
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setText("Aplly");
    applyButton.addActionListener(new clickedApply());
    addButton.setBackground(new Color(236, 233, 230));
    addButton.setBorder(BorderFactory.createEtchedBorder());
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setText("Add");
    addButton.addActionListener(new clickedAdd());
    editButton.setBackground(new Color(236, 233, 230));
    editButton.setBorder(BorderFactory.createEtchedBorder());
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    editButton.setText("Edit");
    editButton.addActionListener(new clickedEdit());
    deleteButton.setBackground(new Color(236, 233, 230));
    deleteButton.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deleteButton.setText("Delete");
    deleteButton.addActionListener(new clickedDelete());
    closeButton.addActionListener(new clickedClose());
    closeButton.setText("Close");
    closeButton.setHorizontalTextPosition(SwingConstants.LEFT);
    closeButton.setBorder(BorderFactory.createEtchedBorder());
    closeButton.setBackground(new Color(236, 233, 230));
    jPanel4.add(addButton, new XYConstraints(5, 11, 78, 32));
    jPanel4.add(deleteButton, new XYConstraints(5, 48, 80, 31));
    jPanel4.add(editButton, new XYConstraints(4, 83, 79, 31));
    jPanel4.add(applyButton, new XYConstraints(4, 122, 79, 30));
    jPanel1.add(jPanel3,  new XYConstraints(23, 5, 431, 68));
    jPanel3.add(logoLabel, new XYConstraints(66, 5, 304, 51));
    jPanel1.add(statusLabel, new XYConstraints(465, 42, 57, 28));
    jPanel1.add(ActionPanel,  new XYConstraints(210, 77, 310, 97));
    ActionPanel.add(jLabel1, new XYConstraints(9, 10, -1, 42));
    ActionPanel.add(notalertRadioButton, new XYConstraints(220, 40, 72, 13));
    ActionPanel.add(hostaddrTextField, new XYConstraints(93, 21, 110, 21));
    ActionPanel.add(alertRadioButton, new XYConstraints(220, 15, 58, 17));
    jPanel1.add(jPanel2,         new XYConstraints(26, 75, 181, 97));
    jPanel2.add(alertallRadioButton, new XYConstraints(9, 5, -1, -1));
    jPanel2.add(disableallRadioButton, new XYConstraints(6, 35, 78, -1));
    jPanel2.add(applyallButton,      new XYConstraints(89, 29, 79, 30));
    jPanel1.add(tablePanel, new XYConstraints(25, 183, 397, 184));
    tablePanel.add(scrollPane, new XYConstraints(6, 6, 378, 169));
    jPanel1.add(closeButton, new XYConstraints(218, 375, 79, 30));
    jPanel1.add(jPanel4, new XYConstraints(431, 185, 91, 183));
    this.getContentPane().add(jPanel1, BorderLayout.NORTH);

    logoLabel.setIcon(new ImageIcon("./Images/BlackListlogo.gif"));

    statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
    this.setVisible(true);

    ImageIcon icon = new ImageIcon(("images/BlackList.gif"));
    this.setIconImage(icon.getImage());

    this.setTitle("Black List ...");
    // Database section
	db = new DBUtil();
        con = db.Establish();

    alertRadioButton.setSelected(true);
    setdisable();

    refreshRecordTable();
  }
    public static void Reset() {
         try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
                  refreshRecordTable();
                 System.out.println("Reset");
    }

   public static void Apply() {
          try {
                  db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
  }

  void setdisable(){
        hostaddrTextField.setEditable(false);
        alertRadioButton.setEnabled(false);
        notalertRadioButton.setEnabled(false);
  }
  void setenable() {
        hostaddrTextField.setEditable(true);
        alertRadioButton.setEnabled(true);
        notalertRadioButton.setEnabled(true);
  }

  class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          status ="ADD";
          setenable();
          statusLabel.setIcon(new ImageIcon("./Images/Add.gif"));
      }
    }

    class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       setenable();
       ReturnRowSelect=table.getSelectedRow();
       System.out.println(ReturnRowSelect);
       setEdit();
       status = "UPDATE";
      }
    }

  class clickedDelete implements ActionListener {
      public void actionPerformed(ActionEvent e) {

                                String SQL="",Id;

                                       ReturnRowSelect= table.getSelectedRow();
                                       System.out.println("Return Row ......."+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getString("ID");

		SQL = "DELETE FROM blacklist"  + " WHERE ";
                SQL = SQL + "ID = '"+Id+"' ";
		db.SQLExecute(SQL);
		System.out.println(SQL);

                                      }

                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                refreshRecordTable();


   }
  }

     class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        updateRecord();
        statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
        setdisable();
 }
 }
      class clickedApplyAll implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        String SQL="";


        if(alertallRadioButton.isSelected()){
            SQL="UPDATE blacklist SET Status = ";
            SQL = SQL + " 'Alert' ";
        }
        else {
             SQL="UPDATE blacklist SET Status = ";
             SQL = SQL + " 'Not Alert' ";
        }

        db.SQLExecute(SQL);
        System.out.println(SQL);

        refreshRecordTable();
    }
  }

     class clickedClose implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        dispose();
        hide();
 }
 }
  public  void setEdit() {
               String SQL="",HostAddr,Status,Id;

                   statusLabel.setIcon(new ImageIcon("./Images/Edit.gif"));
                   try {
                    rs.first();
                    ReturnRowSelect = table.getSelectedRow();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                    }

                                  Id = rs.getString("ID");
                                  HostAddr = rs.getString("HostAddr");
                                  Status = rs.getString("Status");

                                  hostaddrTextField.setEditable(true);
                                  hostaddrTextField.setText(HostAddr);


                                  if (Status.equals("Alert"))
                                        alertRadioButton.setSelected(true);
                                  else if (Status.equals("Not Alert"))
                                        notalertRadioButton.setSelected(true);


                  }
                                  catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }
  }//end setEdit


 class ListSearchModel extends AbstractTableModel {
        	int LastRow=0;


                   	String[] columnNames = {
                	"Host No.",
                        "Host Address",
                        "Status"
			};

                //Object[][] data = new Object[LastRow][columnNames.length];

                Object[][] data = {
			{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},
			{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},
			{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},{"","",""},
                           		};



        public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;

	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
                //return new Integer(row*col);
	}

//	public Class getColumnClass(int c) {/
//		return getValueAt(0, c).getClass();
//	}

	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}

	public void clearData() {
        for(int i=0; i<data.length; i++)
		  for(int j=0; j<columnNames.length; j++)
		if (j<=15)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
	}
        }

 public static void refreshRecordTable() {
        String SQL="",Id,HostAddr,Status,No;
        int rowno;

        if(con!=null)
        {
          try {
              SQL = "SELECT * FROM blacklist order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);


              rs.first();
              listModel.clearData();

              int row =0;
                             while (rs.next()) {
                                  rs.previous();
                                  Id = rs.getString("ID");
                                  HostAddr = rs.getString("HostAddr");
                                  Status = rs.getString("Status");


                                  rowno = row+1;
                                  No = String.valueOf(rowno);

                                  listModel.setValueAt(No,row,0);
                                  listModel.setValueAt(HostAddr,row,1);
                                  listModel.setValueAt(Status,row,2);
                                  row += 1;
                                  rs.next();
                                  }//while

                                  Id = rs.getString("ID");
                                  HostAddr = rs.getString("HostAddr");
                                  Status = rs.getString("Status");

                                  rowno = row+1;
                                  No = String.valueOf(rowno);

                                  listModel.setValueAt(No,row,0);
                                  listModel.setValueAt(HostAddr,row,1);
                                  listModel.setValueAt(Status,row,2);

                  }//try

                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh

 public void updateRecord() {
              String SQL, field = "", value = "",stringPK="";
              String AlertValue="",Id="";


    if (status.equals("ADD")) {

    SQL = "INSERT INTO blacklist" ;

      if (alertRadioButton.isSelected())
              AlertValue = "Alert";
          else if (notalertRadioButton.isSelected())
              AlertValue = "Not Alert";




      field="HostAddr,Status";
      value=" '"+hostaddrTextField.getText()+"' ,'"+AlertValue+"' " ;



      SQL = SQL + "(" + field + ") VALUES(" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

                   System.out.println("Test Return Row Select : " + ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<=ReturnRowSelect;i++) {
                        rs.next();
                     }

                       Id = rs.getString("ID");
                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }


          if (alertRadioButton.isSelected())
              AlertValue = "Alert";
          else if (notalertRadioButton.isSelected())
              AlertValue = "Not Alert";


          SQL = "UPDATE blacklist SET";
          SQL =SQL + " HostAddr = '"+hostaddrTextField.getText()+"' ,Status = '"+AlertValue+"' ";


          field = "ID = "+Id+" ";
          SQL = SQL + " WHERE "+field;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }
          refreshRecordTable();
          status = "";
  } //end updateRecord()



  }//end class