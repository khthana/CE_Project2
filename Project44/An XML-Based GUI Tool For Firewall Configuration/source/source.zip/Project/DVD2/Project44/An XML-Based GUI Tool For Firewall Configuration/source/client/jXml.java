import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;

import org.w3c.dom.*;
import org.apache.xerces.parsers.DOMParser;
import org.apache.xerces.*;

public class jXml extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JButton runxmlButton = new JButton();

    public static String displayStrings[] = new String[1000];
    static int numberDisplayLines = 0;
    static Document document;
    static Node c;


  public jXml() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    runxmlButton.setPreferredSize(new Dimension(80, 25));
    runxmlButton.setText("Run");
    this.setBackground(Color.lightGray);
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, null);
    jPanel2.add(runxmlButton, null);
    runxmlButton.addActionListener(new clickedRunXml());

  }
     class clickedRunXml implements ActionListener {
      public void actionPerformed(ActionEvent e) {
            displayDocument("firewallconfige.xml");
            //displayDocument("keng.xml");

      }
      }

 /*     class clickedRunXml implements ActionListener {
      public void actionPerformed(ActionEvent e) {

        System.out.println("=============== begin Run XML =============================");

        displayDocument("firewallconfige.xml");

        try {
            FileWriter filewriter = new FileWriter("firewallconfige2.xml");

            for(int loopIndex = 0; loopIndex < numberDisplayLines; loopIndex++){
                filewriter.write(displayStrings[loopIndex].toCharArray());
                System.out.println("filewriter : "+displayStrings[loopIndex]);
                filewriter.write('\n');

            }

                System.out.println("====== print no enter =======");
        for(int loopIndex = 0; loopIndex < numberDisplayLines; loopIndex++){
                System.out.print(displayStrings[loopIndex]);
        }
                System.out.println("====== print no enter =======");

            filewriter.close();
        }
        catch (Exception ee) {
            ee.printStackTrace(System.err);
        }

        System.out.println("=============== end Run XML =============================");
       }//end actionPer
      }//end clickedRunXml
*/
          public static void displayDocument(String uri)
    {
        try {
            DOMParser parser = new DOMParser();
            parser.setIncludeIgnorableWhitespace(false);
            parser.parse(uri);
            document = parser.getDocument();

            //display(document, "");
              display(document);
        } catch (Exception e) {
            e.printStackTrace(System.err);
        }
    }

    public static void display(Node node) {

     Node FIREWALL_CONFIGE = ((Document)node).getDocumentElement();
     System.out.println("1 "+FIREWALL_CONFIGE.getNodeName());

     Node FIREWALL_CONFIGE1 = ((Document)node).getDocumentElement();
     System.out.println("1_ "+FIREWALL_CONFIGE1.getNextSibling());


     Node RULE = FIREWALL_CONFIGE.getFirstChild();
     System.out.println("2 "+RULE.getNodeName());

 //    Node RULE1 = FIREWALL_CONFIGE.getFirstChild();
   //  System.out.println("2_2 "+RULE1.getFirstChild().getNodeValue());

     Node RULE5 = FIREWALL_CONFIGE.getLastChild();
     System.out.println("3 "+RULE5.getNodeName());

//=========================================
     Node tmp = RULE.getParentNode();
     System.out.println("4 "+tmp.getNodeName());

//==========================================

  /* Node meetingsNode = ((Document)node).getDocumentElement();
        Node meetingNode = meetingsNode.getFirstChild();
        Node peopleNode = meetingNode.getLastChild();
        Node personNode = peopleNode.getLastChild();
        Node first_nameNode = personNode.getFirstChild();
        Node last_nameNode = first_nameNode.getNextSibling();

        System.out.println("Third name: " +
            first_nameNode.getFirstChild().getNodeValue() + ' '
            + last_nameNode.getFirstChild().getNodeValue());
*/


     }


  /*  public static void display2(Node node, String indent)
    {
        if (node == null) {
            return;
        }

        int type = node.getNodeType();

        switch (type) {
            case Node.DOCUMENT_NODE: {
                displayStrings[numberDisplayLines] = indent;
                displayStrings[numberDisplayLines] += "<?xml version=\"1.0\" encoding=\""+
                  "UTF-8" + "\"?>";
                System.out.println("DOCUMENT_NODE = "+displayStrings[numberDisplayLines]);
                numberDisplayLines++;
                display(((Document)node).getDocumentElement(), "");
                break;
             }

             case Node.ELEMENT_NODE: {

                 if(node.getNodeName().equals("NAME")) {
                     Element middleNameElement = document.createElement("MIDDLE_NAME");
                     Text textNode = document.createTextNode("XML");
                     middleNameElement.appendChild(textNode);
                     node.appendChild(middleNameElement);
                 }

                 displayStrings[numberDisplayLines] = indent;
                 displayStrings[numberDisplayLines] += "<";
                 displayStrings[numberDisplayLines] += node.getNodeName();

                 int length = (node.getAttributes() != null) ? node.getAttributes().getLength() : 0;
                 Attr attributes[] = new Attr[length];
                 for (int loopIndex = 0; loopIndex < length; loopIndex++) {
                     attributes[loopIndex] = (Attr)node.getAttributes().item(loopIndex);
                 }

                 for (int loopIndex = 0; loopIndex < attributes.length; loopIndex++) {
                     Attr attribute = attributes[loopIndex];
                     displayStrings[numberDisplayLines] += " ";
                     displayStrings[numberDisplayLines] += attribute.getNodeName();
                     displayStrings[numberDisplayLines] += "=\"";
                     displayStrings[numberDisplayLines] += attribute.getNodeValue();
                     displayStrings[numberDisplayLines] += "\"";
                 }

                 displayStrings[numberDisplayLines]+=">";

                     System.out.println("====== begin ELEMENT_NODE =====");
                     String newgetParentNode = node.getParentNode().getNodeValue();
                     System.out.println("newgetParentNode Value = "+newgetParentNode);

                     float newgetParentNode1 = node.getParentNode().getNodeType();
                     System.out.println("newgetParentNode Type = "+newgetParentNode1);

                     newgetParentNode = node.getNodeName();
                     System.out.println("getNodeName = "+newgetParentNode);


                     newgetParentNode = node.getParentNode().getNodeName();
                     System.out.println("getParentNode Name = "+newgetParentNode);

                     //newgetParentNode = node.getPreviousSibling().getNodeName();
                     //System.out.println("get Previous Sibling Name = "+newgetParentNode);

                     //newgetParentNode = node.getNextSibling().getNodeName();
                     //System.out.println("get Next Sibling Name = "+newgetParentNode);

                     //if (node.getNodeName() == "NOT_SRC_PORT")


                     System.out.println("====== end ELEMENT_NODE =====");


                 System.out.println("ELEMENT_NODE = "+displayStrings[numberDisplayLines]);

                 numberDisplayLines++;

                 NodeList childNodes = node.getChildNodes();

                 if (childNodes != null) {



                     length = childNodes.getLength();
                     indent += "    ";
                     for (int loopIndex = 0; loopIndex < length; loopIndex++ ) {
                        display(childNodes.item(loopIndex), indent);
                     }
                 }

                 break;
             }

             case Node.CDATA_SECTION_NODE: {
                 displayStrings[numberDisplayLines] = indent;
                 displayStrings[numberDisplayLines] += "<![CDATA[";
                 displayStrings[numberDisplayLines] += node.getNodeValue();
                 displayStrings[numberDisplayLines] += "]]>";
                 System.out.println("CDTA_SECTION = "+displayStrings[numberDisplayLines]);
                 numberDisplayLines++;
                 break;

             }

             case Node.TEXT_NODE: {
                 displayStrings[numberDisplayLines] = indent;
                 String newText = node.getNodeValue().trim();
                 if(newText.indexOf("\n") < 0 && newText.length() > 0) {
                     displayStrings[numberDisplayLines] += newText;

                     System.out.println("====== begin TEXT_NODE =====");

                     String newgetParentNode = node.getParentNode().getNodeValue();
                     System.out.println("newgetParentNode Value = "+newgetParentNode);

                     float ParentNodeType = node.getParentNode().getNodeType();
                     System.out.println("newgetParentNode Type = "+ParentNodeType);

                     newgetParentNode = node.getNodeName();
                     System.out.println("get NodeName = "+newgetParentNode);

                     newgetParentNode = node.getParentNode().getNodeName();
                     System.out.println("newgetParentNode Name = "+newgetParentNode);


                     //newgetParentNode = node.getPreviousSibling().getNodeName();
                     //System.out.println("get Previous Sibling Name = "+newgetParentNode);

                     //newgetParentNode = node.getNextSibling().getNodeName();
                     //System.out.println("get Next Sibling Name = "+newgetParentNode);

                     System.out.println("====== end TEXT_NODE =====");

                     if (node.getNodeName() == "NOT_SRC_IP") {
                        System.out.println("Insert NOT_SRC_IP : ");
                     }
                      else if (node){

                      }


                     System.out.println("TEXT_NODE = "+displayStrings[numberDisplayLines]);
                     numberDisplayLines++;
                 }

                 break;
             }

             case Node.PROCESSING_INSTRUCTION_NODE: {
                 displayStrings[numberDisplayLines] = indent;
                 displayStrings[numberDisplayLines] += "<?";
                 displayStrings[numberDisplayLines] += node.getNodeName();
                 String text = node.getNodeValue();
                 if (text != null && text.length() > 0) {
                     displayStrings[numberDisplayLines] += text;
                 }
                 displayStrings[numberDisplayLines] += "?>";
                 System.out.println("PROCESSING_INSTRUCTION_NODE = "+displayStrings[numberDisplayLines]);
                 numberDisplayLines++;
                 break;
            }
        }

        if (type == Node.ELEMENT_NODE) {
            displayStrings[numberDisplayLines] = indent.substring(0, indent.length() - 4);
            displayStrings[numberDisplayLines] += "</";
            displayStrings[numberDisplayLines] += node.getNodeName();
            displayStrings[numberDisplayLines] += ">";
            System.out.println("TYPE_ELEMENT_NODE = "+displayStrings[numberDisplayLines]);
            numberDisplayLines++;
            indent += "    ";

        }
    }


          public static void main(String args[])
    {
        displayDocument(args[0]);

        try {
            FileWriter filewriter = new FileWriter("customer2.xml");

            for(int loopIndex = 0; loopIndex < numberDisplayLines; loopIndex++){
                filewriter.write(displayStrings[loopIndex].toCharArray());
                filewriter.write('\n');
            }

            filewriter.close();
        }
        catch (Exception e) {
            e.printStackTrace(System.err);
        }
    }
*/

}//end class