import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.table.AbstractTableModel;
import java.sql.*;


public class DefineChain extends JPanel {

  public static ListSearchModel listModel;
  // Database Component
  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  String[] policyNames = {"ACCEPT","DROP","REJECT"};

  String status="";

  int ReturnRowSelect;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JLabel logoLabel = new JLabel();
  JLabel statusLabel = new JLabel();
  JPanel tablePanel = new JPanel();

  XYLayout xYLayout3 = new XYLayout();
  JTable table;
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JTextField nameTextField = new JTextField();
  JLabel policyLabel = new JLabel();
  JLabel jLabel2 = new JLabel();
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  XYLayout xYLayout9 = new XYLayout();
  JButton addButton = new JButton(new ImageIcon("images/Add.png"));
  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  JPanel jPanel8 = new JPanel();
  JButton deleteButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JTextField commentTextField = new JTextField();
  JLabel commentLabel = new JLabel();
  JComboBox policyComboBox = new JComboBox(policyNames);


  public DefineChain() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

    logoLabel.setIcon(new ImageIcon("./Images/DefineChain.gif"));
    listModel = new ListSearchModel();
    table = new JTable(listModel);
    JScrollPane scrollPane = new JScrollPane(table);


    this.setLayout(borderLayout1);
    jPanel1.setLayout(xYLayout1);
    logoLabel.setBorder(BorderFactory.createEtchedBorder());
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    statusLabel.setToolTipText("");
    statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    statusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    tablePanel.setLayout(xYLayout3);
    table.setBorder(BorderFactory.createEtchedBorder());
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    tablePanel.setBackground(new Color(236, 233, 230));
    tablePanel.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.setMinimumSize(new Dimension(400, 200));
    jPanel3.setLayout(xYLayout2);
    nameTextField.setBackground(Color.white);
    nameTextField.setPreferredSize(new Dimension(75, 19));
    nameTextField.setEditable(false);
    policyLabel.setText("Policy");
    jLabel2.setText("Name");
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setBackground(new Color(236, 233, 230));
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setActionCommand("Ok");
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setText("OK");
    applyButton.addActionListener(new clickedApply());
    addButton.setBackground(new Color(236, 233, 230));
    addButton.setBorder(BorderFactory.createEtchedBorder());
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setText("Add");
    addButton.addActionListener(new clickedAdd());
    editButton.setBackground(new Color(236, 233, 230));
    editButton.setBorder(BorderFactory.createEtchedBorder());
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    editButton.setText("Edit");
    editButton.addActionListener(new clickedEdit());
    jPanel8.setLayout(xYLayout9);
    jPanel8.setBackground(new Color(236, 233, 230));
    jPanel8.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setBackground(new Color(236, 233, 230));
    deleteButton.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deleteButton.setText("Delete");
    deleteButton.addActionListener(new clickedDelete());
    this.setBackground(new Color(236, 233, 230));
    commentTextField.setBackground(Color.white);
    commentTextField.setEditable(false);
    commentLabel.setText("Comment");
    policyComboBox.setBackground(new Color(236, 233, 230));
    jPanel3.add(statusLabel,    new XYConstraints(358, 3, 61, 19));
    jPanel3.add(commentTextField, new XYConstraints(193, 53, 92, -1));
    jPanel3.add(jLabel2, new XYConstraints(34, 21, 49, -1));
    jPanel3.add(nameTextField, new XYConstraints(93, 20, 88, -1));
    jPanel3.add(policyLabel, new XYConstraints(210, 21, 41, -1));
    jPanel3.add(policyComboBox, new XYConstraints(258, 19, 104, 22));
    jPanel3.add(commentLabel, new XYConstraints(116, 54, 64, -1));
    jPanel1.add(logoLabel,  new XYConstraints(22, 13, 426, 67));
    jPanel1.add(jPanel8,  new XYConstraints(23, 85, 426, 49));
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel8.add(applyButton, new XYConstraints(287, 7, 79, 31));
    jPanel8.add(addButton, new XYConstraints(47, 7, 78, 32));
    jPanel8.add(deleteButton, new XYConstraints(126, 7, 80, 31));
    jPanel8.add(editButton, new XYConstraints(207, 7, 79, 31));
    jPanel1.add(tablePanel, new XYConstraints(21, 232, 430, 176));
    tablePanel.add(scrollPane, new XYConstraints(7, 6, 412, 161));
    jPanel1.add(jPanel3,   new XYConstraints(23, 138, 427, 89));

    statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
    // Database section
	db = new DBUtil();
	con = db.Establish();

    setdisable();

    refreshRecordTable();
  }//end jbinit();

  public static void refreshDefineChaintComboBox() {
      String SQL="";


                SQL = "SELECT * from definechain order by ID";
                rs = db.SQLRetrive(SQL);
          try {
                rs.first();

                while(rs.next()){
                    rs.previous();

                   if( !(rs.getString("ID").equals("1") ||  rs.getString("ID").equals("2") || rs.getString("ID").equals("3") ))

                  {
                    UpdatePanel.chainComboBox.addItem(rs.getString("Name"));
                    UpdatePanel.actionComboBox.addItem(rs.getString("Name"));

                    FtpTcp.actionComboBox.addItem(rs.getString("Name"));
                    FtpdataTcp.actionComboBox.addItem(rs.getString("Name"));
                    pop3Tcp.actionComboBox.addItem(rs.getString("Name"));
                    TelnetTcp.actionComboBox.addItem(rs.getString("Name"));
                    SshTcp.actionComboBox.addItem(rs.getString("Name"));
                    SmtpTcp.actionComboBox.addItem(rs.getString("Name"));
                    HttpTcp.actionComboBox.addItem(rs.getString("Name"));
                    DnsTcp.actionComboBox.addItem(rs.getString("Name"));

                    FtpTcp.chainComboBox.addItem(rs.getString("Name"));
                    FtpdataTcp.chainComboBox.addItem(rs.getString("Name"));
                    pop3Tcp.chainComboBox.addItem(rs.getString("Name"));
                    TelnetTcp.chainComboBox.addItem(rs.getString("Name"));
                    SshTcp.chainComboBox.addItem(rs.getString("Name"));
                    SmtpTcp.chainComboBox.addItem(rs.getString("Name"));
                    HttpTcp.chainComboBox.addItem(rs.getString("Name"));
                    DnsTcp.chainComboBox.addItem(rs.getString("Name"));

                    ChainSearch.chainComboBox.addItem(rs.getString("Name"));

                }
                    rs.next();
                }
                  if( !(rs.getString("ID").equals("1") ||  rs.getString("ID").equals("2") || rs.getString("ID").equals("3") ))

                  {

                    UpdatePanel.chainComboBox.addItem(rs.getString("Name"));
                    UpdatePanel.actionComboBox.addItem(rs.getString("Name"));

                    FtpTcp.actionComboBox.addItem(rs.getString("Name"));
                    FtpdataTcp.actionComboBox.addItem(rs.getString("Name"));
                    pop3Tcp.actionComboBox.addItem(rs.getString("Name"));
                    TelnetTcp.actionComboBox.addItem(rs.getString("Name"));
                    SshTcp.actionComboBox.addItem(rs.getString("Name"));
                    SmtpTcp.actionComboBox.addItem(rs.getString("Name"));
                    HttpTcp.actionComboBox.addItem(rs.getString("Name"));
                    DnsTcp.actionComboBox.addItem(rs.getString("Name"));

                    FtpTcp.chainComboBox.addItem(rs.getString("Name"));
                    FtpdataTcp.chainComboBox.addItem(rs.getString("Name"));
                    pop3Tcp.chainComboBox.addItem(rs.getString("Name"));
                    TelnetTcp.chainComboBox.addItem(rs.getString("Name"));
                    SshTcp.chainComboBox.addItem(rs.getString("Name"));
                    SmtpTcp.chainComboBox.addItem(rs.getString("Name"));
                    HttpTcp.chainComboBox.addItem(rs.getString("Name"));
                    DnsTcp.chainComboBox.addItem(rs.getString("Name"));

                    ChainSearch.chainComboBox.addItem(rs.getString("Name"));

                  }
               }
          catch(Exception ex) {
                System.out.println(ex.getMessage());
          }
  }

  void setenable() {
      nameTextField.setEditable(true);
      commentTextField.setEditable(true);
  }

  void setdisable() {
      nameTextField.setEditable(false);
      policyComboBox.setEditable(false);
      commentTextField.setEditable(false);

  }
  void clearfield() {
      nameTextField.setText("");
      policyComboBox.setSelectedIndex(1);
      commentTextField.setText("");
  }

  public static void Reset(){
            try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
                  refreshRecordTable();
                 System.out.println("Reset");

  }

   public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }

  class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          setenable();
          nameTextField.setEditable(true);
          commentTextField.setEditable(true);
          status="ADD";
          statusLabel.setIcon(new ImageIcon("./Images/Add.gif"));
      }
    }

    class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       setenable();
       ReturnRowSelect=table.getSelectedRow();
       System.out.println(ReturnRowSelect);
       statusLabel.setIcon(new ImageIcon("./Images/Edit.gif"));
       status="UPDATE";
       setEdit();
      }
    }

    public  void setEdit() {
               String SQL="",Name,Policy,Comment;

               ReturnRowSelect = table.getSelectedRow();
                   try {
                    rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                    }

                                  Name = rs.getString("Name");
                                  Policy = rs.getString("policy");
                                  Comment = rs.getString("Comment");

                                  nameTextField.setEditable(true);
                                  commentTextField.setEditable(true);

                                  nameTextField.setText(Name);
                                  policyComboBox.setSelectedItem(Policy);
                                  commentTextField.setText(Comment);




                  }
                                  catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }
  }//end setEdit


                    class clickedDelete implements ActionListener {
                        public void actionPerformed(ActionEvent e) {

                       String SQL="",Id;

                                       ReturnRowSelect= table.getSelectedRow();
                                       System.out.println("Return Row ......."+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getString("ID");
              if(!(Id.equals("1") || Id.equals("2") || Id.equals("3")))  {
		SQL = "DELETE FROM definechain"  + " WHERE ";
                SQL = SQL + "ID = '"+Id+"' ";
		db.SQLExecute(SQL);
		System.out.println(SQL);
              }
                                      }
                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                refreshRecordTable();

                                }
                          }
  void addtoComboBox() {
                    UpdatePanel.chainComboBox.addItem(nameTextField.getText().toString());
                    UpdatePanel.actionComboBox.addItem(nameTextField.getText().toString());

                    FtpTcp.actionComboBox.addItem(nameTextField.getText().toString());
                    FtpdataTcp.actionComboBox.addItem(nameTextField.getText().toString());
                    pop3Tcp.actionComboBox.addItem(nameTextField.getText().toString());
                    TelnetTcp.actionComboBox.addItem(nameTextField.getText().toString());
                    SshTcp.actionComboBox.addItem(nameTextField.getText().toString());
                    SmtpTcp.actionComboBox.addItem(nameTextField.getText().toString());
                    HttpTcp.actionComboBox.addItem(nameTextField.getText().toString());
                    DnsTcp.actionComboBox.addItem(nameTextField.getText().toString());

                    FtpTcp.chainComboBox.addItem(nameTextField.getText().toString());
                    FtpdataTcp.chainComboBox.addItem(nameTextField.getText().toString());
                    pop3Tcp.chainComboBox.addItem(nameTextField.getText().toString());
                    TelnetTcp.chainComboBox.addItem(nameTextField.getText().toString());
                    SshTcp.chainComboBox.addItem(nameTextField.getText().toString());
                    SmtpTcp.chainComboBox.addItem(nameTextField.getText().toString());
                    HttpTcp.chainComboBox.addItem(nameTextField.getText().toString());
                    DnsTcp.chainComboBox.addItem(nameTextField.getText().toString());

                    ChainSearch.chainComboBox.addItem(nameTextField.getText().toString());
  }

 class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          addtoComboBox();
          System.out.println("Apply");
          updateRecord();
          clearfield();
          setdisable();




      }
    }

   class ListSearchModel extends AbstractTableModel {
        	int LastRow=0;


                   	String[] columnNames = {
                	"Chain No.",
                        "Name",
                        "Policy",
                        "Comment"};


                //Object[][] data = new Object[LastRow][columnNames.length];

                Object[][] data = {
			{"","","",""},{"","","",""},{"", "","",""},{"","","",""},{"","","",""},{"","","",""},{"","","",""},{"","","",""},
			{"","","",""},{"","","",""},{"", "","",""},{"","","",""},{"","","",""},{"","","",""},{"","","",""},{"","","",""},
			{"","","",""},{"","","",""},{"", "","",""},{"","","",""},{"","","",""},{"","","",""},{"","","",""},{"","","",""},
                           		};



        public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;

	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
                //return new Integer(row*col);
	}

//	public Class getColumnClass(int c) {/
//		return getValueAt(0, c).getClass();
//	}

	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}

	public void clearData() {
        for(int i=0; i<data.length; i++)
		  for(int j=0; j<columnNames.length; j++)
		if (j<=15)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
	}
        }

   public static void refreshRecordTable() {
        String SQL="",Id,Name,Policy,Comment;



        if(con!=null)
        {
          try {
              SQL = "SELECT * FROM definechain order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

              listModel.clearData();
              rs.first();
              int row =0;
                             while (rs.next()) {
                                  rs.previous();
                                  Id = rs.getString("ID");
                                  Name = rs.getString("Name");
                                  Policy = rs.getString("policy");
                                  Comment = rs.getString("Comment");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Name,row,1);
                                  listModel.setValueAt(Policy,row,2);
                                  listModel.setValueAt(Comment,row,3);
                                  row += 1;
                                  rs.next();
                                  }//while

                                  Id = rs.getString("ID");
                                  Name = rs.getString("Name");
                                  Policy = rs.getString("policy");
                                  Comment = rs.getString("Comment");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Name,row,1);
                                  listModel.setValueAt(Policy,row,2);
                                  listModel.setValueAt(Comment,row,3);
                  }//try

                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh

    public void updateRecord() {
              String SQL, field = "", value = "",stringPK="";
              String Name="",Value="";
              int Id=0;
              int  ID=0;

    System.out.println("use updateRecord");
    if (status.equals("ADD")) {
    SQL = "INSERT INTO definechain" ;

      field="Name,policy,Comment";
      value=" '"+nameTextField.getText().trim()+"' ,'" +policyComboBox.getSelectedItem()+ "','"+commentTextField.getText().trim()+"'  " ;


      SQL = SQL + "(" + field + ") VALUES(" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

                   System.out.println("Test Return Row Select : " + ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                        rs.next();
                     }

                       Id = rs.getInt("ID");
                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }

//          String VarName="#";
//          VarName = VarName.concat(nameTextField.getText());
          SQL = "UPDATE definechain SET";
          SQL =SQL + " Name = '"+nameTextField.getText().trim()+"' ,policy = '"+policyComboBox.getSelectedItem()+"',Comment = '"+commentTextField.getText().trim()+"' ";

          field = "ID = "+Id+" ";
          SQL = SQL + " WHERE "+field;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }
          refreshRecordTable();
          status = "";
          statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
  } //end updateRecord()


  }//end class
