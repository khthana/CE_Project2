package jkserver;

import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.swing.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import org.w3c.dom.*;
import org.apache.xerces.parsers.DOMParser;
import org.bouncycastle.*;
import org.bouncycastle.jce.provider.*;

class threadAlarm extends Thread
{ threadAlarm(String src) { super(src);
  }
  private Properties prop = System.getProperties();
  public void run()
  { jkserverFrame.displayArea.append("\nblacklist>>> " + getName());
    jkserverFrame.displayArea.setCaretPosition(jkserverFrame.displayArea.getText().length());
    try { sleep(1800000); // 30 minutes
    }
    catch(Exception e)  { System.out.println("threadAlarm can't sleep");
                          System.out.println(e);
    }
    jkserverFrame.comboAlerted.removeItem(getName());
  }
}
class threadBlock extends Thread
{ threadBlock(String src) { super(src);
  }
  private Properties prop = System.getProperties();
  public void run()
  { try { Process p;
          if(prop.getProperty("os.name").equals("Windows 98") || prop.getProperty("os.name").equals("Windows 2000"))
          { p = Runtime.getRuntime().exec("notepad");
            jkserverFrame.displayArea.append("\nblock>>> " + getName() + " <<<100 sec");
            jkserverFrame.displayArea.setCaretPosition(jkserverFrame.displayArea.getText().length());
            sleep(100000);  // 100 secs
            jkserverFrame.displayArea.append("\nunblock>>> " + getName());
            jkserverFrame.displayArea.setCaretPosition(jkserverFrame.displayArea.getText().length());
          }
          else  { p = Runtime.getRuntime().exec("iptables -I INPUT 1 -s " + getName() + "/32 -j DROP");
                  p = Runtime.getRuntime().exec("iptables -I FORWARD 1 -s " + getName() + "/32 -j DROP");
                  jkserverFrame.displayArea.append("\nblock>>> " + getName() + " <<<100 sec");
                  jkserverFrame.displayArea.setCaretPosition(jkserverFrame.displayArea.getText().length());
                  sleep(100000);
                  p = Runtime.getRuntime().exec("iptables -D FORWARD -s " + getName() + "/32 -j DROP");
                  p = Runtime.getRuntime().exec("iptables -D INPUT -s " + getName() + "/32 -j DROP");
                  jkserverFrame.comboDy.removeItem(getName());
                  jkserverFrame.displayArea.append("\nunblock>>> " + getName());
                  jkserverFrame.displayArea.setCaretPosition(jkserverFrame.displayArea.getText().length());
          }
    }
    catch(Exception e)  { System.out.println("threadBlock - run - error");
                          System.out.println(e);
    }
  }
}
class threadDetect extends Thread
{ threadDetect(String name) { super(name);
  }
  private final String logFile = new String("packet.log");
  private Properties prop = System.getProperties();
  private String getSource(String line)
  { try { int ptrSrc = line.indexOf("SRC=");
          int ptrEqualSign = line.indexOf("=", ptrSrc);
          int ptrSpace = line.indexOf(" ", ptrSrc);
          String ip = line.substring(ptrEqualSign + 1, ptrSpace);
          return ip.trim();
    }
    catch(Exception e)  { return "";
    }
  }
  public void run()
  { try { FileWriter fw = new FileWriter(logFile);
          fw.write("log file is created by threadDetect");
          fw.close();
    }
    catch(IOException iox)  { System.out.println("threadDetect - run - create file error");
                              System.out.println(iox);
    }
    while(true)
    { try { FileReader fr = new FileReader(logFile);
            BufferedReader br = new BufferedReader(fr);
            String strBeforeDmesg = new String("");
            String str = new String("");
            strBeforeDmesg = br.readLine();
            br.close();
            sleep(10000);
            Process proc;
            if(prop.getProperty("os.name").equals("Windows 98") || prop.getProperty("os.name").equals("Windows 2000"))
              proc = Runtime.getRuntime().exec("notepad " + logFile);
            else
            { proc = Runtime.getRuntime().exec("dmesg");
              InputStream is = proc.getInputStream();
              byte[] b = new byte[1152];
              int n;
              String iis = new String("");
              while((n = is.read(b)) != -1)
                iis = iis + new String(b);  // if stdin is nothing, iis = ""
              FileWriter fwt = new FileWriter(logFile);
              fwt.write(iis);
              fwt.close();
            }
            FileReader frr = new FileReader(logFile);
            BufferedReader brr = new BufferedReader(frr);
            String strAfterDmesg = new String("");
            strAfterDmesg = brr.readLine();
            brr.close();
            if(!strBeforeDmesg.equals(strAfterDmesg))
            { FileReader fileReader = new FileReader(logFile);
              BufferedReader buffReader = new BufferedReader(fileReader);
              String strLogLine = new String("");
              String strSource = new String("");
              while((strLogLine = buffReader.readLine()) != null)
              { if(strLogLine.startsWith("DY-DROP: "))
                { strSource = getSource(strLogLine);
                  boolean found = false;
                  for(int i = 0; i < jkserverFrame.comboDy.getItemCount(); i++)
                    if(strSource.equals((String)jkserverFrame.comboDy.getItemAt(i)))
                      found = true;
                  if(!found)
                  { jkserverFrame.comboDy.addItem(strSource);
                    new threadBlock(strSource).start();
                  }
                }
                else
                if(strLogLine.startsWith("BLACKLIST: "))
                { strSource = getSource(strLogLine);
                  boolean alert = false;
                  for(int j = 0; j < jkserverFrame.comboAlert.getItemCount(); j++)
                    if(strSource.equals((String)jkserverFrame.comboAlert.getItemAt(j)))
                      alert = true;
                  if(alert)
                  { boolean found = false;
                    for(int i = 0; i < jkserverFrame.comboAlerted.getItemCount(); i++)
                      if(strSource.equals((String)jkserverFrame.comboAlerted.getItemAt(i)))
                        found = true;
                    if(!found)
                    { jkserverFrame.comboAlerted.addItem(strSource);
                      new threadAlarm(strSource).start();
                    }
                  }
                }
              }
              buffReader.close();
            }
      }
      catch(Exception e) {  System.out.println("threadDetect - run - error");
                            System.out.println(e);
      }
    }
  }
}

public class jkserverFrame extends JFrame {
  private final String strRemoteCtrl = new String("remoteControl");
  private final String strTextEdit = new String("textEdit");
  private final String strSendXML = new String("sendXML");
  private final String strReceiveXML = new String("recXML");
  private final String strLogin = new String("login");
  private final String strDisconnect = new String("disconnect");
  private final String tempFile = new String("temp.fw");
  private final String privFileName = new String("privKey.dec");
  private final String pubFileName = new String("pubKey.enc");
  private final String loginFile = new String("login.dat");
  private final String xmlFile = new String("firewallconfig.xml");
  private final String encryptedFile = new String("xmlEncrypted.txt");
  private final String scriptFile = new String("rc.firewall");
  private String strScriptFile = new String("");
  private String service = new String("");
  private int JKserverPort = 7123;
  private boolean loginComplete = false;
  private Properties prop = System.getProperties();
  private ServerSocket server;
  private Socket connection;
  private ObjectOutputStream output;
  private ObjectInputStream input;
  private int counter = 1;
  private String line = new String("#######################################################");

  JPanel contentPane;
  XYLayout xYLayout1 = new XYLayout();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JTextField enterField = new JTextField();
  TitledBorder titledBorder3;
  JButton okButton = new JButton();
  JScrollPane displayPane = new JScrollPane();
  public static JTextArea displayArea = new JTextArea();
  public static JComboBox comboAlert = new JComboBox();
  public static JComboBox comboDy = new JComboBox();
  public static JComboBox comboAlerted = new JComboBox();

  /**Construct the frame*/
  public jkserverFrame() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(jkserverFrame.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    contentPane.setFont(new java.awt.Font("SansSerif", 0, 12));
    contentPane.setForeground(Color.blue);
    contentPane.setToolTipText("JKserver for Linux Redhat 7.x");
    contentPane.setLayout(xYLayout1);
    this.setFont(new java.awt.Font("SansSerif", 0, 12));
    this.setLocale(new java.util.Locale("th", "", ""));
    this.setResizable(false);
    this.setSize(new Dimension(705, 505));
    this.setTitle("JKserver for Linux Redhat 7.x");
    enterField.setEnabled(false);
    enterField.setForeground(Color.blue);
    enterField.setBorder(BorderFactory.createLineBorder(Color.black));
    enterField.setNextFocusableComponent(okButton);
    enterField.setDisabledTextColor(Color.lightGray);
    enterField.setText("enterField");
    okButton.setBackground(Color.gray);
    okButton.setEnabled(false);
    okButton.setFont(new java.awt.Font("SansSerif", 0, 12));
    okButton.setForeground(Color.orange);
    okButton.setBorder(BorderFactory.createLineBorder(Color.black));
    okButton.setText("okButton");
    displayArea.setBackground(new Color(233, 249, 247));
    displayArea.setFont(new java.awt.Font("SansSerif", 0, 12));
    displayArea.setForeground(new Color(0, 0, 133));
    displayArea.setBorder(null);
    displayArea.setNextFocusableComponent(enterField);
    displayArea.setToolTipText("displayArea");
    displayArea.setDisabledTextColor(Color.lightGray);
    displayArea.setEditable(false);
    displayArea.setSelectionColor(new Color(144, 255, 186));
    displayArea.setText("displayArea");
    displayPane.setFont(new java.awt.Font("SansSerif", 0, 12));
    displayPane.setBorder(BorderFactory.createLineBorder(Color.black));
    displayPane.setNextFocusableComponent(displayArea);
    comboDy.setEnabled(false);
    comboDy.setVisible(false);
    comboDy.removeAllItems();
    comboAlerted.setEnabled(false);
    comboAlerted.setVisible(false);
    comboAlerted.removeAllItems();
    contentPane.add(enterField,      new XYConstraints(7, 404, 577, 25));
    contentPane.add(okButton,          new XYConstraints(592, 404, 100, 25));
    contentPane.add(displayPane,   new XYConstraints(7, 45, 685, 352));
    contentPane.add(comboAlert, new XYConstraints(8, 435, 112, 20));
    contentPane.add(comboDy, new XYConstraints(452, 471, 144, 20));
    contentPane.add(comboAlerted, new XYConstraints(430, 465, 76, 24));
    comboAlert.setEnabled(false);
    comboAlert.setVisible(false);
    comboAlert.removeAllItems();
    displayPane.getViewport().add(displayArea, null);

    if(!prop.getProperty("os.name").equals("Windows 98") && !prop.getProperty("os.name").equals("Windows 2000"))
      new threadDetect("dydrop_blacklist").start();
  }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
  public void runServer()
  { try { server = new ServerSocket(JKserverPort, 1);
            while(true) // run forever
            { waitForConnection();
              getStreams();
              service = getService();
              System.out.println(service);
              if(service.equals(strLogin))
                serviceLogin();
              else  { if(loginComplete)
                      { if(service.equals(strTextEdit))
                          serviceTextEdit();
                        else  if(service.equals(strSendXML))
                                serviceXML();
                              else  if(service.equals(strRemoteCtrl))
                                      serviceRemoteCtrl();
                                    else  if(service.equals(strReceiveXML))
                                            serviceXML_();
                      }
              }
              closeConnection();
              ++counter;
            }
          }
    catch(EOFException eofEx)  { System.out.println("client disconnected connection");
    }
    // problems with i/o
    catch(IOException ioEx) { ioEx.printStackTrace();
    }
  }
  private void waitForConnection() throws IOException
  { if(displayArea.getText().equals("displayArea"))
      displayArea.setText("waiting for connection");
    else  displayArea.append("\nwaiting for connection");
    displayArea.setCaretPosition(displayArea.getText().length());
    connection = server.accept();
    displayArea.append("\n" + line);
    displayArea.append("\nconnection "+counter+" received from: "+connection.getInetAddress().getHostName());
    displayArea.setCaretPosition(displayArea.getText().length());
  }
  private void getStreams() throws IOException
  { output = new ObjectOutputStream(connection.getOutputStream());
    output.flush();
    input = new ObjectInputStream(connection.getInputStream());
  }
  private void closeConnection() throws IOException
  { output.close();
    input.close();
    connection.close();
    displayArea.append("\nconnection is closed");
    displayArea.append("\n" + line);
    displayArea.setCaretPosition(displayArea.getText().length());
  }
  private PrivateKey getPrivateKey()
  { try { FileInputStream privFile = new FileInputStream(privFileName);
          byte[] bytePrivKey = new byte[privFile.available()];
          privFile.read(bytePrivKey);
          privFile.close();
          PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(bytePrivKey);
          KeyFactory keyFac = KeyFactory.getInstance("RSA", "BC");
          PrivateKey privKey = keyFac.generatePrivate(keySpec);
          return privKey;
    }
    catch(Exception e)  { System.out.println("getPrivateKey - get privKey from file error");
                          return null;
    }
  }
  private void serviceLogin()
  { Security.addProvider(new  BouncyCastleProvider());
    loginComplete = false;
    try { PrivateKey privKey = getPrivateKey();
          byte[] byteCipherText = new byte[512];
          int len = input.read(byteCipherText);
          // create cipher which used to decrypt
          Cipher decCipher = Cipher.getInstance("RSA", "BC");
          decCipher.init(Cipher.DECRYPT_MODE, privKey);
          // decrypt
          ByteArrayOutputStream baos = new ByteArrayOutputStream();
          int k = (((RSAPrivateKey)privKey).getModulus().bitLength() + 7) >>> 3;
          int inOff = 0;
          while(true) { int leftToDo = len - inOff;
                        if(leftToDo <= 0) { break;
                        }
                        int chunkSize = (leftToDo > k ? k: leftToDo);
                        decCipher.update(byteCipherText, inOff, chunkSize);
                        baos.write(decCipher.doFinal());
                        inOff += chunkSize;
          }
          byte[] bytePlainText = baos.toByteArray();
          baos.flush();
          String strPlainText = new String(bytePlainText);
          // check login data
          FileReader fin = new FileReader(loginFile);
          BufferedReader bin = new BufferedReader(fin);
          String str = new String("");
          boolean boo = false;
          while((str = bin.readLine()) != null)
          { if(str.equals(strPlainText))
            { boo = true;
              break;
            }
          }
          bin.close();
          if(boo)
            output.writeObject("ok");
          else  output.writeObject("error");
          output.flush();
          loginComplete = true;
    }
    catch(Exception e)  { System.out.println("serviceLogin - error");
    System.out.println(e);
    }
  }
  private PublicKey getPublicKey()
  { byte[] bytePubKey;
    try { FileInputStream pubFile = new FileInputStream(pubFileName);
            bytePubKey = new byte[pubFile.available()];
            pubFile.read(bytePubKey);
            pubFile.close();
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(bytePubKey);
            KeyFactory keyFac = KeyFactory.getInstance("RSA", "BC");
            PublicKey pubKey = keyFac.generatePublic(keySpec);
            return pubKey;
    }
    catch(Exception e)  { System.out.println("login - getPublickey - get pubKey from file error");
                          return null;
    }
  }
  private void serviceXML_()
  { try { BufferedReader buff = new BufferedReader(new FileReader(xmlFile));
          String strXmlLine = new String("");
          while((strXmlLine = buff.readLine()) != null)
          { System.out.println(strXmlLine);
            byte[] byteXmlLine = strXmlLine.getBytes();
            Security.addProvider(new BouncyCastleProvider());
            PublicKey pubKey = getPublicKey();
            Cipher encCipher = Cipher.getInstance("RSA", "BC");
            encCipher.init(Cipher.ENCRYPT_MODE, pubKey);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int k = (((RSAPublicKey)pubKey).getModulus().bitLength() + 7) >>> 3;
            int maxSize = k - 11;
            int inOff = 0;
            while(true) { int leftToDo = byteXmlLine.length - inOff;
                                  if(leftToDo <= 0) { break;
                                  }
                                  int chunkSize = (leftToDo > maxSize ? maxSize: leftToDo);
                                  encCipher.update(byteXmlLine, inOff, chunkSize);
                                  baos.write(encCipher.doFinal());
                                  inOff += chunkSize;
            }
            byte[] byteEncryptedLine = baos.toByteArray();
            baos.flush();
            System.out.println(new String(byteEncryptedLine));
            output.write(byteEncryptedLine);
            output.flush();
          }
          String strDone = new String("$$$done$$$$");
          output.write(strDone.getBytes());
          output.flush();
    }
    catch(Exception e)  { displayArea.append("\n!!! serviceXML_ error !!!!");
                          displayArea.setCaretPosition(displayArea.getText().length());
    }
  }
  private void serviceXML()
  { final String scriptHeader = "modprobe -r ipchains\n" +
                                "modprobe ip_tables\n" +
                                "modprobe iptable_filter\n" +
                                "modprobe iptable_nat\n" +
                                "modprobe ip_conntrack\n" +
                                "modprobe ip_conntrack_ftp\n\n" +
                                "iptables -X\n" +
                                "iptables -F\n" +
                                "iptables -Z\n" +
                                "iptables -t nat -X\n" +
                                "iptables -t nat -F\n" +
                                "iptables -t nat -Z\n\n";
    final String dtdXML = "<?xml version=\"1.0\"?>\n" +
                          "<!DOCTYPE FIREWALL_CONFIG [\n" +
                          "<!ELEMENT FIREWALL_CONFIG (OPTIONS,VAR_LIST*,CHAIN_LIST*,BLACK_LIST*,CONFIG_CHAIN*)>\n" +
                          "<!ELEMENT OPTIONS (DISABLE_BROADCASTS,DISABLE_PINGS,DISABLE_ICMP_REDIRECT,ENABLE_PROTECTION,DISABLE_SPOOFING,ENABLE_SYN_COOKIES,DISABLE_SROUTING,LOG_MARTIANS,DY_DROP)>\n" +
                          "<!ELEMENT DISABLE_BROADCASTS (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_PINGS (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_ICMP_REDIRECT (#PCDATA)>\n" +
                          "<!ELEMENT ENABLE_PROTECTION (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_SPOOFING (#PCDATA)>\n" +
                          "<!ELEMENT ENABLE_SYN_COOKIES (#PCDATA)>\n" +
                          "<!ELEMENT DISABLE_SROUTING (#PCDATA)>\n" +
                          "<!ELEMENT LOG_MARTIANS (#PCDATA)>\n" +
                          "<!ELEMENT DY_DROP (#PCDATA)>\n" +
                          "<!ELEMENT VAR_LIST (VAR*)>\n" +
                          "<!ELEMENT VAR (VALUE,COMMENT)>\n" +
                          "<!ELEMENT VALUE (#PCDATA)>\n" +
                          "<!ELEMENT COMMENT (#PCDATA)>\n" +
                          "<!ELEMENT CHAIN_LIST (CHAIN*)>\n" +
                          "<!ELEMENT CHAIN (POLICY,COMMENT)>\n" +
                          "<!ELEMENT POLICY (#PCDATA)>\n" +
                          "<!ELEMENT BLACK_LIST (BL*)>\n" +
                          "<!ELEMENT BL (ADDR,STATUS)>\n" +
                          "<!ELEMENT ADDR (#PCDATA)>\n" +
                          "<!ELEMENT STATUS (#PCDATA)>\n" +
                          "<!ELEMENT CONFIG_CHAIN (RULE*)>\n" +
                          "<!ELEMENT RULE (TABLE?,CHAIN_NAME,PROTOCOL?,SRC?,DES?,IN_IF?,OUT_IF?,FRAGMENT?,MATCH?,MARK?,UID_OWNER?,GID_OWNER?,PID_OWNER?,SID_OWNER?,JUMP_TARGET,TARGET_EXT?)>\n" +
                          "<!ELEMENT TABLE (#PCDATA)>\n" +
                          "<!ELEMENT CHAIN_NAME (#PCDATA)>\n" +
                          "<!ELEMENT PROTOCOL (NOT,VALUE,SRC_PORT?,DES_PORT?,TCP_FLAG?,SYN?,TCP_OP?,ICMP_TYPE?)>\n" +
                          "<!ELEMENT NOT (#PCDATA)>\n" +
                          "<!ELEMENT SRC_PORT (NOT,VALUE)>\n" +
                          "<!ELEMENT DES_PORT (NOT,VALUE)>\n" +
                          "<!ELEMENT TCP_FLAG (MASK,COMP)>\n" +
                          "<!ELEMENT MASK (NOT,VALUE)>\n" +
                          "<!ELEMENT SYN (NOT,VALUE)>\n" +
                          "<!ELEMENT TCP_OP (NOT,VALUE)>\n" +
                          "<!ELEMENT ICMP_TYPE (NOT,VALUE)>\n" +
                          "<!ELEMENT SRC (NOT,VALUE)>\n" +
                          "<!ELEMENT DES (NOT,VALUE)>\n" +
                          "<!ELEMENT IN_IF (NOT,VALUE)>\n" +
                          "<!ELEMENT OUT_IF (NOT,VALUE)>\n" +
                          "<!ELEMENT FRAGMENT (NOT,VALUE)>\n" +
                          "<!ELEMENT MATCH (MAC?,LIMIT?,MULTIPORT?,STATE?,UNCLEAN?,TOS?)>\n" +
                          "<!ELEMENT MAC (VALUE, SOURCE)>\n" +
                          "<!ELEMENT SOURCE (NOT ,VALUE)>\n" +
                          "<!ELEMENT LIMIT (VALUE, RATE?, BURST?)>\n" +
                          "<!ELEMENT RATE (#PCDATA)>\n" +
                          "<!ELEMENT BURST (#PCDATA)>\n" +
                          "<!ELEMENT MULTIPORT (VALUE, SPORT, DPORT, PORT)>\n" +
                          "<!ELEMENT SPORT (#PCDATA)>\n" +
                          "<!ELEMENT DPORT (#PCDATA)>\n" +
                          "<!ELEMENT PORT (#PCDATA)>\n" +
                          "<!ELEMENT STATE (VALUE, STATE_LIST)>\n" +
                          "<!ELEMENT STATE_LIST (#PCDATA)>\n" +
                          "<!ELEMENT UNCLEAN (#PCDATA)>\n" +
                          "<!ELEMENT TOS (VALUE,TYPE)>\n" +
                          "<!ELEMENT TYPE (#PCDATA)>\n" +
                          "<!ELEMENT MARK (#PCDATA)>\n" +
                          "<!ELEMENT UID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT GID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT PID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT SID_OWNER (#PCDATA)>\n" +
                          "<!ELEMENT JUMP_TARGET (#PCDATA)>\n" +
                          "<!ELEMENT TARGET_EXT (LOG_LEVEL?,LOG_PREFIX?,LOG_TCP_SEQ?,LOG_TCP_OPT?,LOG_IP_OPT?,SET_MARK?,REJECT_WITH?,SET_TOS?,TO?,TO_SRC?,TO_DES?,TO_PORT?)>\n" +
                          "<!ELEMENT LOG_LEVEL (#PCDATA)>\n" +
                          "<!ELEMENT LOG_PREFIX (#PCDATA)>\n" +
                          "<!ELEMENT LOG_TCP_OPT (#PCDATA)>\n" +
                          "<!ELEMENT LOG_IP_OPT (#PCDATA)>\n" +
                          "<!ELEMENT SET_MARK (#PCDATA)>\n" +
                          "<!ELEMENT REJECT_WITH (#PCDATA)>\n" +
                          "<!ELEMENT SET_TOS (#PCDATA)>\n" +
                          "<!ELEMENT TO (#PCDATA)>\n" +
                          "<!ELEMENT TO_SRC (#PCDATA)>\n" +
                          "<!ELEMENT TO_DES (#PCDATA)>\n" +
                          "<!ELEMENT TO_PORT (#PCDATA)>\n" +
                          "<!ATTLIST BL\n" +
                            "number CDATA #IMPLIED>\n" +
                          "<!ATTLIST RULE\n" +
                            "n CDATA #IMPLIED>\n" +
                          "]>\n";
    String xmlData = new String("");
    String EncryptedData = new String("");
    Security.addProvider(new  BouncyCastleProvider());
    comboAlert.removeAllItems();
    try { byte[] byteEncryptedLine = new byte[1152];
          int len = input.read(byteEncryptedLine);
          String strDone = new String(byteEncryptedLine).substring(0, 11);
          while(!strDone.equals("$$$done$$$$"))
          { EncryptedData += new String(byteEncryptedLine) + "\n";
            PrivateKey privKey = getPrivateKey();
            // create cipher which used to decrypt
            Cipher decCipher = Cipher.getInstance("RSA", "BC");
            decCipher.init(Cipher.DECRYPT_MODE, privKey);
            // decrypt
            System.out.println("decrypt");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int k = (((RSAPrivateKey)privKey).getModulus().bitLength() + 7) >>> 3;
            //int maxSize = k - 11;
            int inOff = 0;
            while(true) { int leftToDo = len - inOff;//byteEncryptedLine.length - inOff;
                          if(leftToDo <= 0) { break;
                          }
                          int chunkSize = (leftToDo > k ? k: leftToDo);
                          decCipher.update(byteEncryptedLine, inOff, chunkSize);
                          baos.write(decCipher.doFinal());
                          inOff += chunkSize;
            }
            byte[] byteXmlLine = baos.toByteArray();
            baos.flush();
            String strXmlLine = new String(byteXmlLine);
            xmlData += strXmlLine + "\n";
            len = input.read(byteEncryptedLine);
            strDone = new String(byteEncryptedLine).substring(0, 11);
          }

          String contentXML = dtdXML + xmlData;
          // write to file
          FileWriter fw = new FileWriter(xmlFile);
          fw.write(contentXML);
          fw.close();
          FileWriter efw = new FileWriter(encryptedFile);
          efw.write(EncryptedData);
          efw.close();

          Node firewall_conf = getXMLdoc(xmlFile).getDocumentElement();
          Node op_node = firewall_conf.getFirstChild();
          Node var_node = op_node.getNextSibling();
          Node chain_node = var_node.getNextSibling();
          Node black_node = chain_node.getNextSibling();
          Node conf_chain_node = black_node.getNextSibling();

          strScriptFile = "";
          compileXML(var_node);
          strScriptFile += "\n";
          compileXML(chain_node);
          strScriptFile += "\n";
          compileXML(op_node);
          strScriptFile += "\n";
          compileXML(black_node);
          strScriptFile += "\n";
          //compileXML(conf_chain_node);
          NodeList rule_list = conf_chain_node.getChildNodes();
          if(rule_list != null)
            for(int i = 0; i < rule_list.getLength(); i++)
              { compileXML(rule_list.item(i));
                strScriptFile += "\n";
              }

          System.out.println(strScriptFile + "*");
          FileWriter sfw = new FileWriter(scriptFile);
          sfw.write(scriptHeader + strScriptFile);
          sfw.close();

          displayArea.append("\nrun script>>> " + scriptFile);
          displayArea.setCaretPosition(displayArea.getText().length());
          Process proc;
          if(prop.getProperty("os.name").equals("Windows 98") || prop.getProperty("os.name").equals("Windows 2000"))
            proc = Runtime.getRuntime().exec("notepad " + scriptFile);
          else  proc = Runtime.getRuntime().exec("bash " + scriptFile);
    }
    catch(Exception e)  { displayArea.append("\n!!! serviceXML error !!!!");
                          displayArea.setCaretPosition(displayArea.getText().length());
    }
  }
  private String nodeValue(String value)
  { String str = new String("");
    if(value.equals("null"))
      str = "";
    else  str = value;
    return str;
  }
  private String genPara(String value, String para)
  { String str = new String("");
    if(value.equals(""))
      str = "";
    else  str = " " + para + " " +value;
    return str;
  }
  private void compileXML(Node node)
  { switch(node.getNodeType())
    { case  Node.ELEMENT_NODE:
        String nodeName = node.getNodeName();
        if(nodeName.equals("VAR"))  // get var's name
        { NamedNodeMap attr = node.getAttributes();
          strScriptFile += nodeValue(attr.item(0).getNodeValue()) + "=";
        }
        if(nodeName.equals("CHAIN"))
        { NamedNodeMap attr = node.getAttributes();
          String chainName = nodeValue(attr.item(0).getNodeValue());
          if((!chainName.equals("INPUT")) && (!chainName.equals("OUTPUT")) && (!chainName.equals("FORWARD")))
            strScriptFile += "iptables -N " + chainName + "\n";
          strScriptFile += "iptables -P " + chainName;
        }
        if(nodeName.equals("RULE"))
          strScriptFile += "iptables";
        if(nodeName.equals("PROTOCOL"))
          strScriptFile += " -p";
        if(nodeName.equals("SRC_PORT"))
          strScriptFile += " --sport";
        if(nodeName.equals("DES_PORT"))
          strScriptFile += " --dport";
        if(nodeName.equals("TCP_FLAG"))
          strScriptFile += " --tcp-flags";
        //if(nodeName.equals("SYN"))
        if(nodeName.equals("TCP_OP"))
          strScriptFile += " --tcp-option";
        if(nodeName.equals("ICMP_TYPE"))
          strScriptFile += " --icmp-type";
        if(nodeName.equals("SRC"))
          strScriptFile += " -s";
        if(nodeName.equals("DES"))
          strScriptFile += " -d";
        if(nodeName.equals("IN_IF"))
          strScriptFile += " -i";
        if(nodeName.equals("OUT_IF"))
          strScriptFile += " -o";
        //if(nodeName.equals("FRAGMENT"))
        //if(nodeName.equals("MATCH"))
        if(nodeName.equals("MAC") || nodeName.equals("LIMIT") || nodeName.equals("MULTIPORT") || nodeName.equals("STATE") ||
          nodeName.equals("TOS"))
          strScriptFile += " -m";
        if(nodeName.equals("SOURCE"))
          strScriptFile += " --mac-source";
        NodeList kids = node.getChildNodes();
        if(kids != null)
          for(int j = 0; j < kids.getLength(); j++)
            compileXML(kids.item(j));
        break;
      case  Node.TEXT_NODE:
        String parentName = node.getParentNode().getNodeName();
        String nodeVal = nodeValue(node.getNodeValue());
        if(parentName.equals("VALUE") && node.getParentNode().getParentNode().getNodeName().equals("VAR"))
          strScriptFile += "\"" + nodeVal + "\"";
        if(parentName.equals("POLICY") || parentName.equals("NOT") ||
          (parentName.equals("VALUE") && !node.getParentNode().getParentNode().getNodeName().equals("VAR")) ||
          parentName.equals("COMP"))
          if(!nodeVal.equals(""))
            strScriptFile += " " + nodeVal;
        if(parentName.equals("COMMENT"))
          strScriptFile += " # " + nodeVal + "\n";
        if(parentName.equals("ADDR")) // blacklist
          strScriptFile += "iptables -A INPUT -s " + nodeVal + "/32 -m limit --limit 1/second -j LOG --log-prefix \"BLACKLIST: \"\n" +
                                      "iptables -A INPUT -s " + nodeVal + "/32 -j DROP\n" +
                                      "iptables -A FORWARD -s " + nodeVal + "/32 -m limit --limit 1/second -j LOG --log-prefix \"BLACKLIST: \"\n" +
                                      "iptables -A FORWARD -s " + nodeVal + "/32 -j DROP\n";
        if(parentName.equals("STATUS"))
          if(nodeVal.equals("Alert"))
            comboAlert.addItem(node.getParentNode().getPreviousSibling().getFirstChild().getNodeValue());
        if(parentName.equals("TABLE"))
          strScriptFile += genPara(nodeVal, "-t");
        if(parentName.equals("CHAIN_NAME"))
          strScriptFile += genPara(nodeVal, "-A");
        if(parentName.equals("RATE"))
          strScriptFile += genPara(nodeVal, "--limit");
        if(parentName.equals("BURST"))
          strScriptFile += genPara(nodeVal, "--limit-burst");
        if(parentName.equals("SPORT"))
          strScriptFile += genPara(nodeVal, "--sport");
        if(parentName.equals("DPORT"))
          strScriptFile += genPara(nodeVal, "--dport");
        if(parentName.equals("PORT"))
          strScriptFile += genPara(nodeVal, "--port");
        if(parentName.equals("STATE_LIST"))
          strScriptFile += genPara(nodeVal, "--state");
        if(parentName.equals("UNCLEAN"))
          strScriptFile += genPara(nodeVal, "-m");
        if(parentName.equals("TYPE"))
          strScriptFile += genPara(nodeVal, "--tos");
        if(parentName.equals("MARK"))
          strScriptFile += genPara(nodeVal, "--mark");
        if(parentName.equals("UID_OWNER"))
          strScriptFile += genPara(nodeVal, "--uid-owner");
        if(parentName.equals("GID_OWNER"))
          strScriptFile += genPara(nodeVal, "--gid-owner");
        if(parentName.equals("PID_OWNER"))
          strScriptFile += genPara(nodeVal, "--pid-owner");
        if(parentName.equals("SID_OWNER"))
          strScriptFile += genPara(nodeVal, "--sid-owner");
        if(parentName.equals("JUMP_TARGET"))
          strScriptFile += genPara(nodeVal, "-j");
        if(parentName.equals("LOG_LEVEL"))
          strScriptFile += genPara(nodeVal, "--log-level");
        if(parentName.equals("LOG_PREFIX"))
          strScriptFile += genPara(nodeVal, "--log-prefix");
        if(parentName.equals("LOG_TCP_SEQ"))
          strScriptFile += genPara(nodeVal, "--log-tcp-sequence");
        if(parentName.equals("LOG_TCP_OPT"))
          strScriptFile += genPara(nodeVal, "--log-tcp-options");
        if(parentName.equals("LOG_IP_OPT"))
          strScriptFile += genPara(nodeVal, "--log-ip-options");
        if(parentName.equals("SET_MARK"))
          strScriptFile += genPara(nodeVal, "--set-mark");
        if(parentName.equals("REJECT_WITH"))
          strScriptFile += genPara(nodeVal, "--reject-with");
        if(parentName.equals("SET_TOS"))
          strScriptFile += genPara(nodeVal, "--set-tos");
        if(parentName.equals("TO"))
          strScriptFile += genPara(nodeVal, "--to");
        if(parentName.equals("TO_SRC"))
          strScriptFile += genPara(nodeVal, "--to-source");
        if(parentName.equals("TO_DES"))
          strScriptFile += genPara(nodeVal, "--to-destination");
        if(parentName.equals("TO_PORT"))
          strScriptFile += genPara(nodeVal, "--to-ports");
        if(parentName.equals("DISABLE_BROADCASTS") || parentName.equals("DISABLE_PINGS") ||
          parentName.equals("DISABLE_ICMP_REDIRECT") || parentName.equals("ENABLE_PROTECTION") ||
          parentName.equals("DISABLE_SPOOFING") || parentName.equals("ENABLE_SYN_COOKIES") ||
          parentName.equals("DISABLE_SROUTING") || parentName.equals("LOG_MARTIANS") || parentName.equals("DY_DROP"))
          strScriptFile += nodeVal + "\n";
        break;
      default:
        System.out.println("compileXML - default");
        System.out.println(node.getNodeType());
    }
  }
  private Document getXMLdoc(String file)
  { try { DOMParser parser = new DOMParser();
          parser.setIncludeIgnorableWhitespace(false);
          parser.parse(xmlFile);
          Document document = parser.getDocument();
          return document;
    }
    catch(Exception e)  { e.printStackTrace(System.err);
                          return null;
    }
  }
  private void serviceRemoteCtrl() throws IOException
  { String commandLine = new String("");
    String temp = new String("");
    do  { try { byte[] byteCL = new byte[1152];
                // read byte because wanna crypt this commandLine
                input.read(byteCL);
                commandLine = new String(byteCL).trim();
                temp = commandLine;
                temp = temp.toLowerCase();
                if(temp.equals("")) // connection already be closed by unusual reason
                { temp = strDisconnect;
                }
                else
                { displayArea.append("\nexecute: " + commandLine);
                  displayArea.setCaretPosition(displayArea.getText().length());
                }

                if(!temp.equals(strDisconnect))
                  try { Process cmdExe = Runtime.getRuntime().exec(commandLine);
                        // executer will be here if exec is ok
                        output.writeObject("ok");
                        output.flush();
                        try
                        { // get stdin
                          InputStream is = cmdExe.getInputStream();
                          byte[] b = new byte[1152];
                          int i;
                          String iis = new String("");
                          while((i = is.read(b)) != -1)
                            iis = iis + new String(b);
                          // if stdin is nothing, iis = ""
                          output.writeObject(iis);
                          output.flush();
                          // get stderr
                          InputStream es = cmdExe.getErrorStream();
                          String ees = new String("");
                          while((i = es.read(b)) != -1)
                            ees = ees + new String(b);
                          // if stderr is nothing, ees = ""
                          output.writeObject(ees);
                          output.flush();
                        }
                        catch(IOException e)  { System.out.println("caught error in get stdin & stderr process");
                                                System.out.println(e);
                        }
                  }
                  catch(IOException e)  { // executer will be here if exec is unexecutable
                                          output.writeObject("failed");
                                          output.flush();
                                          displayArea.append(" <<<unexecutable command");
                                          displayArea.setCaretPosition(displayArea.getText().length());
                  }
            }
            catch(Exception ex)  { //System.out.println("read commandLine error");
                                                    //closeConnection();
                                                    displayArea.append("\n!!! read command line error !!!!");
                                                    displayArea.setCaretPosition(displayArea.getText().length());
          }
    } while(!temp.equals(strDisconnect));
  }
  private void serviceTextEdit()
  { String str = new String("");
    try { str = (String)input.readObject();
          FileWriter fw = new FileWriter(tempFile);
          fw.write(str);
          fw.close();
          try { displayArea.append("\nanalyze>>> " + tempFile);
                displayArea.setCaretPosition(displayArea.getText().length());
                System.out.println(prop);
                Process p;
                if(prop.getProperty("os.name").equals("Windows 98") || prop.getProperty("os.name").equals("Windows 2000"))
                  p = Runtime.getRuntime().exec("notepad " + tempFile);
                else  p = Runtime.getRuntime().exec("bash " + tempFile);
                // executer will be here if exec is ok
                output.writeObject("ok");
                output.flush();
                // get and send stdin
                InputStream is = p.getInputStream();
                byte[] b = new byte[1152];
                int i;
                String iis = new String("");
                while((i = is.read(b)) != -1) // if stdin is nothing
                  iis = iis + new String(b);  // don't do this, so iss = ""
                System.out.println(iis);
                output.writeObject(iis);
                output.flush();
                // get and send stderr
                InputStream es = p.getErrorStream();
                String ees = new String("");
                while((i = es.read(b)) != -1)
                  ees = ees + new String(b);
                System.out.println(ees);
                output.writeObject(ees);
                output.flush();
                // run original script for rollback
                if(prop.getProperty("os.name").equals("Windows 98") || prop.getProperty("os.name").equals("Windows 2000"))
                  p = Runtime.getRuntime().exec("notepad " + scriptFile);
                else  p = Runtime.getRuntime().exec("bash " + scriptFile);
          }
          catch(Exception e)  { // executer will be here if exec is unexecutable
                                output.writeObject("failed");
                                output.flush();
                                //displayArea.append(" <<<error");
                                //displayArea.setCaretPosition(displayArea.getText().length());
          }
    }
    catch(Exception e)  { System.out.println("readObject or write file error in serviceTextEdit");
                          System.out.println(e);
    }
  }
  private String getService()
  { String str = new String("");
    try { str = (String)input.readObject();
    }
    catch(Exception e)  { System.out.println(e);
    }
    return str;
  }
}