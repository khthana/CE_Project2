import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.swing.*;
import javax.crypto.*;
import com.borland.jbcl.layout.*;
import org.bouncycastle.jce.provider.*;

public class ClientChat extends JPanel {
  private ObjectOutputStream output;
  private ObjectInputStream input;
  private String chatServer;
  private byte[]  decDataB = new  byte[1152]; // about 1000 chars
  private Socket client;

  ButtonGroup buttonGroup1 = new ButtonGroup();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JLabel messageLabel = new JLabel();
  JTextArea displayArea = new JTextArea();
  JPanel jPanel4 = new JPanel();
  JScrollPane scrollPane = new JScrollPane();
  JPanel jPanel2 = new JPanel();
  JPanel displayareaPanel = new JPanel();
  JLabel logoLabel = new JLabel();
  JButton execmdButton2 = new JButton(new ImageIcon("images/exec.png"));
  JTextField commandTextField = new JTextField();
  JButton execmdButton = new JButton(new ImageIcon("images/exec.png"));
  XYLayout xYLayout6 = new XYLayout();
  XYLayout xYLayout4 = new XYLayout();
  XYLayout xYLayout3 = new XYLayout();
  JTextField ipconnectTextField = new JTextField();

  /**Construct the frame*/
  public ClientChat(String host) {
    //super("Client");
    // set server to which this client connects
    chatServer = host;

    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    this.setBackground(new Color(236, 233, 230));
    this.setMaximumSize(new Dimension(600, 500));
    xYLayout1.setWidth(523);
    xYLayout1.setHeight(432);

    //scrollPane.add(displayArea, null);
    //setIconImage(Toolkit.getDefaultToolkit().createImage(ClientChat.class.getResource("[Your Icon]")));
   // contentPane = (JPanel) this.getContentPane();

    setFont(new java.awt.Font("SansSerif", 0, 12));
   //this.setTitle("ChatClient");
    this.setVisible(true);
    this.setLayout(xYLayout1);

  //runClient();
    jPanel1.setLayout(xYLayout2);
    messageLabel.setIcon(new ImageIcon("./Images/message.gif"));
    messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    messageLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    displayArea.setLineWrap(true);
    displayArea.setWrapStyleWord(true);
    displayArea.setBackground(Color.white);
    displayArea.setMinimumSize(new Dimension(0, 0));
    jPanel4.setLayout(xYLayout6);
    jPanel4.setBackground(new Color(236, 233, 230));
    jPanel4.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.setMinimumSize(new Dimension(0, 0));
    scrollPane.setPreferredSize(new Dimension(300, 18));
    jPanel2.setLayout(xYLayout4);
    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    displayareaPanel.setBackground(new Color(236, 233, 230));
    displayareaPanel.setBorder(BorderFactory.createEtchedBorder());
    displayareaPanel.setLayout(xYLayout3);
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    logoLabel.setIcon(new ImageIcon("./Images/Chat.gif"));
    execmdButton2.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent e) {
        execmdButton2_actionPerformed(e);
      }
    });
    execmdButton2.setText("Connect");
    execmdButton2.setHorizontalTextPosition(SwingConstants.LEFT);
    execmdButton2.setActionCommand("Ok");
    execmdButton2.setBorder(BorderFactory.createEtchedBorder());
    execmdButton2.setBackground(new Color(236, 233, 230));
    execmdButton.setBackground(new Color(236, 233, 230));
    execmdButton.setBorder(BorderFactory.createEtchedBorder());
    execmdButton.setActionCommand("Ok");
    execmdButton.setHorizontalTextPosition(SwingConstants.LEFT);
    execmdButton.setText("EXE");
    execmdButton.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(ActionEvent e) {
        execmdButton_actionPerformed(e);
      }
    });
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel4.add(messageLabel, new XYConstraints(5, 8, 67, 26));
    jPanel4.add(commandTextField, new XYConstraints(73, 11, 295, 22));
    jPanel4.add(execmdButton, new XYConstraints(396, 6, 79, 31));
    jPanel1.add(displayareaPanel,    new XYConstraints(3, 95, 495, 204));
    displayareaPanel.add(scrollPane,                  new XYConstraints(11, 10, 470, 179));
    jPanel1.add(jPanel2, new XYConstraints(3, 18, 495, 70));
    scrollPane.getViewport().add(displayArea, null);
    jPanel2.add(ipconnectTextField, new XYConstraints(375, 3, 104, 25));
    jPanel2.add(execmdButton2, new XYConstraints(390, 33, 79, 31));
    jPanel2.add(logoLabel,     new XYConstraints(93, 1, 279, 72));
    jPanel1.add(jPanel4,     new XYConstraints(3, 308, 497, 51));
    this.add(jPanel1,  new XYConstraints(3, 31, 518, 366));
  }

    class clickedConnect implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          runClient();
     }
    }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
   // super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
  // connect to server and process messages from server
   public  void runClient()
  {
    // connect ot server, get streams process connection
    try {
      // step 1: create a socket to make connection
      connectToServer();
      // step 2: get the input and output streams
      getStreams();
      // step 3: process connection
      processConnection();
      // step 4: close connection
      closeConnection();
    }
    // server closed connection
    catch(EOFException eofException) {
      System.out.println("server terminated connection");
    }
    // process problems communicating with server
    catch(IOException ioException)  {
      ioException.printStackTrace();
    }
  }
  // get streams to send and receive data
  private void getStreams() throws IOException
  {
    // set up output stream for objects
    output = new ObjectOutputStream(client.getOutputStream());
    // flush output buffer to send header information
    output.flush();
    // set up input stream for objects
    input = new ObjectInputStream(client.getInputStream());

    displayArea.append("\ngot i/o streams\n");
  }
  // connect to server
  private void connectToServer() throws IOException
  {
    displayArea.setText("attempting connection\n");
    // create socket to make connection to server
    client = new Socket(InetAddress.getByName(chatServer), 7123);
    // display connection information
    displayArea.append("connected to: "+client.getInetAddress().getHostName());
  }
  // process connection with server
  private void processConnection() throws IOException
  {
    // enable enterfield so client user can send message
   // enterField.setEnabled(true);
    // process messages set from server
    do  {
      Security.addProvider(new  BouncyCastleProvider());
      try {
        byte[]  encDataB = new byte[1152];
        input.read(encDataB);
        // get private key from file
        FileInputStream	ffis = new	FileInputStream("priKey.dec");
        byte[]	priKeyB = new	byte[ffis.available()];
        ffis.read(priKeyB);
        ffis.close();
        PKCS8EncodedKeySpec	kkeySpec = new	PKCS8EncodedKeySpec(priKeyB);
        KeyFactory	kkeyFac = KeyFactory.getInstance("RSA", "BC");
        PrivateKey	priKey = kkeyFac.generatePrivate(kkeySpec);
        // create cipher which used to decrypt
        Cipher  decCipher = Cipher.getInstance("RSA", "BC");
        decCipher.init(Cipher.DECRYPT_MODE, priKey);
        // decrypt message
        ByteArrayOutputStream bbaos = new ByteArrayOutputStream();
        int kk = (((RSAPrivateKey)priKey).getModulus().bitLength()+7) >>> 3;
        int iinOff = 0;
        while(true){
          int lleftToDo = encDataB.length - iinOff;
          if(lleftToDo <= 0){
            break;
          }
          int cchunkSize = (lleftToDo > kk ? kk : lleftToDo);
          decCipher.update(encDataB, iinOff, cchunkSize);
          bbaos.write(decCipher.doFinal());
          iinOff += cchunkSize;
        }
        // get data from buffer
        decDataB = bbaos.toByteArray();
        bbaos.flush();
        System.out.println("Decrypted Data: ");
        System.out.println((new String(decDataB)) + "###");
        System.out.println(decDataB.length);
        displayArea.append("\n" + new String(encDataB));
        displayArea.append("\n" + new String(decDataB));
        displayArea.setCaretPosition(displayArea.getText().length());
      }
      catch(Exception ex) { System.out.println(" caught exception: " + ex);
      }
    } while(!(new String(decDataB)).equals("terminate"));
  } // end method process connection
  // close streams and socket
  private void closeConnection() throws IOException
  {
    displayArea.append("\nclosing connection");
    output.close();
    input.close();
    client.close();
  }
  void enterField_actionPerformed(ActionEvent e) {
  sendData(e.getActionCommand());
  }
  // send message to server
  private void sendData(String message)
  {
    // send object to server
    try {
      output.writeObject("client>>> "+message);
      output.flush();
      displayArea.append("\nclient>>> "+message);
    }
    // process problems sending object
    catch(IOException ioException)  {
      displayArea.append("\nerror writing object");
    }
  }

  void connectButton_actionPerformed(ActionEvent e) {

  }
  void displayArea_keyPressed(KeyEvent e) {

  }
  void displayArea_keyReleased(KeyEvent e) {

  }
  void execmdButton2_actionPerformed(ActionEvent e) {

  }
  void execmdButton_actionPerformed(ActionEvent e) {

  }
}