import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.sql.*;

public class Icmp extends JPanel {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  Border border1;
  TitledBorder titledBorder1;
  Border border2;
  TitledBorder titledBorder2;
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  XYLayout xYLayout9 = new XYLayout();
  JButton resetButton = new JButton(new ImageIcon("images/Reset.png"));
  JPanel jPanel10 = new JPanel();
  Border border3;
  TitledBorder titledBorder3;
  JPanel jPanel8 = new JPanel();
  XYLayout xYLayout8 = new XYLayout();
  JPanel jPanel9 = new JPanel();
  XYLayout xYLayout10 = new XYLayout();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JLabel jLabel10 = new JLabel();
  JPanel jPanel12 = new JPanel();
  JPanel jPanel11 = new JPanel();
  JTextField avetimestampTextField = new JTextField();
  JCheckBox echorequestCheckBox = new JCheckBox();
  JTextField aveechorequestTextField = new JTextField();
  JCheckBox timestampCheckBox = new JCheckBox();
  XYLayout xYLayout12 = new XYLayout();
  JTextField maxechorequestTextField = new JTextField();
  XYLayout xYLayout11 = new XYLayout();
  JCheckBox dropicmpCheckBox = new JCheckBox();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel3 = new JLabel();
  XYLayout xYLayout7 = new XYLayout();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel1 = new JLabel();
  XYLayout xYLayout5 = new XYLayout();
  JTextField maxtimestampTextField = new JTextField();
  XYLayout xYLayout4 = new XYLayout();
  JCheckBox othericmpCheckBox = new JCheckBox();
  JPanel jPanel6 = new JPanel();
  Border border4;
  TitledBorder titledBorder4;
  Border border5;
  TitledBorder titledBorder5;
  XYLayout xYLayout6 = new XYLayout();
  JTextField maxothericmpTextField = new JTextField();
  JTextField aveothericmpTextField = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel7 = new JLabel();
  Border border6;
  TitledBorder titledBorder6;
  JButton clearButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JPanel jPanel13 = new JPanel();
  XYLayout xYLayout13 = new XYLayout();
  JLabel logoLabel = new JLabel();
  JLabel plusplusLabel = new JLabel();

  public Icmp() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161)),"times stamp attack");
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder4 = new TitledBorder(border4,"other icmp");
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder5 = new TitledBorder(border5,"other icmp");
    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder6 = new TitledBorder(border6,"other icmp");
    applyButton.addActionListener(new clickedApply());
    applyButton.setText("Apply");
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setBackground(new Color(236, 233, 230));
    resetButton.addActionListener(new clickedReset());
    resetButton.setText("Reset");
    resetButton.setHorizontalTextPosition(SwingConstants.LEFT);
    resetButton.setBorder(BorderFactory.createEtchedBorder());
    resetButton.setBackground(new Color(236, 233, 230));
    jPanel10.setBackground(new Color(236, 233, 230));
    jPanel10.setLayout(xYLayout9);
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel8.setLayout(xYLayout8);
    jPanel8.setBackground(new Color(236, 233, 230));
    jPanel9.setLayout(xYLayout10);
    jPanel9.setBackground(new Color(236, 233, 230));
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder1 = new TitledBorder(border1,"ping flood");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"other icmp");
    this.setBackground(new Color(236, 233, 230));
    this.setLayout(borderLayout1);
    jPanel1.setLayout(xYLayout1);
    jPanel2.setLayout(xYLayout2);
    jPanel3.setLayout(xYLayout3);
    jPanel7.setLayout(xYLayout7);
    jPanel7.setBackground(new Color(236, 233, 230));
    jPanel5.setBackground(new Color(236, 233, 230));
    jPanel5.setLayout(xYLayout5);
    jPanel5.setBorder(titledBorder3);
    jPanel4.setLayout(xYLayout4);
    jPanel4.setBackground(new Color(236, 233, 230));
    jLabel10.setBackground(new Color(236, 233, 230));
    jLabel10.setText("Average ex. 3/s, 4/m, 5/m, 6/d     Max ex. 3, 4 , 5, or 6");
    jPanel12.setLayout(xYLayout12);
    jPanel11.setBackground(new Color(236, 233, 230));
    jPanel11.setLayout(xYLayout11);
    jPanel11.setBorder(titledBorder1);
    echorequestCheckBox.setBackground(new Color(236, 233, 230));
    timestampCheckBox.setBackground(new Color(236, 233, 230));
    dropicmpCheckBox.setBackground(new Color(236, 233, 230));
    dropicmpCheckBox.setForeground(new Color(102, 102, 153));
    dropicmpCheckBox.setText("drop icmp");
    jLabel6.setText("Average");
    jLabel5.setText("Max");
    jLabel4.setText("time stamp");
    jLabel3.setText("echo request");
    jLabel2.setText("Max");
    jLabel1.setText("Average");
    othericmpCheckBox.setBackground(new Color(236, 233, 230));
    othericmpCheckBox.setText("jCheckBox1");
    jPanel12.setBackground(new Color(236, 233, 230));
    jPanel6.setBackground(new Color(236, 233, 230));
    jPanel6.setBorder(titledBorder6);
    jPanel6.setLayout(xYLayout6);
    maxothericmpTextField.setEditable(false);
    aveothericmpTextField.setEditable(false);
    jLabel9.setText("icmp");
    jLabel8.setText("Max");
    jLabel7.setText("Average");
    clearButton.setBackground(new Color(236, 233, 230));
    clearButton.setBorder(BorderFactory.createEtchedBorder());
    clearButton.setHorizontalTextPosition(SwingConstants.LEFT);
    clearButton.setText("Clear");
    clearButton.addActionListener(new clickedClear());
    jPanel13.setBackground(new Color(236, 233, 230));
    jPanel13.setBorder(BorderFactory.createEtchedBorder());
    jPanel13.setLayout(xYLayout13);
    logoLabel.setIcon(new ImageIcon("./Images/icmplogo.gif"));
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    plusplusLabel.setIcon(new ImageIcon("./Images/plusplus.png"));
    plusplusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    plusplusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2,                               new XYConstraints(6, 8, 453, 422));
    jPanel10.add(applyButton, new XYConstraints(8, 6, 78, 32));
    jPanel10.add(resetButton, new XYConstraints(88, 6, 79, 31));
    jPanel10.add(clearButton,   new XYConstraints(169, 6, 79, 31));
    jPanel5.add(avetimestampTextField, new XYConstraints(169, 3, 47, 23));
    jPanel5.add(jLabel6, new XYConstraints(107, 3, 54, 21));
    jPanel5.add(jLabel5, new XYConstraints(226, 3, 33, 20));
    jPanel5.add(maxtimestampTextField, new XYConstraints(271, 3, 47, 24));
    jPanel5.add(jLabel4, new XYConstraints(18, 3, 74, 22));
    jPanel4.add(jPanel11, new XYConstraints(4, 0, 339, 70));
    jPanel4.add(jPanel5, new XYConstraints(3, 72, 342, 68));
    jPanel11.add(maxechorequestTextField, new XYConstraints(269, 6, 47, 24));
    jPanel11.add(jLabel3, new XYConstraints(16, 6, 85, 22));
    jPanel11.add(jLabel1, new XYConstraints(109, 7, 54, 21));
    jPanel11.add(aveechorequestTextField, new XYConstraints(167, 6, 47, 23));
    jPanel11.add(jLabel2, new XYConstraints(224, 7, 33, 20));
    jPanel4.add(jPanel6,          new XYConstraints(2, 141, 343, 75));
    jPanel6.add(jLabel9, new XYConstraints(15, 7, 40, 22));
    jPanel6.add(maxothericmpTextField,  new XYConstraints(267, 8, 47, 24));
    jPanel6.add(jLabel8, new XYConstraints(224, 8, 33, 20));
    jPanel6.add(jLabel7, new XYConstraints(103, 8, 54, 21));
    jPanel6.add(aveothericmpTextField, new XYConstraints(168, 8, 47, 23));
    jPanel4.add(jLabel10, new XYConstraints(11, 218, 330, -1));
    jPanel3.add(jPanel8, new XYConstraints(42, 281, 346, -1));
    jPanel3.add(jPanel10,   new XYConstraints(96, 268, 304, 42));
    jPanel3.add(jPanel12, new XYConstraints(16, 2, 407, 270));
    jPanel2.add(jPanel3,    new XYConstraints(8, 86, 430, 323));
    jPanel7.add(timestampCheckBox, new XYConstraints(3, 94, -1, -1));
    jPanel7.add(othericmpCheckBox,  new XYConstraints(3, 161, 16, 21));
    jPanel7.add(echorequestCheckBox,     new XYConstraints(3, 17, -1, -1));
    jPanel12.add(dropicmpCheckBox,     new XYConstraints(10, 5, -1, 21));
    jPanel3.add(jPanel9, new XYConstraints(35, 9, 78, 22));
    jPanel2.add(jPanel13, new XYConstraints(8, 11, 430, 72));
    jPanel13.add(logoLabel,          new XYConstraints(124, 0, 237, 70));
    jPanel13.add(plusplusLabel,   new XYConstraints(89, 18, 46, 35));
    jPanel12.add(jPanel4, new XYConstraints(42, 28, 354, 237));
    jPanel12.add(jPanel7, new XYConstraints(6, 38, 30, 201));

    dropicmpCheckBox.addActionListener(new checkeddropicmp());
    othericmpCheckBox.addActionListener(new checkedothericmp());
    echorequestCheckBox.addActionListener(new checkedechorequest());
    timestampCheckBox.addActionListener(new checkedtimestamp());


         // Database section
	db = new DBUtil();
	con = db.Establish();



            aveechorequestTextField.setEditable(false);
            maxechorequestTextField.setEditable(false);

            avetimestampTextField.setEditable(false);
            maxtimestampTextField.setEditable(false);

            aveothericmpTextField.setEditable(false);
            maxothericmpTextField.setEditable(false);

            refreshRecord();

  }
    void refreshRecord() {
        String SQL="",limitrate,limitBnum;

        SQL="select limitrate, limitBnum from confige Where Service in ('icmpechoinput')";
        try {
        rs = db.SQLRetrive(SQL);
        rs.first();

            if (rs.getString("limitrate") != null && rs.getString("limitBnum") != null) {
             if (!rs.getString("limitrate").equals("") && !rs.getString("limitBnum").equals("")) {
                  echorequestCheckBox.setSelected(true);
                  limitrate = rs.getString("limitrate");
                  limitBnum = rs.getString("limitBnum");
                  aveechorequestTextField.setEditable(true);
                  aveechorequestTextField.setText(limitrate);
                  maxechorequestTextField.setEditable(true);
                  maxechorequestTextField.setText(limitBnum);
             }
            }
        }
            catch(SQLException ex) {
                System.out.println(ex.getMessage());
        }


        SQL="select limitrate, limitBnum from confige Where Service in ('icmptimeinput')";
        try {
        rs = db.SQLRetrive(SQL);
        rs.first();

            if (rs.getString("limitrate") != null && rs.getString("limitBnum") != null) {
              if (!rs.getString("limitrate").equals("") && !rs.getString("limitBnum").equals("")) {
                  timestampCheckBox.setSelected(true);
                  limitrate = rs.getString("limitrate");
                  limitBnum = rs.getString("limitBnum");
                  avetimestampTextField.setEditable(true);
                  avetimestampTextField.setText(limitrate);
                  maxtimestampTextField.setEditable(true);
                  maxtimestampTextField.setText(limitBnum);
             }
           }

        }
            catch(SQLException ex) {
                System.out.println(ex.getMessage());
        }

        SQL="select limitrate, limitBnum from confige Where Service in ('icmpotherinput')";
        try {
        rs = db.SQLRetrive(SQL);
        rs.first();

            if (rs.getString("limitrate") != null && rs.getString("limitBnum") != null) {
              if (!rs.getString("limitrate").equals("") && !rs.getString("limitBnum").equals("")) {
                  othericmpCheckBox.setSelected(true);
                  limitrate = rs.getString("limitrate");
                  limitBnum = rs.getString("limitBnum");
                  aveothericmpTextField.setEditable(true);
                  aveothericmpTextField.setText(limitrate);
                  maxothericmpTextField.setEditable(true);
                  maxothericmpTextField.setText(limitBnum);
             }
            }

        }
            catch(SQLException ex) {
                System.out.println(ex.getMessage());
        }

    }

     class checkeddropicmp implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          if(dropicmpCheckBox.isSelected()){
            echorequestCheckBox.setSelected(false);
            timestampCheckBox.setSelected(false);
            othericmpCheckBox.setSelected(false);

            aveechorequestTextField.setEditable(false);
            maxechorequestTextField.setEditable(false);

            avetimestampTextField.setEditable(false);
            maxtimestampTextField.setEditable(false);

            aveothericmpTextField.setEditable(false);
            maxothericmpTextField.setEditable(false);


         }
     }
    }

     class checkedechorequest implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          if(echorequestCheckBox.isSelected()){
            aveechorequestTextField.setEditable(true);
            maxechorequestTextField.setEditable(true);
            dropicmpCheckBox.setSelected(false);
         }
          else {
            aveechorequestTextField.setEditable(false);
            maxechorequestTextField.setEditable(false);

          }
     }
    }

    class checkedtimestamp implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          if(timestampCheckBox.isSelected()){
            avetimestampTextField.setEditable(true);
            maxtimestampTextField.setEditable(true);
            dropicmpCheckBox.setSelected(false);
         }
          else {
            avetimestampTextField.setEditable(false);
            maxtimestampTextField.setEditable(false);
          }
     }
    }
    class checkedothericmp implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          if(othericmpCheckBox.isSelected()){
            aveothericmpTextField.setEditable(true);
            maxothericmpTextField.setEditable(true);
            dropicmpCheckBox.setSelected(false);
         }
          else {
            aveothericmpTextField.setEditable(false);
            maxothericmpTextField.setEditable(false);
          }
     }
    }

     class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        String ave,max,SQL;

     try {

       if(dropicmpCheckBox.isSelected()){
          SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',Action = 'DROP' where Service = 'icmpinputdrop'";
          System.out.println(SQL);
          db.SQLExecute(SQL);
          SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',Action = 'DROP' where Service = 'icmpforwarddrop'";
          System.out.println(SQL);
          db.SQLExecute(SQL);
          db.con.commit();
       }
       else {
          SQL = "update confige set Chain = '',Protocal = '',Action = '' where Service = 'icmpinputdrop'";
          System.out.println(SQL);
          db.SQLExecute(SQL);
          SQL = "update confige set Chain = '',Protocal = '',Action = 'DROP' where Service = 'icmpforwarddrop'";
          System.out.println(SQL);
          db.SQLExecute(SQL);
          db.con.commit();
       }


        if (echorequestCheckBox.isSelected()) {
           ave = aveechorequestTextField.getText();
           max = maxechorequestTextField.getText();
           SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',icmptype='echo-request',matchs='limit',limits='--limit',limitrate='"+ave+"',limitB='--limit-burst',limitBnum='"+max+"',Action='ACCEPT' Where Service = 'icmpechoinput'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',icmptype='echo-request',matchs='limit',limits='--limit',limitrate='"+ave+"',limitB='--limit-burst',limitBnum='"+max+"',Action='ACCEPT' Where Service = 'icmpechoforward'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',icmptype='echo-request',Action='DROP' Where Service = 'icmpechoinputdrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',icmptype='echo-request',Action='DROP' Where Service = 'icmpechoforwarddrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();
        }

        else {
           SQL = "update confige set Chain = '',Protocal = '',icmptype='',matchs='',limits='',limitrate='',limitB='',limitBnum='',Action='' Where Service = 'icmpechoinput'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',icmptype='',matchs='',limits='',limitrate='',limitB='',limitBnum='',Action='' Where Service = 'icmpechoforward'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',icmptype='',Action='' Where Service = 'icmpechoinputdrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',icmptype='',Action='' Where Service = 'icmpechoforwarddrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();
        }

         if (timestampCheckBox.isSelected()) {
           ave = avetimestampTextField.getText();
           max = maxtimestampTextField.getText();
           SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',icmptype='timestamp-request',matchs='limit',limits='--limit',limitrate='"+ave+"',limitB='--limit-burst',limitBnum='"+max+"',Action='ACCEPT' Where Service = 'icmptimeinput'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',icmptype='timestamp-request',matchs='limit',limits='--limit',limitrate='"+ave+"',limitB='--limit-burst',limitBnum='"+max+"',Action='ACCEPT' Where Service = 'icmptimeforward'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',icmptype='timestamp-request',Action='DROP' Where Service = 'icmptimeinputdrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',icmptype='timestamp-request',Action='DROP' Where Service = 'icmptimeforwarddrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();
        }
        else {
           SQL = "update confige set Chain = '',Protocal = '',icmptype='',matchs='',limits='',limitrate='',limitB='',limitBnum='',Action='' Where Service = 'icmptimeinput'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',icmptype='',matchs='',limits='',limitrate='',limitB='',limitBnum='',Action='' Where Service = 'icmptimeforward'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',icmptype='',Action='' Where Service = 'icmptimeinputdrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',icmptype='',Action='' Where Service = 'icmptimeforwarddrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();
        }

       if(othericmpCheckBox.isSelected()) {
           ave = aveothericmpTextField.getText();
           max = maxothericmpTextField.getText();

           SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',matchs='limit',limits='--limit',limitrate='"+ave+"',limitB='--limit-burst',limitBnum='"+max+"',Action='ACCEPT' Where Service = 'icmpotherinput'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'INPUT',Protocal = 'ICMP',Action='DROP' Where Service = 'icmpotherinputdrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',matchs='limit',limits='--limit',limitrate='"+ave+"',limitB='--limit-burst',limitBnum='"+max+"',Action='ACCEPT' Where Service = 'icmpotherforward'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = 'FORWARD',Protocal = 'ICMP',Action='DROP' Where Service = 'icmpotherforwarddrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

       }
       else {
           SQL = "update confige set Chain = '',Protocal = '',matchs='',limits='',limitrate='',limitB='',limitBnum='',Action='' Where Service = 'icmpotherinput'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',Action='' Where Service = 'icmpotherinputdrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',matchs='',limits='',limitrate='',limitB='',limitBnum='',Action='' Where Service = 'icmpotherforward'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();

           SQL = "update confige set Chain = '',Protocal = '',Action='' Where Service = 'icmpotherforwarddrop'";
           System.out.println(SQL);
           db.SQLExecute(SQL);
           db.con.commit();
       }
        }//try
      catch(SQLException ex) {
            System.out.println(ex.getMessage());
      }


      }

    }

    public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }
    class clickedReset implements ActionListener {
        public void actionPerformed(ActionEvent e) {
           refreshRecord();

   }
  }
    class clickedClear implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            dropicmpCheckBox.setSelected(false);
            echorequestCheckBox.setSelected(false);
            timestampCheckBox.setSelected(false);
            othericmpCheckBox.setSelected(false);

            aveechorequestTextField.setText("");
            maxechorequestTextField.setText("");
            avetimestampTextField.setText("");
            maxtimestampTextField.setText("");
            aveothericmpTextField.setText("");
            maxothericmpTextField.setText("");

            aveechorequestTextField.setEditable(false);
            maxechorequestTextField.setEditable(false);
            avetimestampTextField.setEditable(false);
            maxtimestampTextField.setEditable(false);
            aveothericmpTextField.setEditable(false);
            maxothericmpTextField.setEditable(false);
      }
    }

}// end class