package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.table.AbstractTableModel;
import java.sql.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class DefineVar extends JPanel {

  public static ListSearchModel listModel;
  // Database Component
  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs;

  String status="";

  int ReturnRowSelect;
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JLabel logoLabel = new JLabel();
  JLabel statusLabel = new JLabel();
  JPanel tablePanel = new JPanel();

  XYLayout xYLayout3 = new XYLayout();
  JTable table;
  String typeNames[] = {"IP","Port","Device",};
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JComboBox typeComboBox = new JComboBox(typeNames);
  JTextField nameTextField = new JTextField();
  JTextField commentTextField = new JTextField();
  JLabel typeLabel = new JLabel();
  JLabel commentLabel = new JLabel();
  JTextField valueTextField = new JTextField();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  XYLayout xYLayout9 = new XYLayout();
  JButton addButton = new JButton(new ImageIcon("images/Add.png"));
  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  JPanel jPanel8 = new JPanel();
  JButton deleteButton = new JButton(new ImageIcon("images/DeleteRow.png"));


  public DefineVar() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

    logoLabel.setIcon(new ImageIcon("./Images/DefineVar.gif"));
    listModel = new ListSearchModel();
    table = new JTable(listModel);
    JScrollPane scrollPane = new JScrollPane(table);


    this.setLayout(borderLayout1);
    jPanel1.setLayout(xYLayout1);
    logoLabel.setBorder(BorderFactory.createEtchedBorder());
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    statusLabel.setToolTipText("");
    statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    statusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    tablePanel.setLayout(xYLayout3);
    table.setBorder(BorderFactory.createEtchedBorder());
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    tablePanel.setBackground(new Color(236, 233, 230));
    tablePanel.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.setMinimumSize(new Dimension(400, 200));
    jPanel3.setLayout(xYLayout2);
    nameTextField.setBackground(Color.white);
    nameTextField.setPreferredSize(new Dimension(75, 19));
    nameTextField.setEditable(false);
    commentTextField.setBackground(Color.white);
    commentTextField.setEditable(false);
    typeLabel.setText("Type");
    commentLabel.setText("Comment");
    valueTextField.setBackground(Color.white);
    valueTextField.setPreferredSize(new Dimension(75, 19));
    valueTextField.setEditable(false);
    jLabel3.setText("Value");
    jLabel2.setText("Name");
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    typeComboBox.setBackground(new Color(236, 233, 230));
    applyButton.setBackground(new Color(236, 233, 230));
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setActionCommand("Ok");
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setText("OK");
    applyButton.addActionListener(new clickedApply());
    addButton.setBackground(new Color(236, 233, 230));
    addButton.setBorder(BorderFactory.createEtchedBorder());
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setText("Add");
    addButton.addActionListener(new clickedAdd());
    editButton.setBackground(new Color(236, 233, 230));
    editButton.setBorder(BorderFactory.createEtchedBorder());
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    editButton.setText("Edit");
    editButton.addActionListener(new clickedEdit());
    jPanel8.setLayout(xYLayout9);
    jPanel8.setBackground(new Color(236, 233, 230));
    jPanel8.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setBackground(new Color(236, 233, 230));
    deleteButton.setBorder(BorderFactory.createEtchedBorder());
    deleteButton.setHorizontalTextPosition(SwingConstants.LEFT);
    deleteButton.setText("Delete");
    deleteButton.addActionListener(new clickedDelete());
    this.setBackground(new Color(236, 233, 230));
    jPanel3.add(nameTextField,   new XYConstraints(87, 12, 88, -1));
    jPanel3.add(jLabel2,   new XYConstraints(28, 13, 49, -1));
    jPanel3.add(typeComboBox,  new XYConstraints(88, 49, 88, 22));
    jPanel3.add(typeLabel, new XYConstraints(29, 49, 42, 19));
    jPanel3.add(valueTextField,  new XYConstraints(265, 13, 92, -1));
    jPanel3.add(statusLabel,   new XYConstraints(358, 3, 61, 23));
    jPanel3.add(commentTextField,   new XYConstraints(266, 51, 92, -1));
    jPanel3.add(commentLabel,   new XYConstraints(189, 54, 64, -1));
    jPanel3.add(jLabel3,  new XYConstraints(188, 15, 49, -1));
    jPanel1.add(logoLabel,   new XYConstraints(17, 14, 424, 67));
    jPanel1.add(jPanel8, new XYConstraints(16, 84, 426, 49));
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel8.add(applyButton, new XYConstraints(287, 7, 79, 31));
    jPanel8.add(addButton, new XYConstraints(47, 7, 78, 32));
    jPanel8.add(deleteButton, new XYConstraints(126, 7, 80, 31));
    jPanel8.add(editButton, new XYConstraints(207, 7, 79, 31));
    jPanel1.add(tablePanel, new XYConstraints(14, 231, 430, 176));
    tablePanel.add(scrollPane, new XYConstraints(7, 6, 412, 161));
    jPanel1.add(jPanel3,  new XYConstraints(16, 137, 427, 89));

    statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
    // Database section
	db = new DBUtil();
	con = db.Establish();

    setdisable();

    refreshRecordTable();
  }//end jbinit();

  void setenable() {
      nameTextField.setEditable(true);
      valueTextField.setEditable(true);
      typeComboBox.setEditable(true);
      commentTextField.setEditable(true);
  }

  void setdisable() {
      nameTextField.setEditable(false);
      valueTextField.setEditable(false);
      typeComboBox.setEditable(false);
      commentTextField.setEditable(false);
  }
  void clearfield() {
      nameTextField.setText("");
      valueTextField.setText("");
      typeComboBox.setSelectedIndex(0);
      commentTextField.setText("");
  }

  public static void Reset(){
            try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
                  refreshRecordTable();
                 System.out.println("Reset");

  }

   public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }

  class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          setenable();
          nameTextField.setEditable(true);
          valueTextField.setEditable(true);
          commentTextField.setEditable(true);
          status="ADD";
          statusLabel.setIcon(new ImageIcon("./Images/Add.gif"));
      }
    }

    class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       setenable();
       ReturnRowSelect=table.getSelectedRow();
       System.out.println(ReturnRowSelect);
       statusLabel.setIcon(new ImageIcon("./Images/Edit.gif"));
       status="UPDATE";
       setEdit();
      }
    }

    public  void setEdit() {
               String SQL="",Name,Value,Type,Comment;

               ReturnRowSelect = table.getSelectedRow();
                   try {
                    rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                    }

                                  Name = rs.getString("Name");
                                  Name = Name.substring(1,Name.length());
                                  Value = rs.getString("Value");
                                  Type = rs.getString("Type");
                                  Comment = rs.getString("Comment");

                                  nameTextField.setEditable(true);
                                  valueTextField.setEditable(true);
                                  typeComboBox.setEditable(true);
                                  commentTextField.setEditable(true);

                                  nameTextField.setText(Name);
                                  valueTextField.setText(Value);

                                  if (Type == "IP")
                                        typeComboBox.setSelectedIndex(0);
                                  else if (Type == "Port")
                                        typeComboBox.setSelectedIndex(1);
                                  else if (Type == "Device")
                                        typeComboBox.setSelectedIndex(2);

                                  commentTextField.setText(Comment);


                  }
                                  catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }
  }//end setEdit


                    class clickedDelete implements ActionListener {
                        public void actionPerformed(ActionEvent e) {

                       String SQL="",Id;

                                       ReturnRowSelect= table.getSelectedRow();
                                       System.out.println("Return Row ......."+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getString("ID");


		SQL = "DELETE FROM definevar"  + " WHERE ";
                SQL = SQL + "ID = '"+Id+"' ";
		db.SQLExecute(SQL);
		System.out.println(SQL);

                                      }

                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }
                                refreshRecordTable();

                                }
                          }

 class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          System.out.println("Apply");
          updateRecord();
          clearfield();
          setdisable();
      }
    }

   class ListSearchModel extends AbstractTableModel {
        	int LastRow=0;


                   	String[] columnNames = {
                	"Rule No.",
                        "Name",
			"Values",
                        "Type",
                        "Comment"};


                //Object[][] data = new Object[LastRow][columnNames.length];

                Object[][] data = {
			{"","","","",""},{"","","","",""},{"", "","","",""},{"","","","",""},{"","","","",""},{"","","","",""},{"","","","",""},{"","","","",""},
			{"","","","",""},{"","","","",""},{"", "","","",""},{"","","","",""},{"","","","",""},{"","","","",""},{"","","","",""},{"","","","",""},
			{"","","","",""},{"","","","",""},{"", "","","",""},{"","","","",""},{"","","","",""},{"","","","",""},{"","","","",""},{"","","","",""},
                           		};



        public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		return data.length;

	}

	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Object getValueAt(int row, int col) {
		return data[row][col];
                //return new Integer(row*col);
	}

//	public Class getColumnClass(int c) {/
//		return getValueAt(0, c).getClass();
//	}

	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}

	public void clearData() {
        for(int i=0; i<data.length; i++)
		  for(int j=0; j<columnNames.length; j++)
		if (j<=15)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
	}
        }

   void adddefinevar() {

   }
   public static void refreshRecordTable() {
        String SQL="",Id,Name,Type,Value,Comment;


                                  JLabel SourceComLabel = new JLabel();
                                  JLabel DesComLabel = new JLabel();
                                  JLabel FirewallComLabel = new JLabel();

        if(con!=null)
        {
          try {
              SQL = "SELECT * FROM definevar order by ID";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

              listModel.clearData();
              rs.first();
              int row =0;
                             while (rs.next()) {
                                  rs.previous();
                                  Id = rs.getString("ID");
                                  Name = rs.getString("Name");
                                  Value = rs.getString("Value");
                                  Type = rs.getString("Type");
                                  Comment = rs.getString("Comment");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Name,row,1);
                                  listModel.setValueAt(Value,row,2);
                                  listModel.setValueAt(Type,row,3);
                                  listModel.setValueAt(Comment,row,4);
                                  row += 1;
                                  rs.next();
                                  }//while

                                  Id = rs.getString("ID");
                                  Name = rs.getString("Name");
                                  Value = rs.getString("Value");
                                  Type = rs.getString("Type");
                                  Comment = rs.getString("Comment");

                                  listModel.setValueAt(Id,row,0);
                                  listModel.setValueAt(Name,row,1);
                                  listModel.setValueAt(Value,row,2);
                                  listModel.setValueAt(Type,row,3);
                                  listModel.setValueAt(Comment,row,4);
                  }//try

                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh

    public void updateRecord() {
              String SQL, field = "", value = "",stringPK="";
              String Name="",Value="";
              int Id=0;
              int  ID=0;

    System.out.println("use updateRecord");
    if (status.equals("ADD")) {
    SQL = "INSERT INTO definevar" ;

      field="Name,Value,Type,Comment";
      value=" '"+nameTextField.getText().trim()+"' , '" + valueTextField.getText().trim() + "'  , '"+typeNames[typeComboBox.getSelectedIndex()]+"', '" +commentTextField.getText().trim()+ "'  " ;


      SQL = SQL + "(" + field + ") VALUES(" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

                   System.out.println("Test Return Row Select : " + ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                        rs.next();
                     }

                       Id = rs.getInt("ID");


                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }

//          String VarName="#";
//          VarName = VarName.concat(nameTextField.getText());
          SQL = "UPDATE definevar SET";
          SQL =SQL + " Name = '"+nameTextField.getText().trim()+"' ,Value = '" +valueTextField.getText().trim()+ "' ,Type = '"+typeNames[typeComboBox.getSelectedIndex()]+"' ,Comment = '"+commentTextField.getText().trim()+"' ";

          field = "ID = "+Id+" ";
          SQL = SQL + " WHERE "+field;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }
          refreshRecordTable();
          status = "";
          statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));
  } //end updateRecord()


  }//end class
