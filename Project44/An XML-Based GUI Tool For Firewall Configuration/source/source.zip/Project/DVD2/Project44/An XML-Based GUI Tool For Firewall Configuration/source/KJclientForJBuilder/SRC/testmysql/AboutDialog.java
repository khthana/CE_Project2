//package main;
package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AboutDialog extends JFrame {
  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();

  JLabel logoLabel = new JLabel();
  JButton closeButton = new JButton(new ImageIcon("images/ExitDoor.gif"));

  public AboutDialog() {
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    setVisible(true);

  }


  void jbInit() throws Exception {

    logoLabel.setIcon(new ImageIcon("./Images/By.gif"));
    panel1.setLayout(xYLayout1);
    panel1.setBackground(new Color(236, 233, 230));
    panel1.setPreferredSize(new Dimension(386, 220));
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(xYLayout2);
    logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    logoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    closeButton.setBackground(new Color(236, 233, 230));
    closeButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    closeButton.setPreferredSize(new Dimension(45, 29));
    closeButton.setHorizontalTextPosition(SwingConstants.LEFT);
    closeButton.setText("Close");
    closeButton.addActionListener(new clickedClose());
    getContentPane().add(panel1);
    panel1.add(jPanel1,              new XYConstraints(9, 8, 370, 206));
    jPanel1.add(closeButton, new XYConstraints(136, 158, 90, 32));
    jPanel1.add(logoLabel,      new XYConstraints(50, 16, 266, 127));

  ImageIcon icon = new ImageIcon(("images/inform.png"));
    this.setIconImage(icon.getImage());
    this.setTitle("About ..KJ iptables Firewall Builder");
  }//end jbinit()

     class clickedClose implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          hide();
          dispose();
      }
    }

}//end class