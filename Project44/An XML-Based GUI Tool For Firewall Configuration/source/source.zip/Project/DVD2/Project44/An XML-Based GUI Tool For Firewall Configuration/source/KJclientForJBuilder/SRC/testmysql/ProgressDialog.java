//package main;
package testmysql;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.table.AbstractTableModel;
import java.sql.*;
import java.util.*;
import java.text.*;
import javax.swing.JTable.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ProgressDialog extends JDialog {

  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  public static JProgressBar progressBar = new JProgressBar();
  XYLayout xYLayout2 = new XYLayout();
  JButton closeButton = new JButton();
  public static JLabel messageLabel = new JLabel();

  public ProgressDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public ProgressDialog() {
    this(null, "", false);

        //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    setVisible(true);

  }
  void jbInit() throws Exception {

    panel1.setLayout(xYLayout1);
    jPanel1.setLayout(xYLayout2);
    closeButton.setText("Close");
    progressBar.setStringPainted(true);
  //  messageLabel.setBackground(Color.red);
    messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    messageLabel.setText("Working ...");
    jPanel1.setMaximumSize(new Dimension(300, 120));
 //   panel1.setBackground(new Color(236, 233, 230));
    this.getContentPane().setBackground(new Color(236, 233, 230));
    jPanel1.add(progressBar, new XYConstraints(46, 5, 185, 27));
    jPanel1.add(closeButton,  new XYConstraints(92, 67, 90, 29));
    jPanel1.add(messageLabel,   new XYConstraints(67, 40, 146, 20));
    getContentPane().add(panel1);
    panel1.add(jPanel1,      new XYConstraints(47, 34, 293, 117));
    closeButton.addActionListener(new clickedClose());



  }//end jbinit

    class clickedClose implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          dispose();
          hide();
      }
    }



}//end class