package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.sql.*;
import java.net.*;
import java.net.InetAddress;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import javax.crypto.*;
import org.bouncycastle.*;
import org.bouncycastle.jce.provider.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:
 * @author
 * @version 1.0
 */

public class Password extends JFrame {
  DBUtil db;
  Connection con;
  ResultSet rs;

  private final String strLogin = new String("login");
  private static final String pubFileName = new String("pubKey.enc");
  public static String JKserverAddr = new String("");

  private Socket client;
  private ObjectOutputStream output;
  private ObjectInputStream input;

 // Frame2 frame;
  JPanel panel1 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  XYLayout xYLayout2 = new XYLayout();
  JLabel loginLabel = new JLabel();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  JPasswordField passwordTextField = new JPasswordField();
  JLabel usernameLabel = new JLabel();
  JTextField usernameTextField = new JTextField();
  JLabel passwdLabel = new JLabel();
  JLabel ImageLabel = new JLabel();
  JButton okButton = new JButton();
  JLabel myhostLabel = new JLabel();
  String username,dpassword="";


  public Password() {
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
      //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    setVisible(true);

  }


  void jbInit() throws Exception {
    try {
              InetAddress myhost = InetAddress.getLocalHost();
              myhostLabel.setText("Host Name : "+myhost.getHostName()+"  IP Address : "+myhost.getHostAddress());
    }
    catch(Exception e)
    {
        System.out.println("Failed to find myHost");
        e.printStackTrace();
    }

    panel1.setLayout(xYLayout2);
    this.getContentPane().setLayout(xYLayout1);
    xYLayout1.setWidth(390);
    xYLayout1.setHeight(244);
    panel1.setBackground(new Color(236, 233, 230));
    loginLabel.setBackground(new Color(236, 233, 226));
    loginLabel.setBorder(BorderFactory.createEtchedBorder());
    loginLabel.setDisplayedMnemonic('0');
    loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
    loginLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    this.getContentPane().setBackground(new Color(236, 233, 230));
    this.setTitle("");
    jPanel1.setBackground(new Color(236, 233, 226));
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(xYLayout3);
    usernameLabel.setText("User name");
    usernameLabel.setIcon(new ImageIcon("./Images/User.png"));
    usernameTextField.setNextFocusableComponent(passwordTextField);
    usernameTextField.setText("admin");
    passwdLabel.setText("Password");
    passwdLabel.setIcon(new ImageIcon("./Images/Key.png"));
    ImageLabel.setBorder(BorderFactory.createEtchedBorder());
    ImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
    ImageLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    ImageLabel.setIcon(new ImageIcon("./Images/firewall_login.png"));
    okButton.setBackground(new Color(236, 233, 230));
    okButton.setText("OK");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    //okButton.addActionListener(new clickedOk());
    myhostLabel.setHorizontalAlignment(SwingConstants.RIGHT);
    myhostLabel.setHorizontalTextPosition(SwingConstants.LEFT);
    passwordTextField.setNextFocusableComponent(okButton);
    ipTextField.setText("127.0.0.1");
    jLabel1.setText(" JKserver");
    jPanel1.add(okButton, new XYConstraints(178, 111, 89, 29));
    jPanel1.add(passwdLabel,  new XYConstraints(113, 73, 90, 28));
    jPanel1.add(passwordTextField,  new XYConstraints(207, 76, 136, 21));
    jPanel1.add(ImageLabel,    new XYConstraints(12, 26, 84, 110));
    jPanel1.add(myhostLabel,       new XYConstraints(16, 148, 346, 19));
    jPanel1.add(usernameTextField, new XYConstraints(207, 46, 135, 23));
    jPanel1.add(ipTextField, new XYConstraints(207, 17, 134, 22));
    jPanel1.add(usernameLabel, new XYConstraints(113, 41, 90, 31));
    jPanel1.add(jLabel1, new XYConstraints(113, 18, 56, 19));
    panel1.add(loginLabel,     new XYConstraints(9, 8, 367, 34));
    panel1.add(jPanel1, new XYConstraints(9, 47, 368, 175));
    this.getContentPane().add(panel1,      new XYConstraints(1, 6, 389, 228));
    loginLabel.setIcon(new ImageIcon("./Images/Login.gif"));

       db = new DBUtil();
       con = db.Establish();

   ImageIcon icon = new ImageIcon(("images/Lock.png"));
    this.setIconImage(icon.getImage());
    this.setTitle("Login");

  }// end jbinit()
 /*class clickedOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {
       String SQL="";

              SQL = "SELECT * FROM user";
              System.out.println(SQL);
              rs = db.SQLRetrive(SQL);

         try {
                  rs.next();
                  username = rs.getString("username");
                  dpassword = rs.getString("password");

                  System.out.println("username : "+username);
                  System.out.println("dpassword : "+dpassword);

               }
          catch (SQLException ex) {
                     System.out.println(ex.getMessage());
          }


    if(username.equalsIgnoreCase(usernameTextField.getText().trim())) {
    if (!isPasswordCorrect()) {
	JOptionPane.showMessageDialog(null,"Success! You typed the right password.",
	    "Success!",JOptionPane.INFORMATION_MESSAGE);

             Application1.frame.setEnabled(true);
             dispose();
             hide();

    } else {

	JOptionPane.showMessageDialog(null,
	    "Invalid password. Try again.",
	    "Error Message",
	    JOptionPane.ERROR_MESSAGE);
    }
    }
    else{
           JOptionPane.showMessageDialog(null,
	    "Invalid password. Try again.",
	    "Error Message",
	    JOptionPane.ERROR_MESSAGE);

    }

      }
    }//////////end clickedOk*/

    boolean isPasswordCorrect() {

     char[] password = passwordTextField.getPassword();

        if(password.length != dpassword.length())
            return false;
        for(int i=0;i<password.length;i++)
         if(  password[i] != (dpassword.charAt(i)))
             return false;


        return true;
    }
     /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
  private void connectToServer()
  { System.out.println("attempting connection");
    try { client = new Socket(InetAddress.getByName(JKserverAddr), 7123);
            System.out.println("connected to: " + client.getInetAddress().getHostName());
    }
    catch(Exception e)  { System.out.println("connection failed");
    }
  }
  private void getStreams()
  { try { output = new ObjectOutputStream(client.getOutputStream());
            output.flush();
            input = new ObjectInputStream(client.getInputStream());
            System.out.println("got i/o streams");
    }
    catch(Exception e)  { System.out.println("login - getStreams error");
    }
  }
  public static PublicKey getPublicKey()
  { byte[] bytePubKey;
    try { FileInputStream pubFile = new FileInputStream(pubFileName);
            bytePubKey = new byte[pubFile.available()];
            pubFile.read(bytePubKey);
            pubFile.close();
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(bytePubKey);
            KeyFactory keyFac = KeyFactory.getInstance("RSA", "BC");
            PublicKey pubKey = keyFac.generatePublic(keySpec);
            //System.out.println(new String(pubKey.getEncoded()));
            return pubKey;
    }
    catch(Exception e)  { System.out.println("login - getPublickey - get pubKey from file error");
                          return null;
    }
  }
  private void processConnection()
  { String strPass = new String(passwordTextField.getPassword());
    String strPlainText = new String(usernameTextField.getText() + "@" + strPass);
    String loginStatus = new String("");
    // add provider
    try { Security.addProvider(new BouncyCastleProvider());
            PublicKey pubKey = getPublicKey();
            byte[] bytePlainText = strPlainText.getBytes();
            // create cipher which used to encrypt
            Cipher encCipher = Cipher.getInstance("RSA", "BC");
            encCipher.init(Cipher.ENCRYPT_MODE, pubKey);
            // encrypt
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int k = (((RSAPublicKey)pubKey).getModulus().bitLength() + 7) >>> 3;
            int maxSize = k - 11;
            int inOff = 0;
            while(true) { int leftToDo = bytePlainText.length - inOff;
                                  if(leftToDo <= 0) { break;
                                  }
                                  int chunkSize = (leftToDo > maxSize ? maxSize: leftToDo);
                                  encCipher.update(bytePlainText, inOff, chunkSize);
                                  baos.write(encCipher.doFinal());
                                  inOff += chunkSize;
            }
            byte[] byteCipherText = baos.toByteArray();
            baos.flush();
            // send to server
            output.write(byteCipherText);
            output.flush();
            loginStatus = (String)input.readObject();
    }
    catch(Exception ex) { System.out.println("processConnection - error");
    }
    if(loginStatus.equals("ok"))
    { Application1.frame.setEnabled(true);
      dispose();
      hide();
      Application1.frame.setEnabled(true);
    }
    else  { JOptionPane.showMessageDialog(null, "incorrect username or password.", "login error", JOptionPane.ERROR_MESSAGE);
    }
  }
  private void closeConnection()
  { System.out.println("closing connection");
    try { output.close();
            input.close();
            client.close();
            System.out.println("connection is closed");
    }
    catch(Exception e)  { System.out.println("login - closeConnection error");
    }
  }
  void okButton_actionPerformed(ActionEvent e) {
    JKserverAddr = ipTextField.getText();
    connectToServer();
    getStreams();
    RemoteControl.sendService(strLogin, output);
    processConnection();
    closeConnection();
  }
  JTextField ipTextField = new JTextField();
  JLabel jLabel1 = new JLabel();
  }// end class
