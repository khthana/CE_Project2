import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.util.*;
import java.sql.*;
import java.text.*;
import javax.swing.JTable;
import java.lang.String;
import javax.swing.table.AbstractTableModel;

public class DnsTcp extends JPanel {

  public static DBUtil db;
  public static Connection con;
  public static ResultSet rs,rsDefineVar;
  JLabel label2;
  String url, user, password, retriveSQL, tableName;

  public static JTable table;

   public static final String EMPTY = "";
   public static final String NEW = "NEW";
   public static final String UPDATE = "UPDATE";
   public static final String PK = "PK";

   public static boolean src_ipError,src_portError,src_deviceError,des_ipError,des_portError,des_deviceError;

  public String status;
  int ReturnRowSelect;

  public static String chainNames[] = {"INPUT","OUTPUT","FORWARD"};
  public static String actionNames[]= {"ACCEPT","DROP","REJECT"};


  JPanel jPanel2 = new JPanel();
  XYLayout xYLayout1 = new XYLayout();
  JPanel jPanel1 = new JPanel();
  XYLayout xYLayout2 = new XYLayout();
  JLabel ftptcpLabel = new JLabel();
  JPanel jPanel3 = new JPanel();
  XYLayout xYLayout3 = new XYLayout();
  Border border1;
  Border border2;
  Border border3;
  TitledBorder titledBorder1;
  Border border4;
  JPanel jPanel7 = new JPanel();
  JLabel actionLabel = new JLabel();

  public static JComboBox chainComboBox = new JComboBox(chainNames);
  public static JComboBox actionComboBox = new JComboBox(actionNames);

  JLabel src_IPLabel = new JLabel();
  JLabel des_deviceLabel = new JLabel();
  public static JTextField src_ipTextField = new JTextField();
  JLabel des_IPLabel = new JLabel();
  JLabel chainLabel = new JLabel();
  public static JTextField src_deviceTextField = new JTextField();
  public static JTextField des_ipTextField = new JTextField();
  public static JTextField des_deviceTextField = new JTextField();
  JLabel src_deviceLabel = new JLabel();
  XYLayout xYLayout6 = new XYLayout();
  Border border5;
  XYLayout xYLayout5 = new XYLayout();
  JPanel jPanel5 = new JPanel();
  Border border6;
  XYLayout xYLayout7 = new XYLayout();
  JPanel jPanel8 = new JPanel();
  XYLayout xYLayout9 = new XYLayout();
  JButton applyButton = new JButton(new ImageIcon("images/Apply.png"));
  JButton addButton = new JButton(new ImageIcon("images/Add.png"));
  JButton editButton = new JButton(new ImageIcon("images/Edit.png"));
  JButton clearButton = new JButton(new ImageIcon("images/DeleteRow.png"));
  JPanel jPanel4 = new JPanel();
  XYLayout xYLayout4 = new XYLayout();
  JPanel jPanel10 = new JPanel();
  JPanel jPanel9 = new JPanel();
  XYLayout xYLayout11 = new XYLayout();
  XYLayout xYLayout10 = new XYLayout();
  Border border7;
  TitledBorder titledBorder2;
  JPanel jPanel6 = new JPanel();
  XYLayout xYLayout8 = new XYLayout();
  JPanel tablePanel = new JPanel();
  Border border8;


  Border border9;
  XYLayout xYLayout12 = new XYLayout();
  JCheckBox notsrcipCheckBox = new JCheckBox();
  JCheckBox notsrcdeviceCheckBox = new JCheckBox();
  JCheckBox notdesipCheckBox = new JCheckBox();
  JCheckBox notdesdeviceCheckBox = new JCheckBox();
  JCheckBox notsrcportCheckBox = new JCheckBox();
  public static JTextField src_portTextField = new JTextField();
  JCheckBox notdesportCheckBox = new JCheckBox();
  public static JTextField des_portTextField = new JTextField();
  JButton okButton = new JButton(new ImageIcon("Images/Ok.png"));
  Border border10;
  Border border11;
  TitledBorder titledBorder3;
  JLabel iptablesLabel = new JLabel();
  JLabel tcpLabel = new JLabel();
  JRadioButton enableRadioButton = new JRadioButton();
  JRadioButton disableRadioButton = new JRadioButton();
  JLabel enableLabel = new JLabel();
  JLabel disableLabel = new JLabel();
  JLabel plusplusLabel = new JLabel();
  JLabel des_portLabel = new JLabel();
  JLabel src_portLabel = new JLabel();
  JLabel statusLabel = new JLabel();
  JButton activateButton = new JButton(new ImageIcon("images/CheckAll.gif"));


  public DnsTcp() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

    url ="jdbc:odbc:dbConfige";
    user="admin";
    password="";
    tableName="Confige";
    retriveSQL="SELECT * FROM Confige";


Object[][] data = {
            {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","" , "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },
            {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","" , "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },
            {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","" , "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },
            {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","" , "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },
            {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },    {new Boolean(false),"","", "", "", "","", "", "", "","", "", "", "","" , "", "" },    {new Boolean(false),"", "", "", "","", "", "", "","", "", "", "","", "", "", "" },
   };


String[] columnNames = {     "select",
                             "rule no.",
                             "chain",
                             "protocal",
			     "use src ip",
                             "src ip",
                             "use src port",
			     "src port",
                             "use src device",
                             "src device",
                             "use des ip",
                             "des ip",
                             "use des port",
                             "des port",
                             "use des device",
                             "des device",
                             "action"};

  table = new JTable(data,columnNames)
  {
			public TableCellRenderer getCellRenderer(int row, int column) {
				TableColumn tableColumn = getColumnModel().getColumn(column);
				TableCellRenderer renderer = tableColumn.getCellRenderer();
				if (renderer == null) {
					Class c = getColumnClass(column);
					if( c.equals(Object.class) )
					{
						Object o = getValueAt(row,column);
						if( o != null )
					c = getValueAt(row,column).getClass();
					}
					renderer = getDefaultRenderer(c);
				}
				return renderer;
			}

                                                                                          public TableCellEditor getCellEditor(int row, int column) {
				TableColumn tableColumn = getColumnModel().getColumn(column);
				TableCellEditor editor = tableColumn.getCellEditor();
				if (editor == null) {
					Class c = getColumnClass(column);
					if( c.equals(Object.class) )
					{
						Object o = getValueAt(row,column);
						if( o != null )
					c = getValueAt(row,column).getClass();
					}
					editor = getDefaultEditor(c);
				}
				return editor;
			}

                 public void clearData() {
                for(int i=0; i<table.getRowCount(); i++)
		  for(int j=0; j<table.getColumnCount(); j++)
		if (j<=20)
		  setValueAt("", i, j);
		else
	setValueAt(new Boolean(false), i, j);
      }

		};


     ftptcpLabel.setIcon(new ImageIcon("./Images/Dns.gif"));
     iptablesLabel.setIcon(new ImageIcon("./Images/iptables.gif"));
     tcpLabel.setIcon(new ImageIcon("./Images/Tcp.gif"));
    enableLabel.setIcon(new ImageIcon("./Images/Enable.png"));
    disableLabel.setIcon(new ImageIcon("./Images/Disable.png"));
    plusplusLabel.setIcon(new ImageIcon("./Images/plusplus.png"));


  border11 = BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161));
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 161)),"Options");
    table.setDefaultRenderer( JComponent.class, new JComponentCellRenderer() );
  table.setDefaultEditor( JComponent.class, new JComponentCellEditor() );


  JScrollPane scrollPane = new JScrollPane(table);
  border10 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));


    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border7 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder2 = new TitledBorder(border7,"Options");
    border8 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border9 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    this.setLayout(xYLayout7);
    jPanel8.setLayout(xYLayout9);
    applyButton.setBackground(new Color(236, 233, 230));
    applyButton.setBorder(BorderFactory.createEtchedBorder());
    applyButton.setHorizontalTextPosition(SwingConstants.LEFT);
    applyButton.setText("Aplly");
    addButton.setBackground(new Color(236, 233, 230));
    addButton.setBorder(BorderFactory.createEtchedBorder());
    addButton.setHorizontalTextPosition(SwingConstants.LEFT);
    addButton.setText("Add");
    editButton.setBackground(new Color(236, 233, 230));
    editButton.setBorder(BorderFactory.createEtchedBorder());
    editButton.setHorizontalTextPosition(SwingConstants.LEFT);
    editButton.setText("Edit");
    clearButton.setBackground(new Color(236, 233, 230));
    clearButton.setBorder(BorderFactory.createEtchedBorder());
    clearButton.setHorizontalTextPosition(SwingConstants.LEFT);
    clearButton.setText("Clear");
    jPanel4.setLayout(xYLayout4);
    jPanel10.setLayout(xYLayout11);
    jPanel10.setBackground(new Color(236, 233, 230));
    jPanel10.setBorder(titledBorder3);
    jPanel9.setLayout(xYLayout10);
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"Options");
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    ftptcpLabel.setBorder(BorderFactory.createEtchedBorder());
    ftptcpLabel.setPreferredSize(new Dimension(20, 30));
    ftptcpLabel.setHorizontalAlignment(SwingConstants.CENTER);
    ftptcpLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"Chain");
    jPanel1.setLayout(xYLayout1);
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel1.setPreferredSize(new Dimension(400, 200));
    jPanel2.setLayout(xYLayout2);
    jPanel3.setLayout(xYLayout3);
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setBorder(border1);
    actionLabel.setText("Action");
    src_IPLabel.setText("src IP");
    des_deviceLabel.setText("des Device");
    des_IPLabel.setText("des IP");
    chainLabel.setText("Chain");
    src_deviceLabel.setText("src Device");

    jPanel7.setLayout(xYLayout6);
    jPanel7.setBackground(new Color(236, 233, 230));
    jPanel7.setBorder(border5);
    jPanel5.setLayout(xYLayout5);
    jPanel6.setLayout(xYLayout8);
    tablePanel.setLayout(xYLayout12);
    tablePanel.setBackground(new Color(236, 233, 230));
    tablePanel.setBorder(border8);

    scrollPane.setViewportBorder(BorderFactory.createEtchedBorder());
    scrollPane.getViewport().setBackground(new Color(236, 233, 230));
    scrollPane.setAutoscrolls(true);
    scrollPane.setBorder(BorderFactory.createEtchedBorder());
    scrollPane.setDoubleBuffered(true);
    scrollPane.setPreferredSize(new Dimension(400, 200));

    xYLayout7.setWidth(651);
    xYLayout7.setHeight(455);
    notsrcipCheckBox.setBackground(new Color(236, 233, 230));
    notsrcipCheckBox.setText("!");
    notsrcdeviceCheckBox.setBackground(new Color(236, 233, 230));
    notsrcdeviceCheckBox.setText("!");
    notdesipCheckBox.setBackground(new Color(236, 233, 230));
    notdesipCheckBox.setText("!");
    notdesdeviceCheckBox.setBackground(new Color(236, 233, 230));
    notdesdeviceCheckBox.setText("!");
    notsrcportCheckBox.setBackground(new Color(236, 233, 230));
    notsrcportCheckBox.setToolTipText("");
    notsrcportCheckBox.setText("!");
    notdesportCheckBox.setBackground(new Color(236, 233, 230));
    notdesportCheckBox.setText("!");
    okButton.setBackground(new Color(236, 233, 230));
    okButton.setBorder(BorderFactory.createEtchedBorder());
    okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    okButton.setText("OK");
    this.setBackground(new Color(236, 233, 230));
    this.setMaximumSize(new Dimension(800, 600));
    this.setMinimumSize(new Dimension(200, 300));
    this.setPreferredSize(new Dimension(500, 300));
    jPanel5.setBackground(new Color(236, 233, 230));
    jPanel9.setBackground(new Color(236, 233, 230));
    jPanel8.setBackground(new Color(236, 233, 230));
    chainComboBox.setBackground(new Color(236, 233, 230));
    actionComboBox.setBackground(new Color(236, 233, 230));
    jPanel6.setBackground(new Color(236, 233, 230));
    jPanel2.setBackground(new Color(236, 233, 230));
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    table.setGridColor(Color.lightGray);
    table.setIntercellSpacing(new Dimension(2, 2));
    table.setSelectionBackground(new Color(255, 255, 239));
    jPanel4.setBackground(new Color(236, 233, 230));
    iptablesLabel.setHorizontalAlignment(SwingConstants.CENTER);
    iptablesLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    enableRadioButton.setBackground(new Color(236, 233, 230));
    enableRadioButton.setHorizontalTextPosition(SwingConstants.RIGHT);
    enableRadioButton.setText("Enable");
    disableRadioButton.setBackground(new Color(236, 233, 230));
    disableRadioButton.setHorizontalTextPosition(SwingConstants.RIGHT);
    disableRadioButton.setText("Disable");
    plusplusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    plusplusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    des_portLabel.setText("des Port");
    src_portLabel.setText("src Port");
    statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
    statusLabel.setHorizontalTextPosition(SwingConstants.LEFT);
    statusLabel.setText("status :");
    activateButton.addActionListener(new clickedActivate());
    activateButton.setText("Activate");
    activateButton.setHorizontalTextPosition(SwingConstants.LEFT);
    activateButton.setBorder(BorderFactory.createEtchedBorder());
    activateButton.setBackground(new Color(236, 233, 230));
    this.add(jPanel2,      new XYConstraints(3, 5, -1, 443));
    jPanel2.add(jPanel1,                          new XYConstraints(-3, 4, 592, 452));
    jPanel1.add(jPanel6, new XYConstraints(-22, 212, 609, -1));
    jPanel6.add(tablePanel,     new XYConstraints(31, 6, 576, 206));
    tablePanel.add(scrollPane,    new XYConstraints(7, 6, 558, 191));
    jPanel1.add(jPanel3,                  new XYConstraints(9, 54, 577, 155));
    jPanel1.add(ftptcpLabel, new XYConstraints(9, 0, 576, 48));
    jPanel1.add(plusplusLabel,          new XYConstraints(155, 6, 46, 35));
    jPanel1.add(tcpLabel,           new XYConstraints(426, 19, 92, 26));
    jPanel1.add(statusLabel, new XYConstraints(501, 27, 76, 17));
    this.add(iptablesLabel,    new XYConstraints(600, 9, 38, 423));
    jPanel8.add(clearButton,          new XYConstraints(1, 104, 80, 31));
    jPanel8.add(addButton,       new XYConstraints(2, 10, 78, 32));
    jPanel8.add(applyButton,              new XYConstraints(1, 43, 79, 30));
    jPanel8.add(editButton,      new XYConstraints(1, 73, 79, 31));
    jPanel3.add(jPanel4,       new XYConstraints(463, 8, 108, -1));
    jPanel4.add(jPanel10,                     new XYConstraints(4, 0, -1, 135));
    jPanel10.add(jPanel9,         new XYConstraints(-3, 0, 93, 102));
    jPanel9.add(enableRadioButton,    new XYConstraints(4, 11, 57, 15));
    jPanel3.add(jPanel7,  new XYConstraints(92, 16, 371, 125));
    jPanel5.add(notdesportCheckBox, new XYConstraints(140, 7, 23, 18));
    jPanel5.add(src_portTextField, new XYConstraints(82, 7, 52, 21));
    jPanel5.add(des_portLabel, new XYConstraints(165, 9, 48, 17));
    jPanel5.add(notsrcportCheckBox,      new XYConstraints(4, 5, 24, 20));
    jPanel5.add(src_portLabel,  new XYConstraints(32, 9, 47, 15));
    jPanel5.add(des_portTextField, new XYConstraints(216, 5, 55, 22));
    jPanel7.add(des_ipTextField, new XYConstraints(271, 7, 88, -1));
    jPanel7.add(notdesdeviceCheckBox,  new XYConstraints(186, 35, 23, 19));
    jPanel7.add(okButton, new XYConstraints(284, 85, 76, 28));
    jPanel7.add(src_IPLabel, new XYConstraints(31, 9, 34, -1));
    jPanel7.add(src_ipTextField, new XYConstraints(89, 8, 84, -1));
    jPanel7.add(notdesipCheckBox, new XYConstraints(185, 10, 23, 17));
    jPanel7.add(des_IPLabel, new XYConstraints(207, 12, 57, -1));
    jPanel7.add(notsrcipCheckBox, new XYConstraints(7, 9, 21, 14));
    jPanel7.add(notsrcdeviceCheckBox, new XYConstraints(7, 38, 25, 14));
    jPanel7.add(src_deviceLabel, new XYConstraints(31, 37, 62, -1));
    jPanel7.add(src_deviceTextField, new XYConstraints(89, 33, 84, -1));
    jPanel7.add(des_deviceLabel, new XYConstraints(208, 38, 69, -1));
    jPanel7.add(des_deviceTextField, new XYConstraints(272, 34, 88, -1));
    jPanel7.add(chainComboBox, new XYConstraints(272, 60, 88, 21));
    jPanel7.add(chainLabel, new XYConstraints(208, 64, 41, -1));
    jPanel7.add(actionComboBox, new XYConstraints(88, 59, 86, 21));
    jPanel7.add(actionLabel, new XYConstraints(31, 61, 43, -1));
    jPanel7.add(jPanel5, new XYConstraints(4, 82, 278, -1));
    jPanel3.add(jPanel8, new XYConstraints(5, 6, 81, 142));
    jPanel9.add(disableRadioButton,   new XYConstraints(5, 35, 63, 13));
    jPanel9.add(disableLabel, new XYConstraints(70, 30, 23, 24));
    jPanel9.add(enableLabel,    new XYConstraints(70, 8, 26, 25));
    jPanel9.add(activateButton,         new XYConstraints(8, 61, 78, 32));


    ButtonGroup rbg = new ButtonGroup();
        rbg.add(enableRadioButton);
        rbg.add(disableRadioButton);

       enableRadioButton.setSelected(true);

    // Database section
	db = new DBUtil();
	con = db.Establish();


    addButton.addActionListener(new clickedAdd());
    applyButton.addActionListener(new clickedApply());
    editButton.addActionListener(new clickedEdit());
    clearButton.addActionListener(new clickedClear());
    okButton.addActionListener(new clickedOk());

    table.addMouseListener(new clickedTable());

    TableColumn column=null;
    column=table.getColumnModel().getColumn(1);
    column.setMaxWidth(150);
    column.setMinWidth(0);
    column.setWidth(150);

    statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));

    table.setRowHeight(40);

     // jPanel7.setVisible(false);

         try {
          rs.last();
            }
        catch(Exception ex)
          {
            System.out.println(ex.getMessage());
          }

    refreshRecordTable();

  }////////////end jbinit()

 class clickedTable extends MouseAdapter {
  public void mouseClicked(MouseEvent e) {
    System.out.println("Table ................................");
    System.out.println("getRwoCount :> "+table.getRowCount());


     for(int row=0;row<table.getRowCount();row++) {
        table.setValueAt(new Boolean(false),row,0);
        System.out.println(row);
    }

        int selectRow = table.getSelectedRow();
        table.setValueAt(new Boolean(true),selectRow,0);
  }
 }

  class clickedActivate implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          String SQL="",en_dis="";

          if(enableRadioButton.isSelected() == true)
              en_dis = "ENABLE";
          else
              en_dis = "DISABLE";

                    SQL = "UPDATE confige SET en_dis =  '"+en_dis+ "' ";
                    db.SQLExecute(SQL);
                    System.out.println(SQL);
     }
  }

    public void checkSrcIP() {

        String  allIP,IP,subNet="",aIP,bIP,cIP,dIP;
        int i,iaIP,ibIP,icIP,idIP;

        src_ipError = false;
//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////
  if(!src_ipTextField.getText().trim().equalsIgnoreCase("ANY")) {

  if (src_ipTextField.getText().trim().length() != 0) {
  try {
        allIP=src_ipTextField.getText().trim();
        System.out.println(allIP);

       i = allIP.indexOf("/");
       if (i < 0) i = allIP.length();
       IP = allIP.substring(0,i);

       System.out.println("//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////");
       System.out.println(IP.toString());


       i = IP.indexOf(".");
       aIP = IP.substring(0,i);
       IP = IP.substring(i+1,IP.length());
       System.out.println(aIP.toString());

      i = IP.indexOf(".");
      bIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
      System.out.println(bIP.toString());

      i = IP.indexOf(".");
      cIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
     System.out.println(cIP.toString());

     dIP = IP.substring(0,IP.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);



         if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else {

//        src_ipTextField.transferFocus();

//        JOptionPane.showConfirmDialog(this,"   Source IP Wrong !!  ","Error !!",JOptionPane.DEFAULT_OPTION,JOptionPane.ERROR_MESSAGE);
        System.out.println("Message Error");
        src_ipError = true;
//        src_portTextField.requestFocus();
        //System.exit();
        // Runtime.getRuntime().exit(1);


        }
   }//try}
  catch (Exception e) {
      //System.out.println(e.getMessage());
      //src_portTextField.requestFocus();
    //  System.out.println("Src IP !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 1");
      //JOptionPane.showMessageDialog(this,"   Source IP Wrong !!  ***","Error !!",JOptionPane.ERROR_MESSAGE);

  //    System.out.println("Src IP !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 2");
      src_ipError = true;
  }
//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////

  try {
       System.out.println("//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////");

     allIP=src_ipTextField.getText().trim();

     i = allIP.indexOf("/");
    if (i>0) {
    subNet = allIP.substring(i+1,allIP.length());
    System.out.println(subNet.toString());
    i = subNet.indexOf(".");

    if (i < 0 && Integer.parseInt(subNet) <= 32 && Integer.parseInt(subNet) >= 0) {
    }
    else {

     i = subNet.indexOf(".");
     aIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(aIP.toString());

     i = subNet.indexOf(".");
     bIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(bIP.toString());

     i = subNet.indexOf(".");
     cIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(cIP.toString());

     dIP = subNet.substring(0,subNet.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);


       if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else  {
      //  src_portTextField.requestFocus();
        //src_ipTextField.transferFocus();
    //    JOptionPane.showMessageDialog(this,"   Source IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
        System.out.println("Message Error");
//        errorfield = true;
        src_ipError = true;
        }


 }
 }
 else {
  }
   }
  catch (Exception e) {
     // System.out.println(e.getMessage());
    //  src_portTextField.requestFocus();
  //    JOptionPane.showMessageDialog(this,"   Source IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
//      errorfield = true;
              src_ipError = true;
  }

  }// end if ()
  }

//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
  } //end checkIP

  public void checkDesIP() {
        String  allIP,IP,subNet="",aIP,bIP,cIP,dIP;
        int i,iaIP,ibIP,icIP,idIP;

        des_ipError = false;

//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////
    if(!des_ipTextField.getText().trim().equalsIgnoreCase("ANY")) {

    if(des_ipTextField.getText().trim().length() != 0) {
  try {
        allIP=des_ipTextField.getText().trim();
        System.out.println(allIP);

       i = allIP.indexOf("/");
       if (i < 0) i = allIP.length();
       IP = allIP.substring(0,i);

       System.out.println("//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////");
       System.out.println(IP.toString());


       i = IP.indexOf(".");
       aIP = IP.substring(0,i);
       IP = IP.substring(i+1,IP.length());
       System.out.println(aIP.toString());

      i = IP.indexOf(".");
      bIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
      System.out.println(bIP.toString());

      i = IP.indexOf(".");
      cIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
     System.out.println(cIP.toString());

     dIP = IP.substring(0,IP.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);



         if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else {
        //des_ipTextField.transferFocus();
       // des_portTextField.requestFocus();
        //JOptionPane.showConfirmDialog(this,"   Destination IP Wrong !!  ","Error !!",JOptionPane.DEFAULT_OPTION,JOptionPane.ERROR_MESSAGE);
        System.out.println("Message Error");
        des_ipError = true;
        }
   }//try}
  catch (Exception e) {
      //System.out.println(e.getMessage());
      //des_portTextField.requestFocus();
      //JOptionPane.showMessageDialog(this,"   Destination IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
        des_ipError = true;
  }
//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////

  try {
       System.out.println("//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////");

     allIP=des_ipTextField.getText().trim();

     i = allIP.indexOf("/");
    if (i>0) {
    subNet = allIP.substring(i+1,allIP.length());
    System.out.println(subNet.toString());
    i = subNet.indexOf(".");

    if (i < 0 && Integer.parseInt(subNet) <= 32 && Integer.parseInt(subNet) >= 0) {
    }
    else {

     i = subNet.indexOf(".");
     aIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(aIP.toString());

     i = subNet.indexOf(".");
     bIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(bIP.toString());

     i = subNet.indexOf(".");
     cIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(cIP.toString());

     dIP = subNet.substring(0,subNet.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);


       if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else  {
//        des_ipTextField.transferFocus();
    //    des_portTextField.requestFocus();
  //      JOptionPane.showMessageDialog(this,"   Destination IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
//        System.out.println("Message Error");
              des_ipError = true;
        }


 }
 }
 else {
  }
   }
  catch (Exception e) {
      System.out.println(e.getMessage());
      //des_portTextField.requestFocus();
//      des_ipTextField.transferFocus();
      //JOptionPane.showMessageDialog(this,"   Destication IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
    //  errorfield = true;
      des_ipError = true;
  }

    }// end if()
  }
//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
  } //end checkIP
 public void checkSrcPort() {
    String src_port,min_port,max_port;
    int port,port1,port2,i;

    src_portError = false;

    src_port = src_portTextField.getText().trim();

    if(!src_port.equalsIgnoreCase("ANY")) {

    i = src_port.indexOf(":");
    if (i>0) {
    min_port = src_port.substring(0,i);
    System.out.println("min_port before"+min_port);
    min_port = min_port.trim();
    System.out.println("min_port after"+min_port);

    max_port = src_port.substring(i+1,src_port.length());
    System.out.println("max_port before"+max_port);
    max_port = max_port.trim();
    System.out.println("max_port after"+max_port);


 if (src_portTextField.getText().trim().length() != 0) {
  try {
//     port = Integer.parseInt(src_portTextField.getText().trim());
       port1 = Integer.parseInt(min_port);
       port2 = Integer.parseInt(max_port);

     if (port1 > 65535 || port2 >65535)
      {
        //src_deviceTextField.requestFocus();
      //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
//        System.out.println("Error !!");
        src_portError = true;
      }

     }
  catch(Exception e){
//      src_portTextField.transferFocus();
  //    src_deviceTextField.requestFocus();
    //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      src_portError = true;
    }
  }

  }//if(i>0)
  else {

    if (src_portTextField.getText().trim().length() != 0) {
  try {
     port = Integer.parseInt(src_portTextField.getText().trim());
      if (port > 65535)
      {
     //  des_deviceTextField.requestFocus();
       //JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
       src_portError = true;
      }
     }
  catch(Exception e){
    //des_portTextField.transferFocus();
   // des_deviceTextField.requestFocus();
 //   JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      src_portError = true;
  }
  }

  }//else if(i>0)

  }

 }// end src_port

 public void checkDesPort() {
    String des_port,min_port,max_port;
    int port,port1,port2,i;

    des_portError = false;

    des_port = des_portTextField.getText().trim();

  if(!des_port.equalsIgnoreCase("ANY")){

    i = des_port.indexOf(":");
    if (i>0) {
    min_port = des_port.substring(0,i);
    System.out.println("min_port before"+min_port);
    min_port = min_port.trim();
    System.out.println("min_port after"+min_port);

    max_port = des_port.substring(i+1,des_port.length());
    System.out.println("max_port before"+max_port);
    max_port = max_port.trim();
    System.out.println("max_port after"+max_port);


 if (des_portTextField.getText().trim().length() != 0) {
  try {
//     port = Integer.parseInt(src_portTextField.getText().trim());
       port1 = Integer.parseInt(min_port);
       port2 = Integer.parseInt(max_port);

     if (port1 > 65535 || port2 >65535)
      {
        //src_deviceTextField.requestFocus();
      //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
//        System.out.println("Error !!");
          des_portError = true;
      }

     }
  catch(Exception e){
//      src_portTextField.transferFocus();
  //    src_deviceTextField.requestFocus();
    //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      des_portError = true;
    }
  }

  }//if(i>0)
  else {

    if (des_portTextField.getText().trim().length() != 0) {
  try {
     port = Integer.parseInt(des_portTextField.getText().trim());
      if (port > 65535)
      {
     //  des_deviceTextField.requestFocus();
       //JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
       des_portError = true;
      }
     }
  catch(Exception e){
    //des_portTextField.transferFocus();
   // des_deviceTextField.requestFocus();
 //   JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      des_portError = true;
  }
  }
  }//else if(i>0)
  }
 }// end src_port
 public void checkSrcDevice() {
      int ieth,ippp,index=0;
      String  device,num="";

      src_deviceError = false;

   if(!src_deviceTextField.getText().trim().equalsIgnoreCase("ANY")) {

   if(src_deviceTextField.getText().trim().length() != 0){

       device = src_deviceTextField.getText().trim();

      // System.out.println("device.substring(0,2) :"+device.substring(0,2));
      // System.out.println("device.substring(0,3) :"+device.substring(0,3));

      if (device.length() > 2) {

      if ( ! (device.substring(0,3).equals("eth")) && !(device.substring(0,3).equals("ppp")) ) {
        //src_deviceTextField.transferFocus();
       // des_ipTextField.requestFocus();
        //JOptionPane.showMessageDialog(this,"  Source Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
          src_deviceError = true;
      }
       else {

          if (device.substring(0,3).equals("eth") ) {
              num = device.substring(3,device.length());
              System.out.println("eth : "+num);
             }
          else if(device.substring(0,3).equals("ppp") ) {
              num = device.substring(3,device.length());
              System.out.println("ppp : "+num);
            }
        try {
            int deviceno = Integer.parseInt(num);
          }
        catch(Exception e){
            //src_deviceTextField.transferFocus();
//            des_ipTextField.requestFocus();
  //          JOptionPane.showMessageDialog(this,"  Source Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
            src_deviceError = true;
        }
      }
      }
      else if( !(device.length() == 2 && device.equals("lo"))) {
//           des_ipTextField.requestFocus();
  //         JOptionPane.showMessageDialog(this,"  Source Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
    //       errorfield = true;
           src_deviceError = true;
      }
    }
    }
 }

 public void checkDesDevice() {
      int ieth,ippp,index=0;
      String  device,num="";


    des_deviceError = false;

    if(!des_deviceTextField.getText().trim().equalsIgnoreCase("ANY")) {

    if(des_deviceTextField.getText().trim().length() != 0){

       device = des_deviceTextField.getText().trim();

       //System.out.println("device.substring(0,2) :"+device.substring(0,2));
      // System.out.println("device.substring(0,3) :"+device.substring(0,3));

      if (device.length() > 2) {

      if ( ! (device.substring(0,3).equals("eth")) && !(device.substring(0,3).equals("ppp")) ) {
        //des_deviceTextField.transferFocus();
        //src_ipTextField.requestFocus();
        //JOptionPane.showMessageDialog(this,"  Destination Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
        //errorfield = true;
        des_deviceError = true;

      }
       else {

          if (device.substring(0,3).equals("eth")) {
              num = device.substring(3,device.length());
              System.out.println("eth : "+num);
             }
          else if(device.substring(0,3).equals("ppp")) {
              num = device.substring(3,device.length());
              System.out.println("ppp : "+num);
            }

        try {
            int deviceno = Integer.parseInt(num);
          }
        catch(Exception e){
//            src_ipTextField.requestFocus();
  //          JOptionPane.showMessageDialog(this,"  Destination Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
          des_deviceError = true;
       }

        }
      }

      else if (!(device.equals("lo") && device.length() == 2)){
//           src_ipTextField.requestFocus();
  //         JOptionPane.showMessageDialog(this,"  Destination Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
    //       errorfield = true;
            des_deviceError = true;
      }
    }
    }
 }


  class clickedOk implements ActionListener {
      public void actionPerformed(ActionEvent e) {


        checkSrcIP();
        checkSrcPort();
        checkSrcDevice();
        checkDesIP();
        checkDesPort();
        checkDesDevice();

        checkdefinevar();

    if (!(src_ipError || src_portError || src_deviceError || des_ipError || des_portError || des_deviceError))
       {
         updateRecord();
         jPanel7.setVisible(false);
         statusLabel.setIcon(new ImageIcon("./Images/Empty.gif"));

         src_ipError = false;
         src_portError = false;
         src_deviceError = false;
         des_ipError = false;
         des_portError = false;
         des_deviceError = false;
       }
     else
          new DnsTcpError();


     }
  }
  class clickedAdd implements ActionListener {
      public void actionPerformed(ActionEvent e) {
      status = "ADD";
      clearField();
      statusLabel.setIcon(new ImageIcon("./Images/Add.gif"));

      jPanel7.setVisible(true);
    }
  }
  void clearField() {

      src_ipTextField.setText("");
      src_portTextField.setText("");
      src_deviceTextField.setText("");

      des_ipTextField.setText("");
      des_portTextField.setText("");
      des_deviceTextField.setText("");

    notsrcipCheckBox.setSelected(false);
    notsrcportCheckBox.setSelected(false);
    notsrcdeviceCheckBox.setSelected(false);
    notdesipCheckBox.setSelected(false);
    notdesportCheckBox.setSelected(false);
    notdesdeviceCheckBox.setSelected(false);

      chainComboBox.setSelectedIndex(0);
      actionComboBox.setSelectedIndex(0);

  }

  class clickedApply implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          try {
                  db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }

    }
  }

  class clickedEdit implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          status = "UPDATE";
          statusLabel.setIcon(new ImageIcon("./Images/Edit.gif"));
          clearField();
          setEdit();
          jPanel7.setVisible(true);
    }
  }

  class clickedClear implements ActionListener {
      public void actionPerformed(ActionEvent e) {

                               int Id;
                                String SQL="",Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;

                                       ReturnRowSelect = table.getSelectedRow();
                                       System.out.println("ReturnRowSelect : "+ReturnRowSelect);
                                  try {
                                  rs.first();
                                      for (int i=0;i<ReturnRowSelect;i++){
                                  rs.next();
                                    }

                                    Id = rs.getInt("ID");
                                    Chain = rs.getString("Chain");
                                    src_IP = rs.getString("src_IP");
                                    src_Port = rs.getString("src_Port");
                                    src_Device = rs.getString("src_Device");
                                    des_IP = rs.getString("des_IP");
                                    des_Port = rs.getString("des_Port");
                                    des_Device = rs.getString("des_Device");
                                    Protocal = rs.getString("Protocal");
                                    Action = rs.getString("Action");

                                        	// Get previous or next for bookmark
		//boolean combineKey = false;
		// Make SQL
		SQL = "DELETE FROM " + tableName + " WHERE ";

                                                            SQL = SQL +  "ID =  "+Id+" ";//+"    AND Chain =  '" +Chain+ "'   AND src_IP =  '"+src_IP+"' "+
                                                                                 //   " AND src_Port =  '"+src_Port+"'   AND src_Device =   '"+src_Device+"'  " +
                                                                                   // " AND des_IP =  '"+des_IP+"'   AND des_Port =  '"+src_Port+"'   AND des_Device =  '"+des_Device+"'  "+
                                                                                   // " AND Protocal =  '"+Protocal+"'   AND Action =  '"+Action+"' ";

		db.SQLExecute(SQL);
		System.out.println(SQL);

                                    }

                                       catch(SQLException ex) {
                                      System.out.println(ex.getMessage());
                                      }

                                refreshRecordTable();

    }
  }

  void enableField() {

      src_ipTextField.enable();
      src_portTextField.enable();
      src_deviceTextField.enable();

      des_ipTextField.enable();
      des_portTextField.enable();
      des_deviceTextField.enable();

      notsrcipCheckBox.enable();
      notsrcportCheckBox.enable();
      notsrcdeviceCheckBox.enable();

      notdesipCheckBox.enable();
      notdesportCheckBox.enable();
      notdesdeviceCheckBox.enable();

      actionComboBox.enable();
      chainComboBox.enable();

  }

  void disableField() {

      src_ipTextField.disable();
      src_portTextField.disable();
      src_deviceTextField.disable();

      des_ipTextField.disable();
      des_portTextField.disable();
      des_deviceTextField.disable();

      notsrcipCheckBox.disable();
      notsrcportCheckBox.disable();
      notsrcdeviceCheckBox.disable();

      notdesipCheckBox.disable();
      notdesportCheckBox.disable();
      notdesdeviceCheckBox.disable();

      actionComboBox.disable();
      chainComboBox.disable();
  }



 public static void refreshRecordTable() {
        String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
        String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice;
        String Message = "";

        if(con!=null)
        {
          try {

          SQL = "SELECT * FROM confige Where Service = 'DnsTcp'  order by ID" ;
          System.out.println(SQL);
          rs = db.SQLRetrive(SQL);



                for(int i=0; i<table.getRowCount(); i++)
                    for(int j=1; j<table.getColumnCount(); j++)
		if (j<=20)
		  table.setValueAt("", i, j);
		else
                table.setValueAt(new Boolean(false), i, j);

                rs.first();

               int row =0;
               while (rs.next()) {
                                  rs.previous();

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  JLabel SourceComLabel = new JLabel(src_IP, new ImageIcon( table.getClass().getResource("SourceCom.png")),JLabel.CENTER);
                                  JLabel DesComLabel = new JLabel(des_IP, new ImageIcon( table.getClass().getResource("DesCom.png")),JLabel.CENTER);

                                  JLabel ChainLabel = new JLabel(Chain, new ImageIcon( table.getClass().getResource("Chain.gif")),JLabel.CENTER);
                                  JLabel ProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("pTcp.gif")),JLabel.CENTER);

                                  JLabel  NotLabel = new JLabel("", new ImageIcon( table.getClass().getResource("Not.gif")),JLabel.CENTER);
                                  JLabel  YesLabel = new JLabel("", new ImageIcon( table.getClass().getResource("Yes.png")),JLabel.CENTER);

                                  JLabel  SrcIPLabel = new JLabel(src_IP, new ImageIcon( table.getClass().getResource("SourceCom.png")),JLabel.CENTER);
                                  JLabel  DesIPLabel = new JLabel(des_IP, new ImageIcon( table.getClass().getResource("DesCom.png")),JLabel.CENTER);

                                  JLabel  SrcPortLabel = new JLabel(src_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);
                                  JLabel  DesPortLabel = new JLabel(des_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);

                                 JLabel  SrcDeviceLabel = new JLabel(src_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);
                                 JLabel  DesDeviceLabel = new JLabel(des_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);

                                 JLabel  AnyLabel = new JLabel("ANY", new ImageIcon( table.getClass().getResource("Any.png")),JLabel.CENTER);

                                 JLabel  DefineChainActionLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Define.gif")),JLabel.CENTER);

                                JLabel  AcceptLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Accept.gif")),JLabel.CENTER);
                                JLabel  DropLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Drop.gif")),JLabel.CENTER);
                                JLabel  RejectLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Reject.gif")),JLabel.CENTER);


                                 JLabel  InputLabel = new JLabel("INPUT", new ImageIcon( table.getClass().getResource("Input.gif")),JLabel.CENTER);
                                 JLabel  OutputLabel = new JLabel("OUTPUT", new ImageIcon( table.getClass().getResource("Output.gif")),JLabel.CENTER);
                                 JLabel  ForwardLabel = new JLabel("FORWARD", new ImageIcon( table.getClass().getResource("Forward.png")),JLabel.CENTER);
                                 JLabel  DefineChainLabel = new JLabel(Chain, new ImageIcon( table.getClass().getResource("Define.gif")),JLabel.CENTER);

                              table.setValueAt(Id,row,1);

                              if (Chain.equals("INPUT"))
                                    table.setValueAt(InputLabel,row,2);
                             else
                                  if(Chain.equals("OUTPUT"))
                                     table.setValueAt(OutputLabel,row,2);
                                   else
                                   if(Chain.equals("FORWARD"))
                                     table.setValueAt(ForwardLabel,row,2);
                                        else
                                          table.setValueAt(DefineChainLabel,row,2);


                                    table.setValueAt(ProtocalLabel,row,3);

                                  if (notSrcIP.equals("NO"))
                                      table.setValueAt(NotLabel,row,4);
                                  else
                                      table.setValueAt(YesLabel,row,4);

                                  if (src_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,5);
                                  else
                                      table.setValueAt(SourceComLabel,row,5);

                                  if (notSrcPort.equals("NO"))
                                      table.setValueAt(NotLabel,row,6);
                                  else
                                      table.setValueAt(YesLabel,row,6);

                                   if (src_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,7);
                                  else
                                      table.setValueAt(SrcPortLabel,row,7);

                                  if (notSrcDevice.equals("NO"))
                                      table.setValueAt(NotLabel,row,8);
                                  else
                                      table.setValueAt(YesLabel,row,8);

                                  if (src_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,9);
                                  else
                                      table.setValueAt(SrcDeviceLabel,row,9);

                                  if (notDesIP.equals("NO"))
                                      table.setValueAt(NotLabel,row,10);
                                  else
                                      table.setValueAt(YesLabel,row,10);

                                  if (des_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,11);
                                  else
                                      table.setValueAt(DesComLabel,row,11);

                                  if (notSrcPort.equals("NO"))
                                      table.setValueAt(NotLabel,row,12);
                                  else
                                      table.setValueAt(YesLabel,row,12);

                                   if (des_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,13);
                                  else
                                      table.setValueAt(DesPortLabel,row,13);

                                  if (notDesDevice.equals("NO"))
                                      table.setValueAt(NotLabel,row,14);
                                  else
                                      table.setValueAt(YesLabel,row,14);

                                  if (des_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,15);
                                  else
                                      table.setValueAt(DesDeviceLabel,row,15);

                                  if (Action.equals("ACCEPT"))
                                      table.setValueAt(AcceptLabel,row,16);
                                  else
                                      if (Action.equals("DROP"))
                                          table.setValueAt(DropLabel,row,16);
                                      else
                                          if(Action.equals("REJECT"))
                                            table.setValueAt(RejectLabel,row,16);
                                          else
                                            table.setValueAt(DefineChainActionLabel,row,16);


                                   row += 1;
                                   rs.next();
                                  }//while

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  JLabel SourceComLabel = new JLabel(src_IP, new ImageIcon( table.getClass().getResource("SourceCom.png")),JLabel.CENTER);
                                  JLabel DesComLabel = new JLabel(des_IP, new ImageIcon( table.getClass().getResource("DesCom.png")),JLabel.CENTER);

                                  JLabel ChainLabel = new JLabel(Chain, new ImageIcon( table.getClass().getResource("Chain.gif")),JLabel.CENTER);
                                  JLabel ProtocalLabel = new JLabel(new ImageIcon( table.getClass().getResource("pTcp.gif")),JLabel.CENTER);

                                  JLabel  NotLabel = new JLabel("", new ImageIcon( table.getClass().getResource("Not.gif")),JLabel.CENTER);
                                  JLabel  YesLabel = new JLabel("", new ImageIcon( table.getClass().getResource("Yes.png")),JLabel.CENTER);

                                  JLabel  SrcIPLabel = new JLabel(src_IP, new ImageIcon( table.getClass().getResource("SourceCom.png")),JLabel.CENTER);
                                  JLabel  DesIPLabel = new JLabel(des_IP, new ImageIcon( table.getClass().getResource("DesCom.png")),JLabel.CENTER);

                                  JLabel  SrcPortLabel = new JLabel(src_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);
                                  JLabel  DesPortLabel = new JLabel(des_Port, new ImageIcon( table.getClass().getResource("Port.png")),JLabel.CENTER);

                                 JLabel  SrcDeviceLabel = new JLabel(src_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);
                                 JLabel  DesDeviceLabel = new JLabel(des_Device, new ImageIcon( table.getClass().getResource("Device.png")),JLabel.CENTER);

                                 JLabel  AnyLabel = new JLabel("ANY", new ImageIcon( table.getClass().getResource("Any.png")),JLabel.CENTER);

                                 JLabel  DefineChainActionLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Define.gif")),JLabel.CENTER);

                                JLabel  AcceptLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Accept.gif")),JLabel.CENTER);
                                JLabel  DropLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Drop.gif")),JLabel.CENTER);
                                JLabel  RejectLabel = new JLabel(Action, new ImageIcon( table.getClass().getResource("Reject.gif")),JLabel.CENTER);


                                 JLabel  InputLabel = new JLabel("INPUT", new ImageIcon( table.getClass().getResource("Input.gif")),JLabel.CENTER);
                                 JLabel  OutputLabel = new JLabel("OUTPUT", new ImageIcon( table.getClass().getResource("Output.gif")),JLabel.CENTER);
                                 JLabel  ForwardLabel = new JLabel("FORWARD", new ImageIcon( table.getClass().getResource("Forward.png")),JLabel.CENTER);
                                 JLabel  DefineChainLabel = new JLabel(Chain, new ImageIcon( table.getClass().getResource("Define.gif")),JLabel.CENTER);

                              table.setValueAt(Id,row,1);

                              if (Chain.equals("INPUT"))
                                    table.setValueAt(InputLabel,row,2);
                             else
                                  if(Chain.equals("OUTPUT"))
                                     table.setValueAt(OutputLabel,row,2);
                                   else
                                   if(Chain.equals("FORWARD"))
                                     table.setValueAt(ForwardLabel,row,2);
                                        else
                                          table.setValueAt(DefineChainLabel,row,2);


                                    table.setValueAt(ProtocalLabel,row,3);

                                  if (notSrcIP.equals("NO"))
                                      table.setValueAt(NotLabel,row,4);
                                  else
                                      table.setValueAt(YesLabel,row,4);

                                  if (src_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,5);
                                  else
                                      table.setValueAt(SourceComLabel,row,5);

                                  if (notSrcPort.equals("NO"))
                                      table.setValueAt(NotLabel,row,6);
                                  else
                                      table.setValueAt(YesLabel,row,6);

                                   if (src_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,7);
                                  else
                                      table.setValueAt(SrcPortLabel,row,7);

                                  if (notSrcDevice.equals("NO"))
                                      table.setValueAt(NotLabel,row,8);
                                  else
                                      table.setValueAt(YesLabel,row,8);

                                  if (src_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,9);
                                  else
                                      table.setValueAt(SrcDeviceLabel,row,9);

                                  if (notDesIP.equals("NO"))
                                      table.setValueAt(NotLabel,row,10);
                                  else
                                      table.setValueAt(YesLabel,row,10);

                                  if (des_IP.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,11);
                                  else
                                      table.setValueAt(DesComLabel,row,11);

                                  if (notSrcPort.equals("NO"))
                                      table.setValueAt(NotLabel,row,12);
                                  else
                                      table.setValueAt(YesLabel,row,12);

                                   if (des_Port.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,13);
                                  else
                                      table.setValueAt(DesPortLabel,row,13);

                                  if (notDesDevice.equals("NO"))
                                      table.setValueAt(NotLabel,row,14);
                                  else
                                      table.setValueAt(YesLabel,row,14);

                                  if (des_Device.equals("ANY"))
                                      table.setValueAt(AnyLabel,row,15);
                                  else
                                      table.setValueAt(DesDeviceLabel,row,15);

                                  if (Action.equals("ACCEPT"))
                                      table.setValueAt(AcceptLabel,row,16);
                                  else
                                      if (Action.equals("DROP"))
                                          table.setValueAt(DropLabel,row,16);
                                      else
                                          if(Action.equals("REJECT"))
                                            table.setValueAt(RejectLabel,row,16);
                                          else
                                            table.setValueAt(DefineChainActionLabel,row,16);



                  }//try
                           catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                             }
                }//if
          }//refresh






  public   void setEdit() {

               String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
               String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice;
               String tmp;

                   ReturnRowSelect = table.getSelectedRow();
                  System.out.println("ReturnRowSelect : "+ReturnRowSelect);
                   try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++){
                      rs.next();
                    }

                                  Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                                  src_ipTextField.setText(src_IP);
                                  src_portTextField.setText(src_Port);
                                  src_deviceTextField.setText(src_Device);
                                  des_ipTextField.setText(des_IP);
                                  des_portTextField.setText(des_Port);
                                  des_deviceTextField.setText(des_Device);

                                   if (notSrcIP.equals("NO"))
                                        notsrcipCheckBox.setSelected(true);
                                  if (notSrcPort.equals("NO"))
                                        notsrcportCheckBox.setSelected(true);
                                  if (notSrcDevice.equals("NO"))
                                        notsrcdeviceCheckBox.setSelected(true);

                                  if (notDesIP.equals("NO"))
                                        notdesipCheckBox.setSelected(true);
                                  if (notDesPort.equals("NO"))
                                        notdesportCheckBox.setSelected(true);
                                  if (notDesDevice.equals("NO"))
                                        notdesdeviceCheckBox.setSelected(true);

                                  chainComboBox.setSelectedItem(Chain.trim());
                                  actionComboBox.setSelectedItem(Action.trim());
                  }
                                   catch(SQLException ex) {
                                        System.out.println(ex.getMessage());
                             }

  }//end setEdit








           public void checkdefinevar() {
         String SQL="",Name,Value,Type,Comment;

         SQL = "SELECT * FROM DefineVar order by ID";
         rsDefineVar = db.SQLRetrive(SQL);
    try {
          rsDefineVar.first();
             while(rsDefineVar.next()) {
                  rsDefineVar.previous();
                  Name = rsDefineVar.getString("Name");
                  Type = rsDefineVar.getString("Type");

         if(Type.equalsIgnoreCase("IP"))
         {
          if(Name.equalsIgnoreCase(src_ipTextField.getText().trim()))
             {
                 src_ipError = false;
             }
          if(Name.equalsIgnoreCase(des_ipTextField.getText().trim()))
             {
                 des_ipError = false;
             }
          }
          else if(Type.equalsIgnoreCase("Port"))
          {
           if(Name.equalsIgnoreCase(src_portTextField.getText().trim()))
            {
                  src_portError = false;
            }
           if(Name.equalsIgnoreCase(des_portTextField.getText().trim()))
            {
                  des_portError = false;
            }
          }
          else if(Type.equalsIgnoreCase("Device"))
          {
            if(Name.equalsIgnoreCase(src_deviceTextField.getText().trim()))
            {
                  src_deviceError = false;
            }
           if(Name.equalsIgnoreCase(des_deviceTextField.getText().trim()))
            {
                  des_deviceError = false;
            }

          }

                  rsDefineVar.next();
             }//end while

            Name = rsDefineVar.getString("Name");
            Type = rsDefineVar.getString("Type");

         if(Type.equalsIgnoreCase("IP"))
         {
          if(Name.equalsIgnoreCase(src_ipTextField.getText().trim()))
             {
                 src_ipError = false;
             }
          if(Name.equalsIgnoreCase(des_ipTextField.getText().trim()))
             {
                 des_ipError = false;
             }
          }
          else if(Type.equalsIgnoreCase("Port"))
          {
           if(Name.equalsIgnoreCase(src_portTextField.getText().trim()))
            {
                  src_portError = false;
            }
           if(Name.equalsIgnoreCase(des_portTextField.getText().trim()))
            {
                  des_portError = false;
            }
          }
          else if(Type.equalsIgnoreCase("Device"))
          {
            if(Name.equalsIgnoreCase(src_deviceTextField.getText().trim()))
            {
                  src_deviceError = false;
            }
           if(Name.equalsIgnoreCase(des_deviceTextField.getText().trim()))
            {
                  des_deviceError = false;
            }

          }

        }
        catch(Exception ex){

        }
        }
    public static void Apply() {
        try {
               db.con.commit();
                  }
               catch (SQLException ex) {
                  System.out.println(ex.getMessage());
        }

    }
     public static void clickedReset() {
         try {
                  db.con.rollback();
                 }
            catch (SQLException ex) {
                  System.out.println(ex.getMessage());
               }
                  refreshRecordTable();
                 System.out.println("Reset");
    }

              public void updateRecord() {
              String SQL, field = "", value = "",stringPK="";
              String src_ip="",src_port="",src_device="",des_ip="",des_port="",des_device="";
              String chainValue = "",notsrcipCB="",notsrcportCB="",notsrcdeviceCB="",notdesipCB="",notdesportCB="",notdesdeviceCB="";
              int  ID=0;
              String temp, en_disValue;

        System.out.println("use updateRecord");


    if (status.equals("ADD")) {
    SQL = "INSERT INTO " + tableName ;
        for(int i=1; i < UpdatePanel.fieldinfo.length; i++) {
    //  field = field + ", " +"Service ,"+ UpdatePanel.fieldinfo[i][0];
          field = field + ", "+ UpdatePanel.fieldinfo[i][0];
       }

       field = "Service"+field;
         if (src_ipTextField.getText().trim().length()== 0)
              src_ip = "ANY";
        else
              src_ip = src_ipTextField.getText().trim().toUpperCase();

         if (src_portTextField.getText().trim().length() == 0)
              src_port = "ANY";
        else
              src_port = src_portTextField.getText().trim().toUpperCase();

         if (src_deviceTextField.getText().trim().length() == 0)
              src_device = "ANY";
         else
              src_device = src_deviceTextField.getText().trim().toUpperCase();

         if (des_ipTextField.getText().trim().length() == 0)
              des_ip = "ANY";
         else
              des_ip = des_ipTextField.getText().trim().toUpperCase();

         if (des_portTextField.getText().trim().length()== 0)
              des_port = "ANY";
         else
             des_port = des_portTextField.getText().trim().toUpperCase();

         if (des_deviceTextField.getText().trim().length()== 0)
              des_device = "ANY";
        else
              des_device = des_deviceTextField.getText().trim().toUpperCase();

         if ( notsrcipCheckBox.isSelected() == true )
              notsrcipCB = "NO";
         else notsrcipCB = "YES";
         if ( notsrcportCheckBox.isSelected() == true)
              notsrcportCB = "NO";
         else notsrcportCB = "YES";
         if ( notsrcdeviceCheckBox.isSelected() == true)
              notsrcdeviceCB = "NO";
         else notsrcdeviceCB = "YES";

         if ( notdesipCheckBox.isSelected() == true )
              notdesipCB = "NO";
         else notdesipCB = "YES";
         if ( notdesportCheckBox.isSelected() == true)
              notdesportCB = "NO";
         else notdesportCB = "YES";
         if ( notdesdeviceCheckBox.isSelected() == true)
              notdesdeviceCB = "NO";
         else notdesdeviceCB = "YES";

  if(src_device.substring(0,3).equals("PPP") || src_device.substring(0,3).equals("ETH") || src_device.substring(0,2).equals("LO")){
          src_device = src_device.toLowerCase();
  }

  if(des_device.substring(0,3).equals("PPP") || des_device.substring(0,3).equals("ETH") || des_device.substring(0,2).equals("LO")){
          des_port = des_device.toLowerCase();
  }

          value=value +" 'DnsTcp' ,'"+chainComboBox.getSelectedItem().toString()+"' , '" + src_ip + "'  , '" +src_port+ "' , '" +src_device+ "' , '" +des_ip+ "' , '" +des_port+ "' , '" +des_device+ "' , '"+"TCP"+"'  , '" +actionComboBox.getSelectedItem()+ "'  , '" +notsrcipCB+ "', '" +notsrcportCB+ "', '" +notsrcdeviceCB+ "', '" +notdesipCB+ "', '" +notdesportCB+ "', '" +notdesdeviceCB+ "'";

      SQL = SQL + "(" + field + ") VALUES (" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

                   System.out.println("Test Return Row Select : " + ManagePanel.ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                     }
                       ID = rs.getInt("ID");
                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }


         if (src_ipTextField.getText().trim().length()== 0)
              src_ip = "ANY";
        else
              src_ip = src_ipTextField.getText().trim().toUpperCase();

         if (src_portTextField.getText().trim().length() == 0)
              src_port = "";
        else
              src_port = src_portTextField.getText();

         if (src_deviceTextField.getText().trim().length() == 0)
              src_device = "ANY";
         else
              src_device = src_deviceTextField.getText().trim().toUpperCase();

         if (des_ipTextField.getText().trim().length() == 0)
              des_ip = "ANY";
         else
              des_ip = des_ipTextField.getText().trim().toUpperCase();

         if (des_portTextField.getText().trim().length()== 0)
              des_port = "";
         else
             des_port = des_portTextField.getText().trim().toUpperCase();

         if (des_deviceTextField.getText().trim().length()== 0)
              des_device = "ANY";
        else
              des_device = des_deviceTextField.getText().trim().toUpperCase();

         if ( notsrcipCheckBox.isSelected() == true )
              notsrcipCB = "NO";
         else notsrcipCB = "YES";
         if ( notsrcportCheckBox.isSelected() == true)
              notsrcportCB = "NO";
         else notsrcportCB = "YES";
         if ( notsrcdeviceCheckBox.isSelected() == true)
              notsrcdeviceCB = "NO";
         else notsrcdeviceCB = "YES";

         if ( notdesipCheckBox.isSelected() == true )
              notdesipCB = "NO";
         else notdesipCB = "YES";
         if ( notdesportCheckBox.isSelected() == true)
              notdesportCB = "NO";
         else notdesportCB = "YES";
         if ( notdesdeviceCheckBox.isSelected() == true)
              notdesdeviceCB = "NO";
         else notdesdeviceCB = "YES";

          if ( enableRadioButton.isSelected() == true )
              en_disValue = "ENABLE";
          else
              en_disValue = "DISABLE";

if(src_device.substring(0,3).equals("PPP") || src_device.substring(0,3).equals("ETH") || src_device.substring(0,2).equals("LO")){
          src_device = src_device.toLowerCase();
  }

  if(des_device.substring(0,3).equals("PPP") || des_device.substring(0,3).equals("ETH") || des_device.substring(0,2).equals("LO")){
          des_port = des_device.toLowerCase();
  }


              SQL = "UPDATE " + tableName + " SET";
              // value=value+" '"+chainValue+"' , '" + src_ipTextField.getText() + "'  , '" +src_portTextField.getText()+ "' , '" +src_deviceTextField.getText()+ "' , '" +des_ipTextField.getText()+ "' , '" +des_portTextField.getText()+ "' , '" +des_deviceTextField.getText()+ "' , '" +protocalNames[protocalComboBox.getSelectedIndex()]+ "'  , '" +actionNames[actionComboBox.getSelectedIndex()]+ "'  , '" +notsrcipCB+ "', '" +notsrcportCB+ "', '" +notsrcdeviceCB+ "', '" +notdesipCB+ "', '" +notdesportCB+ "', '" +notdesdeviceCB+ "' " ;

              field = field + " notSrcIP = '"+notsrcipCB+"'  , notSrcPort = '" +notsrcportCB+ "',notSrcDevice='"+notsrcdeviceCB+"'      ";
              field = field + ", notDesIP = '"+notdesipCB+ "'  , notDesPort='"+notdesportCB+"',notDesDevice='"+notdesdeviceCB+"'   ";
              field = field + ", src_IP = '" +src_ipTextField.getText()+ "'  , src_Port = '" +src_portTextField.getText()+ "'   , src_Device = '" +src_deviceTextField.getText()+ "'  , des_IP = '" +des_ipTextField.getText()+ "'  , des_Port = '" +des_portTextField.getText()+ "'      ";
              field = field + ", Chain= '"+chainComboBox.getSelectedItem().toString()+"'   , Action = '"+actionComboBox.getSelectedItem().toString()+"' ";

          stringPK = " ID = "+ID+" ";
          SQL = SQL + field + "WHERE"+stringPK;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }

                    try {
                          rs.last();
                      }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }

          refreshRecordTable();


  }
}