package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.sql.*;
import java.lang.*;
import java.text.*;
import java.util.*;
import java.io.*;
import javax.swing.JTextField;
import com.borland.jbcl.layout.*;

public class SearchUpdatePanel extends JPanel {

        ManagePanel manpanel = new ManagePanel();
	JPanel panel;
	// Display Component
	JTextField allField[];
	int numberOfRecord;
	// Database Component
	DBUtil db;
	Connection con;
	public static ResultSet rs,rsDefineVar;
        public static boolean src_ipError,src_portError,src_deviceError,des_ipError,des_portError,des_deviceError;
        String bookmark[] = new String[5]; // �óդ����տ�Ŵ�����
	// 0: Field Name, 1: Field Type, 2: Caption, 3: Value, 4: Primary Key 5: Source
	public static String fieldinfo[][];
	String url;
	String user;
	String password;
	String retriveSQL;
	String tableName;

        public static final String EMPTY = "";
        public static final String NEW = "NEW";
        public static final String UPDATE = "UPDATE";
        public static final String PK = "PK";

        /**Construct the frame*/
  public SearchUpdatePanel() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    String settableInfo[][] = {
			{ "ID", "INTEGER", "ID", "", "PK"},
			{ "Chain", "STRING", "Chain", "", ""},
			{ "src_IP", "STRING", "src_IP", "", ""},
			{ "src_Port", "STRING", "src_Port", "", ""},
			{ "src_Device", "STRING", "src_Device", "", ""},
			{ "des_IP", "STRING", "des_IP", "", ""},
			{ "des_Port", "STRING", "des_Port", "", ""},
			{ "des_Device", "STRING", "des_Device", "", ""},
			{ "Protocal", "STRING", "Protocal", "", ""},
			{ "Action", "STRING", "Action", "", ""},

                        { "notSrcIP", "STRING", "notSrcIP", "", ""},
			{ "notSrcPort", "STRING", "notSrcPort", "", ""},
			{ "notSrcDevice", "STRING", "notSrcDevice", "", ""},
			{ "notDesIP", "STRING", "notDesIP", "", ""},
			{ "notDesPort", "STRING", "notDesPort ", "", ""},
			{ "notDesDevice", "STRING", "notDesDevice", "", ""},



		};
      String seturl = "jdbc:odbc:dbConfige";
      String setuser = "admin";
      String setpassword = "";
      String setSQL = "SELECT * FROM Confige";
      String settable = "Confige";

      try {
        jbInit();
        System.out.println("DBUtil");
      }
      catch(Exception e) {
        e.printStackTrace();
      }

                setDBPanel(settableInfo, settable, setSQL, seturl, setuser, setpassword, "Firewall Configuration");

      }   // end SearchUpdatePanel Constructor


      // table.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        public static String protocalNames[] = { "TCP","UDP","ICMP"};
        public static String actionNames[]= { "ACCEPT","DROP","REJECT"};
        public static String chainNames[] = {"INPUT","OUTPUT","FORWARD"};

        JPanel contentPane;
        public static String status = "";
        JPanel jPanel3 = new JPanel();
        public static JLabel updatelogoLabel = new JLabel();
        Border border1;
        TitledBorder titledBorder1;
        Border border2;
        TitledBorder titledBorder2;
        Border border3;
        TitledBorder titledBorder3;
        Border border4;
        TitledBorder titledBorder4;
        JPanel jPanel1 = new JPanel();
        GridLayout gridLayout1 = new GridLayout();
        JPanel jPanel9 = new JPanel();
        Border border5;
        TitledBorder titledBorder5;
        Border border6;
        Border border7;
        TitledBorder titledBorder6;
        TitledBorder titledBorder7;
        TitledBorder titledBorder8;
        Color color1;
        TitledBorder titledBorder9;
        TitledBorder titledBorder10;
         Border border8;
        TitledBorder titledBorder11;
        Border border9;
        public static JTextField des_ipTextField = new JTextField(10);
        JPanel jPanel8 = new JPanel();
        public static JTextField des_deviceTextField = new JTextField(10);
        public static JCheckBox notdesportCheckBox = new JCheckBox();
        JPanel desPanel = new JPanel();
        public static JCheckBox notdesdeviceCheckBox = new JCheckBox();
        public static JCheckBox notdesipCheckBox = new JCheckBox();
        public static JTextField des_portTextField = new JTextField(10);

      JLabel jLabel8 = new JLabel();
      JLabel jLabel7 = new JLabel();
      JLabel jLabel6 = new JLabel();
      JPanel jPanel2 = new JPanel();

       ButtonGroup rbg = new ButtonGroup();

      Border border10;
      JPanel jPanel10 = new JPanel();
      JPanel jPanel110 = new JPanel();
      public static JComboBox protocalComboBox = new JComboBox(protocalNames);
      public static JComboBox actionComboBox = new JComboBox(actionNames);
      JPanel jPanel11 = new JPanel();
      JLabel jLabel4 = new JLabel();
      JLabel jLabel3 = new JLabel();
      Border border11;
      JPanel jPanel4 = new JPanel();
      BorderLayout borderLayout5 = new BorderLayout();
      GridBagLayout gridBagLayout6 = new GridBagLayout();
      JPanel jPanel14 = new JPanel();

      JButton cancelButton = new JButton(new ImageIcon("images/Cancel.png"));
      JButton resetButton = new JButton(new ImageIcon("images/Reset.png"));
      JButton okButton = new JButton(new ImageIcon("images/Ok.png"));

      GridBagLayout gridBagLayout5 = new GridBagLayout();

      JPanel chainPanel = new JPanel();

      public static JTextField src_ipTextField = new JTextField(10);
      public static JCheckBox notsrcportCheckBox = new JCheckBox();
      JLabel jLabel11 = new JLabel();
      JLabel jLabel10 = new JLabel();
      JLabel jLabel9 = new JLabel();
      public static JCheckBox notsrcipCheckBox = new JCheckBox();
      public static JCheckBox notsrcdeviceCheckBox = new JCheckBox();
     public static JTextField src_portTextField = new JTextField(10);
     public static JTextField src_deviceTextField = new JTextField(10);
      JPanel srcPanel = new JPanel();
      JLabel srccomLabel = new JLabel();
      JLabel descomLabel = new JLabel();
      JLabel chainLabel = new JLabel();
      XYLayout xYLayout1 = new XYLayout();
      XYLayout xYLayout2 = new XYLayout();
      XYLayout xYLayout3 = new XYLayout();
  XYLayout xYLayout4 = new XYLayout();
  XYLayout xYLayout5 = new XYLayout();
  XYLayout xYLayout6 = new XYLayout();

  public static JComboBox chainComboBox = new JComboBox(chainNames);

  XYLayout xYLayout7 = new XYLayout();
  XYLayout xYLayout8 = new XYLayout();
  XYLayout xYLayout9 = new XYLayout();
  XYLayout xYLayout10 = new XYLayout();
  public static JCheckBox notprotocolCheckBox = new JCheckBox();


  /**Component initialization*/
  public void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("[Your Icon]")));
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.lightGray,new Color(134, 134, 134));
    titledBorder1 = new TitledBorder(border1,"Source");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134));
    titledBorder2 = new TitledBorder(border2,"Source");
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134));
    titledBorder3 = new TitledBorder(border3,"Destination");
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134));
    titledBorder4 = new TitledBorder(border4,"Chain");
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134));
    titledBorder5 = new TitledBorder(border5,"");
    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(134, 134, 134));
    border7 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(134, 134, 134));
    titledBorder6 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"");
    titledBorder7 = new TitledBorder("");
    titledBorder8 = new TitledBorder("");
    color1 = jPanel3.getBackground();
    titledBorder9 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),"");
    titledBorder10 = new TitledBorder(BorderFactory.createLineBorder(new Color(153, 153, 153),2),"");
    border8 = BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(153, 153, 153),2),BorderFactory.createEmptyBorder(0,0,3,0));
    titledBorder11 = new TitledBorder(BorderFactory.createLineBorder(new Color(153, 153, 153),2),"");
    border9 = BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142)),BorderFactory.createEmptyBorder(0,0,3,0));
    border10 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border11 = BorderFactory.createEmptyBorder(10,0,0,0);
    setLayout(xYLayout1);
    //this.setTitle("Firewall Configuration");
    updatelogoLabel.setBackground(new Color(236, 233, 230));
    updatelogoLabel.setFont(new java.awt.Font("SansSerif", 1, 12));
    updatelogoLabel.setForeground(UIManager.getColor("Desktop.background"));
    updatelogoLabel.setBorder(border11);
    updatelogoLabel.setPreferredSize(new Dimension(120, 30));
    updatelogoLabel.setHorizontalAlignment(SwingConstants.CENTER);
    updatelogoLabel.setHorizontalTextPosition(SwingConstants.CENTER);
    this.setBackground(new Color(236, 233, 230));
    setFont(new java.awt.Font("SansSerif", 1, 12));
    this.setMaximumSize(new Dimension(624, 356));
    this.setPreferredSize(new Dimension(524, 378));
    jPanel3.setBackground(new Color(236, 233, 230));
    jPanel3.setFont(new java.awt.Font("SansSerif", 1, 12));
    jPanel3.setForeground(SystemColor.desktop);
    jPanel3.setLayout(xYLayout4);
    jPanel1.setLayout(gridLayout1);
    gridLayout1.setRows(2);
    jPanel9.setLayout(xYLayout3);
    des_ipTextField.setFocusAccelerator('4');
    des_ipTextField.setScrollOffset(10);
    jPanel8.setBackground(new Color(236, 233, 230));
    jPanel8.setFont(new java.awt.Font("SansSerif", 1, 12));
    jPanel8.setMaximumSize(new Dimension(428, 50));
    jPanel8.setMinimumSize(new Dimension(270, 10));
    jPanel8.setPreferredSize(new Dimension(482, 10));
    jPanel8.setLayout(xYLayout2);
    notdesportCheckBox.setBackground(new Color(236, 233, 230));
    notdesportCheckBox.setRequestFocusEnabled(false);
    notdesportCheckBox.setText("!");
    desPanel.setLayout(xYLayout5);
    desPanel.setBackground(new Color(236, 233, 230));
    desPanel.setFont(new java.awt.Font("SansSerif", 1, 12));
    desPanel.setBorder(titledBorder3);
    desPanel.setMaximumSize(new Dimension(239, 115));
    notdesdeviceCheckBox.setBackground(new Color(236, 233, 230));
    notdesdeviceCheckBox.setRequestFocusEnabled(false);
    notdesdeviceCheckBox.setText("!");
    notdesipCheckBox.setBackground(new Color(236, 233, 230));
    notdesipCheckBox.setRequestFocusEnabled(false);
    notdesipCheckBox.setText("!");
    jLabel8.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel8.setText("des IP");
    jLabel7.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel7.setText("des Port");
    jLabel6.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel6.setText("des Device");

    srccomLabel.setIcon(new ImageIcon("images/ComputerSrc.png"));

    jPanel2.setBackground(new Color(236, 233, 230));
    jPanel2.setPreferredSize(new Dimension(500, 60));
    jPanel2.setLayout(xYLayout8);
    jPanel10.setLayout(borderLayout5);
    jPanel110.setLayout(xYLayout10);
    jPanel110.setBackground(new Color(236, 233, 230));
    jPanel110.setMaximumSize(new Dimension(351, 32));
    protocalComboBox.setBackground(new Color(236, 233, 230));
    protocalComboBox.setBorder(BorderFactory.createLoweredBevelBorder());
    protocalComboBox.setMaximumRowCount(5);
    jPanel11.setPreferredSize(new Dimension(520, 50));
    jPanel11.setLayout(xYLayout9);
    jPanel11.setBackground(new Color(236, 233, 230));
    jPanel11.setMaximumSize(new Dimension(480, 480));
    actionComboBox.setBackground(new Color(236, 233, 230));
    actionComboBox.setBorder(BorderFactory.createLoweredBevelBorder());
    actionComboBox.setToolTipText("");
    jLabel4.setBackground(new Color(236, 233, 216));
    jLabel4.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel4.setText("Protocol");
    jLabel3.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel3.setText("Action");
    jPanel4.setLayout(gridBagLayout5);
    jPanel14.setLayout(gridBagLayout6);
    jPanel14.setBackground(new Color(236, 233, 230));
    jPanel14.setBorder(border10);
    jPanel14.setMaximumSize(new Dimension(555, 48));
    jPanel14.setMinimumSize(new Dimension(500, 48));
    jPanel14.setPreferredSize(new Dimension(500, 54));
    cancelButton.setBackground(new Color(236, 233, 230));
    cancelButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    cancelButton.setBorder(titledBorder9);
    cancelButton.setMaximumSize(new Dimension(70, 29));
    cancelButton.setMinimumSize(new Dimension(70, 29));
    cancelButton.setPreferredSize(new Dimension(70, 29));
    cancelButton.setHorizontalTextPosition(SwingConstants.LEFT);
    cancelButton.setText("Cancel");
    cancelButton.addActionListener(new clickedCancel());
    resetButton.setBackground(new Color(236, 233, 230));
    resetButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    resetButton.setBorder(titledBorder6);
    resetButton.setMaximumSize(new Dimension(70, 29));
    resetButton.setMinimumSize(new Dimension(70, 29));
    resetButton.setPreferredSize(new Dimension(80, 33));
    resetButton.setHorizontalTextPosition(SwingConstants.LEFT);
    resetButton.setText("Reset");
    okButton.setBackground(new Color(236, 233, 230));
    okButton.setFont(new java.awt.Font("SansSerif", 1, 12));
    okButton.setBorder(border9);
    okButton.setMaximumSize(new Dimension(70, 29));
    okButton.setMinimumSize(new Dimension(70, 29));
    okButton.setPreferredSize(new Dimension(45, 29));
    okButton.setHorizontalTextPosition(SwingConstants.LEFT);
    okButton.setText("OK");
    okButton.addActionListener(new clickedOk());
    chainPanel.setBorder(titledBorder4);
    //chainPanel.createImage(new ImageIcon("images/Chain.png"));
//    chainPanel.

    chainPanel.setPreferredSize(new Dimension(475, 50));
    chainPanel.setBackground(new Color(236, 233, 230));
    chainPanel.setFont(new java.awt.Font("SansSerif", 1, 12));
    chainPanel.setLayout(xYLayout7);
    src_ipTextField.setCaretPosition(0);
    src_ipTextField.setFocusAccelerator('1');
    src_ipTextField.setSelectedTextColor(Color.blue);
    src_ipTextField.setSelectionEnd(0);
    src_ipTextField.setSelectionStart(0);
    notsrcportCheckBox.setBackground(new Color(236, 233, 230));
    notsrcportCheckBox.setRequestFocusEnabled(false);
    notsrcportCheckBox.setText("!");
    jLabel11.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel11.setText("src Device");
    jLabel10.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel10.setText("src Port");
    jLabel9.setFont(new java.awt.Font("SansSerif", 1, 12));
    jLabel9.setText("src IP");
    notsrcipCheckBox.setBackground(new Color(236, 233, 230));
    notsrcipCheckBox.setRequestFocusEnabled(false);
    notsrcipCheckBox.setText("!");
    notsrcdeviceCheckBox.setBackground(new Color(236, 233, 230));
    notsrcdeviceCheckBox.setRequestFocusEnabled(false);
    notsrcdeviceCheckBox.setText("!");
    src_portTextField.setMinimumSize(new Dimension(200, 19));
    src_portTextField.setPreferredSize(new Dimension(120, 19));
    src_portTextField.setFocusAccelerator('2');
    src_portTextField.setSelectedTextColor(Color.blue);
    srcPanel.setBackground(new Color(236, 233, 230));
    srcPanel.setFont(new java.awt.Font("SansSerif", 1, 12));
    srcPanel.setBorder(titledBorder2);
    srcPanel.setLayout(xYLayout6);
    descomLabel.setIcon(new ImageIcon("images/ComputerDes.png"));
    chainLabel.setIcon(new ImageIcon("images/Chain.gif"));
    src_deviceTextField.setFocusAccelerator('3');
    des_portTextField.setFocusAccelerator('5');
    des_deviceTextField.setFocusAccelerator('6');
    jPanel4.setBackground(new Color(236, 233, 230));
    jPanel10.setBackground(new Color(236, 233, 230));
    xYLayout1.setWidth(515);
    xYLayout1.setHeight(403);
    jPanel9.setBackground(new Color(236, 233, 230));
    chainComboBox.setBackground(new Color(236, 233, 230));
    chainComboBox.setBorder(BorderFactory.createLoweredBevelBorder());
    notprotocolCheckBox.setBackground(new Color(236, 233, 230));
    notprotocolCheckBox.setText("!");
    add(jPanel3,   new XYConstraints(0, 0, -1, 47));
    jPanel3.add(updatelogoLabel, new XYConstraints(153, 7, 209, 34));
    add(jPanel1,  new XYConstraints(0, 30, 511, 402));
    jPanel1.add(jPanel9, null);
    jPanel1.add(jPanel10, null);
    jPanel110.add(actionComboBox, new XYConstraints(310, 7, 155, 27));
    jPanel110.add(jLabel4, new XYConstraints(48, 11, -1, -1));
    jPanel110.add(protocalComboBox, new XYConstraints(104, 7, 143, 26));
    jPanel110.add(jLabel3, new XYConstraints(270, 11, -1, -1));
    jPanel110.add(notprotocolCheckBox,  new XYConstraints(17, 6, 27, 25));
    jPanel10.add(jPanel4, BorderLayout.SOUTH);
    jPanel4.add(jPanel14,               new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 70, 0), -26, 10));
    jPanel14.add(okButton,       new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 122, 0, 0), 11, 2));
    jPanel14.add(cancelButton,              new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(4, 0, 6, 74), 14, 3));
    jPanel14.add(resetButton,    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 87, 5, 122), 10, 1));
    jPanel10.add(jPanel11,  BorderLayout.NORTH);
    jPanel11.add(jPanel110,  new XYConstraints(21, 1, 464, 43));
    chainPanel.add(chainComboBox,   new XYConstraints(147, 0, 144, 27));
    chainPanel.add(chainLabel,      new XYConstraints(89, 0, 51, 30));


    srcPanel.add(src_deviceTextField, new XYConstraints(96, 66, -1, -1));
    srcPanel.add(notsrcipCheckBox, new XYConstraints(12, 18, -1, -1));
    srcPanel.add(jLabel9, new XYConstraints(40, 22, -1, -1));
    srcPanel.add(src_ipTextField, new XYConstraints(96, 22, -1, -1));
    srcPanel.add(src_portTextField, new XYConstraints(96, 43, -1, -1));
    srcPanel.add(jLabel10, new XYConstraints(39, 45, -1, -1));
    srcPanel.add(notsrcportCheckBox, new XYConstraints(12, 41, -1, -1));
    srcPanel.add(notsrcdeviceCheckBox, new XYConstraints(12, 64, -1, -1));
    srcPanel.add(jLabel11, new XYConstraints(40, 68, -1, -1));
    srcPanel.add(srccomLabel,          new XYConstraints(91, 0, 33, 21));
    jPanel8.add(srcPanel,         new XYConstraints(19, 5, 229, 114));
    jPanel8.add(desPanel,            new XYConstraints(252, 5, 239, 114));
    desPanel.add(descomLabel,            new XYConstraints(90, 0, 34, 19));
    desPanel.add(des_deviceTextField, new XYConstraints(105, 66, -1, -1));
    desPanel.add(notdesipCheckBox, new XYConstraints(5, 18, -1, -1));
    desPanel.add(jLabel8, new XYConstraints(45, 22, -1, -1));
    desPanel.add(des_ipTextField, new XYConstraints(105, 20, -1, -1));
    desPanel.add(notdesportCheckBox, new XYConstraints(5, 41, -1, -1));
    desPanel.add(jLabel7, new XYConstraints(44, 45, -1, -1));
    desPanel.add(des_portTextField, new XYConstraints(105, 43, -1, -1));
    desPanel.add(notdesdeviceCheckBox, new XYConstraints(6, 62, -1, -1));
    desPanel.add(jLabel6, new XYConstraints(45, 68, -1, -1));
    jPanel9.add(jPanel2,   new XYConstraints(1, 15, 511, -1));
    jPanel2.add(chainPanel,      new XYConstraints(18, 0, 470, 61));
    jPanel9.add(jPanel8,    new XYConstraints(0, 70, 511, 131));

    resetButton.addActionListener(new clickedReset());


    src_ipTextField.addFocusListener(new src_ipTextFieldFocus());
    src_ipTextField.addKeyListener(new enteredSrc_IP());

    src_portTextField.addFocusListener(new src_portTextFieldFocus());
    src_portTextField.addKeyListener(new enteredSrc_Port());

    src_deviceTextField.addFocusListener(new src_deviceTextFieldFocus());
    src_deviceTextField.addKeyListener(new enteredSrc_Device());

    des_ipTextField.addFocusListener(new des_ipTextFieldFocus());
    des_ipTextField.addKeyListener(new enteredDes_IP());

    des_portTextField.addFocusListener(new des_portTextFieldFocus());
    des_portTextField.addKeyListener(new enteredDes_Port());

    des_deviceTextField.addFocusListener(new des_deviceTextFieldFocus());
    des_deviceTextField.addKeyListener(new enteredDes_Device());



  }//end jbinit
  public class src_ipTextFieldFocus implements FocusListener  {
    public void focusGained(FocusEvent e) {
          System.out.println("Focus Gained");
    }
    public void focusLost(FocusEvent e) {
          System.out.println("Focus Lost");
          checkSrcIP();
    }
  }

  public class src_portTextFieldFocus implements FocusListener  {
    public void focusGained(FocusEvent e) {
          System.out.println("Focus Gained");
    }
    public void focusLost(FocusEvent e) {
          System.out.println("Focus Lost");
          checkSrcPort();
    }
  }
  public class src_deviceTextFieldFocus implements FocusListener  {
    public void focusGained(FocusEvent e) {
          System.out.println("Focus Gained");
    }
    public void focusLost(FocusEvent e) {
          System.out.println("Focus Lost");
          checkSrcDevice();
    }
  }

 public class des_ipTextFieldFocus implements FocusListener  {
    public void focusGained(FocusEvent e) {
          System.out.println("Focus Gained");
    }
    public void focusLost(FocusEvent e) {
          System.out.println("Focus Lost");
          checkDesIP();
    }
  }

   public class des_portTextFieldFocus implements FocusListener  {
    public void focusGained(FocusEvent e) {
          System.out.println("Focus Gained");
    }
    public void focusLost(FocusEvent e) {
          System.out.println("Focus Lost");
          checkDesPort();
    }
  }

   public class des_deviceTextFieldFocus implements FocusListener  {
    public void focusGained(FocusEvent e) {
          System.out.println("Focus Gained");
    }
    public void focusLost(FocusEvent e) {
          System.out.println("Focus Lost");
          checkDesDevice();
    }
  }

  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
//    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            System.exit(0);
    }
  }

  class enteredSrc_IP extends KeyAdapter {
    public void keyPressed(KeyEvent evt) {
      int key = evt.getKeyCode();
      if (key == KeyEvent.VK_ENTER) {
            src_portTextField.requestFocus();
            System.out.println("Enter pressed");
      }
    }
  }//end enterSrc_IP

  class enteredSrc_Port extends KeyAdapter {
    public void keyPressed(KeyEvent evt) {
      int key = evt.getKeyCode();
      if (key == KeyEvent.VK_ENTER) {
            src_deviceTextField.requestFocus();
            System.out.println("Enter");
      }

    }
  }//end enterSrc_Port

  class enteredSrc_Device extends KeyAdapter {
    public void keyPressed(KeyEvent evt) {
      int key = evt.getKeyCode();
      if (key == KeyEvent.VK_ENTER) {
            des_ipTextField.requestFocus();
            System.out.println("Enter");
      }
    }
  }//end enterSrc_Device

  class enteredDes_IP extends KeyAdapter {
    public void keyPressed(KeyEvent evt) {
      int key = evt.getKeyCode();
      if (key == KeyEvent.VK_ENTER) {
           des_portTextField.requestFocus();
            System.out.println("Enter");
      }
    }
  }//end enterDes_IP

  class enteredDes_Port extends KeyAdapter {
    public void keyPressed(KeyEvent evt) {
      int key = evt.getKeyCode();
      if (key == KeyEvent.VK_ENTER) {
            des_deviceTextField.requestFocus();
            System.out.println("Enter");
      }
    }
  }//end enterDes_Port

  class enteredDes_Device extends KeyAdapter {
    public void keyPressed(KeyEvent evt) {
      int key = evt.getKeyCode();
      if (key == KeyEvent.VK_ENTER) {
            src_ipTextField.requestFocus();
            System.out.println("Enter");
      }
    }
  }//end enterDes_Device

  public void checkSrcIP() {

        String  allIP,IP,subNet="",aIP,bIP,cIP,dIP;
        int i,iaIP,ibIP,icIP,idIP;

        src_ipError = false;
//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////
  if(!src_ipTextField.getText().trim().equalsIgnoreCase("ANY")) {

  if (src_ipTextField.getText().trim().length() != 0) {
  try {
        allIP=src_ipTextField.getText().trim();
        System.out.println(allIP);

       i = allIP.indexOf("/");
       if (i < 0) i = allIP.length();
       IP = allIP.substring(0,i);

       System.out.println("//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////");
       System.out.println(IP.toString());


       i = IP.indexOf(".");
       aIP = IP.substring(0,i);
       IP = IP.substring(i+1,IP.length());
       System.out.println(aIP.toString());

      i = IP.indexOf(".");
      bIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
      System.out.println(bIP.toString());

      i = IP.indexOf(".");
      cIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
     System.out.println(cIP.toString());

     dIP = IP.substring(0,IP.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);



         if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else {

//        src_ipTextField.transferFocus();

//        JOptionPane.showConfirmDialog(this,"   Source IP Wrong !!  ","Error !!",JOptionPane.DEFAULT_OPTION,JOptionPane.ERROR_MESSAGE);
        System.out.println("Message Error");
        src_ipError = true;
//        src_portTextField.requestFocus();
        //System.exit();
        // Runtime.getRuntime().exit(1);


        }
   }//try}
  catch (Exception e) {
      //System.out.println(e.getMessage());
      //src_portTextField.requestFocus();
    //  System.out.println("Src IP !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 1");
      //JOptionPane.showMessageDialog(this,"   Source IP Wrong !!  ***","Error !!",JOptionPane.ERROR_MESSAGE);

  //    System.out.println("Src IP !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 2");
      src_ipError = true;
  }
//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////

  try {
       System.out.println("//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////");

     allIP=src_ipTextField.getText().trim();

     i = allIP.indexOf("/");
    if (i>0) {
    subNet = allIP.substring(i+1,allIP.length());
    System.out.println(subNet.toString());
    i = subNet.indexOf(".");

    if (i < 0 && Integer.parseInt(subNet) <= 32 && Integer.parseInt(subNet) >= 0) {
    }
    else {

     i = subNet.indexOf(".");
     aIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(aIP.toString());

     i = subNet.indexOf(".");
     bIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(bIP.toString());

     i = subNet.indexOf(".");
     cIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(cIP.toString());

     dIP = subNet.substring(0,subNet.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);


       if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else  {
      //  src_portTextField.requestFocus();
        //src_ipTextField.transferFocus();
    //    JOptionPane.showMessageDialog(this,"   Source IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
        System.out.println("Message Error");
//        errorfield = true;
        src_ipError = true;
        }


 }
 }
 else {
  }
   }
  catch (Exception e) {
     // System.out.println(e.getMessage());
    //  src_portTextField.requestFocus();
  //    JOptionPane.showMessageDialog(this,"   Source IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
//      errorfield = true;
              src_ipError = true;
  }

  }// end if ()

  }

//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
  } //end checkIP

  public void checkDesIP() {
        String  allIP,IP,subNet="",aIP,bIP,cIP,dIP;
        int i,iaIP,ibIP,icIP,idIP;

        des_ipError = false;

//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////
  if(!des_ipTextField.getText().trim().equalsIgnoreCase("ANY")) {

  if(des_ipTextField.getText().trim().length() != 0) {
  try {
        allIP=des_ipTextField.getText().trim();
        System.out.println(allIP);

       i = allIP.indexOf("/");
       if (i < 0) i = allIP.length();
       IP = allIP.substring(0,i);

       System.out.println("//////////////////////////////////////////////////////////// section check IP ///////////////////////////////////////////////////////////////////////////");
       System.out.println(IP.toString());


       i = IP.indexOf(".");
       aIP = IP.substring(0,i);
       IP = IP.substring(i+1,IP.length());
       System.out.println(aIP.toString());

      i = IP.indexOf(".");
      bIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
      System.out.println(bIP.toString());

      i = IP.indexOf(".");
      cIP = IP.substring(0,i);
      IP = IP.substring(i+1,IP.length());
     System.out.println(cIP.toString());

     dIP = IP.substring(0,IP.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);



         if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else {
        //des_ipTextField.transferFocus();
       // des_portTextField.requestFocus();
        //JOptionPane.showConfirmDialog(this,"   Destination IP Wrong !!  ","Error !!",JOptionPane.DEFAULT_OPTION,JOptionPane.ERROR_MESSAGE);
        System.out.println("Message Error");
        des_ipError = true;
        }
   }//try}
  catch (Exception e) {
      //System.out.println(e.getMessage());
      //des_portTextField.requestFocus();
      //JOptionPane.showMessageDialog(this,"   Destination IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
        des_ipError = true;
  }
//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////

  try {
       System.out.println("//////////////////////////////////////////////////////////// section check subNet ///////////////////////////////////////////////////////////////////////////");

     allIP=des_ipTextField.getText().trim();

     i = allIP.indexOf("/");
    if (i>0) {
    subNet = allIP.substring(i+1,allIP.length());
    System.out.println(subNet.toString());
    i = subNet.indexOf(".");

    if (i < 0 && Integer.parseInt(subNet) <= 32 && Integer.parseInt(subNet) >= 0) {
    }
    else {

     i = subNet.indexOf(".");
     aIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(aIP.toString());

     i = subNet.indexOf(".");
     bIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(bIP.toString());

     i = subNet.indexOf(".");
     cIP = subNet.substring(0,i);
     subNet = subNet.substring(i+1,subNet.length());
     System.out.println(cIP.toString());

     dIP = subNet.substring(0,subNet.length());
     System.out.println(dIP.toString());

     iaIP = Integer.parseInt(aIP);
     ibIP = Integer.parseInt(bIP);
     icIP = Integer.parseInt(cIP);
     idIP = Integer.parseInt(dIP);


       if (( iaIP <= 255 ) && (ibIP <=  255) && ( icIP <= 255 ) && (idIP <=  255)) {
            }
        else  {
//        des_ipTextField.transferFocus();
    //    des_portTextField.requestFocus();
  //      JOptionPane.showMessageDialog(this,"   Destination IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
//        System.out.println("Message Error");
              des_ipError = true;
        }


 }
 }
 else {
  }
   }
  catch (Exception e) {
      System.out.println(e.getMessage());
      //des_portTextField.requestFocus();
//      des_ipTextField.transferFocus();
      //JOptionPane.showMessageDialog(this,"   Destication IP Wrong !!  ","Error !!",JOptionPane.ERROR_MESSAGE);
    //  errorfield = true;
      des_ipError = true;
  }

  }// end if()
  }
//////////////////////////////////////////////////////////// End section check IP ///////////////////////////////////////////////////////////////////////////
  } //end checkIP
 public void checkSrcPort() {
    String src_port,min_port,max_port;
    int port,port1,port2,i;

    src_portError = false;

    src_port = src_portTextField.getText().trim();

  if(!src_port.equalsIgnoreCase("ANY")) {

    i = src_port.indexOf(":");
    if (i>0) {
    min_port = src_port.substring(0,i);
    System.out.println("min_port before"+min_port);
    min_port = min_port.trim();
    System.out.println("min_port after"+min_port);

    max_port = src_port.substring(i+1,src_port.length());
    System.out.println("max_port before"+max_port);
    max_port = max_port.trim();
    System.out.println("max_port after"+max_port);


 if (src_portTextField.getText().trim().length() != 0) {
  try {
//     port = Integer.parseInt(src_portTextField.getText().trim());
       port1 = Integer.parseInt(min_port);
       port2 = Integer.parseInt(max_port);

     if (port1 > 65535 || port2 >65535)
      {
        //src_deviceTextField.requestFocus();
      //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
//        System.out.println("Error !!");
        src_portError = true;
      }

     }
  catch(Exception e){
//      src_portTextField.transferFocus();
  //    src_deviceTextField.requestFocus();
    //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      src_portError = true;
    }
  }

  }//if(i>0)
  else {

    if (src_portTextField.getText().trim().length() != 0) {
  try {
     port = Integer.parseInt(src_portTextField.getText().trim());
      if (port > 65535)
      {
     //  des_deviceTextField.requestFocus();
       //JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
       src_portError = true;
      }
     }
  catch(Exception e){
    //des_portTextField.transferFocus();
   // des_deviceTextField.requestFocus();
 //   JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      src_portError = true;
  }
  }
  }//else if(i>0)

  }

 }// end src_port

 public void checkDesPort() {
    String des_port,min_port,max_port;
    int port,port1,port2,i;

    des_portError = false;

    des_port = des_portTextField.getText().trim();

    if(!des_port.equalsIgnoreCase("ANY")) {

    i = des_port.indexOf(":");
    if (i>0) {
    min_port = des_port.substring(0,i);
    System.out.println("min_port before"+min_port);
    min_port = min_port.trim();
    System.out.println("min_port after"+min_port);

    max_port = des_port.substring(i+1,des_port.length());
    System.out.println("max_port before"+max_port);
    max_port = max_port.trim();
    System.out.println("max_port after"+max_port);


 if (des_portTextField.getText().trim().length() != 0) {
  try {
//     port = Integer.parseInt(src_portTextField.getText().trim());
       port1 = Integer.parseInt(min_port);
       port2 = Integer.parseInt(max_port);

     if (port1 > 65535 || port2 >65535)
      {
        //src_deviceTextField.requestFocus();
      //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
//        System.out.println("Error !!");
          des_portError = true;
      }

     }
  catch(Exception e){
//      src_portTextField.transferFocus();
  //    src_deviceTextField.requestFocus();
    //  JOptionPane.showMessageDialog(this,"  Source Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      des_portError = true;
    }
  }

  }//if(i>0)
  else {

    if (des_portTextField.getText().trim().length() != 0) {
  try {
     port = Integer.parseInt(des_portTextField.getText().trim());
      if (port > 65535)
      {
     //  des_deviceTextField.requestFocus();
       //JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
       des_portError = true;
      }
     }
  catch(Exception e){
    //des_portTextField.transferFocus();
   // des_deviceTextField.requestFocus();
 //   JOptionPane.showMessageDialog(this,"  Destination Port Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
      System.out.println("Error !!");
      des_portError = true;
  }
  }
  }//else if(i>0)

  }

 }// end src_port
 public void checkSrcDevice() {
      int ieth,ippp,index=0;
      String  device,num="";

      src_deviceError = false;

   if(!src_deviceTextField.getText().trim().equalsIgnoreCase("ANY")) {

   if(src_deviceTextField.getText().trim().length() != 0){

       device = src_deviceTextField.getText().trim();

      // System.out.println("device.substring(0,2) :"+device.substring(0,2));
      // System.out.println("device.substring(0,3) :"+device.substring(0,3));

      if (device.length() > 2) {

      if ( ! (device.substring(0,3).equals("eth")) && !(device.substring(0,3).equals("ppp")) ) {
        //src_deviceTextField.transferFocus();
       // des_ipTextField.requestFocus();
        //JOptionPane.showMessageDialog(this,"  Source Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
          src_deviceError = true;
      }
       else {

          if (device.substring(0,3).equals("eth") ) {
              num = device.substring(3,device.length());
              System.out.println("eth : "+num);
             }
          else if(device.substring(0,3).equals("ppp") ) {
              num = device.substring(3,device.length());
              System.out.println("ppp : "+num);
            }
        try {
            int deviceno = Integer.parseInt(num);
          }
        catch(Exception e){
            //src_deviceTextField.transferFocus();
//            des_ipTextField.requestFocus();
  //          JOptionPane.showMessageDialog(this,"  Source Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
            src_deviceError = true;
        }
      }
      }
      else if( !(device.length() == 2 && device.equals("lo"))) {
//           des_ipTextField.requestFocus();
  //         JOptionPane.showMessageDialog(this,"  Source Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
    //       errorfield = true;
           src_deviceError = true;
      }
    }
    }
 }

 public void checkDesDevice() {
      int ieth,ippp,index=0;
      String  device,num="";


    des_deviceError = false;

    if(!des_deviceTextField.getText().trim().equalsIgnoreCase("ANY")) {

    if(des_deviceTextField.getText().trim().length() != 0){

       device = des_deviceTextField.getText().trim();

       //System.out.println("device.substring(0,2) :"+device.substring(0,2));
      // System.out.println("device.substring(0,3) :"+device.substring(0,3));

      if (device.length() > 2) {

      if ( ! (device.substring(0,3).equals("eth")) && !(device.substring(0,3).equals("ppp")) ) {
        //des_deviceTextField.transferFocus();
        //src_ipTextField.requestFocus();
        //JOptionPane.showMessageDialog(this,"  Destination Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
        //errorfield = true;
        des_deviceError = true;

      }
       else {

          if (device.substring(0,3).equals("eth")) {
              num = device.substring(3,device.length());
              System.out.println("eth : "+num);
             }
          else if(device.substring(0,3).equals("ppp")) {
              num = device.substring(3,device.length());
              System.out.println("ppp : "+num);
            }

        try {
            int deviceno = Integer.parseInt(num);
          }
        catch(Exception e){
//            src_ipTextField.requestFocus();
  //          JOptionPane.showMessageDialog(this,"  Destination Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
          des_deviceError = true;
       }

        }
      }

      else if (!(device.equals("lo") && device.length() == 2)){
//           src_ipTextField.requestFocus();
  //         JOptionPane.showMessageDialog(this,"  Destination Device Wrong !! ","Error !!",JOptionPane.ERROR_MESSAGE);
    //       errorfield = true;
            des_deviceError = true;
      }
     }
    }
 }

  class clickedOk implements ActionListener  {
    public void actionPerformed(ActionEvent e) {

        checkSrcIP();
        checkSrcPort();
        checkSrcDevice();
        checkDesIP();
        checkDesPort();
        checkDesDevice();
        checkdefinevar();

    if (!(src_ipError || src_portError || src_deviceError || des_ipError || des_portError || des_deviceError))
       {
         updateRecord();
         Frame2.tabbedPaneMain.setSelectedIndex(0);
         Frame2.tabbedPaneMain.setEnabledAt(0,true);
         Frame2.tabbedPaneMain.setEnabledAt(1,false);
         src_ipError = false;
         src_portError = false;
         src_deviceError = false;
         des_ipError = false;
         des_portError = false;
         des_deviceError = false;
       }
     else
          new SearchUpdateError();

        }
  }

  class clickedCancel implements ActionListener {
    public void actionPerformed(ActionEvent e) {
       Frame2.tabbedPaneMain.setEnabledAt(1,false);
       Frame2.tabbedPaneMain.setSelectedIndex(0);
        Frame2.tabbedPaneMain.setEnabledAt(0,true);
    }
  }

  class clickedReset implements ActionListener {
    public void actionPerformed(ActionEvent e) {
          ManagePanel.setEdit();
    }
  }

  public void retriveOldValue() {
                                  System.out.println("retriveOldValue");

                               /*   if (manpanel.ChainOldValue.equals("INPUT"))
                                      inputRadioButton.setSelected(true);
                                  else if (manpanel.ChainOldValue.equals("FORWARD"))
                                      outputRadioButton.setSelected(true);
                                  else if(manpanel.ChainOldValue.equals("NAT"))
                                       forwardRadioButton.setSelected(true);
                                */
                                  if (manpanel.notSrcIPOldValue.equals("!"))
                                       notsrcipCheckBox.setSelected(true);
                                  if (manpanel.notSrcPortOldValue.equals("!"))
                                       notsrcportCheckBox.setSelected(true);
                                  if (manpanel.notSrcDeviceOldValue.equals("!"))
                                       notsrcdeviceCheckBox.setSelected(true);

                                  if (manpanel.notDesIPOldValue.equals("!"))
                                       notdesipCheckBox.setSelected(true);
                                  if (manpanel.notDesPortOldValue.equals("!"))
                                       notdesportCheckBox.setSelected(true);
                                  if (manpanel.notDesDeviceOldValue.equals("!"))
                                       notdesdeviceCheckBox.setSelected(true);

                                  src_ipTextField.setText(manpanel.src_IPOldValue);
                                  src_portTextField.setText(manpanel.src_PortOldValue);
                                  src_deviceTextField.setText(manpanel.src_DeviceOldValue);
                                  des_ipTextField.setText(manpanel.des_IPOldValue);
                                  des_portTextField.setText(manpanel.des_PortOldValue);
                                  des_deviceTextField.setText(manpanel.des_DeviceOldValue);

                                 if (manpanel.ProtocalOldValue.equals("TCP"))
                                       protocalComboBox.setSelectedIndex(0);
                                  if (manpanel.notDesPortOldValue.equals("UDP"))
                                        protocalComboBox.setSelectedIndex(1);
                                  if (manpanel.notDesDeviceOldValue.equals("ICMP"))
                                        protocalComboBox.setSelectedIndex(2);

                                 if (manpanel.ActionOldValue.equals("ACCEPT"))
                                       actionComboBox.setSelectedIndex(0);
                                  if (manpanel.notDesPortOldValue.equals("DROP"))
                                        actionComboBox.setSelectedIndex(1);
                                  if (manpanel.notDesDeviceOldValue.equals("REJECT"))
                                        actionComboBox.setSelectedIndex(2);

                                  System.out.println("retriveOldValue");
  }

    public void setDBPanel(String TableStruc[][], String Table, String Sql, String Url, String User, String Password, String title) {
	fieldinfo = TableStruc;
	tableName = Table;
	retriveSQL = Sql;
	url = Url;
	user = User;
	password = Password;

	db = new DBUtil();
	refreshDB();
	System.out.println("setDBPanel");
  }

    public void refreshDB() {
	if (con!=null)
                           db.Close();
	con = db.Establish();
	rs = db.SQLRetrive(retriveSQL);
	  try {
	      //  rs.last();
		  int count=0;
			while(rs.next()){
					count++;
			}
//			numberOfRecord = rs.getRow();
			numberOfRecord = count;
	  //      rs.first();
                                } catch (SQLException ex) {
	       System.out.println(ex.getMessage());
	}
      }



  public void checkdefinevar() {
         String SQL="",Name,Value,Type,Comment;

         SQL = "SELECT * FROM DefineVar order by ID";
         rsDefineVar = db.SQLRetrive(SQL);
    try {
          rsDefineVar.first();
             while(rsDefineVar.next()) {
                  rsDefineVar.previous();
                  Name = rsDefineVar.getString("Name");
                  Type = rsDefineVar.getString("Type");

         if(Type.equalsIgnoreCase("IP"))
         {
          if(Name.equalsIgnoreCase(src_ipTextField.getText().trim()))
             {
                 src_ipError = false;
             }
          if(Name.equalsIgnoreCase(des_ipTextField.getText().trim()))
             {
                 des_ipError = false;
             }
          }
          else if(Type.equalsIgnoreCase("Port"))
          {
           if(Name.equalsIgnoreCase(src_portTextField.getText().trim()))
            {
                  src_portError = false;
            }
           if(Name.equalsIgnoreCase(des_portTextField.getText().trim()))
            {
                  des_portError = false;
            }
          }
          else if(Type.equalsIgnoreCase("Device"))
          {
            if(Name.equalsIgnoreCase(src_deviceTextField.getText().trim()))
            {
                  src_deviceError = false;
            }
           if(Name.equalsIgnoreCase(des_deviceTextField.getText().trim()))
            {
                  des_deviceError = false;
            }

          }

                  rsDefineVar.next();
             }//end while

            Name = rsDefineVar.getString("Name");
            Type = rsDefineVar.getString("Type");

         if(Type.equalsIgnoreCase("IP"))
         {
          if(Name.equalsIgnoreCase(src_ipTextField.getText().trim()))
             {
                 src_ipError = false;
             }
          if(Name.equalsIgnoreCase(des_ipTextField.getText().trim()))
             {
                 des_ipError = false;
             }
          }
          else if(Type.equalsIgnoreCase("Port"))
          {
           if(Name.equalsIgnoreCase(src_portTextField.getText().trim()))
            {
                  src_portError = false;
            }
           if(Name.equalsIgnoreCase(des_portTextField.getText().trim()))
            {
                  des_portError = false;
            }
          }
          else if(Type.equalsIgnoreCase("Device"))
          {
            if(Name.equalsIgnoreCase(src_deviceTextField.getText().trim()))
            {
                  src_deviceError = false;
            }
           if(Name.equalsIgnoreCase(des_deviceTextField.getText().trim()))
            {
                  des_deviceError = false;
            }

          }

        }
        catch(Exception ex){

        }


  }//end check

    public void updateRecord() {
      String SQL, field = "", value = "",stringPK="";
      String src_ip="",notprotocol,src_port="",src_device="",des_ip="",des_port="",des_device="";
      String chainValue = "",notsrcipCB="",notsrcportCB="",notsrcdeviceCB="",notdesipCB="",notdesportCB="",notdesdeviceCB="";
              int  ID=0,RuleNoValue=0;
              String temp;
      int ReturnRowSelect=0;

        System.out.println("use updateRecord");

    if (status.equals("ADD")) {
                    try {
                      rs.last();
                      }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }

    SQL = "INSERT INTO " + tableName ;
    for(int i=1; i < fieldinfo.length; i++) {
        field = field + ", " + fieldinfo[i][0];
       }

         if (src_ipTextField.getText().trim().length()== 0)
              src_ip = "ANY";
        else
              src_ip = src_ipTextField.getText().trim().toUpperCase();

         if (src_portTextField.getText().trim().length() == 0)
              src_port = "ANY";
        else
              src_port = src_portTextField.getText().trim().toUpperCase();

         if (src_deviceTextField.getText().trim().length() == 0)
              src_device = "ANY";
         else
              src_device = src_deviceTextField.getText().trim().toUpperCase();

         if (des_ipTextField.getText().trim().length() == 0)
              des_ip = "ANY";
         else
              des_ip = des_ipTextField.getText().trim().toUpperCase();

         if (des_portTextField.getText().trim().length()== 0)
              des_port = "ANY";
         else
             des_port = des_portTextField.getText().trim().toUpperCase();

         if (des_deviceTextField.getText().length()== 0)
              des_device = "ANY";
        else
              des_device = des_deviceTextField.getText().trim().toUpperCase();


         if ( notsrcipCheckBox.isSelected() == true )
              notsrcipCB = "NO";
         else notsrcipCB = "YES";
         if ( notsrcportCheckBox.isSelected() == true)
              notsrcportCB = "NO";
         else notsrcportCB = "YES";
         if ( notsrcdeviceCheckBox.isSelected() == true)
              notsrcdeviceCB = "NO";
         else notsrcdeviceCB = "YES";

         if ( notdesipCheckBox.isSelected() == true )
              notdesipCB = "NO";
         else notdesipCB = "YES";
         if ( notdesportCheckBox.isSelected() == true)
              notdesportCB = "NO";
         else notdesportCB = "YES";
         if ( notdesdeviceCheckBox.isSelected() == true)
              notdesdeviceCB = "NO";
         else notdesdeviceCB = "YES";

         if(notprotocolCheckBox.isSelected())
              notprotocol = "NO";
         else notprotocol = "YES";

         try {
                rs.last();
           }
         catch(Exception ex) {
                System.out.println(ex.getMessage());
         }


  if(src_device.substring(0,3).equalsIgnoreCase("ppp") || src_device.substring(0,3).equalsIgnoreCase("eth") || src_device.substring(0,2).equalsIgnoreCase("lo")){
          src_device = src_device.toLowerCase();
  }

  if(des_device.substring(0,3).equalsIgnoreCase("ppp") || des_device.substring(0,3).equalsIgnoreCase("eth") || des_device.substring(0,2).equalsIgnoreCase("lo")){
          des_device = des_device.toLowerCase();
  }

     value=value+" '"+chainComboBox.getSelectedItem().toString()+"' , '" + src_ip + "'  , '" +src_port+ "' , '" +src_device+ "' , '" +des_ip+ "' , '" +des_port+ "' , '" +des_device+ "' , '" +protocalNames[protocalComboBox.getSelectedIndex()]+ "'  , '" +actionNames[actionComboBox.getSelectedIndex()]+ "'  , '" +notsrcipCB+ "', '" +notsrcportCB+ "', '" +notsrcdeviceCB+ "', '" +notdesipCB+ "', '" +notdesportCB+ "', '" +notdesdeviceCB+ "' ,'"+notprotocol+"'  ";


      field = field + " ,notprotocal ";
      field = field.substring(1);
      value = value.substring(1);

      SQL = SQL + "(" + field + ") VALUES (" + value + ")";
      db.SQLExecute(SQL);
      System.out.println(SQL);
    }

    if (status.equals("UPDATE")) {

             if(ProtocalSearch.seteditProtocalSearch)
                   ReturnRowSelect = ProtocalSearch.table.getSelectedRow();
             else if(ActionSearch.seteditActionSearch)
                    ReturnRowSelect = ActionSearch.table.getSelectedRow();
             else if(ChainSearch.seteditChainSearch)
                    ReturnRowSelect = ChainSearch.table.getSelectedRow();
             else if(PortSearch.seteditPortSearch)
                    ReturnRowSelect = PortSearch.table.getSelectedRow();
             else if(IPSearch.seteditIPSearch)
                    ReturnRowSelect = IPSearch.table.getSelectedRow();

                System.out.println("ReturnRowSelect"+ReturnRowSelect);
                    try {
                      rs.first();
                    for (int i=0;i<ReturnRowSelect;i++) {
                      rs.next();
                     }
                       ID = rs.getInt("ID");
                    }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }


         if (src_ipTextField.getText().trim().length()== 0)
              src_ip = "ANY";
        else
              src_ip = src_ipTextField.getText().trim().toUpperCase();

         if (src_portTextField.getText().trim().length() == 0)
              src_port = "ANY";
        else
              src_port = src_portTextField.getText().trim().toUpperCase();

         if (src_deviceTextField.getText().trim().length() == 0)
              src_device = "ANY";
         else
              src_device = src_deviceTextField.getText().trim().toUpperCase();

         if (des_ipTextField.getText().trim().length() == 0)
              des_ip = "ANY";
         else
              des_ip = des_ipTextField.getText().trim().toUpperCase();

         if (des_portTextField.getText().trim().length()== 0)
              des_port = "ANY";
         else
             des_port = des_portTextField.getText().trim().toUpperCase();

         if (des_deviceTextField.getText().trim().length()== 0)
              des_device = "ANY";
        else
              des_device = des_deviceTextField.getText().trim().toUpperCase();

         if ( notsrcipCheckBox.isSelected() == true )
              notsrcipCB = "NO";
         else notsrcipCB = "YES";
         if ( notsrcportCheckBox.isSelected() == true)
              notsrcportCB = "NO";
         else notsrcportCB = "YES";
         if ( notsrcdeviceCheckBox.isSelected() == true)
              notsrcdeviceCB = "NO";
         else notsrcdeviceCB = "YES";

         if ( notdesipCheckBox.isSelected() == true )
              notdesipCB = "NO";
         else notdesipCB = "YES";
         if ( notdesportCheckBox.isSelected() == true)
              notdesportCB = "NO";
         else notdesportCB = "YES";
         if ( notdesdeviceCheckBox.isSelected() == true)
              notdesdeviceCB = "NO";
         else notdesdeviceCB = "YES";

         if(notprotocolCheckBox.isSelected())
              notprotocol = "NO";
         else notprotocol = "YES";




  if(src_device.substring(0,3).equals("PPP") || src_device.substring(0,3).equals("ETH") || src_device.substring(0,2).equals("LO")){
          src_device = src_device.toLowerCase();
  }

  if(des_device.substring(0,3).equals("PPP") || des_device.substring(0,3).equals("ETH") || des_device.substring(0,2).equals("LO")){
          des_port = des_device.toLowerCase();
  }

              SQL = "UPDATE " + tableName + " SET";

              field = field + " notprotocal = '"+notprotocol+"',notSrcIP = '"+notsrcipCB+"'  , notSrcPort = '" +notsrcportCB+ "',notSrcDevice='"+notsrcdeviceCB+"'      ";
              field = field + ", notDesIP = '"+notdesipCB+ "'  , notDesPort='"+notdesportCB+"',notDesDevice='"+notdesdeviceCB+"'   ";
              field = field + ", src_IP = '" +src_ip+ "'  , src_Port = '" +src_port+ "'   , src_Device = '" +src_device+ "'  , des_IP = '" +des_ip+ "'  , des_Port = '" +des_port+ "' , des_Device = '" +des_device+ "'      ";
              field = field + ", Action = '"+actionComboBox.getSelectedItem().toString()+"'   , Protocal = '" +protocalNames[protocalComboBox.getSelectedIndex()]+ "',Chain = '"+chainComboBox.getSelectedItem().toString()+"'   ";

          stringPK = " ID = "+ID+" ";
          SQL = SQL + field + "WHERE"+stringPK;

          db.SQLExecute(SQL);
          System.out.println(SQL);
      }
                    try {
                      ManagePanel.rs.last();
                      }
                    catch(SQLException ex) {
                      System.out.println(ex.getMessage());
                     }

          ProtocalSearch.seteditProtocalSearch = false;
          ActionSearch.seteditActionSearch = false;
          ChainSearch.seteditChainSearch = false;
          PortSearch.seteditPortSearch = false;
          IPSearch.seteditIPSearch = false;


  } //end updateRecord()
 }//end class