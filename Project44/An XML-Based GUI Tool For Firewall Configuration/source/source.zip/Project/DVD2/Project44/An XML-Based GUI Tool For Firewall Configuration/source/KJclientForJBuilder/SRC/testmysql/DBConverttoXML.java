//package main;
package testmysql;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.lang.*;
import java.io.*;


public class DBConverttoXML extends JPanel {
    // Database Component
      DBUtil db;
      Connection con;
      ResultSet rs;
      String url;
      String user;
      String password;
      String retriveSQL;
      String table;

  public static int pgstatus=0;
  public static int RowCount=0;
  public static int value=0;
  int NoLastRow;
  String displayRule="";
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JButton toXMLButton = new JButton();

  public DBConverttoXML() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {

            String url = "jdbc:odbc:dbConfige";
            String user = "admin";
            String password = "";
            String SQL = "SELECT * FROM Confige";
            String table = "Confige";

            // Database section
            db = new DBUtil();
            con = db.Establish();

    this.setLayout(borderLayout1);
    toXMLButton.setBackground(new Color(236, 233, 230));
    toXMLButton.setPreferredSize(new Dimension(80, 27));
    toXMLButton.setText("toXML");
    this.setBackground(Color.lightGray);
    this.setOpaque(false);
    jPanel1.setBackground(new Color(236, 233, 230));
    jPanel2.setBackground(new Color(236, 233, 230));
    this.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel2, null);
    jPanel2.add(toXMLButton, null);

      toXMLButton.addActionListener(new clickedConverttoXML());
  }


   class clickedConverttoXML implements ActionListener {
      public void actionPerformed(ActionEvent e) {

           value=0;
           new ProgressDialog();
           String SQL="",Id,Chain,Action,src_IP,src_Port,src_Device,des_IP,des_Port,des_Device,Protocal;
           String notSrcIP,notSrcPort,notSrcDevice,notDesIP,notDesPort,notDesDevice;


           displayRule+="<?xml version=\"1.0\" standalone=\"yes\"?>\n";
           displayRule+="<FIREWALL_CONFIGE>\n";
            int no;
           SQL="SELECT * FROM Confige order by ID";
              try {


                      FileWriter fout = new FileWriter("firewallconfige.xml");
                      rs = db.SQLRetrive(SQL);
                      NoLastRow = rs.getRow();

                     while (rs.next()){

	                          Id = rs.getString("ID");
                                  Chain = rs.getString("Chain");
                                  src_IP = rs.getString("src_IP");
                                  src_Port = rs.getString("src_Port");
                                  src_Device = rs.getString("src_Device");
                                  des_IP = rs.getString("des_IP");
                                  des_Port = rs.getString("des_Port");
                                  des_Device = rs.getString("des_Device");
                                  Protocal = rs.getString("Protocal");
                                  Action = rs.getString("Action");

                                  notSrcIP = rs.getString("notSrcIP");
                                  notSrcPort = rs.getString("notSrcPort");
                                  notSrcDevice = rs.getString("notSrcDevice");
                                  notDesIP = rs.getString("notDesIP");
                                  notDesPort = rs.getString("notDesPort");
                                  notDesDevice = rs.getString("notDesDevice");

                            //GENERATE firewallconfige.xml
                            displayRule += "<RULE>\n"+
                            "<CHAIN>'"+Chain+"'</CHAIN>"+
                            "<SRC>\n"+
                                "<NOT_SRC_IP>'"+notSrcIP+"'</NOT_SRC_IP>\n"+
                                "<NOT_SRC_PORT>'"+notSrcPort+"'</NOT_SRC_PORT>\n"+
                                "<NOT_SRC_DEVICE>'"+notSrcDevice+"'</NOT_SRC_DEVICE>\n"+
                                "<SRC_IP>'"+src_IP+"'</SRC_IP>\n"+
                                "<SRC_PORT>'"+src_Port+"'</SRC_PORT>\n"+
                                "<SRC_DEVICE>'"+src_Device+"'</SRC_DEVICE>\n"+
                            "</SRC>\n"+
                            "<DES>"+
                                "<NOT_DES_IP>'"+notDesIP+"'</NOT_DES_IP>\n"+
                                "<NOT_DES_PORT>'"+notDesPort+"'</NOT_DES_PORT>\n"+
                                "<NOT_DES_DEVICE>'"+notDesDevice+"'</NOT_DES_DEVICE>\n"+
                                "<DES_IP>'"+des_IP+"'</DES_IP>\n"+
                                "<DES_PORT>'"+des_Port+"'</DES_PORT>\n"+
                                "<DES_DEVICE>'"+des_Device+"'</DES_DEVICE>\n"+
                            "</DES>\n"+
                            "<PROTOCAL>'"+Protocal+"'</PROTOCAL>\n"+
                            "<ACTION>'"+Action+"'</ACTION>\n"+
                             "</RULE>\n";

                           //value=value+100/RowCount;
                           value=value+1;
                           pgBar();

                           rs.next();

                    }

                      displayRule  = displayRule+"</FIREWALL_CONFIGE>";

                            fout.write(displayRule);
                            fout.write('\n');

                             rs.close();
                             fout.close();
              }
                           catch(SQLException ex) {
                               System.out.println(ex.getMessage());
                       }

                        catch (IOException ie) {
                              System.out.println(ie.getMessage());
                           }
          System.out.println("Complete generate XML");
   }//end actionPerformed
 }//end clickedConverttoXML

        void pgBar() {

                                        //  value=0;
                                        //int min = value+100/RowCount; int max=RowCount-2;

                                        int min = 0; int max=NoLastRow;


                                        ProgressDialog.progressBar.setValue(min);
					ProgressDialog.progressBar.setMinimum(min);
					ProgressDialog.progressBar.setMaximum(max);
                                        System.out.println(RowCount);
					//sklfor (value=0; value<=RowCount; value++) {
						try {
							new Robot().delay(100);

						} catch (Exception ex) {
							// Ignore Exception
						}

                                System.out.println(value);
                                ProgressDialog.progressBar.setValue(value);
	                	ProgressDialog.progressBar.paint(ProgressDialog.progressBar.getGraphics());
                                ProgressDialog.messageLabel.setText(displayRule);
                                ProgressDialog.messageLabel.setText("Sucesssfull !!!");




      //}

        }/////end pgBar


}// end class



