package tumltool;

import java.awt.Graphics;

public class FigNaryLine extends FigLine {
  FigNary myNary;
  FigClass myClass;
  String mySide;

  public FigNaryLine(FigNary fNary,FigClass fClass,String side) {
    myNary = fNary;
    myClass = fClass;
    mySide = side;
    if (side.compareTo("W") == 0)
      super.setBeginCordinate(fNary.getX(),fNary.getY()+15);
    if (side.compareTo("E") == 0)
      super.setBeginCordinate(fNary.getX()+31,fNary.getY()+16);
    if (side.compareTo("S") == 0)
      super.setBeginCordinate(fNary.getX()+15,fNary.getY()+30);
    super.setEndCordinate(fClass.getCX(),fClass.getCY());
    super.setSizeSRC(1,1);
    super.setSizeDES(fClass.getWidth(),fClass.getHeight());
  }

  public void paintComponent(Graphics g){
    super.paintComponent(g);
  }

  public void setBeginCordinate(int x, int y){
    if (mySide.compareTo("W") == 0)
      super.setBeginCordinate(myNary.getX(),myNary.getY()+15);
    if (mySide.compareTo("E") == 0)
      super.setBeginCordinate(myNary.getX()+31,myNary.getY()+16);
    if (mySide.compareTo("S") == 0)
      super.setBeginCordinate(myNary.getX()+15,myNary.getY()+30);
  }

  public void setNary(FigNary fNary){
    myNary = fNary;
  }

  public FigNary getNary(){
    return myNary;
  }

  public void setNaryClass(FigClass fClass){
    myClass = fClass;
  }

  public FigClass getNaryClass(){
    return myClass;
  }
}