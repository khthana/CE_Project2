package tumltool;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class PopupMenuAggregation extends JPopupMenu {
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  ImageIcon imageProperties;
  ImageIcon imageDelete;
  PropertiesAggregation rChoosed;
  Vector vAggregation;
  int indexAggregation;
  JTextArea DrawArea;

  public PopupMenuAggregation() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    imageProperties = new ImageIcon("Properties.gif");
    imageDelete     = new ImageIcon("Delete.gif");

    jMenuItem1.setIcon(imageProperties);
    jMenuItem1.setText("Properties");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem1_actionPerformed(e);
      }
    });
    jMenuItem2.setIcon(imageDelete);
    jMenuItem2.setText("Delete");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem2_actionPerformed(e);
      }
    });
    this.add(jMenuItem1);
    this.addSeparator();
    this.add(jMenuItem2);
  }

  public void setAll(JTextArea drawArea,Vector V,int index,PropertiesAggregation pAggregation) {
    DrawArea = drawArea;
    vAggregation = V;
    indexAggregation = index;
    rChoosed = pAggregation;
  }

  void jMenuItem1_actionPerformed(ActionEvent e) {
    rChoosed.show();
  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    FigAggregationLine deleteAggregation = (FigAggregationLine) vAggregation.elementAt(indexAggregation);
    DrawArea.remove(deleteAggregation);
    DrawArea.repaint();
    vAggregation.removeElementAt(indexAggregation);
  }
}