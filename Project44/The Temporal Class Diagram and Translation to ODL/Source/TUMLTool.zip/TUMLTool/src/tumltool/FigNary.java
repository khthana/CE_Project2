package tumltool;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import COM.intersys.objects.*;

public class FigNary extends JPanel {
  String  roleName = "";
  String  granularity = "";
  int     indexTimeType = 0;
  String  timestampType = "Period";

  int width   = 31;
  int height  = 31;
  int x = 0;
  int y = 0;
  int[] xPoint = {15,30,15,0};
  int[] yPoint = {0,15,30,15};
  Color bgColor = new Color(255,255,204);
  Image ttRtIcon;
  Image vtRtIcon;
  Image btRtIcon;
  FigClass  fClass = null;
  FigClass  sClass = null;
  FigClass  tClass = null;
  Oid oid = null;

  public FigNary(int X,int Y) {
    try {
      ttRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/ttIcon.gif"));
      vtRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vtIcon.gif"));
      btRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/btIcon.gif"));
      x = X;
      y = Y;
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public FigNary() {
    try {
      ttRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/ttIcon.gif"));
      vtRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vtIcon.gif"));
      btRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/btIcon.gif"));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void paintComponent(Graphics g){
    this.setBounds(x,y,width,height);
    g.setColor(bgColor);
    g.fillPolygon(xPoint,yPoint,4);
    g.setColor(Color.black);
    g.drawPolygon(xPoint,yPoint,4);
    if (indexTimeType == 1)
      g.drawImage(vtRtIcon,8,8,this);
    if (indexTimeType == 2)
      g.drawImage(ttRtIcon,8,8,this);
    if (indexTimeType == 3)
      g.drawImage(btRtIcon,8,8,this);
  }

  public void setRoleName(String RoleName) {
    roleName = RoleName;
  }

  public String getRoleName(){
    return roleName;
  }

  public void setGranularity(String Granularity){
    granularity = Granularity;
  }

  public String getGranularity(){
    return granularity;
  }

  public void setIndexTimeType(int i){
    indexTimeType = i;
  }

  public int getIndexTimeType(){
    return indexTimeType;
  }

  public void setTimestampType(String t){
    timestampType = t;
  }

  public String getTimestampType(){
    return timestampType;
  }

  public void setX(int X){
    x = X;
  }

  public void setY(int Y){
    y = Y;
  }

  public int getX(){
    return x;
  }

  public int getY(){
    return y;
  }

  public void setFClass(FigClass FClass){
    fClass = FClass;
  }

  public void setSClass(FigClass SClass){
    sClass = SClass;
  }

  public void setTClass(FigClass TClass){
    tClass = TClass;
  }

  public FigClass getFClass() {
    return fClass;
  }

  public FigClass getSClass() {
    return sClass;
  }

  public FigClass getTClass() {
    return tClass;
  }

  public void setOid(Oid id) {
    oid = id;
  }

  public Oid getOid() {
    return oid;
  }

  public void setBounds() {
    this.paintComponent(this.getGraphics());
  }

  /*
          |---------|
          |    0    |
          |3       1|
          |    2    |
          |---------|
  */
  public boolean checkArea(int cx,int cy){
    // vector 1
    int tx = 0 + xPoint[0] - xPoint[1];
    int ty = 0 + yPoint[0] - yPoint[1];
    if(!crossProduct(tx,ty,cx -( x + xPoint[1]),cy -( y + yPoint[1]))) return false;
    // vector 2
    tx = 0 + xPoint[3] - xPoint[0];
    ty = 0 + yPoint[3] - yPoint[0];
//   if(!crossProduct(cx - xPoint[0],cy - yPoint[0],tx,ty)) return false;
    if(!crossProduct(tx,ty,cx -( x + xPoint[0]),cy -(y + yPoint[0]))) return false;
    // vector 3
    tx = 0 + xPoint[2] - xPoint[3];
    ty = 0 + yPoint[2] - yPoint[3];
//    if(!crossProduct(cx - xPoint[3],cy - yPoint[3],tx,ty)) return false;
    if(!crossProduct(tx,ty,cx -( x + xPoint[3]),cy -( y + yPoint[3]))) return false;
    // vector 4
    tx = 0 + xPoint[1] - xPoint[2];
    ty = 0 + yPoint[1] - yPoint[2];
//    if(!crossProduct(cx - xPoint[2],cy - yPoint[2],tx,ty)) return false;
    if(!crossProduct(tx,ty,cx -( x + xPoint[2]),cy -( y + yPoint[2]))) return false;
    return true;
  }

  public boolean crossProduct(int v1I,int v1J,int v2I,int v2J){
      if ((-v1I*v2J + v1J*v2I) >= 0)    // Inverse from v1I*v2J - v1J*v2I
          return true;                  // because Y axis is not normal form
      return false;
  }

}