package tumltool;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;

public class PopupMenuTernary extends JPopupMenu {
  JMenuItem jMenuItem2 = new JMenuItem();
  ImageIcon imageProperties;
  ImageIcon imageDelete;
  Vector vTernary;
  Vector vFternary;
  Vector vSternary;
  Vector vTternary;
  int indexTernary;
  JTextArea DrawArea;

  public PopupMenuTernary() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    imageProperties = new ImageIcon("Properties.gif");
    imageDelete     = new ImageIcon("Delete.gif");
    jMenuItem2.setIcon(imageDelete);
    jMenuItem2.setText("Delete");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem2_actionPerformed(e);
      }
    });
    this.add(jMenuItem2);
  }

  public void setAll(JTextArea drawArea,Vector V,Vector F,Vector S,Vector T,int index) {
    DrawArea = drawArea;
    vTernary = V;
    vFternary = F;
    vSternary = S;
    vTternary = T;
    indexTernary = index;
  }


  void jMenuItem2_actionPerformed(ActionEvent e) {
    FigNary deleteTernary = (FigNary) vTernary.elementAt(indexTernary);
    FigNaryLine fLine = findTernaryLine(deleteTernary,vFternary);
    FigNaryLine sLine = findTernaryLine(deleteTernary,vSternary);
    FigNaryLine tLine = findTernaryLine(deleteTernary,vTternary);
    vFternary.removeElement(fLine);
    vSternary.removeElement(sLine);
    vTternary.removeElement(tLine);
    decClassRelation(deleteTernary.getIndexTimeType(),fLine.getNaryClass());
    decClassRelation(deleteTernary.getIndexTimeType(),sLine.getNaryClass());
    decClassRelation(deleteTernary.getIndexTimeType(),tLine.getNaryClass());
    DrawArea.remove(fLine);
    DrawArea.remove(sLine);
    DrawArea.remove(tLine);
    DrawArea.remove(deleteTernary);
    DrawArea.repaint();
    vTernary.removeElementAt(indexTernary);
  }

  private FigNaryLine findTernaryLine(FigNary nary,Vector vNaryline) {
    FigNaryLine naryLine = null;
    int i = 0;
    while (i <= vNaryline.size()) {
      naryLine = (FigNaryLine) vNaryline.elementAt(i);
      if (naryLine.getNary().getOid() == nary.getOid())
        return naryLine;
      i++;
    }
    return naryLine;
  }

  private void decClassRelation(int t,FigClass decClass){
    if (t == 1) {
      decClass.decAssociationVT();
    }
    if (t == 2) {
      decClass.decAssociationTT();
    }
    if (t == 3) {
      decClass.decAssociationBT();
    }
  }
}
