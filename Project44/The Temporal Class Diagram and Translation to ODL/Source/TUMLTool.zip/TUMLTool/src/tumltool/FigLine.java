package tumltool;
import java.awt.Graphics;
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;
import COM.intersys.objects.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FigLine extends JPanel {
  private int arrowWidth = 12;
  private int arrowHeigh = 6;
  private int _srcId;
  private int _desId;
  private int _bx,_by,_ex,_ey;
  protected int _hx,_hy,_tx,_ty;
  private int _widthSRC,_highSRC;
  private int _widthDES,_highDES;
//  boolean bitSrc[] = {false,false,false,false};
  protected int _realX1,_realY1,_realX2,_realY2;
  protected int _areaX1,_areaY1,_areaX2,_areaY2,_areaX3,_areaY3,_areaX4,_areaY4;
  private int _srcArrowHead;
  Oid oid = null;

  public FigLine() {
    _srcArrowHead = 0;
  }

  public void setBeginCordinate(int bx,int by) {
    _bx = bx;
    _by = by;
  }

  public void setEndCordinate(int ex,int ey) {
    _ex = ex;
    _ey = ey;
  }

  public void setSrcID(int src) {
    _srcId = src;
  }

  public int getSrcID() {
    return _srcId;
  }

  public void setDesID(int des) {
    _desId = des;
  }

  public int getDesID() {
    return _desId;
  }

  public void setSizeSRC(int width,int high){
    _widthSRC = width;
    _highSRC = high;
  }

  public void setSizeDES(int width,int high){
    _widthDES = width;
    _highDES = high;
  }

  public void setSrcArrowHead(int type) {
  // 0 = none
  // 1 = triangle
  // 2 = rectangle
    _srcArrowHead = type;
  }

  private int calX(int y) {
    if ((_ex - _bx) == 0)
      return _bx;
    float m = ((float)(_ey - _by)) / ((float)(_ex - _bx));
    int   b = (int) (_by - (m * _bx));
    return (int) ((y - b) / m);
  }

  private int calY(int x) {
    if ((_ey - _by) == 0)
      return _by;
    float m = ((float)(_ey - _by)) / ((float)(_ex - _bx));
    int   b = (int) (_by - (m * _bx));
    return (int) ((m * x) + b);
  }

  public void calculatePointSRC(){
    int xMinSRC = _bx - _widthSRC/2 , xMaxSRC = _bx + _widthSRC/2;
    int yMinSRC = _by + _highSRC/2 , yMaxSRC = _by - _highSRC/2;
    boolean bitSrc[] = {false,false,false,false};

    bitSrc[0] = ((yMaxSRC - _ey) > 0) ? true : false;
    bitSrc[1] = ((_ey - yMinSRC) > 0) ? true : false;
    bitSrc[2] = ((_ex - xMaxSRC) > 0) ? true : false;
    bitSrc[3] = ((xMinSRC - _ex) > 0) ? true : false;

    boolean north[] = {true,false,false,false};
    if ((bitSrc[0] == north[0]) && (bitSrc[1] == north[1]) &&
        (bitSrc[2] == north[2]) && (bitSrc[3] == north[3])) {
      _hx = calX(yMaxSRC);
      _hy = yMaxSRC;
    }

    boolean south[] = {false,true,false,false};
    if ((bitSrc[0] == south[0]) && (bitSrc[1] == south[1]) &&
        (bitSrc[2] == south[3]) && (bitSrc[3] == south[3])) {
      _hx = calX(yMinSRC);
      _hy = yMinSRC;
    }

    boolean east[] = {false,false,true,false};
    if ((bitSrc[0] == east[0]) && (bitSrc[1] == east[1]) &&
        (bitSrc[2] == east[2]) && (bitSrc[3] == east[3])) {
      _hx = xMaxSRC;
      _hy = calY(xMaxSRC);
    }

    boolean west[] = {false,false,false,true};
    if ((bitSrc[0] == west[0]) && (bitSrc[1] == west[1]) &&
        (bitSrc[2] == west[2]) && (bitSrc[3] == west[3])) {
      _hx = xMinSRC;
      _hy = calY(xMinSRC);
    }

    boolean north_west[] = {true,false,false,true};
    if ((bitSrc[0] == north_west[0]) && (bitSrc[1] == north_west[1]) &&
        (bitSrc[2] == north_west[2]) && (bitSrc[3] == north_west[3])) {
      if (calX(yMaxSRC) <= xMinSRC) {
        _hx = xMinSRC;
        _hy = calY(xMinSRC);
      }
      else {
        _hx = calX(yMaxSRC);
        _hy = yMaxSRC;
      }
    }

    boolean north_east[] = {true,false,true,false};
    if ((bitSrc[0] == north_east[0]) && (bitSrc[1] == north_east[1]) &&
        (bitSrc[2] == north_east[2]) && (bitSrc[3] == north_east[3])) {
      if (calX(yMaxSRC) >= xMaxSRC) {
        _hx = xMaxSRC;
        _hy = calY(xMaxSRC);
      }
      else {
        _hx = calX(yMaxSRC);
        _hy = yMaxSRC;
      }
    }
    boolean south_west[] = {false,true,false,true};
    if ((bitSrc[0] == south_west[0]) && (bitSrc[1] == south_west[1]) &&
        (bitSrc[2] == south_west[2]) && (bitSrc[3] == south_west[3])) {
      if (calX(yMinSRC) <= xMinSRC) {
        _hx = xMinSRC;
        _hy = calY(xMinSRC);
      }
      else {
        _hx = calX(yMinSRC);
        _hy = yMinSRC;
      }
    }
    boolean south_east[] = {false,true,true,false};
    if ((bitSrc[0] == south_east[0]) && (bitSrc[1] == south_east[1]) &&
        (bitSrc[2] == south_east[2]) && (bitSrc[3] == south_east[3])) {
      if (calX(yMinSRC) >= xMaxSRC) {
        _hx = xMaxSRC;
        _hy = calY(xMaxSRC);
      }
      else {
        _hx = calX(yMinSRC);
        _hy = yMinSRC;
      }
    }
  }

  public void calculatePointDES(){
    int xMinDES = _ex - _widthDES/2 , xMaxDES = _ex + _widthDES/2;
    int yMinDES = _ey + _highDES/2 , yMaxDES = _ey - _highDES/2;
    boolean bit[] = {false,false,false,false};

    bit[0] = ((yMaxDES - _by) > 0) ? true : false;
    bit[1] = ((_by - yMinDES) > 0) ? true : false;
    bit[2] = ((_bx - xMaxDES) > 0) ? true : false;
    bit[3] = ((xMinDES - _bx) > 0) ? true : false;

    boolean north[] = {true,false,false,false};
    if ((bit[0] == north[0]) && (bit[1] == north[1]) &&
        (bit[2] == north[2]) && (bit[3] == north[3])) {
      _tx = calX(yMaxDES);
      _ty = yMaxDES;
    }

    boolean south[] = {false,true,false,false};
    if ((bit[0] == south[0]) && (bit[1] == south[1]) &&
        (bit[2] == south[3]) && (bit[3] == south[3])) {
      _tx = calX(yMinDES);
      _ty = yMinDES;
    }

    boolean east[] = {false,false,true,false};
    if ((bit[0] == east[0]) && (bit[1] == east[1]) &&
        (bit[2] == east[2]) && (bit[3] == east[3])) {
      _tx = xMaxDES;
      _ty = calY(xMaxDES);
    }

    boolean west[] = {false,false,false,true};
    if ((bit[0] == west[0]) && (bit[1] == west[1]) &&
        (bit[2] == west[2]) && (bit[3] == west[3])) {
      _tx = xMinDES;
      _ty = calY(xMinDES);
    }
    boolean north_west[] = {true,false,false,true};
    if ((bit[0] == north_west[0]) && (bit[1] == north_west[1]) &&
        (bit[2] == north_west[2]) && (bit[3] == north_west[3])) {
      if (calX(yMaxDES) <= xMinDES) {
        _tx = xMinDES;
        _ty = calY(xMinDES);
      }
      else {
        _tx = calX(yMaxDES);
        _ty = yMaxDES;
      }
    }
    boolean north_east[] = {true,false,true,false};
    if ((bit[0] == north_east[0]) && (bit[1] == north_east[1]) &&
        (bit[2] == north_east[2]) && (bit[3] == north_east[3])) {
      if (calX(yMaxDES) >= xMaxDES) {
        _tx = xMaxDES;
        _ty = calY(xMaxDES);
      }
      else {
        _tx = calX(yMaxDES);
        _ty = yMaxDES;
      }
    }
    boolean south_west[] = {false,true,false,true};
    if ((bit[0] == south_west[0]) && (bit[1] == south_west[1]) &&
        (bit[2] == south_west[2]) && (bit[3] == south_west[3])) {
      if (calX(yMinDES) <= xMinDES) {
        _tx = xMinDES;
        _ty = calY(xMinDES);
      }
      else {
        _tx = calX(yMinDES);
        _ty = yMinDES;
      }
    }
    boolean south_east[] = {false,true,true,false};
    if ((bit[0] == south_east[0]) && (bit[1] == south_east[1]) &&
        (bit[2] == south_east[2]) && (bit[3] == south_east[3])) {
      if (calX(yMinDES) >= xMaxDES) {
        _tx = xMaxDES;
        _ty = calY(xMaxDES);
      }
      else {
        _tx = calX(yMinDES);
        _ty = yMinDES;
      }
    }
  }

/*  public void draw(Graphics g) {
    calculatePointSRC();
    calculatePointDES();
    g.drawLine(_hx,_hy,_tx,_ty);
  }
*/
  public void paintComponent(Graphics g){
    calculatePointSRC();
    calculatePointDES();
    g.setColor(Color.black);

    if (_tx >_hx) {
      if (_ty > _hy) {
        if (_tx - _hx < 48) {
          _realX1 = 0+(int)((48-(_tx-_hx))/2); _realY1 = 0;
          _realX2 = 48-(int)((48-(_tx-_hx))/2); _realY2 = _ty-_hy;
          g.drawLine(0+(int)((48-(_tx-_hx))/2),0,48-(int)((48-(_tx-_hx))/2),_ty-_hy);
          this.setBounds(_hx-(int)((48-(_tx-_hx))/2),_hy,48,_ty-_hy+1);
        }
        if (_ty - _hy < 48) {
          _realX1 = 0; _realY1 = 0+(int)((48-(_ty-_hy))/2);
          _realX2 = _tx-_hx; _realY2 = 48-(int)((48-(_ty-_hy))/2);
          g.drawLine(0,0+(int)((48-(_ty-_hy))/2),_tx-_hx,48-(int)((48-(_ty-_hy))/2));
          this.setBounds(_hx,_hy-(int)((48-(_ty-_hy))/2),_tx-_hx+1,48);
        }
        if ((_tx - _hx >= 48) && (_ty - _hy >= 48)) {
          _realX1 = 0; _realY1 = 0;
          _realX2 = _tx-_hx; _realY2 = _ty-_hy;
          g.drawLine(0,0,_tx-_hx,_ty-_hy);
          this.setBounds(_hx,_hy,_tx-_hx+1,_ty-_hy+1);
        }
      }
      if (_hy > _ty) {
        if (_hy - _ty < 48) {
          _realX1 = 0; _realY1 = 48-(int)((48-(_hy-_ty))/2);
          _realX2 = _tx-_hx; _realY2 = 0+(int)((48-(_hy-_ty))/2);
          g.drawLine(0,48-(int)((48-(_hy-_ty))/2),_tx-_hx,0+(int)((48-(_hy-_ty))/2));
          this.setBounds(_hx,_ty-(int)((48-(_hy-_ty))/2),_tx-_hx+1,48);
        }
        if (_tx - _hx < 48) {
          _realX1 = 0+(int)((48-(_tx-_hx))/2); _realY1 = _hy-_ty;
          _realX2 = 48-(int)((48-(_tx-_hx))/2); _realY2 = 0;
          g.drawLine(0+(int)((48-(_tx-_hx))/2),_hy-_ty,48-(int)((48-(_tx-_hx))/2),0);
          this.setBounds(_hx-(int)((48-(_tx-_hx))/2),_ty,48,_hy-_ty+1);
        }
        if ((_tx - _hx >= 48) && (_hy - _ty >= 48)) {
          g.drawLine(0,_hy-_ty,_tx-_hx,0);
          _realX1 = 0; _realY1 = _hy-_ty;
          _realX2 = _tx-_hx; _realY2 = 0;
          this.setBounds(_hx,_ty,_tx-_hx+1,_hy-_ty+1);
        }
      }
    }

    if (_hx > _tx) {
      if (_ty > _hy) {
        if (_hx - _tx < 48) {
          _realX1 = 48-(int)((48-(_hx-_tx))/2); _realY1 = 0;
          _realX2 = 0+(int)((48-(_hx-_tx))/2); _realY2 = _ty-_hy;
          g.drawLine(48-(int)((48-(_hx-_tx))/2),0,0+(int)((48-(_hx-_tx))/2),_ty-_hy);
          this.setBounds(_tx-(int)((48-(_hx-_tx))/2),_hy,48,_ty-_hy+1);
        }
        if (_ty - _hy < 48) {
          _realX1 = _hx - _tx; _realY1 = 0+(int)((48-(_ty-_hy))/2);
          _realX2 = 0; _realY2 = 48-(int)((48-(_ty-_hy))/2);
          g.drawLine(_hx - _tx,0+(int)((48-(_ty-_hy))/2),0,48-(int)((48-(_ty-_hy))/2));
          this.setBounds(_tx,_hy-(int)((48-(_ty-_hy))/2),_hx-_tx+1,48);
        }
        if ((_hx - _tx >= 48) && (_ty-_hy >= 48)) {
          _realX1 = _hx-_tx ; _realY1 = 0;
          _realX2 = 0 ; _realY2 = _ty-_hy;
          g.drawLine(_hx - _tx,0,0,_ty-_hy);
          this.setBounds(_tx,_hy,_hx-_tx+1,_ty-_hy+1);
        }
      }
      if (_ty < _hy) {
        if (_hy - _ty < 48) {
          _realX1 = _hx-_tx ; _realY1 = 48-(int)((48-(_hy-_ty))/2);
          _realX2 = 0 ; _realY2 = 0+(int)((48-(_hy-_ty))/2);
          g.drawLine(_hx - _tx,48-(int)((48-(_hy-_ty))/2),0,0+(int)((48-(_hy-_ty))/2));
          this.setBounds(_tx,_ty-(int)((48-(_hy-_ty))/2),_hx-_tx+1,48);
        }
        if (_hx - _tx < 48) {
          _realX1 = 48-(int)((48-(_hx-_tx))/2); _realY1 = _hy-_ty;
          _realX2 = 0+(int)((48-(_hx-_tx))/2); _realY2 = 0;
          g.drawLine(48-(int)((48-(_hx-_tx))/2),_hy-_ty,0+(int)((48-(_hx-_tx))/2),0);
          this.setBounds(_tx-(int)((48-(_hx-_tx))/2),_ty,48,_hy-_ty+1);
        }
        if ((_hx - _tx >= 48) && (_hy - _ty >= 48)) {
          _realX1 = _hx-_tx ; _realY1 = _hy-_ty;
          _realX2 = 0 ; _realY2 = 0;
          g.drawLine(_hx - _tx,_hy-_ty,0,0);
          this.setBounds(_tx,_ty,_hx-_tx+1,_hy-_ty+1);
        }
      }
    }

    if (_tx == _hx) {
      if (_ty > _hy){
        g.drawLine(0+arrowWidth/2,0,0+arrowWidth/2,_ty-_hy);
        _realX1 = 0 ; _realY1 = 0;
        _realX2 = 0 ; _realY2 = _ty-_hy;
        this.setBounds(_hx-arrowWidth/2,_hy,arrowWidth+1,_ty-_hy);
      }
      if (_ty < _hy){
        g.drawLine(0+arrowWidth/2,_hy-_ty,0+arrowWidth/2,0);
        _realX1 = 0 ; _realY1 = _hy-_ty;
        _realX2 = 0 ; _realY2 = 0;
        this.setBounds(_tx-arrowWidth/2,_ty,arrowWidth+1,_hy-_ty);
      }
    }

    if (_ty == _hy) {
      if (_hx < _tx) {
        g.drawLine(0,0+arrowWidth/2,_tx-_hx,0+arrowWidth/2);
        _realX1 = 0 ; _realY1 = 0;
        _realX2 = _tx-_hx ; _realY2 = 0;
        this.setBounds(_hx,_hy-arrowWidth/2,_tx-_hx,_ty-_hy+1+arrowWidth);
      }
      if (_hx > _tx) {
        g.drawLine(0,0+arrowWidth/2,_hx-_tx,0+arrowWidth/2);
        _realX1 = 0 ; _realY1 = 0;
        _realX2 = _hx-_tx ; _realY2 = 0;
        this.setBounds(_tx,_hy-arrowWidth/2,_hx-_tx,_ty-_hy+1+arrowWidth);
      }
    }
    if (_srcArrowHead == 1)
      DrawArrowTriangle(g);
    if (_srcArrowHead == 2)
      DrawArrowRectangle(g);
  }

  public void setBounds() {
    this.paintComponent(this.getGraphics());
//    calculatePointSRC();
//    calculatePointDES();
//    this.setBounds(_hx,_hy,_tx-_hx+1,_ty-_hy+1);
  }

  private void DrawArrowTriangle(Graphics g){
    int    xFrom, xTo, yFrom, yTo;
    double denom, x, y, dx, dy, cos, sin;
    Polygon triangle;
    xTo = 0;
    xFrom = _tx - _hx;
    yTo = 0;
    yFrom = _ty - _hy;

    if (_tx >_hx) {
      if (_ty > _hy) {
        if (_tx - _hx < 48) {
          xTo   = 0 +(int)((48-(_tx-_hx))/2);
          yTo   = 0;
          xFrom = 48-(int)((48-(_tx-_hx))/2);
          yFrom = _ty-_hy;
        }
        if (_ty - _hy < 48) {
          xTo   = 0;
          yTo   = 0 +(int)((48-(_ty-_hy))/2);
          xFrom = _tx-_hx;
          yFrom = 48-(int)((48-(_ty-_hy))/2);
        }
        if ((_tx - _hx >= 48) && (_ty - _hy >= 48)) {
          xTo = 0;
          yTo = 0;
          xFrom = _tx - _hx;
          yFrom = _ty - _hy;
        }
      }
      if (_hy > _ty) {
        if (_hy - _ty < 48) {
          xTo   = 0;
          yTo   = 48-(int)((48-(_hy-_ty))/2);
          xFrom = _tx-_hx;
          yFrom = 0+(int)((48-(_hy-_ty))/2);
        }
        if (_tx - _hx < 48) {
          xTo   = 0+(int)((48-(_tx-_hx))/2);
          yTo   = _hy-_ty;
          xFrom = 48-(int)((48-(_tx-_hx))/2);
          yFrom = 0;
        }
        if ((_tx - _hx >= 48) && (_hy - _ty >= 48)) {
          xTo   = 0;
          yTo   = _hy-_ty;
          xFrom = _tx-_hx;
          yFrom = 0;
        }
      }
    }

    if (_hx > _tx) {
      if (_ty > _hy) {
        if (_hx - _tx < 48) {
          xTo   = 48-(int)((48-(_hx-_tx))/2);
          yTo   = 0;
          xFrom = 0 +(int)((48-(_hx-_tx))/2);
          yFrom   = _ty-_hy;
        }
        if (_ty - _hy < 48) {
          xTo   = _hx - _tx;
          yTo   = 0 +(int)((48-(_ty-_hy))/2);
          xFrom = 0;
          yFrom = 48-(int)((48-(_ty-_hy))/2);
        }
        if ((_hx - _tx >= 48) && (_ty-_hy >= 48)) {
          xTo   = _hx - _tx;
          yTo   = 0;
          xFrom = 0;
          yFrom = _ty - _hy;
        }
      }
      if (_ty < _hy) {
        if (_hy - _ty < 48) {
            xTo   = _hx-_tx;
            yTo   = 48 - (int)((48-(_hy-_ty))/2);
            xFrom = 0;
            yFrom = 0  + (int)((48-(_hy-_ty))/2);
        }
        if (_hx - _tx < 48) {
          xTo   = 48- (int)((48-(_hx-_tx))/2);
          yTo   = _hy - _ty;
          xFrom = 0 + (int)((48-(_hx-_tx))/2);
          yFrom = 0;
        }
        if ((_hx - _tx >= 48) && (_hy - _ty >= 48)) {
          xTo   = _hx - _tx;
          yTo   = _hy - _ty;
          xFrom = 0;
          yFrom = 0;
        }
      }
    }

    if (_tx == _hx) {
      if (_ty > _hy){
        xTo   = arrowWidth / 2;
        yTo   = 0;
        xFrom = arrowWidth / 2;
        yFrom = _ty-_hy;
      }
      if (_ty < _hy){
        xTo   = arrowWidth / 2;
        yTo   = _hy-_ty;
        xFrom = arrowWidth / 2;
        yFrom = 0;
      }
    }

    if (_ty == _hy) {
      if (_hx < _tx) {
        xTo   = 0;
        yTo   = 0 + arrowWidth/2;
        xFrom = _tx-_hx;
        yFrom = 0 + arrowWidth/2;
      }
      if (_hx > _tx) {
        xTo   = _hx-_tx;
        yTo   = 0 + arrowWidth/2;
        xFrom = 0;
        yFrom = 0 + arrowWidth/2;
      }
    }

    dx   	= (double)(xTo - xFrom);
    dy   	= (double)(yTo - yFrom);

    denom 	= dist(dx, dy);
    if (denom <= 0.01) return;

    cos = arrowWidth/denom;
    sin = arrowHeigh/denom;
    x   = xTo - cos*dx;
    y   = yTo - cos*dy;
    int x1  = (int)(x - sin*dy);
    int y1  = (int)(y + sin*dx);
    int x2  = (int)(x + sin*dy);
    int y2  = (int)(y - sin*dx);

    triangle = new Polygon();
    triangle.addPoint(xTo, yTo);
    triangle.addPoint(x1, y1);
    triangle.addPoint(x2, y2);

    g.setColor(Color.white);
    g.fillPolygon(triangle);
    g.setColor(Color.black);
    g.drawPolygon(triangle);
  }


  private void DrawArrowRectangle(Graphics g){
    int    xFrom, xTo, yFrom, yTo;
    double denom, x, y, dx, dy, cos, sin;
    Polygon rectangle;
    xTo = 0;
    xFrom = _tx - _hx;
    yTo = 0;
    yFrom = _ty - _hy;

    if (_tx >_hx) {
      if (_ty > _hy) {
        if (_tx - _hx < 48) {
          xTo   = 0 +(int)((48-(_tx-_hx))/2);
          yTo   = 0;
          xFrom = 48-(int)((48-(_tx-_hx))/2);
          yFrom = _ty-_hy;
        }
        if (_ty - _hy < 48) {
          xTo   = 0;
          yTo   = 0 +(int)((48-(_ty-_hy))/2);
          xFrom = _tx-_hx;
          yFrom = 48-(int)((48-(_ty-_hy))/2);
        }
        if ((_tx - _hx >= 48) && (_ty - _hy >= 48)) {
          xTo = 0;
          yTo = 0;
          xFrom = _tx - _hx;
          yFrom = _ty - _hy;
        }
      }
      if (_hy > _ty) {
        if (_hy - _ty < 48) {
          xTo   = 0;
          yTo   = 48-(int)((48-(_hy-_ty))/2);
          xFrom = _tx-_hx;
          yFrom = 0+(int)((48-(_hy-_ty))/2);
        }
        if (_tx - _hx < 48) {
          xTo   = 0+(int)((48-(_tx-_hx))/2);
          yTo   = _hy-_ty;
          xFrom = 48-(int)((48-(_tx-_hx))/2);
          yFrom = 0;
        }
        if ((_tx - _hx >= 48) && (_hy - _ty >= 48)) {
          xTo   = 0;
          yTo   = _hy-_ty;
          xFrom = _tx-_hx;
          yFrom = 0;
        }
      }
    }

    if (_hx > _tx) {
      if (_ty > _hy) {
        if (_hx - _tx < 48) {
          xTo   = 48-(int)((48-(_hx-_tx))/2);
          yTo   = 0;
          xFrom = 0 +(int)((48-(_hx-_tx))/2);
          yFrom   = _ty-_hy;
        }
        if (_ty - _hy < 48) {
          xTo   = _hx - _tx;
          yTo   = 0 +(int)((48-(_ty-_hy))/2);
          xFrom = 0;
          yFrom = 48-(int)((48-(_ty-_hy))/2);
        }
        if ((_hx - _tx >= 48) && (_ty-_hy >= 48)) {
          xTo   = _hx - _tx;
          yTo   = 0;
          xFrom = 0;
          yFrom = _ty - _hy;
        }
      }
      if (_ty < _hy) {
        if (_hy - _ty < 48) {
            xTo   = _hx-_tx;
            yTo   = 48 - (int)((48-(_hy-_ty))/2);
            xFrom = 0;
            yFrom = 0  + (int)((48-(_hy-_ty))/2);
        }
        if (_hx - _tx < 48) {
          xTo   = 48- (int)((48-(_hx-_tx))/2);
          yTo   = _hy - _ty;
          xFrom = 0 + (int)((48-(_hx-_tx))/2);
          yFrom = 0;
        }
        if ((_hx - _tx >= 48) && (_hy - _ty >= 48)) {
          xTo   = _hx - _tx;
          yTo   = _hy - _ty;
          xFrom = 0;
          yFrom = 0;
        }
      }
    }

    if (_tx == _hx) {
      if (_ty > _hy){
        xTo   = arrowWidth / 2;
        yTo   = 0;
        xFrom = arrowWidth / 2;
        yFrom = _ty-_hy;
      }
      if (_ty < _hy){
        xTo   = arrowWidth / 2;
        yTo   = _hy-_ty;
        xFrom = arrowWidth / 2;
        yFrom = 0;
      }
    }

    if (_ty == _hy) {
      if (_hx < _tx) {
        xTo   = 0;
        yTo   = 0 + arrowWidth/2;
        xFrom = _tx-_hx;
        yFrom = 0 + arrowWidth/2;
      }
      if (_hx > _tx) {
        xTo   = _hx-_tx;
        yTo   = 0 + arrowWidth/2;
        xFrom = 0;
        yFrom = 0 + arrowWidth/2;
      }
    }

    dx   	= (double)(xTo - xFrom);
    dy   	= (double)(yTo - yFrom);

    denom 	= dist(dx, dy);
    if (denom <= 0.01) return;

    cos = arrowWidth/denom;
    sin = arrowHeigh/denom;
    x   = xTo - cos*dx;
    y   = yTo - cos*dy;
    int x1  = (int)(x - sin*dy);
    int y1  = (int)(y + sin*dx);
    int x2  = (int)(x + sin*dy);
    int y2  = (int)(y - sin*dx);
    int x3  = (int)(xTo - arrowWidth*2*dx/denom);
    int y3  = (int)(yTo - arrowWidth*2*dy/denom);

    rectangle = new Polygon();
    rectangle.addPoint(xTo, yTo);
    rectangle.addPoint(x1, y1);
    rectangle.addPoint(x3, y3);
    rectangle.addPoint(x2, y2);

    g.setColor(Color.white);
    g.fillPolygon(rectangle);
    g.setColor(Color.black);
    g.drawPolygon(rectangle);
  }

  protected double dist(double dx, double dy) {
    return Math.sqrt(dx*dx+dy*dy);
  }


  public void calculateAreaPoint(){
   double tx = (double) Math.abs(_realX1 - _realX2);
   double ty = (double) Math.abs(_realY1 - _realY2);

   int _tempX1,_tempY1,_tempX2,_tempY2;

   int xStart = this.getX();
   int yStart = this.getY();

   if(ty/tx > 1.0){
      if(_realY1 > _realY2){
        _tempX1 = _realX1;
        _tempY1 = _realY1;

        _tempX2 = _realX2;
        _tempY2 = _realY2;
      }else{
        _tempX1 = _realX2;
        _tempY1 = _realY2;

        _tempX2 = _realX1;
        _tempY2 = _realY1;
      }
   }else{
      if(_realX1 > _realX2){
        _tempX1 = _realX1;
        _tempY1 = _realY1;

        _tempX2 = _realX2;
        _tempY2 = _realY2;
      }else{
        _tempX1 = _realX2;
        _tempY1 = _realY2;

        _tempX2 = _realX1;
        _tempY2 = _realY1;
      }
   }

   if(ty/tx > 1.0){
     _areaX1 = _tempX1 - 10 + xStart;
     _areaX2 = _tempX1 + 10 + xStart;
     _areaY1 = _areaY2 = _tempY1 + yStart;

     _areaX3 = _tempX2 + 10 + xStart;
     _areaX4 = _tempX2 - 10 + xStart;
     _areaY3 = _areaY4 = _tempY2 + yStart;
   }else{
     _areaY1 = _tempY1 + 10 + yStart;
     _areaY2 = _tempY1 - 10 + yStart;
     _areaX1 = _areaX2 = _tempX1 + xStart;

     _areaY3 = _tempY2 - 10 + yStart;
     _areaY4 = _tempY2 + 10 + yStart;
     _areaX3 = _areaX4 = _tempX2 + xStart;
   }
  }

  public boolean checkArea(int x,int y){
    calculateAreaPoint();
    // vector 1
    if(!crossProduct(_areaX2-_areaX1,_areaY2 - _areaY1,x - _areaX1,y - _areaY1)) return false;
    // vector 2
    if(!crossProduct(_areaX3-_areaX2,_areaY3 - _areaY2,x - _areaX2,y - _areaY2)) return false;
    // vector 3
    if(!crossProduct(_areaX4-_areaX3,_areaY4 - _areaY3,x - _areaX3,y - _areaY3)) return false;
    // vector 4
    if(!crossProduct(_areaX1-_areaX4,_areaY1 - _areaY4,x - _areaX4,y - _areaY4)) return false;
    return true;
  }

  private boolean crossProduct(int v1I,int v1J,int v2I,int v2J){
      if ((-v1I*v2J + v1J*v2I) >= 0)    // Inverse from v1I*v2J - v1J*v2I
          return true;                  // because Y axis is not normal form
      return false;
  }

  public void setOid(Oid aOid){
    oid = aOid;
  }

  public Oid getOid() {
    return oid;
  }
}