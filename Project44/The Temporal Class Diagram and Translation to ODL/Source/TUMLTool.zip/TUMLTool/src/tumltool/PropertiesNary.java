package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.util.Vector;
import java.awt.event.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesNary extends JDialog {
  JPanel panelMain = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel panelProperties = new JPanel();
  JPanel panelButton = new JPanel();
  JButton buttonOK = new JButton();
  JButton buttonCancel = new JButton();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();
  JPanel jPanel6 = new JPanel();
  JPanel jPanel7 = new JPanel();
  JPanel jPanel8 = new JPanel();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JLabel jLabel1 = new JLabel();
  JTextField textFieldRole = new JTextField();
  JLabel jLabel2 = new JLabel();
  JComboBox comboBoxFClass = new JComboBox();
  JLabel jLabel3 = new JLabel();
  JComboBox comboBoxSClass = new JComboBox();
  JLabel jLabel4 = new JLabel();
  JComboBox comboBoxTClass = new JComboBox();
  JLabel jLabel5 = new JLabel();
  JComboBox comboBoxCategory = new JComboBox();
  JPanel jPanel9 = new JPanel();
  JPanel jPanel10 = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  Border border1;
  JComboBox comboBoxGranularity = new JComboBox();
  ButtonGroup buttonGroupValidtime = new ButtonGroup();
  JRadioButton radioButtonTimepoint = new JRadioButton();
  JRadioButton radioButtonPeriod = new JRadioButton();
  FlowLayout flowLayout2 = new FlowLayout();
  FlowLayout flowLayout3 = new FlowLayout();
  FlowLayout flowLayout4 = new FlowLayout();
  FlowLayout flowLayout5 = new FlowLayout();
  FlowLayout flowLayout1 = new FlowLayout();
  FlowLayout flowLayout6 = new FlowLayout();
  Vector vClass;
  FigNary myNary;
  public int OK_OPTION = 0;
  public int CANCEL_OPTION = 1;
  int optionSelected;

  public PropertiesNary(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
      //Center the window
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = this.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

//  public PropertiesNary() {
//    this(null, "", false);
//  }

  void jbInit() throws Exception {
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140));
    panelMain.setLayout(borderLayout1);
    this.setResizable(false);
    this.setTitle("Ternary Association Properties");
    buttonOK.setMnemonic('O');
    buttonOK.setText("OK");
    buttonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOK_actionPerformed(e);
      }
    });
    buttonCancel.setText("Cancel");
    buttonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonCancel_actionPerformed(e);
      }
    });
    panelProperties.setBorder(BorderFactory.createEtchedBorder());
    panelProperties.setLayout(verticalFlowLayout1);
    jLabel1.setPreferredSize(new Dimension(40, 16));
    jLabel1.setText("Role:");
    textFieldRole.setPreferredSize(new Dimension(230, 20));
    jLabel2.setPreferredSize(new Dimension(90, 16));
    jLabel2.setText("First Class:");
    jLabel3.setPreferredSize(new Dimension(90, 16));
    jLabel3.setText("Second Class:");
    jLabel4.setPreferredSize(new Dimension(90, 16));
    jLabel4.setText("Third Class:");
    jLabel5.setPreferredSize(new Dimension(130, 16));
    jLabel5.setText("Timestamp Category:");
    jPanel8.setLayout(borderLayout2);
    jPanel8.setBorder(new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Valid time timestamp"));
    jPanel9.setBorder(new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Valid time type"));
    jPanel10.setBorder(new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Granularity"));
    radioButtonTimepoint.setText("Timepoint");
    radioButtonPeriod.setSelected(true);
    radioButtonPeriod.setText("Period");
    jPanel3.setLayout(flowLayout1);
    jPanel4.setLayout(flowLayout2);
    jPanel5.setLayout(flowLayout3);
    jPanel6.setLayout(flowLayout4);
    jPanel7.setLayout(flowLayout5);
    comboBoxFClass.setPreferredSize(new Dimension(180, 22));
    comboBoxFClass.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        comboBoxFClass_itemStateChanged(e);
      }
    });
    comboBoxSClass.setPreferredSize(new Dimension(180, 22));
    comboBoxSClass.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        comboBoxSClass_itemStateChanged(e);
      }
    });
    comboBoxTClass.setPreferredSize(new Dimension(180, 22));
    comboBoxTClass.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        comboBoxTClass_itemStateChanged(e);
      }
    });
    comboBoxCategory.setPreferredSize(new Dimension(140, 22));
    comboBoxCategory.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        comboBoxCategory_itemStateChanged(e);
      }
    });
    panelButton.setLayout(flowLayout6);
    flowLayout6.setAlignment(FlowLayout.RIGHT);
    comboBoxGranularity.setPreferredSize(new Dimension(125, 22));
    getContentPane().add(panelMain);
    panelMain.add(panelProperties, BorderLayout.CENTER);
    panelProperties.add(jPanel3, null);
    jPanel3.add(jLabel1, null);
    jPanel3.add(textFieldRole, null);
    panelProperties.add(jPanel4, null);
    jPanel4.add(jLabel2, null);
    jPanel4.add(comboBoxFClass, null);
    panelProperties.add(jPanel5, null);
    jPanel5.add(jLabel3, null);
    jPanel5.add(comboBoxSClass, null);
    panelProperties.add(jPanel6, null);
    jPanel6.add(jLabel4, null);
    jPanel6.add(comboBoxTClass, null);
    panelProperties.add(jPanel7, null);
    jPanel7.add(jLabel5, null);
    jPanel7.add(comboBoxCategory, null);
    panelProperties.add(jPanel8, null);
    jPanel8.add(jPanel9, BorderLayout.WEST);
    jPanel9.add(radioButtonPeriod, null);
    jPanel9.add(radioButtonTimepoint, null);
    jPanel8.add(jPanel10, BorderLayout.CENTER);
    jPanel10.add(comboBoxGranularity, null);
    panelMain.add(panelButton,  BorderLayout.SOUTH);
    panelButton.add(buttonOK, null);
    panelButton.add(buttonCancel, null);
    buttonGroupValidtime.add(radioButtonPeriod);
    buttonGroupValidtime.add(radioButtonTimepoint);
    setValidtimeEnabled(false);
  }

  public void setNary(FigNary fNary){
    myNary = fNary;
    textFieldRole.setText(fNary.getRoleName());
  }

  public FigNary getNary(){
    return myNary;
  }

  public void setClassVector(Vector aClass) {
    vClass = aClass;
    comboBoxFClass.removeAllItems();
    comboBoxSClass.removeAllItems();
    comboBoxTClass.removeAllItems();
    for (int i = 0 ; i < vClass.size() ; i++) {
      FigClass fClass = (FigClass) vClass.elementAt(i);
      comboBoxFClass.addItem(fClass.getName());
      comboBoxSClass.addItem(fClass.getName());
      comboBoxTClass.addItem(fClass.getName());
    }
    if (myNary.getFClass() != null) {
      comboBoxFClass.setSelectedItem(myNary.getFClass().getName());
      comboBoxSClass.setSelectedItem(myNary.getSClass().getName());
      comboBoxTClass.setSelectedItem(myNary.getTClass().getName());
    }
    setComboBoxCategory();
  }

  private void setComboBoxCategory() {
    comboBoxCategory.removeAllItems();
    comboBoxCategory.addItem(TimeType.getsTimeType(0));
    if (comboBoxFClass.getSelectedIndex() > -1) {
      FigClass fClass = (FigClass)vClass.elementAt(comboBoxFClass.getSelectedIndex());
      if (comboBoxSClass.getSelectedIndex() > -1) {
        FigClass sClass = (FigClass)vClass.elementAt(comboBoxSClass.getSelectedIndex());
        if (comboBoxTClass.getSelectedIndex() > -1) {
          FigClass tClass = (FigClass)vClass.elementAt(comboBoxTClass.getSelectedIndex());
          if ((fClass.getiTimeType() > 0)&&(fClass.getiTimeType() != 2)&&(sClass.getiTimeType() > 0)&&(sClass.getiTimeType() != 2)&&(tClass.getiTimeType() > 0)&&(tClass.getiTimeType() != 2))
            comboBoxCategory.addItem(TimeType.getsTimeType(1));
          if ((fClass.getiTimeType() > 1)&&(sClass.getiTimeType() > 1)&&(tClass.getiTimeType() > 1))
            comboBoxCategory.addItem(TimeType.getsTimeType(2));
          if ((fClass.getiTimeType() == 3)&&(sClass.getiTimeType() == 3)&&(tClass.getiTimeType() == 3))
            comboBoxCategory.addItem(TimeType.getsTimeType(3));
          comboBoxCategory.setSelectedItem(TimeType.getsTimeType(myNary.getIndexTimeType()));
        }
      }
    }
  }

  private void setComboBoxGranularity() {
    if (comboBoxFClass.getSelectedIndex() > -1) {
      FigClass fClass = (FigClass)vClass.elementAt(comboBoxFClass.getSelectedIndex());
      if (comboBoxSClass.getSelectedIndex() > -1) {
        FigClass sClass = (FigClass)vClass.elementAt(comboBoxSClass.getSelectedIndex());
        if (comboBoxTClass.getSelectedIndex() > -1) {
          FigClass tClass = (FigClass)vClass.elementAt(comboBoxTClass.getSelectedIndex());
          if ((fClass.getIGranularity() >= sClass.getIGranularity())&&(fClass.getIGranularity() >= tClass.getIGranularity())) {
            comboBoxGranularity.removeAllItems();
            for (int i = 5;i >= fClass.getIGranularity();i--)
              comboBoxGranularity.addItem(Granularity.getGranularity(i));
          }
          if ((sClass.getIGranularity() >= fClass.getIGranularity())&&(sClass.getIGranularity() >= tClass.getIGranularity())) {
            comboBoxGranularity.removeAllItems();
            for (int i = 5;i >= sClass.getIGranularity();i--)
              comboBoxGranularity.addItem(Granularity.getGranularity(i));
          }
          if ((tClass.getIGranularity() >= fClass.getIGranularity())&&(tClass.getIGranularity() >= sClass.getIGranularity())) {
            comboBoxGranularity.removeAllItems();
            for (int i = 5;i >= tClass.getIGranularity();i--)
              comboBoxGranularity.addItem(Granularity.getGranularity(i));
          }
          if (myNary.getGranularity().length() == 0)
            comboBoxGranularity.setSelectedItem(Granularity.getGranularity(5));
          else
            comboBoxGranularity.setSelectedItem(myNary.getGranularity());
        }
      }
    }
  }

  public int showDialog(){
    this.show();
    return optionSelected;
  }

  void buttonOK_actionPerformed(ActionEvent e) {
    optionSelected = OK_OPTION;
    if (textFieldRole.getText().length() != 0) {
      if ((comboBoxFClass.getSelectedIndex() != comboBoxSClass.getSelectedIndex()) &&
          (comboBoxFClass.getSelectedIndex() != comboBoxTClass.getSelectedIndex()) &&
          (comboBoxSClass.getSelectedIndex() != comboBoxTClass.getSelectedIndex())) {
        myNary.setRoleName(textFieldRole.getText());
        myNary.setFClass(getFigClass(comboBoxFClass.getSelectedItem().toString()));
        myNary.setSClass(getFigClass(comboBoxSClass.getSelectedItem().toString()));
        myNary.setTClass(getFigClass(comboBoxTClass.getSelectedItem().toString()));
        if (myNary.getIndexTimeType() != TimeType.getiTimeType(comboBoxCategory.getSelectedItem().toString())) {
          decClassRelation(myNary.getIndexTimeType());
          incClassRelation(TimeType.getiTimeType(comboBoxCategory.getSelectedItem().toString()));
          myNary.setIndexTimeType(TimeType.getiTimeType(comboBoxCategory.getSelectedItem().toString()));
        }

        if (radioButtonPeriod.isSelected() == true)
          myNary.setTimestampType(radioButtonPeriod.getText());
        else
          myNary.setTimestampType(radioButtonTimepoint.getText());
        if (comboBoxGranularity.getSelectedIndex() > -1)
          myNary.setGranularity(comboBoxGranularity.getSelectedItem().toString());
        else
          myNary.setGranularity(Granularity.getGranularity(5));
        this.setVisible(false);
      } else
        JOptionPane.showMessageDialog(this,"Please choose different class","Error Message",JOptionPane.ERROR_MESSAGE);
    } else
      JOptionPane.showMessageDialog(this,"Please insert Role's name","Error Message",JOptionPane.ERROR_MESSAGE);
  }

  void buttonCancel_actionPerformed(ActionEvent e) {
    optionSelected = CANCEL_OPTION;
    this.setVisible(false);
  }

  void comboBoxFClass_itemStateChanged(ItemEvent e) {
    setComboBoxCategory();
  }

  void comboBoxSClass_itemStateChanged(ItemEvent e) {
    setComboBoxCategory();
  }

  void comboBoxTClass_itemStateChanged(ItemEvent e) {
    setComboBoxCategory();
  }

  void comboBoxCategory_itemStateChanged(ItemEvent e) {
    if (comboBoxCategory.getSelectedIndex() > -1) {
      String item = comboBoxCategory.getSelectedItem().toString();
      if ( (item.compareTo(TimeType.getsTimeType(1)) == 0) || (item.compareTo(TimeType.getsTimeType(3)) == 0))
        setValidtimeEnabled(true);
      else
        setValidtimeEnabled(false);
      if (item.compareTo(TimeType.getsTimeType(2)) == 0) {
        radioButtonPeriod.setSelected(true);
        comboBoxGranularity.setSelectedIndex(0);
      }
    }
  }

  void setValidtimeEnabled(boolean t) {
    radioButtonPeriod.setEnabled(t);
    radioButtonTimepoint.setEnabled(t);
    comboBoxGranularity.setEnabled(t);
    setComboBoxGranularity();
  }

  private FigClass getFigClass(String name) {
    for (int i = 0 ; i < vClass.size() ; i++) {
      FigClass classChecked = (FigClass)vClass.elementAt(i);
      if (classChecked.getName().compareTo(name) == 0)
        return classChecked;
    }
    return null;
  }

  private void incClassRelation(int t){
    if (t == 1) {
      myNary.getFClass().incAssociationVT();
      myNary.getSClass().incAssociationVT();
      myNary.getTClass().incAssociationVT();
    }
    if (t == 2) {
      myNary.getFClass().incAssociationTT();
      myNary.getSClass().incAssociationTT();
      myNary.getTClass().incAssociationTT();
    }
    if (t == 3) {
      myNary.getFClass().incAssociationBT();
      myNary.getSClass().incAssociationBT();
      myNary.getTClass().incAssociationBT();
    }
  }

  private void decClassRelation(int t){
    if (t == 1) {
      myNary.getFClass().decAssociationVT();
      myNary.getSClass().decAssociationVT();
      myNary.getTClass().decAssociationVT();
    }
    if (t == 2) {
      myNary.getFClass().decAssociationTT();
      myNary.getSClass().decAssociationTT();
      myNary.getTClass().decAssociationTT();
    }
    if (t == 3) {
      myNary.getFClass().decAssociationBT();
      myNary.getSClass().decAssociationBT();
      myNary.getTClass().decAssociationBT();
    }
  }
}