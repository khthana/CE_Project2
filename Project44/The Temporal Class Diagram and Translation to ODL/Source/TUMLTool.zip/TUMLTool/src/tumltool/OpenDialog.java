package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import COM.intersys.objects.*;
import Model.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class OpenDialog extends JDialog {
  JPanel panelTable = new JPanel();
  JPanel panelButton = new JPanel();
  JButton buttonCancel = new JButton();
  JButton buttonOK = new JButton();
  JScrollPane scrollPane1 = new JScrollPane();
  BorderLayout borderLayout1 = new BorderLayout();
  AttrJTable tableDiagram = new AttrJTable();
  String columns[] = {"ID","Diagram Name", "Descriptions"};
  String rows[][] = { };
  ObjectFactory mFactory = null;
  Oid oid = null;

  public OpenDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public OpenDialog() {
    this(null, "", false);
  }

  void jbInit() throws Exception {
    panelTable.setLayout(borderLayout1);
    buttonCancel.setText("Cancel");
    buttonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonCancel_actionPerformed(e);
      }
    });
    buttonOK.setText("OK");
    buttonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOK_actionPerformed(e);
      }
    });
    scrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    this.setResizable(false);
    this.setTitle("Open Diagram");
    panelTable.setPreferredSize(new Dimension(454, 200));
    getContentPane().add(panelTable);
    this.getContentPane().add(panelButton,  BorderLayout.SOUTH);
    panelButton.add(buttonOK, null);
    panelButton.add(buttonCancel, null);
    panelTable.add(scrollPane1,  BorderLayout.CENTER);
    scrollPane1.getViewport().add(tableDiagram, null);
    tableDiagram.setDataVector(rows,columns);
    tableDiagram.setSelectionMode(0);
  }

  void setFactory(ObjectFactory aFactory){
    mFactory = aFactory;
    try {
      ResultSet rset;
      rset = new ResultSet(mFactory,"Model.Diagrams","ByID");
      rset.execute();
      while (rset.next()) {
        tableDiagram.insertRow(0,rows);
        tableDiagram.setValueAt(rset.getString(1),0,0);
        tableDiagram.setValueAt(rset.getString(2),0,1);
        tableDiagram.setValueAt(rset.getString(3),0,2);
      }
      rset.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
  }

  void buttonOK_actionPerformed(ActionEvent e) {
    if (tableDiagram.getSelectedRow() >= 0) {
      int row = tableDiagram.getSelectedRow();
      String sId = tableDiagram.getValueAt(row,0).toString();
      try {
        Diagrams mDiagram = new Diagrams(mFactory,sId);
        oid = mDiagram._getOid();
        mDiagram._close();
        mDiagram = null;
      } catch (Exception ex) {
        ex.printStackTrace();
      }
      this.setVisible(false);
    }
  }

  void buttonCancel_actionPerformed(ActionEvent e) {
    oid = null;
    this.setVisible(false);
  }

  Oid getSelectedOid() {
    return oid;
  }
}