package tumltool;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.event.*;
import java.io.*;
import COM.intersys.objects.*;

/**
 * Title:       TCDTOOL
 * Description: Program use drawing Temporal Class Diagram
 * Copyright:   Copyright (c) 2001
 * Company:     KMITL
 * @author      Yutthana Suiwongsa & Akachan Pitisakhonvit
 * @version 1.0
 */

public class TUMLTool extends JFrame {
  ObjectFactory mFactory = null;

  JButton buttonNewDiagram    = new JButton();
  JButton buttonOpenDiagram   = new JButton();
  JButton buttonSaveDiagram   = new JButton();
  JButton buttonCloseDiagram  = new JButton();
  JButton buttonExportDiagram = new JButton();

  JToggleButton toggleButtonSelect      = new JToggleButton();
  JToggleButton toggleButtonClass       = new JToggleButton();
  JToggleButton toggleButtonInheritance = new JToggleButton();
  JToggleButton toggleButtonAssociation = new JToggleButton();
  JToggleButton toggleButtonAggregation = new JToggleButton();
  JToggleButton toggleButtonNary        = new JToggleButton();
  JToggleButton toggleButtonAssociationClass = new JToggleButton();
  ButtonGroup buttonGroupTool = new ButtonGroup();

  ImageIcon imageNewDiagram;
  ImageIcon imageOpenDiagram;
  ImageIcon imageSaveDiagram;
  ImageIcon imageCloseDiagram;
  ImageIcon imageDeleteDiagram;
  ImageIcon imageGenerateCode;
  ImageIcon imageSelect;
  ImageIcon imageClass;
  ImageIcon imageInheritance;
  ImageIcon imageAssociation;
  ImageIcon imageAggregation;
  ImageIcon imageNary;
  ImageIcon imageAssociationClass;

  Image cursorClass;
  Image cursorInheritance;
  Image cursorAggregation;
  Image cursorAssociation;
  Image cursorAssociationClass;
  Image cursorNary;

  JMenuBar Menu         = new JMenuBar();
  JMenu FileMenu        = new JMenu();
  JMenuItem MenuNew     = new JMenuItem();
  JMenuItem MenuOpen    = new JMenuItem();
  JMenuItem MenuSave    = new JMenuItem();
  JMenuItem MenuSaveAs  = new JMenuItem();
  JMenuItem MenuClose   = new JMenuItem();
  JMenuItem MenuDelete  = new JMenuItem();
  JMenuItem MenuExit    = new JMenuItem();
  JMenu ExportMenu      = new JMenu();
  JMenuItem MenuODL     = new JMenuItem();
  JMenuItem MenuTODL    = new JMenuItem();
  JMenu ProjectMenu     = new JMenu();
  JMenuItem MenuProjectProperties = new JMenuItem();

  JLabel labelName  = new JLabel();
  JLabel MouseMove  = new JLabel();

  Vector vClass       = new Vector();
  Vector vInheritance = new Vector();
  Vector vAssociation = new Vector();
  Vector vAggregation = new Vector();
  Vector vTernary     = new Vector();
  Vector vFternaryLine= new Vector();
  Vector vSternaryLine= new Vector();
  Vector vTternaryLine= new Vector();

  int indexClass       = -1;
  int indexAssociation = -1;
  int indexInheritance = -1;
  int indexAggregation = -1;
  int indexTernary     = -1;

  int pointX1  = 0;
  int pointY1  = 0;
  int pointX2o = 0;
  int pointY2o = 0;
  int pointX2n = 0;
  int pointY2n = 0;

  PropertiesClass pClass             = new PropertiesClass(this,"",true);
  PropertiesInheritance pInheritance = new PropertiesInheritance(this,"",true);
  PropertiesAssociation pAssociation = new PropertiesAssociation(this,"",true);
  PropertiesAggregation pAggregation = new PropertiesAggregation(this,"",true);
  PropertiesProject pProject         = new PropertiesProject(this,"Diagram Properties",true);
  PropertiesNary pNary               = new PropertiesNary(this,"",true);

  PopupMenuClass popupClass             = new PopupMenuClass();
  PopupMenuAssociation popupAssociation = new PopupMenuAssociation();
  PopupMenuInheritance popupInheritance = new PopupMenuInheritance();
  PopupMenuAggregation popupAggregation = new PopupMenuAggregation();
  PopupMenuTernary popupTernary         = new PopupMenuTernary();

  GenerateODL _generatorODL                 = new GenerateODL(this,"Object Definition Language Code",true);
  GenerateTemporalODL _generatorTemporalODL = new GenerateTemporalODL(this,"Temporal Object Definition Language Code",true);
  GenerateCDL _generatorCDL                 = new GenerateCDL(this,"Cache' Definition Language Code",true);
  GenerateTCDL _generatorTCDL               = new GenerateTCDL(this,"Temporal Cache' Definition Language Code",true);

  JToolBar toolBarFile = new JToolBar();
  JToolBar toolBarTool = new JToolBar();
  JPanel statusBar     = new JPanel();
  JTextArea DrawArea   = new JTextArea(80,180);
  JScrollPane jScrollPane1   = new JScrollPane();
  DirChooser dirChoose       = new DirChooser();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();

  boolean modified = false;
  JMenuItem MenuCDL = new JMenuItem();
  JMenuItem MenuTCDL = new JMenuItem();
  JCheckBoxMenuItem MenuShowDialog = new JCheckBoxMenuItem();

  public TUMLTool() {
    try {
      mFactory = new ObjectFactory("cn_iptcp:127.0.0.1[1972]:PROJECT");
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    TUMLTool TUMLTool = new TUMLTool();
  }

  private void jbInit() throws Exception {
    imageNewDiagram       = new ImageIcon("newDiagram.gif");
    imageOpenDiagram      = new ImageIcon("openDiagram.gif");
    imageSaveDiagram      = new ImageIcon("saveDiagram.gif");
    imageCloseDiagram     = new ImageIcon("closeDiagram.gif");
    imageDeleteDiagram    = new ImageIcon("delete.gif");
    imageGenerateCode     = new ImageIcon("GenerateCode.gif");
    imageSelect           = new ImageIcon("Select.gif");
    imageClass            = new ImageIcon("Interface.gif");
    imageInheritance      = new ImageIcon("Inheritance.gif");
    imageAssociation      = new ImageIcon("Association.gif");
    imageAggregation      = new ImageIcon("Aggregation.gif");
    imageAssociationClass = new ImageIcon("AssociationClass.gif");
    imageNary             = new ImageIcon("NaryAssociation.gif");
    cursorClass           = Toolkit.getDefaultToolkit().getImage("Classcursor.gif");
    cursorInheritance     = Toolkit.getDefaultToolkit().getImage("Generizationcursor.gif");
    cursorAggregation     = Toolkit.getDefaultToolkit().getImage("Aggregationcursor.gif");
    cursorAssociation     = Toolkit.getDefaultToolkit().getImage("Associationcursor.gif");
    cursorAssociationClass= Toolkit.getDefaultToolkit().getImage("AssociationClasscursor.gif");
    cursorNary            = Toolkit.getDefaultToolkit().getImage("Narycursor.gif");

    setTitle("Temporal Class Diagram Tool");
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowActivated(WindowEvent e) {
        this_windowActivated(e);
      }
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    this.getContentPane().setLayout(borderLayout1);
    FileMenu.setMnemonic('F');
    FileMenu.setText("File");
    MenuNew.setIcon(imageNewDiagram);
    MenuNew.setMnemonic('N');
    MenuNew.setText("New Diagram...");
    MenuNew.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuNew_actionPerformed(e);
      }
    });
    MenuOpen.setIcon(imageOpenDiagram);
    MenuOpen.setMnemonic('O');
    MenuOpen.setText("Open Diagram...");
    MenuOpen.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuOpen_actionPerformed(e);
      }
    });
    MenuSave.setIcon(imageSaveDiagram);
    MenuSave.setMnemonic('S');
    MenuSave.setText("Save Diagram...");
    MenuSave.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuSave_actionPerformed(e);
      }
    });
    MenuClose.setIcon(imageCloseDiagram);
    MenuClose.setMnemonic('C');
    MenuClose.setText("Close Diagram");
    MenuClose.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuClose_actionPerformed(e);
      }
    });
    this.setJMenuBar(Menu);
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    DrawArea.setEditable(false);
    MenuExit.setMnemonic('X');
    ExportMenu.setMnemonic('P');
    ProjectMenu.setMnemonic('D');
    ProjectMenu.setText("Diagram");
    MenuProjectProperties.setMnemonic('0');
    MenuProjectProperties.setText("Project Properties...");
    MenuProjectProperties.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuProjectProperties_actionPerformed(e);
      }
    });
    buttonSaveDiagram.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonSaveDiagram_actionPerformed(e);
      }
    });
    buttonOpenDiagram.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOpenDiagram_actionPerformed(e);
      }
    });
    buttonNewDiagram.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonNewDiagram_actionPerformed(e);
      }
    });
    MenuDelete.setIcon(imageDeleteDiagram);
    MenuDelete.setText("Delete Diagram");
    MenuDelete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuDelete_actionPerformed(e);
      }
    });
    MenuSaveAs.setMnemonic('V');
    MenuSaveAs.setText("       Save As...");
    MenuSaveAs.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuSaveAs_actionPerformed(e);
      }
    });
    buttonCloseDiagram.setMaximumSize(new Dimension(25, 25));
    buttonCloseDiagram.setToolTipText("Close Diagram");
    buttonCloseDiagram.setIcon(imageCloseDiagram);
    buttonCloseDiagram.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonCloseDiagram_actionPerformed(e);
      }
    });
    buttonCloseDiagram.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        buttonCloseDiagram_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        buttonCloseDiagram_mouseExited(e);
      }
      public void mousePressed(MouseEvent e) {
        buttonCloseDiagram_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        buttonCloseDiagram_mouseReleased(e);
      }
    });
    buttonCloseDiagram.setBorder(null);

    MenuCDL.setText("CDL FIles");
    MenuCDL.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuCDL_actionPerformed(e);
      }
    });
    MenuTCDL.setText("TCDL Files");
    MenuTCDL.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuTCDL_actionPerformed(e);
      }
    });
    MenuShowDialog.setText("Show Dialog");
    imageNewDiagram.setDescription("");
    DrawArea.add(popupClass);
    DrawArea.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
      public void mouseDragged(MouseEvent e) {
        DrawArea_mouseDragged(e);
      }
      public void mouseMoved(MouseEvent e) {
        DrawArea_mouseMoved(e);
      }
    });
    DrawArea.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        DrawArea_mouseClicked(e);
      }
      public void mousePressed(MouseEvent e) {
        DrawArea_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        DrawArea_mouseReleased(e);
      }
    });

    MouseMove.setText("MouseMove");
    ExportMenu.setText("Export");
    MenuODL.setText("ODL Files");
    MenuODL.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuODL_actionPerformed(e);
      }
    });
    MenuTODL.setText("TODL Files");
    MenuTODL.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuTODL_actionPerformed(e);
      }
    });
    MenuExit.setText("Exit");
    MenuExit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        MenuExit_actionPerformed(e);
      }
    });
    buttonNewDiagram.setMaximumSize(new Dimension(25, 25));
    buttonNewDiagram.setMinimumSize(new Dimension(25, 25));
    buttonNewDiagram.setPreferredSize(new Dimension(25, 25));
    buttonNewDiagram.setToolTipText("New Diagram");
    buttonNewDiagram.setIcon(imageNewDiagram);
    buttonNewDiagram.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        buttonNewDiagram_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        buttonNewDiagram_mouseExited(e);
      }
      public void mousePressed(MouseEvent e) {
        buttonNewDiagram_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        buttonNewDiagram_mouseReleased(e);
      }
    });
    buttonNewDiagram.setBorder(null);

    buttonOpenDiagram.setMaximumSize(new Dimension(25, 25));
    buttonOpenDiagram.setToolTipText("Open Diagram");
    buttonOpenDiagram.setIcon(imageOpenDiagram);
    buttonOpenDiagram.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        buttonOpenDiagram_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        buttonOpenDiagram_mouseExited(e);
      }
      public void mousePressed(MouseEvent e) {
        buttonOpenDiagram_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        buttonOpenDiagram_mouseReleased(e);
      }
    });
    buttonOpenDiagram.setBorder(null);

    buttonSaveDiagram.setMaximumSize(new Dimension(25, 25));
    buttonSaveDiagram.setToolTipText("Save Diagram");
    buttonSaveDiagram.setIcon(imageSaveDiagram);
    buttonSaveDiagram.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        buttonSaveDiagram_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        buttonSaveDiagram_mouseExited(e);
      }
      public void mousePressed(MouseEvent e) {
        buttonSaveDiagram_mousePressed(e);
      }
      public void mouseReleased(MouseEvent e) {
        buttonSaveDiagram_mouseReleased(e);
      }
    });
    buttonSaveDiagram.setBorder(null);

    buttonExportDiagram.setMaximumSize(new Dimension(25, 25));
    buttonExportDiagram.setToolTipText("Export Files");
    buttonExportDiagram.setIcon(imageGenerateCode);
    buttonExportDiagram.setBorder(null);

    toolBarTool.setOrientation(JToolBar.VERTICAL);
    toolBarTool.setAlignmentX((float) 0.5);
    toolBarTool.setToolTipText("Tool Box");
    toolBarTool.setFloatable(false);
    toolBarTool.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonSelect.setMaximumSize(new Dimension(30, 30));
    toggleButtonSelect.setMinimumSize(new Dimension(30, 30));
    toggleButtonSelect.setPreferredSize(new Dimension(30, 30));
    toggleButtonSelect.setToolTipText("Select");
    toggleButtonSelect.setIcon(imageSelect);
    toggleButtonSelect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonSelect_actionPerformed(e);
      }
    });
    toggleButtonSelect.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonSelect_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonSelect_mouseExited(e);
      }
    });
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setMaximumSize(new Dimension(30, 30));
    toggleButtonClass.setToolTipText("Class");
    toggleButtonClass.setIcon(imageClass);
    toggleButtonClass.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonClass_actionPerformed(e);
      }
    });
    toggleButtonClass.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonClass_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonClass_mouseExited(e);
      }
    });
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setMaximumSize(new Dimension(30, 30));
    toggleButtonInheritance.setToolTipText("Generization");
    toggleButtonInheritance.setIcon(imageInheritance);
    toggleButtonInheritance.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonInheritance_actionPerformed(e);
      }
    });
    toggleButtonInheritance.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonInheritance_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonInheritance_mouseExited(e);
      }
    });
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setMaximumSize(new Dimension(30, 30));
    toggleButtonAssociation.setToolTipText("Association");
    toggleButtonAssociation.setIcon(imageAssociation);
    toggleButtonAssociation.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonAssociation_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonAssociation_mouseExited(e);
      }
    });
    toggleButtonAssociation.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonAssociation_actionPerformed(e);
      }
    });
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setMaximumSize(new Dimension(30, 30));
    toggleButtonAggregation.setToolTipText("Aggregation");
    toggleButtonAggregation.setIcon(imageAggregation);
    toggleButtonAggregation.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonAggregation_actionPerformed(e);
      }
    });
    toggleButtonAggregation.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonAggregation_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonAggregation_mouseExited(e);
      }
    });
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociationClass.setMaximumSize(new Dimension(30, 30));
    toggleButtonAssociationClass.setToolTipText("Association Class");
    toggleButtonAssociationClass.setIcon(imageAssociationClass);
    toggleButtonAssociationClass.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonAssociationClass_actionPerformed(e);
      }
    });
    toggleButtonAssociationClass.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonAssociationClass_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonAssociationClass_mouseExited(e);
      }
    });

    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setMaximumSize(new Dimension(30, 30));
    toggleButtonNary.setMinimumSize(new Dimension(21, 21));
    toggleButtonNary.setPreferredSize(new Dimension(21, 21));
    toggleButtonNary.setToolTipText("Ternary Association");
    toggleButtonNary.setIcon(imageNary);
    toggleButtonNary.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseEntered(MouseEvent e) {
        toggleButtonNary_mouseEntered(e);
      }
      public void mouseExited(MouseEvent e) {
        toggleButtonNary_mouseExited(e);
      }
    });
    toggleButtonNary.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleButtonNary_actionPerformed(e);
      }
    });

    statusBar.setBorder(BorderFactory.createLoweredBevelBorder());
    statusBar.setLayout(borderLayout2);
    toolBarFile.setFloatable(false);
    this.getContentPane().add(toolBarTool, BorderLayout.WEST);
    this.getContentPane().add(statusBar, BorderLayout.SOUTH);
    this.getContentPane().add(toolBarFile,  BorderLayout.NORTH);
    this.getContentPane().add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(DrawArea, null);
    this.setSize(800,600);
    this.setVisible(true);

    Menu.add(FileMenu);
    Menu.add(ExportMenu);
    Menu.add(ProjectMenu);

    FileMenu.add(MenuNew);
    FileMenu.add(MenuOpen);
    FileMenu.add(MenuSave);
    FileMenu.add(MenuSaveAs);
    FileMenu.add(MenuClose);
    FileMenu.addSeparator();
    FileMenu.add(MenuDelete);
    FileMenu.addSeparator();
    FileMenu.add(MenuExit);


    ExportMenu.add(MenuODL);
    ExportMenu.add(MenuTODL);
    ExportMenu.addSeparator();
    ExportMenu.add(MenuCDL);
    ExportMenu.add(MenuTCDL);
    ExportMenu.addSeparator();
    ExportMenu.add(MenuShowDialog);

    ProjectMenu.add(MenuProjectProperties);

    toolBarFile.add(buttonNewDiagram);
    toolBarFile.add(buttonOpenDiagram);
    toolBarFile.add(buttonSaveDiagram);
    toolBarFile.add(buttonCloseDiagram);
    toolBarFile.addSeparator();

    toolBarTool.add(toggleButtonSelect, null);
    toolBarTool.add(toggleButtonClass, null);
    toolBarTool.add(toggleButtonAssociation, null);
    toolBarTool.add(toggleButtonInheritance, null);
    toolBarTool.add(toggleButtonAggregation, null);
    toolBarTool.add(toggleButtonNary, null);

    buttonGroupTool.add(toggleButtonSelect);
    buttonGroupTool.add(toggleButtonClass);
    buttonGroupTool.add(toggleButtonInheritance);
    buttonGroupTool.add(toggleButtonAssociation);
    buttonGroupTool.add(toggleButtonAggregation);
    buttonGroupTool.add(toggleButtonNary);
    buttonGroupTool.add(toggleButtonAssociationClass);

    statusBar.add(MouseMove, BorderLayout.EAST);

    MenuDelete.setEnabled(false);

  }


//-------------------- Start Event Mouse ---------------

  void DrawArea_mouseClicked(MouseEvent e) {
      // Checking Calling Properties Dialog of Class with double click
      if ((toggleButtonSelect.isSelected())&&
         ((e.getModifiers()&e.BUTTON1_MASK) != 0)&&
          (e.getClickCount() >= 2)){
          if(CheckFigClass(pointX1,pointY1)){
//              jLabel2.setText("2 Click");
              FigClass selClass = (FigClass) vClass.elementAt(indexClass);
              pClass.loadProperties(vClass,indexClass);
              pClass.showDialog();
          } else if (CheckFigAssociation(pointX1,pointY1)){
              FigAssociationLine selALine = (FigAssociationLine) vAssociation.elementAt(indexAssociation);
              pAssociation.addNew(false);
              pAssociation.loadProperties(selALine);
              pAssociation.showDialog();
          } else if (CheckFigInheritance(pointX1,pointY1)){
              FigInheritanceLine selILine = (FigInheritanceLine) vInheritance.elementAt(indexInheritance);
              pInheritance.loadProperties(selILine);
              pInheritance.showDialog();
          } else if(CheckFigAggregation(pointX1,pointY1)){
              FigAggregationLine selAggLine = (FigAggregationLine) vAggregation.elementAt(indexAggregation);
              pAggregation.loadProperties(selAggLine);
              pAggregation.showDialog();
          } else if(CheckFigNary(pointX1,pointY1)){
              FigNary selNary = (FigNary) vTernary.elementAt(indexTernary);
              pNary.setNary(selNary);
              pNary.setClassVector(vClass);
              if (pNary.showDialog() == pNary.OK_OPTION) {
                ternaryUpdate(pNary.getNary());
              }
          }
          diagramModified(true);
      }

      //  Checking Calling Popup Menu of Class
      if (toggleButtonSelect.isSelected() &&
         e.isMetaDown() && CheckFigClass(pointX1,pointY1)) {
//         jLabel2.setText("Right Click");
         pClass.loadProperties(vClass,indexClass);
         popupClass.setEnvironment(DrawArea,vClass,indexClass);
         popupClass.setPropertiesClass(pClass);
         popupClass.setDeleteEnable(canDeleteClass((FigClass) vClass.elementAt(indexClass)));
         popupClass.show(DrawArea,pointX1,pointY1);
         diagramModified(true);
      }

      //  Checking Calling Popup Menu of Association
      if (toggleButtonSelect.isSelected() &&
          e.isMetaDown() && CheckFigAssociation(pointX1,pointY1)) {
          FigAssociationLine selALine = (FigAssociationLine) vAssociation.elementAt(indexAssociation);
          pAssociation.loadProperties(selALine);
          popupAssociation.setAll(DrawArea,vAssociation,indexAssociation,pAssociation);
          popupAssociation.show(DrawArea,pointX1,pointY1);
          diagramModified(true);
      }

      //  Checking Calling Popup Menu of Inheritance
      if (toggleButtonSelect.isSelected() &&
          e.isMetaDown() && CheckFigInheritance(pointX1,pointY1)) {
          FigInheritanceLine selALine = (FigInheritanceLine) vInheritance.elementAt(indexInheritance);
          pInheritance.loadProperties(selALine);
          popupInheritance.setAll(DrawArea,vInheritance,indexInheritance,pInheritance);
          popupInheritance.show(DrawArea,pointX1,pointY1);
          diagramModified(true);
      }

      //  Checking Calling Popup Menu of Aggregation
      if (toggleButtonSelect.isSelected() &&
          e.isMetaDown() && CheckFigAggregation(pointX1,pointY1)) {
          FigAggregationLine selALine = (FigAggregationLine) vAggregation.elementAt(indexAggregation);
          pAggregation.loadProperties(selALine);
          popupAggregation.setAll(DrawArea,vAggregation,indexAggregation,pAggregation);
          popupAggregation.show(DrawArea,pointX1,pointY1);
          diagramModified(true);
      }

      //  Checking Calling Popup Menu of Ternary
      if (toggleButtonSelect.isSelected() &&
          e.isMetaDown() && CheckFigNary(pointX1,pointY1)) {
          FigNary selTernary = (FigNary) vTernary.elementAt(indexTernary);
          popupTernary.setAll(DrawArea,vTernary,vFternaryLine,vSternaryLine,vTternaryLine,indexTernary);
          popupTernary.show(DrawArea,pointX1,pointY1);
          diagramModified(true);
      }

      // Create new class on draw area
      if((toggleButtonClass.isSelected())&&
        ((e.getModifiers()&e.BUTTON1_MASK) != 0)&&
         (e.getClickCount() == 1)&&
         (!CheckFigClass(pointX1,pointY1))){
          FigClass newClass = new FigClass(pointX1,pointY1);
          vClass.addElement(newClass);
          newClass.setBounds(pointX1,pointY1,80,100);
          newClass.setVisible(true);
          DrawArea.add(newClass,null);
          DrawArea.repaint();
          diagramModified(true);
      }

      // Create new Ternary Association Relation
      if ((toggleButtonNary.isSelected())&&
         ((e.getModifiers()&e.BUTTON1_MASK) != 0)&&
          (e.getClickCount() == 1)&&
          (!CheckNary(pointX1,pointY1))){
          FigNary newNary = new FigNary(pointX1-15,pointY1-15);
          pNary.setNary(newNary);
          pNary.setClassVector(vClass);
          if (pNary.showDialog() == pNary.OK_OPTION) {
            newNary = pNary.getNary();
            vTernary.addElement(newNary);
            newNary.setBounds(pointX1-15,pointY1-15,30,30);
            newNary.setVisible(true);
            FigNaryLine fNary = new FigNaryLine(newNary,newNary.getFClass(),"W");
            vFternaryLine.addElement(fNary);
            fNary.setBounds(pointX1,pointY1,5,5);
            fNary.setVisible(true);
            FigNaryLine sNary = new FigNaryLine(newNary,newNary.getSClass(),"E");
            vSternaryLine.addElement(sNary);
            sNary.setBounds(pointX1,pointY1,5,5);
            sNary.setVisible(true);
            FigNaryLine tNary = new FigNaryLine(newNary,newNary.getTClass(),"S");
            vTternaryLine.addElement(tNary);
            tNary.setBounds(pointX1,pointY1,5,5);
            tNary.setVisible(true);
            DrawArea.add(newNary,null);
            DrawArea.add(fNary,null);
            DrawArea.add(sNary,null);
            DrawArea.add(tNary,null);
            DrawArea.repaint();
            diagramModified(true);
          }
      }
  }

  void DrawArea_mouseMoved(MouseEvent e) {
    String mousepoint = new String("X : " + e.getX() + " Y : " + e.getY() + " ");
    MouseMove.setText(mousepoint);
    if (toggleButtonSelect.isSelected())
      DrawArea.setCursor(new Cursor(12));
    if (toggleButtonClass.isSelected())
      DrawArea.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursorClass,new Point(0,0),"cursorClass"));
    if (toggleButtonInheritance.isSelected())
      DrawArea.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursorInheritance,new Point(0,0),"cursorInheritance"));
    if (toggleButtonAssociation.isSelected())
      DrawArea.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursorAssociation,new Point(0,0),"cursorAssoication"));
    if (toggleButtonAggregation.isSelected())
      DrawArea.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursorAggregation,new Point(0,0),"cursorAggregation"));
    if (toggleButtonAssociationClass.isSelected())
      DrawArea.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursorAssociationClass,new Point(0,0),"cursorAssociationClass"));
    if (toggleButtonNary.isSelected())
      DrawArea.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(cursorNary,new Point(0,0),"cursorNary"));
  }

void DrawArea_mouseDragged(MouseEvent e) {
    String mousepoint = new String("X : " + e.getX() + " Y : " +e.getY());
//    jLabel2.setText(mousepoint);

    pointX2o = pointX2n;
    pointY2o = pointY2n;

    pointX2n = e.getX();
    pointY2n = e.getY();

// moving class picture on drawarea
    if(toggleButtonSelect.isSelected()) {
        moveClass();
        moveNary();
    }
  }


void DrawArea_mousePressed(MouseEvent e) {
    String mousepoint = new String("X : " + e.getX() + " Y : " +e.getY());
//    jLabel1.setText(mousepoint);
    pointX2n = pointX1 = e.getX();
    pointY2n = pointY1 = e.getY();
//    dragLine.setBeginPoint(e.getX(),e.getY());


/*    if(InheritanceButton.isSelected()){
      if(CheckFigClass(pointX1,pointY1)){
        FigClass _classPressed = (FigClass) vClass.elementAt(indexClass);
        pointX1 = _classPressed.getCX();
        pointY1 = _classPressed.getCY();
        String mouspoint = new String("X : " + pointX1 + " Y : " + pointY1 );
        jLabel1.setText(mouspoint);
      }
    }
*/

//------ toggleButtonSelect checking area
    if(toggleButtonSelect.isSelected()){
      if(CheckFigClass(pointX1,pointY1)){
//        jLabel1.setText("Click on Class");
      }
      CheckFigNary(pointX1,pointY1);
    }

//------ toggleButtonInheritance checking area
    if(toggleButtonInheritance.isSelected()){
      if(CheckFigClass(pointX1,pointY1)){
        FigClass _classPressed = (FigClass) vClass.elementAt(indexClass);
        pointX1 = _classPressed.getCX();
        pointY1 = _classPressed.getCY();
        String mouspoint = new String("X : " + pointX1 + " Y : " + pointY1 );
//        jLabel1.setText(mouspoint);
      }
    }

//------ toggleButtonAssociation checking area
    if(toggleButtonAssociation.isSelected()){
      if(CheckFigClass(pointX1,pointY1)){
        FigClass _classPressed = (FigClass) vClass.elementAt(indexClass);
        pointX1 = _classPressed.getCX();
        pointY1 = _classPressed.getCY();
        String mouspoint = new String("X : " + pointX1 + " Y : " + pointY1 );
//        jLabel1.setText(mouspoint);
      }
    }

// toggleButtonAssociation checking area
    if(toggleButtonAggregation.isSelected()){
      if(CheckFigClass(pointX1,pointY1)){
        FigClass _classPressed = (FigClass) vClass.elementAt(indexClass);
        pointX1 = _classPressed.getCX();
        pointY1 = _classPressed.getCY();
        String mouspoint = new String("X : " + pointX1 + " Y : " + pointY1 );
//        jLabel1.setText(mouspoint);
      }
    }

}

void DrawArea_mouseReleased(MouseEvent e) {
  int oldIndexClass = indexClass;

// toggleButtonInheritance checking destination class
  if(toggleButtonInheritance.isSelected()){
    if (CheckFigClass(e.getX(),e.getY())&&(oldIndexClass != -1)) {
      if (oldIndexClass != indexClass) {
        FigClass _classPressed = (FigClass) vClass.elementAt(oldIndexClass);
        FigClass _classReleased = (FigClass) vClass.elementAt(indexClass);
        if(!haveInheritance(_classPressed,_classReleased)){
          if(!haveInheritance(_classReleased,_classPressed)){
            FigInheritanceLine fLine = new FigInheritanceLine();
            fLine.setParentClass(_classPressed);
    //        fLine.setBeginCordinate(_classPressed.getCX(),_classPressed.getCY());
    //        fLine.setSizeSRC(_classPressed.Width(),_classPressed.high());
    //        fLine.setSrcID(_classPressed.getId());
            pointX2n = _classReleased.getCX();
            pointY2n = _classReleased.getCY();
            if (fLine.setInheritClass(_classReleased)) {
//              fLine.setEndCordinate(pointX2n,pointY2n);
//              fLine.setSizeDES(_classReleased.Width(),_classReleased.high());
//              fLine.setDesID(_classReleased.getId());
              fLine.setBounds(pointX1,pointY1,5,5);
              fLine.setVisible(true);

              vInheritance.addElement(fLine);
              DrawArea.add(fLine,null);
              DrawArea.repaint();
            }
          }else{
            JOptionPane.showMessageDialog(this,"Can't create this relationship.","TUML",JOptionPane.ERROR_MESSAGE);
          }
        }else {
          JOptionPane.showMessageDialog(this,"This relationship has already.\nCan't create again.","TUML",JOptionPane.ERROR_MESSAGE);
        }
//        jLabel1.setText(fLine.getSrcID());
      }
      diagramModified(true);
    }
  }

// toggleButtonAssociation checking destination class
  if(toggleButtonAssociation.isSelected()){
    if (CheckFigClass(e.getX(),e.getY())&&(oldIndexClass != -1)) {
      if (oldIndexClass != indexClass) {
        FigClass _classPressed = (FigClass) vClass.elementAt(oldIndexClass);
        FigClass _classReleased = (FigClass) vClass.elementAt(indexClass);
        if(!haveAssociation(_classPressed,_classReleased)){
            pAssociation.addNew(true);
            pAssociation.setSrcClass(_classPressed);
            pAssociation.setDesClass(_classReleased);
            pAssociation.showDialog();
        }else{
            JOptionPane.showMessageDialog(this,"Association between classes has already.\nCan't create again.","TUML",JOptionPane.ERROR_MESSAGE);
        }
      }
      diagramModified(true);
    }
  }

  if(toggleButtonAggregation.isSelected()){
    if (CheckFigClass(e.getX(),e.getY())&&(oldIndexClass != -1)) {
      if (oldIndexClass != indexClass) {
        FigClass _classPressed = (FigClass) vClass.elementAt(oldIndexClass);
        FigClass _classReleased = (FigClass) vClass.elementAt(indexClass);

        if(!haveAggregation(_classPressed,_classReleased)){
          pAggregation.addNew(true);
          pAggregation.setSrcClass(_classPressed);
          pAggregation.setAggregateClass(_classReleased);
          pAggregation.showDialog();
        }else
          JOptionPane.showMessageDialog(this,"Aggregation between classes has already.\nCan't create again.","TUML",JOptionPane.ERROR_MESSAGE);
/*
        FigAggregationLine fAggLine = new FigAggregationLine();
        fAggLine.setSrcClass(_classPressed); //.setSrcClass(_classPressed);
        fAggLine.setAggregateClass(_classReleased);
        fAggLine.setBounds(pointX1,pointY1,5,5);
        fAggLine.setVisible(true);

        vAggregation.addElement(fAggLine);
        DrawArea.add(fAggLine,null);
        DrawArea.repaint();
*/
      }
    diagramModified(true);
    }
  }

}

    public void addAssociation(){
        FigAssociationLine fALine = new FigAssociationLine();
        fALine.setSrcClass(pAssociation.getSrcClass());
        fALine.setDesClass(pAssociation.getDesClass());
        fALine.setBounds(pointX1,pointY1,5,5);
        fALine.setVisible(true);


        pAssociation.updateProperties(fALine);
        pAssociation.addNew(false);
        vAssociation.addElement(fALine);
        DrawArea.add(fALine,null);
        DrawArea.repaint();
    }

    public void addAggregation(){
        FigAggregationLine fAggLine = new FigAggregationLine();
        fAggLine.setSrcClass(pAggregation.getSrcClass());
        fAggLine.setAggregateClass(pAggregation.getAggregateClass());
        fAggLine.setBounds(pointX1,pointY1,5,5);
        fAggLine.setVisible(true);

        pAggregation.updateProperties(fAggLine);
        pAggregation.addNew(false);
        vAggregation.addElement(fAggLine);
        DrawArea.add(fAggLine,null);
        DrawArea.repaint();
    }

    public boolean canDeleteClass(FigClass fClass) {
      for (int i = 0 ; i < vInheritance.size();i++){
        FigInheritanceLine iLine = (FigInheritanceLine) vInheritance.elementAt(i);
        if ((fClass.getId() == iLine.getParentClass().getId()) ||
            (fClass.getId() == iLine.getInheritClass().getId()) )
          return false;
      }
      for (int i = 0 ; i < vAssociation.size();i++){
        FigAssociationLine aLine = (FigAssociationLine) vAssociation.elementAt(i);
        if ((fClass.getId() == aLine.getSrcClass().getId()) ||
            (fClass.getId() == aLine.getDesClass().getId()) )
          return false;
      }
      for (int i = 0 ; i < vAggregation.size();i++){
        FigAggregationLine gLine = (FigAggregationLine) vAggregation.elementAt(i);
        if ((fClass.getId() == gLine.getSrcClass().getId()) ||
            (fClass.getId() == gLine.getAggregationClass().getId()) )
          return false;
      }
      for (int i = 0 ; i < vTernary.size() ; i++){
        FigNary tLine = (FigNary) vTernary.elementAt(i);
        if ((fClass.getId() == tLine.getFClass().getId()) ||
            (fClass.getId() == tLine.getSClass().getId()) ||
            (fClass.getId() == tLine.getTClass().getId()))
          return false;
      }
      return true;
    }

    public boolean CheckFigClass(int x,int y){
      for (int i = 0 ; i < vClass.size() ; i++){
        FigClass checkClass = (FigClass) vClass.elementAt(i);
        if (checkClass.checkArea(x,y)){
          indexClass = i;
//          jLabel2.setText("Select on " + i);
          return true;
        }
      }
      indexClass = -1;
      return false;
    }

    public boolean CheckNary(int x,int y){
      for (int i = 0 ; i < vTernary.size() ; i++){
        FigNary checkNary = (FigNary) vTernary.elementAt(i);
        if (checkNary.checkArea(x,y)) {
          indexTernary = i;
          return true;
        }
      }
      indexClass = -1;
      return false;
    }

    public boolean CheckFigAssociation(int x,int y){
      for (int i = 0 ; i < vAssociation.size() ; i++){
        FigAssociationLine checkAssociation = (FigAssociationLine) vAssociation.elementAt(i);
        if (checkAssociation.checkArea(x,y)){
          indexAssociation = i;
          return true;
        }
      }
      indexAssociation = -1;
      return false;
    }

    public boolean CheckFigAggregation(int x,int y){
      for (int i = 0 ; i < vAggregation.size() ; i++){
        FigAggregationLine checkAggregation = (FigAggregationLine) vAggregation.elementAt(i);
        if (checkAggregation.checkArea(x,y)){
          indexAggregation = i;
          return true;
        }
      }
      indexAggregation = -1;
      return false;
    }


    public boolean CheckFigInheritance(int x,int y){
      for (int i = 0 ; i < vInheritance.size() ; i++){
        FigInheritanceLine checkInheritance = (FigInheritanceLine) vInheritance.elementAt(i);
        if (checkInheritance.checkArea(x,y)){
          indexInheritance = i;
          return true;
        }
      }
      indexInheritance = -1;
      return false;
    }

    public boolean CheckFigNary(int x,int y){
      for (int i = 0 ; i < vTernary.size() ; i++){
        FigNary checkTernary = (FigNary) vTernary.elementAt(i);
        if (checkTernary.checkArea(x,y)){
          indexTernary = i;
          return true;
        }
      }
      indexTernary = -1;
      return false;
    }


    public boolean haveInheritance(FigClass parent,FigClass inherit){
      int parentID = parent.getId();
      int inheritID = inherit.getId();
      for (int i = 0 ; i < vInheritance.size() ; i++){
        FigInheritanceLine checkInheritance = (FigInheritanceLine) vInheritance.elementAt(i);
        int Tparent = ((FigClass)checkInheritance.getParentClass()).getId();
        int Tinherit = ((FigClass)checkInheritance.getInheritClass()).getId();
        if ((Tparent == parentID )&&(Tinherit == inheritID))
//            ((Tparent == inheritID)&&(Tinherit == parentID))){
          return true;
      }
      return false;

    }

    public boolean haveAssociation(FigClass class1,FigClass class2){
      int class1ID = class1.getId();
      int class2ID = class2.getId();
      for (int i = 0 ; i < vAssociation.size() ; i++){
        FigAssociationLine checkAssociation = (FigAssociationLine) vAssociation.elementAt(i);
        int Tclass1 = ((FigClass)checkAssociation.getSrcClass()).getId();
        int Tclass2 = ((FigClass)checkAssociation.getDesClass()).getId();
        if (((Tclass1 == class1ID )&&(Tclass2 == class2ID))||
            ((Tclass1 == class2ID)&&(Tclass2 == class1ID)))
          return true;
      }
      return false;

    }

    public boolean haveAggregation(FigClass class1,FigClass class2){
      int class1ID = class1.getId();
      int class2ID = class2.getId();
      for (int i = 0 ; i < vAggregation.size() ; i++){
        FigAggregationLine checkAggregation = (FigAggregationLine) vAggregation.elementAt(i);
        int Tclass1 = ((FigClass)checkAggregation.getSrcClass()).getId();
        int Tclass2 = ((FigClass)checkAggregation.getAggregationClass()).getId();
        if (((Tclass1 == class1ID )&&(Tclass2 == class2ID))||
            ((Tclass1 == class2ID)&&(Tclass2 == class1ID)))
          return true;
      }
      return false;

    }

    public void moveClass(){
      if (indexClass != -1){
        FigClass moveClass = (FigClass) vClass.elementAt(indexClass);
        int newpointX = pointX2n - pointX2o + moveClass.PointX();
        int newpointY = pointY2n - pointY2o + moveClass.PointY();
        if((newpointX > 0)&&(newpointY > 0)){
          moveClass.setPoint(newpointX,newpointY);
          moveClass.setBounds(moveClass.PointX(),moveClass.PointY(),moveClass.Width(),moveClass.high());
          moveRelation(moveClass);
          moveAssociation(moveClass);
          moveAggregation(moveClass);
          moveNaryLine(moveClass);
        }
        diagramModified(true);
      }
    }

    public void moveNary(){
      if (indexTernary != -1){
        FigNary naryMoved = (FigNary) vTernary.elementAt(indexTernary);
        int newpointX = pointX2n - pointX2o + naryMoved.getX();
        int newpointY = pointY2n - pointY2o + naryMoved.getY();
        if ((newpointX > 0)&&(newpointY > 0)) {
          naryMoved.setX(newpointX);
          naryMoved.setY(newpointY);
          naryMoved.setBounds(newpointX,newpointY,naryMoved.getWidth(),naryMoved.getHeight());
          moveNaryLine(naryMoved);
        }
        diagramModified(true);
      }
    }

    public void moveRelation(FigClass classMoved) {
      for (int i = 0 ; i < vInheritance.size() ; i++) {
        FigInheritanceLine relationMoved = (FigInheritanceLine) vInheritance.elementAt(i);
        if (classMoved.getId() == relationMoved.getSrcID()) {
          relationMoved.setBeginCordinate(classMoved.getCX(),classMoved.getCY());
          relationMoved.setSizeSRC(classMoved.Width(),classMoved.high());
          relationMoved.setBounds();
        }
        if (classMoved.getId() == relationMoved.getDesID()) {
          relationMoved.setEndCordinate(classMoved.getCX(),classMoved.getCY());
          relationMoved.setSizeDES(classMoved.Width(),classMoved.high());
          relationMoved.setBounds();
        }
      }
    }

    public void moveAssociation(FigClass classMoved) {
      for (int i = 0 ; i < vAssociation.size() ; i++) {
        FigAssociationLine associationMoved = (FigAssociationLine) vAssociation.elementAt(i);
        if (classMoved.getId() == associationMoved.getSrcID()) {
          associationMoved.setBeginCordinate(classMoved.getCX(),classMoved.getCY());
          associationMoved.setSizeSRC(classMoved.Width(),classMoved.high());
          associationMoved.setBounds();
        }
        if (classMoved.getId() == associationMoved.getDesID()) {
          associationMoved.setEndCordinate(classMoved.getCX(),classMoved.getCY());
          associationMoved.setSizeDES(classMoved.Width(),classMoved.high());
          associationMoved.setBounds();
        }
      }
    }

    public void moveAggregation(FigClass classMoved) {
      for (int i = 0 ; i < vAggregation.size() ; i++) {
        FigAggregationLine aggregationMoved = (FigAggregationLine) vAggregation.elementAt(i);
        if (classMoved.getId() == aggregationMoved.getSrcID()) {
          aggregationMoved.setBeginCordinate(classMoved.getCX(),classMoved.getCY());
          aggregationMoved.setSizeSRC(classMoved.Width(),classMoved.high());
          aggregationMoved.setBounds();
        }
        if (classMoved.getId() == aggregationMoved.getDesID()) {
          aggregationMoved.setEndCordinate(classMoved.getCX(),classMoved.getCY());
          aggregationMoved.setSizeDES(classMoved.Width(),classMoved.high());
          aggregationMoved.setBounds();
        }
      }
    }

    public void moveNaryLine(FigClass classMoved) {
      for (int i = 0 ; i < vFternaryLine.size() ; i++) {
        FigNaryLine naryLineMoved = (FigNaryLine) vFternaryLine.elementAt(i);
        if (classMoved.getId() == naryLineMoved.getNaryClass().getId()) {
          naryLineMoved.setEndCordinate(classMoved.getCX(),classMoved.getCY());
          naryLineMoved.setSizeDES(classMoved.Width(),classMoved.high());
          naryLineMoved.setBounds();
        }
      }
      for (int i = 0 ; i < vSternaryLine.size() ; i++) {
        FigNaryLine naryLineMoved = (FigNaryLine) vSternaryLine.elementAt(i);
        if (classMoved.getId() == naryLineMoved.getNaryClass().getId()) {
          naryLineMoved.setEndCordinate(classMoved.getCX(),classMoved.getCY());
          naryLineMoved.setSizeDES(classMoved.Width(),classMoved.high());
          naryLineMoved.setBounds();
        }
      }
      for (int i = 0 ; i < vTternaryLine.size() ; i++) {
        FigNaryLine naryLineMoved = (FigNaryLine) vTternaryLine.elementAt(i);
        if (classMoved.getId() == naryLineMoved.getNaryClass().getId()) {
          naryLineMoved.setEndCordinate(classMoved.getCX(),classMoved.getCY());
          naryLineMoved.setSizeDES(classMoved.Width(),classMoved.high());
          naryLineMoved.setBounds();
        }
      }
    }

    public void moveNaryLine(FigNary naryMoved) {
      for (int i = 0 ; i < vFternaryLine.size() ; i++) {
        FigNaryLine naryLineMoved = (FigNaryLine) vFternaryLine.elementAt(i);
        if (naryMoved.getFClass().equals(naryLineMoved.getNaryClass())) {
          naryLineMoved.setBeginCordinate(naryMoved.getX(),naryMoved.getY());
          naryLineMoved.setBounds();
        }
      }
      for (int i = 0 ; i < vSternaryLine.size() ; i++) {
        FigNaryLine naryLineMoved = (FigNaryLine) vSternaryLine.elementAt(i);
        if (naryMoved.getSClass().equals(naryLineMoved.getNaryClass())) {
          naryLineMoved.setBeginCordinate(naryMoved.getX(),naryMoved.getY());
          naryLineMoved.setBounds();
        }
      }
      for (int i = 0 ; i < vTternaryLine.size() ; i++) {
        FigNaryLine naryLineMoved = (FigNaryLine) vTternaryLine.elementAt(i);
        if (naryMoved.getTClass().equals(naryLineMoved.getNaryClass())) {
          naryLineMoved.setBeginCordinate(naryMoved.getX(),naryMoved.getY());
          naryLineMoved.setBounds();
        }
      }
    }

    public void clrscr(){
      FigClass fClass = new FigClass();
      fClass.clear();
      vClass.removeAllElements();
      vInheritance.removeAllElements();
      vAssociation.removeAllElements();
      vAggregation.removeAllElements();
      vTernary.removeAllElements();
      vFternaryLine.removeAllElements();
      vSternaryLine.removeAllElements();
      vTternaryLine.removeAllElements();
      DrawArea.removeAll();
      DrawArea.repaint();
    }

    void attributeDelete(Oid oid) {
      try {
        Model.Attribute mAttr = new Model.Attribute(mFactory);
        mAttr._delete(oid);
        mAttr._close();
        mAttr = null;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    void classDelete(Oid oid){
      try {
        Model.Classes mClass = new Model.Classes(mFactory,oid);
        ListOfObjects mList = mClass.getlistAttribute();
        for (int i = 1 ; i <= mList._count() ; i++){
          attributeDelete(mList._getObjectAt(i));
        }
        mClass._close();
        mClass = new Model.Classes(mFactory);
        mClass._delete(oid);
        mClass._close();
        mClass = null;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    void inheritDelete(Oid oid){
      try {
        Model.InheritanceLine mLine = new Model.InheritanceLine(mFactory);
        mLine._delete(oid);
        mLine._close();
        mLine = null;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    void associaDelete(Oid oid){
      try {
        Model.AssociationLine mLine = new Model.AssociationLine(mFactory);
        mLine._delete(oid);
        mLine._close();
        mLine = null;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    void aggregaDelete(Oid oid){
      try {
        Model.AggregationLine mLine = new Model.AggregationLine(mFactory);
        mLine._delete(oid);
        mLine._close();
        mLine = null;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    void ternaryDelete(Oid oid){
      try {
        Model.TernaryLine mLine = new Model.TernaryLine(mFactory);
        mLine._delete(oid);
        mLine._close();
        mLine = null;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    void diagramDelete(){
      int value = JOptionPane.showConfirmDialog(this,"Are you sure to delete diagram?","TUML",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
      if (value == JOptionPane.YES_OPTION) {
      // yes, delete diagram sure
        if (pProject.getOid() == null) {
          clrscr();
        } else {
          clrscr();
          try {
            Model.Diagrams mDiagram = new Model.Diagrams(mFactory,pProject.getOid());
            ListOfObjects mList = mDiagram.getlistClasses();
            for (int i = 1 ; i <= mList._count() ; i++){
              classDelete(mList._getObjectAt(i));
            }
            mList = mDiagram.getlistRelationInheritance();
            for (int i = 1 ; i <= mList._count() ; i++){
              inheritDelete(mList._getObjectAt(i));
            }
            mList = mDiagram.getlistRelationAssociation();
            for (int i = 1 ; i <= mList._count() ; i++){
              associaDelete(mList._getObjectAt(i));
            }
            mList = mDiagram.getlistRelationAggregation();
            for (int i = 1 ; i <= mList._count() ; i++){
              aggregaDelete(mList._getObjectAt(i));
            }
            mList = mDiagram.getlistRelationTernary();
            for (int i = 1 ; i <= mList._count() ; i++){
              ternaryDelete(mList._getObjectAt(i));
            }
            mDiagram = new Model.Diagrams(mFactory);
            mDiagram._delete(pProject.getOid());
            mDiagram._close();
            mDiagram = null;
            pProject.setOid(null);
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      pProject.dispose();
      buttonCloseDiagram.setEnabled(false);
      MenuProjectProperties.setEnabled(false);
      MenuSaveAs.setEnabled(false);
      MenuSave.setEnabled(false);
      MenuClose.setEnabled(false);
      MenuDelete.setEnabled(false);
      jScrollPane1.setVisible(false);
      }
    }

    void ternaryUpdate(FigNary fNary){
      FigNaryLine naryLine = findTernaryLine(fNary,vFternaryLine);
      if (naryLine.getNaryClass().getOid() != fNary.getFClass().getOid()) {
        vFternaryLine.removeElement(naryLine);
        DrawArea.remove(naryLine);
        FigNaryLine fNaryLine = new FigNaryLine(fNary,fNary.getFClass(),"W");
        fNaryLine.setBounds(pointX1,pointY1,5,5);
        fNaryLine.setVisible(true);
        vFternaryLine.addElement(fNaryLine);
        DrawArea.add(fNaryLine,null);
        DrawArea.repaint();
      }
      naryLine = findTernaryLine(fNary,vSternaryLine);
      if (naryLine.getNaryClass().getOid() != fNary.getSClass().getOid()) {
        vSternaryLine.removeElement(naryLine);
        DrawArea.remove(naryLine);
        FigNaryLine fNaryLine = new FigNaryLine(fNary,fNary.getSClass(),"E");
        fNaryLine.setBounds(pointX1,pointY1,5,5);
        fNaryLine.setVisible(true);
        vSternaryLine.addElement(fNaryLine);
        DrawArea.add(fNaryLine,null);
        DrawArea.repaint();
      }
      naryLine = findTernaryLine(fNary,vTternaryLine);
      if (naryLine.getNaryClass().getOid() != fNary.getTClass().getOid()) {
        vTternaryLine.removeElement(naryLine);
        DrawArea.remove(naryLine);
        FigNaryLine fNaryLine = new FigNaryLine(fNary,fNary.getTClass(),"S");
        fNaryLine.setBounds(pointX1,pointY1,5,5);
        fNaryLine.setVisible(true);
        vTternaryLine.addElement(fNaryLine);
        DrawArea.add(fNaryLine,null);
        DrawArea.repaint();
      }
    }

    FigNaryLine findTernaryLine(FigNary nary,Vector vNaryline) {
      FigNaryLine naryLine = null;
      int i = 0;
      while (i <= vNaryline.size()) {
        naryLine = (FigNaryLine) vNaryline.elementAt(i);
        if (naryLine.getNary().getOid() == nary.getOid())
          return naryLine;
        i++;
      }
      return naryLine;
    }

    void diagramOpen(){
      if (!okToAbandon()) {
        return;
      }

      OpenDialog openDialog = new OpenDialog(this,"",true);
      openDialog.setFactory(mFactory);
      openDialog.show();

      pProject = new PropertiesProject(this,"Diagram Properties",true);
      pProject.setOid(openDialog.getSelectedOid());
      if (pProject.getOid() != null){
        clrscr();
        LoadDatabase loadDB = new LoadDatabase(mFactory);
        loadDB.Load(pProject);

        vClass = loadDB.getVClass();
        vInheritance = loadDB.getVInheritance();
        vAssociation = loadDB.getVAssociation();
        vAggregation = loadDB.getVAggregation();
        vTernary     = loadDB.getVTernary();
        for (int i = 0;i < vClass.size();i++) {
          DrawArea.add((FigClass) vClass.elementAt(i),null);
        }
        for (int i = 0;i < vInheritance.size();i++) {
          FigInheritanceLine fLine = (FigInheritanceLine) vInheritance.elementAt(i);
          DrawArea.add(fLine,null);
          fLine.setBounds();
        }
        for (int i = 0;i < vAssociation.size();i++) {
          FigAssociationLine fAsso = (FigAssociationLine) vAssociation.elementAt(i);
          DrawArea.add(fAsso,null);
          fAsso.setBounds();
        }
        for (int i = 0;i < vAggregation.size();i++) {
          FigAggregationLine fAggr = (FigAggregationLine) vAggregation.elementAt(i);
          DrawArea.add(fAggr,null);
          fAggr.setBounds();
        }
        for (int i = 0;i < vTernary.size();i++) {
          FigNary fNary = (FigNary) vTernary.elementAt(i);
          DrawArea.add(fNary,null);
          fNary.setBounds();
          FigNaryLine fNaryLine = new FigNaryLine(fNary,fNary.getFClass(),"W");
          FigNaryLine sNaryLine = new FigNaryLine(fNary,fNary.getSClass(),"E");
          FigNaryLine tNaryLine = new FigNaryLine(fNary,fNary.getTClass(),"S");
          vFternaryLine.addElement(fNaryLine);
          vSternaryLine.addElement(sNaryLine);
          vTternaryLine.addElement(tNaryLine);
          fNaryLine.setBounds(pointX1,pointY1,5,5);
          sNaryLine.setBounds(pointX1,pointY1,5,5);
          tNaryLine.setBounds(pointX1,pointY1,5,5);
          DrawArea.add(fNaryLine,null);
          DrawArea.add(sNaryLine,null);
          DrawArea.add(tNaryLine,null);
        }
      DrawArea.repaint();
      ExportMenu.setEnabled(true);
      MenuProjectProperties.setEnabled(true);
      MenuSave.setEnabled(true);
      MenuSaveAs.setEnabled(true);
      MenuClose.setEnabled(true);
      MenuDelete.setEnabled(true);
      buttonSaveDiagram.setEnabled(true);
      buttonCloseDiagram.setEnabled(true);
      jScrollPane1.setVisible(true);
      diagramModified(false);
      }
    }

    void diagramNew() {
      if (!okToAbandon()) {
        return;
      }
      jScrollPane1.setVisible(true);
      modified = false;
      pProject = new PropertiesProject(this,"Diagram Properties",true);
      MenuProjectProperties.setEnabled(true);
      MenuSave.setEnabled(true);
      MenuDelete.setEnabled(false);
      buttonSaveDiagram.setEnabled(true);
      buttonCloseDiagram.setEnabled(true);
      clrscr();
    }

    void diagramSave() {
      if (pProject.getName().length() == 0)
          pProject.showDialog();
      if (pProject.getName().length() != 0) {
          SaveDatabase saveDB = new SaveDatabase(mFactory);
          saveDB.setDiagram(pProject);
          saveDB.setClass(vClass);
          saveDB.setInheritance(vInheritance);
          saveDB.setAssociation(vAssociation);
          saveDB.setAggregation(vAggregation);
          saveDB.setTernary(vTernary);
          if (pProject.getOid() == null) {
            saveDB.Save();
          } else {
            saveDB.Update();
          }
          MenuDelete.setEnabled(true);
          MenuClose.setEnabled(true);
          diagramModified(false);
        }
    }

    void diagramSaveAs() {
      int value = pProject.showDialog();
      if (value == pProject.OK_OPTION) {
        SaveDatabase saveDB = new SaveDatabase(mFactory);
        saveDB.setDiagram(pProject);
        saveDB.setClass(vClass);
        saveDB.setInheritance(vInheritance);
        saveDB.setAssociation(vAssociation);
        saveDB.setAggregation(vAggregation);
        saveDB.setTernary(vTernary);
        saveDB.Save();

        MenuDelete.setEnabled(true);
        MenuClose.setEnabled(true);
        diagramModified(false);
      }
    }

    void diagramClose() {
      if (!okToAbandon()) {
        return;
      }
      clrscr();
      pProject.dispose();
      ExportMenu.setEnabled(false);
      MenuProjectProperties.setEnabled(false);
      MenuSave.setEnabled(false);
      MenuSaveAs.setEnabled(false);
      MenuClose.setEnabled(false);
      MenuDelete.setEnabled(false);
      buttonSaveDiagram.setEnabled(false);
      buttonCloseDiagram.setEnabled(false);
      jScrollPane1.setVisible(false);
    }

  void diagramModified(boolean t) {
    modified = t;
    buttonSaveDiagram.setEnabled(t);
    MenuSave.setEnabled(t);
  }

  // Check if diagram is modified.
  // If so get user to make a "Save? yes/no/cancel" decision.
  boolean okToAbandon() {
    if (!modified) {
      return true;
    }
    int value =  JOptionPane.showConfirmDialog(this, "Save changes?",
                                         "Confirm Message", JOptionPane.YES_NO_CANCEL_OPTION) ;
    switch (value) {
       case JOptionPane.YES_OPTION:
         // yes, please save changes
         diagramSave();
         return true;//saveFile();
       case JOptionPane.NO_OPTION:
         // no, abandon edits
         // i.e. return true without saving
         diagramModified(false);
         return true;
       case JOptionPane.CANCEL_OPTION:
       default:
         // cancel
         return false;
    }
  }


  void this_windowActivated(WindowEvent e) {
      if(pAssociation.isAddNew())
        addAssociation();
      if(pAggregation.isAddNew())
        addAggregation();

      DrawArea.repaint();
  }

  void MenuODL_actionPerformed(ActionEvent e) {
    if(pProject.checkDetail()){
        int returnVal = dirChoose.showDialog(this,"OK");
        if(returnVal == 0){
          File file = dirChoose.getSelectedFile();
          _generatorODL.loadProjectProperties(pProject.getName(),pProject.getPackage(),pProject.getDesigner(),pProject.getDescription());
          _generatorODL.genCode(file.getPath(),vClass,vInheritance,vAssociation,vAggregation,vTernary);
          if(MenuShowDialog.isSelected())
            _generatorODL.showDialog();
        }
    }else
      JOptionPane.showMessageDialog(this,"Please insert detail of diagram","TUML",JOptionPane.ERROR_MESSAGE);
  }

//      _generatorTODL.genCode(vClass,vInheritance,vAssociation,vAggregation);
//      _generatorTODL.showDialog();

  void MenuTODL_actionPerformed(ActionEvent e) {
    if(pProject.checkDetail()){
      int returnVal = dirChoose.showDialog(this,"OK");
      if(returnVal == 0){
        File file = dirChoose.getSelectedFile();
        _generatorTemporalODL.loadProjectProperties(pProject.getName(),pProject.getPackage(),pProject.getDesigner(),pProject.getDescription());
        _generatorTemporalODL.genCode(file.getPath(),vClass,vInheritance,vAssociation,vAggregation,vTernary);
        if(MenuShowDialog.isSelected())
          _generatorTemporalODL.showDialog();
      }
    }else
      JOptionPane.showMessageDialog(this,"Please insert detail of diagram","TUML",JOptionPane.ERROR_MESSAGE);
  }

  void MenuCDL_actionPerformed(ActionEvent e) {
    if(pProject.checkDetail()){
      int returnVal = dirChoose.showDialog(this,"OK");
      if(returnVal == 0){
        File file = dirChoose.getSelectedFile();
        _generatorCDL.loadProjectProperties(pProject.getName(),pProject.getPackage(),pProject.getDesigner(),pProject.getDescription());
        _generatorCDL.genCode(file.getPath(),vClass,vInheritance,vAssociation,vAggregation,vTernary);

        if(MenuShowDialog.isSelected())
          _generatorCDL.showDialog();
      }
    }else
      JOptionPane.showMessageDialog(this,"Please insert detail of diagram","TUML",JOptionPane.ERROR_MESSAGE);
  }


  void MenuTCDL_actionPerformed(ActionEvent e) {
    if(pProject.checkDetail()){
      int returnVal = dirChoose.showDialog(this,"OK");
      if(returnVal == 0){
        File file = dirChoose.getSelectedFile();
        _generatorTCDL.loadProjectProperties(pProject.getName(),pProject.getPackage(),pProject.getDesigner(),pProject.getDescription());
        _generatorTCDL.genCode(file.getPath(),vClass,vInheritance,vAssociation,vAggregation,vTernary);

        if(MenuShowDialog.isSelected())
          _generatorTCDL.showDialog();
      }
    }else
      JOptionPane.showMessageDialog(this,"Please insert detail of diagram","TUML",JOptionPane.ERROR_MESSAGE);
  }



  void this_windowClosing(WindowEvent e) {
    try {
//      mFactory.close();
//      mFactory = null;
      System.exit(0);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

/** toolBarFile | buttonNewDiagram mouse event */
  void buttonNewDiagram_mouseEntered(MouseEvent e) {
    buttonNewDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void buttonNewDiagram_mouseExited(MouseEvent e) {
    buttonNewDiagram.setBorder(BorderFactory.createEmptyBorder());
  }
  void buttonNewDiagram_mousePressed(MouseEvent e) {
    buttonNewDiagram.setBorder(BorderFactory.createLoweredBevelBorder());
  }
  void buttonNewDiagram_mouseReleased(MouseEvent e) {
    buttonNewDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }

/** toolBarFile | buttonOpen Diagram mouse event */
  void buttonOpenDiagram_mouseEntered(MouseEvent e) {
    buttonOpenDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void buttonOpenDiagram_mouseExited(MouseEvent e) {
    buttonOpenDiagram.setBorder(BorderFactory.createEmptyBorder());
  }
  void buttonOpenDiagram_mousePressed(MouseEvent e) {
    buttonOpenDiagram.setBorder(BorderFactory.createLoweredBevelBorder());
  }
  void buttonOpenDiagram_mouseReleased(MouseEvent e) {
    buttonOpenDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }

/** toolBarFile | buttonSave Diagram mouse event */
  void buttonSaveDiagram_mouseEntered(MouseEvent e) {
    buttonSaveDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void buttonSaveDiagram_mouseExited(MouseEvent e) {
    buttonSaveDiagram.setBorder(BorderFactory.createEmptyBorder());
  }
  void buttonSaveDiagram_mousePressed(MouseEvent e) {
    buttonSaveDiagram.setBorder(BorderFactory.createLoweredBevelBorder());
  }
  void buttonSaveDiagram_mouseReleased(MouseEvent e) {
    buttonSaveDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }

/** toolBarFile | buttonClose Diagram mouse event */
  void buttonCloseDiagram_mouseEntered(MouseEvent e) {
    buttonCloseDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }

  void buttonCloseDiagram_mouseExited(MouseEvent e) {
    buttonCloseDiagram.setBorder(BorderFactory.createEmptyBorder());
  }

  void buttonCloseDiagram_mousePressed(MouseEvent e) {
    buttonCloseDiagram.setBorder(BorderFactory.createLoweredBevelBorder());
  }

  void buttonCloseDiagram_mouseReleased(MouseEvent e) {
    buttonCloseDiagram.setBorder(BorderFactory.createRaisedBevelBorder());
  }

/** toolBarTool | toggleButtonSelect mouse event */
  void toggleButtonSelect_mouseEntered(MouseEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void toggleButtonSelect_mouseExited(MouseEvent e) {
    if (toggleButtonSelect.isSelected())
      toggleButtonSelect.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
  }
  void toggleButtonSelect_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

/** toolBarTool | toggleButtonClass mouse event */
  void toggleButtonClass_mouseEntered(MouseEvent e) {
    toggleButtonClass.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void toggleButtonClass_mouseExited(MouseEvent e) {
    if (toggleButtonClass.isSelected())
      toggleButtonClass.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
  }
  void toggleButtonClass_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

/** toolBarTool | toggleButtonAssociation mouse event */
  void toggleButtonAssociation_mouseEntered(MouseEvent e) {
    toggleButtonAssociation.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void toggleButtonAssociation_mouseExited(MouseEvent e) {
    if (toggleButtonAssociation.isSelected())
      toggleButtonAssociation.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
  }
  void toggleButtonAssociation_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

/** toolBarTool | toggleButtonInheritance mouse event */
  void toggleButtonInheritance_mouseEntered(MouseEvent e) {
    toggleButtonInheritance.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void toggleButtonInheritance_mouseExited(MouseEvent e) {
    if (toggleButtonInheritance.isSelected())
      toggleButtonInheritance.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
  }
  void toggleButtonInheritance_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

/** toolBarTool | toggleButtonAggregation mouse event */
  void toggleButtonAggregation_mouseEntered(MouseEvent e) {
    toggleButtonAggregation.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void toggleButtonAggregation_mouseExited(MouseEvent e) {
    if (toggleButtonAggregation.isSelected())
      toggleButtonAggregation.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
  }
  void toggleButtonAggregation_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

/** toolBarTool | toggleButtonNary mouse event */
  void toggleButtonNary_mouseEntered(MouseEvent e) {
    toggleButtonNary.setBorder(BorderFactory.createRaisedBevelBorder());
  }

  void toggleButtonNary_mouseExited(MouseEvent e) {
    if (toggleButtonNary.isSelected())
      toggleButtonNary.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

  void toggleButtonNary_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonNary.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
  }


/** toolBarTool | toggleButtonAssociationClass mouse event */
  void toggleButtonAssociationClass_mouseEntered(MouseEvent e) {
    toggleButtonAssociationClass.setBorder(BorderFactory.createRaisedBevelBorder());
  }
  void toggleButtonAssociationClass_mouseExited(MouseEvent e) {
    if (toggleButtonAssociationClass.isSelected())
      toggleButtonAssociationClass.setBorder(BorderFactory.createLoweredBevelBorder());
    else
      toggleButtonAssociationClass.setBorder(BorderFactory.createEtchedBorder());
  }
  void toggleButtonAssociationClass_actionPerformed(ActionEvent e) {
    toggleButtonSelect.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonClass.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonInheritance.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAggregation.setBorder(BorderFactory.createEtchedBorder());
    toggleButtonAssociationClass.setBorder(BorderFactory.createLoweredBevelBorder());
    toggleButtonNary.setBorder(BorderFactory.createEtchedBorder());
  }

  void MenuNew_actionPerformed(ActionEvent e) {
    diagramNew();
  }

  void MenuOpen_actionPerformed(ActionEvent e) {
    diagramOpen();
  }

  void MenuSave_actionPerformed(ActionEvent e) {
    diagramSave();
  }

  void MenuSaveAs_actionPerformed(ActionEvent e) {
    diagramSaveAs();
  }

  void MenuClose_actionPerformed(ActionEvent e) {
    diagramClose();
  }

  void MenuDelete_actionPerformed(ActionEvent e) {
    diagramDelete();
  }

  void MenuExit_actionPerformed(ActionEvent e) {
//    try {
//      mFactory.close();
//      mFactory = null;
      System.exit(0);
//    } catch (Exception ex) {
//      ex.printStackTrace();
//    }
  }

  void MenuProjectProperties_actionPerformed(ActionEvent e) {
    if (pProject.OK_OPTION == pProject.showDialog())
      diagramModified(true);
  }

  void buttonNewDiagram_actionPerformed(ActionEvent e) {
    diagramNew();
  }

  void buttonSaveDiagram_actionPerformed(ActionEvent e) {
    diagramSave();
  }

  void buttonOpenDiagram_actionPerformed(ActionEvent e) {
    diagramOpen();
  }

  void buttonCloseDiagram_actionPerformed(ActionEvent e) {
    diagramClose();
  }



}



