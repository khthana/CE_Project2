package tumltool;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class Granularity {
  static private String defaultGranularity[] = {"Year","Month","Day","Hour","Minute","Second"};
  public Granularity() {

  }

  static public String[] getDefault(){
    return defaultGranularity;
  }

  static public String getGranularity(int gr){
    if(gr < 6)
      return defaultGranularity[gr];
    return "Error";
  }

  static public int getIndexOf(String gr){
    if(gr.compareToIgnoreCase(defaultGranularity[0]) == 0)
      return 0;
    if(gr.compareToIgnoreCase(defaultGranularity[1]) == 0)
      return 1;
    if(gr.compareToIgnoreCase(defaultGranularity[2]) == 0)
      return 2;
    if(gr.compareToIgnoreCase(defaultGranularity[3]) == 0)
      return 3;
    if(gr.compareToIgnoreCase(defaultGranularity[4]) == 0)
      return 4;
    if(gr.compareToIgnoreCase(defaultGranularity[5]) == 0)
      return 5;

    return -1;
  }

  static public int maxGanularity(){
    return defaultGranularity.length;
  }

}