package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesClass extends JDialog {
  JPanel panelGeneral = new JPanel();
  JLabel iNameLabel = new JLabel();
  JTextField iName = new JTextField();
  JLabel labelTimeType = new JLabel();
  JLabel labelGranularity = new JLabel();
  JComboBox iTimeType = new JComboBox();
  JScrollPane scrollPaneAttributes = new JScrollPane();
  AttrJTable attrTable = new AttrJTable();
  JButton attrAdd = new JButton();
  JButton attrDelete = new JButton();
  JButton attrEdit = new JButton();
  JButton pUpdate = new JButton();
  JButton pClose = new JButton();
  String columns[] = {"Name", "Collect",  "Type", "TimeType"};
  String rows[][] = { };
  FigClass pInter;
  int selClass;
  Vector allClass;
  Vector cAttr;
  Vector newSetAttr = new Vector();

  Frame _tumlFrame[] = TUMLTool.getFrames();
  PropertiesAttribute pAttr = new PropertiesAttribute(_tumlFrame[0],"",true);
//  ErrorDialog eDialog = new ErrorDialog(_tumlFrame[1],"",true);
  JComboBox iGranularity = new JComboBox();
  JPanel panelButton = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JTabbedPane TabbedPane = new JTabbedPane();
  JPanel panelAttributes = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel panelAttributesButton = new JPanel();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  VerticalFlowLayout verticalFlowLayout2 = new VerticalFlowLayout();
  JLabel labelDescription = new JLabel();
  JTextArea textAreaDescription = new JTextArea();
  JPanel panelTimeType = new JPanel();
  GridLayout gridLayout1 = new GridLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  JScrollPane scrollPaneDocument = new JScrollPane();

  public PropertiesClass(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropertiesClass() {
    this(null, "", false);
  }

  void jbInit() throws Exception {
    panelGeneral.setLayout(verticalFlowLayout2);
    iNameLabel.setText("Class Name:");
    iName.setToolTipText("");
    labelTimeType.setText("Timestamp Category:");
    labelGranularity.setText("Granularity:");
    attrAdd.setMnemonic('A');
    attrAdd.setText("Add...");
    attrAdd.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        attrAdd_actionPerformed(e);
      }
    });
    attrDelete.setText("Remove");
    attrDelete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        attrDelete_actionPerformed(e);
      }
    });
    attrEdit.setMnemonic('E');
    attrEdit.setText("Edit...");
    attrEdit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        attrEdit_actionPerformed(e);
      }
    });
    pUpdate.setText("OK");
    pUpdate.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        pUpdate_actionPerformed(e);
      }
    });
    pClose.setText("Cancel");
    pClose.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        pClose_actionPerformed(e);
      }
    });

    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowActivated(WindowEvent e) {
        this_windowActivated(e);
      }
    });

/*    pAttr.ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        update_table();
      }
    });
*/
    iTimeType.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        iTimeType_itemStateChanged(e);
      }
    });
    panelButton.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    panelAttributes.setLayout(borderLayout1);
    panelAttributesButton.setLayout(verticalFlowLayout1);
    labelDescription.setText("Description:");
    textAreaDescription.setBorder(BorderFactory.createLoweredBevelBorder());
    textAreaDescription.setRows(9);
    panelTimeType.setLayout(gridLayout1);
    gridLayout1.setRows(2);
    gridLayout1.setColumns(2);
    gridLayout1.setHgap(10);
    scrollPaneAttributes.setPreferredSize(new Dimension(300, 300));
    scrollPaneDocument.setPreferredSize(new Dimension(277, 200));
    this.setTitle("Class Properties");
    panelTimeType.add(labelTimeType, null);
    panelTimeType.add(labelGranularity, null);
    panelTimeType.add(iTimeType, null);
    panelTimeType.add(iGranularity, null);

    panelGeneral.add(iNameLabel, null);
    panelGeneral.add(iName, null);
    panelGeneral.add(panelTimeType, null);
    panelGeneral.add(labelDescription, null);

    this.getContentPane().setLayout(borderLayout2);
    panelButton.add(pUpdate, null);
    panelButton.add(pClose, null);
    this.getContentPane().add(TabbedPane, BorderLayout.CENTER);
    TabbedPane.add(panelGeneral,  "General");
    TabbedPane.add(panelAttributes,  "Attributes");
    scrollPaneAttributes.getViewport().add(attrTable, null);
    panelAttributes.add(scrollPaneAttributes, BorderLayout.CENTER);
    panelAttributes.add(panelAttributesButton,  BorderLayout.EAST);
    panelAttributesButton.add(attrAdd,null);
    panelAttributesButton.add(attrEdit,null);
    panelAttributesButton.add(attrDelete,null);
    this.getContentPane().add(panelButton, BorderLayout.SOUTH);
    panelGeneral.add(scrollPaneDocument, null);
    scrollPaneDocument.getViewport().add(textAreaDescription, null);

/*    iTimeType.addItem(st);
    iTimeType.addItem(vt);
    iTimeType.addItem(tt);
    iTimeType.addItem(bt);
*/
    iTimeType.addItem(TimeType.getsTimeType(0));
    iTimeType.addItem(TimeType.getsTimeType(1));
    iTimeType.addItem(TimeType.getsTimeType(2));
    iTimeType.addItem(TimeType.getsTimeType(3));

    iGranularity.addItem(Granularity.getGranularity(0));
    iGranularity.addItem(Granularity.getGranularity(1));
    iGranularity.addItem(Granularity.getGranularity(2));
    iGranularity.addItem(Granularity.getGranularity(3));
    iGranularity.addItem(Granularity.getGranularity(4));
    iGranularity.addItem(Granularity.getGranularity(5));

    attrTable.setDataVector(rows,columns);
    attrTable.setSelectionMode(0); // Single Selection on Table
  }

//  void loadProperties(FigClass selInterface){
  public void loadProperties(Vector setofClass,int indexClass){

    allClass = setofClass;
    selClass = indexClass;

    pInter = (FigClass) setofClass.elementAt(indexClass);

    iName.setText(pInter.getName());
    cAttr = pInter.getAttribute();
    copyAttr(cAttr,newSetAttr);
    loadAttribute2Table(newSetAttr);
    iTimeType.setSelectedItem(pInter.getTimeType());
    iGranularity.setSelectedItem(pInter.getGranularity());
    textAreaDescription.setText(pInter.getDescriptions());
  }


  private void copyAttr(Vector v1,Vector v2){
//    v2 = v1;
    v2.removeAllElements();
    structureAttribute attr;
    for(int i = 1 ; i <= v1.size() ; i++ ){
      attr = new structureAttribute();
      attr.Copy((structureAttribute) v1.elementAt(i-1));
      v2.addElement(attr);
    }

  }

  private void clearTable(){
    for(int i = attrTable.getRowCount(); i > 0 ; i--)
      attrTable.removeRow(0);
  }

  private void loadAttribute2Table(Vector attr){
    structureAttribute a;
    clearTable();
    int i = attr.size();
    for(i = attr.size() ; i > 0 ; i--){
      a = (structureAttribute) attr.elementAt(i-1);
      attrTable.insertRow(0,rows);

      attrTable.setValueAt(a.getName(),0,0);
      attrTable.setValueAt(a.getCollect(),0,1);
      attrTable.setValueAt(a.getType(),0,2);
      attrTable.setValueAt(a.getsTimeStamp(),0,3);
    }

    checkTimeType();
    checkGranularity();
  }


  public void pUpdate_actionPerformed(ActionEvent e) {
    if(checkName()){
      pInter.setName(iName.getText());
      pInter.setTimeType(iTimeType.getSelectedItem().toString());
      pInter.setGranularity(iGranularity.getSelectedItem().toString());
      pInter.setDescriptions(textAreaDescription.getText());
      copyAttr(newSetAttr,cAttr);
      this.setVisible(false);
    }else
/*      eDialog.setErrorText("This class's name has already in use.\nOr class must have name.");
      eDialog.showDialog();
*/
      JOptionPane.showMessageDialog(this,"This class's name has already in use.\nOr class must have name.","TUML",JOptionPane.INFORMATION_MESSAGE);

  }

  void pClose_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }

  public void attrAdd_actionPerformed(ActionEvent e) {
    pAttr.checkTimeType(TimeType.getiTimeType((String) iTimeType.getSelectedItem()));
    pAttr.checkGranularity((String) iGranularity.getSelectedItem());
    pAttr.addAttribute(newSetAttr);
//    pAttr.setLocation(220,150);
    pAttr.showDialog();
  }

  public void attrEdit_actionPerformed(ActionEvent e) {
    int i = attrTable.getSelectedRow();
    if(i >= 0){
      pAttr.checkTimeType(TimeType.getiTimeType((String) iTimeType.getSelectedItem()));
      pAttr.checkGranularity((String) iGranularity.getSelectedItem());
      pAttr.loadInformation(newSetAttr,i);

//      pAttr.setLocation(220,150);
      pAttr.showDialog();
    }
  }

  void this_windowActivated(WindowEvent e) {
/*    if(pAttr.isVisible())
      pAttr.setVisible(true);
    if(eDialog.isVisible())
      eDialog.showDialog();
*/
    loadAttribute2Table(newSetAttr);
  }

  public void attrDelete_actionPerformed(ActionEvent e) {
    int i = attrTable.getSelectedRow()  ;
    if(i >= 0){
      newSetAttr.removeElementAt(i);
      loadAttribute2Table(newSetAttr);
    }
  }

  private boolean checkName(){
    int max = allClass.size();
    String name = iName.getText();
    if (haveSpace(name))
      return false;
    FigClass c;
    for(int i = 0;  i < max ; i++){
        c = (FigClass) allClass.elementAt(i);
        if( name.equals(c.getName()) && (i != selClass))
          return false;
    }
    return true;
  }

  private boolean haveSpace(String str){
    int i = str.indexOf(" ");
    return ((str.length() == 0)||(i >= 0)) ? true : false;
  }

  private void iTimeType_itemStateChanged(ItemEvent e) {
    String selItem = (String) iTimeType.getSelectedItem();
    if((selItem == TimeType.getsTimeType(1))||
       (selItem == TimeType.getsTimeType(3))){
      iGranularity.setVisible(true);
      iGranularity.setEnabled(true);
//      iGranularity.setSelectedItem();
    }
//    else{
    if(selItem == TimeType.getsTimeType(2)){
      iGranularity.setVisible(true);
      iGranularity.setEnabled(false);
      iGranularity.setSelectedItem("Second");
    }
    if(selItem == TimeType.getsTimeType(0))
      iGranularity.setVisible(false);
  }

  private void checkTimeType(){
//    String gr = (String) iGranularity.getSelectedItem();
    String focus = (String) iTimeType.getSelectedItem();
    iTimeType.removeAllItems();
    int result1 = lookAttrTimeType();
    int result2 = lookAssociationTimeType();
    int result3 = (result1 > result2) ? result1 : result2;
    switch(result3){
      case 0 : iTimeType.addItem(TimeType.getsTimeType(0));
               iTimeType.addItem(TimeType.getsTimeType(1));
               iTimeType.addItem(TimeType.getsTimeType(2));
               break;
      case 1 : iTimeType.addItem(TimeType.getsTimeType(1));
               break;
      case 2 : iTimeType.addItem(TimeType.getsTimeType(2));
               break;
      default : break;
    }
   iTimeType.addItem(TimeType.getsTimeType(3));

   iTimeType.setSelectedItem(focus);
//   iGranularity.setSelectedItem(gr);
  }

  private int lookAssociationTimeType(){
//    return 1;
    int temp = 0;
    if(pInter.haveAssociationVT()) temp = 1;
    if(pInter.haveAssociationTT()) temp = 2;
    if((pInter.haveAssociationTT() && pInter.haveAssociationVT())||
      (pInter.haveAssociationBT())) temp = 3;

    return temp;
  }

  private int lookAttrTimeType(){
    structureAttribute attr;
    int found = 0;
    int val;
    int max = newSetAttr.size();
    for(int i = 0;i < max; i++ ){
      attr = (structureAttribute) newSetAttr.elementAt(i);
      val = attr.getiTimeStamp();
      if (((val + found) == 3)||(found == 3))
        return 3;
      if (found < val) found = val;
    }
    return found;
  }

  private void checkGranularity(){
    String gr = (String) iGranularity.getSelectedItem();
    iGranularity.removeAllItems();
    int max = lookAttrGranularity();
    for(int i = 0 ; i <= max ; i++)
      iGranularity.addItem(Granularity.getGranularity(i));
    iGranularity.setSelectedItem(gr);
  }

  private int lookAttrGranularity(){
    structureAttribute attr;
    int found = Granularity.maxGanularity()-1;
    int val;
    int max = newSetAttr.size();
    for(int i = 0;i < max; i++ ){
      attr = (structureAttribute) newSetAttr.elementAt(i);
      val = attr.getiGranularity();
      if (found > val) found = val;
    }
    return found;
  }

  public void showDialog(){
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    this.setVisible(true);


  }

}