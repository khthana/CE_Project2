package tumltool;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import COM.intersys.objects.*;

/**
 * Title:        Temporal Class Diagram Modeling Tool
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      King Mongkut's Institute of Technology Ladkrabang
 * @author       Mr.Yutthana Suiwongsa & Mr.Akachan Pitisakornwit
 * @version 1.0
 */

public class FigClass extends JPanel {

  static private int id_created = 0;

  private Oid oid = null;
  private int _pointX;
  private int _pointY;
  private int width = 80;
  private int high  = 45;
  private Color color = new Color(255,255,204);
  private String iName = "NewClass";//new String("Interface");
  private int indexTimeType = 0;
  private Vector attribute = new Vector();
  private int granularity = 5;
  private int id;
  private String descriptions = "";

  Image ttIcon;
  Image vtIcon;
  Image btIcon;
  Image ttAttrIcon;
  Image vtAttrIcon;
  Image btAttrIcon;

  private int _associationVT = 0;
  private int _associationTT = 0;
  private int _associationBT = 0;

  public FigClass(int x, int y) {
    try {
      _pointX = x;
      _pointY = y;
      id = id_created;
      iName = iName + id;
      id_created++;

      ttIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/tticon.gif"));
      vtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vticon.gif"));
      btIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/bticon.gif"));
      ttAttrIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/ttAttrIcon.gif"));
      vtAttrIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vtAttrIcon.gif"));
      btAttrIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/btAttrIcon.gif"));
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public FigClass() {
    try {
      _pointX = 0;
      _pointY = 0;
      id = id_created;
      iName = iName + id;
      id_created++;

      ttIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/tticon.gif"));
      vtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vticon.gif"));
      btIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/bticon.gif"));
      ttAttrIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/ttAttrIcon.gif"));
      vtAttrIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vtAttrIcon.gif"));
      btAttrIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/btAttrIcon.gif"));
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void clear(){
    id_created = 0;
  }

  public void setPoint(int x,int y){
    _pointX = x;
    _pointY = y;
    this.setBounds(_pointX,_pointY,width,high);
  }

  public void paintComponent(Graphics g){
    g.setColor(color);
    g.fill3DRect(0,0,this.width,this.high,true);
    g.setColor(Color.black);
    g.drawRect(0,0,this.width,this.high);

    drawTimeType(g);
    width = 80;
    drawName(g);
    drawAttribute(g);
    this.setBounds(_pointX,_pointY,width,high);
  }

  public void drawAttribute(Graphics g){
    structureAttribute attr;
    int maxAttr = attribute.size();
    int i = 0;
    int y = 30;
    String str = "";
    for(;i < maxAttr ;i++ ){
      attr = (structureAttribute) attribute.elementAt(i);
      if (attr.getiTimeStamp() == 1)
        g.drawImage(vtAttrIcon,1,(i+1)*10+10,this);
      if (attr.getiTimeStamp() == 2)
        g.drawImage(ttAttrIcon,1,(i+1)*10+10,this);
      if (attr.getiTimeStamp() == 3)
        g.drawImage(btAttrIcon,1,(i+1)*10+10,this);

      str = attr.getName() + "  : " + attr.getType();
      y = (i+1)*10+20;
      if (((str.length()-3)*7 + 22) > width) width = (str.length()-3)*7+22;

      g.drawString(str ,17,y);
    }

    high = y+22; // Calculate High of this fig
    g.drawLine(0,19,width,19);
    g.drawLine(0,y+7,width,y+7);

  }

  public void drawName(Graphics g){
    g.setColor(Color.black);
    int xStart = 2;
    if(indexTimeType != 0)
      xStart = 23;
    if ((iName.length()*7+ xStart) > width) width = iName.length()*7+xStart;

    g.drawString(iName,2,15);
  }

  public void drawTimeType(Graphics g){
    if(indexTimeType != 0){
      if (indexTimeType == 1)
        g.drawImage(vtIcon,width-18,2,this);
      if (indexTimeType == 2)
        g.drawImage(ttIcon,width-18,2,this);
      if (indexTimeType == 3)
        g.drawImage(btIcon,width-18,2,this);
    }
  }

  public boolean checkArea(int x,int y){
    if ((x >= _pointX )&&(x <= (_pointX + width)) &&
        (y >= _pointY )&&(y <= (_pointY + high))) return true;
    return false;
  }

  public String getName(){
    return iName;
  }

  public void setName(String nName){
    iName = nName;
  }

  public void setTimeType(String type){
//    iTimeType.setTimeType(type);
      indexTimeType = TimeType.getiTimeType(type);
  }

  public void setTimeType(int iType){
//    iTimeType.setTimeType(iType);
      if (iType < 4)
        indexTimeType = iType;
  }

  public void setGranularity(int iGR){
//    if(iGR < 6)
      granularity = iGR;
  }

  public void setGranularity(String GR){
    granularity = Granularity.getIndexOf(GR);
  }

  public String getGranularity(){
    return Granularity.getGranularity(granularity);
  }

  public int getIGranularity(){
    return granularity;
  }

  public int getiTimeType(){
    return indexTimeType;
  }

  public String getTimeType(){
    return TimeType.getsTimeType(indexTimeType);
  }

  public void setDescriptions(String descrip){
    descriptions = descrip;
  }

  public String getDescriptions(){
    return descriptions;
  }

  public int PointX(){
    return _pointX;
  }

  public int PointY(){
    return _pointY;
  }

  public int Width(){
    return width;
  }

  public int high(){
    return high;
  }

  public void setWidth(int w){
    width = w;
  }

  public void setHigh(int h){
    high = h;
  }
// function return center cordinate of figclass
  public int getCX() {
    return _pointX + (width/2);
  }

  public int getCY() {
    return _pointY + (high/2);
  }

  public void setAttribute(Vector vAttribute){
    attribute = vAttribute;
  }

  public Vector getAttribute(){
    return attribute;
  }

  public void setId(int aid){
    id = aid;
  }

  public int getId(){
    return id;
  }

  public void incAssociationVT(){
    _associationVT++;
  }

  public void incAssociationTT(){
    _associationTT++;
  }

  public void incAssociationBT(){
    _associationBT++;
  }

  public void decAssociationVT(){
    _associationVT--;
  }

  public void decAssociationTT(){
    _associationTT--;
  }

  public void decAssociationBT(){
    _associationBT--;
  }

  public boolean haveAssociationVT(){
    return (_associationVT > 0) ? true : false ;
  }

  public boolean haveAssociationTT(){
    return (_associationTT > 0) ? true : false ;
  }

  public boolean haveAssociationBT(){
    return (_associationBT > 0) ? true : false ;
  }

  public int getAssociationTT(){
    return _associationTT;
  }

  public int getAssociationVT(){
    return _associationVT;
  }

  public int getAssociationBT(){
    return _associationBT;
  }

  public void setAssociationTT(int tt){
    _associationTT = tt;
  }

  public void setAssociationVT(int vt){
    _associationVT = vt;
  }

  public void setAssociationBT(int bt){
    _associationBT = bt;
  }

  public void setOid(Oid id){
    oid = id;
  }

  public Oid getOid(){
    return oid;
  }
}