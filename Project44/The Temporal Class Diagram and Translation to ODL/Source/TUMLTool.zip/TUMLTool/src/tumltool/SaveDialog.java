package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SaveDialog extends JDialog {
  JPanel panel1 = new JPanel();
  JPanel PanelButton = new JPanel();
  JButton ButtonCancel = new JButton();
  JButton ButtonOK = new JButton();
  JPanel PanelTextField = new JPanel();
  JLabel LabelDiagramName = new JLabel();
  JTextField TextFieldName = new JTextField();
  FlowLayout flowLayout1 = new FlowLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JList ListDiagram = new JList();

  public SaveDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public SaveDialog() {
    this(null, "", false);
  }
  void jbInit() throws Exception {
    panel1.setLayout(verticalFlowLayout1);
    ButtonCancel.setText("Cancel");
    ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ButtonCancel_actionPerformed(e);
      }
    });
    ButtonOK.setText("OK");
    ButtonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ButtonOK_actionPerformed(e);
      }
    });
    LabelDiagramName.setText("Name:");
    PanelButton.setLayout(flowLayout1);
    PanelTextField.setLayout(borderLayout2);
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    flowLayout1.setVgap(0);
    borderLayout2.setHgap(10);
    this.setResizable(false);
    this.setTitle("Save Diagram");
    ListDiagram.setEnabled(false);
    ListDiagram.setBorder(BorderFactory.createEtchedBorder());
    ListDiagram.setPreferredSize(new Dimension(300, 150));
    ListDiagram.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    getContentPane().add(panel1);
    PanelButton.add(ButtonOK, null);
    PanelButton.add(ButtonCancel, null);
    PanelTextField.add(LabelDiagramName, BorderLayout.WEST);
    PanelTextField.add(TextFieldName, BorderLayout.CENTER);
    panel1.add(ListDiagram, null);
    panel1.add(PanelTextField, null);
    panel1.add(PanelButton, null);
  }

  void ButtonCancel_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }

  void ButtonOK_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }
}