package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesInheritance extends JDialog {
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel2 = new JLabel();
  FlowLayout flowLayout1 = new FlowLayout();
  FlowLayout flowLayout2 = new FlowLayout();
  JTextField parentClass = new JTextField();
  JTextField inheritClass = new JTextField();
  JPanel jPanel3 = new JPanel();
  JButton ok = new JButton();
  FlowLayout flowLayout3 = new FlowLayout();

  public PropertiesInheritance(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropertiesInheritance() {
    this(null, "", false);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    this.getContentPane().setLayout(verticalFlowLayout1);
    jLabel1.setPreferredSize(new Dimension(120, 16));
    jLabel1.setText("      Superclass");
    jLabel2.setPreferredSize(new Dimension(120, 16));
    jLabel2.setText("      Subclass");
    jPanel2.setLayout(flowLayout1);
    jPanel1.setLayout(flowLayout2);
    verticalFlowLayout1.setVerticalFill(true);
    flowLayout2.setAlignment(FlowLayout.LEFT);
    flowLayout1.setAlignment(FlowLayout.LEFT);
    parentClass.setPreferredSize(new Dimension(220, 20));
    parentClass.setEditable(false);
    inheritClass.setPreferredSize(new Dimension(220, 20));
    inheritClass.setEditable(false);
    ok.setText("Ok");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    jPanel3.setLayout(flowLayout3);
    flowLayout3.setAlignment(FlowLayout.RIGHT);
    this.setTitle("Inheritance Properties");
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(parentClass, null);
    this.getContentPane().add(jPanel2, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(inheritClass, null);
    this.getContentPane().add(jPanel3, null);
    jPanel3.add(ok, null);
    this.setLocation(150,100);
  }

  public void ok_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }

  public void loadProperties(FigInheritanceLine ILine){
    FigClass parent = ILine.getParentClass();
    parentClass.setText(parent.getName());

    FigClass inherit = ILine.getInheritClass();
    inheritClass.setText(inherit.getName());
  }

  public void showDialog(){
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    this.setVisible(true);
  }

}