package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import COM.intersys.objects.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesProject extends JDialog {
  JPanel panelName        = new JPanel();
  JPanel panelDesigner    = new JPanel();
  JPanel panelPackage     = new JPanel();
  JPanel panelDescription = new JPanel();
  JPanel panelButton      = new JPanel();
  JPanel panelReset       = new JPanel();
  JPanel panelCommand     = new JPanel();

  JLabel labelName        = new JLabel();
  JLabel labelDesigner    = new JLabel();
  JLabel labelPackage     = new JLabel();
  private JTextField textfieldName      = new JTextField();
  private JTextField textfieldDesigner  = new JTextField();
  private JTextField textfieldPackage   = new JTextField();

  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  FlowLayout flowLayout1  = new FlowLayout();
  FlowLayout flowLayout2  = new FlowLayout();
  FlowLayout flowLayout3  = new FlowLayout();
  FlowLayout flowLayout4  = new FlowLayout();

  TitledBorder titledBorder1;
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();

  private JButton buttonOk      = new JButton();
  private JButton buttonCancel  = new JButton();
  private JButton buttonReset   = new JButton();
  private JScrollPane scrollpaneDescription = new JScrollPane();
  private JTextArea textareaDescription     = new JTextArea();

  private Oid oid = null;
  private String _pName         = "";
  private String _pDesigner     = "";
  private String _pDescription  = "";
  private String _pPackage      = "";

  private int option;
  public int OK_OPTION = 0;
  public int CANCEL_OPTION = 1;

  public PropertiesProject(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropertiesProject() {
    this(null, "", false);
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Description");
    this.getContentPane().setLayout(verticalFlowLayout1);
    labelName.setPreferredSize(new Dimension(120, 16));
    labelName.setText("Diagram Name:");
    textfieldName.setPreferredSize(new Dimension(220, 20));
    labelDesigner.setPreferredSize(new Dimension(120, 16));
    labelDesigner.setText("Designer:");
    panelDesigner.setLayout(flowLayout1);
    panelName.setLayout(flowLayout2);
    textfieldDesigner.setPreferredSize(new Dimension(220, 20));
    panelDescription.setBorder(titledBorder1);
    panelDescription.setPreferredSize(new Dimension(390, 120));
    panelDescription.setLayout(borderLayout1);
    this.setTitle("Project Properties");
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    scrollpaneDescription.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    scrollpaneDescription.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    buttonOk.setMnemonic('O');
    buttonOk.setText("OK");
    buttonOk.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOk_actionPerformed(e);
      }
    });
    buttonCancel.setText("Cancel");
    buttonCancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonCancel_actionPerformed(e);
      }
    });
    panelButton.setLayout(borderLayout2);
    panelReset.setPreferredSize(new Dimension(250, 27));
    panelReset.setLayout(flowLayout4);
    buttonReset.setText("Reset");
    buttonReset.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonReset_actionPerformed(e);
      }
    });
    flowLayout4.setAlignment(FlowLayout.LEFT);
    labelPackage.setPreferredSize(new Dimension(120, 16));
    labelPackage.setText("Package Name:");
    textfieldPackage.setPreferredSize(new Dimension(220, 20));
    panelPackage.setLayout(flowLayout3);
    panelButton.add(panelReset, BorderLayout.CENTER);
    panelReset.add(buttonReset, null);
    panelButton.add(panelCommand, BorderLayout.EAST);
    panelCommand.add(buttonOk, null);
    panelCommand.add(buttonCancel, null);
    this.getContentPane().add(panelName, null);
    this.getContentPane().add(panelDesigner, null);
    panelDesigner.add(labelDesigner, null);
    panelName.add(labelName, null);
    panelName.add(textfieldName, null);
    panelDesigner.add(textfieldDesigner, null);
    this.getContentPane().add(panelPackage, null);
    this.getContentPane().add(panelDescription, null);
    panelDescription.add(scrollpaneDescription, BorderLayout.CENTER);
    scrollpaneDescription.getViewport().add(textareaDescription, null);
    this.getContentPane().add(panelButton, null);
    panelPackage.add(labelPackage, null);
    panelPackage.add(textfieldPackage, null);
  }

  public int showDialog(){
    textfieldName.setText(_pName);
    textfieldDesigner.setText(_pDesigner);
    textfieldPackage.setText(_pPackage);
    textareaDescription.setText(_pDescription);

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    this.setVisible(true);

    return option;
  }

  void buttonOk_actionPerformed(ActionEvent e) {
    if (textfieldName.getText().length() > 0) {
      _pName = textfieldName.getText();
      _pDesigner = textfieldDesigner.getText();
      _pPackage = textfieldPackage.getText();
      _pDescription = textareaDescription.getText();
      option = OK_OPTION;
      this.setVisible(false);
    } else
      JOptionPane.showMessageDialog(this,"Please enter diagram's name","TUML",JOptionPane.INFORMATION_MESSAGE);
  }

  void buttonCancel_actionPerformed(ActionEvent e) {
//    if (_pName.length() > 0) {
      option = CANCEL_OPTION;
      this.setVisible(false);
//    } else
//      JOptionPane.showMessageDialog(this,"Please enter diagram's name","TUML",JOptionPane.INFORMATION_MESSAGE);
  }

  void buttonReset_actionPerformed(ActionEvent e) {
    textfieldName.setText("");
    textfieldDesigner.setText("");
    textareaDescription.setText("");
    textfieldPackage.setText("");
  }

  public void setOid(Oid aid) {
    oid = aid;
  }

  public Oid getOid() {
    return oid;
  }

  public void setName(String name) {
    _pName = name;
  }

  public String getName() {
    return _pName;
  }

  public void setDesigner(String designer) {
    _pDesigner = designer;
  }

  public String getDesigner() {
    return _pDesigner;
  }

  public void setPackage(String packages) {
    _pPackage = packages;
  }

  public String getPackage() {
    return _pPackage;
  }

  public void setDescription(String description) {
    _pDescription = description;
  }

  public String getDescription() {
    return _pDescription;
  }

  public boolean checkDetail(){
    if((_pPackage.length() == 0)||(_pName.length() == 0)||( _pDesigner.length() == 0))
      return false;
    return true;
  }

  void this_windowClosing(WindowEvent e) {
    option = CANCEL_OPTION;
  }

}