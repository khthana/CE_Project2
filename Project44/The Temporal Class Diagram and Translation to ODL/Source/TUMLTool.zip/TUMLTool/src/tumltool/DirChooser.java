package tumltool;

import javax.swing.JFileChooser;

/**
 * Title: Directory Chooser
 * Description: use to browse directory and select directory at you want
 * @author Yutthana Suiwongsa
 * @version 1.0
 */

public class DirChooser extends JFileChooser {
  public DirChooser() {
    this.setFileSelectionMode(1);
    this.setDialogTitle("Select Directory");
    this.setDialogType(2);
    this.setFileFilter((null));
    this.setAcceptAllFileFilterUsed(false);
  }
}