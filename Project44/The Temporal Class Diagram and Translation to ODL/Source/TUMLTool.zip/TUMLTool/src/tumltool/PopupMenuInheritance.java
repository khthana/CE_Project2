package tumltool;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class PopupMenuInheritance extends JPopupMenu {
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  ImageIcon imageProperties;
  ImageIcon imageDelete;
  PropertiesInheritance rChoosed;
  Vector vInheritance;
  int indexInheritance;
  JTextArea DrawArea;

  public PopupMenuInheritance() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    imageProperties = new ImageIcon("Properties.gif");
    imageDelete     = new ImageIcon("Delete.gif");
    jMenuItem1.setIcon(imageProperties);
    jMenuItem1.setText("Properties");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem1_actionPerformed(e);
      }
    });
    jMenuItem2.setIcon(imageDelete);
    jMenuItem2.setText("Delete");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem2_actionPerformed(e);
      }
    });
    this.add(jMenuItem1);
    this.addSeparator();
    this.add(jMenuItem2);
  }

  public void setAll(JTextArea drawArea,Vector V,int index,PropertiesInheritance pInheritance) {
    DrawArea = drawArea;
    vInheritance = V;
    indexInheritance = index;
    rChoosed = pInheritance;
  }

  void jMenuItem1_actionPerformed(ActionEvent e) {
    rChoosed.show();
  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    FigInheritanceLine deleteInheritance = (FigInheritanceLine) vInheritance.elementAt(indexInheritance);
    DrawArea.remove(deleteInheritance);
    DrawArea.repaint();
    vInheritance.removeElementAt(indexInheritance);
  }
}
