package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import javax.swing.border.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesAssociation extends JDialog {
  FigClass srcClass;
  FigClass desClass;
//  TimeType timeType = new TimeType();
//  structureAssociation strucAss = new structureAssociation();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JPanel panelSrcClass = new JPanel();
  JLabel labelSrcClass = new JLabel();
  JTextField nameSrcClass = new JTextField();
  FlowLayout flowLayout1 = new FlowLayout();
  JPanel panelDesClass = new JPanel();
  JLabel lebelDesClass = new JLabel();
  JTextField nameDesClass = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel panelTimestamp = new JPanel();
  JLabel TimeStamp = new JLabel();
  JComboBox ListTimeType = new JComboBox();
  JPanel panelTimeTimestamp = new JPanel();
  JComboBox listGranularity = new JComboBox();
  JTextField role = new JTextField();
  JPanel panelMultiplicity = new JPanel();
  JLabel lableInvRole = new JLabel();
  JTextField inverseRole = new JTextField();
  ButtonGroup Multiplicity = new ButtonGroup();
  ButtonGroup tType = new ButtonGroup();
  JPanel panelButton = new JPanel();
  JButton ok = new JButton();
  JButton cancel = new JButton();
  FlowLayout flowLayout3 = new FlowLayout();
  JRadioButton one2one = new JRadioButton();
  JRadioButton one2many = new JRadioButton();
  JRadioButton many2one = new JRadioButton();
  JRadioButton many2many = new JRadioButton();

  Border border1 = BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140));
  TitledBorder titledBorder1  = new TitledBorder(border1,"Multiplicity");
  Border border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(148, 145, 140));
  TitledBorder titledBorder2 = new TitledBorder(border2,"Valid time timestamp");
  Border border3  = BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140));
  TitledBorder titledBorder3  = new TitledBorder(border3,"Valid time timestamp");

  Border border4 = BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140));
  TitledBorder titledBorder4 = new TitledBorder(border4,"Role");
  Border border5 = BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140));
  TitledBorder titledBorder5  = new TitledBorder(border5,"VT Type");
  Border border6 = BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140));
  TitledBorder titledBorder6 = new TitledBorder(border6,"Granularity");


  JPanel jPanel2 = new JPanel();
  JPanel vtType = new JPanel();
  JRadioButton period = new JRadioButton();
  JRadioButton timepoint = new JRadioButton();
  JPanel vtGranularity = new JPanel();
  JLabel jLabel1 = new JLabel();
  VerticalFlowLayout verticalFlowLayout2 = new VerticalFlowLayout();
  JPanel jPanel1 = new JPanel();
  FigAssociationLine _fALine = new FigAssociationLine();

  private boolean _completeAddNew = false;
  private boolean _prepareAddNew = false;
  FlowLayout flowLayout4 = new FlowLayout();
  FlowLayout flowLayout5 = new FlowLayout();

//  private int _oldTimeType = 0;


  public PropertiesAssociation(Frame frame, String title, boolean modal) {
    super(frame, title, modal);

    try {
      jbInit();
      pack();
      //Center the window
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = this.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropertiesAssociation() {
    this(null, "", false);
    try {
      jbInit();
      pack();
      //Center the window
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = this.getSize();
      if (frameSize.height > screenSize.height) {
        frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
        frameSize.width = screenSize.width;
      }
      this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

  }

  void jbInit() throws Exception {

    panelSrcClass.setLayout(flowLayout1);
    this.getContentPane().setLayout(verticalFlowLayout1);
    nameSrcClass.setPreferredSize(new Dimension(220, 20));
    nameSrcClass.setEditable(false);
    lebelDesClass.setPreferredSize(new Dimension(120, 16));
    lebelDesClass.setText("Destination Class");
    nameDesClass.setPreferredSize(new Dimension(220, 20));
    nameDesClass.setEditable(false);
    panelDesClass.setLayout(flowLayout2);
    labelSrcClass.setPreferredSize(new Dimension(120, 16));
    labelSrcClass.setText("Source Class");
    TimeStamp.setPreferredSize(new Dimension(120, 16));
    TimeStamp.setText("Timestamp Category");
    ListTimeType.setPreferredSize(new Dimension(220, 20));
    ListTimeType.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        ListTimeType_itemStateChanged(e);
      }
    });
    role.setPreferredSize(new Dimension(150, 18));
    lableInvRole.setPreferredSize(new Dimension(50, 16));
    lableInvRole.setToolTipText("");
    lableInvRole.setHorizontalAlignment(SwingConstants.RIGHT);
    lableInvRole.setText("Inverse ");
    inverseRole.setPreferredSize(new Dimension(150, 20));
    ok.setHorizontalAlignment(SwingConstants.RIGHT);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    cancel.setHorizontalAlignment(SwingConstants.RIGHT);
    cancel.setText("Cancel");
    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel_actionPerformed(e);
      }
    });
    panelButton.setLayout(flowLayout3);
    flowLayout3.setAlignment(FlowLayout.RIGHT);
    one2one.setText("one-to-one");
    one2many.setText("one-to-many");
    many2one.setText("many-to-one");
    many2many.setText("many-to-many");
    panelMultiplicity.setBorder(titledBorder1);
    panelTimeTimestamp.setBorder(titledBorder3);
    panelTimeTimestamp.setLayout(flowLayout4);
    jPanel2.setBorder(titledBorder4);
    jPanel2.setLayout(verticalFlowLayout2);
    period.setText("Period");
    timepoint.setText("Timepoint");
    vtType.setBorder(titledBorder5);
    vtType.setMaximumSize(new Dimension(168, 61));
    vtType.setLayout(flowLayout5);
    vtGranularity.setBorder(titledBorder6);
    vtGranularity.setMinimumSize(new Dimension(242, 61));
    vtGranularity.setPreferredSize(new Dimension(242, 61));
    jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel1.setHorizontalTextPosition(SwingConstants.LEADING);
    jLabel1.setText("Name ");
    listGranularity.setPreferredSize(new Dimension(220, 20));
    this.setTitle("Association Properties");
    flowLayout4.setAlignment(FlowLayout.LEFT);
    flowLayout5.setAlignment(FlowLayout.RIGHT);
    this.getContentPane().add(panelSrcClass, null);
    panelSrcClass.add(labelSrcClass, null);
    panelSrcClass.add(nameSrcClass, null);
    this.getContentPane().add(panelDesClass, null);
    panelDesClass.add(lebelDesClass, null);
    panelDesClass.add(nameDesClass, null);
    this.getContentPane().add(panelTimestamp, null);
    panelTimestamp.add(TimeStamp, null);
    panelTimestamp.add(ListTimeType, null);
    this.getContentPane().add(panelTimeTimestamp, null);
    vtType.add(period, null);
    vtType.add(timepoint, null);
    panelTimeTimestamp.add(vtType, null);
    panelTimeTimestamp.add(vtGranularity, null);
    vtGranularity.add(listGranularity, null);
    this.getContentPane().add(jPanel2, null);
    jPanel2.add(jPanel1, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(role, null);
    jPanel1.add(lableInvRole, null);
    jPanel1.add(inverseRole, null);
    this.getContentPane().add(panelMultiplicity, null);
    this.getContentPane().add(panelButton, null);
    panelButton.add(ok, null);

    ListTimeType.addItem(TimeType.getsTimeType(0));
    ListTimeType.addItem(TimeType.getsTimeType(1));
    ListTimeType.addItem(TimeType.getsTimeType(2));
    ListTimeType.addItem(TimeType.getsTimeType(3));

    listGranularity.removeAllItems();
    listGranularity.addItem(Granularity.getGranularity(0));
    listGranularity.addItem(Granularity.getGranularity(1));
    listGranularity.addItem(Granularity.getGranularity(2));
    listGranularity.addItem(Granularity.getGranularity(3));
    listGranularity.addItem(Granularity.getGranularity(4));
    listGranularity.addItem(Granularity.getGranularity(5));



    panelButton.add(cancel, null);
    panelMultiplicity.add(one2one, null);
    panelMultiplicity.add(one2many, null);
    panelMultiplicity.add(many2one, null);
    panelMultiplicity.add(many2many, null);
    Multiplicity.add(one2one);
    Multiplicity.add(one2many);
    Multiplicity.add(many2one);
    Multiplicity.add(many2many);
    tType.add(timepoint);
    tType.add(period);

//    Dimension d1 = ,d2 = ;
//    d1.setSize(168,61);
//    d2.setSize(242,61);
    vtType.setPreferredSize(new Dimension(168,61));
    vtGranularity.setPreferredSize(new Dimension(242,61));
  }

  public void setSrcClass(FigClass sClass) {
    srcClass = sClass;
  }

  public void setDesClass(FigClass dClass) {
    desClass = dClass;
  }

  public void showDialog() {
/*    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
*/
    if(_prepareAddNew){
      nameSrcClass.setText(srcClass.getName());
      nameDesClass.setText(desClass.getName());
      setListTimeType();
    }
//    super.show();

//    this.setLocation(150,100);
    this.setVisible(true);
  }

  private void setListTimeType() {
    ListTimeType.removeAllItems();
    ListTimeType.addItem(TimeType.getsTimeType(0));
    if ((srcClass.getiTimeType() == 3) &&
        (desClass.getiTimeType() == 3)) {
//      ListTimeType.addItem(TimeType.getsTimeType(0));
      ListTimeType.addItem(TimeType.getsTimeType(1));
      ListTimeType.addItem(TimeType.getsTimeType(2));
      ListTimeType.addItem(TimeType.getsTimeType(3));
    }
    if (((srcClass.getiTimeType() == 1) &&
         (desClass.getiTimeType() == 3)) ||
        ((srcClass.getiTimeType() == 3) &&
         (desClass.getiTimeType() == 1)) ||
        ((srcClass.getiTimeType() == 1) &&
         (desClass.getiTimeType() == 1))) {
//      ListTimeType.addItem(TimeType.getsTimeType(0));
      ListTimeType.addItem(TimeType.getsTimeType(1));
    }
    if (((srcClass.getiTimeType() == 2) &&
         (desClass.getiTimeType() == 3)) ||
        ((srcClass.getiTimeType() == 3) &&
         (desClass.getiTimeType() == 2)) ||
        ((srcClass.getiTimeType() == 2) &&
         (desClass.getiTimeType() == 2))) {
//      ListTimeType.addItem(TimeType.getsTimeType(0));
      ListTimeType.addItem(TimeType.getsTimeType(2));
    }
/*    if ((srcClass.getTimeType() == "Static Time" ) ||
        (desClass.getTimeType() == "Static Time" )) {
      ListTimeType.addItem(TimeType.getsTimeType(0));
    }
*/
  }

  public void addNew(boolean b){
    _prepareAddNew = b;
    _completeAddNew = false;
    period.setSelected(true);
    one2one.setSelected(true);
    role.setText("");
    inverseRole.setText("");
//    _oldTimeType = 0;
  }

  public void cancel_actionPerformed(ActionEvent e) {
    _completeAddNew = false;
    _prepareAddNew = false;
    this.setVisible(false);
  }

  public FigClass getSrcClass(){
    return srcClass;
  }

  public FigClass getDesClass(){
    return desClass;
  }

  public boolean isAddNew(){
    return _completeAddNew;
  }

  public void loadProperties(FigAssociationLine fALine){
    _fALine = fALine;
    role.setText(fALine.getRole());
    inverseRole.setText(fALine.getInverseRole());
    srcClass = fALine.getSrcClass();
    desClass = fALine.getDesClass();
    nameSrcClass.setText(srcClass.getName());
    nameDesClass.setText(desClass.getName());
    setListTimeType();

    ListTimeType.setSelectedItem(fALine.getsTimeType());
    listGranularity.setSelectedItem(fALine.getGranularity());


    String tsType = fALine.getTimestampType();
    if(tsType.compareToIgnoreCase(period.getText()) == 0)
      period.setSelected(true);
    else
      timepoint.setSelected(true);

    String multi = fALine.getMultiplicity();
    one2one.setSelected(true);
    if(multi.compareToIgnoreCase(one2many.getText())  == 0)  one2many.setSelected(true);
    if(multi.compareToIgnoreCase(many2one.getText())  == 0)  many2one.setSelected(true);
    if(multi.compareToIgnoreCase(many2many.getText()) == 0)  many2many.setSelected(true);
  }

  public void ok_actionPerformed(ActionEvent e){
    if((!haveSpace(role.getText()))&&(!haveSpace(inverseRole.getText()))){
        _completeAddNew = _prepareAddNew;
        if(!_prepareAddNew)
          updateProperties(_fALine);
        this.setVisible(false);
    } else
    JOptionPane.showMessageDialog(this,"Please Enter Role name and Inverse Role name","TUML",JOptionPane.CLOSED_OPTION);
  }

  private boolean haveSpace(String str){
    int i = str.indexOf(" ");
    return ((str.length() == 0)||(i >= 0)) ? true : false;
  }

  public void updateProperties(FigAssociationLine fALine){
    updateLine(fALine);
    fALine.setRole(role.getText());
    fALine.setInverseRole(inverseRole.getText());
    if(one2one.isSelected())   fALine.setMultiplicity(one2one.getText());
    if(one2many.isSelected())  fALine.setMultiplicity(one2many.getText());
    if(many2one.isSelected())  fALine.setMultiplicity(many2one.getText());
    if(many2many.isSelected()) fALine.setMultiplicity(many2many.getText());

    fALine.setTimeType((String) ListTimeType.getSelectedItem());
    fALine.setGranularity((String) listGranularity.getSelectedItem());
    if(period.isSelected())
      fALine.setTimestampType(period.getText());
    else
      fALine.setTimestampType(timepoint.getText());
  }

  private void updateLine(FigAssociationLine fALine){
    String aa = (String) ListTimeType.getSelectedItem();
    int _newTimeType = TimeType.getiTimeType(aa);
    int _oldTimeType = fALine.getiTimeType();
//    if(_newTimeType != _oldTimeType){
    switch(_newTimeType){
      case 1 : srcClass.incAssociationVT();
               desClass.incAssociationVT();
               break;
      case 2 : srcClass.incAssociationTT();
               desClass.incAssociationTT();
               break;
      case 3 : srcClass.incAssociationBT();
               desClass.incAssociationBT();
               break;
      default :break;
    }

    switch(_oldTimeType){
      case 1 : srcClass.decAssociationVT();
               desClass.decAssociationVT();
               break;
      case 2 : srcClass.decAssociationTT();
               desClass.decAssociationTT();
               break;
      case 3 : srcClass.decAssociationBT();
               desClass.decAssociationBT();
               break;
      default :break;
    }
    _oldTimeType = 0;

  }

  private void setVT(boolean status1,boolean status2){
    period.setVisible(status1);
    timepoint.setVisible(status1);

    listGranularity.setVisible(status2);
    listGranularity.setEnabled(status1);
  }

  void ListTimeType_itemStateChanged(ItemEvent e) {
    String selItem = (String) ListTimeType.getSelectedItem();
    if((selItem == TimeType.getsTimeType(1))||
       (selItem == TimeType.getsTimeType(3))){
       setVT(true,true);
    }
    if(selItem == TimeType.getsTimeType(2)){
       setVT(false,true);
       listGranularity.setSelectedItem(Granularity.getGranularity(5));
    }
    if(selItem == TimeType.getsTimeType(0)){
       setVT(false,false);
    }
  }
}