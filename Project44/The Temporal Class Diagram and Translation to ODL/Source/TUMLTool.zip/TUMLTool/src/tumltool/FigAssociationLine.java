package tumltool;

import java.awt.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FigAssociationLine extends FigLine {

  Image ttRtIcon;
  Image vtRtIcon;
  Image btRtIcon;
  int arrowWidth = 8;
  int arrowHeigh = 4;
  int gap = 22;

  FigClass SrcClass;
  FigClass DesClass;
  structureLine _association = new structureLine();

//  int _areaX1,_areaY1,_areaX2,_areaY2,_areaX3,_areaY3,_areaX4,_areaY4;

  public FigAssociationLine() {
    try {
      ttRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/ttRtIcon.gif"));
      vtRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vtRtIcon.gif"));
      btRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/btRtIcon.gif"));
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void paintComponent(Graphics g) {
    super.setBeginCordinate(SrcClass.getCX(),SrcClass.getCY());
    super.setEndCordinate(DesClass.getCX(),DesClass.getCY());
    super.setSizeSRC(SrcClass.Width(),SrcClass.high());
    super.setSizeDES(DesClass.Width(),DesClass.high());

    int centerLineX = (_realX1+_realX2)/2 -10;
    int centerLineY = (_realY1+_realY2)/2 -10;
    calculatePointSRC();
    calculatePointDES();
    g.setColor(Color.black);

    if (_tx >_hx) {
      if (_ty > _hy) {
        if (_tx -_hx < 22) {
          _realX1 = 0+(int)((22-(_tx-_hx))/2); _realY1 = 0;
          _realX2 = 22-(int)((22-(_tx-_hx))/2); _realY2 = _ty-_hy;
          g.drawLine(0+(int)((22-(_tx-_hx))/2),0,22-(int)((22-(_tx-_hx))/2),_ty-_hy);
          this.setBounds(_hx-(int)((22-(_tx-_hx))/2),_hy,22,_ty-_hy+1);
//          g.drawImage(vtRtIcon,centerLineX+(int)((22-(_tx-_hx))/2),centerLineY,this);
        }
        if (_ty - _hy < 22) {
          _realX1 = 0; _realY1 = 0+(int)((22-(_ty-_hy))/2);
          _realX2 = _tx-_hx; _realY2 = 22-(int)((22-(_ty-_hy))/2);
          g.drawLine(0,0+(int)((22-(_ty-_hy))/2),_tx-_hx,22-(int)((22-(_ty-_hy))/2));
          this.setBounds(_hx,_hy-(int)((22-(_ty-_hy))/2),_tx-_hx+1,22);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY+(int)((22-(_ty-_hy))/2),this);
        }
        if ((_tx - _hx >= 22) && (_ty - _hy >= 22)) {
          _realX1 = 0; _realY1 = 0;
          _realX2 = _tx-_hx; _realY2 = _ty-_hy;

          g.drawLine(0,0,_tx-_hx,_ty-_hy);
          this.setBounds(_hx,_hy,_tx-_hx+1,_ty-_hy+1);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
        }

      }
      if (_hy > _ty) {
        if (_hy - _ty < 22) {
          _realX1 = 0; _realY1 = 22-(int)((22-(_hy-_ty))/2);
          _realX2 = _tx-_hx; _realY2 = (int)((22-(_hy-_ty))/2);

          g.drawLine(0,22-(int)((22-(_hy-_ty))/2),_tx-_hx,0+(int)((22-(_hy-_ty))/2));
          this.setBounds(_hx,_ty-(int)((22-(_hy-_ty))/2),_tx-_hx+1,22);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY+(int)((22-(_hy-_ty))/2),this);
        }
        if (_tx - _hx < 22) {
          _realX1 = 0+(int)((22-(_tx-_hx))/2); _realY1 = _hy-_ty;
          _realX2 = 22-(int)((22-(_tx-_hx))/2); _realY2 = 0;

          g.drawLine(0+(int)((22-(_tx-_hx))/2),_hy-_ty,22-(int)((22-(_tx-_hx))/2),0);
          this.setBounds(_hx-(int)((22-(_tx-_hx))/2),_ty,22,_hy-_ty+1);
//          g.drawImage(vtRtIcon,centerLineX+(int)((22-(_tx-_hx))/2),centerLineY,this);
        }
        if ((_tx - _hx >= 22) && (_hy - _ty >= 22)) {
          _realX1 = 0; _realY1 = _hy-_ty;
          _realX2 = _tx-_hx; _realY2 = 0;

          g.drawLine(0,_hy-_ty,_tx-_hx,0);
          this.setBounds(_hx,_ty,_tx-_hx+1,_hy-_ty+1);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
        }
      }
    }


    if (_hx > _tx) {
      if (_ty > _hy) {
        if (_ty - _hy < 22) {
          _realX1 = _hx-_tx ; _realY1 = 0+(int)((22-(_ty-_hy))/2);
          _realX2 = 0 ; _realY2 = 22-(int)((22-(_ty-_hy))/2);

          g.drawLine(_hx - _tx,0+(int)((22-(_ty-_hy))/2),0,22-(int)((22-(_ty-_hy))/2));
          this.setBounds(_tx,_hy-(int)((22-(_ty-_hy))/2),_hx-_tx+1,22);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY+(int)((22-(_ty-_hy))/2),this);
        }
        if (_hx - _tx < 22) {
          _realX1 = 22-(int)((22-(_hx-_tx))/2); _realY1 = 0;
          _realX2 = 0+(int)((22-(_hx-_tx))/2) ; _realY2 = _ty-_hy;

          g.drawLine(22-(int)((22-(_hx-_tx))/2),0,0+(int)((22-(_hx-_tx))/2),_ty-_hy);
          this.setBounds(_tx-(int)((22-(_hx-_tx))/2),_hy,22,_ty-_hy+1);
//          g.drawImage(vtRtIcon,centerLineX+(int)((22-(_hx-_tx))/2),centerLineY,this);
        }
        if ((_hx - _tx >= 22) && (_ty - _hy >= 22)) {
          _realX1 = _hx-_tx; _realY1 = 0;
          _realX2 = 0; _realY2 = _ty-_hy;

          g.drawLine(_hx - _tx,0,0,_ty-_hy);
          this.setBounds(_tx,_hy,_hx-_tx+1,_ty-_hy+1);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
        }
      }
      if (_hy > _ty) {
        if (_hy - _ty < 22) {
          _realX1 = _hx-_tx ; _realY1 = 22-(int)((22-(_hy-_ty))/2);
          _realX2 = 0 ; _realY2 = 0+(int)((22-(_hy-_ty))/2);

          g.drawLine(_hx - _tx,22-(int)((22-(_hy-_ty))/2),0,0+(int)((22-(_hy-_ty))/2));
          this.setBounds(_tx,_ty-(int)((22-(_hy-_ty))/2),_hx-_tx+1,22);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY+(int)((22-(_hy-_ty))/2),this);
        }
        if (_hx - _tx < 22) {
          _realX1 = 22-(int)((22-(_hx-_tx))/2); _realY1 = _hy-_ty;
          _realX2 = 0+(int)((22-(_hx-_tx))/2); _realY2 = 0;

          g.drawLine(22-(int)((22-(_hx-_tx))/2),_hy-_ty,0+(int)((22-(_hx-_tx))/2),0);
          this.setBounds(_tx-(int)((22-(_hx-_tx))/2),_ty,22,_hy-_ty+1);
///          g.drawImage(vtRtIcon,centerLineX+(int)((22-(_hx-_tx))/2),centerLineY,this);
        }
        if ((_hx - _tx >= 22) && (_hy - _ty >= 22)) {
          _realX1 = _hx-_tx; _realY1 = _hy-_ty;
          _realX2 = 0; _realY2 = 0;

          g.drawLine(_hx - _tx,_hy-_ty,0,0);
          this.setBounds(_tx,_ty,_hx-_tx+1,_hy-_ty+1);
//          g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
        }
      }
    }

    if (_tx == _hx) {
      if (_ty > _hy){
        _realX1 = 0+10 ; _realY1 = 0;
        _realX2 = 0+10 ; _realY2 = _ty-_hy;
        g.drawLine(0+10,0,0+10,_ty-_hy);
        this.setBounds(_hx-10,_hy,20,_ty-_hy);
      }
      if (_ty < _hy){
        _realX1 = 0+10 ; _realY1 = _hy-_ty;
        _realX2 = 0+10 ; _realY2 = 0;
        g.drawLine(0+10,_hy-_ty,0+10,0);
        this.setBounds(_tx-10,_ty,20,_hy-_ty);
      }
//      g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
    }

    if (_ty == _hy) {
      if (_hx < _tx) {
        _realX1 = 0 ; _realY1 = 0+10;
        _realX2 = _tx-_hx ; _realY2 = 0+10;
        g.drawLine(0,0+10,_tx-_hx,0+10);
        this.setBounds(_hx,_hy-10,_tx-_hx,_ty-_hy+20);
      }
      if (_hx > _tx) {
        _realX1 = 0 ; _realY1 = 0+10;
        _realX2 = _hx-_tx ; _realY2 = 0+10;
        g.drawLine(0,0+10,_hx-_tx,0+10);
        this.setBounds(_tx,_hy-10,_hx-_tx,_ty-_hy+20);
      }
//      g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
    }
   DrawMultiplicity(g);
   if(_association.getiTimeType() == 1)
     g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
   if(_association.getiTimeType() == 2)
     g.drawImage(ttRtIcon,centerLineX,centerLineY,this);
   if(_association.getiTimeType() == 3)
     g.drawImage(btRtIcon,centerLineX,centerLineY,this);
  }

  private void DrawAnyTriangle(Graphics g,int _hx,int _hy,int _tx,int _ty,int type){
    int    xFrom, xTo, yFrom, yTo;
    double denom, x, y, dx, dy, cos, sin;
    Polygon triangle;
    xTo = 0;
    xFrom = _tx - _hx;
    yTo = 0;
    yFrom = _ty - _hy;

    if (_tx >_hx) {
      if (_ty > _hy) {
        if (_tx - _hx < gap) {
          xTo   = 0 +(int)((gap-(_tx-_hx))/2);
          yTo   = 0;
          xFrom = gap-(int)((gap-(_tx-_hx))/2);
          yFrom = _ty-_hy;
        }
        if (_ty - _hy < gap) {
          xTo   = 0;
          yTo   = 0 +(int)((gap-(_ty-_hy))/2);
          xFrom = _tx-_hx;
          yFrom = gap-(int)((gap-(_ty-_hy))/2);
        }
        if ((_tx - _hx >= gap) && (_ty - _hy >= gap)) {
          xTo = 0;
          yTo = 0;
          xFrom = _tx - _hx;
          yFrom = _ty - _hy;
        }
      }
      if (_hy > _ty) {
        if (_hy - _ty < gap) {
          xTo   = 0;
          yTo   = gap-(int)((gap-(_hy-_ty))/2);
          xFrom = _tx-_hx;
          yFrom = 0+(int)((gap-(_hy-_ty))/2);
        }
        if (_tx - _hx < gap) {
          xTo   = 0+(int)((gap-(_tx-_hx))/2);
          yTo   = _hy-_ty;
          xFrom = gap-(int)((gap-(_tx-_hx))/2);
          yFrom = 0;
        }
        if ((_tx - _hx >= gap) && (_hy - _ty >= gap)) {
          xTo   = 0;
          yTo   = _hy-_ty;
          xFrom = _tx-_hx;
          yFrom = 0;
        }
      }
    }

    if (_hx > _tx) {
      if (_ty > _hy) {
        if (_hx - _tx < gap) {
          xTo   = gap-(int)((gap-(_hx-_tx))/2);
          yTo   = 0;
          xFrom = 0 +(int)((gap-(_hx-_tx))/2);
          yFrom   = _ty-_hy;
        }
        if (_ty - _hy < gap) {
          xTo   = _hx - _tx;
          yTo   = 0 +(int)((gap-(_ty-_hy))/2);
          xFrom = 0;
          yFrom = gap-(int)((gap-(_ty-_hy))/2);
        }
        if ((_hx - _tx >= gap) && (_ty-_hy >= gap)) {
          xTo   = _hx - _tx;
          yTo   = 0;
          xFrom = 0;
          yFrom = _ty - _hy;
        }
      }
      if (_ty < _hy) {
        if (_hy - _ty < gap) {
            xTo   = _hx-_tx;
            yTo   = gap - (int)((gap-(_hy-_ty))/2);
            xFrom = 0;
            yFrom = 0  + (int)((gap-(_hy-_ty))/2);
        }
        if (_hx - _tx < gap) {
          xTo   = gap- (int)((gap-(_hx-_tx))/2);
          yTo   = _hy - _ty;
          xFrom = 0 + (int)((gap-(_hx-_tx))/2);
          yFrom = 0;
        }
        if ((_hx - _tx >= gap) && (_hy - _ty >= gap)) {
          xTo   = _hx - _tx;
          yTo   = _hy - _ty;
          xFrom = 0;
          yFrom = 0;
        }
      }
    }

    if (_tx == _hx) {
      if (_ty > _hy){
        xTo   = (arrowWidth / 2) + 6;
        yTo   = 0;
        xFrom = (arrowWidth / 2) + 6;
        yFrom = _ty-_hy;
      }
      if (_ty < _hy){
        xTo   = (arrowWidth / 2) + 6;
        yTo   = _hy-_ty;
        xFrom = (arrowWidth / 2) + 6;
        yFrom = 0;
      }
    }

    if (_ty == _hy) {
      if (_hx < _tx) {
        xTo   = 0;
        yTo   = 6 + arrowWidth/2;
        xFrom = _tx-_hx;
        yFrom = 6 + arrowWidth/2;
      }
      if (_hx > _tx) {
        xTo   = _hx-_tx;
        yTo   = 6 + arrowWidth/2;
        xFrom = 0;
        yFrom = 6 + arrowWidth/2;
      }
    }

    dx   	= (double)(xTo - xFrom);
    dy   	= (double)(yTo - yFrom);

    denom 	= dist(dx, dy);
    if (denom <= 0.01) return;

    cos = arrowWidth/denom;
    sin = arrowHeigh/denom;
    x   = xTo - cos*dx;
    y   = yTo - cos*dy;
    int x1  = (int)(x - sin*dy);
    int y1  = (int)(y + sin*dx);
    int x2  = (int)(x + sin*dy);
    int y2  = (int)(y - sin*dx);

    triangle = new Polygon();
    triangle.addPoint(xTo, yTo);
    triangle.addPoint(x1, y1);
    triangle.addPoint(x2, y2);

    g.setColor(Color.black);
    g.fillPolygon(triangle);
    g.setColor(Color.black);
    g.drawPolygon(triangle);

    if (type == 1) {
      xTo = (int) x;
      yTo = (int) y;
      x   = xTo - cos*dx;
      y   = yTo - cos*dy;
      x1  = (int)(x - sin*dy);
      y1  = (int)(y + sin*dx);
      x2  = (int)(x + sin*dy);
      y2  = (int)(y - sin*dx);
      triangle = new Polygon();
      triangle.addPoint(xTo, yTo);
      triangle.addPoint(x1, y1);
      triangle.addPoint(x2, y2);
      g.setColor(Color.black);
      g.fillPolygon(triangle);
      g.setColor(Color.black);
      g.drawPolygon(triangle);
    }
  }

  private void DrawMultiplicity(Graphics g) {
    Font oldF = g.getFont();
    Font newF = new Font(oldF.getName(),oldF.getStyle(),10);
    g.setFont(newF);
    String multi = _association.getMultiplicity();

    if (multi.compareToIgnoreCase("one-to-one") == 0) {
//      g.drawString("0..1",7,8);
//      g.drawString("0..1",_tx-_hx-20,8);
      this.DrawAnyTriangle(g,_hx,_hy,_tx,_ty,0);
      this.DrawAnyTriangle(g,_tx,_ty,_hx,_hy,0);
    }
    if (multi.compareToIgnoreCase("one-to-many") == 0) {
//      g.drawString("0..1",7,8);
//      g.drawString("*",_tx-_hx-10,8);
      this.DrawAnyTriangle(g,_hx,_hy,_tx,_ty,0);
      this.DrawAnyTriangle(g,_tx,_ty,_hx,_hy,1);
    }
    if (multi.compareToIgnoreCase("many-to-one") == 0) {
//      g.drawString("*",7,8);
//      g.drawString("0..1",_tx-_hx-20,8);
      this.DrawAnyTriangle(g,_hx,_hy,_tx,_ty,1);
      this.DrawAnyTriangle(g,_tx,_ty,_hx,_hy,0);
    }
    if (multi.compareToIgnoreCase("many-to-many") == 0) {
//      g.drawString("*",7,8);
//      g.drawString("*",_tx-_hx-10,8);
      this.DrawAnyTriangle(g,_hx,_hy,_tx,_ty,1);
      this.DrawAnyTriangle(g,_tx,_ty,_hx,_hy,1);
    }
    g.setFont(oldF);
  }

  public void setSrcClass(FigClass f) {
    this.setBeginCordinate(f.getCX(),f.getCY());
    this.setSizeSRC(f.Width(),f.high());
    this.setSrcID(f.getId());
    SrcClass = f;
    _association.setSrcClass(f);
  }

  public void setDesClass(FigClass f) {
    this.setEndCordinate(f.getCX(),f.getCY());
    this.setSizeDES(f.Width(),f.high());
    this.setDesID(f.getId());
    DesClass = f;
    _association.setDesClass(f);

  }

  public FigClass getSrcClass(){
    return SrcClass;
  }

  public FigClass getDesClass(){
    return DesClass;
  }

  public void setRole(String role){
    _association.setRole(role);
  }

  public void setInverseRole(String invRole){
    _association.setInvRole(invRole);
  }

  public void setMultiplicity(String multiplicity){
    _association.setMultiplicity(multiplicity);
  }

  public void setTimeType(String timeType){
    _association.setTimeType(timeType);
  }

  public void setTimeType(int timeType){
    _association.setTimeType(timeType);
  }

  public void setGranularity(String granularity){
    _association.setGranularity(granularity);
  }

  public String getRole(){
    return _association.getRole();
  }

  public String getInverseRole(){
    return _association.getInvRole();
  }

  public String getMultiplicity(){
    return _association.getMultiplicity();
  }

  public String getsTimeType(){
    return _association.getsTimeType();
  }

  public int getiTimeType(){
    return _association.getiTimeType();
  }

  public String getGranularity(){
    return _association.getGranularity();
  }

  public void setTimestampType(String timestampType){
    _association.setTimestampType(timestampType);
  }

  public String getTimestampType(){
    return _association.getTimestampType();
  }

  public void prepareDelete(){
    switch( _association.getiTimeType()){
      case 1 : SrcClass.decAssociationVT();
               DesClass.decAssociationVT();
               break;
      case 2 : SrcClass.decAssociationTT();
               DesClass.decAssociationTT();
               break;
      case 3 : SrcClass.decAssociationBT();
               DesClass.decAssociationBT();
               break;
      default :break;
    }

  }

}