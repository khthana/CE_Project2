package tumltool;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class PopupMenuClass extends JPopupMenu {
  ImageIcon imageProperties;
  ImageIcon imageDelete;
  JMenuItem menuItemProperties = new JMenuItem();
  JMenuItem menuItemDelete = new JMenuItem();
  PropertiesClass classChoosed = new PropertiesClass();
  Vector vInterface = new Vector();
  int indexInterface;
  JTextArea DrawArea;

  public PopupMenuClass() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    imageProperties = new ImageIcon("Properties.gif");
    imageDelete     = new ImageIcon("Delete.gif");

    menuItemProperties.setIcon(imageProperties);
    menuItemProperties.setText("Properties");
    menuItemProperties.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        menuItemProperties_actionPerformed(e);
      }
    });
    menuItemDelete.setIcon(imageDelete);
    menuItemDelete.setText("Delete");
    menuItemDelete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        menuItemDelete_actionPerformed(e);
      }
    });
    this.add(menuItemProperties);
    this.addSeparator();
    this.add(menuItemDelete);
  }

  public void setEnvironment(JTextArea drawArea,Vector V,int index) {
    vInterface = V;
    DrawArea = drawArea;
    indexInterface = index;
  }

  public void setPropertiesClass(PropertiesClass p) {
    classChoosed = p;
  }

  public void setDeleteEnable(boolean s) {
    menuItemDelete.setEnabled(s);
  }

  void menuItemProperties_actionPerformed(ActionEvent e) {
    classChoosed.setLocation(200,65);
    classChoosed.setVisible(true);
  }

  void menuItemDelete_actionPerformed(ActionEvent e) {
    FigClass deleteClass = (FigClass) vInterface.elementAt(indexInterface);
    DrawArea.remove(deleteClass);
    DrawArea.repaint();
    vInterface.removeElementAt(indexInterface);
  }
}