package tumltool;
import java.awt.*;
import java.util.*;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FigInheritanceLine extends FigLine {
  private FigClass parentClass;
  private FigClass inheritClass;

  public FigInheritanceLine() {
    this.setSrcArrowHead(1);
  }

  public void setParentClass(FigClass f) {
    parentClass = f;
    this.setBeginCordinate(f.getCX(),f.getCY());
    this.setSizeSRC(f.Width(),f.high());
    this.setSrcID(f.getId());
  }

  public boolean setInheritClass(FigClass f) {
    if (parentClass.getTimeType() == "Static Time") {
      inheritClass = f;
      this.setDesID(f.getId());
      this.setSizeDES(f.Width(),f.high());
      this.setEndCordinate(f.getCX(),f.getCY());
      return true;
    }
    if (parentClass.getTimeType() == "Valid Time") {
      if ((f.getTimeType() != "Static Time") && (f.getTimeType() != "Transaction Time")) {
        inheritClass = f;
        this.setDesID(f.getId());
        this.setSizeDES(f.Width(),f.high());
        this.setEndCordinate(f.getCX(),f.getCY());
        return true;
      }
    }
    if (parentClass.getTimeType() == "Transaction Time") {
      if ((f.getTimeType() != "Static Time") && (f.getTimeType() != "Valid Time")) {
        inheritClass = f;
        this.setDesID(f.getId());
        this.setSizeDES(f.Width(),f.high());
        this.setEndCordinate(f.getCX(),f.getCY());
        return true;
      }
    }
    if (parentClass.getTimeType() == "Bitemporal Time") {
      if (f.getTimeType() == "Bitemporal Time") {
        inheritClass = f;
        this.setDesID(f.getId());
        this.setSizeDES(f.Width(),f.high());
        this.setEndCordinate(f.getCX(),f.getCY());
        return true;
      }
    }
    return false;
  }

  public void paintComponent(Graphics g){
    super.setBeginCordinate(parentClass.getCX(),parentClass.getCY());
    super.setEndCordinate(inheritClass.getCX(),inheritClass.getCY());
    super.setSizeSRC(parentClass.Width(),parentClass.high());
    super.setSizeDES(inheritClass.Width(),inheritClass.high());
    super.paintComponent(g);
  }

  public FigClass getParentClass(){
    return parentClass;
  }

  public FigClass getInheritClass(){
    return inheritClass;
  }
}

