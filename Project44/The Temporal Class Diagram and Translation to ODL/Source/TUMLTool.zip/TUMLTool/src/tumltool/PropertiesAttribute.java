package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.border.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesAttribute extends JDialog {
  JLabel lName = new JLabel();
  JLabel lTimeType = new JLabel();
  JLabel granularity = new JLabel();
  JTextField attrName = new JTextField();

  JComboBox attrTimeType = new JComboBox();

  JButton buttonOK = new JButton();
  JButton Cancel = new JButton();
//  ErrorDialog eDialog = new ErrorDialog();

  private String type[] = {"Short","Integer","Long","Unsigned Short","Unsigned Long","Float","Double","Char","Boolean","String"};
  private String coll[] = {"Single","Set"};
  JComboBox collect = new JComboBox(coll);
  JComboBox attrType = new JComboBox(type);

  JComboBox attrGranularity = new JComboBox();
  Vector setofAttr;
  int selAttr;
  JPanel panelButton = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JPanel panelName = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JPanel panelType = new JPanel();
  JPanel panelTimestamp = new JPanel();
  BorderLayout borderLayout4 = new BorderLayout();
  JPanel panelGranularity = new JPanel();
  BorderLayout borderLayout5 = new BorderLayout();
  JScrollPane scrollPaneDescription = new JScrollPane();
  JTextArea textAreaDescription = new JTextArea();
  JLabel labelDocuments = new JLabel();
  JPanel panelTimestampType = new JPanel();
  JLabel timestamp_type = new JLabel();
  JRadioButton timepoint = new JRadioButton();
  JRadioButton period = new JRadioButton();
  BorderLayout borderLayout1 = new BorderLayout();
  JPanel panelCheckbox = new JPanel();
  BoxLayout2 boxLayout21 = new BoxLayout2();
  ButtonGroup gTimestamp = new ButtonGroup();
  JPanel jPanel1 = new JPanel();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel jPanel2 = new JPanel();

  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  Border border1;
  FlowLayout flowLayout3 = new FlowLayout();
  FlowLayout flowLayout4 = new FlowLayout();

  public PropertiesAttribute(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropertiesAttribute() {
    this(null, "Attribute Properties", false);
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Type");
    titledBorder2 = new TitledBorder(BorderFactory.createLineBorder(Color.white,1),"Collect");
    titledBorder3 = new TitledBorder("");
    border1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Collect");
    lName.setPreferredSize(new Dimension(110, 20));
    lName.setHorizontalAlignment(SwingConstants.LEFT);
    lName.setText("Attribute Name: ");
    lTimeType.setPreferredSize(new Dimension(110, 23));
    lTimeType.setHorizontalAlignment(SwingConstants.LEFT);
    lTimeType.setText("Timestamp: ");
    granularity.setPreferredSize(new Dimension(110, 23));
    granularity.setToolTipText("");
    granularity.setHorizontalAlignment(SwingConstants.LEFT);
    granularity.setText("Granularity: ");
    buttonOK.setText("OK");
    buttonOK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonOK_actionPerformed(e);
      }
    });
    Cancel.setText("Cancel");
    Cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancel_actionPerformed(e);
      }
    });
    attrTimeType.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        attrTimeType_itemStateChanged(e);
      }
    });
/*    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowActivated(WindowEvent e) {
        this_windowActivated(e);
      }
    });
*/
    panelButton.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    this.getContentPane().setLayout(verticalFlowLayout1);
    this.setResizable(false);
    this.setTitle("Properties Attribute");
    panelName.setLayout(borderLayout2);
    panelType.setLayout(flowLayout2);
    panelTimestamp.setLayout(borderLayout4);
    panelGranularity.setLayout(borderLayout5);
    textAreaDescription.setBorder(BorderFactory.createLoweredBevelBorder());
    textAreaDescription.setRows(5);
    scrollPaneDescription.setBorder(BorderFactory.createEtchedBorder());
    scrollPaneDescription.setPreferredSize(new Dimension(379, 150));
    attrGranularity.setPreferredSize(new Dimension(200, 23));
    attrName.setPreferredSize(new Dimension(200, 20));
    attrTimeType.setPreferredSize(new Dimension(200, 23));
    labelDocuments.setPreferredSize(new Dimension(66, 23));
    labelDocuments.setText("Description:");
    panelName.setToolTipText("");
    timestamp_type.setPreferredSize(new Dimension(110, 16));
    timestamp_type.setText("Timestamp Type");
    panelTimestampType.setLayout(borderLayout1);
    timepoint.setText("TimePoint");
    period.setText("Period");
    panelCheckbox.setLayout(boxLayout21);
    attrType.setPreferredSize(new Dimension(150, 23));
    flowLayout2.setAlignment(FlowLayout.LEFT);
    collect.setPreferredSize(new Dimension(150, 23));
    collect.setActionCommand("collect");
    jPanel2.setBorder(titledBorder1);
    jPanel2.setLayout(flowLayout3);
    jPanel1.setBorder(border1);
    jPanel1.setPreferredSize(new Dimension(180, 60));
    jPanel1.setLayout(flowLayout4);
    panelTimestampType.add(timestamp_type, BorderLayout.WEST);
    panelButton.add(buttonOK, null);
    panelButton.add(Cancel, null);
    this.getContentPane().add(panelName, null);
    panelName.add(lName,  BorderLayout.WEST);
    panelName.add(attrName,  BorderLayout.CENTER);
    this.getContentPane().add(panelType, null);
    panelType.add(jPanel1, null);
    jPanel1.add(collect, null);
    panelType.add(jPanel2, null);
    jPanel2.add(attrType, null);
    this.getContentPane().add(panelTimestamp, null);
    panelTimestamp.add(lTimeType, BorderLayout.WEST);
    panelTimestamp.add(attrTimeType, BorderLayout.CENTER);
    this.getContentPane().add(panelGranularity, null);
    panelGranularity.add(granularity, BorderLayout.WEST);
    panelGranularity.add(attrGranularity, BorderLayout.CENTER);
    this.getContentPane().add(panelTimestampType, null);
    this.getContentPane().add(labelDocuments, null);
    this.getContentPane().add(scrollPaneDescription, null);
    scrollPaneDescription.getViewport().add(textAreaDescription, null);
    this.getContentPane().add(panelButton, null);
    panelTimestampType.add(panelCheckbox,  BorderLayout.CENTER);
    panelCheckbox.add(period, null);
    panelCheckbox.add(timepoint, null);

    gTimestamp.add(period);
    gTimestamp.add(timepoint);

  }

  public void loadInformation(Vector allAttr,int indexAttr){
    setofAttr = allAttr;
    selAttr = indexAttr;

    structureAttribute attr = (structureAttribute) allAttr.elementAt(indexAttr);
    attrName.setText(attr.getName());
    attrType.setSelectedItem(attr.getType());
    attrTimeType.setSelectedItem(attr.getsTimeStamp());
    attrGranularity.setSelectedItem(attr.getGranularity());
    collect.setSelectedItem(attr.getCollect());
    if(attr.getTimestampType().equals("Period"))
      period.setSelected(true);
    else
      timepoint.setSelected(true);
    textAreaDescription.setText(attr.getDescriptions());
  }

  public void checkTimeType(int timeType){
    attrTimeType.removeAllItems();
    attrTimeType.addItem(TimeType.getsTimeType(0));
    switch(timeType){
      case 1 : attrTimeType.addItem(TimeType.getsTimeType(1));
               break;
      case 2 : attrTimeType.addItem(TimeType.getsTimeType(2));
               break;
      case 3 : attrTimeType.addItem(TimeType.getsTimeType(1));
               attrTimeType.addItem(TimeType.getsTimeType(2));
               attrTimeType.addItem(TimeType.getsTimeType(3));
               break;
      default : break;
    }
  }

  public void addAttribute(Vector allAttr){
    selAttr = -1;
    setofAttr = allAttr;
    period.setSelected(true);
    attrName.setText("");
    textAreaDescription.setText("");
  }

  private void Cancel_actionPerformed(ActionEvent e) {
    this.setVisible(false);
  }

  private void buttonOK_actionPerformed(ActionEvent e) {
    structureAttribute attr;
    if(checkNameAttr()){
        if (selAttr == -1){
          attr = new structureAttribute();
          setPropertiesAttribute(attr);
          setofAttr.addElement(attr);   // Add new attribute to set of attribute
        }else{
          attr = (structureAttribute) setofAttr.elementAt(selAttr);
          setPropertiesAttribute(attr);
        }
        this.setVisible(false);
    }else{
      JOptionPane.showMessageDialog(this,"This attribute's name has already in use.\nOr attribute must have name.","TUML",JOptionPane.INFORMATION_MESSAGE);
    }
  }

  private void setPropertiesAttribute(structureAttribute attr){
     attr.setName(attrName.getText());
     attr.setType((String) attrType.getSelectedItem());
     int ts = TimeType.getiTimeType((String) attrTimeType.getSelectedItem());
     attr.setTimeStamp(ts);
     attr.setDescriptions(textAreaDescription.getText());
     switch(ts){
       case 0  : attr.setGranularity("Second");
                 break;
       case 2  : attr.setGranularity("Second");
                 break;
       default : attr.setGranularity((String) attrGranularity.getSelectedItem());
                 break;

     }
     attr.setCollect(collect.getSelectedItem().toString());
     if(period.isSelected())
        attr.setTimestampType("Period");
     else
        attr.setTimestampType("TimePoint");

 }

  public void checkGranularity(String gr){
    int iGr = Granularity.getIndexOf(gr);
    int max = Granularity.maxGanularity();
    attrGranularity.removeAllItems();
    for(; iGr < max ; iGr++)
      attrGranularity.addItem(Granularity.getGranularity(iGr));
  }


  private boolean  checkNameAttr(){
    int max = setofAttr.size();
    String name = attrName.getText();
    if(name.equals(""))
        return false;
    structureAttribute attr;
    for(int i = 0;  i < max ; i++){
        attr = (structureAttribute) setofAttr.elementAt(i);
        if(name.equals(attr.getName()) && (i != selAttr))
            return false;
    }
    return true;
  }

  void attrTimeType_itemStateChanged(ItemEvent e) {
/*    String selItem = (String) attrTimeType.getSelectedItem();
    if((selItem == TimeType.getsTimeType(1))||
       (selItem == TimeType.getsTimeType(3))){

      attrGranularity.setEnabled(true);
      if (selAttr >= 0){
        structureAttribute attr = (structureAttribute) setofAttr.elementAt(selAttr);
        attrGranularity.setSelectedItem(attr.getGranularity());
      }
    }else{
      attrGranularity.setEnabled(false);
      attrGranularity.setSelectedItem("Second");
    }
*/
    String selItem = (String) attrTimeType.getSelectedItem();
    if((selItem == TimeType.getsTimeType(1))||
       (selItem == TimeType.getsTimeType(3))){
//      panelGranularity.setVisible(true);
      panelCheckbox.setVisible(true);
      attrGranularity.setVisible(true);
      attrGranularity.setEnabled(true);
    }
    if(selItem == TimeType.getsTimeType(2)){
//      panelGranularity.setVisible(true);
      panelCheckbox.setVisible(true);
      attrGranularity.setVisible(true);
      attrGranularity.setEnabled(false);
      attrGranularity.setSelectedItem("Second");
      panelCheckbox.setVisible(false);
    }
    if(selItem == TimeType.getsTimeType(0)){
      attrGranularity.setVisible(false);
//        panelGranularity.setVisible(false);
      panelCheckbox.setVisible(false);
    }
  }

  public void showDialog(){
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    this.setVisible(true);


  }
/*  void this_windowActivated(WindowEvent e) {
    if(eDialog.isVisible())
      eDialog.showDialog();
  }
*/
}