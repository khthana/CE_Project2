package tumltool;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class structureLine {

  private FigClass _SrcClass;
  private FigClass _DesClass;
  private String _role = "";
  private String _invRole = "";
  private String _multiplicity = "one-to-one";
  private int _indexTimeType = 0;
  private int _granularity = 5;
  private String _timestampType = "";

  public structureLine() {

  }

  public void setSrcClass(FigClass SrcClass){
    _SrcClass = SrcClass;
  }

  public void setDesClass(FigClass DesClass){
    _DesClass = DesClass;
  }

  public void setRole(String role){
    _role = role;
  }

  public void setInvRole(String invRole){
    _invRole = invRole;
  }

  public void setMultiplicity(String multiplicity){
    _multiplicity = multiplicity;
  }

  public String getRole(){
    return _role;
  }

  public String getInvRole(){
    return _invRole;
  }

  public String getMultiplicity(){
    return _multiplicity;
  }

  public void setTimestampType(String TimestampType){
    _timestampType = TimestampType;
  }

  public String getTimestampType(){
    return _timestampType;
  }

  public void setTimeType(int indexTimeType){
    _indexTimeType = indexTimeType;
  }

  public void setTimeType(String timeType){
    _indexTimeType = TimeType.getiTimeType(timeType);
  }

  public String getsTimeType(){
    return TimeType.getsTimeType(_indexTimeType);
  }

  public int getiTimeType(){
    return _indexTimeType;
  }


  public void setGranularity(String granularity){
    _granularity = Granularity.getIndexOf(granularity);
  }

  public String getGranularity(){
    return Granularity.getGranularity(_granularity);
  }

  public FigClass getSrcClass(){
    return _SrcClass;
  }

  public FigClass getDesClass(){
    return _DesClass;
  }

}