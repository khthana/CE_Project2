package tumltool;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class TimeType {

//  0 --> Static Time
//  1 --> Valid Time
//  2 --> Transaction Time
//  3 --> Bitemporal Time

//  private int iTimeType = 0;
  private static String sTimeType[] = {"Static Time", "Valid Time", "Transaction Time", "Bitemporal Time",""};
  private static String nTimeType[] = {"st", "vt", "tt", "bt"}; // Nick Name

  public TimeType() {
  }

  public static int getiTimeType(String type){
    if(type.compareToIgnoreCase(sTimeType[0]) == 0)
//    ||(type == sTimeType[0]))
//    if(type.equalsIgnoreCase(sTimeType[0]))
      return 0;
    if(type.compareToIgnoreCase(sTimeType[1]) == 0)
//      ||(type == sTimeType[1]))
//    if(type.equalsIgnoreCase(sTimeType[1]))
      return 1;
    if(type.compareToIgnoreCase(sTimeType[2]) == 0)
//      ||(type == sTimeType[2]))
//    if(type.equalsIgnoreCase(sTimeType[2]))
      return 2;
    if(type.compareToIgnoreCase(sTimeType[3]) == 0)
//      ||(type == sTimeType[3]))
//    if(type.equalsIgnoreCase(sTimeType[3]))
      return 3;
    return -1;
  }

  public static String getsTimeType(int index){
    if (index <= 3)
      return sTimeType[index];
    return "error";
  }

  public static String getnTimeType(int index){
    if (index <= 3)
      return nTimeType[index];
    return "error";
  }

/*  public void Copy(TimeType newTime){
    this.iTimeType = newTime.iTimeType;
  }
*/
}