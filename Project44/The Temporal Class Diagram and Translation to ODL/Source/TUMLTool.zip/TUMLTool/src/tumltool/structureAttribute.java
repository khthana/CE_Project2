package tumltool;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class structureAttribute {
  private String attrName = "";
  private int indexTimeType = 0;
//attrType[] = {"Integer", "Float", "String", "Double", "Short", "Long"};
  private String attrType = "";
  private int granularity = 5;
  private String timestamp_type = "";
  private String descriptions = "";
  private String collect = "Single";

  public structureAttribute() {

  }

  public void Copy(structureAttribute newAttr){
    this.attrName = newAttr.attrName;
    this.attrType = newAttr.attrType;
    this.granularity = newAttr.granularity;
    this.indexTimeType = newAttr.indexTimeType;
    this.timestamp_type = newAttr.timestamp_type;
    this.collect  = newAttr.collect;
    this.descriptions = newAttr.descriptions;

  }

  public void setName(String name){
    attrName = name;
  }

  public void setGranularity(String gr){
    granularity = Granularity.getIndexOf(gr);
  }

  public void setGranularity(int gr){
    granularity = gr;
  }

  public void setType(String ntype){
    attrType = ntype;
  }

  public void setTimeStamp(int ts){
    indexTimeType = ts;
  }

  public void setTimeStamp(String ts){
    indexTimeType = TimeType.getiTimeType(ts);
  }

  public String getsTimeStamp(){
    return TimeType.getsTimeType(indexTimeType);
  }

  public String getnTimeStamp(){
    return TimeType.getnTimeType(indexTimeType);
  }

  public int getiTimeStamp(){
    return indexTimeType;
  }

  public String getGranularity(){
    return Granularity.getGranularity(granularity);
  }

  public int getiGranularity(){
    return granularity;
  }

  public String getType(){
    return attrType;
  }

  public String getName(){
    return attrName;
  }

  public void setTimestampType(String stamptype){
    timestamp_type = stamptype;
  }

  public String getTimestampType(){
    return timestamp_type;
  }

  public void setDescriptions(String descrip){
    descriptions = descrip;
  }

  public String getDescriptions(){
    return descriptions;
  }

  public void setCollect(String coll){
    collect = coll;
  }

  public String getCollect(){
    return collect;
  }

}