package tumltool;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import javax.swing.border.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PropertiesAggregation extends JDialog {
  VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  JPanel jPanel1 = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();
  JLabel labelsrcClass = new JLabel();
  JTextField nameSrcClass = new JTextField();
  JPanel jPanel2 = new JPanel();
  JLabel labelAggregateClass = new JLabel();
  JTextField nameAggClass = new JTextField();
  FlowLayout flowLayout2 = new FlowLayout();
  JPanel panelButton = new JPanel();
  JButton ok = new JButton();
  FlowLayout flowLayout3 = new FlowLayout();

  private boolean _completeAddNew = false;
  private boolean _prepareAddNew = false;

  private FigClass _srcClass;
  private FigClass _aggClass;
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;
  JPanel panelMultiplicity = new JPanel();
  TitledBorder titledBorder5;
  JRadioButton one = new JRadioButton();
  JRadioButton many = new JRadioButton();
  FlowLayout flowLayout8 = new FlowLayout();
  ButtonGroup tType = new ButtonGroup();
  ButtonGroup Multiplicity = new ButtonGroup();
  JButton Cancel = new JButton();

  FigAggregationLine _fAggLine;
  FigClass srcClass;
  FigClass aggClass;
  JPanel panelRole = new JPanel();
  TitledBorder titledBorder6;
  JLabel lableRoleName = new JLabel();
  JTextField roleName = new JTextField();

  public PropertiesAggregation(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public PropertiesAggregation() {
    this(null, "", false);
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Valid Time Timestamp");
    titledBorder2 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"VT Type");
    titledBorder3 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Granularity");
    titledBorder4 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Role");
    titledBorder5 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Multiplicity");
    titledBorder6 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Role");
    this.getContentPane().setLayout(verticalFlowLayout1);
    jPanel1.setLayout(flowLayout1);
    labelsrcClass.setPreferredSize(new Dimension(120, 16));
    labelsrcClass.setText("Source Class");
    nameSrcClass.setPreferredSize(new Dimension(220, 20));
    nameSrcClass.setEditable(false);
    labelAggregateClass.setPreferredSize(new Dimension(120, 16));
    labelAggregateClass.setText("Aggregation Class");
    nameAggClass.setPreferredSize(new Dimension(220, 20));
    nameAggClass.setEditable(false);
    jPanel2.setLayout(flowLayout2);
    ok.setText("OK");
    ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ok_actionPerformed(e);
      }
    });
    panelButton.setLayout(flowLayout3);
    flowLayout3.setAlignment(FlowLayout.RIGHT);
    this.setTitle("Aggregation Properties");
    panelMultiplicity.setBorder(titledBorder5);
    panelMultiplicity.setLayout(flowLayout8);
    one.setText("one");
    many.setText("many");
    Cancel.setText("Cancel");
    Cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancel_actionPerformed(e);
      }
    });
    lableRoleName.setPreferredSize(new Dimension(120, 16));
    lableRoleName.setText("Role");
    roleName.setPreferredSize(new Dimension(220, 20));
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(labelsrcClass, null);
    jPanel1.add(nameSrcClass, null);
    this.getContentPane().add(jPanel2, null);
    jPanel2.add(labelAggregateClass, null);
    jPanel2.add(nameAggClass, null);
    this.getContentPane().add(panelRole, null);
    this.getContentPane().add(panelMultiplicity, null);
    panelMultiplicity.add(one, null);
    panelMultiplicity.add(many, null);
    this.getContentPane().add(panelButton, null);
    panelButton.add(ok, null);
    panelButton.add(Cancel, null);
    this.setLocation(150,100);

    Multiplicity.add(one);
    Multiplicity.add(many);
    panelRole.add(lableRoleName, null);
    panelRole.add(roleName, null);


//    listGranularity.removeAllItems();

  }

  private void ok_actionPerformed(ActionEvent e) {
    if (roleName.getText().length() == 0)
      JOptionPane.showMessageDialog(this,"Please Enter Role Name","Warning Message",JOptionPane.WARNING_MESSAGE);
    else {
      _completeAddNew = _prepareAddNew;
      if(!_prepareAddNew)
        updateProperties(_fAggLine);
      this.setVisible(false);
    }
  }

  private void Cancel_actionPerformed(ActionEvent e) {
    _completeAddNew = false;
    _prepareAddNew = false;
    this.setVisible(false);
  }

  public void loadProperties(FigAggregationLine fAggLine){

    _fAggLine = fAggLine;
//    role.setText(fAggLine.getRole());
//    inverseRole.setText(fAggLine.getInverseRole());
//    setListTimeType();

    FigClass srcClass = fAggLine.getSrcClass();
    nameSrcClass.setText(srcClass.getName());

    FigClass aggClass = fAggLine.getAggregationClass();
    nameAggClass.setText(aggClass.getName());

//    listTimeType.setSelectedItem(fAggLine.getsTimeType());
//    listGranularity.setSelectedItem(fAggLine.getGranularity());


//    String tsType = fAggLine.getTimestampType();
/*    if(tsType.compareToIgnoreCase(period.getText()) == 0)
      period.setSelected(true);
    else
      timepoint.setSelected(true);
*/

    roleName.setText(fAggLine.getRole());
    String multi = fAggLine.getMultiplicity();

    if(multi.compareToIgnoreCase(many.getText())  == 0)  many.setSelected(true);
    else one.setSelected(true);
//    if(multi.compareToIgnoreCase(many2one.getText())  == 0)  many2one.setSelected(true);
//    if(multi.compareToIgnoreCase(many2many.getText()) == 0)  many2many.setSelected(true);

  }

  public void updateProperties(FigAggregationLine fALine){
//    updateLine(fALine);
    fALine.setRole(roleName.getText());
//    fALine.setInverseRole(inverseRole.getText());
    if(one.isSelected())   fALine.setMultiplicity(one.getText());
    if(many.isSelected())  fALine.setMultiplicity(many.getText());
///    if(many2one.isSelected())  fALine.setMultiplicity(many2one.getText());
//    if(many2many.isSelected()) fALine.setMultiplicity(many2many.getText());

//    fALine.setTimeType((String) listTimeType.getSelectedItem());
//    fALine.setGranularity((String) listGranularity.getSelectedItem());
/*    if(period.isSelected())
      fALine.setTimestampType(period.getText());
    else
      fALine.setTimestampType(timepoint.getText());
*/  }


  public void showDialog(){
    if(_prepareAddNew){
      nameSrcClass.setText(srcClass.getName());
      nameAggClass.setText(aggClass.getName());
//      setListTimeType();
    }

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = this.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    this.setVisible(true);
  }

/*  void listTimeType_itemStateChanged(ItemEvent e) {
    String selItem = (String) listTimeType.getSelectedItem();
    if((selItem == TimeType.getsTimeType(1))||
       (selItem == TimeType.getsTimeType(3))){
       setVT(true,true);
    }
    if(selItem == TimeType.getsTimeType(2)){
       setVT(false,true);
       listGranularity.setSelectedItem(Granularity.getGranularity(5));
    }
    if(selItem == TimeType.getsTimeType(0)){
       setVT(false,false);
    }
  }
*/
/*  private void setVT(boolean status1,boolean status2){
//    period.setVisible(status1);
    timepoint.setVisible(status1);

    listGranularity.setVisible(status2);
    listGranularity.setEnabled(status1);
  }
*/

  public boolean isAddNew(){
    return _completeAddNew;
  }

  public void addNew(boolean b){
    _prepareAddNew = b;
    _completeAddNew = false;
//    period.setSelected(true);
    one.setSelected(true);
    roleName.setText("");
//    role.setText("");
//    inverseRole.setText("");
//    _oldTimeType = 0;
  }
  public void setSrcClass(FigClass sClass) {
    srcClass = sClass;
  }

  public void setAggregateClass(FigClass aClass) {
    aggClass = aClass;
  }

  public FigClass getSrcClass(){
    return srcClass;
  }

  public FigClass getAggregateClass(){
    return aggClass;
  }


}