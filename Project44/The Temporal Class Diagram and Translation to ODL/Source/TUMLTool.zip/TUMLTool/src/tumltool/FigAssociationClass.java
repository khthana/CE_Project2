package tumltool;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FigAssociationClass extends FigClass {
  FigClass srcClass;
  FigClass desClass;
  FigLine  mainLine;
  public FigAssociationClass(FigClass sClass,FigClass dClass) {
    srcClass = sClass;
    desClass = dClass;
  }
}