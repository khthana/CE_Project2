package tumltool;

import java.util.*;
import java.awt.*;
//import javax.swing.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class GenerateTemporalODL extends GenerateCode{

  public GenerateTemporalODL() {
  }

  public GenerateTemporalODL(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
  }

  public void genCode(String path,Vector vClass,Vector vInheritance,Vector vAssociation,Vector vAggregation,Vector vTernary){
    resetCode();

    genFromClass(vClass);
    genFromInheritance(vInheritance);
    genFromAssociation(vAssociation);
    genFromAggregation(vAggregation);
    genFromNary(vTernary);
    _code.append(_SPcode);
    this.exportToPath(path,"TODL");
  }

  private void genFromClass(Vector vClass){
    FigClass _class;
    Vector _setAttr;
    structureAttribute _attr;
    for(int i = 0 ; i < vClass.size() ; i++){
      _class = (FigClass) vClass.elementAt(i);

      _code.append(_interface + " " + _class.getName() + "  :\r\n"
                   + "( extent " + _class.getName() + "s )\r\n{\r\n" + _space5 );


      switch(_class.getiTimeType()){
       case 1 : _code.append(_attribute + " Temporal_Element<" + _class.getGranularity().toUpperCase()
                           + "> vt_lifespan;\r\n\r\n" + _space5);
                break;
       case 2 : _code.append(_attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n\r\n"
                           + _space5);
                break;
       case 3 : _code.append(_attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n"
                          +  _space5 + "typedef struct{Period<SECOND> tt_timestamp; \r\n"
                          +  _space5 + _space5 + "Temporal_Element<"
                          + _class.getGranularity().toUpperCase()
                          + "> vt_lifespan} VT_Lifespan_Element;\r\n"
                          + _space5 + _attribute + " Set<VT_Lifespan_Element> vt_lifespan;\r\n\r\n"
                          + _space5);
                break;
       default : break;
      }


      _code.append("// Attribute Part\r\n");
      // Start Generate Code from Attribute
          _setAttr = _class.getAttribute();
          for(int j=0 ; j < _setAttr.size() ; j++){
            _attr = (structureAttribute) _setAttr.elementAt(j);
            switch(_attr.getiTimeStamp()){
              case 1  : _code.append(_space5 + _attribute + " Set<struct element{"
                                   + _attr.getType() + " value," + _attr.getTimestampType()
                                   + "<" + _attr.getGranularity().toUpperCase() + "> vt_timestamp"
                                   + "}> " + _attr.getName() + ";\r\n");
                        break;
              case 2  : _code.append(_space5 + _attribute + " Set<struct element{"
                                   + _attr.getType() + " value,Period<SECOND> tt_timestamp"
                                   + "}> " + _attr.getName() + ";\r\n");
                        break;
              case 3  : _code.append(_space5 + _attribute + " Set<struct element{"
                                   + _attr.getType() + " value,Period" // " + _attr.getTimestampType()
                                   + "<SECOND> tt_timestamp, \r\n"
                                   + _space5 + _space5 + _attr.getTimestampType() + "<"
                                   + _attr.getGranularity().toUpperCase() + "> vt_timestamp"
                                   + "}> " + _attr.getName() + ";\r\n");

                        break;
              default : if(_attr.getCollect().compareToIgnoreCase("Single") == 0)
                          _code.append(_space5 + _attribute + " " + _attr.getType() + " " + _attr.getName() + ";\r\n");
                        else
                          _code.append(_space5 + _attribute + " " + _attr.getCollect() + "<" + _attr.getType() + "> " + _attr.getName() + ";\r\n");
                        break;
            }
          }
      // End Generate Code from Attribute
      _code.append(_space5 + "// End Attribute Part of "+ _class.getName() + "\r\n\r\n"
        + _space5 + "// Relationship Part\r\n"
        + _space5 + "// End Relationship Part of "+ _class.getName() + "\r\n"
        + "}; \r\n\r\n");
    }
  }

  private void genFromInheritance(Vector vInherit){
    FigInheritanceLine _inherit;
    FigClass _parentClass,_inheritClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";

    int index = 0;
    for(int i = 0 ; i < vInherit.size() ; i++){
      _inherit = (FigInheritanceLine) vInherit.elementAt(i);
      _parentClass = _inherit.getParentClass();
      _inheritClass = _inherit.getInheritClass();

      searchString = _interface + " " + _inheritClass.getName() + "  :";
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      index = index + searchString.length();
      _code2insert = "  " + _parentClass.getName() +  " ,"; // prepare code to insert

      _code = _code.insert(index,_code2insert);
    }
    replaceCode(_code,":\r\n","\r\n");
    replaceCode(_code,",\r\n","\r\n");
  }

  private void genFromAssociation(Vector vAssociation){
    FigAssociationLine _association;
    FigClass _srcClass,_desClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _role = "";
    String _invRole = "";
    String _multiplicity = "";

    String _newClassName = "";
    String _newRole = "";
    String _newInvRole = "";

    int index = 0;
    for(int i = 0 ; i < vAssociation.size() ; i++){
      _association = (FigAssociationLine) vAssociation.elementAt(i);
      _srcClass = _association.getSrcClass();
      _desClass = _association.getDesClass();
      _role = _association.getRole();
      _invRole = _association.getInverseRole();
      _multiplicity = _association.getMultiplicity();

      genAssociation(_association.getiTimeType(),_association.getTimestampType()
                    ,_association.getGranularity(),_srcClass.getName(),_desClass.getName()
                    ,_role,_invRole,_multiplicity);
/*      _newClassName = _srcClass.getName() + "_" + _role + "_" + _desClass.getName() + "_" + _invRole;
      _newRole = "i_" + _role;
      _newInvRole = "i_" + _invRole;
*/
/*      searchString = _space5 + "// End Relationship Part of "+ _srcClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code

      // ----- prepare code to insert ------
      switch(_association.getiTimeType()){
        case 1  :
                  _code2insert = _space5 + _relationship
                  + "<" + _association.getTimestampType().charAt(0) + ","
                  + _association.getGranularity().toUpperCase() + ">";
                  break;
        case 2  :
               //_code2insert = _space5 + _tt  + _relationship;
                  _code2insert = _space5 + _relationship;
                  break;
        case 3  :
                  _code2insert = _space5 + _relationship
                  + "<" + _association.getTimestampType().charAt(0) + ","
                  + _association.getGranularity().toUpperCase() + ">";
                  break;
        default : _code2insert = _space5 + _relationship;
                  break;

      }


      if(_association.getiTimeType() == 0 ){
          if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("many-to-one")))
              _code2insert = _code2insert + " " + _desClass.getName()+ " " + _role
                           + "\r\n" + _space5 + _space5 + _inverse + " " + _desClass.getName() + "::"  + _invRole + ";\r\n";
          else
              _code2insert = _code2insert + " Set<" + _desClass.getName()+ "> " + _role
                       + "\r\n" + _space5 + _space5 + _inverse + " " + _desClass.getName() + "::"  + _invRole + ";\r\n";
      }else
          _code2insert = _code2insert + " Set<" + _newClassName + "> " + _role + "\r\n"
                  + _space5 + _space5 + _inverse + " " + _newClassName + "::"  + _newRole + ";\r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Source Class **************


      // ----- Start Insert Code for Destination Class --------
      searchString = _space5 + "// End Relationship Part of "+ _desClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code

      // ----- prepare code to insert ------

      switch(_association.getiTimeType()){
        case 1  : _code2insert = _space5 + _relationship
                  + "<" + _association.getTimestampType().charAt(0) + ","
                  + _association.getGranularity().toUpperCase() + ">";
                  break;
        case 2  : _code2insert = _space5 + _relationship;
                  break;
        case 3  : _code2insert = _space5 + _relationship
                  + "<" + _association.getTimestampType().charAt(0) + ","
                  + _association.getGranularity().toUpperCase() + ">";
                  break;
        default : _code2insert = _space5 + _relationship;
                  break;
      }

      if(_association.getiTimeType() == 0 ){
          if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("one-to-many")))
              _code2insert = _code2insert + " " + _srcClass.getName() + " " + _invRole
                         + "\r\n" + _space5 + _space5 + _inverse + " " + _srcClass.getName() + "::"  + _role + ";\r\n";
          else
              _code2insert = _code2insert + " Set<" + _srcClass.getName()+ "> " + _invRole
                         + "\r\n" + _space5 + _space5 + _inverse + " " + _srcClass.getName() + "::"  + _role + ";\r\n";
      }else
          _code2insert = _code2insert + " Set<" + _newClassName + "> " + _invRole
                       + "\r\n" + _space5 + _space5 + _inverse + " " + _newClassName + "::"  + _newInvRole + ";\r\n";

      _code = _code.insert(index,_code2insert);

      // ****** End Insert Code for Destination Class **********



      // ------ Start Insert Code for NewClass ----------------
      if(_association.getiTimeType() != 0 ){
          _code2insert = _interface + " " +_newClassName + " \r\n"
                       + "( extent " + _newClassName + "s )\r\n{\r\n" + _space5;


          switch( _association.getiTimeType() ){
           case 1 : _code2insert = _code2insert + _attribute + " Temporal_Element<" + _association.getGranularity().toUpperCase()
                               + "> vt_lifespan;\r\n\r\n";
                    break;
           case 2 : _code2insert = _code2insert + _attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n\r\n";
                    break;
           case 3 : _code2insert = _code2insert + _attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n"
                              +  _space5 + "typedef struct{Period<SECOND> tt_timestamp; \r\n"
                              +  _space5 + _space5 + "Temporal_Element<"
                              + _association.getGranularity().toUpperCase()
                              + "> vt_lifespan} VT_Lifespan_Element;\r\n"
                              + _space5 + _attribute + " Set<VT_Lifespan_Element> vt_lifespan;\r\n\r\n";
                    break;
           default : break;
          }

          _code2insert = _code2insert + _space5 + _relationship + " "
                       + _srcClass.getName() + " " + _newRole + "\r\n"
                       + _space5 + _space5 + _inverse + " " + _srcClass.getName() + "::"
                       + _role + ";\r\n";


          _code2insert = _code2insert + _space5 + _relationship + " "
                       + _desClass.getName() + " " + _newInvRole + "\r\n"
                       + _space5 + _space5 + _inverse + " " + _desClass.getName() + "::"
                       + _invRole + ";\r\n";

          _code2insert = _code2insert + "};\r\n\r\n";

          _code = _code.append(_code2insert);
      }
*/
      // ****** end Insert Code for NewClass ****************
    }
  }

  private void genFromAggregation(Vector vAggregation){
    FigAggregationLine _aggregation;
    FigClass _aggregateClass,_srcClass;
    String _code2insert = "";
    String _tempCode  = "";
    String _searchString = "";
    String _multiplicity = "";

    int index = 0;
    for(int i = 0 ; i < vAggregation.size() ; i++){
      _aggregation = (FigAggregationLine) vAggregation.elementAt(i);
      _srcClass = _aggregation.getSrcClass();
      _aggregateClass = _aggregation.getAggregationClass();
      _multiplicity = _aggregation.getMultiplicity();

      _searchString = _space5 + "// End Attribute Part of " + _srcClass.getName();
       _tempCode = _code.toString();
      index = _tempCode.indexOf(_searchString); // search index to insert code

      // ----- prepare code to insert ------
      if(_multiplicity.equals("one"))
          _code2insert = _space5 + _attribute + " " + _aggregateClass.getName() +
                         " " + _aggregation.getRole() + ";\r\n";
      else
          _code2insert = _space5 + _attribute + " Set<" + _aggregateClass.getName() +
                         "> " + _aggregation.getRole() + ";\r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Source Class **************
    }
  }

  private void genFromNary(Vector vTernary){
    FigNary _fNary;
    FigClass _fClass,_sClass,_tClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _role = "";
    String _invRole = "";
    String _multiplicity = "";

    String _newClassName = "";
    int index = 0;

    for(int i = 0 ; i < vTernary.size() ; i++){
      _fNary = (FigNary) vTernary.elementAt(i);

      _fClass = _fNary.getFClass();
      _sClass = _fNary.getSClass();
      _tClass = _fNary.getTClass();
      _role   = _fNary.getRoleName();
      _invRole = "NaryINV" + _role;
//      _newClassName = _fClass.getName() + _sClass.getName() + _tClass.getName() + _role;
      _newClassName = "NaryClass" + _role;

      // Create New Class
      _code = _code.append(_interface + " " + _newClassName + " \r\n"
        + "( extent "+ _newClassName + "s )\r\n"
        + "{ \r\n" + _space5);

      switch(_fNary.getIndexTimeType()){
       case 1 : _code.append(_attribute + " Temporal_Element<" + _fNary.getGranularity().toUpperCase()
                           + "> vt_lifespan;\r\n\r\n" + _space5);
                break;
       case 2 : _code.append(_attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n\r\n"
                           + _space5);
                break;
       case 3 : _code.append(_attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n"
                          +  _space5 + "typedef struct{Period<SECOND> tt_timestamp; \r\n"
                          +  _space5 + _space5 + "Temporal_Element<"
                          + _fNary.getGranularity().toUpperCase()
                          + "> vt_lifespan} VT_Lifespan_Element;\r\n"
                          + _space5 + _attribute + " Set<VT_Lifespan_Element> vt_lifespan;\r\n\r\n"
                          + _space5);
                break;
       default : break;
      }


      _code = _code.append("// Attribute Part\r\n"
        + _space5 + "// End Attribute Part of "+ _newClassName + "\r\n\r\n"

        + _space5 + "// Relationship Part\r\n"
        + _space5 + "// End Relationship Part of "+ _newClassName + "\r\n"
        + "}; \r\n\r\n");

      // Create Relationship
      genAssociation(_fNary.getIndexTimeType(),_fNary.getTimestampType()
                    ,_fNary.getGranularity(),_fClass.getName(),_newClassName
                    ,_role,_invRole,"one-to-many");

      genAssociation(_fNary.getIndexTimeType(),_fNary.getTimestampType()
                    ,_fNary.getGranularity(),_sClass.getName(),_newClassName
                    ,_role,_invRole,"one-to-many");

      genAssociation(_fNary.getIndexTimeType(),_fNary.getTimestampType()
                    ,_fNary.getGranularity(),_tClass.getName(),_newClassName
                    ,_role,_invRole,"one-to-many");

    }
  }

  private void genAssociation(int iTimeType,String TimestampType,String granularity,String _srcClass,String _desClass,String _role,String _invRole,String _multiplicity){
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";

    String _newClassName = "";
    String _newRole = "";
    String _newInvRole = "";
    int index = 0;

      _newClassName = _srcClass + "_" + _role + "_" + _desClass + "_" + _invRole;
      _newRole = "i_" + _role;
      _newInvRole = "i_" + _invRole;

      searchString = _space5 + "// End Relationship Part of "+ _srcClass;
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code

      // ----- prepare code to insert ------
      switch(iTimeType){
        case 1  :
                  _code2insert = _space5 + _relationship
                  + "<" + TimestampType.charAt(0) + ","
                  + granularity.toUpperCase() + ">";
                  break;
        case 2  :
                  _code2insert = _space5 + _relationship;
                  break;
        case 3  :
                  _code2insert = _space5 + _relationship
                  + "<" + TimestampType.charAt(0) + ","
                  + granularity.toUpperCase() + ">";
                  break;
        default : _code2insert = _space5 + _relationship;
                  break;

      }


      if(iTimeType == 0 ){
          if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("many-to-one")))
              _code2insert = _code2insert + " " + _desClass+ " " + _role
                           + "\r\n" + _space5 + _space5 + _inverse + " " + _desClass + "::"  + _invRole + ";\r\n";
          else
              _code2insert = _code2insert + " Set<" + _desClass+ "> " + _role
                       + "\r\n" + _space5 + _space5 + _inverse + " " + _desClass + "::"  + _invRole + ";\r\n";
      }else
          _code2insert = _code2insert + " Set<" + _newClassName + "> " + _role + "\r\n"
                  + _space5 + _space5 + _inverse + " " + _newClassName + "::"  + _newRole + ";\r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Source Class **************


      // ----- Start Insert Code for Destination Class --------
      searchString = _space5 + "// End Relationship Part of "+ _desClass;
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code

      // ----- prepare code to insert ------

      switch(iTimeType){
        case 1  : _code2insert = _space5 + _relationship
                  + "<" + TimestampType.charAt(0) + ","
                  + granularity.toUpperCase() + ">";
                  break;
        case 2  : _code2insert = _space5 + _relationship;
                  break;
        case 3  : _code2insert = _space5 + _relationship
                  + "<" + TimestampType.charAt(0) + ","
                  + granularity.toUpperCase() + ">";
                  break;
        default : _code2insert = _space5 + _relationship;
                  break;
      }

      if(iTimeType == 0 ){
          if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("one-to-many")))
              _code2insert = _code2insert + " " + _srcClass + " " + _invRole
                         + "\r\n" + _space5 + _space5 + _inverse + " " + _srcClass + "::"  + _role + ";\r\n";
          else
              _code2insert = _code2insert + " Set<" + _srcClass+ "> " + _invRole
                         + "\r\n" + _space5 + _space5 + _inverse + " " + _srcClass + "::"  + _role + ";\r\n";
      }else
          _code2insert = _code2insert + " Set<" + _newClassName + "> " + _invRole
                       + "\r\n" + _space5 + _space5 + _inverse + " " + _newClassName + "::"  + _newInvRole + ";\r\n";

      _code = _code.insert(index,_code2insert);

      // ****** End Insert Code for Destination Class **********



      // ------ Start Insert Code for NewClass ----------------
      if(iTimeType != 0 ){
          _code2insert = _interface + " " +_newClassName + " \r\n"
                       + "( extent " + _newClassName + "s )\r\n{\r\n" + _space5;


          switch( iTimeType ){
           case 1 : _code2insert = _code2insert + _attribute + " Temporal_Element<" + granularity.toUpperCase()
                               + "> vt_lifespan;\r\n\r\n";
                    break;
           case 2 : _code2insert = _code2insert + _attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n\r\n";
                    break;
           case 3 : _code2insert = _code2insert + _attribute + " Temporal_Element<SECOND> tt_lifespan;\r\n"
                              +  _space5 + "typedef struct{Period<SECOND> tt_timestamp; \r\n"
                              +  _space5 + _space5 + "Temporal_Element<"
                              + granularity.toUpperCase()
                              + "> vt_lifespan} VT_Lifespan_Element;\r\n"
                              + _space5 + _attribute + " Set<VT_Lifespan_Element> vt_lifespan;\r\n\r\n";
                    break;
           default : break;
          }

          _code2insert = _code2insert + _space5 + _relationship + " "
                       + _srcClass + " " + _newRole + "\r\n"
                       + _space5 + _space5 + _inverse + " " + _srcClass + "::"
                       + _role + ";\r\n";


          _code2insert = _code2insert + _space5 + _relationship + " "
                       + _desClass + " " + _newInvRole + "\r\n"
                       + _space5 + _space5 + _inverse + " " + _desClass + "::"
                       + _invRole + ";\r\n";

          _code2insert = _code2insert + "};\r\n\r\n";

          _code = _code.append(_code2insert);
      }
      // ****** end Insert Code for NewClass ****************
  }

}