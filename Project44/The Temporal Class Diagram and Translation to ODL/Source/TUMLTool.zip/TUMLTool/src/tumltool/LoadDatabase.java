package tumltool;
import java.util.*;
import COM.intersys.objects.*;
import COM.intersys.util.*;
import COM.intersys.util.CacheException;
import COM.intersys.util.SysList;
import Model.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class LoadDatabase {
  ObjectFactory mFactory = null;
  PropertiesProject Diagram = null;
  Vector vClass = new Vector();
  Vector vInheritance = new Vector();
  Vector vAssociation = new Vector();
  Vector vAggregation = new Vector();
  Vector vTernary = new Vector();

  public LoadDatabase(ObjectFactory aFactory) {
    mFactory = aFactory;
  }

  private structureAttribute loadAttribute(Oid oid){
  structureAttribute rAttr = new structureAttribute();
    try {
      Attribute mAttribute = new Attribute(mFactory,oid);
      rAttr.setName(mAttribute.getName());
      rAttr.setDescriptions(mAttribute.getDescriptions());
      rAttr.setGranularity(mAttribute.getGranularity());
      rAttr.setTimestampType(mAttribute.getTimestampType());
      rAttr.setType(mAttribute.getType());
      rAttr.setCollect(mAttribute.getCollection());
      rAttr.setTimeStamp(mAttribute.getIndexTimeType());
      mAttribute._close();
      mAttribute = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return rAttr;
  }

  private FigClass loadClass(Oid oid){
  FigClass rClass = new FigClass();
  ListOfObjects mList = null;
  Vector vAttribute = new Vector();
    try {
      Classes mClass = new Classes(mFactory,oid);
      rClass.setName(mClass.getName());
      rClass.setDescriptions(mClass.getDescriptions());
      rClass.setGranularity(mClass.getGranularity());
      rClass.setTimeType(mClass.getIndexTimeType());
      rClass.setPoint(mClass.getPointX(),mClass.getPointY());
      rClass.setId(mClass.getId());
      rClass.setAssociationTT(mClass.getAssociationTT());
      rClass.setAssociationVT(mClass.getAssociationVT());
      rClass.setAssociationBT(mClass.getAssociationBT());
      rClass.setWidth(mClass.getWidth());
      rClass.setHigh(mClass.getHigh());
      rClass.setOid(mClass._getOid());
      mList = mClass.getlistAttribute();
      for (int i = 1 ; i <= mList._count() ; i++){
        vAttribute.addElement(loadAttribute(mList._getObjectAt(i)));
      }
      rClass.setAttribute(vAttribute);
      mClass._close();
      mClass = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return rClass;
  }

  private FigClass getClass(Oid id) {
    for (int i=0;i < vClass.size();i++) {
      FigClass figClass = (FigClass) vClass.elementAt(i);
      try {
      if (id.getIdInt() == figClass.getOid().getIdInt())
        return figClass;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return null;
  }

  private FigInheritanceLine loadInheritance(Oid id){
  FigInheritanceLine rInherit = new FigInheritanceLine();
    try {
      InheritanceLine mLine = new InheritanceLine(mFactory,id);
      rInherit.setParentClass(getClass(mLine.getSuperClass()._getOid()));
      rInherit.setInheritClass(getClass(mLine.getSubClass()._getOid()));
      rInherit.setOid(mLine._getOid());
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return rInherit;
  }

  private FigAssociationLine loadAssociation(Oid id){
  FigAssociationLine rLine = new FigAssociationLine();
    try {
      AssociationLine mLine = new AssociationLine(mFactory,id);
      rLine.setSrcClass(getClass(mLine.getSrcClass()._getOid()));
      rLine.setDesClass(getClass(mLine.getDesClass()._getOid()));
      rLine.setRole(mLine.getName());
      rLine.setInverseRole(mLine.getInvName());
      rLine.setMultiplicity(mLine.getMultiplicity());
      rLine.setTimestampType(mLine.getTimestampType());
      rLine.setTimeType(mLine.getIndexTimeType());
      rLine.setGranularity(mLine.getGranularity());
      rLine.setOid(mLine._getOid());
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return rLine;
  }

  private FigAggregationLine loadAggregation(Oid id){
  FigAggregationLine rLine = new FigAggregationLine();
    try {
      AggregationLine mLine = new AggregationLine(mFactory,id);
      rLine.setSrcClass(getClass(mLine.getSrcClass()._getOid()));
      rLine.setAggregateClass(getClass(mLine.getAggregationClass()._getOid()));
      rLine.setMultiplicity(mLine.getMultiplicity());
      rLine.setRole(mLine.getRoleName());
      rLine.setOid(mLine._getOid());
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return rLine;
  }

  private FigNary loadTernary(Oid Id) {
  FigNary rNary = new FigNary();
    try {
      TernaryLine mLine = new TernaryLine(mFactory, Id);
      rNary.setRoleName(mLine.getRoleName());
      rNary.setX(mLine.getCoordinateX());
      rNary.setY(mLine.getCoordinateY());
      rNary.setIndexTimeType(mLine.getIndexTimeType());
      rNary.setGranularity(mLine.getGranularity());
      rNary.setTimestampType(mLine.getTimestampType());
      rNary.setFClass(getClass(mLine.getFirstClass()._getOid()));
      rNary.setSClass(getClass(mLine.getSecondClass()._getOid()));
      rNary.setTClass(getClass(mLine.getThirdClass()._getOid()));
      rNary.setOid(mLine._getOid());
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return rNary;
  }

  private void loadDiagram(Oid Id){
  ListOfObjects mList = null;
  ListOfObjects mListInherit = null;
  ListOfObjects mListAssocia = null;
  ListOfObjects mListAggrega = null;
  ListOfObjects mListTernary = null;
    try {
      Diagrams mDiagram = new Diagrams(mFactory,Id);
      Diagram.setName(mDiagram.getName());
      Diagram.setDescription(mDiagram.getDescriptions());
      Diagram.setDesigner(mDiagram.getDesigner());
      Diagram.setPackage(mDiagram.getPackage());
      Diagram.setOid(mDiagram._getOid());
      mList = mDiagram.getlistClasses();
      for (int i = 1 ; i <= mList._count() ; i++){
        vClass.addElement(loadClass(mList._getObjectAt(i)));
      }
      mListInherit = mDiagram.getlistRelationInheritance();
      for (int i = 1 ; i <= mListInherit._count() ; i++){
        vInheritance.addElement(loadInheritance(mListInherit._getObjectAt(i)));
      }
      mListAssocia = mDiagram.getlistRelationAssociation();
      for (int i = 1 ; i <= mListAssocia._count() ; i++){
        vAssociation.addElement(loadAssociation(mListAssocia._getObjectAt(i)));
      }
      mListAggrega = mDiagram.getlistRelationAggregation();
      for (int i = 1 ; i <= mListAggrega._count() ; i++){
        vAggregation.addElement(loadAggregation(mListAggrega._getObjectAt(i)));
      }
      mListTernary = mDiagram.getlistRelationTernary();
      for (int i = 1 ; i <= mListTernary._count() ; i++){
        vTernary.addElement(loadTernary(mListTernary._getObjectAt(i)));
      }
      mListTernary._close();
      mListTernary = null;
      mListAggrega._close();
      mListAggrega = null;
      mListAssocia._close();
      mListAssocia = null;
      mListInherit._close();
      mListInherit = null;
      mList._close();
      mList = null;
      mDiagram._close();
      mDiagram = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void Load(PropertiesProject aDiagram) {
    try {
      Diagram = aDiagram;
      loadDiagram(Diagram.getOid());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public PropertiesProject  getDiagram() {
    return Diagram;
  }

  public Vector getVClass() {
    return vClass;
  }

  public Vector getVInheritance() {
    return vInheritance;
  }

  public Vector getVAssociation() {
    return vAssociation;
  }

  public Vector getVAggregation() {
    return vAggregation;
  }

  public Vector getVTernary() {
    return vTernary;
  }
}




