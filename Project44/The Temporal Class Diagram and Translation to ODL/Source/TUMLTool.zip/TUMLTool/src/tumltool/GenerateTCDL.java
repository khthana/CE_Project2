package tumltool;

import java.util.*;
import java.awt.*;
import javax.swing.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class GenerateTCDL extends GenerateCode {



  public GenerateTCDL() {
  }


  public GenerateTCDL(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
  }

  public void genCode(String path,Vector vClass,Vector vInheritance,Vector vAssociation,Vector vAggregation,Vector vTernary){
    boolean _error = false;
//    _code.delete(0,_code.capacity());
//    _SPcode.delete(0,_SPcode.capacity());
    resetCode();
    _SPcode.append("// -------- Addition Code ---------- \r\n\r\n");

    _error = false;
    genFromClass(vClass);
    genFromInheritance(vInheritance);
    _error = genFromAssociation(vAssociation);

    if(_error)
      JOptionPane.showMessageDialog(this,"Have one-to-one or many-to-many relationship can't generate to CDL","TUML",JOptionPane.ERROR_MESSAGE);
    else{
      genFromAggregation(vAggregation);
      _code.append(_SPcode);    // Add Special Code
      genFromNary(vTernary);
      genStorageDefault();
      exportToPath(path,"CDL");
    }
  }


  private void genFromClass(Vector vClass){

    FigClass _class;
    Vector _setAttr;
    structureAttribute _attr;
    String attrCode = "";

    for(int i = 0 ; i < vClass.size() ; i++){
      _class = (FigClass) vClass.elementAt(i);
      _code.append(_classString + " " + _packageName + "." + _class.getName() + "  \r\n"
        + "{ \r\n"
        + _space5 + "super = %Library.Persistent; \r\n\r\n"
        + _space5 + "persistent; \r\n\r\n");

      switch(_class.getiTimeType()){
       case 1 :
                _code.append(_space5 + _commentTIME + _class.getName() + " \r\n");
                _code.append(_space5 + _attribute + " vtTimestamp "
                  + " { type = TemporalElement.GR" + _class.getGranularity().toUpperCase() + "; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");
                _code.append(_space5 + _commentEnd + _class.getName() + " \r\n");
                break;
       case 2 :
                _code.append(_space5 + _commentTIME + _class.getName() + " \r\n");
                _code.append(_space5 + _attribute + " ttTimestamp "
                  + " { type = TemporalElement.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");
                _code.append(_space5 + _commentEnd + _class.getName() + " \r\n");
                break;
       case 3 :
                _code.append(_space5 + _commentTIME + _class.getName() + " \r\n");
                _code.append(_space5 + _attribute + " ttTimestamp "
                  + " { type = TemporalElement.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                  + _space5 + _commentMiddleEnd

                  + _space5 + "list " + _attribute + " vtTimestamp "
                  + " { type = " + _packageName + ".btTimestamp" + _class.getName() + "; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");
                _code.append(_space5 + _commentEnd + _class.getName() + " \r\n");

                _SPcode.append(_classString + " " + _packageName + ".btTimestamp" + _class.getName() + "  \r\n"
                  + "{ \r\n"
                  + _space5 + "super = %Library.SerialObject; \r\n\r\n"
                  + _space5 + "serial; \r\n\r\n"

                  + _space5 + "// Attribute Part\r\n"

                  + _space5 + _attribute + " ttTimestamp"
                  + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                  + _space5 + _attribute + " vtTimestamp"
                  + " { type = TemporalElement.GR" + _class.getGranularity().toUpperCase() + "; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                  + _space5 + "// End Attribute Part of "+ _class.getName() + "\r\n\r\n"

                  + _space5 + "// Relationship Part\r\n"
                  + _space5 + "// End Relationship Part of " + _class.getName() + "\r\n"

                  + _space5 + "storage Default \r\n"
                  + _space5 + "{ \r\n"
                  + _space5 + _space5 + "type = %Library.CacheSerialState; \r\n"
                  + _space5 + _space5 + "state = btTimestamp" + _class.getName() + "State; \r\n"
                  + _space5 + _space5 + "data btTimestamp" + _class.getName() + "State \r\n"
                  + _space5 + _space5 + "{ \r\n"
                  + _space5 + _space5 + _space5 + "structure = list; \r\n"
                  + _space5 + _space5 + _space5 + "// end structure of " + _packageName + ".btTimestamp" + _class.getName() + " \r\n"
                  + _space5 + _space5 + "} \r\n"
                  + _space5 + "} \r\n"
                  + "}; \r\n\r\n");
                break;
       default : break;
      }

      _code.append(_space5 + "// Attribute Part\r\n");
      // Start Generate Code from Attribute
          _setAttr = _class.getAttribute();
          for(int j=0 ; j < _setAttr.size() ; j++){
            _attr = (structureAttribute) _setAttr.elementAt(j);
            switch( _attr.getiTimeStamp() ) {
              case 1 :
                       _code.append(_space5 + "list " + _attribute + " " + _attr.getName()
                          + " { type = " + _packageName + ".element" + _class.getName() + _attr.getName() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");
//                       timetype = "vt_Timestamp";

                       attrCode = _space5 + _attribute + " value"
                          + " { type = %Library." + _attr.getType() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                          + _space5 + _attribute + " vtTimestamp"
                          + " { type = " + _attr.getTimestampType() + ".GR" + _attr.getGranularity().toUpperCase() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";

                       break;
              case 2 :
                       _code.append(_space5 + "list " + _attribute + " " + _attr.getName()
                          + " { type = " + _packageName + ".element" + _class.getName() + _attr.getName() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");

//                       timetype = "tt_Timestamp";

                       attrCode = _space5 + _attribute + " value"
                          + " { type = %Library." + _attr.getType() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                          + _space5 + _attribute + " ttTimestamp"
                          + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";

                        break;
              case 3 :
                       _code.append(_space5 + "list " + _attribute + " " + _attr.getName()
                          + " { type = " + _packageName + ".element" + _class.getName() + _attr.getName() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");

//                       timetype = "bt_Timestamp";

                       attrCode = _space5 + _attribute + " value"
                          + " { type = %Library." + _attr.getType() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                          + _space5 + _attribute + " ttTimestamp"
                          + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                          + _space5 + _attribute + " vtTimestamp"
                          + " { type = " + _attr.getTimestampType() + ".GR" + _attr.getGranularity().toUpperCase() + "; calculated = 0; not final; multidimensional = 0;"
                          + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";


                        break;
              default :
                        if(_attr.getCollect().compareToIgnoreCase("Single") == 0)
                          _code.append(_space5 + _attribute + " " + _attr.getName()
                              + " { type = %Library." + _attr.getType() + "; calculated = 0; not final; multidimensional = 0;"
                              + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");
                        else
            //              _code.append(_space5 + _attribute + " " + _attr.getCollect() + "<" + _attr.getType() + "> " + _attr.getName() + ";\r\n");
                          _code.append(_space5 + "list " + _attribute + " " + _attr.getName()
                              + " { type = %Library." + _attr.getType() + "; calculated = 0; not final; multidimensional = 0;"
                              + " public; not required; sqlcomputed = 0; transient = 0; } \r\n");
                        break;
            }

            if( _attr.getiTimeStamp() > 0){
                       _SPcode.append(_classString + " " + _packageName + ".element" + _class.getName() + _attr.getName() + "  \r\n"
                          + "{ \r\n"
                          + _space5 + "super = %Library.SerialObject; \r\n\r\n"
                          + _space5 + "serial; \r\n\r\n"

                          + _space5 + "// Attribute Part\r\n"

                          + attrCode // VT Code or TT Code or BT Code

                          + _space5 + "// End Attribute Part of " + _class.getName() + "\r\n\r\n"

                          + _space5 + "// Relationship Part\r\n"
                          + _space5 + "// End Relationship Part of " + _class.getName() + "\r\n"

                          + _space5 + "storage Default \r\n"
                          + _space5 + "{ \r\n"
                          + _space5 + _space5 + "type = %Library.CacheSerialState; \r\n"
                          + _space5 + _space5 + "state = btTimestamp" + _class.getName() + "State; \r\n"
                          + _space5 + _space5 + "data btTimestamp" + _class.getName() + "State \r\n"
                          + _space5 + _space5 + "{ \r\n"
                          + _space5 + _space5 + _space5 + "structure = list; \r\n"
                          + _space5 + _space5 + _space5 + "// end structure of " + _packageName + ".btTimestamp" + _class.getName() + " \r\n"
                          + _space5 + _space5 + "} \r\n"
                          + _space5 + "} \r\n"
                          + "}; \r\n\r\n");
            }

          }
      // End Generate Code from Attribute
      _code.append(_space5 + "// End Attribute Part of "+ _class.getName() + "\r\n\r\n"
        + _space5 + "// Relationship Part\r\n"
        + _space5 + "// End Relationship Part of "+ _class.getName() + "\r\n"

	+ _space5 + "storage Default \r\n"
	+ _space5 + "{ \r\n"
	+ _space5 + _space5 + "type = %Library.CacheStorage; \r\n"
	+ _space5 + _space5 + "datalocation = ^" + _packageName + "." + _class.getName() + "D; \r\n"
	+ _space5 + _space5 + "indexlocation = ^" + _packageName + "." + _class.getName() + "I; \r\n"
	+ _space5 + _space5 + "idlocation = ^" + _packageName + "." + _class.getName() + "D; \r\n"
	+ _space5 + _space5 + "defaultdata = " + _class.getName() + "DefaultData; \r\n"
	+ _space5 + _space5 + "data " + _class.getName() + "DefaultData \r\n"
	+ _space5 + _space5 + "{ \r\n"
	+ _space5 + _space5 + _space5 + "structure = listnode; \r\n"
	+ _space5 + _space5 + _space5 + "// end structure of " + _packageName + "." + _class.getName() + " \r\n"
	+ _space5 + _space5 + "} \r\n"
	+ _space5 + "} \r\n"
        + "}; \r\n\r\n");
    }
//  "Short","Long","Unsigned Short","Unsigned Long","Double","Char"
    replaceCode(_code,"%Library.Short","%Library.SmallInt");
    replaceCode(_code,"%Library.Long","%Library.Integer");
    replaceCode(_code,"%Library.Unsigned Short","%Library.SmallInt");
    replaceCode(_code,"%Library.Unsigned Long","%Library.Integer");
    replaceCode(_code,"%Library.Double","%Library.Float");
    replaceCode(_code,"%Library.Char","%Library.String");
  }


  private void genFromInheritance(Vector vInherit){
    FigInheritanceLine _inherit;
    FigClass _parentClass,_inheritClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";

    int index = 0;
    int indexE = 0;

    for(int i = 0 ; i < vInherit.size() ; i++){
      _inherit = (FigInheritanceLine) vInherit.elementAt(i);
      _parentClass = _inherit.getParentClass();
      _inheritClass = _inherit.getInheritClass();

//	       subscript = "InheritC";
      _tempCode = _code.toString();

      searchString = "// end structure of " + _packageName + "." + _inheritClass.getName();
      index = _tempCode.indexOf(searchString);
      _code2insert = "subscript =\"" + _inheritClass.getName() + "\";\r\n" + _space5 + _space5 + _space5;
      _code = _code.insert(index,_code2insert);

      searchString = _classString + " " + _packageName + "." + _inheritClass.getName();

      index = _tempCode.indexOf(searchString); // search index to insert code
      searchString = "%Library.Persistent;";
      index = _tempCode.indexOf(searchString,index); // search index to insert code
      _code2insert = _packageName + "." + _parentClass.getName() + ",";
      _code = _code.insert(index,_code2insert);

      searchString = _space5 + _space5 + "datalocation = ^" + _packageName + "." + _inheritClass.getName() + "D; \r\n";
      replaceCode(_code,searchString,"");
      searchString = _space5 + _space5 + "indexlocation = ^" + _packageName + "." + _inheritClass.getName() + "I; \r\n";
      replaceCode(_code,searchString,"");
      searchString = _space5 + _space5 + "idlocation = ^" + _packageName + "." + _inheritClass.getName() + "D; \r\n";
      replaceCode(_code,searchString,"");

/*      searchString = _space5 + _commentTIME + _inheritClass.getName();

      switch(_parentClass.getiTimeType()){
        case 1 :
                _tempCode = _code.toString();
                index = _tempCode.indexOf(searchString);
                index = index + searchString.length();
                searchString = _space5 + _commentEnd + _inheritClass.getName();
                indexE = _tempCode.indexOf(searchString,index);
                if((index > 0)&&(indexE > 0))
                  _code.delete(index+3,indexE);
                break;
        case 2 :
                _tempCode = _code.toString();
                index = _tempCode.indexOf(searchString);
                index = index + searchString.length();
                if(_inheritClass.getiTimeType() == 3)
                  searchString = _space5 + _commentMiddleEnd;
                else
                  searchString = _space5 + _commentEnd + _inheritClass.getName();
                indexE = _tempCode.indexOf(searchString,index);
                if((index > 0)&&(indexE > 0))
                  _code.delete(index+3,indexE);
                break;
        case 3 :
                _tempCode = _code.toString();
                index = _tempCode.indexOf(searchString);
                index = index + searchString.length();
                searchString = _space5 + _commentEnd + _inheritClass.getName();
                indexE = _tempCode.indexOf(searchString,index);
                if((index > 0)&&(indexE > 0))
                  _code.delete(index+3,indexE);
                break;
        default : break;
      }
*/
    }
    searchString = ",%Library.Persistent";
    replaceCode(_code,searchString,"");
  }

  private boolean genFromAssociation(Vector vAssociation){
    FigAssociationLine _association;
    FigClass _srcClass,_desClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _role = "";
    String _invRole = "";
    String _multiplicity = "";
//    String _timetype = "";
    String _timestamptype = "";
//    String _newClassName = "";
//    String attrCode = "";
    String _granularity = "";
    int _itimetype = 0;


    int index = 0;
    for(int i = 0 ; i < vAssociation.size() ; i++){
      _association = (FigAssociationLine) vAssociation.elementAt(i);
      _srcClass = _association.getSrcClass();
      _desClass = _association.getDesClass();
      _role = _association.getRole();
      _invRole = _association.getInverseRole();
      _multiplicity = _association.getMultiplicity();
      _itimetype = _association.getiTimeType();
//      _timetype = _association.getsTimeType();
      _timestamptype = _association.getTimestampType();
      _granularity = _association.getGranularity().toUpperCase();
//      _newClassName = "relation" + _srcClass.getName() + _role + _desClass.getName() + _invRole;

//      attrCode = "";

      if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("many-to-many")))
        return true;

      genAssociation(_itimetype,_timestamptype,_granularity
                    ,_srcClass.getName(),_desClass.getName()
                    ,_role,_invRole,_multiplicity);

/*      searchString = _space5 + "// End Relationship Part of " + _srcClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      // ----- prepare code to insert ------


      switch(_itimetype){
        case 1  : _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _role + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";

                  attrCode = _space5 + _attribute + " vtTimestamp "
                     + " { type = " + _timestamptype + "." + _granularity + "; calculated = 0; not final; multidimensional = 0;"
                     + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";


                  break;
        case 2  : _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _role + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";

                  attrCode = _space5 + _attribute + " ttTimestamp "
                     + " { type = TemporalElement.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                     + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";

                  break;
        case 3  : _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _role + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";

                  attrCode = _space5 + _attribute + " ttTimestamp "
                    + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                    + _space5 + "list " + _attribute + " vtTimestamp "
                    + " { type = " + _packageName + ".btTimestamp" + _newClassName + "; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";


                  _code.append(_classString + " " + _packageName + ".btTimestamp" + _newClassName + "  \r\n"
                    + "{ \r\n"
                    + _space5 + "super = %Library.SerialObject; \r\n\r\n"
                    + _space5 + "serial; \r\n\r\n"

                    + _space5 + "// Attribute Part\r\n"

                    + _space5 + _attribute + " ttTimestamp"
                    + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                    + _space5 + _attribute + " vtTimestamp"
                    + " { type = " + _timestamptype + "." + _granularity + "; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                    + _space5 + "// End Attribute Part of "+ _newClassName + "\r\n\r\n"

                    + _space5 + "// Relationship Part\r\n"
                    + _space5 + "// End Relationship Part of "+ _newClassName + "\r\n"

                    + _space5 + "storage Default \r\n"
                    + _space5 + "{ \r\n"
                    + _space5 + _space5 + "type = %Library.CacheSerialState; \r\n"
                    + _space5 + _space5 + "state = btTimestamp" + _newClassName + "State; \r\n"
                    + _space5 + _space5 + "data btTimestamp" + _newClassName + "State \r\n"
                    + _space5 + _space5 + "{ \r\n"
                    + _space5 + _space5 + _space5 + "structure = list; \r\n"
                    + _space5 + _space5 + _space5 + "// end structure of " + _packageName + ".btTimestamp" + _newClassName + " \r\n"
                    + _space5 + _space5 + "} \r\n"
                    + _space5 + "} \r\n"
                    + "}; \r\n\r\n");

                  break;
        default :
                  if(_multiplicity.equals("one-to-many"))
                    _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." +  _desClass.getName()
                               +  "; calculated = 0; not final; cardinality = one; inverse = " +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  else
                    _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." +  _desClass.getName()
                               +  "; calculated = 0; not final; cardinality = many; inverse = " +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
      }
      _code = _code.insert(index,_code2insert);

      // ****** End Insert Code for Source Class **************

      searchString = _space5 + "// End Relationship Part of "+ _desClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code

      // ----- prepare code to insert ------
      switch(_itimetype){
        case 1  : _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
        case 2  : _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
        case 3  : _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
        default :
                  if(_multiplicity.equals("many-to-one"))
                      _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." +  _srcClass.getName()
                                 +  "; cardinality = one; inverse = " +  _role + "; transient = 0; }\r\n";
                  else
                      _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." +  _srcClass.getName()
                                 +  "; cardinality = many; inverse = " +  _role + "; transient = 0; }\r\n";
                  break;
      }
      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Destination Class **********

      // ------ Start Insert Code for NewClass ----------------
      if(_itimetype != 0 ){
        _code.append(_classString + " " + _packageName + "." + _newClassName + " \r\n"
           + "{ \r\n"

           + _space5 + "super = %Library.Persistent; \r\n\r\n"
           + _space5 + "persistent; \r\n\r\n"

           + _space5 + "// Attribute Part\r\n"

           + attrCode // VT Code or TT Code or BT Code

           + _space5 + "// End Attribute Part of " + _newClassName + "\r\n\r\n"

           + _space5 + "// Relationship Part\r\n"

           + _space5 + _relationship + " I" + _role + " { type = " + _packageName + "." +  _srcClass.getName()
                     + "; cardinality = many; inverse = " +  _role + "; transient = 0; }\r\n"

           + _space5 + _relationship + " I" + _invRole + " { type = " + _packageName + "." +  _desClass.getName()
                     + "; cardinality = many; inverse = " +  _invRole + "; transient = 0; }\r\n"

           + _space5 + "// End Relationship Part of " + _newClassName + "\r\n"

            + _space5 + "storage Default \r\n"
            + _space5 + "{ \r\n"
            + _space5 + _space5 + "type = %Library.CacheStorage; \r\n"
            + _space5 + _space5 + "datalocation = ^" + _packageName + "." + _newClassName + "D; \r\n"
            + _space5 + _space5 + "indexlocation = ^" + _packageName + "." + _newClassName + "I; \r\n"
            + _space5 + _space5 + "idlocation = ^" + _packageName + "." + _newClassName + "D; \r\n"
            + _space5 + _space5 + "defaultdata = " + _newClassName + "DefaultData; \r\n"
            + _space5 + _space5 + "data " + _newClassName + "DefaultData \r\n"
            + _space5 + _space5 + "{ \r\n"
            + _space5 + _space5 + _space5 + "structure = listnode; \r\n"
            + _space5 + _space5 + _space5 + "// end structure of " + _packageName + "." + _newClassName + " \r\n"
            + _space5 + _space5 + "} \r\n"
            + _space5 + "} \r\n"

           + "}; \r\n\r\n");

//          _SPcode = _SPcode.append(_code2insert);
      }
*/
      // ****** Start Insert Code for NewClass ****************
    }
    return false;
  }

  private void genFromAggregation(Vector vAggregation){
    FigAggregationLine _aggregation;
    FigClass _aggregateClass,_srcClass;
    String _code2insert = "";
    String _tempCode  = "";
    String _searchString = "";
    String _multiplicity = "";

    int index = 0;
    for(int i = 0 ; i < vAggregation.size() ; i++){
      _aggregation = (FigAggregationLine) vAggregation.elementAt(i);
      _srcClass = _aggregation.getSrcClass();
      _aggregateClass = _aggregation.getAggregationClass();
      _multiplicity = _aggregation.getMultiplicity();

      _searchString = _space5 + "// End Attribute Part of " + _srcClass.getName();
       _tempCode = _code.toString();
      index = _tempCode.indexOf(_searchString); // search index to insert code

      // ----- prepare code to insert ------
/*
      if(_multiplicity.equals("one"))
        _code2insert = _space5 + _attribute + " " + _aggregation.getRole()
            + " { type = " + _packageName + "." + _aggregateClass.getName() + "; calculated = 0; not final; multidimensional = 0;"
            + " public; not required; sqlcomputed = 0; sqlfieldname = _" + _aggregateClass.getName() + "; transient = 0; } \r\n";
      else
        _code2insert = _space5 + "list " + _attribute + " " + _aggregation.getRole()
            + " { type = " + _packageName + "." + _aggregateClass.getName() + "; calculated = 0; not final; multidimensional = 0;"
            + " public; not required; sqlcomputed = 0; sqlfieldname = _" + _aggregateClass.getName() + "; transient = 0; } \r\n";
*/
      if(_multiplicity.equals("one"))
        _code2insert = _space5 + _attribute + " " + _aggregation.getRole()
            + " { type = " + _packageName + "." + _aggregateClass.getName() + "; calculated = 0; not final; multidimensional = 0;"
            + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";
      else
        _code2insert = _space5 + "list " + _attribute + " " + _aggregation.getRole()
            + " { type = " + _packageName + "." + _aggregateClass.getName() + "; calculated = 0; not final; multidimensional = 0;"
            + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Source Class **************

    }
  }

  private void genStorageDefault(){
    String _tempCode = _code.toString();
    String _code2insert = "";
    String _stringRole = "";
    int count = 0;

    int lenghtR = _relationship.length();
    int indexR = _tempCode.indexOf(_relationship);
    int indexER = 0;

    int lenghtA = _attribute.length();
    int indexA = _tempCode.indexOf(_attribute);
    int indexEA = 0;
    int indexEnd = 0;
    if((indexA < indexR)&&(indexA > 0))
      indexEnd = _tempCode.indexOf("// end structure of",indexA);
    else
      indexEnd = _tempCode.indexOf("// end structure of",indexR);

    while(((indexR < indexEnd)&&(indexR > 0))||
         ((indexA < indexEnd)&&(indexA > 0))){
      count = 1;
      _code2insert = "";
      while((indexA < indexEnd)&&(indexA > 0))
      {
        indexEA = _tempCode.indexOf(" ",indexA + lenghtA + 1);
        _stringRole = _tempCode.substring(indexA + lenghtA + 1,indexEA);
        _code2insert = _code2insert + "value (" + count + ") = " + _stringRole + "; \r\n" + _space5 + _space5 + _space5;
        count++;
        indexA = _tempCode.indexOf(_attribute,indexEA);
      }

      while((indexR < indexEnd)&&(indexR > 0))
      {
        indexER = _tempCode.indexOf(" ",indexR + lenghtR + 1);
        _stringRole = _tempCode.substring(indexR + lenghtR + 1,indexER);
        _code2insert = _code2insert + "value (" + count + ") = " + _stringRole + "; \r\n" + _space5 + _space5 + _space5;
        count++;
        indexR = _tempCode.indexOf(_relationship,indexER);
      }

      _code.insert(indexEnd,_code2insert);
      _tempCode = _code.toString();

      indexA = _tempCode.indexOf(_attribute,indexEnd);

      indexR = _tempCode.indexOf(_relationship,indexEnd);

      if((indexA < indexR)&&(indexA > 0)||(indexR < 0))
        indexEnd = _tempCode.indexOf("// end structure of",indexA);
      else
        indexEnd = _tempCode.indexOf("// end structure of",indexR);
    }
  }

  private void genFromNary(Vector vTernary){
    FigNary _fNary;
    FigClass _fClass,_sClass,_tClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _role = "";
    String _invRole = "";
//    String _multiplicity = "";

    String _newClassName = "";
    int index = 0;

    for(int i = 0 ; i < vTernary.size() ; i++){
      _fNary = (FigNary) vTernary.elementAt(i);

      _fClass = _fNary.getFClass();
      _sClass = _fNary.getSClass();
      _tClass = _fNary.getTClass();
      _role   = _fNary.getRoleName();
      _invRole = "NaryINV" + _role;
//      _newClassName = _fClass.getName() + _sClass.getName() + _tClass.getName() + _role;
      _newClassName = "NaryClass" + _role;

      switch(_fNary.getIndexTimeType() ){
       case 1 :
                _code2insert = _space5 + _commentTIME + _newClassName + " \r\n"
                  + _space5 + _attribute + " vtTimestamp "
                  + " { type = TemporalElement.GR" + _fNary.getGranularity().toUpperCase() + "; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"
                  + _space5 + _commentEnd + _newClassName + " \r\n";
                break;
       case 2 :
                _code2insert = _space5 + _commentTIME + _newClassName + " \r\n"
                  + _space5 + _attribute + " ttTimestamp "
                  + " { type = TemporalElement.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"
                  + _space5 + _commentEnd + _newClassName + " \r\n";
                break;
       case 3 :
                _code2insert = _space5 + _commentTIME + _newClassName + " \r\n"
                  + _space5 + _attribute + " ttTimestamp "
                  + " { type = TemporalElement.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                  + _space5 + _commentMiddleEnd

                  + _space5 + "list " + _attribute + " vtTimestamp "
                  + " { type = " + _packageName + ".btTimestamp" + _newClassName + "; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"
                  + _space5 + _commentEnd + _newClassName + " \r\n";

                _code.append(_classString + " " + _packageName + ".btTimestamp" + _newClassName + "  \r\n"
                  + "{ \r\n"
                  + _space5 + "super = %Library.SerialObject; \r\n\r\n"
                  + _space5 + "serial; \r\n\r\n"

                  + _space5 + "// Attribute Part\r\n"

                  + _space5 + _attribute + " ttTimestamp"
                  + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                  + _space5 + _attribute + " vtTimestamp"
                  + " { type = TemporalElement.GR" + _fNary.getGranularity().toUpperCase() + "; calculated = 0; not final; multidimensional = 0;"
                  + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                  + _space5 + "// End Attribute Part of "+ _newClassName + "\r\n\r\n"

                  + _space5 + "// Relationship Part\r\n"
                  + _space5 + "// End Relationship Part of " + _newClassName + "\r\n"

                  + _space5 + "storage Default \r\n"
                  + _space5 + "{ \r\n"
                  + _space5 + _space5 + "type = %Library.CacheSerialState; \r\n"
                  + _space5 + _space5 + "state = btTimestamp" + _newClassName + "State; \r\n"
                  + _space5 + _space5 + "data btTimestamp" + _newClassName + "State \r\n"
                  + _space5 + _space5 + "{ \r\n"
                  + _space5 + _space5 + _space5 + "structure = list; \r\n"
                  + _space5 + _space5 + _space5 + "// end structure of " + _packageName + ".btTimestamp" + _newClassName + " \r\n"
                  + _space5 + _space5 + "} \r\n"
                  + _space5 + "} \r\n"
                  + "}; \r\n\r\n");
                break;
       default : _code2insert = "";
                break;
      }


      // Create New Class
      _code = _code.append(_classString + " " + _packageName + "." + _newClassName + " \r\n"
        + "{ \r\n"
        + _space5 + "super = %Library.Persistent; \r\n\r\n"
        + _space5 + "persistent; \r\n\r\n"
        + _code2insert
        + _space5 + "// Attribute Part\r\n"
        + _space5 + "// End Attribute Part of "+ _newClassName + "\r\n\r\n"

        + _space5 + "// Relationship Part\r\n"
        + _space5 + "// End Relationship Part of "+ _newClassName + "\r\n"
	+ _space5 + "storage Default \r\n"
	+ _space5 + "{ \r\n"
	+ _space5 + _space5 + "type = %Library.CacheStorage; \r\n"
	+ _space5 + _space5 + "datalocation = ^" + _packageName + "." + _newClassName + "D; \r\n"
	+ _space5 + _space5 + "indexlocation = ^" + _packageName + "." + _newClassName + "I; \r\n"
	+ _space5 + _space5 + "idlocation = ^" + _packageName + "." + _newClassName + "D; \r\n"
	+ _space5 + _space5 + "defaultdata = " + _newClassName + "DefaultData; \r\n"
	+ _space5 + _space5 + "data " + _newClassName + "DefaultData \r\n"
	+ _space5 + _space5 + "{ \r\n"
	+ _space5 + _space5 + _space5 + "structure = listnode; \r\n"
	+ _space5 + _space5 + _space5 + "// end structure of " + _packageName + "." + _newClassName + " \r\n"
	+ _space5 + _space5 + "} \r\n"
	+ _space5 + "} \r\n"
        + "}; \r\n\r\n");

        genAssociation(_fNary.getIndexTimeType(),_fNary.getTimestampType()
                    ,_fNary.getGranularity().toUpperCase(),_fClass.getName(),_newClassName
                    ,_role,_invRole + "1","one-to-many");

        genAssociation(_fNary.getIndexTimeType(),_fNary.getTimestampType()
                    ,_fNary.getGranularity().toUpperCase(),_sClass.getName(),_newClassName
                    ,_role,_invRole + "2","one-to-many");

        genAssociation(_fNary.getIndexTimeType(),_fNary.getTimestampType()
                    ,_fNary.getGranularity().toUpperCase(),_tClass.getName(),_newClassName
                    ,_role,_invRole + "3","one-to-many");

    }
  }

  private void genAssociation(int _iTimeType,String _timestamptype,String _granularity,String _srcClass,String _desClass,String _role,String _invRole,String _multiplicity){
    FigAssociationLine _association;
//    FigClass _srcClass,_desClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _newClassName = "";
    String attrCode = "";


    int index = 0;

      _newClassName = "relation" + _srcClass + _role + _desClass + _invRole;


      searchString = _space5 + "// End Relationship Part of " + _srcClass;
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      // ----- prepare code to insert ------

      switch(_iTimeType){
        case 1  : _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _role + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";

                  attrCode = _space5 + _attribute + " vtTimestamp "
                     + " { type = " + _timestamptype + ".GR" + _granularity + "; calculated = 0; not final; multidimensional = 0;"
                     + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";


                  break;
        case 2  : _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _role + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";

                  attrCode = _space5 + _attribute + " ttTimestamp "
                     + " { type = TemporalElement.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                     + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";

                  break;
        case 3  : _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _role + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";

                  attrCode = _space5 + _attribute + " ttTimestamp "
                    + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                    + _space5 + "list " + _attribute + " vtTimestamp "
                    + " { type = " + _packageName + ".btTimestamp" + _newClassName + "; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n";


                  _code.append(_classString + " " + _packageName + ".btTimestamp" + _newClassName + "  \r\n"
                    + "{ \r\n"
                    + _space5 + "super = %Library.SerialObject; \r\n\r\n"
                    + _space5 + "serial; \r\n\r\n"

                    + _space5 + "// Attribute Part\r\n"

                    + _space5 + _attribute + " ttTimestamp"
                    + " { type = Period.GRSECOND; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                    + _space5 + _attribute + " vtTimestamp"
                    + " { type = " + _timestamptype + ".GR" + _granularity + "; calculated = 0; not final; multidimensional = 0;"
                    + " public; not required; sqlcomputed = 0; transient = 0; } \r\n"

                    + _space5 + "// End Attribute Part of "+ _newClassName + "\r\n\r\n"

                    + _space5 + "// Relationship Part\r\n"
                    + _space5 + "// End Relationship Part of "+ _newClassName + "\r\n"

                    + _space5 + "storage Default \r\n"
                    + _space5 + "{ \r\n"
                    + _space5 + _space5 + "type = %Library.CacheSerialState; \r\n"
                    + _space5 + _space5 + "state = btTimestamp" + _newClassName + "State; \r\n"
                    + _space5 + _space5 + "data btTimestamp" + _newClassName + "State \r\n"
                    + _space5 + _space5 + "{ \r\n"
                    + _space5 + _space5 + _space5 + "structure = list; \r\n"
                    + _space5 + _space5 + _space5 + "// end structure of " + _packageName + ".btTimestamp" + _newClassName + " \r\n"
                    + _space5 + _space5 + "} \r\n"
                    + _space5 + "} \r\n"
                    + "}; \r\n\r\n");

                  break;
        default :
                  if(_multiplicity.equals("one-to-many"))
                    _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." +  _desClass
                               +  "; calculated = 0; not final; cardinality = one; inverse = " +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  else
                    _code2insert = _space5 + _relationship + " " + _role + " { type = " + _packageName + "." +  _desClass
                               +  "; calculated = 0; not final; cardinality = many; inverse = " +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
      }
      _code = _code.insert(index,_code2insert);

      // ****** End Insert Code for Source Class **************

      searchString = _space5 + "// End Relationship Part of "+ _desClass;
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code

      // ----- prepare code to insert ------
      switch(_iTimeType){
        case 1  : _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
        case 2  : _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
        case 3  : _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." + _newClassName
                     +  "; calculated = 0; not final; cardinality = one; inverse = I" +  _invRole + "; multidimensional = 0; public; not required; sqlcomputed = 0; transient = 0; }\r\n";
                  break;
        default :
                  if(_multiplicity.equals("many-to-one"))
                      _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." +  _srcClass
                                 +  "; cardinality = one; inverse = " +  _role + "; transient = 0; }\r\n";
                  else
                      _code2insert = _space5 + _relationship + " " + _invRole + " { type = " + _packageName + "." +  _srcClass
                                 +  "; cardinality = many; inverse = " +  _role + "; transient = 0; }\r\n";
                  break;
      }
      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Destination Class **********

      // ------ Start Insert Code for NewClass ----------------
      if(_iTimeType != 0 ){
        _code.append(_classString + " " + _packageName + "." + _newClassName + " \r\n"
           + "{ \r\n"

           + _space5 + "super = %Library.Persistent; \r\n\r\n"
           + _space5 + "persistent; \r\n\r\n"

           + _space5 + "// Attribute Part\r\n"

           + attrCode // VT Code or TT Code or BT Code

           + _space5 + "// End Attribute Part of " + _newClassName + "\r\n\r\n"

           + _space5 + "// Relationship Part\r\n"

           + _space5 + _relationship + " I" + _role + " { type = " + _packageName + "." +  _srcClass
                     + "; cardinality = many; inverse = " +  _role + "; transient = 0; }\r\n"

           + _space5 + _relationship + " I" + _invRole + " { type = " + _packageName + "." +  _desClass
                     + "; cardinality = many; inverse = " +  _invRole + "; transient = 0; }\r\n"

           + _space5 + "// End Relationship Part of " + _newClassName + "\r\n"

            + _space5 + "storage Default \r\n"
            + _space5 + "{ \r\n"
            + _space5 + _space5 + "type = %Library.CacheStorage; \r\n"
            + _space5 + _space5 + "datalocation = ^" + _packageName + "." + _newClassName + "D; \r\n"
            + _space5 + _space5 + "indexlocation = ^" + _packageName + "." + _newClassName + "I; \r\n"
            + _space5 + _space5 + "idlocation = ^" + _packageName + "." + _newClassName + "D; \r\n"
            + _space5 + _space5 + "defaultdata = " + _newClassName + "DefaultData; \r\n"
            + _space5 + _space5 + "data " + _newClassName + "DefaultData \r\n"
            + _space5 + _space5 + "{ \r\n"
            + _space5 + _space5 + _space5 + "structure = listnode; \r\n"
            + _space5 + _space5 + _space5 + "// end structure of " + _packageName + "." + _newClassName + " \r\n"
            + _space5 + _space5 + "} \r\n"
            + _space5 + "} \r\n"

           + "}; \r\n\r\n");


      }
      // ****** Start Insert Code for NewClass ****************


  }

}