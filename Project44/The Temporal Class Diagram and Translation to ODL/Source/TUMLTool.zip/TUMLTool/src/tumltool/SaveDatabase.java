package tumltool;
import java.util.*;
import COM.intersys.objects.*;
import COM.intersys.util.*;
import COM.intersys.util.CacheException;
import COM.intersys.util.SysList;
import Model.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SaveDatabase {
  ObjectFactory mFactory = null;
  PropertiesProject diagram = null;
  private Vector vClass;
  private Vector vInheritance;
  private Vector vAssociation;
  private Vector vAggregation;
  private Vector vTernary;
/*
   mFactory = new ObjectFactory("cn_iptcp:127.0.0.1[1972]:TCD");
   ListOfObjects  mList = new ListOfObjects(mFactory);
//   TCD.Classes oClasses = new TCD.Classes(mFactory);
//   mList._insert(new TCD.Classes(mFactory,1));
//   mList._saveData();

/*  oClasses.setName("Person");
  oClasses.setParent("");
  oClasses.setType("Static");
  oClasses.setXpositon(100);
  oClasses.setYposition(200);
  oClasses.setDescription("test test tes");
  oClasses.setCountAttr(0);
  oClasses._save();
  oClasses._close();
  oClasses = null; */
/*
   TCD.Diagram cDiagram = new TCD.Diagram(mFactory,4);
   mList = cDiagram.getClasses();
   mList._removeAt(1);
   TCD.Classes oClasses = new TCD.Classes(mFactory,mList._getObjectAt(2));
   System.out.println(oClasses.getName() + oClasses.getType());
   System.out.println(mList._count());
   mList._removeAt(1);
   TCD.Classes oClasses2 = new TCD.Classes(mFactory,1);
/*  oClasses2.setName("Manager");
  oClasses2.setParent("Employee");
  oClasses2.setType("Transaction Time");
  oClasses2.setXpositon(200);
  oClasses2.setYposition(300);
  oClasses2.setDescription("test");
  oClasses2._save();*/
//  mList._insert(oClasses2);
//  oClasses2._close();
//  mList._insert(new TCD.Classes(mFactory,2));
//  mList._saveData();
//  System.out.println(mList._count());
//  cDiagram.setClasses(mList);

//   mList._close();
//   mList = null;
//   cDiagram._delete(new Oid("4"));
//   cDiagram.setName("Project5");
//   cDiagram.setDescription("This is a test5");
//   cDiagram.setCountClass(0);
/*   cDiagram._save();
   cDiagram._close();
   cDiagram = null;
   mFactory.close();
   mFactory = null;

//   Person.Per mPer = new Person.Per(mFactory,"2");
//   Date DOB = null;
//   mPer.CreatePer("SN1234","Yutth","Sui","Yutthana","Suiwongsa",DOB,"Male");
//   Person.TFirstName mTFN = new Person.TFirstName(mFactory);
//   mTFN.setTFirstName("Akachan");
//   ListOfObjects  mLoo = new ListOfObjects(mFactory);
//   mLoo._insert(mTFN);
//   mPer.setTFirstName(mLoo);
//   mPer._save();
//   mPer._close();
//   mPer = null;
//   mLoo._close();
//   mLoo = null;
//   mTFN._close();
//  mTFN = null;*/

  public SaveDatabase(ObjectFactory factory) {
    mFactory = factory;
  }

  public void setDiagram(PropertiesProject aDiagram) {
    diagram = aDiagram;
  }

  public void setClass(Vector aClass) {
    vClass = aClass;
  }

  public void setInheritance(Vector aInheritance) {
    vInheritance = aInheritance;
  }

  public void setAssociation(Vector aAssociation) {
    vAssociation = aAssociation;
  }

  public void setAggregation(Vector aAggregation) {
    vAggregation = aAggregation;
  }

  public void setTernary(Vector aTernary) {
    vTernary = aTernary;
  }

  private Oid saveAttribute(structureAttribute sAttr) {
    Oid oidAttr = null;
    try {
      Attribute mAttribute = new Attribute(mFactory);
      mAttribute.setName(sAttr.getName());
      mAttribute.setDescriptions(sAttr.getDescriptions());
      mAttribute.setIndexTimeType(sAttr.getiTimeStamp());
      mAttribute.setGranularity(sAttr.getiGranularity());
      mAttribute.setType(sAttr.getType());
      mAttribute.setCollection(sAttr.getCollect());
      mAttribute.setTimestampType(sAttr.getTimestampType());
      mAttribute._save();
      oidAttr = mAttribute._getOid();
      mAttribute._close();
      mAttribute = null;
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return oidAttr;
  }

  private Oid saveClass(FigClass fClass) {
    Oid oidClass = null;
    try {
      Classes mClasses = new Classes(mFactory);
      ListOfObjects mList = new ListOfObjects(mFactory);
      mClasses.setId(fClass.getId());
      mClasses.setName(fClass.getName());
      mClasses.setIndexTimeType(fClass.getiTimeType());
      mClasses.setGranularity(fClass.getIGranularity());
      mClasses.setDescriptions(fClass.getDescriptions());
      mClasses.setPointX(fClass.PointX());
      mClasses.setPointY(fClass.PointY());
      mClasses.setWidth(fClass.Width());
      mClasses.setHigh(fClass.high());
      mClasses.setAssociationBT(fClass.getAssociationBT());
      mClasses.setAssociationVT(fClass.getAssociationVT());
      mClasses.setAssociationTT(fClass.getAssociationTT());
      for (int i = 0 ; i < fClass.getAttribute().size(); i++){
        structureAttribute lAttr = (structureAttribute) fClass.getAttribute().elementAt(i);
        mList._insertObject(saveAttribute(lAttr));
      }
      mClasses.setlistAttribute(mList);
      mClasses._save();
      oidClass = mClasses._getOid();
      mClasses._close();
      mClasses = null;
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    fClass.setOid(oidClass);
    return oidClass;
  }

  private Oid saveInheritance(FigInheritanceLine aInherit) {
    Oid id = null;
    try {
      InheritanceLine mInherit = new InheritanceLine(mFactory);
      FigClass test = aInherit.getParentClass();
      mInherit.setSuperClass(new Classes(mFactory,aInherit.getParentClass().getOid()));
      mInherit.setSubClass(new Classes(mFactory,aInherit.getInheritClass().getOid()));
      mInherit._save();
      id = mInherit._getOid();
      mInherit._close();
      mInherit = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return id;
  }

  private Oid saveAssociation(FigAssociationLine aLine) {
  Oid id = null;
    try {
      AssociationLine mLine = new AssociationLine(mFactory);
      mLine.setSrcClass(new Classes(mFactory,aLine.getSrcClass().getOid()));
      mLine.setDesClass(new Classes(mFactory,aLine.getDesClass().getOid()));
      mLine.setName(aLine.getRole());
      mLine.setInvName(aLine.getInverseRole());
      mLine.setMultiplicity(aLine.getMultiplicity());
      mLine.setIndexTimeType(aLine.getiTimeType());
      mLine.setTimestampType(aLine.getTimestampType());
      mLine.setGranularity(aLine.getGranularity());
      mLine._save();
      id = mLine._getOid();
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return id;
  }

  private Oid saveAggregation(FigAggregationLine aAggregate) {
    Oid id = null;
    try {
      AggregationLine mAggregate = new AggregationLine(mFactory);
      mAggregate.setSrcClass(new Classes(mFactory,aAggregate.getSrcClass().getOid()));
      mAggregate.setAggregationClass(new Classes(mFactory,aAggregate.getAggregationClass().getOid()));
      mAggregate.setMultiplicity(aAggregate.getMultiplicity());
      mAggregate.setRoleName(aAggregate.getRole());
      mAggregate._save();
      id = mAggregate._getOid();
      mAggregate._close();
      mAggregate = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return id;
  }

  private Oid saveTernary(FigNary aTernary) {
    Oid id = null;
    try {
      TernaryLine mTernary = new TernaryLine(mFactory);
      mTernary.setRoleName(aTernary.getRoleName());
      mTernary.setIndexTimeType(aTernary.getIndexTimeType());
      mTernary.setGranularity(aTernary.getGranularity());
      mTernary.setTimestampType(aTernary.getTimestampType());
      mTernary.setFirstClass( new Classes(mFactory,aTernary.getFClass().getOid()));
      mTernary.setSecondClass(new Classes(mFactory,aTernary.getSClass().getOid()));
      mTernary.setThirdClass( new Classes(mFactory,aTernary.getTClass().getOid()));
      mTernary.setCoordinateX(aTernary.getX());
      mTernary.setCoordinateY(aTernary.getY());
      mTernary._save();
      id = mTernary._getOid();
      mTernary._close();
      mTernary = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return id;
  }

/*  private void saveAggregation() {
    try {
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
*/

  private void saveDiagram() {
    try {
      Diagrams mDiagram = new Diagrams(mFactory);
      ListOfObjects mListClass = new ListOfObjects(mFactory);
      ListOfObjects mListInherit = new ListOfObjects(mFactory);
      ListOfObjects mListAssocia = new ListOfObjects(mFactory);
      ListOfObjects mListAggregate = new ListOfObjects(mFactory);
      ListOfObjects mListTernary = new ListOfObjects(mFactory);

      mDiagram.setName(diagram.getName());
      mDiagram.setDesigner(diagram.getDesigner());
      mDiagram.setPackage(diagram.getPackage());
      mDiagram.setDescriptions(diagram.getDescription());
      for (int i = 0 ; i < vClass.size() ; i++){
        FigClass lClass = (FigClass) vClass.elementAt(i);
        mListClass._insertObject(saveClass(lClass));
      }
      for (int i = 0 ; i < vInheritance.size() ; i++){
        FigInheritanceLine lInherit = (FigInheritanceLine) vInheritance.elementAt(i);
        mListInherit._insertObject(saveInheritance(lInherit));
      }
      for (int i = 0 ; i < vAssociation.size() ; i++){
        FigAssociationLine lAssocia = (FigAssociationLine) vAssociation.elementAt(i);
        mListAssocia._insertObject(saveAssociation(lAssocia));
      }
      for (int i = 0 ; i < vAggregation.size() ; i++){
        FigAggregationLine lAggregate = (FigAggregationLine) vAggregation.elementAt(i);
        mListAggregate._insertObject(saveAggregation(lAggregate));
      }
      for (int i = 0 ; i < vTernary.size() ; i++){
        FigNary lNary = (FigNary) vTernary.elementAt(i);
        mListTernary._insertObject(saveTernary(lNary));
      }
      mDiagram.setlistClasses(mListClass);
      mDiagram.setlistRelationInheritance(mListInherit);
      mDiagram.setlistRelationAssociation(mListAssocia);
      mDiagram.setlistRelationAggregation(mListAggregate);
      mDiagram.setlistRelationTernary(mListTernary);
      mDiagram._save();
      diagram.setOid(mDiagram._getOid());
      mDiagram._close();
      mDiagram = null;
      mListInherit._close();
      mListInherit = null;
      mListAssocia._close();
      mListAssocia = null;
      mListAggregate._close();
      mListAggregate = null;
      mListTernary._close();
      mListTernary = null;
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private void deleteAttribute(ListOfObjects mListAttr) {
    try {
      Attribute mAttr = new Attribute(mFactory);
      for (int i = 1; i <= mListAttr._count();i++) {
        mAttr._delete(mListAttr._getObjectAt(i));
      }
      mListAttr._clear();
      mAttr._close();
      mAttr = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void deleteClass(ListOfObjects mListClass) {
    try {
      ListOfObjects mListAttr = null;
      Classes mClass = null;
      for (int i = 1; i <= mListClass._count();i++) {
        mClass = new Classes(mFactory,mListClass._getObjectAt(i));
        mListAttr = mClass.getlistAttribute();
        deleteAttribute(mListAttr);
      }
      mClass = new Classes(mFactory);
      for (int i = 1; i <= mListClass._count();i++) {
        mClass._delete(mListClass._getObjectAt(i));
      }
      mListClass._clear();
      mClass._close();
      mClass = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void deleteInheritance(ListOfObjects mListInherit) {
    try {
      InheritanceLine mLine = new InheritanceLine(mFactory);
      for (int i = 1 ; i <= mListInherit._count();i++){
        mLine._delete(mListInherit._getObjectAt(i));
      }
      mListInherit._clear();
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void deleteAssociation(ListOfObjects mListAssocia) {
    try {
      AssociationLine mLine = new AssociationLine(mFactory);
      for (int i = 1 ; i <= mListAssocia._count();i++){
        mLine._delete(mListAssocia._getObjectAt(i));
      }
      mListAssocia._clear();
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void deleteAggregation(ListOfObjects mListAggrega) {
    try {
      AggregationLine mLine = new AggregationLine(mFactory);
      for (int i = 1 ; i <= mListAggrega._count();i++){
        mLine._delete(mListAggrega._getObjectAt(i));
      }
      mListAggrega._clear();
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void deleteTernary(ListOfObjects mListTernary) {
    try {
      TernaryLine mLine = new TernaryLine(mFactory);
      for (int i = 1 ; i <= mListTernary._count();i++){
        mLine._delete(mListTernary._getObjectAt(i));
      }
      mListTernary._clear();
      mLine._close();
      mLine = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void updateDiagram() {
    try {
      Diagrams mDiagram = new Diagrams(mFactory,diagram.getOid());
      ListOfObjects mListClass = mDiagram.getlistClasses();
      ListOfObjects mListInherit = mDiagram.getlistRelationInheritance();
      ListOfObjects mListAssocia = mDiagram.getlistRelationAssociation();
      ListOfObjects mListAggrega = mDiagram.getlistRelationAggregation();
      ListOfObjects mListTernary = mDiagram.getlistRelationTernary();

      mDiagram.setName(diagram.getName());
      mDiagram.setDesigner(diagram.getDesigner());
      mDiagram.setPackage(diagram.getPackage());
      mDiagram.setDescriptions(diagram.getDescription());

      deleteClass(mListClass);
      for (int i = 0 ; i < vClass.size();i++){
        FigClass lClass = (FigClass) vClass.elementAt(i);
        mListClass._insertObject(saveClass(lClass));
      }

      deleteInheritance(mListInherit);
      for (int i = 0 ; i < vInheritance.size();i++){
        FigInheritanceLine lInherit = (FigInheritanceLine) vInheritance.elementAt(i);
        mListInherit._insertObject(saveInheritance(lInherit));
      }

      deleteAssociation(mListAssocia);
      for (int i = 0 ; i < vAssociation.size();i++){
        FigAssociationLine lAssocia = (FigAssociationLine) vAssociation.elementAt(i);
        mListAssocia._insertObject(saveAssociation(lAssocia));
      }

      deleteAggregation(mListAggrega);
      for (int i = 0 ; i < vAggregation.size();i++){
        FigAggregationLine lAggregate = (FigAggregationLine) vAggregation.elementAt(i);
        mListAggrega._insertObject(saveAggregation(lAggregate));
      }

      deleteTernary(mListTernary);
      for (int i = 0 ; i < vTernary.size();i++){
        FigNary lTernary = (FigNary) vTernary.elementAt(i);
        mListTernary._insertObject(saveTernary(lTernary));
      }

      mDiagram.setlistClasses(mListClass);
      mDiagram.setlistRelationInheritance(mListInherit);
      mDiagram.setlistRelationAssociation(mListAssocia);
      mDiagram.setlistRelationAggregation(mListAggrega);
      mDiagram.setlistRelationTernary(mListTernary);
      mDiagram._save();
      mDiagram = null;
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void Save() {
    try {
      saveDiagram();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void Update() {
    try {
      updateDiagram();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}