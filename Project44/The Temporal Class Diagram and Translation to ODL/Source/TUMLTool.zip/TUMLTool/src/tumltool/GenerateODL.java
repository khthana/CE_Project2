package tumltool;

import java.util.*;
import java.awt.*;
//import javax.swing.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class GenerateODL extends GenerateCode {

  public GenerateODL() {

  }

  public GenerateODL(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
  }


  public void genCode(String path,Vector vClass,Vector vInheritance,Vector vAssociation,Vector vAggregation,Vector vTernary){
//    _code.delete(0,_code.capacity());
    resetCode();

    genFromClass(vClass);
    genFromInheritance(vInheritance);
    genFromAssociation(vAssociation);
    genFromAggregation(vAggregation);
    genFromNary(vTernary);
    exportToPath(path,"ODL");
  }

  private void genFromClass(Vector vClass){
    FigClass _class;
    Vector _setAttr;
    structureAttribute _attr;
    for(int i = 0 ; i < vClass.size() ; i++){
      _class = (FigClass) vClass.elementAt(i);
      _code.append(_interface + " " + _class.getName() + "  :\r\n"
        + "( extent "+ _class.getName() + "s )\r\n"
        + "{ \r\n" + _space5 + "// Attribute Part\r\n");
      // Start Generate Code from Attribute
          _setAttr = _class.getAttribute();
          for(int j=0 ; j < _setAttr.size() ; j++){
            _attr = (structureAttribute) _setAttr.elementAt(j);
            if(_attr.getCollect().compareToIgnoreCase("Single") == 0)
              _code.append(_space5 + _attribute + " " + _attr.getType() + " " + _attr.getName() + ";\r\n");
            else
              _code.append(_space5 + _attribute + " " + _attr.getCollect() + "<" + _attr.getType() + "> " + _attr.getName() + ";\r\n");
          }
      // End Generate Code from Attribute
      _code.append(_space5 + "// End Attribute Part of "+ _class.getName() + "\r\n\r\n"
        + _space5 + "// Relationship Part\r\n"
        + _space5 + "// End Relationship Part of "+ _class.getName() + "\r\n"
        + "}; \r\n\r\n");
    }
  }


  private void genFromInheritance(Vector vInherit){
    FigInheritanceLine _inherit;
    FigClass _parentClass,_inheritClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";

    int index = 0;
    for(int i = 0 ; i < vInherit.size() ; i++){
      _inherit = (FigInheritanceLine) vInherit.elementAt(i);
      _parentClass = _inherit.getParentClass();
      _inheritClass = _inherit.getInheritClass();

      searchString = _interface + " " +_inheritClass.getName() + "  :";
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      index = index + searchString.length();
      _code2insert = "  " + _parentClass.getName() +  " ,"; // prepare code to insert

      _code = _code.insert(index,_code2insert);

    }
    replaceCode(_code,":\r\n","\r\n");
    replaceCode(_code,",\r\n","\r\n");
  }

  private void genFromAssociation(Vector vAssociation){
    FigAssociationLine _association;
    FigClass _srcClass,_desClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _role = "";
    String _invRole = "";
    String _multiplicity = "";

    int index = 0;
    for(int i = 0 ; i < vAssociation.size() ; i++){
      _association = (FigAssociationLine) vAssociation.elementAt(i);
      _srcClass = _association.getSrcClass();
      _desClass = _association.getDesClass();
      _role = _association.getRole();
      _invRole = _association.getInverseRole();
      _multiplicity = _association.getMultiplicity();

      searchString = _space5 + "// End Relationship Part of "+ _srcClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      // ----- prepare code to insert ------
      if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("many-to-one")))
          _code2insert = _space5 + _relationship + " " + _desClass.getName()+ " " + _role
                       + "\r\n" + _space5 + _space5 + _inverse + " " + _desClass.getName() + "::" + _invRole + ";\r\n";
      else
          _code2insert = _space5 + _relationship + " Set<" + _desClass.getName()+ "> " + _role
                       + "\r\n" + _space5 + _space5 + _inverse + " " + _desClass.getName() + "::" + _invRole + ";\r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Source Class **************

      searchString = _space5 + "// End Relationship Part of "+ _desClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      // ----- prepare code to insert ------
      if((_multiplicity.equals("one-to-one"))||(_multiplicity.equals("one-to-many")))
          _code2insert = _space5 + _relationship + " " + _srcClass.getName() + " " + _invRole
                     + "\r\n" + _space5 + _space5 + _inverse + " " + _srcClass.getName() + "::"  + _role + ";\r\n";
      else
          _code2insert = _space5 + _relationship + " Set<" + _srcClass.getName()+ "> " + _invRole
                     + "\r\n" + _space5 + _space5 + _inverse + " " + _srcClass.getName() + "::"  + _role + ";\r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Destination Class **********
    }
  }

  private void genFromAggregation(Vector vAggregation){
    FigAggregationLine _aggregation;
    FigClass _aggregateClass,_srcClass;
    String _code2insert = "";
    String _tempCode  = "";
    String _searchString = "";
    String _multiplicity = "";

    int index = 0;
    for(int i = 0 ; i < vAggregation.size() ; i++){
      _aggregation = (FigAggregationLine) vAggregation.elementAt(i);
      _srcClass = _aggregation.getSrcClass();
      _aggregateClass = _aggregation.getAggregationClass();
      _multiplicity = _aggregation.getMultiplicity();

      _searchString = _space5 + "// End Attribute Part of " + _srcClass.getName();
       _tempCode = _code.toString();
      index = _tempCode.indexOf(_searchString); // search index to insert code

      // ----- prepare code to insert ------
      if(_multiplicity.equals("one"))
          _code2insert = _space5 + _attribute + " " + _aggregateClass.getName() +
                         " " + _aggregation.getRole() + ";\r\n";
      else
          _code2insert = _space5 + _attribute + " Set<" + _aggregateClass.getName() +
                         "> " + _aggregation.getRole() + ";\r\n";

      _code = _code.insert(index,_code2insert);
      // ****** End Insert Code for Source Class **************
    }
  }

  private void genFromNary(Vector vTernary){
    FigNary _fNary;
    FigClass _fClass,_sClass,_tClass;
    String _code2insert = "";
    String _tempCode  = "";
    String searchString = "";
    String _role = "";
    String _invRole = "";
//    String _multiplicity = "";

    String _newClassName = "";
    int index = 0;

    for(int i = 0 ; i < vTernary.size() ; i++){
      _fNary = (FigNary) vTernary.elementAt(i);

      _fClass = _fNary.getFClass();
      _sClass = _fNary.getSClass();
      _tClass = _fNary.getTClass();
      _role   = _fNary.getRoleName();
      _invRole = "NaryINV" + _role;
//      _newClassName = _fClass.getName() + _sClass.getName() + _tClass.getName() + _role;
      _newClassName = "NaryClass" + _role;

      _code2insert = _space5 + _relationship + " Set<" + _newClassName + "> " + _role + "\r\n"
                   + _space5 + _space5 + _inverse + " " + _newClassName + "::" + _invRole + ";\r\n";

      // For First Class
      searchString = _space5 + "// End Relationship Part of "+ _fClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      _code = _code.insert(index,_code2insert);

      // For Second Class
      searchString = _space5 + "// End Relationship Part of "+ _sClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      _code = _code.insert(index,_code2insert);

      // For Third Class
      searchString = _space5 + "// End Relationship Part of "+ _tClass.getName();
      _tempCode = _code.toString();
      index = _tempCode.indexOf(searchString); // search index to insert code
      _code = _code.insert(index,_code2insert);

      // Create New Class
      _code = _code.append(_interface + " " + _newClassName + " \r\n"
        + "( extent "+ _newClassName + "s )\r\n"
        + "{ \r\n" + _space5 + "// Attribute Part\r\n"
        + _space5 + "// End Attribute Part of "+ _newClassName + "\r\n\r\n"
        + _space5 + "// Relationship Part\r\n"

        + _space5 + _relationship + " " + _fClass.getName() + " " + _invRole + "\r\n"
        + _space5 + _space5 + _inverse + " " + _fClass.getName() + "::" + _role + ";\r\n"

        + _space5 + _relationship + " " + _sClass.getName() + " " + _invRole + "\r\n"
        + _space5 + _space5 + _inverse + " " + _sClass.getName() + "::" + _role + ";\r\n"

        + _space5 + _relationship + " " + _tClass.getName() + " " + _invRole + "\r\n"
        + _space5 + _space5 + _inverse + " " + _tClass.getName() + "::" + _role + ";\r\n"

        + _space5 + "// End Relationship Part of "+ _newClassName + "\r\n"
        + "}; \r\n\r\n");
    }
  }
}