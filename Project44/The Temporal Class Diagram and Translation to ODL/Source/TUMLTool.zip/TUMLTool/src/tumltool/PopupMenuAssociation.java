package tumltool;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class PopupMenuAssociation extends JPopupMenu {
  JMenuItem jMenuItem1 = new JMenuItem();
  JMenuItem jMenuItem2 = new JMenuItem();
  ImageIcon imageProperties;
  ImageIcon imageDelete;
  PropertiesAssociation rChoosed;
  Vector vAssociation;
  int indexAssociation;
  JTextArea DrawArea;


  public PopupMenuAssociation() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void setAll(JTextArea drawArea,Vector V,int index,PropertiesAssociation pAssociation) {
    DrawArea = drawArea;
    vAssociation = V;
    indexAssociation = index;
    rChoosed = pAssociation;
  }

  private void jbInit() throws Exception {
    imageProperties   = new ImageIcon("Properties.gif");
    imageDelete       = new ImageIcon("Delete.gif");
    jMenuItem1.setIcon(imageProperties);
    jMenuItem1.setText("Properties");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem1_actionPerformed(e);
      }
    });
    jMenuItem2.setIcon(imageDelete);
    jMenuItem2.setText("Delete");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jMenuItem2_actionPerformed(e);
      }
    });
    this.add(jMenuItem1);
    this.addSeparator();
    this.add(jMenuItem2);
  }

  private void jMenuItem1_actionPerformed(ActionEvent e) {
    rChoosed.show();
  }

  void jMenuItem2_actionPerformed(ActionEvent e) {
    FigAssociationLine deleteAssociation = (FigAssociationLine) vAssociation.elementAt(indexAssociation);
    deleteAssociation.prepareDelete();
    DrawArea.remove(deleteAssociation);
    DrawArea.repaint();
    vAssociation.removeElementAt(indexAssociation);
  }
}