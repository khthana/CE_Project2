package tumltool;

import java.awt.*;
import COM.intersys.objects.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class FigAggregationLine extends FigLine {
  private FigClass _srcClass;
  private FigClass _aggClass;
  private structureLine _aggregation = new structureLine();
  private Oid oid = null;

/*  private Image ttRtIcon;
  private Image vtRtIcon;
  private Image btRtIcon;
*/
  public FigAggregationLine() {

    try {
      this.setSrcArrowHead(2);
/*      ttRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/ttRtIcon.gif"));
      vtRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/vtRtIcon.gif"));
      btRtIcon = Toolkit.getDefaultToolkit().getImage(new java.net.URL("file:///C:/TUMLTool/images/btRtIcon.gif"));
*/    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }

  public void setSrcClass(FigClass fClass){
    _srcClass = fClass;

    this.setBeginCordinate(fClass.getCX(),fClass.getCY());
    this.setSizeSRC(fClass.Width(),fClass.high());
    this.setSrcID(fClass.getId());

  }

  public void setAggregateClass(FigClass fClass){
    _aggClass = fClass;

    this.setEndCordinate(fClass.getCX(),fClass.getCY());
    this.setSizeDES(fClass.Width(),fClass.high());
    this.setDesID(fClass.getId());

  }

  public FigClass getSrcClass(){
    return _srcClass;
  }

  public FigClass getAggregationClass(){
    return _aggClass;
  }

/*
  public void setRole(String role){
    _aggregation.setRole(role);
  }

  public void setInverseRole(String invRole){
    _aggregation.setInvRole(invRole);
  }
*/
  public void setRole(String role){
    _aggregation.setRole(role);
  }

  public void setMultiplicity(String multiplicity){
    _aggregation.setMultiplicity(multiplicity);
  }
/*
  public void setTimeType(String timeType){
    _aggregation.setTimeType(timeType);
  }

  public void setGranularity(String granularity){
    _aggregation.setGranularity(granularity);
  }

  public String getRole(){
    return _aggregation.getRole();
  }

  public String getInverseRole(){
    return _aggregation.getInvRole();
  }
*/
  public String getMultiplicity(){
    return _aggregation.getMultiplicity();
  }

  public String getRole(){
    return _aggregation.getRole();
  }
/*
  public String getsTimeType(){
    return _aggregation.getsTimeType();
  }

  public int getiTimeType(){
    return _aggregation.getiTimeType();
  }

  public String getGranularity(){
    return _aggregation.getGranularity();
  }

  public void setTimestampType(String timestampType){
    _aggregation.setTimestampType(timestampType);
  }

  public String getTimestampType(){
    return _aggregation.getTimestampType();
  }
*/

  public void paintComponent(Graphics g) {
   super.paintComponent(g);

   int centerLineX = (_realX1+_realX2)/2 -10;
   int centerLineY = (_realY1+_realY2)/2 -10;

//   int centerLineX = (_realX1 == _realX2) ? (_realX1+_realX2)/2 - 5: (_realX1+_realX2)/2-10;
//   int centerLineY = (_realY1 == _realY2) ? (_realY1+_realY2)/2 - 5: (_realY1+_realY2)/2-10;
/*   if(_aggregation.getiTimeType() == 1)
     g.drawImage(vtRtIcon,centerLineX,centerLineY,this);
   if(_aggregation.getiTimeType() == 2)
     g.drawImage(ttRtIcon,centerLineX,centerLineY,this);
   if(_aggregation.getiTimeType() == 3)
     g.drawImage(btRtIcon,centerLineX,centerLineY,this);
*/
  }

  public void setOid(Oid id) {
    oid = id;
  }

  public Oid getOid() {
    return oid;
  }
}