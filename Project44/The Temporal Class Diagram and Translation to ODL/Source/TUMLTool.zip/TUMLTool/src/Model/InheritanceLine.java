/**
 * Cache' Java Class Generated 06:15PM  29 Jan 2002 for class Model.InheritanceLine
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;

import Model.Classes;



public class InheritanceLine extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public InheritanceLine( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public InheritanceLine( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public InheritanceLine( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public InheritanceLine( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public InheritanceLine( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public InheritanceLine( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private TransientAttr m_SubClass;
    private TransientAttr m_SuperClass;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "SubClass", (m_SubClass = new TransientAttr( this, "SubClass" )) );
        h.put( "SuperClass", (m_SuperClass = new TransientAttr( this, "SuperClass" )) );
        super._initClass( h );
        

        return "Model.InheritanceLine";
    }



    /**
     * Get Accessor method for SubClass
     *
    **/
    public Classes getSubClass() throws CacheException {
        return (Classes) m_SubClass.get();
    }

    /**
     * Set Accessor method for SubClass
     *
    **/
    public void setSubClass(Classes value) throws CacheException {
        m_SubClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for SuperClass
     *
    **/
    public Classes getSuperClass() throws CacheException {
        return (Classes) m_SuperClass.get();
    }

    /**
     * Set Accessor method for SuperClass
     *
    **/
    public void setSuperClass(Classes value) throws CacheException {
        m_SuperClass.set( (Transient) value );
    }






}


/**
 * End-of-file
**/
