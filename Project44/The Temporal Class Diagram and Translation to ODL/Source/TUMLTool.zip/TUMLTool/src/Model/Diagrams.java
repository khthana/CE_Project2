/**
 * Cache' Java Class Generated 03:00PM  14 Mar 2002 for class Model.Diagrams
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;




public class Diagrams extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public Diagrams( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public Diagrams( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public Diagrams( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Diagrams( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Diagrams( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Diagrams( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private StringAttr m_Descriptions;
    private StringAttr m_Designer;
    private StringAttr m_Name;
    private StringAttr m_Package;
    private TransientAttr m_listClasses;
    private TransientAttr m_listRelationAggregation;
    private TransientAttr m_listRelationAssociation;
    private TransientAttr m_listRelationInheritance;
    private TransientAttr m_listRelationTernary;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "Descriptions", (m_Descriptions = new StringAttr( this, "Descriptions" )) );
        h.put( "Designer", (m_Designer = new StringAttr( this, "Designer" )) );
        h.put( "Name", (m_Name = new StringAttr( this, "Name" )) );
        h.put( "Package", (m_Package = new StringAttr( this, "Package" )) );
        h.put( "listClasses", (m_listClasses = new TransientAttr( this, "listClasses" )) );
        h.put( "listRelationAggregation", (m_listRelationAggregation = new TransientAttr( this, "listRelationAggregation" )) );
        h.put( "listRelationAssociation", (m_listRelationAssociation = new TransientAttr( this, "listRelationAssociation" )) );
        h.put( "listRelationInheritance", (m_listRelationInheritance = new TransientAttr( this, "listRelationInheritance" )) );
        h.put( "listRelationTernary", (m_listRelationTernary = new TransientAttr( this, "listRelationTernary" )) );
        super._initClass( h );
        

        return "Model.Diagrams";
    }



    /**
     * Get Accessor method for Descriptions
     *
    **/
    public String getDescriptions() throws CacheException {
        return m_Descriptions.get();
    }

    /**
     * Set Accessor method for Descriptions
     *
    **/
    public void setDescriptions(String value) throws CacheException {
        m_Descriptions.set( value );
    }



    /**
     * Get Accessor method for Designer
     *
    **/
    public String getDesigner() throws CacheException {
        return m_Designer.get();
    }

    /**
     * Set Accessor method for Designer
     *
    **/
    public void setDesigner(String value) throws CacheException {
        m_Designer.set( value );
    }



    /**
     * Get Accessor method for Name
     *
    **/
    public String getName() throws CacheException {
        return m_Name.get();
    }

    /**
     * Set Accessor method for Name
     *
    **/
    public void setName(String value) throws CacheException {
        m_Name.set( value );
    }



    /**
     * Get Accessor method for Package
     *
    **/
    public String getPackage() throws CacheException {
        return m_Package.get();
    }

    /**
     * Set Accessor method for Package
     *
    **/
    public void setPackage(String value) throws CacheException {
        m_Package.set( value );
    }



    /**
     * Get Accessor method for listClasses
     *
    **/
    public ListOfObjects getlistClasses() throws CacheException {
        return (ListOfObjects) m_listClasses.get();
    }

    /**
     * Set Accessor method for listClasses
     *
    **/
    public void setlistClasses(ListOfObjects value) throws CacheException {
        m_listClasses.set( (Transient) value );
    }



    /**
     * Get Accessor method for listRelationAggregation
     *
    **/
    public ListOfObjects getlistRelationAggregation() throws CacheException {
        return (ListOfObjects) m_listRelationAggregation.get();
    }

    /**
     * Set Accessor method for listRelationAggregation
     *
    **/
    public void setlistRelationAggregation(ListOfObjects value) throws CacheException {
        m_listRelationAggregation.set( (Transient) value );
    }



    /**
     * Get Accessor method for listRelationAssociation
     *
    **/
    public ListOfObjects getlistRelationAssociation() throws CacheException {
        return (ListOfObjects) m_listRelationAssociation.get();
    }

    /**
     * Set Accessor method for listRelationAssociation
     *
    **/
    public void setlistRelationAssociation(ListOfObjects value) throws CacheException {
        m_listRelationAssociation.set( (Transient) value );
    }



    /**
     * Get Accessor method for listRelationInheritance
     *
    **/
    public ListOfObjects getlistRelationInheritance() throws CacheException {
        return (ListOfObjects) m_listRelationInheritance.get();
    }

    /**
     * Set Accessor method for listRelationInheritance
     *
    **/
    public void setlistRelationInheritance(ListOfObjects value) throws CacheException {
        m_listRelationInheritance.set( (Transient) value );
    }



    /**
     * Get Accessor method for listRelationTernary
     *
    **/
    public ListOfObjects getlistRelationTernary() throws CacheException {
        return (ListOfObjects) m_listRelationTernary.get();
    }

    /**
     * Set Accessor method for listRelationTernary
     *
    **/
    public void setlistRelationTernary(ListOfObjects value) throws CacheException {
        m_listRelationTernary.set( (Transient) value );
    }





    /**
     * Query initiator for query ByID
     *
    **/
    public ResultSet Query_ByID() throws CacheException {
        ResultSet _rs;

        _rs = new ResultSet( m_objectServer, "Model.Diagrams", "ByID" );

        return _rs;
    }




}


/**
 * End-of-file
**/
