/**
 * Cache' Java Class Generated 03:35PM  29 Jan 2002 for class Model.Line
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;




public class Line extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public Line( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public Line( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public Line( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Line( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Line( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Line( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private IntAttr m_DesHigh;
    private IntAttr m_DesId;
    private IntAttr m_DesWidth;
    private IntAttr m_SrcArrowHead;
    private IntAttr m_SrcHigh;
    private IntAttr m_SrcId;
    private IntAttr m_SrcWidth;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "DesHigh", (m_DesHigh = new IntAttr( this, "DesHigh" )) );
        h.put( "DesId", (m_DesId = new IntAttr( this, "DesId" )) );
        h.put( "DesWidth", (m_DesWidth = new IntAttr( this, "DesWidth" )) );
        h.put( "SrcArrowHead", (m_SrcArrowHead = new IntAttr( this, "SrcArrowHead" )) );
        h.put( "SrcHigh", (m_SrcHigh = new IntAttr( this, "SrcHigh" )) );
        h.put( "SrcId", (m_SrcId = new IntAttr( this, "SrcId" )) );
        h.put( "SrcWidth", (m_SrcWidth = new IntAttr( this, "SrcWidth" )) );
        super._initClass( h );
        

        return "Model.Line";
    }



    /**
     * Get Accessor method for DesHigh
     *
    **/
    public int getDesHigh() throws CacheException {
        return m_DesHigh.get();
    }

    /**
     * Set Accessor method for DesHigh
     *
    **/
    public void setDesHigh(int value) throws CacheException {
        m_DesHigh.set( value );
    }



    /**
     * Get Accessor method for DesId
     *
    **/
    public int getDesId() throws CacheException {
        return m_DesId.get();
    }

    /**
     * Set Accessor method for DesId
     *
    **/
    public void setDesId(int value) throws CacheException {
        m_DesId.set( value );
    }



    /**
     * Get Accessor method for DesWidth
     *
    **/
    public int getDesWidth() throws CacheException {
        return m_DesWidth.get();
    }

    /**
     * Set Accessor method for DesWidth
     *
    **/
    public void setDesWidth(int value) throws CacheException {
        m_DesWidth.set( value );
    }



    /**
     * Get Accessor method for SrcArrowHead
     *
    **/
    public int getSrcArrowHead() throws CacheException {
        return m_SrcArrowHead.get();
    }

    /**
     * Set Accessor method for SrcArrowHead
     *
    **/
    public void setSrcArrowHead(int value) throws CacheException {
        m_SrcArrowHead.set( value );
    }



    /**
     * Get Accessor method for SrcHigh
     *
    **/
    public int getSrcHigh() throws CacheException {
        return m_SrcHigh.get();
    }

    /**
     * Set Accessor method for SrcHigh
     *
    **/
    public void setSrcHigh(int value) throws CacheException {
        m_SrcHigh.set( value );
    }



    /**
     * Get Accessor method for SrcId
     *
    **/
    public int getSrcId() throws CacheException {
        return m_SrcId.get();
    }

    /**
     * Set Accessor method for SrcId
     *
    **/
    public void setSrcId(int value) throws CacheException {
        m_SrcId.set( value );
    }



    /**
     * Get Accessor method for SrcWidth
     *
    **/
    public int getSrcWidth() throws CacheException {
        return m_SrcWidth.get();
    }

    /**
     * Set Accessor method for SrcWidth
     *
    **/
    public void setSrcWidth(int value) throws CacheException {
        m_SrcWidth.set( value );
    }






}


/**
 * End-of-file
**/
