/**
 * Cache' Java Class Generated 07:35PM  05 Feb 2002 for class Model.Attribute
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;




public class Attribute extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public Attribute( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public Attribute( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public Attribute( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Attribute( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Attribute( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Attribute( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private StringAttr m_Collection;
    private StringAttr m_Descriptions;
    private IntAttr m_Granularity;
    private IntAttr m_IndexTimeType;
    private StringAttr m_Name;
    private StringAttr m_TimestampType;
    private StringAttr m_Type;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "Collection", (m_Collection = new StringAttr( this, "Collection" )) );
        h.put( "Descriptions", (m_Descriptions = new StringAttr( this, "Descriptions" )) );
        h.put( "Granularity", (m_Granularity = new IntAttr( this, "Granularity" )) );
        h.put( "IndexTimeType", (m_IndexTimeType = new IntAttr( this, "IndexTimeType" )) );
        h.put( "Name", (m_Name = new StringAttr( this, "Name" )) );
        h.put( "TimestampType", (m_TimestampType = new StringAttr( this, "TimestampType" )) );
        h.put( "Type", (m_Type = new StringAttr( this, "Type" )) );
        super._initClass( h );
        

        return "Model.Attribute";
    }



    /**
     * Get Accessor method for Collection
     *
    **/
    public String getCollection() throws CacheException {
        return m_Collection.get();
    }

    /**
     * Set Accessor method for Collection
     *
    **/
    public void setCollection(String value) throws CacheException {
        m_Collection.set( value );
    }



    /**
     * Get Accessor method for Descriptions
     *
    **/
    public String getDescriptions() throws CacheException {
        return m_Descriptions.get();
    }

    /**
     * Set Accessor method for Descriptions
     *
    **/
    public void setDescriptions(String value) throws CacheException {
        m_Descriptions.set( value );
    }



    /**
     * Get Accessor method for Granularity
     *
    **/
    public int getGranularity() throws CacheException {
        return m_Granularity.get();
    }

    /**
     * Set Accessor method for Granularity
     *
    **/
    public void setGranularity(int value) throws CacheException {
        m_Granularity.set( value );
    }



    /**
     * Get Accessor method for IndexTimeType
     *
    **/
    public int getIndexTimeType() throws CacheException {
        return m_IndexTimeType.get();
    }

    /**
     * Set Accessor method for IndexTimeType
     *
    **/
    public void setIndexTimeType(int value) throws CacheException {
        m_IndexTimeType.set( value );
    }



    /**
     * Get Accessor method for Name
     *
    **/
    public String getName() throws CacheException {
        return m_Name.get();
    }

    /**
     * Set Accessor method for Name
     *
    **/
    public void setName(String value) throws CacheException {
        m_Name.set( value );
    }



    /**
     * Get Accessor method for TimestampType
     *
    **/
    public String getTimestampType() throws CacheException {
        return m_TimestampType.get();
    }

    /**
     * Set Accessor method for TimestampType
     *
    **/
    public void setTimestampType(String value) throws CacheException {
        m_TimestampType.set( value );
    }



    /**
     * Get Accessor method for Type
     *
    **/
    public String getType() throws CacheException {
        return m_Type.get();
    }

    /**
     * Set Accessor method for Type
     *
    **/
    public void setType(String value) throws CacheException {
        m_Type.set( value );
    }






}


/**
 * End-of-file
**/
