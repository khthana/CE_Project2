/**
 * Cache' Java Class Generated 12:04AM  11 Mar 2002 for class Model.AggregationLine
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;

import Model.Classes;



public class AggregationLine extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public AggregationLine( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public AggregationLine( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public AggregationLine( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public AggregationLine( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public AggregationLine( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public AggregationLine( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private TransientAttr m_AggregationClass;
    private StringAttr m_Multiplicity;
    private StringAttr m_RoleName;
    private TransientAttr m_SrcClass;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "AggregationClass", (m_AggregationClass = new TransientAttr( this, "AggregationClass" )) );
        h.put( "Multiplicity", (m_Multiplicity = new StringAttr( this, "Multiplicity" )) );
        h.put( "RoleName", (m_RoleName = new StringAttr( this, "RoleName" )) );
        h.put( "SrcClass", (m_SrcClass = new TransientAttr( this, "SrcClass" )) );
        super._initClass( h );
        

        return "Model.AggregationLine";
    }



    /**
     * Get Accessor method for AggregationClass
     *
    **/
    public Classes getAggregationClass() throws CacheException {
        return (Classes) m_AggregationClass.get();
    }

    /**
     * Set Accessor method for AggregationClass
     *
    **/
    public void setAggregationClass(Classes value) throws CacheException {
        m_AggregationClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for Multiplicity
     *
    **/
    public String getMultiplicity() throws CacheException {
        return m_Multiplicity.get();
    }

    /**
     * Set Accessor method for Multiplicity
     *
    **/
    public void setMultiplicity(String value) throws CacheException {
        m_Multiplicity.set( value );
    }



    /**
     * Get Accessor method for RoleName
     *
    **/
    public String getRoleName() throws CacheException {
        return m_RoleName.get();
    }

    /**
     * Set Accessor method for RoleName
     *
    **/
    public void setRoleName(String value) throws CacheException {
        m_RoleName.set( value );
    }



    /**
     * Get Accessor method for SrcClass
     *
    **/
    public Classes getSrcClass() throws CacheException {
        return (Classes) m_SrcClass.get();
    }

    /**
     * Set Accessor method for SrcClass
     *
    **/
    public void setSrcClass(Classes value) throws CacheException {
        m_SrcClass.set( (Transient) value );
    }






}


/**
 * End-of-file
**/
