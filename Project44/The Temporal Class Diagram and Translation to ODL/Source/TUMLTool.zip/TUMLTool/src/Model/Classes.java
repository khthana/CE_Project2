/**
 * Cache' Java Class Generated 04:40AM  30 Jan 2002 for class Model.Classes
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;




public class Classes extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public Classes( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public Classes( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public Classes( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Classes( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Classes( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public Classes( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private IntAttr m_AssociationBT;
    private IntAttr m_AssociationTT;
    private IntAttr m_AssociationVT;
    private StringAttr m_Descriptions;
    private IntAttr m_Granularity;
    private IntAttr m_High;
    private IntAttr m_Id;
    private IntAttr m_IndexTimeType;
    private StringAttr m_Name;
    private IntAttr m_PointX;
    private IntAttr m_PointY;
    private IntAttr m_Width;
    private TransientAttr m_listAttribute;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "AssociationBT", (m_AssociationBT = new IntAttr( this, "AssociationBT" )) );
        h.put( "AssociationTT", (m_AssociationTT = new IntAttr( this, "AssociationTT" )) );
        h.put( "AssociationVT", (m_AssociationVT = new IntAttr( this, "AssociationVT" )) );
        h.put( "Descriptions", (m_Descriptions = new StringAttr( this, "Descriptions" )) );
        h.put( "Granularity", (m_Granularity = new IntAttr( this, "Granularity" )) );
        h.put( "High", (m_High = new IntAttr( this, "High" )) );
        h.put( "Id", (m_Id = new IntAttr( this, "Id" )) );
        h.put( "IndexTimeType", (m_IndexTimeType = new IntAttr( this, "IndexTimeType" )) );
        h.put( "Name", (m_Name = new StringAttr( this, "Name" )) );
        h.put( "PointX", (m_PointX = new IntAttr( this, "PointX" )) );
        h.put( "PointY", (m_PointY = new IntAttr( this, "PointY" )) );
        h.put( "Width", (m_Width = new IntAttr( this, "Width" )) );
        h.put( "listAttribute", (m_listAttribute = new TransientAttr( this, "listAttribute" )) );
        super._initClass( h );
        

        return "Model.Classes";
    }



    /**
     * Get Accessor method for AssociationBT
     *
    **/
    public int getAssociationBT() throws CacheException {
        return m_AssociationBT.get();
    }

    /**
     * Set Accessor method for AssociationBT
     *
    **/
    public void setAssociationBT(int value) throws CacheException {
        m_AssociationBT.set( value );
    }



    /**
     * Get Accessor method for AssociationTT
     *
    **/
    public int getAssociationTT() throws CacheException {
        return m_AssociationTT.get();
    }

    /**
     * Set Accessor method for AssociationTT
     *
    **/
    public void setAssociationTT(int value) throws CacheException {
        m_AssociationTT.set( value );
    }



    /**
     * Get Accessor method for AssociationVT
     *
    **/
    public int getAssociationVT() throws CacheException {
        return m_AssociationVT.get();
    }

    /**
     * Set Accessor method for AssociationVT
     *
    **/
    public void setAssociationVT(int value) throws CacheException {
        m_AssociationVT.set( value );
    }



    /**
     * Get Accessor method for Descriptions
     *
    **/
    public String getDescriptions() throws CacheException {
        return m_Descriptions.get();
    }

    /**
     * Set Accessor method for Descriptions
     *
    **/
    public void setDescriptions(String value) throws CacheException {
        m_Descriptions.set( value );
    }



    /**
     * Get Accessor method for Granularity
     *
    **/
    public int getGranularity() throws CacheException {
        return m_Granularity.get();
    }

    /**
     * Set Accessor method for Granularity
     *
    **/
    public void setGranularity(int value) throws CacheException {
        m_Granularity.set( value );
    }



    /**
     * Get Accessor method for High
     *
    **/
    public int getHigh() throws CacheException {
        return m_High.get();
    }

    /**
     * Set Accessor method for High
     *
    **/
    public void setHigh(int value) throws CacheException {
        m_High.set( value );
    }



    /**
     * Get Accessor method for Id
     *
    **/
    public int getId() throws CacheException {
        return m_Id.get();
    }

    /**
     * Set Accessor method for Id
     *
    **/
    public void setId(int value) throws CacheException {
        m_Id.set( value );
    }



    /**
     * Get Accessor method for IndexTimeType
     *
    **/
    public int getIndexTimeType() throws CacheException {
        return m_IndexTimeType.get();
    }

    /**
     * Set Accessor method for IndexTimeType
     *
    **/
    public void setIndexTimeType(int value) throws CacheException {
        m_IndexTimeType.set( value );
    }



    /**
     * Get Accessor method for Name
     *
    **/
    public String getName() throws CacheException {
        return m_Name.get();
    }

    /**
     * Set Accessor method for Name
     *
    **/
    public void setName(String value) throws CacheException {
        m_Name.set( value );
    }



    /**
     * Get Accessor method for PointX
     *
    **/
    public int getPointX() throws CacheException {
        return m_PointX.get();
    }

    /**
     * Set Accessor method for PointX
     *
    **/
    public void setPointX(int value) throws CacheException {
        m_PointX.set( value );
    }



    /**
     * Get Accessor method for PointY
     *
    **/
    public int getPointY() throws CacheException {
        return m_PointY.get();
    }

    /**
     * Set Accessor method for PointY
     *
    **/
    public void setPointY(int value) throws CacheException {
        m_PointY.set( value );
    }



    /**
     * Get Accessor method for Width
     *
    **/
    public int getWidth() throws CacheException {
        return m_Width.get();
    }

    /**
     * Set Accessor method for Width
     *
    **/
    public void setWidth(int value) throws CacheException {
        m_Width.set( value );
    }



    /**
     * Get Accessor method for listAttribute
     *
    **/
    public ListOfObjects getlistAttribute() throws CacheException {
        return (ListOfObjects) m_listAttribute.get();
    }

    /**
     * Set Accessor method for listAttribute
     *
    **/
    public void setlistAttribute(ListOfObjects value) throws CacheException {
        m_listAttribute.set( (Transient) value );
    }






}


/**
 * End-of-file
**/
