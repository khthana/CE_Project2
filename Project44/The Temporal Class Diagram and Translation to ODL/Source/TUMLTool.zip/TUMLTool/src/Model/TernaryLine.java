/**
 * Cache' Java Class Generated 03:32PM  14 Mar 2002 for class Model.TernaryLine
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;

import Model.Classes;



public class TernaryLine extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public TernaryLine( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public TernaryLine( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public TernaryLine( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public TernaryLine( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public TernaryLine( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public TernaryLine( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private IntAttr m_CoordinateX;
    private IntAttr m_CoordinateY;
    private TransientAttr m_FirstClass;
    private StringAttr m_Granularity;
    private IntAttr m_IndexTimeType;
    private StringAttr m_RoleName;
    private TransientAttr m_SecondClass;
    private TransientAttr m_ThirdClass;
    private StringAttr m_TimestampType;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "CoordinateX", (m_CoordinateX = new IntAttr( this, "CoordinateX" )) );
        h.put( "CoordinateY", (m_CoordinateY = new IntAttr( this, "CoordinateY" )) );
        h.put( "FirstClass", (m_FirstClass = new TransientAttr( this, "FirstClass" )) );
        h.put( "Granularity", (m_Granularity = new StringAttr( this, "Granularity" )) );
        h.put( "IndexTimeType", (m_IndexTimeType = new IntAttr( this, "IndexTimeType" )) );
        h.put( "RoleName", (m_RoleName = new StringAttr( this, "RoleName" )) );
        h.put( "SecondClass", (m_SecondClass = new TransientAttr( this, "SecondClass" )) );
        h.put( "ThirdClass", (m_ThirdClass = new TransientAttr( this, "ThirdClass" )) );
        h.put( "TimestampType", (m_TimestampType = new StringAttr( this, "TimestampType" )) );
        super._initClass( h );
        

        return "Model.TernaryLine";
    }



    /**
     * Get Accessor method for CoordinateX
     *
    **/
    public int getCoordinateX() throws CacheException {
        return m_CoordinateX.get();
    }

    /**
     * Set Accessor method for CoordinateX
     *
    **/
    public void setCoordinateX(int value) throws CacheException {
        m_CoordinateX.set( value );
    }



    /**
     * Get Accessor method for CoordinateY
     *
    **/
    public int getCoordinateY() throws CacheException {
        return m_CoordinateY.get();
    }

    /**
     * Set Accessor method for CoordinateY
     *
    **/
    public void setCoordinateY(int value) throws CacheException {
        m_CoordinateY.set( value );
    }



    /**
     * Get Accessor method for FirstClass
     *
    **/
    public Classes getFirstClass() throws CacheException {
        return (Classes) m_FirstClass.get();
    }

    /**
     * Set Accessor method for FirstClass
     *
    **/
    public void setFirstClass(Classes value) throws CacheException {
        m_FirstClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for Granularity
     *
    **/
    public String getGranularity() throws CacheException {
        return m_Granularity.get();
    }

    /**
     * Set Accessor method for Granularity
     *
    **/
    public void setGranularity(String value) throws CacheException {
        m_Granularity.set( value );
    }



    /**
     * Get Accessor method for IndexTimeType
     *
    **/
    public int getIndexTimeType() throws CacheException {
        return m_IndexTimeType.get();
    }

    /**
     * Set Accessor method for IndexTimeType
     *
    **/
    public void setIndexTimeType(int value) throws CacheException {
        m_IndexTimeType.set( value );
    }



    /**
     * Get Accessor method for RoleName
     *
    **/
    public String getRoleName() throws CacheException {
        return m_RoleName.get();
    }

    /**
     * Set Accessor method for RoleName
     *
    **/
    public void setRoleName(String value) throws CacheException {
        m_RoleName.set( value );
    }



    /**
     * Get Accessor method for SecondClass
     *
    **/
    public Classes getSecondClass() throws CacheException {
        return (Classes) m_SecondClass.get();
    }

    /**
     * Set Accessor method for SecondClass
     *
    **/
    public void setSecondClass(Classes value) throws CacheException {
        m_SecondClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for ThirdClass
     *
    **/
    public Classes getThirdClass() throws CacheException {
        return (Classes) m_ThirdClass.get();
    }

    /**
     * Set Accessor method for ThirdClass
     *
    **/
    public void setThirdClass(Classes value) throws CacheException {
        m_ThirdClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for TimestampType
     *
    **/
    public String getTimestampType() throws CacheException {
        return m_TimestampType.get();
    }

    /**
     * Set Accessor method for TimestampType
     *
    **/
    public void setTimestampType(String value) throws CacheException {
        m_TimestampType.set( value );
    }






}


/**
 * End-of-file
**/
