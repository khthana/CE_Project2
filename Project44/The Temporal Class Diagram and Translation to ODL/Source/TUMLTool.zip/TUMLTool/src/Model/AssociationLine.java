/**
 * Cache' Java Class Generated 07:11PM  29 Jan 2002 for class Model.AssociationLine
 *
**/


package Model;


/**
 * Imports
 *
**/

import java.util.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.math.BigInteger;
import java.math.BigDecimal;
import COM.intersys.objects.*;
import COM.intersys.objects.attribute.*;
import COM.intersys.util.SysList;
import COM.intersys.util.CacheException;

import Model.Classes;



public class AssociationLine extends Persistent {

    /**
     * Constructor creates a new instance
     *
    **/
    public AssociationLine( ObjectServer os ) throws CacheException {
        super( os, new SysList() );
    }

    /**
     * Constructor creates a new instance (with arguments)
     *
    **/
    public AssociationLine( ObjectServer os, SysList args ) throws CacheException {
        super( os, args );
    }

    /**
     * Constructor creates attaches to an existing oref
     *
    **/
    public AssociationLine( ObjectServer os, Oref oref ) throws CacheException {
        super( os, oref );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public AssociationLine( ObjectServer os, Oid oid ) throws CacheException {
        super( os, oid );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public AssociationLine( ObjectServer os, String id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * Constructor opens the specified instance
     *
    **/
    public AssociationLine( ObjectServer os, int id ) throws CacheException {
        super( os, new Oid( id ) );
    }

    /**
     * _close closes an Oref
     *
    **/
    public void _close() throws CacheException {
        synchronized (m_objectServer)  {
            super._close();
        }
    }


    /**
     * Parameters
     *
    **/



    /**
     * Property Storage
     *
    **/
    private TransientAttr m_DesClass;
    private StringAttr m_Granularity;
    private IntAttr m_IndexTimeType;
    private StringAttr m_InvName;
    private StringAttr m_Multiplicity;
    private StringAttr m_Name;
    private TransientAttr m_SrcClass;
    private StringAttr m_TimestampType;



    /**
     * Initialize the class
     *
    **/
    protected String _initClass( Hashtable h ) {
        h.put( "DesClass", (m_DesClass = new TransientAttr( this, "DesClass" )) );
        h.put( "Granularity", (m_Granularity = new StringAttr( this, "Granularity" )) );
        h.put( "IndexTimeType", (m_IndexTimeType = new IntAttr( this, "IndexTimeType" )) );
        h.put( "InvName", (m_InvName = new StringAttr( this, "InvName" )) );
        h.put( "Multiplicity", (m_Multiplicity = new StringAttr( this, "Multiplicity" )) );
        h.put( "Name", (m_Name = new StringAttr( this, "Name" )) );
        h.put( "SrcClass", (m_SrcClass = new TransientAttr( this, "SrcClass" )) );
        h.put( "TimestampType", (m_TimestampType = new StringAttr( this, "TimestampType" )) );
        super._initClass( h );
        

        return "Model.AssociationLine";
    }



    /**
     * Get Accessor method for DesClass
     *
    **/
    public Classes getDesClass() throws CacheException {
        return (Classes) m_DesClass.get();
    }

    /**
     * Set Accessor method for DesClass
     *
    **/
    public void setDesClass(Classes value) throws CacheException {
        m_DesClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for Granularity
     *
    **/
    public String getGranularity() throws CacheException {
        return m_Granularity.get();
    }

    /**
     * Set Accessor method for Granularity
     *
    **/
    public void setGranularity(String value) throws CacheException {
        m_Granularity.set( value );
    }



    /**
     * Get Accessor method for IndexTimeType
     *
    **/
    public int getIndexTimeType() throws CacheException {
        return m_IndexTimeType.get();
    }

    /**
     * Set Accessor method for IndexTimeType
     *
    **/
    public void setIndexTimeType(int value) throws CacheException {
        m_IndexTimeType.set( value );
    }



    /**
     * Get Accessor method for InvName
     *
    **/
    public String getInvName() throws CacheException {
        return m_InvName.get();
    }

    /**
     * Set Accessor method for InvName
     *
    **/
    public void setInvName(String value) throws CacheException {
        m_InvName.set( value );
    }



    /**
     * Get Accessor method for Multiplicity
     *
    **/
    public String getMultiplicity() throws CacheException {
        return m_Multiplicity.get();
    }

    /**
     * Set Accessor method for Multiplicity
     *
    **/
    public void setMultiplicity(String value) throws CacheException {
        m_Multiplicity.set( value );
    }



    /**
     * Get Accessor method for Name
     *
    **/
    public String getName() throws CacheException {
        return m_Name.get();
    }

    /**
     * Set Accessor method for Name
     *
    **/
    public void setName(String value) throws CacheException {
        m_Name.set( value );
    }



    /**
     * Get Accessor method for SrcClass
     *
    **/
    public Classes getSrcClass() throws CacheException {
        return (Classes) m_SrcClass.get();
    }

    /**
     * Set Accessor method for SrcClass
     *
    **/
    public void setSrcClass(Classes value) throws CacheException {
        m_SrcClass.set( (Transient) value );
    }



    /**
     * Get Accessor method for TimestampType
     *
    **/
    public String getTimestampType() throws CacheException {
        return m_TimestampType.get();
    }

    /**
     * Set Accessor method for TimestampType
     *
    **/
    public void setTimestampType(String value) throws CacheException {
        m_TimestampType.set( value );
    }






}


/**
 * End-of-file
**/
