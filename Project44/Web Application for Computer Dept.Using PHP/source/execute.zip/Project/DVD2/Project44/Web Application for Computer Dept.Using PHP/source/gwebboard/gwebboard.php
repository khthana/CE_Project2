<? session_start();
include("connect.inc.php");
include("update.inc.php");
include("censor.inc.php");
$dbname=gwebboard();
if($id[0])
{
?>
<html>
<head>
<title>webboard</title>
<META  http-equiv="content-type" content="text/html;charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>

<style>
.a1
  {
  color:#FFFFFF; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13px;
  text-align: center;
  }   
.a2
  {
  color:#FF33FF; /* ��ǧ */
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13px;
  text-align: center;
  }   
.a3
  {
  color:#006AD5; /* green */
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13px;
  text-align: center;
  }   
</style>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: none}
a:hover { color: #0099FF; text-decoration: none}
-->
</style>

<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function NewWindow(mypage, myname, w, h, scroll) {
var winl = (screen.width - w) / 2;
var wint = (screen.height - h) / 2;
winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
win = window.open(mypage, myname, winprops)
if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v3.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : args[i+1];
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    if ((nbArr = document[grpName]) != null)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = args[i+1];
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>

<?
if($select==3)//showuser
{ 
?>
<body bgcolor="#FFFFFF">
<table border=0  width="760" align=left height="640" >
  <tr class=a> 
    <td valign="top" height="97" width="414"><img src="images/logo.gif" width="305" height="74"> 
      <font color="#006291" ><b> </b></font></td>
    <td valign="middle" height="97" width="435"><font color="#FF0066" ><b>GROUP</b></font>&nbsp;<font color="#FF0066" ><b> 
      : 
      &nbsp;<?print($nameboards);?>
      </b></font></td>
  </tr>
  <tr class=a> 
    <td valign="top" colspan="2" height="18"> 
      <table border=0 width="760" align=left cellspacing="1" cellpadding="0">
        <tr height=22 bgcolor=#0053A6> 
          <th align=center width=200 class=a1>�ѹ-���� ���������� Group</th>
          <th align=center width=300 class=a1>Email</th>
          <th align=center width=200 class=a1>
            <div align="center">ʶҹ�</div>
          </th>
        </tr>
        <?
		if($submit=='Submit')
	      { 
		//�� admin 㹵��ҧ admin
		  $sql="select * from admin where nameboard='$nameboards'";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error");
	       $t=1;	
			  while($result=mysql_fetch_array($dbquery))
			  {
		        print("<tr height=20><td  align=center width=225 bgcolor=#EEF3FD><font class=a3>$result[date1]</font>&nbsp;&nbsp;&nbsp;<font class=a2>$result[time1]</font></td>");
                print("<td  align=center width=300 class=a3 bgcolor=#DBE6FD>$result[email]</td>");
                print("<td  align=center width=225 class=a3 bgcolor=#EEF3FD>admin</td></tr>");
          	  } 
		  }
	   //�� user 㹵��ҧ userboard
		  $sql="select * from userboard where nameboard='$nameboards' order by email asc";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error");
   		  $num_rows=mysql_num_rows($dbquery);
			  while($result=mysql_fetch_array($dbquery))
			  {
		        print("<tr height=20><td  align=center width=225 bgcolor=#EEF3FD><font class=a3>$result[date]</font>&nbsp;&nbsp;&nbsp;<font class=a2>$result[time]</font></td>");
                print("<td  align=center width=300 class=a3 bgcolor=#DBE6FD>$result[email]</td>");
                print("<td  align=center width=225 class=a3 bgcolor=#EEF3FD>user</td></tr>");
          	  }
$t=$t+$num_rows;
//�Դ�ҹ������
     closedb();
?>
 <tr height=20 bgcolor="#FFFFFF"> 
          <td  align=center colspan="3">
            <div align="right"><font class=a3><FONT  COLOR="#003871">���������� 
              <FONT  COLOR="#FF0000"><?print($t);?></FONT>
              ��</font></FONT>&nbsp;</div>
          </td>
        </tr>      
</table>
    </td>
 </tr>
  <tr class=a> 
  <td valign="top" colspan="2"> 
 <table width="760" border="0" cellspacing="0" cellpadding="0">
  <tr class=a>
    <td class=a>
      <br>
        <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8" class=a>
      <hr align="center" width="550" >
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
	</td>
  </tr>
</table>
<?
}
elseif($select==2) 
{
?>
  <body bgcolor="#FFFFFF">
<?
 //ź���������ö�� group ��� table userboard
  $sql="delete from userboard where email ='$id[0]' and nameboard='$nameboards'";
  $dbquery=mysql_db_query($dbname,$sql)or die("error1");

//�Դ�ҹ������
 closedb();
print("<META HTTP-EQUIV='REFRESH' Content=0;URL=indexs.php>");
  
}
else //if($select==1||$check_newtopic=='submit') //����� group 
  {
//update num=0 ��� table admin
$sql="update admin set num=0 where (nameboard='$nameboards' and email='$id[0]')";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");


$d=date("d-m-Y");
$t=date("h:i:s a");
$color="#A6E2FF";
//update date2=$d ��� table admin
$sql="update admin set date2='$d',time2='$t' where (nameboard='$nameboards')";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");

 
 if(!$page)    //�ͧ pagging
     $page=1;
   
//��Ǩ�ͺ id �ش���� �����ҡѺ $idtopic_new
$sql="select * from $nameboards where id='$idtopic_new'";
$dbquery=mysql_db_query($dbname,$sql)or die("error22");
$rows=mysql_num_rows($dbquery);	  

 if(($check_newtopic=='Submit') and ($rows==0))
    {
	 // print($filegroup_size);
	  //���ҧ���硷���
      mkdir($nameboards.'/topic'.$idtopic_new,0777) or die("error8");

	  if($filegroup_size<3072000)//check size
          {
     		//print($filegroup_size);
			if(($filegroup!="none") && ($filegroup!=''))   
     		  {	 
			    //���ҧ���硷���
				  $dh=opendir($nameboards.'/topic'.$idtopic_new);
				 mkdir($nameboards.'/topic'.$idtopic_new."/id1",0777) or die("error8");
				 closedir($dh);
				 copy($filegroup,$nameboards.'/topic'.$idtopic_new."/id1/".$filegroup_name);
			  } 

			 //update num=1 ��� table admin
             $sql="update admin set num=1 where (nameboard='$nameboards' and email!='$id[0]')";
             $dbquery=mysql_db_query($dbname,$sql)or die("error0");
			 
			 //$data=stripslashes(nl2br(htmlspecialchars($data)));//��ͧ���§���١�ӴѺ����
		     //$topic=stripslashes(nl2br(htmlspecialchars($topic)));
	        
             $data=htmlspecialchars($data);//��ͧ���§���١�ӴѺ����
		     $topic=htmlspecialchars($topic);

			 $data=ereg_replace("\n","<br>",$data);
             $topic=ereg_replace("\n","<br>",$topic);

			 $data=ereg_replace(" ","&nbsp;",$data);
              $topic=ereg_replace(" ","&nbsp;",$topic);
			 
			 $data=censor($data);
             $topic=censor($topic);

		
			 //��������ŧ���ҧ ����webbaorboard��ҧ�
             $sql="insert into $nameboards (topic,date1,time1,date2,time2,email) values ('$topic','$d','$t','$d','$t','$id[0]')";
             $dbquery=mysql_db_query($dbname,$sql)or die("error1");
              
			  //select ���ҧ ����webbaorboard��ҧ� �����Ҥ�� id �ش����
		      $sql="select * from $nameboards order by id Desc";
		      $dbquery=mysql_db_query($dbname,$sql)or die("error2");
		      $result=mysql_fetch_array($dbquery);
			  $idd=$result[id];
             
			 //���ҧ���ҧ�������ǡѺ ����webbaorboard��ҧ�+id ���� topic ��ҧ�
		     $sql="create table $nameboards$idd (data longtext NOT NULL,ip varchar(50) NOT NULL,email varchar(30) NOT NULL,date varchar(10) NOT NULL,time varchar(11) NOT NULL,id int(5) NOT NULL auto_increment,sent_mail int(1) NOT NULL,icq int(20) NOT NULL,filegroup varchar(50) NOT NULL,logo varchar(20) NOT NULL,PRIMARY KEY (id))";
             $dbquery=mysql_db_query($dbname,$sql) or die("error3ss");
		   		  
		     if($HTTP_X_FORWARDED_FOR=="")
	            $REMOTE=$REMOTE_ADDR; 
             else
	            $REMOTE="$REMOTE_ADDR => $HTTP_X_FORWARDED_FOR ";
	           			  
			  //��������ŧ���ҧ ����webbaorboard��ҧ�+id ���� topic ��ҧ�
             $sql="insert into $nameboards$idd (data,ip,email,date,time,sent_mail,icq,filegroup,logo) values ('$data','$REMOTE','$id[0]','$d','$t','$sent_mail','$icq','$filegroup_name','$logo')";
             $dbquery=mysql_db_query($dbname,$sql)or die("error4");
	
		  }//check file size
	else
		{
		  $fileerror='1';
		}
	}

if($fileerror!='1')
  {
?>
<body bgcolor="#FFFFFF" >
<table border=0  width="760" align=left height="640" >
  <tr class=a > 
    <td valign="top" height="74" width="414"><img src="images/logo.gif" width="305" height="74"> 
    </td>
    <td valign="middle" height="74" width="435"><font color="#FF0066" ><b>GROUP</b></font>&nbsp;<font color="#FF0066" ><b> 
      : &nbsp; 
      <?print($nameboards);?>
      </b></font></td>
  </tr>
  <tr class=a> 
    <td valign="top" colspan="2" height="26"> 
	  <table width="760" border="0" cellspacing="0" cellpadding="0" height="25">
        <tr> 
          
        <td width="8%" height="25" align="center"><a href="newtopic.php?nameboards=<?print($nameboards);?>"><img src="images/postnew.gif" width="98" height="30" border="0" alt="��駡�з������"></a> 
        </td>
          
        <td width="23%" height="25">&nbsp;</td>
          
        <td width="44%" height="25" valign="bottom"> 
          <div align="right"></div>
        </td>
        <td width="6%" height="25" valign="bottom" align="right" bgcolor="#FFFFFF" class=a>&nbsp;</td>
          
        <td width="19%" height="25" valign="bottom" align="center" bgcolor="#FFFFFF"> 
          <div align="right"><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif"><font  color="#006699">PAGE 
            : 
            <?print($page);?>
            </font><b><font color="#0064C8" >|</font></b></font><a href="indexs.php" class=a><font color=#003162> 
            <b>HOME </b></font></a><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif"><b><font color="#0064C8">|</font></b></font></div>
        </td>
  </tr>
</table>
     </td>
     </tr>
<tr class=a> 
    <td valign="top" colspan="2" height="47"> 
      
    <table width="760" border="0" cellspacing="1" cellpadding="1" bordercolor="#ECF9FF">
      <tr bgcolor="#67A6C7" > 
        <td width="5%" height="23" class=a> 
          <div align="center"><font color="#000000"><b>S</b></font></div>
        </td>
        <td width="11%" height="23" class=a> 
          <div align="center"><font color="#000000"><b>�ѹ����駡�з��</b></font></div>
        </td>
        <td width="45%" height="23" class=a> 
          <div align="center"><font color="#000000"><b>��Ǣ�͡�з��</b></font></div>
        </td>
        <td width="23%" height="23" class=a> 
          <div align="center"><font color="#000000"><b>����駡�з��</b></font></div>
        </td>
        <td width="4%" height="23" class=a> 
          <div align="center"><font color="#000000"><b>�ͺ</b></font></div>
        </td>
        <td width="12%" height="23" class=a> 
          <div align="center"><font color="#000000"><b>�ѹ���ͺ����ش</b></font></div>
        </td>
      </tr>
      <?
   		  $sql="select * from $nameboards";
		  $per_page=10;
          $prev=$page-1;
          $next=$page+1;
          $dbquery=mysql_db_query($dbname,$sql)or die("error1");
		  $p_start=($per_page * $page)-$per_page;
          $rows=mysql_num_rows($dbquery);	
		  if($rows<=$per_page)
             $n_page=1;
          else if (($rows%$per_page)==0)
            $n_page=($rows/$per_page);
          else
		   $n_page=($rows/$per_page)+1;
           $n_page=(int)$n_page;

           $sql="select * from $nameboards order by id  Desc LIMIT $p_start, $per_page";
           $dbquery=mysql_db_query($dbname,$sql)or die("error2");
 
		    $c=0;
            while($result=mysql_fetch_array($dbquery))
			  {
		         //��ͧ����ѹ���ͺ����ش
				 $sql3="select * from $nameboards where id=$result[id]";
		         $dbquery3=mysql_db_query($dbname,$sql3)or die("error2");
		         $result3=mysql_fetch_array($dbquery3);
				 
				 //�Ѻ�ӹǹ row  㹵��ҧ ����webbaorboard��ҧ�+id
				 $sql1="select * from $nameboards$result[id]";
		         $dbquery1=mysql_db_query($dbname,$sql1)or die("error3");
		         $num_rows1=mysql_num_rows($dbquery1);	   
		         $num_rows1=$num_rows1-1;
                 
				if($color!="#EBEBEB")
                   $color="#EBEBEB";
				else
                   $color="#FBFBFB";
				if(c_d($result3[date2])!=4) //ź topic �Թ limit
				  { 				
				    print("<tr bgcolor=$color>");
				if(c_d($result3[date2])==1)//��բ��
				  {?>
      <td width="5%" height="20"> 
        <div align="center"><img src="pic/s1.gif" width="22" height="15"></div>
      </td>
      <?}  
				 elseif(c_d($result3[date2])==3)//���ᴧ 
				 {?>
      <td width="5%" height="20"> 
        <div align="center"><img src="pic/s3.gif" width="22" height="15"></div>
      </td>
      <?}
				 elseif(c_d($result3[date2])==2) //�������ͧ  
				 {?>
      <td width="5%" height="20"> 
        <div align="center"><img src="pic/s2.gif" width="22" height="15"></div>
      </td>
      <?}
			//	 $result[topic]=ereg_replace("&nbsp;"," ",$result[topic]);
			 
				 //$result[topic]=ereg_replace("&nbsp;"," ",$result[topic]);
			 	 //$result[topic]=ereg_replace("<br>","#",$result[topic]);
				 //$result[topic]=wordwrap($result[topic],55,'<br>',1);
			     
				 //$result[topic]=ereg_replace(" ","&nbsp;",$result[topic]);
			 	 //$result[topic]=ereg_replace("#","<br>",$result[topic]);
			 
				 
				 print("<td width='11%' height='20' align=center class=info><font  color='#006DA2'>$result[date1]</font></td>");
                  print("<td width='45%' height='20' class=info>&nbsp;<font  color='#006DA2'><a href='topic.php?id2=$result[id]&nameboards=$nameboards' target=_blank> $result[topic]</a></font></td>");
				  print("<td width='23%' height='20' class=info><div align='center'><font  color='#006DA2'>$result[email]</font></div></td>");
				 print(" <td width='4%' height='20' class=info><div align='center'><font  color='#006DA2'>$num_rows1</font></div></td>");
                 print("<td width='12%' height='20' class=info><div align='center'><font  color='#006DA2'>$result[date2]</font></div></td></tr>");
				    }
				 else//ź topic �Թ limit
				  {
				      //źtable �ͧ topic
				       $sql5="drop table $nameboards$result[id]";
		               $dbquery5=mysql_db_query($dbname,$sql5)or die("error4");  
				       
                      //ź record 㹵��ҧ nameboard 
		              $sql6="delete from $nameboards where id='$result[id]'";
		              $dbquery6=mysql_db_query($dbname,$sql6)or die("error9"); 
				  }
				 $c++;
			   } //while1
	?>
    </table>
</td>
</tr>
<br>
<tr class=a> 
    <td valign="top" colspan="2"> 

  <table width="760" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td class=a><? if($prev!=0) print("<a href='$PHP_SELF?page=$prev&nameboards=$nameboards' ><font  color='#006699'>&lt;&lt;</font></a>&nbsp;");?><FONT color="#006699"><b>Page : </b></font>
	<?for($i=1;$i<=$n_page;$i++)
           {
             if($i!=$page)
		       print("<a href='$PHP_SELF?page=$i&nameboards=$nameboards'><font  color='#006699' style='font-size:13px'><b>$i </b></font></a>");
	         else
		       print("<FONT  COLOR='#FF0000' style='font-size:14px'><b>$i </b></FONT>");
           }
if($page!=$n_page)
  print("<a href='$PHP_SELF?page=$next&nameboards=$nameboards' ><font  color='#006699'>&gt;&gt;</font></a>");
//�Դ�ҹ������
     closedb();
?>
 </td>
 </tr>
</table>
<?
}//fileerror==1
else
{
//�Դ�ҹ������
     closedb();
?>
<body bgcolor="#FFFFFF">
<table border=0  width="760" align=left height="640">
  <tr class=a> 
    <td valign="top" height="97" width="414"><img src="images/logo.gif" width="305" height="74"> 
      <font color="#006291" ><b> </b></font></td>
    <td valign="middle" height="97" width="435"><font color="#FF0066" ><b>GROUP</b></font>&nbsp;<font color="#FF0066" ><b> 
      : 
      &nbsp;<?print($nameboards);?>
      </b></font></td>
  </tr>
  <tr class=a> 
 <td valign="top" colspan="2" > 
<div align="center"> 
	 <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>��سҵ�Ǩ�ͺ��Ҵ File �ͧ�س��ͧ����Թ 3M </b></font></font></p>
<p><font class=a><font  color="#FF0000"><b>(��Ң�Ҵ File �ͧ�س�Թ 3M ��õԴ��� admin) </b></font></font></p>
<br>
<br>
<br>

 </div>
<?
}
?>
<table width="760" border="0" cellspacing="0" cellpadding="0">
          <tr class=a>
    <td>&nbsp;</td>
  </tr>
  <tr class=a>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8" class=a>
      <hr align="center" width="550" >
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table> 


</td>
 </tr>
</table>
 <?
  } //����� group
?>
</body>
</html>
<?
}
?>