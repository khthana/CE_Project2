<?session_start();
?>
<html>
<head>
<title>bodys</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<SCRIPT LANGUAGE="JavaScript">

function checkrequired(which) {
var passs=true;
if (document.images) {
for (i=0;i<which.length;i++) {
var tempobj=which.elements[i];
if (tempobj.name.substring(0,10)=="nameboards") {
if (tempobj.selectedIndex==0) {
passs=false;
break;
         }
      }
   }
}
if (!passs) {
alert("��س����͡ Group ���١��ͧ");
return false;
}
else
return true;
}

</script>
</head>
<body bgcolor="#ffffFF">
<table width="630" cellspacing=0 border=0 align=left >
<tr class=a>
<td >

<FORM METHOD=POST ACTION="gwebboard.php" target=_parent onSubmit="return checkrequired(this)">
<INPUT TYPE="hidden" name=idd value=<?print($id[0]);?>>
<table width="630" cellspacing=0 border=1 align=left >
<tr>
<td bordercolor=#3300FF border=1>
<?
include("connect.inc.php");
$dbname=gwebboard();   
 //��ǹ�ͧ admin group
			//��Ǩ�ͺemail&pass�������㹵��ҧ user  ����� admin ������������
            $sql1="select * from user,admin where user.email ='$id[0]'  and user.own='admin' and admin.email=user.email";
	        $dbquery1=mysql_db_query($dbname,$sql1)or die("error");
	        $num_rows1=mysql_num_rows($dbquery1);
             $result1=mysql_fetch_array($dbquery1);
			
			 //��ǹ�ͧ user group
			 //��Ǩ�ͺemail&pass�������㹵��ҧ user  ����� userboard ������������
		     $sql2="select * from user,userboard where user.email ='$id[0]'  and user.own='user' and userboard.email=user.email and user.name!=''";
		     $dbquery2=mysql_db_query($dbname,$sql2)or die("error");
		     $num_rows2=mysql_num_rows($dbquery2);
if($num_rows1>0)
{
?>
	  <table width="630" cellspacing=0 border=1 align=center>
        <tr bgcolor=#391E8C > 
          <td height=15 align=center colspan=3 bgcolor="#330099"><font class=a>��ǹ����� Admin �ͧ Group</font></td>
        </tr>
        <tr bgcolor=#FfFfFF > 
          <td align=center>
            <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0>
              <tr height='2%' class=A bgcolor=#F0F0FF> 
                <td width="145" valign="middle" height="40" class=a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>���� 
                  Group </b></font></td>
                <td width="177" valign="middle" height="40" bgcolor="#F1F1F1" class=A> 
                  <div align="center"><a href="gwebboard.php?nameboards=<?print($result1[nameboard]);?>" target=_parent class=namepe target=_blank><?print($result1[nameboard]);?></a></div>
                </td>
                <td width="73" valign="middle" height="40" bgcolor="#F0F0FF" class=A align=center><font color=#0000FF><b>ʶҹ�</b></font></td>
                <td width="255" valign="middle" height="40" bgcolor="#F1F1F1" class=namepe align=center><? if($result1[num]==1)      //��ǹ�ͧ admin group
			                                                                                                                                                                                        print("<font color=#FF0000>Group Webboard �ա������¹�ŧ</font>");
																																																 else
																																																	print("<font color=#FF9900>Group Webboard ����ա������¹�ŧ</font>");?>
			  </td>
              </tr>
              <tr height='2%' class=A bgcolor=#F0F0FF> 
                <td width="145" valign=middle height="40" class=a bgcolor="#F0F0FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>������Ҫԡ 
                  Group</b></font></td>
                <td width="177" valign="middle" height="40" bgcolor="#F1F1F1" class=A> 
                  <div align="center"><a href="adduser.php?nameboards=<?print($result1[nameboard]);?>" class=namepe target=body>Add 
                    Member</a></div>
                </td>
                <td width="73" valign="middle" height="40" bgcolor="#F0F0FF" class=A align=center><font color=#0000FF><b>ʶҹ�</b></font></td>
                <td width="255" valign="middle" height="40" bgcolor="#F1F1F1" class=A align=center><?//��������� request ���������
																																																	$sql3="select * from user where request ='$result1[nameboard]'";
																																								                                  	$dbquery3=mysql_db_query($dbname,$sql3) or die("error");
																																								                                	$num_rows3=mysql_num_rows($dbquery3);
																																																		 if($num_rows3>0)      //��ǹ�ͧ admin group
																																																			print("<font color=#FF0000>�ռ���� request</font>");
																																																        else
																																																	        print("<font color=#FF9900>����ռ���� request</font>");?>
			</td>
              </tr>
            
               <tr height='2%' class=A bgcolor=#F0F0FF> 
                <td width="145" valign=middle height="40" class=a bgcolor="#F0F0FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>ź��Ҫԡ 
                  Group</b></font></td>
                <td valign="middle" height="40" bgcolor="#F1F1F1" class=A > 
                  <div align="center"><a href="deluser.php?nameboards=<?print($result1[nameboard]);?>" class=namepe target=body>Delete Member</a></div>
                </td>
               <td width="73" valign="middle" height="40" bgcolor="#F1F1F1" class=A align=center>&nbsp;</td>
                <td width="255" valign="middle" height="40" bgcolor="#F1F1F1" class=A align=center>&nbsp;</td> 
			   </tr>
          
		       <tr height='2%' class=A bgcolor=#F0F0FF> 
                <td width="145" valign=middle height="40" class=a bgcolor="#F0F0FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>�ʴ���Ҫԡ 
                  Group </b></font></td>
                <td valign="middle" height="40" bgcolor="#F1F1F1" class=A> 
                  <div align="center"><a href="gwebboard.php?nameboards=<?print($result1[nameboard]);?>&select=3" class=namepe target=_parent>Show 
                    Member</a></div>
                </td>
               <td width="73" valign="middle" height="40" bgcolor="#F1F1F1" class=A align=center>&nbsp;</td>
                <td width="255" valign="middle" height="40" bgcolor="#F1F1F1" class=A align=center>&nbsp;</td> 
			   </tr>	   
			   
	      </table>
        </td>
		  </tr>
      </table>
<?
}
if($num_rows2>0)
{
?> 
    <table width="630" cellspacing=0 border=1 align=center>
        <tr bgcolor=#391E8C > 
          <td height=15 align=center colspan=3 bgcolor="#330099"><font class=a>��ǹ����� User �ͧ Group</font></td>
      <tr bgcolor=#FfFfFF > 
          <td align=center>
              <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0>
                <tr height='2%' class=A bgcolor=#F0F0FF> 
                  <td width="150" valign="middle" height="40" class=a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>���� 
                    Group </b></font></td>
                  <td width="206" valign="middle" height="40" bgcolor="#F1F1F1" class=A> 
                    <div align="center"> 
                        <select name="nameboards" >
                          <option  selected>====Group==== 
                          <?$c=0;
									while($c<$num_rows2) 
									{
			                             $result2=mysql_fetch_array($dbquery2);  						    
										print("<option >$result2[nameboard] ");  
								        $c++;  
									}	
							print("</select>");
                            print("</div>");
						       ?>
                  </td>
                  <td width="274" valign="middle" height="40" bgcolor="#F1F1F1" class=A>&nbsp;</td>
                </tr>
                <tr height='2%' class=A bgcolor=#F0F0FF> 
                  <td width="150" valign=middle height="40" class=a bgcolor="#F0F0FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>����� 
                    Group</b></font></td>
                  <td width="206" valign="middle" height="40" bgcolor="#F1F1F1" class=A> 
                    <div align="center"> 
                      <input type="radio" name="select" value="1" checked>
                    </div>
                  </td>
                  <td width="274" valign="middle" height="40" bgcolor="#F1F1F1" class=A>&nbsp;</td>
                </tr>
                <tr height='2%' class=A bgcolor=#F0F0FF> 
                  <td width="150" valign=middle height="40" class=a bgcolor="#F0F0FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>¡��ԡ����� 
                    Group</b></font></td>
                  <td valign="middle" height="40" bgcolor="#F1F1F1" class=A width="206" > 
                    <div align="center"> 
                      <input type="radio" name="select" value="2">
                    </div>
                  </td>
                  <td valign="middle" height="40" bgcolor="#F1F1F1" class=A width="274" >&nbsp;</td>
                </tr>
                <tr height='2%' class=A bgcolor=#F0F0FF> 
                  <td width="150" valign=middle height="40" class=a bgcolor="#F0F0FF">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=#0000FF><b>�ʴ���Ҫԡ 
                    Group </b></font></td>
                  <td valign="middle" height="40" bgcolor="#F1F1F1" class=A width="206"> 
                    <div align="center"> 
                      <input type="radio" name="select" value="3">
                    </div>
                  </td>
                  <td valign="middle" height="40" bgcolor="#F1F1F1" class=A width="274">&nbsp;</td>
                </tr>
                <tr height='2%'  bgcolor=#FfFfFF align=center> 
                  <td align=center width="150" valign=middle height="40"  bgcolor="#FfFfFF" > 
                    <div align="center"> &nbsp;&nbsp; </div>
                  </td>
                  <td align=center width="206" valign=middle height="40"  bgcolor="#FfFfFF" > 
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>&nbsp;&nbsp;
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancel>
                  </td>
                  <td align=center width="274" valign=middle height="40"  bgcolor="#FfFfFF" >&nbsp;</td>
                </tr>
              </table>
        </td>
		  </tr>
      </table>
    
<?
}
    //�Դ�ҹ������
     closedb();
 ?>
   </td>  
  </tr>
 </table>
</FORM>
</td>
</tr>
 <tr class=a>
 <td class=a>
 <br>
 <table width="635" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class=a> 
            <div align="center"><font color="#000080">Department of Computer Engineering 
              Faculty of Engineering King Mongkut's Institute of Technology<br>
              Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
          </td>
        </tr>
        <tr> 
          <td height="8"> 
            <hr align="center" width="550" size="2">
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center"></div>
          </td>
        </tr>
      </table>

   </td>  
  </tr>
 </table>
</body>
</html>