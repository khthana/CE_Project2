<?
			session_start();
?>
<html>
<head>
<title>ź�������Ҩ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr>
    <td width="10" >&nbsp;</td>
    <td width="10" bgcolor="#D2F8FD" >&nbsp;</td>
    <td width="160" bgcolor="#D2F8FD" valign="top" ><font face="Tahoma, Microsoft Sans Serif" size="2" color="#9900CC"><br>
      </font><font face="Tahoma, Microsoft Sans Serif" size="2" color="#9900CC"><a href="teacher_insert.php">�����������Ҩ����</a><br>
      <a href="teacher_show_update.php">��䢢������Ҩ����</a><br>
      ź�������Ҩ����<br>
	  	   <a href='teacher_select.php' >���͡���˹��Ҩ����</a><br>
      <a href='teacher_show.php'>�ʴ��������Ҩ����</a><br>
       <a href="teacher_show_delete.php">��Ѻ˹����ѡ </a></font>
      <br>
      </td>
    <td width="594" valign="top"> 
<?
  if ($user[1]== 'administrator')
{
include ("connect_home.inc.php");
}
		  		$query_select = "Select * From $Officertable Where ID ='$id'  AND Status = '$user[4]' ";
					$result_select = mysql_query($query_select);
					$snumber = mysql_numrows($result_select);
					$si=0;
						if ($si < $snumber)
						{
							while ($row = mysql_fetch_array($result_select))
								{
								$id = $row[ID];
									$show_order = $row[Show_order];
								$last_update = htmlspecialchars($row[Last_update]);
								$user_name = htmlspecialchars($row[Username]);
								$passwd = htmlspecialchars($row[Password]);
								$picture = htmlspecialchars($row[Picture]);
								$name = htmlspecialchars($row[Name]);
								$email = htmlspecialchars($row[Email]);
								$level = htmlspecialchars($row[Level]);
								$graduation = $row[Graduation];
								$research = $row[Research];
								$course = $row[Course];
								$meeting = $row[Meeting];
								$interest = $row[Interest];
								$experience = $row[Experience];
								$address = $row[Address];
								$telephone = htmlspecialchars($row[Telephone]);
								$tlink = htmlspecialchars($row[Tlink]);
								$bachelor = htmlspecialchars($row[Bachelor]);
								$master = htmlspecialchars($row[Master]);
								$doctor = htmlspecialchars($row[Doctor]);
								}
						}
	echo "
	<table width='580' border='0' cellspacing='1' cellpadding='3' align='center' bordercolor='#FFFFFF' height='164'>
  <tr valign='middle'> 
    <td colspan='4' height='35' bgcolor='#F7F7F7' > 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�����Ţͧ�Ҩ�����Ш��Ҥ�Ԫ����ǡ�������������</font></div>
    </td>
  </tr>
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='17'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�ӴѺ���</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='17' colspan='2'> 
      <div align='left'><font face='Tahoma, Microsoft Sans Serif' size='2'>$show_order</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='95' rowspan='4' width='157'> 
      <div align='center'><img src='Picture_teacher_$id/$picture' width='130' align='middle'></div>
    </td>
  </tr>
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='17'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;</font><font size='2' face='Tahoma, Microsoft Sans Serif'>��䢤����ش����</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='17' colspan='2'> 
      <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>$last_update</font> 
      </div>
    </td>
  </tr>
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='17'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;������͡�Թ</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='17' colspan='2'> 
      <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>$user_name 
        </font></div>
    </td>
  </tr>
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='17'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;</font><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>����-���ʡ��</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='17' colspan='2'><font size='2' face='Tahoma, Microsoft Sans Serif'>$name</font></td>
  </tr>
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='30'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;Email-Address</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='30' colspan='2'> 
      <div align='left'><font face='Tahoma, Microsoft Sans Serif' size='2'><A HREF='mailto:$email'>$email 
        </A></font></div>
    </td>
    <td bgcolor='#D2F8FD' height='30' width='157'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
        <input type='text' name='textfield' value='$picture' readonly size='20'>
        </font> </div>
    </td>
  </tr>
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='30'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;���˹�/˹�ҷ��</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$level</font></td>
  </tr>				  
  <tr> 
    <td width='168' bgcolor='#F7F7F7' height='30'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif'><font face='Tahoma, Microsoft Sans Serif'><font face='Tahoma, Microsoft Sans Serif' size='2'>�͹��дѺ</font><font size='2'></font></font></font></div>
    </td>
    <td bgcolor='#D2F8FD' height='30' colspan='3'><div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;";
								if ($bachelor =='��ԭ�ҵ��')
									{
									echo"<IMG SRC='images/check.gif' WIDTH='17' HEIGHT='18' align='middle'>&nbsp;��ԭ�ҵ�� &nbsp; &nbsp; ";
									}
								if ($bachelor !='��ԭ�ҵ��')
									{
									echo"<IMG SRC='images/uncheck.gif' WIDTH='17' HEIGHT='18' align='middle'>&nbsp;��ԭ�ҵ�� &nbsp; &nbsp; ";
									}
								if ($master == '��ԭ���')
									{
									echo "<IMG SRC='images/check.gif' WIDTH='17' HEIGHT='18' align='middle'>&nbsp;��ԭ��� &nbsp; &nbsp;  ";
									}
								if ($master != '��ԭ���')
									{
										echo "<IMG SRC='images/uncheck.gif' WIDTH='17' HEIGHT='18' align='middle'>&nbsp;��ԭ��� &nbsp; &nbsp; ";
									}
								if ($doctor == '��ԭ���͡')
									{
									echo "<IMG SRC='images/check.gif' WIDTH='17' HEIGHT='18' align='middle'>&nbsp;��ԭ���͡</font></div>";
									}
								if ($doctor != '��ԭ���͡')
									{
									echo "<IMG SRC='images/uncheck.gif' WIDTH='17' HEIGHT='18' align='middle'>&nbsp;��ԭ���͡</font></div>";
									}
								echo"</div></td></tr>
										 <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�ԧ����ǹ���</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp; 
							  &nbsp;";	
								$link = explode(",",$tlink);
								$co = strlen($link);
								for($l = 0;$l<=$co;$l++)
							{
									if ($l == 0)
								{
										echo "<A HREF='http://$link[$l]'>$link[$l]</A>";
								}
								else
									if ($link [ $l] != '')
								{
									   echo ",<A HREF='http://$link[$l]'>$link[$l]</A>";
								}
							}
						echo " 
						</font></td</tr>
						  <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;�س�ز� �Ң��Ԫ� 
								ʶҹ����֡��</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$graduation 
							  </font></td>
						  </tr>
						  <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;�ŧҹ�ҧ�Ԫҡ��</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$research</font></td>
						  </tr>
						  <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'> &nbsp; ���ҧ�͹</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$course 
							  </font></td>
						  </tr>
						  <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���Ҿ����Ե</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$meeting</font></td>
						  </tr>
							<tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>����ʹ�</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$interest</font></td>
						  </tr>
							  <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���ʺ��ó�����</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$experience</font></td>
						  </tr>
								<tr> 
								<td width='168' bgcolor='#F7F7F7' height='30'> 
								  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�������Ѿ��</font></div>
								</td>
								<td bgcolor='#D2F8FD' height='30' colspan='3'><font size='2' face='Tahoma, Microsoft Sans Serif'>$telephone</font></td>
							  </tr>
						  <tr> 
							<td width='168' bgcolor='#F7F7F7' height='30'> 
							  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�������Դ���</font></div>
							</td>
							<td bgcolor='#D2F8FD' height='30' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>$address</font></td>
						  </tr>
    <tr valign='bottom'> 
	<form name='form1' method='post' action='delete_teacher.php'>
	<td width='168' bgcolor='#F7F7F7' height='30'>&nbsp;</td>
	   	   <input type='hidden' name='id' value='$id'>
   	   <input type='hidden' name='picture' value='$picture'>
	    <td bgcolor='#D2F8FD' height='30'  width='180'> 
      <div align='right'>
        <input type='submit' name='Submit1' value='ź������'>
        &nbsp </div>
    </td>
	</form>
	<form name='form2' method='post' action='teacher_show_delete.php'>
    <td bgcolor='#D2F8FD' height='30' colspan='2'>&nbsp; 
      <input type='submit' name='Submit2' value=' ¡��ԡ '>
    </td>
	</form>
  </tr>
    </table>";
?>
    </td>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
