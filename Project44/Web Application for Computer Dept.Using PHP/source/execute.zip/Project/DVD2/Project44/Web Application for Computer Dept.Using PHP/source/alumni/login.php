<?php
	session_start();
	session_destroy();
	session_unset();
	session_register("mem");
	$mem[id1]=session_id();
//	print "$mem[id]";
include("md5.js");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><img src="image/logo-kmitl.jpg" width="139" height="137"></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="137">
                <tr> 
                  <td><img src="image/logo-alumni.jpg" width="600" height="80"></td>
                </tr>
                <tr> 
                  <td>
                    <table width="100%" border="0" cellspacing="1" cellpadding="1"align="left" bordercolor="#000000" bgcolor="#000000">
                      <tr class = BNFont1 align="center"> 
                        <td bgcolor="#99CCFF" width="25%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="index.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Home</font></b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="register_form.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">ŧ����¹</font></b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="login.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��䢢�����</font></b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td>
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="normal.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�Ҥ����</font></b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="cont.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="cont.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�Ҥ������ͧ</font></b></a></font> 
                        </td>
                      </tr>
                      <tr>
                        <td width="20" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                        <td width="78%" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        
                          <td bgcolor="#CCCCFF" height="15"> 
                            <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1" color="#FFFFFF" class="fsize8" align="center"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">&nbsp;<font color="#000000" size="2">����</font></font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                  </div>
                                </td>
                              </tr>
                            </table>
                          </td>
                        
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624" valign="top"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                <tr>
                  <td>
                    <div align="center"><font 
                  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" 
                  color=#006699 size=4><b><img 
                  src="image/edit.jpg" 
                  width=200 height=40 align="top"></b></font> 
                      <hr width="80%">
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <form name=weblogin onSubmit="return check()" 
                  action=edit_register.php method=post autocomplete="off">
                      <table cellspacing=0 cellpadding=0 width="35%" align=center 
                  border=0>
                        <tbody> 
                        <tr> 
                          <td bgcolor=#99ccff height=30> 
                            <div align=center><font 
                        face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><b><font 
                        size=3>Login</font></b></font></div>
                          </td>
                        </tr>
                        <tr valign=top bgcolor=#ccffff> 
                          <td height=45> 
                            <table cellspacing=1 cellpadding=4 width="100%" 
                        bgcolor=#ccccff border=0>
                              <tbody> 
                              <tr> 
                                <td width="31%" bgcolor=#ccccff> 
                                  <div align=right><font 
                              face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" 
                              size=1>Username</font></div>
                                </td>
                                <td width="69%" bgcolor=#ccccff><font 
                              face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                                  <input 
                              maxlength=20 size=15 name=name>
                                  </font></td>
                              </tr>
                              <tr> 
                                <td width="31%" bgcolor=#ccccff> 
                                  <div align=right><font 
                              face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" 
                              size=1>Password</font></div>
                                </td>
                                <td width="69%" bgcolor=#ccccff><font 
                              face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                                  <input 
                              type=password maxlength=20 size=15 name=pwd>
                                  </font></td>
                              </tr>
                              </tbody>
                            </table>
                          </td>
                        </tr>
                        <tr valign=bottom> 
                          <td valign=center bgcolor=#ccccff height=35> 
                            <div align=center><font 
                        face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                              <input type=submit value=Login name=Submit>
                              <!--	<input type="hidden" name="namecode1" value="">-->
                              <input 
                        type=hidden value=18289 name=challenge>
                              <input 
                        type=hidden name=codeedit>
                              <input type=reset value=¡��ԡ name=Submit2>
                              </font></div>
                          </td>
                        </tr>
                        </tbody>
                      </table>
                      <p align=center><font 
                  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" 
                  size=3><a 
                  href="re_pwd.php">������ʼ�ҹ</a></font> </p>
                      <hr width="80%">
                    </form>
                  </td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>

  <div align="center"> </div>
 </center>
 <script language="JavaScript">
<!--
function checks()
{
      var v1 = document.SearchForm.search.value;
        if ( v1.length==0)
           {
           alert("��سһ�͹�ӷ���ͧ��ä���");
           document.SearchForm.search.focus();
           return false;
           }
		 else
           return true;
}
function check()
{
	  var v1 = document.weblogin.name.value;
      var v2 = document.weblogin.pwd.value;
   
	  
        if ( v1.length==0)
           {
           alert("��سһ�͹ Username");
           document.weblogin.name.focus();           
           return false;
           }
        else if (v2.length==0)
           {
           alert("��سһ�͹ Password");
           document.weblogin.pwd.focus();           
		   return false;
           }
        else
           return hash(weblogin,'edit_register.php');
}
//-->
</script>

</body>
</html>
