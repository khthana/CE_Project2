<html>
<head>
<title>�ʴ�����������Ԫ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="../script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #9900CC; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont"> 
    <td width="10"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="772" border="0" cellspacing="0" cellpadding="0" align="center">
  <?
	include ("connect_course.inc.php");
echo "
   <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='130' bgcolor='#D2F8FD' valign='top' ><font size='2' face='Tahoma, Microsoft Sans Serif'><br>
      <a href='index.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='structure.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
     <a href='tendency.php?course_year=$course_year'> Ἱ����֡��</a><br>
      <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
	&nbsp;</td>
  	<td width='10' valign='top' >&nbsp; </td>
    <td width='609' valign='top' >
	<table width='100%' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
       <tr> 
          <td height='54' colspan='11' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵ��ѳ�Ե 
              �Ң��Ԫ����ǡ������������� <br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp; </font></div>
          </td>
        </tr>";
   	$query_group = "Select * From $Categorytable,$Gsubjecttable Where $Categorytable.Course_year  =  '$course_year' AND $Gsubjecttable.Course_year  =  '$course_year' AND $Categorytable.Category  =  '$category' AND $Gsubjecttable.Category  =  '$category' AND $Gsubjecttable.Gsubject  =  '$gsubject' ";
	$result_group = mysql_query($query_group);
	$gnumber = mysql_numrows($result_group);
	$gi=0;
	if ($gi < $gnumber) 
	{
	//echo "	<table width='100%' cellspacing='0' cellpadding='0' align='center' border='1' bordercolor='#FFFFFF'>";
	while ($row = mysql_fetch_array($result_group))
		{
	$category = htmlspecialchars($row[Category]);
	$cprogram1_unit = htmlspecialchars($row[Cprogram1_unit]);
	$cprogram2_unit = htmlspecialchars($row[Cprogram2_unit]);
	$gsubject = htmlspecialchars($row[Gsubject]);
	$gprogram1_unit = htmlspecialchars($row[Gprogram1_unit]);
	$gprogram2_unit = htmlspecialchars($row[Gprogram2_unit]);
	$gdetail = $row[Gdetail];
	$gdetail = eregi_replace('<br>',chr(13),$row[Gdetail]);
	echo "
	<tr bgcolor='#F7F7F7'> 
    <td width='5'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
    <td width='167'>&nbsp;</td>
    <td width='153'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>���������֡�ҷ�� 1</b></font></div>
    </td>
    <td width='153'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>���������֡�ҷ�� 2</b></font></div>
    </td>
    <td width='144'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
  </tr>
  <tr bgcolor='#F7F7F7'> 
    <td colspan='2'><b><font face='Tahoma, Microsoft Sans Serif' size='2'>$category</font></b></td>
    <td width='153' bgcolor= '#D2F8FD'> 
      <div align='center'><b><font face='Tahoma, Microsoft Sans Serif' size='2'>$cprogram1_unit ˹��¡Ե</font></b></div>
    </td>
    <td width='153' bgcolor= '#D2F8FD'> 
      <div align='center'><b><font face='Tahoma, Microsoft Sans Serif' size='2'>$cprogram2_unit ˹��¡Ե</font></b></div>
    </td>
    <td width='144' bgcolor= '#D2F8FD'><b><font face='Tahoma, Microsoft Sans Serif' size='2'></font></b></td>
  </tr>
  <tr> 
    <td width='5' bgcolor='#F7F7F7'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
    <td width='167' bgcolor='#F7F7F7'><font face='Tahoma, Microsoft Sans Serif' size='2'>$gsubject</font> 
    </td>
    <td bgcolor= '#D2F8FD' width='153'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$gprogram1_unit ˹��¡Ե</font></div>
    </td>
    <td bgcolor= '#D2F8FD' width='153'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$gprogram2_unit ˹��¡Ե</font></div>
    </td>
    <td bgcolor='#D2F8FD' width='144'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
  </tr>
  <tr> 
    <td width='5' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
    <td colspan='3' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$gdetail&nbsp; 
      </font></td>
    <td width='144' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>˹��¡Ե(������-��Ժѵ�)</font></div>
    </td>
  </tr>";
		$query = "Select * From $Subjecttable Where Gsubject = '$gsubject' AND Course_year  =  '$course_year'  order by Code";
		$result = mysql_query($query); 
        $number = mysql_numrows($result);
		$i=0; 
		if ($i < $number)
		{
			while ($row  = mysql_fetch_array($result)) 
			{
			$code = htmlspecialchars($row[Code]); 
			$name = htmlspecialchars($row[Name]);
			$ename = htmlspecialchars($row[Ename]); 
			$unit = htmlspecialchars($row[Unit]); 
			$unit_detail = htmlspecialchars($row[Unit_detail]); 
			$unit_operation = htmlspecialchars($row[Unit_operation]); 
		echo "
	<tr bgcolor='#D2F8FD'> 
    <td width='5' height='20'><font face='Tahoma, Microsoft Sans Serif' size='2'></font> 
      <div align='center'></div>
      <div align='center'></div>
      <div align='right'></div>
    </td>
    <td width='167' height='20'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$code</font></div>
    </td>
    <td colspan='2' height='20'><font face='Tahoma, Microsoft Sans Serif' size='2'><a href='show_subject.php?code=$code&&course_year=$course_year'>$name</a></font> 
    </td>
    <td width='144' height='20'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$unit ($unit_detail-$unit_operation)</font></div>
    </td>
  </tr>
  <tr bgcolor='#D2F8FD'> 
    <td width='5' height='20'><font face='Tahoma, Microsoft Sans Serif' size='2'></font><font face='Tahoma, Microsoft Sans Serif' size='2'></font> 
      <div align='center'></div>
    </td>
    <td width='167' height='20'>&nbsp;</td>
    <td colspan='2' height='20'><font face='Tahoma, Microsoft Sans Serif' size='2'>$ename</font></td>
    <td width='144' height='20'> 
      <div align='center'></div>
    </td>
  </tr>";
			}//end while of select subject;
		}//end if of select subject;
		else { 
		 echo"
			<tr> 
			<td colspan='7' bgcolor='#F7F7F7'>
			<div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>����բ���������Ԫ�</font></div>
			</td>
			</tr>";
				}//end else if of select subject;
		}//end while of select group;
		echo "
	 <tr bgcolor='#F7F7F7'> 
    <td width='5'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;</font></td>
    <td colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;</font> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif'  size='2'>&nbsp;</font></div>
    </td>
    <td width='144'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></div>
    </td>
  </tr>";
		}//end if of select group;
	mysql_free_result($result);
	MYSQL_CLOSE();
?>
</table>
</td>
</tr></table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
