<html>
<head>
<title>����ç���ҧ��ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
	<tr> 
    <td width='11'  >&nbsp;</td>
    <td width='14' bgcolor='#DAEEFE'  >&nbsp;</td>
    <td width='134' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_insert.php'>��ѡ�ٵû�ԭ���</a><br>
     <a href='structure_insert_course.php'> �ç���ҧ��ѡ�ٵ�</a><br>
     �����ç���ҧ����<br>
      <a href='insert_category.php'>������Ǵ�Ԫ�����</a><br>
      <a href='select_course_group.php'>�����Ң��Ԫ����� </a><br>
      <a href='Master/Insert/Subject/select_course.php' >��������Ԫ����� </a><br>
      <a href='Master/Insert/Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a><br>
      <a href='index.php'>��Ѻ˹����ѡ </a> <br>
      </font></td>
    <td width='619' valign='top' > 
	$query_structure = "Select * From $Structuretable Where Course_year  =  '$course_year' ";
	$result_structure = mysql_query($query_structure);
	$number_structure = mysql_numrows($result_structure);
	if ($number_structure > 0)
		{
			while ($row  = mysql_fetch_array($result_structure)) 
			{
			$unit_sum_all = htmlspecialchars($row[Unit_sum_all]); 
			$program1_unit = htmlspecialchars($row[Program1_unit]); 
			$program2_unit = htmlspecialchars($row[Program2_unit]); 
			$detail = $row[Detail];
			}
		}
echo"
	<form name='form1' method='post' action='structure_insert_category.php'>
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF' >
          <tr bgcolor='#F7F7F7'> 
            <td height='123' colspan='5'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font size='2' face='Tahoma'></font><font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵ���Һѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year <br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ <br>
                &nbsp; </font></div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td height='30' colspan='5'><font size='2' face='Tahoma'><b>14. ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr bgcolor='#DAEEFE'> 
            <td height='30' colspan='4' bgcolor='#F7F7F7'><font size='2'><font size='2'><font face='Tahoma'><b>14.1 
              �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font></font></font></td>
            <td height='30' width='8' bgcolor='#F7F7F7' rowspan='2'>&nbsp;</td>
          </tr>
          <tr bgcolor='#DAEEFE'> 
            <td height='30' width='24' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='30' colspan='3'><font size='2' face='Tahoma'>�ӹǹ˹��¡Ե��ʹ��ѡ�ٵ÷����������¡��� 
              &nbsp;$unit_sum_all &nbsp;˹��¡Ե </font></td>
          </tr>
          <tr> 
            <td height='30' colspan='5' bgcolor='#F7F7F7'> 
              <div align='left'><font size='2'><font size='2'><font face='Tahoma'><b>14.2 
                �ç���ҧ��ѡ�ٵ� </b></font></font></font></div>
            </td>
          </tr>
          <tr> 
            <td height='11' width='24' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='30' colspan='3' bgcolor='#DAEEFE'> 
              <div align='left'><font size='2' face='Tahoma'><b>&nbsp;- Ἱ �1 
                (Research 1)</b></font><b><font size='2' face='Tahoma' color='#0000FF'> 
                </font></b><font size='2' face='Tahoma'>��Ἱ����֡�ҷ���鹡���Ԩ�����ա�÷��Է�ҹԾ�������ѡ</font></div>
            </td>
            <td height='11' width='8' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          "; $query_1 = "Select * From $Structure_coursetable Where Course_year 
          = '$course_year' AND Type ='Ἱ �1'"; $result_1 = mysql_query($query_1); 
          $number_1 = mysql_numrows($result_1); if ($number_1 > 0) { while ($row 
          = mysql_fetch_array($result_1)) { $category1 = htmlspecialchars($row[Category]); 
          $query_c = "Select Cprogram_unit From $Categorytable Where Course_year 
          = '$course_year' AND Category = '$category1' "; $result_c = mysql_query($query_c); 
          $row = mysql_fetch_array($result_c); $cprogram1_unit = htmlspecialchars($row[Cprogram_unit]); 
          echo " 
          <tr> 
            <td height='0' width='24' bgcolor='#F7F7F7'> 
              <div align="center">
                <input type="checkbox" name="checkbox" value="select1[$i]">
              </div>
            </td>
            <td height='30' width='272' bgcolor='#DAEEFE'> &nbsp;<font face='Tahoma' size='2'>$category1</font></td>
            <td height='30' width='205' bgcolor='#DAEEFE'> 
              <div align='center'><font size='2' face='Tahoma'>$cprogram1_unit&nbsp;&nbsp;&nbsp;&nbsp; 
                ˹��¡Ե </font></div>
            </td>
            <td height='30' width='79' bgcolor='#DAEEFE'> 
              <div align='center'></div>
            </td>
            <td height='0' width='8' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          "; } } echo " 
          <tr> 
            <td height='30' width='24' bgcolor='#F7F7F7'>&nbsp; </td>
            <td height='30' width='272' bgcolor='#DAEEFE'><font size='2' face='Tahoma'>&nbsp;<b>�ӹǹ˹��¡Ե��ʹ��ѡ�ٵ�</b></font></td>
            <td height='30' width='205' bgcolor='#DAEEFE'> 
              <div align='center'><font size='2' face='Tahoma'><b>$program1_unit</b>&nbsp;&nbsp;&nbsp;&nbsp; 
                <b>˹��¡Ե </b></font></div>
            </td>
            <td height='30' width='79' bgcolor='#DAEEFE'>&nbsp;</td>
            <td height='30' width='8' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='4' width='24' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
            <td height='30' colspan='3' bgcolor='#DAEEFE'> 
              <div align='left'><font size='2' face='Tahoma'><b>&nbsp;- Ἱ �2 
                (Research 2)</b></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'> 
                ��Ἱ����֡�ҷ���鹡���Ԩ�����ա�÷��Է�ҹԾ�����С���֡������Ԫ�</font></div>
            </td>
            <td height='4' width='8' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          "; $query_2 = "Select * From $Structure_coursetable Where Course_year 
          = '$course_year' AND Type ='Ἱ �2'"; $result_2 = mysql_query($query_2); 
          $number_2 = mysql_numrows($result_2); if ($number_2 > 0) { while ($row 
          = mysql_fetch_array($result_2)) { $category2 = htmlspecialchars($row[Category]); 
          $query_c = "Select Cprogram_unit From $Categorytable Where Course_year 
          = '$course_year' AND Category = '$category2' "; $result_c = mysql_query($query_c); 
          $row = mysql_fetch_array($result_c); $cprogram2_unit = htmlspecialchars($row[Cprogram_unit]); 
          echo " 
          <tr> 
            <td height='4' width='24' bgcolor='#F7F7F7'> 
              <div align="center">
                <input type="checkbox" name="checkbox2" value="select2[$i]">
              </div>
            </td>
            <td height='30' bgcolor='#DAEEFE' width="272">&nbsp;<font face='Tahoma' size='2'>$category2</font></td>
            <td height='30' bgcolor='#DAEEFE' width="205"> 
              <div align='center'><font size='2' face='Tahoma'>$cprogram2_unit&nbsp;&nbsp;&nbsp;&nbsp; 
                ˹��¡Ե </font></div>
            </td>
            <td height='30' bgcolor='#DAEEFE' width="79">&nbsp;</td>
            <td height='6' bgcolor='#F7F7F7' width="8">&nbsp;</td>
          </tr>
          "; } } echo " "; echo " 
          <tr> 
            <td height='30' width='24' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='30' width='272' bgcolor='#DAEEFE'> <font size='2' face='Tahoma'><b>&nbsp;�ӹǹ˹��¡Ե��ʹ��ѡ�ٵ�</b></font></td>
            <td height='30' width='205' bgcolor='#DAEEFE'> 
              <div align='center'><font size='2' face='Tahoma'><b>$program2_unit</b>&nbsp;&nbsp;&nbsp;&nbsp; 
                <b>˹��¡Ե</b> </font></div>
            </td>
            <td height='30' width='79' bgcolor='#DAEEFE'> 
              <div align='center'><font face='Tahoma' size='2'> </font></div>
            </td>
            <td height='30' bgcolor='#F7F7F7' width="8">&nbsp;</td>
          </tr>
          <tr> 
            <td height='30' colspan='4' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>��͸Ժ������˵ؼŷ��е�ͧ�֡���Ԫҵ�ҧ� 
              �մѧ��� </b></font></td>
            <td height='50' rowspan='2' bgcolor='#F7F7F7' width="8">&nbsp;</td>
          </tr>
          <tr> 
            <td height='20' width='24' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='20' colspan='3' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$detail</font> 
            </td>
          </tr>
          <tr> 
            <td height='42' colspan='5' bgcolor='#F7F7F7'> 
              <div align='center'> </div>
              <div align='center'> 
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
                <input type='hidden' name='type1' value='Ἱ �1'>
                <input type='hidden' name='type2' value='Ἱ �2'>
                <input type='hidden' name='course_year' value='$course_year'>
              </div>
            </td>
          </tr>
        </table>
	   </form>";
	   ?>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
