<? 
	session_start();
if($id[1]=='teacher')
{
?>
<html>
<head>
<title>stuproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<?
include("connect.inc.php");
$dbname=project();
$sql="select * from topicproject where id='$idtopic'";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");
$result=mysql_fetch_array($dbquery);
?>
<body bgcolor="#FFFFFF">
<table border=0 width='630' align=left>
<tr class=a>
<td align=left class=a>
<font  color="#000000"><b>�����ç�ҹ&nbsp;:&nbsp;</b></font><font color="#000080"><?$result[topic_t]=wordwrap($result[topic_t],60,"<br>\n",1);print($result[topic_t]);?></font>
</td>
</tr>
<?if($result[check]==0)
     {?>
<tr class=a>
<td align=left class=a>
<form action='bodys.php' target=body name=form1>
<INPUT TYPE="hidden" name=select value=4>		
<table width="630" border="1" height="6%" bordercolor="#000000" cellpadding="0" cellspacing="0" align=left>
          <tr height='5%' class=a> 
            <td width="130" bgcolor="#004F9D" > 
              <div align="center"><font class=a>���͡������.�.�ç�ҹ</font></div>
            </td>
            <td width="350" bgcolor="#004F9D" > 
              <div align="center"><font class=a>���͹ѡ�֡��</font></div>
            </td>
            <td width="80" bgcolor="#004F9D" > 
              <div align="center"><font class=a>����</font></div>
            </td>
            <td width="70" bgcolor="#004F9D" > 
              <div align="center"><font class=a>�ô�����</font></div>
            </td>
          </tr>
       <?$sql="select * from stuproject where topicid='$idtopic' order by id asc ";
            $dbquery=mysql_db_query($dbname,$sql)or die("error0");
            
			$g=1;
            while($result1=mysql_fetch_array($dbquery))
			   { 
	             $c=1;
                   while($result[num]>=$c)
			   { 
		           $name=('name'.$c);
				   $code=('code'.$c);
				   $gpa=('gpa'.$c);
		   ?>
		     <tr height='4%'> 
            <td width="130" >   
                  <?if($c==1)
				   {     
			   print("<div align='center'><font class=a>�������� $g</font><input type='radio' name='idstu' value=$result1[id]></div>");
				   }        
		            else
				        {
		         print("<div align='center'>&nbsp;</div>");
			           }
		             ?>
		   </td>
            <td width="350" class=a> 
              <div align="left"><font  color="#000000">&nbsp;<?print($c.'.'.$result1[$name]);?></font></div>
            </td>
            <td width="80" class=a> 
              <div align="center"><font  color="#000000"><?print($result1[$code]);?></font></div>
            </td>
            <td width="70" class=a> 
              <div align="center"><font  color="#000000"><?print($result1[$gpa]);?></font></div>
            </td>
          </tr>
         <? $c++; 
			   }//while
			 $g++;
			  }//while
				  ?>        
                <tr>
               <td colspan=4 align=center>
               <table>
					<tr class=a>
					<td>
				  <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif,Ms Sans Serif', system; font-size: 8pt; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=check>
        &nbsp;&nbsp; 
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif,Ms Sans Serif', system; font-size: 8pt; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=reset>
</td>
</tr>					  
</table>

</td>
</tr>					  
</table>
        
  </form>
<?
  }//check==0
else//check==1
  {
?> 
<tr class=a>
<td align=left class=a> 
<form action='bodys.php' target=body name=form2>
<INPUT TYPE="hidden" name=select value=4>		
<INPUT TYPE="hidden" name=idtopic value='<?print($idtopic);?>'>  
<table width="630" border="1" height="12%" bordercolor="#000000" cellpadding="0" cellspacing="0" align=center>
          <tr height='5%' class=a> 
            <td width="6%" bgcolor="#004F9D" > 
              <div align="center"><font class=a>NO.</font><font face="Tahoma,Ms Sans Serif,Ms Sans Serif" size="2"> 
                </font></div>
            </td>
            <td width="60%" bgcolor="#004F9D" > 
              <div align="center"><font class=a>���͹ѡ�֡���ç�ҹ</font></div>
            </td>
            <td width="15%" bgcolor="#004F9D" > 
              <div align="center"><font class=a>����</font></div>
            </td>
            <td width="13%" bgcolor="#004F9D" > 
              <div align="center"><font class=a>�ô�����</font></div>
            </td>
          </tr>
       <?$sql="select * from stuproject where topicid='$idtopic' ";
            $dbquery=mysql_db_query($dbname,$sql)or die("error1");
            $result1=mysql_fetch_array($dbquery);
		         $c=1;
                   while($result[num]>=$c)
			   { 
		           $name=('name'.$c);
				   $code=('code'.$c);
				   $gpa=('gpa'.$c);
		   ?>
		     <tr height='4%'> 
            <td width="6%" class=a>   
           <?    
		   print("<div align='center'><font  color='#000000'>$c.</font></div>");
		   ?>		  
		   </td>
            <td width="60%" class=a> 
              <div align="left"><font  color="#000000">&nbsp;<?print($result1[$name]);?></font></div>
            </td>
            <td width="15%" class=a> 
              <div align="center"><font  color="#000000"><?print($result1[$code]);?></font></div>
            </td>
            <td width="13%" class=a> 
              <div align="center"><font  color="#000000"><?print($result1[$gpa]);?></font></div>
            </td>
          </tr>
         <? $c++; 
			   }//while
				  ?>
			  </table>
         
           <table>
					<tr class=a>
					<td>
				  <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif,Ms Sans Serif', system; font-size: 8pt; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value='Delete' name=check2>
        &nbsp;&nbsp; 
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif,Ms Sans Serif', system; font-size: 8pt; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=reset>
</td>
</tr>					  
</table>
</form>				  
	
	<?
   }//else check==1
  //�Դ�ҹ������
closedb();
?>
</td>
</tr>					  
</table>

</body>
</html>
<?
}
?>