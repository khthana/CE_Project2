<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="770" border="0" cellpadding="0" cellspacing="0">
          <tr> 
            <td> 
            </td>
          </tr>
          <tr> 
            <td> 
              <form name=question action="to_question.php" method=post onSubmit="return check()"  autocomplete="off">
                <table width="774" border="0" cellpadding="0" cellspacing="0">
                  <tr> 
                    <td> 
                      <table cellspacing=1 cellpadding=2 width="80%" border=0 align="center">
                        <tbody> 
                        <tr class=header bgcolor="#67a6c7"> 
                          <td colspan=2 align=center><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><font size="3" color="#FFFFFF">New 
                            Topic</font></font></td>
                        </tr>
                        <tr class=tablerow> 
                          <td width="18%" bgcolor=#dedfdf align=right><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Name<font color="#FF0000">*</font> 
                            :</font></td>
                          <td bgcolor=#f7f7f7 width="82%"> 
                            <input size=25 name=q_name>
                            <span class=11px> </span> </td>
                        </tr>
                        <tr class=tablerow> 
                          <td bgcolor=#dedfdf align=right width="18%"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Email 
                            :</font></td>
                          <td bgcolor=#f7f7f7 width="82%"> 
                            <input type=text size=25 name=q_email>
                          </td>
                        </tr>
                        <tr class=tablerow> 
                          <td bgcolor=#dedfdf align=right width="18%"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Topic<font color="#FF0000">*</font>:</font></td>
                          <td bgcolor=#f7f7f7 width="82%"> 
                            <input size=40 name=q_topic>
                          </td>
                        </tr>
                        <tr class=tablerow> 
                          <td valign=top bgcolor=#dedfdf align=right height="169" width="18%"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Message<font color="#FF0000">*</font>:<br>
                            </font></td>
                          <td height="169" bgcolor="#f7f7f7" width="82%"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
                            <textarea name=q_message rows=9 cols=80></textarea>
                            </font></td>
                        </tr>
                        </tbody> 
                      </table>
                    </td>
                  </tr>
                  <tr> 
                    <td bgcolor="#FFFFFF"> 
              <div align="center">  
  <a href="javascript:setsmile(':smile:')"><img src="pics/smile.gif" border=0></a>
	<a href="javascript:setsmile(':big:')"><img src="pics/biggrin.gif" border=0></a>
	<a href="javascript:setsmile(':ent:')"><img src="pics/blue.gif" border=0></a>
	<a href="javascript:setsmile(':shy:')"><img src="pics/shy.gif" border=0></a>
	<a href="javascript:setsmile(':sun:')"><img src="pics/sunglasses.gif" border=0></a>
	<a href="javascript:setsmile(':sg:')"><img src="pics/supergrin.gif" border=0></a>
	<a href="javascript:setsmile(':embarass:')"><img src="pics/embarass.gif" 	border=0></a>
	<a href="javascript:setsmile(':dead:')"><img src="pics/dead.gif" border=0></a>
	<a href="javascript:setsmile(':cool:')"><img src="pics/cool.gif" border=0></a>
	<a href="javascript:setsmile(':clown:')"><img src="pics/clown.gif" border=0></a>
	<a href="javascript:setsmile(':pukey:')"><img src="pics/pukey.gif" border=0></a><br>
     <a href="javascript:setsmile(':eek:')"><img src="pics/eek.gif" border=0></a> 
                <a href="javascript:setsmile(':roll:')"><img src="pics/sarcblink.gif" border=0></a> 
                <a href="javascript:setsmile(':smoke:')"><img src="pics/smokin.gif" border=0></a> 
                <a href="javascript:setsmile(':angry:')"><img src="pics/reallymad.gif" border=0></a> 
                <a href="javascript:setsmile(':confused:')"><img src="pics/confused.gif" 	border=0></a> 
                <a href="javascript:setsmile(':cry:')"><img src="pics/crying.gif" border=0></a> 
                <a href="javascript:setsmile(':lol:')"><img src="pics/lol.gif" border=0></a> 
                <a href="javascript:setsmile(':yawn:')"><img src="pics/yawn.gif" border=0></a> 
                <a href="javascript:setsmile(':devil:')"><img src="pics/devil.gif" border=0></a> 
                <a href="javascript:setsmile(':tongue:')"><img src="pics/tongue.gif" border=0></a> 
                <a href="javascript:setsmile(':alien:')"><img src="pics/aysmile.gif" border=0></a> 
                <a href="javascript:setsmile(':tasty:')"><img src="pics/tasty.gif" border=0></a> 
                <a href="javascript:setsmile(':crazy:')"><img src="pics/grazy.gif" border=0></a><br>
    <font color="blue" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��ԡ����ٻ�����á�ٻŧ㹢�ͤ���</font>
				</div>

                      <div align="center">
				        <input type=submit value=Submit name=topicsubmit>
			            <input type=reset value=reset name=topicreset>
				        </div>
                    </td>
                  </tr>
                </table>
              </form>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>
 </center>
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.question.q_name.value;
      var v2 = document.question.q_topic.value;
      var v3 = document.question.q_message.value;
   
	  
        if ( v1.length==0)
           {
           alert("��سһ�͹ Name");
           document.question.q_name.focus();           
           return false;
           }
        else if (v2.length==0)
           {
           alert("��سһ�͹ Topic");
           document.question.q_topic.focus();           
		   return false;
           }
        else if (v3.length==0)
           {
           alert("��سһ�͹ Message");
           document.question.q_message.focus();           
		   return false;
           }
}
function setsmile(what)
{
	document.question.q_message.value = document.question.elements.q_message.value+" "+what;
	document.question.q_message.focus();
}
//-->
</script> 
</body>
</html>
