<?php
	session_start();
	include("alumni.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name' and ad_passwd='$pwd'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	if($numrows==0){ 
		require ('inpwd.php');
		print "<META http-equiv=refresh content='2; URL=login.php'>";
		exit;
	}
	$tmp=session_id(); 
	$result = mysql_fetch_array($query);
	$ad_id = $result[ad_id];
	print "<META http-equiv=refresh content='0; URL=body.php?id=$tmp&name=$name'>";
?>