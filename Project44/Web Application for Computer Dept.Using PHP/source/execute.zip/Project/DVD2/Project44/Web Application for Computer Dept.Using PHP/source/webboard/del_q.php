<?
session_start();
include("webboard.inc");
include("md5.js");
if($name&&$pwd){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	$pwd1=$row["ad_passwd"];
	$pwd1=MD5($pwd1).$challenge;
	$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
		if($name==$row["ad_user"] && $pwd==$pwd1) { 
		$sql1 = "select * from question";
		$db_query1 = mysql_db_query ($dbname, $sql1);
		$num_rows1 = mysql_num_rows($db_query1);
		if($num_rows1==0){ 
		}
		else{
			for ($i=0;$i<$num_rows1;$i++){
				print "<META http-equiv=refresh content=\"0; URL=index.php\">";
				$sql = "delete from question where q_id='$login[del]'";
				$dbquery = mysql_db_query($dbname, $sql);
				$sql1 = "delete from answer where a_qid='$login[del]'";
				$dbquery1 = mysql_db_query($dbname, $sql1);
			}
		}
	}
	else{
	?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=delq.php">
<?php
	}
}
else{
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=delq.php">
<?php
}
?>