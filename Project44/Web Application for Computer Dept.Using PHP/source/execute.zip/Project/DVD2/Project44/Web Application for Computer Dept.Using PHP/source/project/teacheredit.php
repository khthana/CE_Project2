<? 
	session_start();
if(($id[0]!='')&&($id[1]=='teacher'))
{
?>
<html>
<head>
<title>�Ҩ��������ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" >
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #006DA2; text-decoration: none}
a:visited { color: #006DA2; text-decoration: none}
a:active { color: #3333FF; text-decoration: none}
a:hover { color: #3333FF; text-decoration: none}
-->
</style>
</head>
<?
include("connect.inc.php");
$dbname=project();

    $sql="select * from topicproject where id='$idtopic'";
    $dbquery=mysql_db_query($dbname,$sql)or die("error1");
    $result=mysql_fetch_array($dbquery);

$make1=ereg_replace("<br>","\n",$result[make1]);
$make2=ereg_replace("<br>","\n",$result[make2]);
$detail=ereg_replace("<br>","\n",$result[detail]);

$make1=ereg_replace("&nbsp;"," ",$make1);
$make2=ereg_replace("&nbsp;"," ",$make2);
$detail=ereg_replace("&nbsp;"," ",$detail);
$topic_t=ereg_replace(" ","&nbsp;",$result[topic_t]);
$topic_e=ereg_replace(" ","&nbsp;",$result[topic_e]);
$advisor1=ereg_replace(" ","&nbsp;",$result[advisor1]);
$advisor2=ereg_replace(" ","&nbsp;",$result[advisor2]);

?>
<body  bgcolor=ffffff>
<table border="0" cellspacing="0" cellpadding="0" width="760" align=center>
  <tr class=a> 
   <td valign="top"> 
<form method="post" action="teacherregis.php" enctype="multipart/form-data" onsubmit="return check()" name=form1>
   <INPUT TYPE="hidden" name=idtopic value=<?print($idtopic);?>>
      <br>
      <table width="760" border="1" bordercolor="#ffffff" cellspacing="0" cellpadding="0" height="100%" align=center>
    <tr class=a>
      <td  valign="top"  bordercolor="#0058B0"> 
		    <table width="760" border="0" height="900" cellpadding="5" cellspacing="1" align="center">
              <tr bgcolor="#003F7D" valign="middle" class=a> 
                <td colspan="3" height="30"> 
                  <div align="center">&nbsp;&nbsp; 
                    <font style='font-size:18px'><b>�����Ǣ���ç�ҹ</b></font></div>
                  </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="30%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�����ç�ҹ(������)&nbsp;&nbsp;</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="topic_t" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif " size="70" maxlength=200 value=<?print($topic_t);?>>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="24%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�����ç�ҹ(�����ѧ���)</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="topic_e" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif " size="70" maxlength=200 value=<?print($topic_e);?>>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="24%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�Ҩ�������֡�� 
                    1&nbsp;&nbsp;</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="advisor1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif " maxlength=40 value=<?print($advisor1);?>>
                  <font style="FONT-SIZE: 9pt" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="24%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�Ҩ�������֡�� 
                    2&nbsp;&nbsp;</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="advisor2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif " maxlength=40 value=<?print($advisor2);?>>
                </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="24%" bgcolor="#0053A6" > 
                  <div align="center"><font class=a>�ӹǹ�ѡ�֡�ҷ���ͧ��� 
                    </font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="num" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif "  maxlength=2 value=<?print($result[num]);?>>
                     <font class=a ><font color=#000000><b>&nbsp;&nbsp;&nbsp;��</b></font></font ><font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="24%" bgcolor="#0053A6" > 
                  <div align="center"><font style='font-size:16px'><font color="#FFFFFF">�ѵ�ػ��ʧ��&nbsp;&nbsp;</font></font> 
                  </div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <textarea rows=5 cols=87 name="make1"  style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif "><?print($make1);?></textarea>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="24%" bgcolor="#0053A6"> 
                  <div align="center"><font style='font-size:16px'><font color="#FFFFFF">�ŷ�����Ѻ&nbsp;&nbsp;</font></font> 
                  </div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <textarea rows=5 cols=87 name="make2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif "><?print($make2);?></textarea>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3"> 
               <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font style='font-size:16px'><font color="#FFFFFF">�����������&nbsp;&nbsp;</font></font> 
                  </div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <textarea rows=15 cols=87 name="detail"  style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif,Ms Sans Serif "><?print($detail);?></textarea>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
             
			<tr height=50 class=a> 
                <td align=right width="23%" valign="top"></td>
                <td colspan=2 align=center  valign=middle><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif,Ms Sans Serif" 
            color=#666666 ><b><u>������</u>��</b> ��سҡ�͡������㹪�ͧ���������ͧ���� 
                  <font style="FONT-SIZE: 13px" face="verdana,arial" color=#ff0000 >&nbsp;*</font> 
                  ��ҡѺ�������ú��ǹ����ó�</font></td>
              </tr>
              <tr> 
                <td width="24%" height="32" bgcolor="#FFFFFF" class=a>&nbsp;</td>
                <td width="50%" height="32" bgcolor="#FFFFFF" class=a> 
                  <div align="right"> 
                    <INPUT TYPE="hidden" name=teacher value=edit>
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=edittopic>
                    &nbsp;&nbsp; 
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancle>
                  </div>
                </td>
                <td width="56%" height="32">&nbsp;</td>
              </tr>
            </table>
        
      </td>
    </tr>
  </table>
  <br>
 <br>
</form>

	
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.form1.topic_t.value;
      var v2 = document.form1.topic_e.value;
      var v3 = document.form1.advisor1.value;
	  var v4 = document.form1.num.value;
  	  var v5 = document.form1.make1.value;
      var v6 = document.form1.make2.value;
      var v7 = document.form1.detail.value;
	    	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.topic_t.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.topic_e.focus();           
           return false;
           }
        else if (v3.length==0)
           {
            alert("��س������������ú��ǹ");            
           document.form1.advisor1.focus();           
		   return false;
        }
		else if (v4.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.num.focus();           
		   return false;
           }
      	else if (v5.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.make1.focus();           
		   return false;
           }
      	else if (v6.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.make2.focus();           
		   return false;
           }
      	else if (v7.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.detail.focus();           
		   return false;
           }
		else
           return true;
}
//-->
</script>
<?
//�Դ�ҹ������
closedb();
?>
</body>
</html>
<?
}
else
 {
?>
 <div align="center">
<br>  
<p><font style='font-size:15'><font face="Tahoma,Ms Sans Serif,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif,Ms Sans Serif"  color="#FF0000">��سҵ�Ǩ�ͺ username&password �ͧ�س�����ա����</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div> 
<?
 }
