<?
session_start();
include("alumni.inc");
include("md5.js");
mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
mysql_select_db($dbname) or die("���͡�ҹ�����������");
If (($std_id=="") or ($std_type=="") or ($std_class=="") or ($std_fullname=="") or ($std_email=="")or ($std_password1=="") or ($std_password2=="") or ($std_username=="") or ($std_question=="") or ($std_answer=="")){ 
			session_destroy();
			session_unset();
			echo "<br><center><font  size=4>�ô��͡���������ú (��੾�п�Ŵ����� *)</font>";
			echo "<br><a href =\"am_form.html\"><font  >��͡����������</font></a></center><br>";
			print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			exit;
}else{
}
If ($std_password1<>$std_password2){ 
		session_destroy();
		session_unset();
		echo "<br><center><font  >��Ŵ� Login_password ��� Password Again ���ç�ѹ</font>";
		echo "<br><a href =\"am_form.html\"><font size=4 >��͡����������</font></a></center><br>";
		print "<META http-equiv=refresh content=\"2; URL=index.html\">";
		exit;
}else{
}

	$sql="	select * from data_alumni where std_username='$mem[n]'";
	$result=mysql_db_query($dbname,$sql) or die("�Դ��Ͱҹ�����������8");
	$NRow = mysql_num_rows($result) or die("�Դ��Ͱҹ�����������9");
	if($NRow==0){ 
?><title>Login Administrator</title>
			
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<!--  <META http-equiv=refresh content="3; URL=login.php">-->
<font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
<?php
	}
	else{
		$row = mysql_fetch_array($result);
		$pwd1=$row["std_password1"];
		$std_n=$row["std_username"];
		$std_n = stripslashes($std_n);
		$pwd1 = stripslashes($pwd1);
		$pwd1 = stripslashes($pwd1);
		$pwd1=MD5($pwd1).$mem[c];
		$pwd1=MD5($pwd1);

		// ��Ǩ�ͺ��� Password �١�������	
		if($mem[n]==$std_n && $mem[p]==$pwd1) { 
		if($mem[id]==$std_id){
		}else{
			$sql6="	select * from data_alumni where std_username='$mem[n]'";
			$result6=mysql_db_query($dbname,$sql6) or die("�Դ��Ͱҹ�����������8");
			$NRow6 = mysql_num_rows($result6) or die("�Դ��Ͱҹ�����������9");
			if($NRow6==0){ 
			}else{
				session_destroy();
				session_unset();
				echo "<br><center><font  size=4 color=#FF0000>���ʹѡ�֡�ҹ���դ������Ǥ�Ѻ</font><br><br>";
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				exit;
			}
		}		
	
		if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])",$std_email)){
		$std_id = htmlspecialchars($std_id);
		$std_class = htmlspecialchars($std_class);
		$std_fullname = htmlspecialchars($std_fullname);
		$std_nick = htmlspecialchars($std_nick);
		$std_type = htmlspecialchars($std_type);
		$std_type1 = htmlspecialchars($std_type1);
		$days= htmlspecialchars($days);
		$day= htmlspecialchars($day);
		$mount= htmlspecialchars($mount);
		$year= htmlspecialchars($year);
		$std_work = htmlspecialchars($std_work);
		$std_position = htmlspecialchars($std_position);
		$std_address_now = htmlspecialchars($std_address_now);
		$std_tel_home = htmlspecialchars($std_tel_home);
		$std_tel_work = htmlspecialchars($std_tel_work);
		$std_pager = htmlspecialchars($std_pager);
		$sstd_icq = htmlspecialchars($sstd_icq);
		$std_email = htmlspecialchars($std_email);
		$std_username = htmlspecialchars($std_username);
		$std_password1 = htmlspecialchars($std_password1);
		$std_password2 = htmlspecialchars($std_passwrk2);
		$std_homepage = htmlspecialchars($std_homepage);
		$std_question = htmlspecialchars($std_question);

		$std_id = nl2br($std_id);
		$std_class = nl2br($std_class);
		$std_fullname = nl2br($std_fullname);
		$std_nick = nl2br($std_nick);
		$std_type = nl2br($std_type);
		$std_type1 = nl2br($std_type1);
		$days= nl2br($days);
		$day= nl2br($day);
		$mount= nl2br($mount);
		$year= nl2br($year);
		$std_work = nl2br($std_work);
		$std_position = nl2br($std_position);
		$std_address_now = nl2br($std_address_now);
		$std_tel_home = nl2br($std_tel_home);
		$std_tel_work = nl2br($std_tel_work);
		$std_pager = nl2br($std_pager);
		$sstd_icq = nl2br($sstd_icq);
		$std_email = nl2br($std_email);
		$std_username = nl2br($std_username);
		$std_password1 = nl2br($std_password1);
		$std_password2 = nl2br($std_passwrk2);
		$std_homepage = nl2br($std_homepage);
		$std_question = nl2br($std_question);

		$std_id = addslashes($std_id);
		$std_class = addslashes($std_class);
		$std_fullname = addslashes($std_fullname);
		$std_nick = addslashes($std_nick);
		$std_type = addslashes($std_type);
		$std_type1 = addslashes($std_type1);
		$days= addslashes($days);
		$day= addslashes($day);
		$mount= addslashes($mount);
		$year= addslashes($year);
		$std_work = addslashes($std_work);
		$std_position = addslashes($std_position);
		$std_address_now = addslashes($std_address_now);
		$std_tel_home = addslashes($std_tel_home);
		$std_tel_work = addslashes($std_tel_work);
		$std_pager = addslashes($std_pager);
		$sstd_icq = addslashes($sstd_icq);
		$std_email = addslashes($std_email);
		$std_username = addslashes($std_username);
		$std_password1 = addslashes($std_password1);
		$std_password2= addslashes($std_passwrk2);
		$std_homepage = addslashes($std_homepage);
		$std_question = addslashes($std_question);

		$std_id = eregi_replace(" ","&nbsp;",$std_id);
		$std_class = eregi_replace(" ","&nbsp;",$std_class);
		$std_fullname = eregi_replace(" ","&nbsp;",$std_fullname);
		$std_nick = eregi_replace(" ","&nbsp;",$std_nick);
		$std_type = eregi_replace(" ","&nbsp;",$std_type);
		$std_type1 = eregi_replace(" ","&nbsp;",$std_type1);
		$days= eregi_replace(" ","&nbsp;",$days);
		$day= eregi_replace(" ","&nbsp;",$day);
		$mount= eregi_replace(" ","&nbsp;",$mount);
		$year= eregi_replace(" ","&nbsp;",$year);
		$std_work = eregi_replace(" ","&nbsp;",$std_work);
		$std_position = eregi_replace(" ","&nbsp;",$std_position);
		$std_address_now = eregi_replace(" ","&nbsp;",$std_address_now);
		$std_tel_home = eregi_replace(" ","&nbsp;",$std_tel_home);
		$std_tel_work = eregi_replace(" ","&nbsp;",$std_tel_work);
		$std_pager = eregi_replace(" ","&nbsp;",$std_pager);
		$sstd_icq = eregi_replace(" ","&nbsp;",$sstd_icq);
		$std_email = eregi_replace(" ","&nbsp;",$std_email);
		$std_username = eregi_replace(" ","&nbsp;",$std_username);
		$std_password1 = eregi_replace(" ","&nbsp;",$std_password1);
		$std_password2= eregi_replace(" ","&nbsp;",$std_password1);
		$std_homepage = eregi_replace(" ","&nbsp;",$std_homepage);
		$std_question = eregi_replace(" ","&nbsp;",$std_question);
		$std_ip = getenv(remote_addr);

		setlocale("LC_TIME","th");	
		$a = date("j");
		$b = strftime("%m");
		$c = strftime("%y");
		$d = date("H:i:s");
		$std_datetime = "$a/$b/$c:$d";
		$sql3= "SELECT * FROM data_alumni WHERE std_username = '$std_username' and std_number = '$mem[1]'"; 
		$db_query3 = mysql_db_query($dbname, $sql3);
		$nums_rows3 = mysql_num_rows($db_query3);
		if($nums_rows3=="1"){
		if($std_type=="������ͧ"){
			if(($std_class<=$maxcon) and ($std_class>=$mincon)){
				$sql = "update $tblname set std_id='$std_id', std_class='$std_class', std_fullname='$std_fullname', std_type1='$std_type1', std_nick='$std_nick', std_type='$std_type', std_days='$days', std_day='$day', std_mount='$mount', std_year='$year', std_work='$std_work', std_position='$std_position', std_address_born='$std_address_born', std_address_now='$std_address_now', std_tel_home='$std_tel_home', std_tel_work='$std_tel_work', std_pager='$std_pager', std_icq='$std_icq', std_email='$std_email', std_homepage='$std_homepage', std_username='$std_username', std_password1='$std_password1', std_password2='$std_password2', std_datetime='$std_datetime', std_ip='$std_ip',std_question='$std_question',std_answer='$std_answer' where std_number='$mem[1]'";	
				$dbquery = mysql_db_query($dbname, $sql);
				session_destroy();
				session_unset();
				echo "<br><center><font  ><B>ŧ�����Ţͧ��ҹ����¹�ŧ���º�������Ǥ�Ѻ</B></font>";
				echo "</center><br>";	
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			}//end if check size con
			else{
				session_destroy();
				session_unset();
				echo "<br><center><font  size=4>�ѡ�֡�ҵ�����ͧ��蹴ѧ������������Ҥ�Ԫ�</font><br>";
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			} // end check size con
		}// end if check con
		else{
			if(($std_class<=$maxnormal) and ($std_class>=$minnormal)){
				$sql = "update $tblname set std_id='$std_id', std_class='$std_class', std_fullname='$std_fullname', std_type1='$std_type1', std_nick='$std_nick', std_type='$std_type', std_days='$days', std_day='$day', std_mount='$mount', std_year='$year', std_work='$std_work', std_position='$std_position', std_address_born='$std_address_born', std_address_now='$std_address_now', std_tel_home='$std_tel_home', std_tel_work='$std_tel_work', std_pager='$std_pager', std_icq='$std_icq', std_email='$std_email', std_homepage='$std_homepage', std_username='$std_username', std_password1='$std_password1', std_password2='$std_password2', std_datetime='$std_datetime', std_ip='$std_ip', std_question='$std_question',std_answer='$std_answer' where std_number='$mem[1]'";	
				$dbquery = mysql_db_query($dbname, $sql);
				session_destroy();
				session_unset();
				echo "<br><center><font  ><B>ŧ�����Ţͧ��ҹ����¹�ŧ���º�������Ǥ�Ѻ</B></font>";
				echo "</center><br>";	
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			} // end if check size normal
			else{
				session_destroy();
				session_unset();
				echo "<br><center><font  size=4>�ѡ�֡���Ҥ������蹴ѧ������������Ҥ�Ԫ�</font><br>";
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			} // end check size normal
		} //end normal 
		} // end if check user row id
		else{
			$sql4 = "SELECT * FROM data_alumni WHERE std_username = '$std_username'"; 
			$db_query4 = mysql_db_query($dbname, $sql4);
			$nums_rows4 = mysql_num_rows($db_query4);
			if($nums_rows4=="0"){
			if($std_type=="������ͧ"){
				if(($std_class<=$maxcon) and ($std_class>=$mincon)){
					$sql = "update $tblname set std_id='$std_id', std_class='$std_class', std_fullname='$std_fullname', std_type1='$std_type1', std_nick='$std_nick', std_type='$std_type', std_days='$days', std_day='$day', std_mount='$mount', std_year='$year', std_work='$std_work', std_position='$std_position', std_address_born='$std_address_born', std_address_now='$std_address_now', std_tel_home='$std_tel_home', std_tel_work='$std_tel_work', std_pager='$std_pager', std_icq='$std_icq', std_email='$std_email', std_homepage='$std_homepage', std_username='$std_username', std_password1='$std_password1', std_password2='$std_password2', std_datetime='$std_datetime', std_ip='$std_ip',std_question='$std_question',std_answer='$std_answer' where std_number='$mem[1]'";	
					$dbquery = mysql_db_query($dbname, $sql);
					session_destroy();
					session_unset();
					echo "<br><center><font  ><B>ŧ�����Ţͧ��ҹ����¹�ŧ���º�������Ǥ�Ѻ</B></font>";
					echo "</center><br>";	
					print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				}//end if check size con
				else{
					session_destroy();
					session_unset();
					echo "<br><center><font  size=4>�ѡ�֡�ҵ�����ͧ��蹴ѧ������������Ҥ�Ԫ�</font><br>";
					print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				} // end check size con
			}// end if check con
			else{
				if(($std_class<=$maxnormal) and ($std_class>=$minnormal)){
					$sql = "update $tblname set std_id='$std_id', std_class='$std_class', std_fullname='$std_fullname', std_type1='$std_type1', std_nick='$std_nick', std_type='$std_type', std_days='$days', std_day='$day', std_mount='$mount', std_year='$year', std_work='$std_work', std_position='$std_position', std_address_born='$std_address_born', std_address_now='$std_address_now', std_tel_home='$std_tel_home', std_tel_work='$std_tel_work', std_pager='$std_pager', std_icq='$std_icq', std_email='$std_email', std_homepage='$std_homepage', std_username='$std_username', std_password1='$std_password1', std_password2='$std_password2', std_datetime='$std_datetime', std_ip='$std_ip',std_question='$std_question',std_answer='$std_answer' where std_number='$mem[1]'";	
					$dbquery = mysql_db_query($dbname, $sql);
					session_destroy();
					session_unset();
					echo "<br><center><font  ><B>ŧ�����Ţͧ��ҹ����¹�ŧ���º�������Ǥ�Ѻ</B></font>";
					echo "</center><br>";	
					print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				} // end if check size normal
				else{
					session_destroy();
					session_unset();
					echo "<br><center><font  size=4>�ѡ�֡���Ҥ������蹴ѧ������������Ҥ�Ԫ�</font><br>";
					print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				} // end check size normal
			} //end normal 
		} // end if user
		else{
			session_destroy();
			session_unset();
			echo "<br><center><font  size=4 color=#FF0000> USER NAME ����դ������Ǥ�Ѻ</font><br><br>";
			print "<META http-equiv=refresh content=\"2; URL=index.html\">";
		} // end user
	} // end user row id

}// end if check email
else{
		echo "<br><center><font  size=4> ��سҡ�͡ Email �ͧ��ҹ����</font><br><br>";
		session_destroy();
		session_unset();
		print "<META http-equiv=refresh content=\"2; URL=index.html\">";
} // end check email

		}
		else{
?>
</font> 
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
  <META http-equiv=refresh content="2; URL=login.php">
<font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
<?php
	 }	
}
?>
</font>