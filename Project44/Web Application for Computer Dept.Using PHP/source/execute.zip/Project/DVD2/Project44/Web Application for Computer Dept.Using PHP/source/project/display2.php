<?
session_start();
 include("connect.inc.php");
$dbname=project();
$sql="select * from news where id='$id1'";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");
$result=mysql_fetch_array($dbquery);
$rows=mysql_num_rows($dbquery);	
  // ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
$result[detail] = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])","<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>",$result[detail]);
$result[detail] = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>",$result[detail]); 

$result[detail]=ereg_replace("&nbsp;"," ",$result[detail]);
$result[detail]=ereg_replace("<br>","~",$result[detail]);
//$result[detail]=wordwrap($result[detail],100,'<br>',1);
$result[detail]=ereg_replace("~","<br>",$result[detail]);
$result[detail]=ereg_replace(" ","&nbsp;",$result[detail]);

if($rows!=0)
{
?>
<HTML>
<HEAD>
<TITLE>��������ͧ <?print($result[topic]);?> -- <?print($result[vardate]);?></TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<BODY text=#000000 bgColor=#ffffff>
<br>
<table border=0  width="760" align=left >
  <tr > 
	<td valign=top>
<IMG height=39 src="images/post2.gif" width=65 align=middle><FONT face="Tahoma,Ms Sans Serif" color=#0000ff style='font-size:16px'>����ͧ </FONT>
<B><FONT face="Tahoma,Ms Sans Serif" color=#0000ff style='font-size:16px'><?print($result[topic]);?></FONT></B>
<FONT face="Tahoma,Ms Sans Serif" color=#0000ff style='font-size:16px'> ��С������� </FONT>
<FONT face="Tahoma,Ms Sans Serif" color=#0000ff style='font-size:16px'><?print($result[vardate]);?></FONT> 
<P>
<table width='100%' border=0 cellspacing="0"cellpadding="0">
<tr>
<td valign=top class=a>
<DD><FONT  face="Tahoma,Ms Sans Serif" color='#000000'><?print($result[detail]);?></FONT>
</td>
</tr>
</table>
<BR>
<BR>
<DIV align=right><IMG height=32 src="images/post1.gif" width=32 align=middle ><font class=a><FONT face="Tahoma,Ms Sans Serif" color=#0060a0 >����С�� </FONT><FONT face="Tahoma,Ms Sans Serif" color=#0060a0 ><?print($result[name]);?></FONT></font><BR></DIV>
<BR>
<BR>
		<?if($result[newsfile]!='')
		{
		 ?>
         <HR>
        <TABLE>
        <TBODY>
        <TR>
        <TD align=middle>
		 <A href="<?print("news".$result[id]."/".$result[newsfile]);?>" target=""><IMG src="images/fileatt.gif" border=0  width="23" height="32"><BR><?print($result[newsfile]);?></A>
        <?
		}
        else
	    {
		?>
		<TABLE>
       <TBODY>
       <TR>
        <TD align=middle>
		 <?
		}
		 ?>
</TD>
  </TR>
  </TBODY>
  </TABLE>
 <?
}
else
{
    ?>

<div align="center">
  <p><br>
    <font class=h><font face="Tahoma,Ms Sans Serif"  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҵ�Ǩ�ͺ id �ͧ�س�����ա����</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div>
<?
}
//�Դ�ҹ������
closedb();
?>
</td>
</tr>
</table>

</BODY>
</HTML>