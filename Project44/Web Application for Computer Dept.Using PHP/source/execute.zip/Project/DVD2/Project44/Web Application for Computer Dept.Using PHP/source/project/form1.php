<?session_start();
 if($id[0]!='')
  {
 include("connect.inc.php");
$dbname=project();
//�֧�����Ũҡ���ҧ userregister
$sql="select * from userregister where (code1='$id[0]' or code2='$id[0]' or code3='$id[0]' or code4='$id[0]')";
$dbquery=mysql_db_query($dbname,$sql)or die("error2");
$rows=mysql_num_rows($dbquery);	 
?>
<html>
<head>
<title>�к��ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" >
<LINK href="main.css" rel=stylesheet  type='text/css'>
</head>
<?
if(($rows==0)||($id[1]=='admin'))
  {
?>
<body  bgcolor=ffffff>
<?
  if(($file=='')&&($reset=='')&&($submit==''))
	  {
             if(!is_dir("temp"))
		       {
		        //���ҧ���硷��� temp 
                mkdir("temp",0777); 
		        }
			 else
		       {
			 $dh=opendir("temp");
			 while($file=readdir($dh))
                {
              if(($file!='.')&&($file!='..'))
                 unlink('temp/'.$file); 
                }
             closedir($dh);
			   }
     }
  if($file=='Submit')
     {
      $dirname="temp"; 
      $dh=opendir($dirname);
     if(($filedata_name=="chap1.pdf")||($filedata_name=="document.pdf")||($filedata_name=="chap2.pdf")||($filedata_name=="chap3.pdf")||($filedata_name=="chap4.pdf")||($filedata_name=="chap5.pdf")||($filedata_name=="chap6.pdf")||($filedata_name=="chap7.pdf")||($filedata_name=="chap8.pdf")||($filedata_name=="chap9.pdf")||($filedata_name=="chap10.pdf")||($filedata_name=="chap11.pdf")||($filedata_name=="chap12.pdf")||($filedata_name=="chap13.pdf")||($filedata_name=="chap14.pdf")||($filedata_name=="chap15.pdf")||($filedata_name=="chap16.pdf")||($filedata_name=="chap17.pdf")||($filedata_name=="chap18.pdf")||($filedata_name=="chap19.pdf")||($filedata_name=="chap20.pdf"))
	 copy($filedata,"temp/".$filedata_name);
      closedir($dh);
     }//addfile
  
   if($reset=='cancel')
	     {
	      $dirname="temp";
          $dh=opendir($dirname);
          while($file=readdir($dh))
              {
              if(($file!='.')&&($file!='..'))
                 unlink($dirname.'/'.$file); 
               }
   closedir($dh);
     $name1='';
	 $name2='';
	 $name3='';
	 $name4='';
	 $code1='';
	 $code2='';
	 $code3='';
	 $code4='';
     $email1='';
	 $email2='';
	 $email3='';
	 $email4='';
     $namept='';
	 $namepe='';
     $advisor1='';
	 $advisor2='';
     $year='';
     $abst='';
	 $abse='';
      }//cancel

if($submit!='Submit')
    {
$result[abst]=ereg_replace("<br>","\n",$result[abst]);
$result[abse]=ereg_replace("<br>","\n",$result[abse]);

$abst=ereg_replace("&nbsp;"," ",$abst);
$abse=ereg_replace("&nbsp;"," ",$abse);
$name1=ereg_replace(" ","&nbsp;",$name1);
$name2=ereg_replace(" ","&nbsp;",$name2);
$name3=ereg_replace(" ","&nbsp;",$name3);
$name4=ereg_replace(" ","&nbsp;",$name4);

$namept=ereg_replace(" ","&nbsp;",$namept);
$namepe=ereg_replace(" ","&nbsp;",$namepe);
$advisor1=ereg_replace(" ","&nbsp;",$advisor1);
$advisor2=ereg_replace(" ","&nbsp;",$advisor2);
?>
<table border="0" cellspacing="0" cellpadding="0" width="760" align=left>
  <tr class=a> 
    <td valign="top">
<form method="post" action="form1.php" enctype="multipart/form-data" onsubmit="return check()" name=form1>
        <table width="760" border="1" bordercolor="#ffffff" cellspacing="0" cellpadding="0" height="600" align=center>
          <tr class=a>
      <td  valign="top"  bordercolor="#0058B0"> 
              <table width="760" border="1" cellpadding="0" cellspacing="1" height="150" bordercolor="#CCCCCC">
                <tr height='32' bgcolor="#003F7D" valign="middle" class=a> 
                  <td colspan="6" align=center height="29"> 
                    <div align="center"><b><font style='font-size:18px'>�����ç�ҹ</font></b> 
                    </div>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="9%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="28%" bgcolor="#F6F6F6" align=left class=a> &nbsp;&nbsp; 
                    <input type="text" name="name1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name1);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                  <td width="12%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="19%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?if($id[1]!='admin') print($id[0]); else print($code1);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="25%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email1);?>>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="9%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="27%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name2);?>>
                  </td>
                  <td width="12%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="19%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code2);?>>
                  </td>
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="25%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email2);?>>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="9%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="27%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name3);?>>
                  </td>
                  <td width="12%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="19%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code3);?>>
                  </td>
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="25%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email3);?>>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="9%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="27%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name4);?>>
                  </td>
                  <td width="12%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="19%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code4);?>>
                  </td>
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="25%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email4);?>>
                  </td>
                </tr>
              </table>
    
	          <table border="1"  cellpadding="5" cellspacing="1" bordercolor="#CCCCCC" width="760">
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�����ç�ҹ(������)&nbsp;&nbsp;</font></div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp; 
                    <input type="text" name="namept" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="70" maxlength=200 value=<?print($namept);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�����ç�ҹ(�����ѧ���)</font></div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp; 
                    <input type="text" name="namepe" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="70" maxlength=200 value=<?print($namepe);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font></td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�Ҩ�������֡��&nbsp;&nbsp;</font></div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp; 
                    <input type="text" name="advisor1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=40 value=<?print($advisor1);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�Ҩ�������֡��&nbsp;&nbsp;</font></div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp; 
                    <input type="text" name="advisor2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=40 value=<?print($advisor2);?>>
                  </td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�ա���֡��&nbsp;&nbsp;</font> 
                    </div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input type="text" name="year" size="5" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=4 value=<?print($year);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6" class=a> 
                    <div align="center"><font style='font-size:16px'><font color="#FFFFFF">���Ѵ���&nbsp;&nbsp;</font></font> 
                    </div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp; 
                    <textarea rows=15 cols=85 name="abst" wrap=virtual style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "><?print($abst)?></textarea>
                  </td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6" class=a> 
                    <div align="center"><font style='font-size:16px'>abstract&nbsp;&nbsp;</font> 
                    </div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <textarea rows=15 cols=85 name="abse" wrap=virtual style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "><?print($abse);?></textarea>
                  </td>
                </tr>
                <tr bgcolor="#0099E3" class=a> 
                  <td width="177" bgcolor="#0053A6" class=a> 
                    <div align="center"><font style='font-size:16px'>Display  
                      &nbsp;&nbsp;</font> </div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp;       
			<table width='550' height=200 border=1 cellspacing="0" cellpadding="0">
					 <tr class=a>
                      <td valign=top class=a>
					 <p><font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">#���� file �������öṺ���մѧ���</font></p>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">1.document.pdf&nbsp;&nbsp;&nbsp;2.chap1.pdf&nbsp;&nbsp;&nbsp;3.chap2.pdf&nbsp;&nbsp;&nbsp;4.chap3.pdf&nbsp;&nbsp;&nbsp;5.chap4.pdf</font><br>                   	
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">6.chap5.pdf&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.chap6.pdf&nbsp;&nbsp;&nbsp;8.chap7.pdf&nbsp;&nbsp;&nbsp;9.chap8.pdf&nbsp;&nbsp;&nbsp;10.chap9.pdf</font><br>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">11.chap10.pdf&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12.chap11.pdf&nbsp;&nbsp;&nbsp;13.chap12.pdf&nbsp;&nbsp;&nbsp;14.chap13.pdf&nbsp;&nbsp;&nbsp;15.chap14.pdf</font><br>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">16.chap15.pdf&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;17.chap16.pdf&nbsp;&nbsp;&nbsp;18.chap17.pdf&nbsp;&nbsp;&nbsp;19.chap18.pdf&nbsp;&nbsp;&nbsp;20.chap19.pdf</font><br>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">21.chap20.pdf</font><br>
					  <p><font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">#���� file ��������������</font></p>	
					   
					  <?			  
			       $dirname="temp";
				   $dh=opendir($dirname);
                   $c=1;
				   while($file=readdir($dh))
                       {
                           if(($file!='.')&&($file!='..'))
						   {
						      print("<font style='FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066'>".$c.'.'.$file."</font><br>"); 
                               $c++;
						   }
						}
                    closedir($dh);
              ?>  
			</td>
			</tr>
			</table>
                  </td>
                </tr>
                <tr bgcolor="#0099E3" bordercolor="#CCCCCC" class=a> 
                  <td width="177" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>File 
                      &nbsp;&nbsp;</font></div>
                  </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input style="FONT-SIZE: 13px; WIDTH: 250px; height:25px;FONT-FAMILY: verdana" type=file  name="filedata">
                    &nbsp; 
                    <input style="FONT-SIZE: 13px; WIDTH: 70px;height:25px; FONT-FAMILY: verdana" type=submit value=Submit name="file">
                  </td>
                </tr>
                <tr bgcolor="#0099E3" bordercolor="#CCCCCC" class=a> 
                  <td width="177" bgcolor="#0053A6" valign="middle" height="83" class=a> 
                    <div align="center"><font  class=a>Keyword 
                      search </font></div>
                  </td>
                  <td bgcolor="#F6F6F6" colspan="2" height="83" valign="top"> 
                    <table width="556" border="0" height="61" cellpadding="0" cellspacing="0">
                      <tr class=a> 
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;1.</font> 
                          <input type="text" name="key1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ">
                        </td>
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;2.</font> 
                          <input type="text" name="key2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ">
                        </td>
                        <td width="29%" height="38" class=a><font color=#000000>&nbsp;3.</font> 
                          <input type="text" name="key3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ">
                        </td>
                      </tr>
                      <tr> 
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;4. </font> 
                          <input type="text" name="key4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ">
                        </td>
                        <td colspan="2" height="38" class=a> <font color=#000000>&nbsp;5.</font> 
                          <input type="text" name="key5" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ">
                        </td>
                      </tr>
                    </table>
                    
                  </td>
                </tr>
                <tr valign=top height=50 bordercolor="#FFFFFF" class=a> 
                  <td align=right width="177">&nbsp;</td>
                  <td colspan=2 align=center  valign=middle><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#666666 ><b><u>������</u>��</b> ��سҡ�͡������㹪�ͧ���������ͧ���� 
                    <font style="FONT-SIZE: 13px" face="verdana,arial" color=#ff0000 >&nbsp;*</font> 
                    ��ҡѺ�������ú��ǹ����ó�</font></td>
                </tr>
                <tr bordercolor="#FFFFFF" class=a> 
                  <td width="177" height="32" bgcolor="#FFFFFF" class=a>&nbsp;</td>
                  <td width="319" height="32" bgcolor="#FFFFFF" class=a> 
                    <div align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 13px; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
                      &nbsp;&nbsp; 
                      <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 13px; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=cancel name=reset>
                    </div>
                  </td>
                  <td width="274" height="32" class=a>&nbsp;</td>
                </tr>
              </table>
        
      </td>
    </tr>
  </table>
  <br>
 <br>
</form>
</td>
</tr>
</table>
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.form1.name1.value;
      var v2 = document.form1.code1.value;
     
	  var v4 = document.form1.namept.value;
  	  var v5 = document.form1.namepe.value;
      var v6 = document.form1.advisor1.value;
      var v7 = document.form1.year.value;
	    	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.name1.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.code1.focus();           
           return false;
           }
       
		else if (v4.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.namept.focus();           
		   return false;
           }
      	else if (v5.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.namepe.focus();           
		   return false;
           }
      	else if (v6.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.advisor1.focus();           
		   return false;
           }
      	else if (v7.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.year.focus();           
		   return false;
           }
		else
           return true;
}
//-->
</script>
<?
}//!=submit
else
  {

$filedoc='';
$filechap1='';
$filechap2='';
$filechap3='';
$filechap4='';
$filechap5='';
$filechap6='';
$filechap7='';
$filechap8='';
$filechap9='';
$filechap10='';
$filechap11='';
$filechap12='';
$filechap13='';
$filechap14='';
$filechap15='';
$filechap16='';
$filechap17='';
$filechap18='';
$filechap19='';
$filechap20='';

$dirname="temp";
$dh=opendir($dirname);
    while($file=readdir($dh))
        {
            if(($file!='.')&&($file!='..'))
                 {
            	    if($file=='document.pdf')
						$filedoc=$file;
                    elseif($file=='chap1.pdf')
					     $filechap1=$file;
                    elseif($file=='chap2.pdf')
					     $filechap2=$file;
                    elseif($file=='chap3.pdf')
					     $filechap3=$file;
                    elseif($file=='chap4.pdf')
					     $filechap4=$file;
                    elseif($file=='chap5.pdf')
					     $filechap5=$file;
                    elseif($file=='chap6.pdf')
					     $filechap6=$file;
                    elseif($file=='chap7.pdf')
					     $filechap7=$file;
                     elseif($file=='chap8.pdf')
					     $filechap8=$file;
					  elseif($file=='chap9.pdf')
					     $filechap9=$file;
            	   elseif($file=='chap10.pdf')
					     $filechap10=$file;
				   elseif($file=='chap11.pdf')
					     $filechap11=$file;
                    elseif($file=='chap12.pdf')
					     $filechap12=$file;
                    elseif($file=='chap13.pdf')
					     $filechap13=$file;
                    elseif($file=='chap14.pdf')
					     $filechap14=$file;
                    elseif($file=='chap15.pdf')
					     $filechap15=$file;
                    elseif($file=='chap16.pdf')
					     $filechap16=$file;
                    elseif($file=='chap17.pdf')
					     $filechap17=$file;
                     elseif($file=='chap18.pdf')
					     $filechap18=$file; 
					 elseif($file=='chap19.pdf')
					     $filechap19=$file; 
					 elseif($file=='chap20.pdf')
					     $filechap20=$file;
				  }
    	}
closedir($dh);

$abst=htmlspecialchars($abst);
$abse=htmlspecialchars($abse);

$abst=ereg_replace("\n","<br>",$abst);
$abse=ereg_replace("\n","<br>",$abse);

$abst=ereg_replace(" ","&nbsp;",$abst);
$abse=ereg_replace(" ","&nbsp;",$abse);

 //��������ŧ���ҧ register
$sql="insert into register (advisor1,advisor2,namept,namepe,year,abst,abse,doc,chap1,chap2,chap3,chap4,chap5,chap6,chap7,chap8,chap9,chap10,chap11,chap12,chap13,chap14,chap15,chap16,chap17,chap18,chap19,chap20,key1,key2,key3,key4,key5) values ('$advisor1','$advisor2','$namept','$namepe','$year','$abst','$abse','$filedoc','$filechap1','$filechap2','$filechap3','$filechap4','$filechap5','$filechap6','$filechap7','$filechap8','$filechap9','$filechap10',chap11='$filechap11' ,chap12='$filechap12' ,chap13='$filechap13' ,chap14='$filechap14',chap15='$filechap15',chap16='$filechap16',chap17='$filechap17',chap18='$filechap18' ,chap19='$filechap19',chap20='$filechap20' ,'$key1','$key2','$key3','$key4','$key5')";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");
         
//�Ҩӹǹ record �ͧ���ҧ register ����ա�� record 
$sql="select * from register order by id Desc";
$dbquery=mysql_db_query($dbname,$sql)or die("error2");
$result=mysql_fetch_array($dbquery);

$numid=$result[id];
 
 //����¹���� dir ��� id
rename('temp','id'.$numid);

//��������ŧ���ҧ userregister
$sql="insert into userregister (name1,code1,email1,name2,code2,email2,name3,code3,email3,name4,code4,email4,id) values ('$name1','$code1','$email1','$name2','$code2','$email2','$name3','$code3','$email3','$name4','$code4','$email4','$numid')";
$dbquery=mysql_db_query($dbname,$sql)or die("error3");

?>
<div align="center">
<br>
 <br>  
<p>
	<font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#0033FF"><b>Complete</b></font></font></p>
  <p><font class=a><font color="#0033FF">�����Ţͧ�س�١�Ѵ��ŧ�ҹ���º��������</font></font></p>  
  <a href='indexs.php' class=home>HOME</a>
  <hr width="400">
  <br>
</div>

<?  
  }//submit
}//��������ա�� register 
else//����ա�� register ����
   {
 ?>  

 <div align="center">
  <p><br>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">���ͧ�ҡ�����ʢͧ�س����㹰ҹ�����Ţͧ��� register ����</font></font></p>
 <a href='indexs.php' class=home>HOME</a>   
 <hr width="400" color=#000000>
  <p>&nbsp;</p>
</div>
<?  
 }
 
//�Դ�ҹ������
closedb();
?>
</body>
</html>
<?
}
else
   {
?>
  <div align="center">
  <p><br>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">���ͧ�ҡ�س�ӼԴ��鹵͹��� register �ͧ�к�</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div>
<?   
   }
?>