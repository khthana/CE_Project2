<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<script type="text/javascript" language="JavaScript"> id = new Array();desc = new Array();credit = new Array();detail = new Array();operation = new Array()
<?
include ("connect_course.inc.php");

$query_delete_temp = "DELETE FROM $Temptable ";
$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);

$query = "Select * From $Subjecttable Where Course_year = '$course_year' ";
$result = mysql_query($query);
$number = mysql_numrows($result);
		$co = 0;
	while ($co < $number) 
		{
	$row = mysql_fetch_array($result);
	$code = htmlspecialchars($row[Code]);
	$name = $row[Name];
	$name = eregi_replace("amp;","",$name);
	$unit = htmlspecialchars($row[Unit]);
	$udetail = htmlspecialchars($row[Unit_detail]);
	$uoperation = htmlspecialchars($row[Unit_operation]);
	print "id[".$co.']="'.$code.'"; desc['.$co.']="'.$name.'"; credit['.$co."]=$unit; detail[".$co."]=$udetail; operation[".$co."]=$uoperation;"; 
	$co++;
	}
	mysql_free_result($result);
	MYSQL_CLOSE();
	$co++;
print 'minCredit=1;' ;
print 'maxCredit=30; max = '.$co.'; pop = 0;';
print 'function isBlank(s) { var len = s.length; for (var i = 0; i < len; i++)';
print '{ if (s.charAt(i) != " ") return false; } return true; }';
print 'function checkSubject(code) { for (var i = 0; i < '.$co.'; i++) ';
?>
{ if (code == id[i]) { return i } } return -1 }
				function checkdetail(index)
 { if (isBlank(document.a.elements[index].value) ) 
	{ return true; }
				var sect = document.a.elements[index +3].value;
 if (isBlank(sect) ) { document.a.elements[index +3].value = "01"; return true; }
				var s = new Number(sect.valueOf() ); var c = checkSubject(document.a.elements[index].value);
 if ( (s > detail[c].valueOf() ) || (s == 0) ) 
	 { alert("Invalid detail " + sect + " �����Ԫ� " + document.a.elements[index].value); return false;  }
 if (s < 10) {
	' document.a.elements[index +3].value =  "0" + s.toString();'
	 document.a.elements[index +3].value =  "" + s.toString();
					}
		 else  {
	document.a.elements[index +3].value =  s.toString();
					} return true; }
function validateForm()
	{  'start function'
		var totalCredit=0; for (var j = 0; j < 51; j += 5) { var index=validate(j);
 if (index==-1 || !checkdetail(j) ) { return; }
 if (index!=-2) { totalCredit += credit[index] }; }
 if (totalCredit > maxCredit) { alert("ŧ����¹������Թ " + maxCredit + " ˹��¡Ե ���͵Դ��ͷ���¹��� / �ӹѡ����¹�"); return; } 
if (totalCredit < minCredit) { alert("ŧ����¹��ͧ����ӡ��� " + minCredit + " ˹��¡Ե ���͵Դ��ͷ���¹��� / �ӹѡ����¹�"); return; } document.a.submit();
 if (pop > 0) { subjectLizst.close(); } }
function validate(j) {var code = document.a.elements[j].value; 
if (isBlank(code) )
	{' document.a.elements[j + 1].value = "";'
	  'document.a.elements[j + 2].value = "";'
	  'document.a.elements[j + 3].value = "";'
return -2; } 
		index = checkSubject(code); 
if (index == -1)
	{ alert("��辺�����Ţͧ�����Ԫ� " + code+" ��س����ҧ���������ǹ�ͧ�����������Ԫҡ�͹"); document.a.elements[j].focus(); return -1; } 
else { 
	document.a.elements[j + 1].value = desc[index] ;
	document.a.elements[j + 2].value = credit[index] ; 
	document.a.elements[j + 3].value = detail[index] ;
	document.a.elements[j + 4].value = operation[index] ;
	return index;
		} 
	} 'end function'
function init() 
{ 

 } 

</script>
</HEAD>
<style type="text/css">
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color:#FFFFFF; text-decoration: none}
a:visited { color:#FFFFFF; text-decoration: none}
a:active { color: #FFFFFF; text-decoration: none}
a:hover { color: #FF0000; text-decoration: none}
</style>
<body bgcolor="#FFFFFF">
<script type="text/javascript" language="JavaScript">init()</script>
<form name="a" action="Frame-2.php" target ="mainFrame" method="post">
<script language="javascript" >
function Brand(tSystem,tBrand,nn)
{
     this.System=tSystem;
     this.Brand=tBrand;
	 this.apid=nn;
}
function Model(tId,tModel,tSystem,tBrand){
     this.ID=tId;
     this.Model=tModel;
     this.System=tSystem;
     this.Brand=tBrand;
}
function getBrands()
{
  var sSelect="<select name='year' class='input200'><option value='' selected></option>";
  var obj0=document.a.type;
  var iSystem=obj0.options[obj0.selectedIndex].value;
   for (var x=1;x<aBrands.length;x++)
    {
           if (aBrands[x].System==iSystem)
           {
                 sSelect=sSelect+"<option value='"+aBrands[x].apid+"'>"+aBrands[x].Brand+"</option>";
           }
     }
    sSelect=sSelect+"</select>";
    document.all.Brands.innerHTML=sSelect;
	
}
var aBrands=new Array();
aBrands[1] = new  Brand('����Ѻ��騺��ԭ�ҵ��','1','1');aBrands[2] = new  Brand('����Ѻ��騺��ԭ�ҵ��','2','2');aBrands[3] = new  Brand('����Ѻ��騺��ԭ�ҵ��','3','3');aBrands[4] = new  Brand('����Ѻ��騺��ԭ�ҵ��','4','4');aBrands[5] = new  Brand('����Ѻ��騺��ԭ�ҵ��','5','5');aBrands[6] = new  Brand('����Ѻ��騺��ԭ���','1','1');aBrands[7] = new  
Brand('����Ѻ��騺��ԭ���','2','2');aBrands[8] = new  
Brand('����Ѻ��騺��ԭ���','3','3');
function fsubmit(){
if ((a.type.value!="")&&(a.year.value!="")&&(a.name.value!="")&&(a.add.value!="")&&(a.reg.value!="")&&(a.email.value!="")){
a.submit()
}else{
alert("��سҡ�͡���������ú")
}
}
</script>
  <table width="612" border="0" cellspacing="0" cellpadding="0" align="left">
  <tr>
      <td width="11">&nbsp;</td>
      <td width="600"> 
        <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td> 
              <table width="550" border="1" cellspacing="0" cellpadding="0" align="center" height="14" bordercolor="#FFFFFF">
                <tr> 
                  <td width="254" height="32"> 
                    <div align="center"><font size="2" face="Tahoma">��ѡ�ٵû�ԭ���͡ 
					<span id="c_country" name="c_country"> 
                    <select name="type" onChange="getBrands();" class="input200" >
                <option selected value=""></option>
                <option  value="����Ѻ��騺��ԭ�ҵ��" ><span id="c_country" name="c_country">����Ѻ��騺��ԭ�ҵ��</span></option>
                <option  value="����Ѻ��騺��ԭ���" ><span id="c_country" name="c_country">����Ѻ��騺��ԭ���</span></option>
              </select>
              </span>
                    </font> </div>
                </td>
                  <td width="112" height="32"> 
                    <div align="center"><font face="Tahoma" size="2">��鹻շ��
					<span id="Brands" name="Brands"> </font> 
                    <font face="Tahoma" size="2"> 
              <select name="year" class="input200">
                <option value="" selected></option>
              </select>
              </span></font></div>
                </td>
                  <td width="121" height="32"> 
                    <div align="center"><font size="2" face="Tahoma">�Ҥ���¹��� 
                    <select name="term">
                      <option value="1">1</option>
                      <option value="2">2</option>
                     </select>
                    </font></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td>
            <table cellpadding="2" cellspacing="2" width="600" align="left" bordercolor="#FFFFFF">
              <tr bgcolor="#EAEAFF"> 
                <td align="middle" width="84"> 
                  <div align="center"><font face="Tahoma" size="2">�����Ԫ�</font></div>
                </td>
                <td align="middle" width="239" bgcolor="#EAEAFF"> 
                  <div align="center"><font face="Tahoma" size="2">�����Ԫ�</font></div>
                </td>
                <td align="middle" width="59"> 
                  <div align="center"><font face="Tahoma" size="2">˹��¡Ե</font></div>
                </td>
                <td align="middle" width="54"> 
                  <div align="center"><font face="Tahoma" size="2">��Ժѵ�</font></div>
                </td>
                <td align="middle" width="54"> 
                  <div align="center"><font size="2" face="Tahoma">������</font></div>
                </td>
                <td align="middle" width="70"> 
                  <div align="center"><font size="1" face="MS Sans Serif"><font face="Tahoma"><font face="Tahoma"><font size="1"><font face="Tahoma"><font face="Tahoma"><font size="3"><font size="2"></font></font></font></font></font></font></font></font></div>
                </td>
              </tr>
              <tr bgcolor="#EAEAFF"> 
                <td width="84" height="29"> 
                  <div align="center"> <font face="Tahoma" size="2"> 
                    <input maxlength="8" name="code" onChange="validate(3)" size="8">
                    </font></div>
                </td>
                <td width="239" height="29"> 
                  <div align="center"> <font face="Tahoma" size="2"> 
                    <input name="cname"  size="40" >
                    </font></div>
                </td>
                <td width="59" height="29"> 
                  <div align="center"> <font face="Tahoma" size="2"> 
                    <input maxlength="2" name="unit" size="2" readonly>
                    </font></div>
                </td>
                <td width="54" height="29"> 
                  <div align="center"> <font face="Tahoma" size="2"> 
                    <input maxlength="2" name="unit_detail" readonly size="2">
                    </font></div>
                </td>
                <td width="54" height="29"> 
                  <div align="center"> <font face="Tahoma" size="2"> 
                    <input maxlength="2" name="unit_opreation" readonly size="2">
                    </font></div>
                </td>
                <td width="70" height="29"> 
                  <div align="center"> <font face="Tahoma" size="2"> 
                    <input type="submit" name="Submit" value="���͡�Ԫ�">
                    </font></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
  <?
	echo "<input type='hidden' name='course_year' value='$course_year'>";
?>
</form>
</body>
</html>
