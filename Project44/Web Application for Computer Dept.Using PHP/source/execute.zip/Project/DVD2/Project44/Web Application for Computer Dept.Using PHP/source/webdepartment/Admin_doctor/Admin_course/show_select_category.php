<html>
<head>
<title>�ʴ���Ǵ�ԪҢͧ��ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
	echo "
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
        <a href='introduce.php?course_year=$course_year'>��ѡ�ٵû�ԭ���͡</a><br>
      <a href='show_select_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
 <a href='show_select_msubject.php?course_year=$course_year'>�������Ԫ���ѡ</a><br>
   <a href='show_select_category.php?course_year=$course_year'>��������Ǵ�Ԫ�</a><br>
      <a href='show_select_group.php?course_year=$course_year'>�������Ң��Ԫ� </a><br>
	   <a href='show_select_subject.php?course_year=$course_year'>����������Ԫ� </a><br>
    <a href='tendency.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a></font> <font face='Tahoma' size='2'><br>
      <a href='index.php'>��Ѻ˹����ѡ </a></font></font></td>
    <td width='619' valign='top' >	";
echo " 
      <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
        <tr> 
          <td height='21' colspan='5' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
              <font face='Tahoma' size='2' color='#515151'><br>
              �š�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ������������� <br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ </font><font size='2' face='Tahoma'><br>
              &nbsp; </font></div>
          </td>
        </tr>
        <tr bgcolor='#F7F7F7'> 
          <td height='31' colspan='5'><font size='2' face='Tahoma'><b>14.3 ����Ԫ����ѡ�ٵ�</b></font></td>
        </tr>";
		$query_1 = "Select * From $Msubjecttable Where Course_year = '$course_year' ";
		$result_1 = mysql_query($query_1);
		$number_1 = mysql_numrows($result_1);
		$i_1=0; 
		if ($i_1 < $number_1)
		{
			while ($row = mysql_fetch_array($result_1)) 
        { 
			$msubject = htmlspecialchars($row[Msubject]);

			echo " 
				<tr> 
          <td height='20' width='43' bgcolor='#F7F7F7'> 
            <div align='center'></div>
            <div align='left'></div>
          </td>
          <td height='20' bgcolor='#EAEAFF' colspan='2'><font size='2' face='Tahoma'><b>$msubject</b></font> 
          </td>
          <td height='20' bgcolor='#EAEAFF' width='80'>&nbsp;</td>
          <td height='20' bgcolor='#F7F7F7' width='47'>&nbsp;</td>
        </tr>";
		$query = "Select * From $Categorytable Where Course_year = '$course_year' AND Msubject = '$msubject' ";
		$result = mysql_query($query);
		$number = mysql_numrows($result);
		$i=0; 
		if ($i < $number)
		{
			while ($row = mysql_fetch_array($result)) 
        { 
			$category = htmlspecialchars($row[Category]);
			$cprogram_unit = htmlspecialchars($row[Cprogram_unit]);
			$detail = $row[Detail];
			echo " 
        <tr> 
          <td height='20' bgcolor='#F7F7F7' width='43'> 
            <div align='center'></div>
            <div align='center'></div>
          </td>
          <td height='20' bgcolor='#EAEAFF' width='78'>&nbsp;</td>
          <td height='20' bgcolor='#EAEAFF' width='293'><a href='show_gsubject.php?course_year=$course_year&&msubject=$msubject&&category=$category'><font face='Tahoma' size='2'>$category</font></a></td>
          <td height='20' bgcolor='#EAEAFF' width='80'> 
            <div align='center'><font face='Tahoma' size='2'>$cprogram_unit&nbsp; ˹��¡Ե</font></div>
          </td>
          <td height='20' bgcolor='#F7F7F7' width='47'>&nbsp;</td>
        </tr> 
        <tr bgcolor='#F7F7F7'> 
          <td height='10' width='43'> 
            <div align='center'> </div>
          </td>
          <td height='10' width='78' bgcolor='#EAEAFF'>&nbsp;</td>
          <td height='10' colspan='2' bgcolor='#EAEAFF'><font face='Tahoma' size='2'>$detail</font></td>
          <td height='10' width='47'>&nbsp;</td>
        </tr>";
			}
		}
	}
}
		echo "
        <tr bgcolor='#F7F7F7'> 
          <td height='10' colspan='5'>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>";
		?>
			
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
