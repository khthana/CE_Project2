<? 
	session_start();
if(($id[0]!='')&&($id[1]=='teacher'))
 {
?>
<html>
<head>
<title>�Ҩ�����ʹ��ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" >
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #006DA2; text-decoration: none}
a:visited { color: #006DA2; text-decoration: none}
a:active { color: #3333FF; text-decoration: none}
a:hover { color: #3333FF; text-decoration: none}
-->
</style>
</head>
<?
include("connect.inc.php");
$dbname=project();
?>
<body  bgcolor=ffffff>
<?
if((!$cetopic)&&(!$edittopic))//!=submit
	{
?>
<table border="0" cellspacing="0" cellpadding="0" width="760" align=center>
  <tr class=a> 
   <td valign="top"> 
<center>
      <br>
    </center>
<form method="post" action="teacherregis.php" onsubmit="return check()" name=form1>
  <table width="760" border="1" bordercolor="#ffffff" cellspacing="0" cellpadding="0" height="100%" align=center>
    <tr class=a>
          <td  valign="top"  bordercolor="#0058B0" height="910"> 
            <table width="760" border="0" height="900" cellpadding="1" cellspacing="1">
              <tr bgcolor="#003F7D" valign="middle" class=a> 
                <td colspan="3" height="30"> 
                  <div align="center"><font class=a>&nbsp;&nbsp;</font>
                    <font color="#FFFFFF" style='font-size:18px'><b>������Ǣ���ç�ҹ</b></font></div>
                </td>
              </tr>
              <tr bgcolor="#0099E3"> 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�����ç�ҹ(������)&nbsp;&nbsp;</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7" class=a>&nbsp;&nbsp; 
                  <input type="text" name="topic_t" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="70" maxlength=200>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3" class=a> 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�����ç�ҹ(�����ѧ���)</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="topic_e" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="70" maxlength=200>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3" class=a> 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�Ҩ�������֡�� 
                    1&nbsp;&nbsp;</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="advisor1"  style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=40>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3" class=a> 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�Ҩ�������֡�� 
                    2&nbsp;&nbsp;</font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="advisor2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=40>
                </td>
              </tr>
              <tr bgcolor="#0099E3" class=a> 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font class=a>�ӹǹ�ѡ�֡�ҷ���ͧ��� 
                    </font></div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <input type="text" name="num" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "  maxlength=2>
                  <font class=a ><font color=#000000><b>&nbsp;&nbsp;&nbsp;��</b></font></font ><font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3" > 
                <td width="23%" bgcolor="#0053A6" > 
                  <div align="center"><font style='font-size:16px'><font color="#FFFFFF">�ѵ�ػ��ʧ��&nbsp;&nbsp;</font></font> 
                  </div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <textarea rows=5 cols=87 name="make1" wrap=virtual style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "></textarea>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3" > 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font style='font-size:16px'><font color="#FFFFFF">�ŷ�����Ѻ&nbsp;&nbsp;</font></font> 
                  </div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <textarea rows=5 cols=87 name="make2" wrap=virtual style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "></textarea>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
              </tr>
              <tr bgcolor="#0099E3" > 
                <td width="23%" bgcolor="#0053A6"> 
                  <div align="center"><font style='font-size:16px'><font color="#FFFFFF">�����������&nbsp;&nbsp;</font></font> 
                  </div>
                </td>
                <td colspan="2" bgcolor="#F4F7F7">&nbsp;&nbsp; 
                  <textarea rows=15 cols=87 name="detail" wrap=virtual style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "></textarea>
                  <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font></td>
              </tr>
              <tr height=50 class=a> 
                <td align=right width="23%" valign="top"></td>
                <td colspan=2 align=center  valign=middle><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#666666 ><b><u>������</u>��</b> ��سҡ�͡������㹪�ͧ���������ͧ���� 
                  <font style="FONT-SIZE: 13px" face="verdana,arial" color=#ff0000 >&nbsp;*</font> 
                  ��ҡѺ�������ú��ǹ����ó�</font></td>
              </tr>
              <tr> 
                <td width="23%" height="44" bgcolor="#FFFFFF" class=a>&nbsp;</td>
                <td width="42%" height="44" bgcolor="#FFFFFF" valign="top" class=a> 
                  <div align="right"> 
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=cetopic>
                    &nbsp;&nbsp; 
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancle>
                  </div>
                </td>
                <td width="46%" height="44" class=a>&nbsp;</td>
              </tr>
            </table>
        
      </td>
    </tr>
  </table>
  <br>
 <br>
</form>

	
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.form1.topic_t.value;
      var v2 = document.form1.topic_e.value;
      var v3 = document.form1.advisor1.value;
	  var v4 = document.form1.num.value;
  	  var v5 = document.form1.make1.value;
      var v6 = document.form1.make2.value;
      var v7 = document.form1.detail.value;
	    	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.topic_t.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.topic_e.focus();           
           return false;
           }
        else if (v3.length==0)
           {
            alert("��س������������ú��ǹ");            
           document.form1.advisor1.focus();           
		   return false;
        }
		else if (v4.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.num.focus();           
		   return false;
           }
      	else if (v5.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.make1.focus();           
		   return false;
           }
      	else if (v6.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.make2.focus();           
		   return false;
           }
      	else if (v7.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.detail.focus();           
		   return false;
           }
		else
           return true;
}
//-->
</script>
<?
}//!=submit
else//submit
  {
$make1=htmlspecialchars($make1);
$make2=htmlspecialchars($make2);
$detail=htmlspecialchars($detail);

$make1=ereg_replace("\n","<br>",$make1);
$make2=ereg_replace("\n","<br>",$make2);
$detail=ereg_replace("\n","<br>",$detail);

$make1=ereg_replace(" ","&nbsp;",$make1);
$make2=ereg_replace(" ","&nbsp;",$make2);
$detail=ereg_replace(" ","&nbsp;",$detail);

 if($edittopic=='Submit')
	{
		//update ������ŧ���ҧ topicproject
       $sql="update topicproject  set advisor1='$advisor1',advisor2='$advisor2',topic_t='$topic_t',topic_e='$topic_e',num='$num',make1='$make1',make2='$make2',detail='$detail' where id='$idtopic'";
       $dbquery=mysql_db_query($dbname,$sql)or die("error2");
	}
 elseif($cetopic=='Submit')
	{
 $d1=date("d-m-Y");
 //��������ŧ���ҧ topicproject
$sql="insert into topicproject (advisor1,advisor2,topic_t,topic_e,num,make1,make2,detail,codeadmin,date) values ('$advisor1','$advisor2','$topic_t','$topic_e','$num','$make1','$make2','$detail','$id[0]','$d1')";
$dbquery=mysql_db_query($dbname,$sql)or die("error3");
    }     
?>
<div align="center">
<br>
 <br>  
<p>
	<font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#0033FF"><b>Complete</b></font></font></p>
  <p><font class=a><font color="#0033FF">�����Ţͧ�س�١�Ѵ��ŧ�ҹ���º�������Ǥ�Ѻ</font></font></p>  
  <a href='indexs.php' class=home>HOME</a>
  <hr width="400">
  <br>
</div>
<?  
  }//submit
//�Դ�ҹ������
closedb();
?>
</body>
</html>
<?
}
else
 {
?>
<div align="center">
<br>  
<p>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҡ�͡������㹪�ͧ���������ͧ����
	&nbsp;*&nbsp; ��ҡѺ�������ú��ǹ����ó�</font></font></p>
	
  <p>&nbsp;</p>
</div> 

<div align="center">
<br>  
<p><font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҵ�Ǩ�ͺ username&password �ͧ�س�����ա����</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div> 
<?
 }
