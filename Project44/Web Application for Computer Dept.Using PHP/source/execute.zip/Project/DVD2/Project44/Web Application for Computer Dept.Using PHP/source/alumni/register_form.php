<?php
	session_start();
	session_destroy();
	session_unset();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left"> 
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><img src="image/logo-kmitl.jpg" width="139" height="137"></font></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="137">
                <tr> 
                  <td><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><img src="image/logo-alumni.jpg" width="600" height="80"></font></td>
                </tr>
                <tr> 
                  <td> 
                    <table width="100%" border="0" cellspacing="1" cellpadding="1"align="left" bordercolor="#000000" bgcolor="#000000">
                      <tr class = BNFont1 align="center"> 
                        <td bgcolor="#99CCFF" width="25%"><font size="3" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><a href="index.php"><b>Home</b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="register_form.php"><b>ŧ����¹</b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="login.php"><b>��䢢�����</b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td> 
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000" height="100%">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></font></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="normal.php"><b>�Ҥ����</b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><a href="cont.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></font></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="cont.php"><b>�Ҥ������ͧ</b></a></font> 
                        </td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                        <td width="78%" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        <td bgcolor="#CCCCFF" height="15"> 
                          <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="1" color="#FFFFFF" class="fsize8" align="center"><b>&nbsp;<font color="#000000" size="2">����</font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                    </font></div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                    </font></div>
                                </td>
                              </tr>
                            </table>
                          </td>
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF" height="100%">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624"> 
              <div align="center"> 
                <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                  <tr> 
                    <td> 
                      <div align="center"><font color="#000000" class="12px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><b><font size="4">��سҡ�͡���������١��ͧ 
                        ��Ъ�ͧ���������ͧ���� <font color=red>*</font> ��ͧ������ú 
                        </font></b></font> 
                        <hr>
                      </div>
                    </td>
                  </tr>
                  <tr> 
                    <td height="100%"> 
                      <form name=register action="alumni_register.php" method="post">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr> 
                            <td> 
                              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">���ʹѡ�֡�� 
                                    <font color="#FF0000">*</font></font> </td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input  size=20 name=std_id>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="12px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">��蹷��<font color="#FF0000"> 
                                    *</font></font> </td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input type=text size=20 name=std_class>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="12px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">�ѡ�֡�� 
                                    <font color="#FF0000">*</font></font> </td>
                                  <td width="76%"><font class="12px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input type=radio name=std_type value=������ͧ>
                                    ������ͧ 
                                    <input type=radio name=std_type value=����>
                                    ���� </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">����-���ʡ�� 
                                    <font color="#FF0000">*</font></font> </td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_fullname>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="12px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">�� 
                                    </font></td>
                                  <td width="76%"><font class="12px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input type=radio name=std_type1 value=���>
                                    ��� 
                                    <input type=radio name=std_type1 value=˭ԧ>
                                    ˭ԧ </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">������� 
                                    </font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_nick>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">�ѹ�Դ 
                                    </font></td>
                                  <td width="76%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">�ѹ 
                                    <select name="days">
                                      <option value="�ѹ���">�ѹ��� 
                                      <option value="�ѧ���">�ѧ��� 
                                      <option value="�ظ">�ظ 
                                      <option value="����ʺ��">����ʺ�� 
                                      <option value="�ء��">�ء�� 
                                      <option value="�����">����� 
                                      <option value="�ҷԵ��">�ҷԵ�� 
                                    </select>
                                    ��� 
                                    <select name="day">
                                      <option>1 
                                      <option>2 
                                      <option>3 
                                      <option>4 
                                      <option>5 
                                      <option>6 
                                      <option>7 
                                      <option>8 
                                      <option>9 
                                      <option>10 
                                      <option>11 
                                      <option>12 
                                      <option>13 
                                      <option>14 
                                      <option>15 
                                      <option>16 
                                      <option>17 
                                      <option>18 
                                      <option>19 
                                      <option>20 
                                      <option>21 
                                      <option>22 
                                      <option>23 
                                      <option>24 
                                      <option>25 
                                      <option>26 
                                      <option>27 
                                      <option>28 
                                      <option>29 
                                      <option>30 
                                      <option>31 
                                    </select>
                                    <select name="mount">
                                      <option value="���Ҥ�">���Ҥ� 
                                      <option value="����Ҿѹ��">����Ҿѹ�� 
                                      <option value="�չҤ�">�չҤ� 
                                      <option value="����¹">����¹ 
                                      <option value="����Ҥ�">����Ҥ� 
                                      <option value="�Զع�¹">�Զع�¹ 
                                      <option value="�á�Ҥ�">�á�Ҥ� 
                                      <option value="�ԧ�Ҥ�">�ԧ�Ҥ� 
                                      <option value="�ѹ��¹">�ѹ��¹ 
                                      <option value="���Ҥ�">���Ҥ� 
                                      <option value="��Ȩԡ�¹">��Ȩԡ�¹ 
                                      <option value="�ѹ�Ҥ�">�ѹ�Ҥ� 
                                    </select>
                                    �.�. 
                                    <input size=10 name=year>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">����ѷ(���ӧҹ) 
                                    </font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <textarea name=std_work rows=3 cols=40></textarea>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">���˹� 
                                    </font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_position>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">������� 
                                    (��������)</font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <textarea name=std_address_born rows=3 cols=40></textarea>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">������� 
                                    (�Ѩ�غѹ)</font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <textarea name=std_address_now rows=3 cols=40></textarea>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">���Ѿ�� 
                                    (��ҹ�ѡ)</font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_tel_home>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">���Ѿ�� 
                                    (���ӧҹ) </font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_tel_work>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">��Ͷ��,ྨ���� 
                                    </font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_pager>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Icq</font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_icq>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Email 
                                    <font color="#FF0000">*</font></font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_email>
                                    <font class="11px" color="#990000">��س���������� 
                                    �������ö�Դ��������͡óշ���ҹ��� password</font></font> 
                                  </td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">���ྨ 
                                    </font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input name=std_homepage size="50">
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Login 
                                    <font color="#FF0000">*</font></font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_username>
                                    </font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Password<font color="#FF0000"> 
                                    *</font></font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_password1 type=password>
                                    <font class=11px> <font color="#990000">��Ҵ����ա���դ����Ӥѭ�������ö����ѭ�ѡɳ�������</font></font></font></td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Password 
                                    again<font color="#FF0000"> *</font></font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_password2 type=password>
                                    <font class=11px> <font color="#990000">��Ǩ�ͺ������촴�������������������ѧ�������</font></font></font> 
                                  </td>
                                </tr>
                                <tr> 
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Question<font color="#FF0000"> 
                                    *</font></font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_question type=text>
                                    <font class=11px></font></font></td>
                                </tr>
                                <tr>
                                  <td width="24%"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">Answer<font color="#FF0000">*</font></font></td>
                                  <td width="76%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                    <input size=20 name=std_answer type=text>
                                    <font class="11px" color="#990000">��سҨӤӵͺ���ͷ�ҹ��� 
                                    password</font></font></td>
                                </tr>
                              </table>
                            </td>
                          </tr>
                          <tr> 
                            <td> 
                              <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
                                <input type=submit value=Submit name=submit>
                                <input type=reset value=Reset name=reset>
                                </font></div>
                            </td>
                          </tr>
                        </table>
                      </form>
                    </td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>
</center>
<font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
<script language="JavaScript">
<!--

function checks()
{
      var v1 = document.SearchForm.search.value;
        if ( v1.length==0)
           {
           alert("��سһ�͹�ӷ���ͧ��ä���");
           document.SearchForm.search.focus();
           return false;
           }
		 else
           return true;
}
//-->
</script>
</font>
</body>
</html>
