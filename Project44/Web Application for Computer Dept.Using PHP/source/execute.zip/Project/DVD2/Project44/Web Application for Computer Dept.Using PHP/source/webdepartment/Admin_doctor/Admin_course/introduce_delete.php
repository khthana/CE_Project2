<html>
<head>
<title>ź��������ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2" bgcolor="#3E3EA8"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<font face="Tahoma" size="2"><table width="778" border="0" cellspacing="0" cellpadding="0"> 
</font> 
<?
include ("connect_course.inc.php");
echo "
<tr> 
  <td width='11'>&nbsp;</td>
  <td width='14' bgcolor='#EAEAFF'>&nbsp;</td>
 <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      ź��ѡ�ٵû�ԭ���͡</font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_delete_course.php?course_year=$course_year' target ='_parent'>ź�ç���ҧ��ѡ�ٵ�</a><br>
	   <a href='structure_delete_main_subject.php?course_year=$course_year' target ='_parent'> ź�������Ԫ���ѡ</a><br>
	  <a href='structure_delete_category.php?course_year=$course_year' target ='_parent'>ź��������Ǵ�Ԫ�</a><br>
      <a href='structure_delete_group.php?course_year=$course_year' target ='_parent'>ź�������Ң��Ԫ� </a><br>
		<a href='Doctor/Delete/Subject/delete_subject.php?course_year=$course_year' target ='_parent'>ź����������Ԫ� <br>
      <a href='Doctor/Delete/Course/delete_course.php?course_year=$course_year' target ='_parent'>�ǡ�èѴ�Ԫ����¹</a></font> <font size='2' face='Tahoma'><br>
      <a href='index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;
      </td>
    <td width='619' valign='top'>";
	
	$query = "Select * From $Introducetable Where Course_year = '$course_year' order by Ctname ASC LIMIT 0, 50 ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$ctname = htmlspecialchars($row[Ctname]);
	$cename = htmlspecialchars($row[Cename]);
	$ftname = htmlspecialchars($row[Ftname]);
	$stname = htmlspecialchars($row[Stname]);
	$fename = htmlspecialchars($row[Fename]);
	$sename = htmlspecialchars($row[Sename]);
	
	$accept = $row[Accept];
	$philosophy_article = $row[Philosophy_Article];
	$program = $row[Program];
	$property = $row[Property];
	$test = $row[Test];
	$csystem = $row[Csystem];
	$ctime = $row[Ctime];
	$register = $row[Register];
	$process = $row[Process];

	$myear1 = $row[Myear1];
	$myear2 = $row[Myear2];
	$myear3 = $row[Myear3];
	$myear4 = $row[Myear4];
	$myear5 = $row[Myear5];

	$m1_year1 = $row[M1_year1];
	$m1_year2 = $row[M1_year2];
	$m1_year3 = $row[M1_year3];
	$m1_year4 = $row[M1_year4];
	$m1_year5 = $row[M1_year5];
	
	$m2_year1 = $row[M2_year1];
	$m2_year2 = $row[M2_year2];
	$m2_year3 = $row[M2_year3];
	$m2_year4 = $row[M2_year4];
	$m2_year5 = $row[M2_year5];

	$m3_year1 = $row[M3_year1];
	$m3_year2 = $row[M3_year2];
	$m3_year3 = $row[M3_year3];
	$m3_year4 = $row[M3_year4];
	$m3_year5 = $row[M3_year5];

	$msum1 = $row[Msum1];
	$msum2 = $row[Msum2];
	$msum3 = $row[Msum3];
	$msum4 = $row[Msum4];
	$msum5 = $row[Msum5];

	$mend1 = $row[Mend1];
	$mend2 = $row[Mend2];
	$mend3 = $row[Mend3];
	$mend4 = $row[Mend4];
	$mend5 = $row[Mend5];
	

	$dyear1 = $row[Dyear1];
	$dyear2 = $row[Dyear2];
	$dyear3 = $row[Dyear3];
	$dyear4 = $row[Dyear4];
	$dyear5 = $row[Dyear5];

	$d1_year1 = $row[D1_year1];
	$d1_year2 = $row[D1_year2];
	$d1_year3 = $row[D1_year3];
	$d1_year4 = $row[D1_year4];
	$d1_year5 = $row[D1_year5];
	
	$d2_year1 = $row[D2_year1];
	$d2_year2 = $row[D2_year2];
	$d2_year3 = $row[D2_year3];
	$d2_year4 = $row[D2_year4];
	$d2_year5 = $row[D2_year5];

	$d3_year1 = $row[D3_year1];
	$d3_year2 = $row[D3_year2];
	$d3_year3 = $row[D3_year3];
	$d3_year4 = $row[D3_year4];
	$d3_year5 = $row[D3_year5];

	$d4_year1 = $row[D4_year1];
	$d4_year2 = $row[D4_year2];
	$d4_year3 = $row[D4_year3];
	$d4_year4 = $row[D4_year4];
	$d4_year5 = $row[D4_year5];

	$d5_year1 = $row[D5_year1];
	$d5_year2 = $row[D5_year2];
	$d5_year3 = $row[D5_year3];
	$d5_year4 = $row[D5_year4];
	$d5_year5 = $row[D5_year5];


	$dsum1 = $row[Dsum1];
	$dsum2 = $row[Dsum2];
	$dsum3 = $row[Dsum3];
	$dsum4 = $row[Dsum4];
	$dsum5 = $row[Dsum5];

	$dend1 = $row[Dend1];
	$dend2 = $row[Dend2];
	$dend3 = $row[Dend3];
	$dend4 = $row[Dend4];
	$dend5 = $row[Dend5];
	$place_tool = $row[Place_Tool];
	echo "
	  <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
        <tr valign='middle'> 
          <td colspan='2' height='103' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե 
              �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
              ��ѡ�ٵ�$course_year&nbsp;<br>
              ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
          </td>
        </tr>
        <tr bgcolor='#F7F7F7'> 
          <td colspan='2' height='27'><b><font size='2' color='#000000' face='Tahoma'>1. 
            ������ѡ�ٵ� </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font size='2' color='#000000' face='Tahoma'>����������</font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$ctname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font size='2' color='#000000' face='Tahoma'>���������ѧ���</font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$cename&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' height='27' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'><b>2. 
            ���ͻ�ԭ��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$ftname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$stname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font size='2' color='#000000' face='Tahoma'>������� 
            (�ѧ���)</font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$fename&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2' color='#000000'>������� 
            (�ѧ���)</font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$sename&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' height='27' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>3. 
            ˹��§ҹ�Ѻ�Դ�ͺ</b></font></td>
        </tr>
        <tr> 
          <td  bgcolor='#F7F7F7' height='27'></td>
          <td  bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$accept&nbsp;</font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2' color='#000000'><b>4. 
              ��Ѫ������ѵ�ػ��ʧ��ͧ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$philosophy_article&nbsp;</font></td>
          </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>5. 
            ��˹�����Դ�͹ </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$program&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>6.</b></font><b><font face='Tahoma' size='2'> 
            �س���ѵԢͧ�������֡�� </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$property&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>7. 
            ��äѴ���͡�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$test&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>8. 
            �к�����֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$csystem&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>9. 
            �������ҡ���֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$ctime&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>10.</b></font><b><font face='Tahoma' size='2'> 
            ���ŧ����¹���¹ </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$register&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>11. 
            ����Ѵ����С������稡���֡��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'  height='27'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$process&nbsp;</font></td>
        </tr>
     <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='27'><b><font face='Tahoma' size='2'>12. 
              �ӹǹ�ѡ�֡��</font></b></td>
          </tr>
          <tr> 
            <td width='98' bgcolor='#F7F7F7' height='399'><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#EAEAFF' height='399'> 
              <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center'>
                <tr> 
                  <td colspan='6' height='25'> <b><font size='2' face='Tahoma'>����Ѻ��騺��ԭ��� 
                    (3 ��) </font></b> </td>
                </tr>
                <tr> 
                  <td rowspan='2'> 
                    <div align='center'></div>
                    <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                  </td>
                  <td colspan='5' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>�ա���֡��</font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$myear1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$myear2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$myear3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$myear4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$myear5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      1</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m1_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $m1_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $m1_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $m1_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m1_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      2</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m2_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m2_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m2_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m2_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m2_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      3</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m3_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m3_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m3_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m3_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$m3_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>���</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$msum1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$msum2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$msum3 &nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$msum4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $msum5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>�Ҵ��ҨШ�����֡��</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $mend1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$mend2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $mend3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $mend4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $mend5&nbsp;
                      </font></div>
                  </td>
                </tr>
              </table>
              <b></b> 
              <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center'>
                <tr> 
                  <td colspan='6' height='25'> <b><font size='2' face='Tahoma'>����Ѻ��騺��ԭ�ҵ�� 
                    (5 ��) </font></b> </td>
                </tr>
                <tr> 
                  <td rowspan='2'> 
                    <div align='center'></div>
                    <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                  </td>
                  <td colspan='5' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>�ա���֡��</font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$dyear1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$dyear2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$dyear3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$dyear4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$dyear5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      1</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d1_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d1_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d1_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d1_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d1_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      2</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d2_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d2_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d2_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d2_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d2_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      3</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d3_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d3_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d3_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d3_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $d3_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      4 </font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d4_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d4_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d4_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d4_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d4_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      5 </font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d5_year1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d5_year2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d5_year3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d5_year4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>$d5_year5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>���</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dsum1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dsum2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dsum3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dsum4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dsum5&nbsp;
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'>�Ҵ��ҨШ�����֡��</font></div>
                  </td>
                  <td width='75' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dend1&nbsp;
                      </font></div>
                  </td>
                  <td width='68' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dend2&nbsp;
                      </font></div>
                  </td>
                  <td width='73' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dend3&nbsp;
                      </font></div>
                  </td>
                  <td width='63' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dend4&nbsp;
                      </font></div>
                  </td>
                  <td width='64' height='25'> 
                    <div align='center'><font face='Tahoma' size='2'> $dend5&nbsp;
                      </font></div>
                  </td>
                </tr>
              </table>
              <b></b> </td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>13. 
              ����ӹ�¤����дǡ㹡���֡�� �鹤�������Ԩ��</b></font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#EAEAFF' height='27'><font face='Tahoma' size='2'>$place_tool
              </font></td>
          </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='27'>
		<div align='center'><font size='2' face='Tahoma'><A HREF='check_delete_introduce.php?course_year=$course_year'>ź��������ѡ�ٵû�ԭ���͡</A></font></div>
		</td>
        </tr>
      </table>
    </td>
  </tr>
</table>";
		}
	}
	MYSQL_CLOSE();
  ?>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
          <div align="center"><font face="Tahoma" size="1">Department of Computer 
            Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
          <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
