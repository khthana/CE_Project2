<html>
<head>
<title>�ʴ�����������Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #9900CC; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
  <?
include ("connect_course.inc.php");
	echo "
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='10' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='138' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce.php?course_year=$course_year'>��ѡ�ٵû�ԭ���͡</a><br>
    <a href='show_select_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
 <a href='show_select_msubject.php?course_year=$course_year'>�������Ԫ���ѡ</a><br>
   <a href='show_select_category.php?course_year=$course_year'>��������Ǵ�Ԫ�</a><br>
      <a href='show_select_group.php?course_year=$course_year'>�������Ң��Ԫ� </a><br>
	   <a href='show_select_subject.php?course_year=$course_year'>����������Ԫ� </a><br>
    <a href='tendency.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a></font> <font face='Tahoma' size='2'><br>
      <a href='index.php'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;</td>
    <td width='619' valign='top' >
	<table width='600' border='0' cellspacing='0' cellpadding='0' align='center' >
        <tr> 
          <td bgcolor='#F7F7F7' height='123'> 
            <div align='center'><font face='Tahoma' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե 
              �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp;</font> </div>
          </td>
        </tr>
      </table>";
		  $query_1 = "Select * From $Msubjecttable Where Course_year = '$course_year' ";
		$result_1 = mysql_query($query_1);
		$number_1 = mysql_numrows($result_1);
		$i_1=0; 
		if ($i_1 < $number_1)
		{
			  echo "<table width='600' cellspacing='0' cellpadding='0' align='center' border='1' bordercolor='#FFFFFF'>";
			while ($row = mysql_fetch_array($result_1)) 
        { 
		$msubject = htmlspecialchars($row[Msubject]);
	    echo "<tr>
					<td colspan='9' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>$msubject</b></font></td>
					</tr>";
    $query_category ="Select * From $Categorytable Where Course_year = '$course_year' AND Msubject = '$msubject' ";
	$result_category = mysql_query($query_category);
	$cnumber = mysql_numrows($result_category);
	$ci=0;
	if ($ci < $cnumber)
	{
			while ($row = mysql_fetch_array($result_category)) 
		{
		$category = htmlspecialchars($row[Category]); 
		$detail = htmlspecialchars($row[Detail]); 
		$detail = eregi_replace('<br>',chr(13),$row[Detail]);
        $gsubject = htmlspecialchars($row[Gsubject]); 
		echo " 
        <tr> 
          <td width='14' bgcolor='#F7F7F7'>&nbsp;</td>
          <td bgcolor='#F7F7F7' colspan='8'><font face='Tahoma' size='2'><b>$category</b></font></td>
        </tr>
        <tr> 
          <td bgcolor='#F7F7F7' colspan='2'>&nbsp;</td>
          <td colspan='7' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>$detail</font></td>
        </tr>";
		$query_group = "Select * From $Gsubjecttable Where Course_year = '$course_year' AND Msubject = '$msubject' AND Category ='$category' ";
		$result_group = mysql_query($query_group); 
        $gnumber = mysql_numrows($result_group);
		$gi=0;
		if ($gi < $gnumber)
		{ 
        while ($row = mysql_fetch_array($result_group))
		{
		$gsubject = htmlspecialchars($row[Gsubject]); 
        $gdetail = $row[Gdetail];
		$gdetail = eregi_replace('<br>',chr(13),$row[Gdetail]);
		echo " 
        <tr> 
          <td bgcolor='#F7F7F7' colspan='3'><font face='Tahoma' size='2'>&nbsp;</font></td>
          <td colspan='6' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>$gsubject</font> 
          </td>
        </tr>
        <tr> 
          <td colspan='4' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>&nbsp;</font></td>
          <td bgcolor='#F7F7F7' colspan='5'><font face='Tahoma' size='2'>$gdetail</font></td>
        </tr>";
		$query_subject = "Select * From $Subjecttable Where  Gsubject = '$gsubject' AND Msubject = '$msubject' AND Category = '$category' AND Course_year = '$course_year' ";
		$result_subject = mysql_query($query_subject);
		$snumber = mysql_numrows($result_subject); 
        $si=0;
		if ($si < $snumber)
		{
		while ($row = mysql_fetch_array($result_subject)) 
        {
		$code = htmlspecialchars($row[Code]); 
		$name = htmlspecialchars($row[Name]); 
		$name = eregi_replace("amp;","",$name);
        $ename = htmlspecialchars($row[Ename]);
		$unit = htmlspecialchars($row[Unit]); 
        $unit_detail = htmlspecialchars($row[Unit_detail]);
		$unit_operation = htmlspecialchars($row[Unit_operation]);
		echo " 
        <tr bgcolor='#EAEAFF'> 
          <td colspan='5'><font face='Tahoma' size='2'></font> 
            <div align='center'></div>
          </td>
          <td width='88'> 
            <div align='center'><font face='Tahoma' size='2'>$code</font></div>
          </td>
          <td width='283'><font face='Tahoma' size='2'>&nbsp;<a href='show_subject.php?course_year=$course_year&&msubject=$msubject&&category=$category&&gsubject=$gsubject&&code=$code'>$name</a></font></td>
          <td width='60'> 
            <div align='center'><font face='Tahoma' size='2'>$unit ($unit_detail-$unit_operation)</font></div>
          </td>
          <td width='71'> 
            <div align='center'></div>
          </td>
        </tr>
        <tr bgcolor='#EAEAFF'> 
          <td colspan='6'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'></font></td>
          <td width='283'><font face='Tahoma' size='2'>&nbsp;$ename</font></td>
          <td width='60'> 
            <div align='center'></div>
          </td>
          <td width='71'> 
            <div align='center'></div>
          </td>
        </tr>";
		}// end while of select subject
		}// end if of select subject 
		else 
        {
			echo" 
        <tr> 
          <td colspan='9' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma' size='2'>����բ���������Ԫ�</font></div>
          </td>
        </tr>";
			}
		} // end while of select group 
		}// end if of select group 
		else
			{
				$query_subject = "Select * From $Subjecttable Where  Gsubject = '' AND Msubject = '$msubject' AND Category = '$category' AND Course_year = '$course_year' ";
		$result_subject = mysql_query($query_subject);
		$snumber = mysql_numrows($result_subject); 
        $si=0;
			if ($si < $snumber)
			{
		while ($row = mysql_fetch_array($result_subject)) 
				{
		$code = htmlspecialchars($row[Code]); 
		$name = htmlspecialchars($row[Name]); 
		$name = eregi_replace("amp;","",$name);
        $ename = htmlspecialchars($row[Ename]);
		$unit = htmlspecialchars($row[Unit]); 
        $unit_detail = htmlspecialchars($row[Unit_detail]);
		$unit_operation = htmlspecialchars($row[Unit_operation]);
echo " 
        <tr bgcolor='#EAEAFF'> 
          <td colspan='5'><font face='Tahoma' size='2'></font> 
            <div align='center'></div>
          </td>
          <td width='88'> 
            <div align='center'><font face='Tahoma' size='2'>$code</font></div>
          </td>
          <td width='283'><font face='Tahoma' size='2'>&nbsp;<a href='show_subject.php?course_year=$course_year&&msubject=$msubject&&category=$category&&gsubject=$gsubject&&code=$code'>$name</a></font></td>
          <td width='60'> 
            <div align='center'><font face='Tahoma' size='2'>$unit ($unit_detail-$unit_operation)</font></div>
          </td>
          <td width='71'> 
            <div align='center'></div>
          </td>
        </tr>
        <tr bgcolor='#EAEAFF'> 
          <td colspan='6'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'></font></td>
          <td width='283'><font face='Tahoma' size='2'>&nbsp;$ename</font></td>
          <td width='60'> 
            <div align='center'></div>
          </td>
          <td width='71'> 
            <div align='center'></div>
          </td>
        </tr>";
				}
			}
			}
		} // end while of select category 
	}// end if of select category
	}// end while of select msubject	
		echo " 
        <tr> 
          <td   colspan='9' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
        </tr>			 
      </table>";
		} // end  if of select msubject	
	else
	{ 
	 echo"
			<table width='604' cellspacing='0' cellpadding='0' align='center' border = '1' bordercolor='#FFFFFF'>
			<tr> 
			<td colspan='9' bgcolor='#F7F7F7'>
			<div align='center'><font face='Tahoma' size='2'>����բ���������Ԫ�</font></div>
			</td>
			</tr>
		 	 <tr> 
			<td colspan='9' bgcolor='#F7F7F7'>
			<div align='center'><font face='Tahoma' size='2'>&nbsp;</font></div>
			</td>
			</tr>
		 </table>";
			} // end else if of select category

	MYSQL_CLOSE();
?>
</td>
</tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
