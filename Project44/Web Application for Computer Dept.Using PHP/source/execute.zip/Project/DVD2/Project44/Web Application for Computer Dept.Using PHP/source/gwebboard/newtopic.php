<?session_start();
if($id[0])
{
include("connect.inc.php");
$dbname=gwebboard();
?>
 <html>
<head>
<title>newtopic</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
 <body bgcolor="#FFFFFF">
<table border=0  width="760" align=left height="640">
  <tr class=a> 
    <td valign="top" height="605" align="left"> 
      <div align="left">
        <table width="100%" border="0">
          <tr class=a>
            <td width="51%"><img src="images/logo.gif" width="305" height="74"></td>
            <td width="46%"><font color="#FF0066" ><b>NEW TOPIC</b></font></td>
            <td width="3%">&nbsp;</td>
          </tr>
        </table>
      </div>
     <br>
	 <form  action='gwebboard.php' method=post onsubmit="return check();" name=newtopic enctype="multipart/form-data"> 
        <INPUT TYPE="hidden" name=nameboards value=<?print($nameboards);?>>
      <table cellspacing=1 cellpadding=5 width=656 border=0 align=center bordercolor="#FFFFFF">
        <tr> 
          <td align=right bgcolor=#C4E1E1><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>��Ǣ�� <font 
            face=verdana>:</font></b></font></font></td>
          <td bgcolor=#E2E2E2><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <input 
            style="FONT-SIZE: 13px; Tahoma,Ms Sans Serif" name=topic size=40 maxlength=200>
            </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font></td>
        </tr>
        
		<TR vAlign=top> 
          <TD align=right bgColor=#C4E1E1><FONT 
            face="Tahoma,Ms Sans Serif"><FONT 
            style="FONT-SIZE: 13px"><B>��������´ <FONT 
            face=verdana>:</FONT></B></FONT></FONT></TD>
          <TD bgColor=#E2E2E2> 
            <TEXTAREA style="FONT-SIZE: 18px; Tahoma,Ms Sans Serif" name=data rows=10 wrap=VIRTUAL cols=62></TEXTAREA>
            <FONT style="FONT-SIZE: 13px" face=verdana,arial color=#ff0000 
            >&nbsp;*</FONT></TD>
        </TR>
        
		<tr> 
          <td align=right bgcolor=#C4E1E1><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>ICQ <font 
            face=verdana>:</font></b></font></font></td>
          <td bgcolor=#E2E2E2><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <input 
            style="FONT-SIZE: 13px; Tahoma,Ms Sans Serif" name=icq size=25 maxlength=100>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style="FONT-SIZE: 13px; FONT-FAMILY: verdana" type=checkbox CHECKED 
            name=sent_mail value=1>
            &nbsp;<font color=#990033><font 
            face=Verdana>(</font>�駷ҧ������������դ��ҵͺ<font 
            face=Verdana>)</font></font></font></td>
        </tr>
        
		<?
	//		include("connect.inc.php");
     //       $dbname=gwebboard();
			//�� admin 㹵��ҧ admin
	//	   $sql="select * from admin where nameboard='$nameboards' and email='$id[0]'";
	//	   $dbquery=mysql_db_query($dbname,$sql)or die("error");
	//		$rows=mysql_num_rows($dbquery);	  
	//		if($rows>0)
	//		{
			?>
        <tr> 
          <td align=right bgcolor=#C4E1E1><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 14px"><b>File <font 
            face=verdana>:</font></b></font></font></td>
          <td bgcolor=#E2E2E2><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <input style="FONT-SIZE: 13px; WIDTH: 250px; height:22px;Tahoma,Ms Sans Serif" type=file  name=filegroup>
            &nbsp;<FONT color=#990033><FONT 
            face=Verdana>(</FONT>upload ������Թ 3 M<FONT 
            face=Verdana>)</FONT></FONT></FONT> </font></td>
        </tr>
        <?
	//		}//����� admin ��Ṻ file ��
			?>
        
		
        <tr valign=top> 
          <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp;</font></td>
          <td><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
            <font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
        </tr>
        <tr> 
          <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp;</font></td>
          <td><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif"> 
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit name=check_newtopic value=Submit>
            &nbsp;&nbsp; 
            <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancel>
            </font></td>
        </tr>
        <?
   	//�� id ����ҡ�ش�ҡ���ҧ nameboard
    $sql="select * from $nameboards order by id Desc";
	$dbquery=mysql_db_query($dbname,$sql)or die("error");
	$result=mysql_fetch_array($dbquery);
	$idtopic_new=$result[id]+1;
         ?>
	<INPUT TYPE="hidden" name=idtopic_new value=<?print($idtopic_new);?>>
    </form>
      </table>
      <br>
	  <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr class=a> 
          <td class=a> 
            <div align="center"><font color="#000080">Department of Computer Engineering 
              Faculty of Engineering King Mongkut's Institute of Technology<br>
              Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
          </td>
        </tr>
        <tr> 
          <td height="8" class=a> 
            <hr align="center" width="550" >
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center"></div>
          </td>
        </tr>
      </table>
      </td>
  </tr>
</table>
<script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.newtopic.topic.value;
      var v2 = document.newtopic.data.value;
  	      	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.newtopic.topic.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.newtopic.data.focus();           
           return false;
           }
    	else
            return true;
}
//-->
</script>
</body>
</html>
<?
//�Դ�ҹ������
closedb();
}
?>