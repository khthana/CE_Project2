<html>
<head>
<title>�ǡ�èѴ�Ԫ����¹</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="620" border="0" cellspacing="0" cellpadding="0" align="left">
<tr> 
    <td>
<? 
include ("connect_course.inc.php");
$query_delete_temp = "DELETE FROM $Temptable ";
$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);

	$i =1;
	$sum=0;
	$sum_detail=0;
	$sum_operation=0;
	// start Show Course
	$query = "Select Code,Name From $Coursetable Where Type = '$type' AND Term = '$term' AND Year ='$year' AND Course_year = '$course_year' order by Code ";
	/*
	$query = "Select * From $Coursetable,$Subjecttable Where $Coursetable.Code=$Subjecttable.Code AND $Coursetable.Year='$year' AND $Coursetable.Term='$term' AND $Coursetable.Type='$type' AND $Coursetable.Course_year='$course_year' AND $Subjecttable.Course_year='$course_year' order by $Subjecttable.Code ASC LIMIT 0, 50 "; 
	*/
	$result = mysql_db_query($dbName,$query); 
	if ($result)
	{
echo "<Form  method='post' action='update.php' >
  <table width='97%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center' height='326'>
    <tr bgcolor='#F7F7F7'> 
      <td colspan='4' height='20'> 
        <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵ���Һѳ�Ե 
          �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
          ��ѡ�ٵ�<font color='#9900CC'>$course_year</font><br>
          ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
          ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
      </td>
    </tr>
    <tr bgcolor='#DAEEFE'> 
      <td colspan='4' height='20'> 
        <div align='center'><font size='2' face='Tahoma'>��ѡ�ٵû�ԭ��� <font color='#9900CC'>$type</font></font></div>
      </td>
    </tr>
    <tr bgcolor='#F7F7F7'> 
      <td colspan='4' height='20'> 
        <div align='center'><font face='Tahoma' size='2'>��鹻շ�� <font color='#9900CC'>$year</font> 
          �Ҥ���¹��� <font color='#9900CC'>$term</font></font></div>
      </td>
    </tr>
    <tr bgcolor='#DAEEFE'> 
      <td width='42' height='20' bgcolor='#DAEEFE'> 
        <div align='center'><font size='2' face='Tahoma'>���͡</font></div>
     
      </td>
      <td width='90' height='20'> 
        <div align='center'><font size='2' face='Tahoma'>�����Ԫ�</font></div>
      </td>
      <td width='441' height='20' bgcolor='#DAEEFE'> 
        <div align='center'><font size='2' face='Tahoma'>�����Ԫ�</font></div>
      </td>
      <td width='200' height='20'> 
        <div align='center'><font size='2' face='Tahoma'>˹��¡Ե (������ - ��Ժѵ�)</font></div>
      </td>
    </tr>";
	  while ($row = mysql_fetch_array($result))
	{
	$code = htmlspecialchars($row[Code]);
	$name = htmlspecialchars($row[Name]); 
		$name = eregi_replace("amp;","",$name);
	$query_subject = "Select Ename,Unit,Unit_detail,Unit_operation From $Subjecttable Where Code = '$code' ";
	$result_subject = mysql_query($query_subject);
	$row = mysql_fetch_array($result_subject);
	$ename = htmlspecialchars($row[Ename]); 
	$unit = htmlspecialchars($row[Unit]);
	$unit_detail = htmlspecialchars($row[Unit_detail]); 
	$unit_operation = htmlspecialchars($row[Unit_operation]);
   	$sum = $sum+$unit;
	$sum_detail = $sum_detail+ $unit_detail;
	$sum_operation = $sum_operation+ $unit_operation;
$sql_temp = "INSERT INTO $Temptable(Address,Code,Name) VALUES ('$i','$code','$name')"; 
$result_temp = mysql_db_query("$dbName",$sql_temp);
echo "
    <tr bgcolor='#F7F7F7'> 
	  <td height='13' width='42'> 
        <div align='center'><font face='Tahoma' size='2'><input type='checkbox' name='check[$i]' value='$code'></font></div>
      </td>
  <td height='13' width='90'> 
        <div align='center'> <font face='Tahoma' size='2'>$code</font></div>
      </td>
      <td height='13' bgcolor='#F7F7F7' width='441'>";
					if ($ename == '')
					{
					echo "<div align='left'> <font face='Tahoma' size='2'>&nbsp;$name</font></div>";
					}
					else
					{
					echo "<div align='left'> <font face='Tahoma' size='2'>&nbsp;$name ($ename)</font></div>";
					}
				echo "
		</td>
		<td height='13' width='200'> 
        <div align='center'><font face='Tahoma' size='2'> $unit ($unit_detail-$unit_operation)</font></div>
		</td>
	    </tr>
		<input type='hidden' name='count' value='$i'>";
$i =$i +1;
}
echo "
				<tr bgcolor='#DAEEFE'> 
				  <td height='13' bgcolor='#DAEEFE' colspan='2'>&nbsp;</td>
				  <td height='13' bgcolor='#DAEEFE' width='441'> 
					<div align='center'><font size='2' face='Tahoma'>˹��¡Ե���</font></div>
				  </td>
				  <td height='13' width='200'> 
					<div align='center'><font face='Tahoma' size='2'> $sum ($sum_detail-$sum_operation)</font></div>
				  </td>
				</tr>
				<tr bgcolor='#F7F7F7'> 
				  <td colspan='4' height='20'> 
					<div align='center'><font size='2' face='Tahoma'> 
					  <input type='submit' name='Submit' value='�ѹ�֡������'>
					  <input type='reset' name='Cancel' value='¡��ԡ������'>
					  </font></div>
				  </td>
				</tr>
				<input type='hidden' name='type' value='$type'>
				<input type='hidden' name='year' value='$year'>
				<input type='hidden' name='term' value='$term'>
				<input type='hidden' name='course_year' value='$course_year'>"; 
	}
else { echo "No data."; }
	mysql_free_result($result);
	MYSQL_CLOSE();
	?>
	  </table>
<table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
<tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="600" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</td>
<tr>
</table>
</form>
</body>
</html>

