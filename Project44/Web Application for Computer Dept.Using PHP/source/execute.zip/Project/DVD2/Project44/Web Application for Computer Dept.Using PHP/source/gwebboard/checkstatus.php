<?
session_unset();
session_start();
session_destroy();
$id=array($emails,$pass);
session_register(id);
//print($pass);
//print($email);
?> 
<html>
<head>
<title>Un title page</title>
<SCRIPT LANGUAGE="JavaScript">

function checkrequired(which) {
var passs=true;
if (document.images) {
for (i=0;i<which.length;i++) {
var tempobj=which.elements[i];
if (tempobj.name.substring(0,10)=="nameboards") {
if (tempobj.selectedIndex==0) {
passs=false;
break;
         }
      }
   }
}
if (!passs) {
alert("��س����͡ group ���١��ͧ");
return false;
}
else
return true;
}

</script>

<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->

</style>

<body bgcolor="#FFFFFF">	
<?
include("connect.inc.php3");
$dbname=gwebboard();
//print($email);
//print($pass);

if ((ereg("^.[a-zA-Z0-9]+@.+\..+$",$emails))&&($emails!="")&&($pass!=""))
  {//user
	$sql="select * from user where email ='$emails' and pass='$pass'";
	$dbquery=mysql_db_query($dbname,$sql) or die("error");
	$num_rows=mysql_num_rows($dbquery);
	
	if($num_rows>0)
		{
	        //��ǹ�ͧ admin group
			//��Ǩ�ͺemail&pass�������㹵��ҧ user  ����� admin ������������
            $sql1="select * from user,admin where user.email ='$emails' and user.pass='$pass' and user.own='admin' and admin.email=user.email";
	        $dbquery1=mysql_db_query($dbname,$sql1)or die("error");
	        $num_rows1=mysql_num_rows($dbquery1);
             $result1=mysql_fetch_array($dbquery1);
			
			 //��ǹ�ͧ user group
			 //��Ǩ�ͺemail&pass�������㹵��ҧ user  ����� userboard ������������
		     $sql2="select * from user,userboard where user.email ='$emails' and user.pass='$pass' and user.own='user' and userboard.email=user.email";
		     $dbquery2=mysql_db_query($dbname,$sql2)or die("error");
		     $num_rows2=mysql_num_rows($dbquery2);
	   		  ?>   
<form method="post" action="webboard.php3" onSubmit="return checkrequired(this)" target=_blank>
<table width="96%" border="0" cellspacing="0" cellpadding="0" height="64">
  <tr valign="bottom"> 
    <td colspan="2" height="30"> 
      <div align="right"></div>
    </td>
  </tr>
  <tr> 
    <td valign="bottom" width="79%" height="27"> 
      <div align="left"><font size="4"><font color="#333333" face="Microsoft Sans Serif" size="3"><b><font color="#006291">USERNAME 
        : <?print($emails)?></font></b></font></font></div>
    </td>
    <td valign="bottom" width="21%" height="27" align="right"> 
      <div align="center"></div>
      <div align="right"><font face="MS Sans Serif, CordiaUPC" size=1><font 
            face="MS Sans Serif, CordiaUPC" size=1><font style="FONT-SIZE: 8pt" 
            color=#cccccc><font face="Microsoft Sans Serif" color="#0033FF" size="2"><b><font color="#66CCFF">|</font></b></font> 
        <font color="#0000FF"><b><font face="Microsoft Sans Serif" size="2"><a href="index.php3">HOME</a></font> 
        <font face="Microsoft Sans Serif" size="2" color="#66CCFF">|</font></b></font></font></font></font></div>
    </td>
  </tr>
  <tr valign="top"> 
    <td colspan="2"><img src="status/line.gif" width="743" height="4"></td>
  </tr>
</table>
<br>
<table width="96%" border="0" cellspacing="0" cellpadding="0" height="299">
  <tr> 
    <td width="15%" valign="top" bgcolor="#66CCFF" height="435"> 
      <table width="92%" border="0" cellspacing="0" cellpadding="0" height="117">
        <tr>
          <td width="6%" height="16">&nbsp;</td>
          <td width="88%" height="16">&nbsp;</td>
          <td width="6%" height="16">&nbsp;</td>
        </tr>
        <tr>
          <td width="6%" height="21">&nbsp;</td>
          <td width="88%" align="left" height="0" valign="middle"> 
            <p><font size="2" face="Microsoft Sans Serif"><b><font color="#0000FF"><a href="showuserall.php3" target=_blank>��Ҫԡ������</a></font></b></font></p>
            </td>
          <td width="6%" height="21">&nbsp;</td>
        </tr>
        <tr>
          <td width="6%">&nbsp;</td>
          <td width="88%" valign="middle"><font size="2" face="Microsoft Sans Serif"><b><font color="#0000FF" size="1"><a href="index.html">HELP</a></font></b></font></td>
          <td width="6%">&nbsp;</td>
        </tr>
        <tr>
          <td width="6%">&nbsp;</td>
          <td width="88%">&nbsp;</td>
          <td width="6%">&nbsp;</td>
        </tr>
        <tr>
          <td width="6%">&nbsp;</td>
          <td width="88%">&nbsp;</td>
          <td width="6%">&nbsp;</td>
        </tr>
      </table>
	<p>&nbsp;</p>
    </td>
    <td width="8%" height="435">&nbsp;</td>
    <td width="38%" valign="top" height="435"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="384" bordercolor="#66CCFF">
        <tr> 
          <td valign="top" width="2%" height="22" rowspan="2"><img src="status/hd_bd.gif" width="9" height="28"></td>
          <td width="94%" bgcolor="#66CCFF" height="28"> 
            <div align="center"><b><font color="#FFFFFF" size="3" face="Microsoft Sans Serif">ADMIN</font></b></div>
          </td>
          <td width="4%" valign="top" height="22" rowspan="2"><b><font color="#000000"><img src="status/hd_bd2.gif" width="9" height="28"></font></b></td>
        </tr>
        <tr> 
          <td width="94%" bgcolor="#FFFFFF" height="469" valign="top"> 
            <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#66CCFF" height="292">
              <tr> 
                <td height="314" valign="top"> 
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="284">
                    <tr> 
                      <td width="28%" height="63"valign="bottom">
                          <div align="center">
			               <?if($num_rows1>0)        //��ǹ�ͧ admin group
			                    {
							     if($result1[num]==1)      //��ǹ�ͧ admin group
			                       print("<img src='pic/S2.gif' width='22' height='15'>");
							     else
								   print("<img src='pic/S1.gif' width='22' height='15'>"); 	  
						        }
							?> 
		                 </div></td>
                      <td valign="bottom" width="58%" height="63"> 
                        <div align="left"><font face="Microsoft Sans Serif">
			                 <?if($num_rows1>0)        //��ǹ�ͧ admin group
			                       print("<a href='webboardadmin.php3?nameboardw=$result1[nameboard]' target='_blank'>$result1[nameboard]</a>");
							  ?>
						</font></div>
                      </td>
                      <td width="14%" height="63">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td width="28%" height="63"valign="middle">
                          <div align="center">
			               <?if($num_rows1>0)        //��ǹ�ͧ admin group
			                    {
							    //��������� request ���������
									$sql3="select * from user where request ='$result1[nameboard]'";
                                  	$dbquery3=mysql_db_query($dbname,$sql3) or die("error");
                                	$num_rows3=mysql_num_rows($dbquery3);
								 if($num_rows3>0)      //��ǹ�ͧ admin group
			                       print("<img src='pic/S2.gif' width='22' height='15'>");
							     else
								   print("<img src='pic/S1.gif' width='22' height='15'>"); 	  
						        }
							?> 
		                 </div></td>
                      <td width="58%" height="85">
			              <?if($num_rows1>0)         //��ǹ�ͧ admin group
			                    print("<a href='adduser.php3?nameboarda=$result1[nameboard]' target='_blank''><font face='Microsoft Sans Serif'>������Ҫԡ</font></a>");?>
			             </td>
                      <td width="14%" height="85">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td width="28%" height="55">&nbsp;</td>
                      <td width="58%" height="55" valign="top"> 
                        <p>
			                 <?if($num_rows1>0)        //��ǹ�ͧ admin group
			                      print("<a href='deluser.php3?nameboardd=$result1[nameboard]' target='_blank''><font face='Microsoft Sans Serif'>ź��Ҫԡ</font></a>");?>
                     </p> 
					 </td>
                      <td width="14%" height="55">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td width="28%" height="98">&nbsp;</td>
                      <td width="58%" height="98" valign="top"><a href="showuseradmin.php3?nameboardsh=<?print($result1[nameboard]);?>" target='_blank'><font face="Microsoft Sans Serif">
		                     <?if($num_rows1>0)        //��ǹ�ͧ admin group
			                    print("�ʴ������ group");?>
			             </font></a></td>
                      <td width="14%" height="98">&nbsp;</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td width="2%" height="435">&nbsp;</td>
    <td width="37%" valign="top" height="435"> 
      <table width="99%" border="0" cellspacing="0" cellpadding="0" height="509" bordercolor="#66CCFF">
        <tr> 
          <td valign="top" width="2%" height="22" rowspan="2"><img src="status/hd_bd.gif" width="9" height="28"></td>
          <td width="94%" bgcolor="#66CCFF" height="28"> 
            <div align="center"><b><font color="#FFFFFF" size="3" face="Microsoft Sans Serif">USER</font></b></div>
          </td>
          <td width="4%" valign="top" height="22" rowspan="2"><b><font color="#000000"><img src="status/hd_bd2.gif" width="9" height="28"></font></b></td>
        </tr>
        <tr> 
            <td width="94%" bgcolor="#FFFFFF" height="505" valign="top"> 
              <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#66CCFF" height="316">
                <tr> 
                  <td height="312" valign="top"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" height="300">
                      <tr> 
                        <td width="17%" height="63">&nbsp;</td>
                        <td valign="bottom" width="69%" height="63"> 
                          <?if($num_rows2>0)        //��ǹ�ͧ user group
			                    {?>
                          <div align="center"> 
                            <select name="nameboards" >
                              <option  selected>====group==== 
                              <?$c=0;
									while($c<$num_rows2) 
									{
			                             $result2=mysql_fetch_array($dbquery2);  						    
										print("<option >$result2[nameboard] ");  
								        $c++;  
									}	
							print("</select>");
                            print("</div>");
						       }?>
                            </select>
                          </div>
                        </td>
                        <td width="14%" height="63">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="17%" height="55" >&nbsp;&nbsp;</td>
                        <td width="69%" height="55" valign=middle> 
                          <?if($num_rows2>0)        //��ǹ�ͧ user group
			                     {           
								   print("  <input type='radio' name='select' value=1 checked>&nbsp;&nbsp;<font color='#005CA2' face='MS Sans Serif, Microsoft Sans Serif' size='3'>����� group</font>"); 
								 }?>
                        </td>
                        <td width="14%" height="85">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="17%" height="55" align=right valign=top>&nbsp;&nbsp;</td>
                        <td width="69%" height="56" valign="top"> 
                          <?if($num_rows2>0)        //��ǹ�ͧ user group
			                     {           
							       print("<input type='radio' name='select' value=2>&nbsp;&nbsp;<font color='#005CA2' face='MS Sans Serif, Microsoft Sans Serif' size='3'>¡��ԡ����� group</font>");
                   				 }?>
                        </td>
                        <td width="14%" height="55">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="17%" height="98" align=right valign=top rowspan="2">&nbsp;&nbsp;</td>
                        <td width="69%" height="48" valign="top"> 
                          <?if($num_rows2>0)        //��ǹ�ͧ user group
		                             print("<input type='radio' name='select' value=3>&nbsp;&nbsp;<font color='#005CA2' face='MS Sans Serif, Microsoft Sans Serif' size='3'> �ʴ������ group</font>");
                     		   ?>
                        </td>
                        <td width="14%" height="98" rowspan="2">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td width="69%" height="54" valign="top"> 
                          <div align="center"> 
                            <?if($num_rows2>0)        //��ǹ�ͧ user group
		                           print("<input type='image' src='pic/go.gif' width='30' height='25' name='image'>");
                     		   ?>
							   
                          </div>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<INPUT TYPE="hidden" name=idd value=<?print($emails);?>>
</form>
<?}
 else
	    print("<br><br><h3><p align=center>�������ö login 㹰ҹ������</p></h3>");        
 }
	else
         print("<br><br><h3><p align=center>��س������������١��ͧ</p></h3>");

  //�Դ�ҹ������
     closedb();
?>
</body>
</html>