<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Administrator Tool</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<!-- �ѡ������͹仾���� Status Bar-->
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<p align="center"><img src="image/admin.jpg" width="480" height="65"></p>
<hr width="80%">
<?php
include("alumni.inc");
include("md5.js");
if($mem[n]&&$mem[p]){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$mem[n]'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	$pwd1=$row["ad_passwd"];
	$pwd1=MD5($pwd1).$mem[c];
	$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
	if($mem[n]==$row["ad_user"] && $mem[p]==$pwd1) { 
		$pagesize = 30;
		$gif_up = $a+($b*31)+$c;
		if (empty($page)){
				$page=1;
			}
			$q_sql = "select * from administrator";
			$q_db_query = mysql_db_query ($dbname, $q_sql) or die("�Դ��Ͱҹ�����������39");
			$num_rows = mysql_num_rows($q_db_query) or die("�Դ��Ͱҹ�����������40");
			$rt = $num_rows%$pagesize;
			if($rt!=0) { 
				$totalpage = floor($num_rows/$pagesize)+1; 
			}
			else{
				$totalpage = floor($num_rows/$pagesize); 
			}
			$goto = ($page-1)*$pagesize;
			$sql = "select * from administrator";
			$db_query = mysql_db_query ($dbname, $sql) or die("�Դ��Ͱҹ�����������50");
			if (!$db_query){
				print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
				exit;
			}
			else{
				$nums_rows = mysql_num_rows($db_query);
				print "<form name='weblogin'  method='post'  action='del_admin2.php?q_id=$q_id'  autocomplete='off' >";
				print "<table border=0  width=100% cellspacing=1 cellpadding=4>";
				print "<tr ><td bgcolor=$corlor_head align=center width=10><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B><CENTER>ź</CENTER></B></FONT></td>";
				print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>����-���ʡ��</b></font></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>User Name</b></font></td></tr>";
				for ($i=0;$i<$nums_rows;$i++){
				$result1 = mysql_fetch_array($db_query) or die("�Դ��Ͱҹ����������63");
				$ad_id = $result1[ad_id];
				$ad_name = $result1[ad_name];
				$ad_surname = $result1[ad_surname];
				$ad_user = $result1[ad_user];
				$ad_passwd = $result1[ad_passwd];
				$ad_passwd2 = $result1[ad_passwd2];

				$ad_id = stripslashes($ad_id);
				$ad_name = stripslashes($ad_name);
				$ad_surname = stripslashes($ad_surname);
				$ad_user = stripslashes($ad_user);
				$ad_passwd = stripslashes($ad_passwd);
				$ad_passwd2 = stripslashes($ad_passwd2);
				if($ad_user!="root"){
					print "<Tr> <Td bgcolor=$bg1 width=10><input type='radio' name='delad[$i]' value=$ad_id>";
					print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$ad_name $ad_surname</font></Td>";
					print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$ad_user</font></Td></tr>";
				}
				else{}
				}	// end for
				print "</table>";
			} // end else
			print "<table border=0 width=100%><tr>";
			print"<td><div align=left><input type='radio' name='a'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>���͡ Administrator ���зӡ��ź��з��</td>";
			print "<td align=right>";
//			print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Page </font>";
			for($i=1 ; $i<$page ; $i++){
//				print "<a href='$PHP_SELF?page=$i'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
			}
//			print "<font face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1  color=red><b>$page</b></font> ";
			for($i=$page+1 ; $i<=$totalpage ; $i++){
//				print "<a href=$PHP_SELF?page=$i><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
			}
			print"</td>";
			print"</tr></table></td></tr></table>";
			print "<center><hr width='80%'><input type='submit' name='Submit' value='Submit'>&nbsp;&nbsp;&nbsp;";
			 print "<input type='reset' name='Submit2' value='Reset'></center>";
			print "</form>";
	}
	else{
	?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=login.php">
	<?php
	}
}
?>
</body>
</html>