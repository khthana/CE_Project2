<?
session_start();
?>
<HTML>
<HEAD>
<TITLE>filedownload</TITLE>
<META http-equiv=content-type content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
</HEAD>
<?
include("connect.inc.php");
$dbname=project();

//�֧�����Ũҡ���ҧ register,userregister ��� id
$sql="select * from register,userregister where register.id='$id1' and register.id=userregister.id";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");
$result=mysql_fetch_array($dbquery);
?>
<BODY text=#444444 vLink=#373784 aLink=#ff6600 link=#003db9 bgColor=#ffffff >
<form name="download" method="post" action="download.php" onsubmit="return check();" >
<INPUT TYPE="hidden" name=id1 value='<?print($id1);?>'>
<INPUT TYPE="hidden" name=status value='user'>
<TABLE cellSpacing=0 cellPadding=0 width="760" align=center border=0>
<tr class=a>
<td>
<TABLE cellSpacing=0 cellPadding=2 width="760" align=center bgColor=#dddddd 
border=0>
  <TBODY> 
  <TR align=middle > 
    <TD height=50 bgcolor="#FFFFFF" align=left width="300"><img src="images/logo.gif" width="305" height="74"> 
    </TD>
    <TD height=50 bgcolor="#FFFFFF" align=left width="452" class=h><div align="center"><FONT  COLOR="#CA0065" ><b><?print($result[namept]);?></b></FONT><br><FONT COLOR="#CA0065" ><b><?print($result[namepe]);?></b></font>
        </div></TD>
  </TR>
  </TBODY>
</TABLE>
<TABLE borderColor=#0066cc cellSpacing=0 cellPadding=0 width="700" align=center 
bgColor=#ffffff border=2>
  <TBODY> 
  <TR>
    <TD vAlign=top align=middle>
      <TABLE cellSpacing=0 cellPadding=0 width="740" border=0>
        <TBODY>
        <TR class=a>
          <TD vAlign=top width="50%"><IMG height=8 
            src="images/ll1.gif" 
            width=8></TD>
          <TD vAlign=top align=right width="50%"><IMG height=8 
            src="images/ll2.gif" 
            width=8></TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=5 cellPadding=2 width="90%" align=center>
        <TBODY>
        <TR vAlign=bottom class=a>
          <TD class=h><font  color="#0066FF"><b>���͹䢡�� 
            Download File �ç�ҹ</b></font></TD>
        </TR>
        <TR vAlign=center>
          <TD class=a><FONT  color=#0066cc 
            >�ô��ҹ��зӤ������㨢�͵�ŧ��ҧ��ҧ����������´��͹���� 
            Download file �ç�ҹ�ͧ�Ҥ�Ԫ����ǡ�������������</FONT></TD>
        </TR></TBODY></TABLE><BR>
      <TABLE cellSpacing=2 cellPadding=2 width="90%" align=center>
        <TBODY> 
        <TR class=a> 
                <TD vAlign=top align=right width="11%"> 
                  <TABLE cellSpacing=0 cellPadding=0>
              <TBODY> 
              <TR bgColor=#0033cc> 
                <TD align=middle width=20 height=20><FONT 
                  class=a><B>1</B></FONT></TD>
              </TR>
              </TBODY> 
            </TABLE>
          </TD>
                <TD width="89%" valign="top" class=a><font color=#000000><B><FONT 
            color=#0066cc>�ç�ҹ </FONT></B>�������ǹ˹�觢ͧ<B><FONT color=#0066cc> 
                  ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ�Ҥ�Ԫ����ǡ�������������</FONT></B> 
                  ����ç�ҹ���Ѵ�Ӣ���¹ѡ�֡��<B><FONT color=#0066cc> �Ҥ�Ԫ����ǡ������������� 
                  </FONT></B></font> </TD>
        </TR>
        <TR> 
                <TD width="11%">&nbsp;</TD>
        </TR>
        <TR> 
                <TD vAlign=top align=right width="11%"> 
                  <TABLE cellSpacing=0 cellPadding=0>
              <TBODY> 
              <TR vAlign=center align=middle bgColor=#0033cc> 
                <TD align=middle width=20 height=20><FONT 
                  class=a><B>2</B></FONT></TD>
              </TR>
              </TBODY> 
            </TABLE>
           </TD>
                <TD width="89%" valign="top" class=a><font  color="#0066CC"><b>�Ҥ�Ԫ����ǡ������������� 
                  </b></font><font color=#000000>��ʧǹ�Է���㹡�� Download 
                  File �ç�ҹ ���������һ���ª����ǹ��� ���� �͡���¹Ẻ������㹡���ҼŻ���ª���ҧ� 
                  �� ��ä�� �繵�</font></TD>
        </TR>
        <TR> 
                <TD width="11%">&nbsp;</TD>
        </TR>
        <TR> 
                <TD vAlign=top align=right width="11%"> 
                  <TABLE cellSpacing=0 cellPadding=0>
              <TBODY> 
              <TR vAlign=center align=middle bgColor=#0033cc> 
                <TD align=middle width=20 height=20><FONT 
                  class=a><B>3</B></FONT></TD>
              </TR>
              </TBODY> 
            </TABLE>
            </TD>
                <TD width="89%" valign="top" class=a><font  color="#0066CC"><b>�Ҥ�Ԫ����ǡ������������� 
                  </b></font><font color=#000000>�зӡ���纪���/ʡ�� 
                  ��� email �����繻���ª���� </font><font  color="#0066CC"><b>�Ҥ�Ԫ����ǡ�������������</b></font> 
                  <font color=#000000>㹡�õ�Ǩ�ͺ������� Download File 
                  �ç�ҹ�ͧ </font><font  color="#0066CC"><b>�Ҥ�Ԫ����ǡ�������������</b></font></TD>
        </TR>
        <TR> 
                <TD width="11%">&nbsp;</TD>
        </TR>
        <TR> 
                <TD vAlign=top align=right width="11%"> 
                  <TABLE cellSpacing=0 cellPadding=0>
              <TBODY> 
              <TR vAlign=center align=middle bgColor=#0033cc> 
                <TD align=middle width=20 height=20><FONT 
                  class=a><B>4</B></FONT></TD>
				 </TR>
              </TBODY> 
            </TABLE>
            </TD>
                <TD width="89%" valign="top" class=a><font color=#000000>��سҡ�͡����/ʡ�� 
                  ��� email ���١��ͧ��������繨�ԧ<br>
            <br>
            </font> 
            
			<table width="75%" border="0" cellpadding="0" cellspacing="0">
              <tr class=a> 
                <td width="25%" height="38" class=a> 
                        <div align="right"><font color=#000000>����/ʡ�� 
                          :</font></div>
                </td>
                <td width="41%" height="38" class=a>&nbsp; 
            
                    <input type="text" name="name" size=20 maxlength=80>
            
                </td>
                <td width="34%" height="38" class=a>&nbsp;</td>
              </tr>
              <tr> 
                <td width="25%" class=a> 
                        <div align="right"><font color=#000000>Email 
                          :</font></div>
                </td>
                <td width="41%" class=a>&nbsp;     
                    <input type="text" name="email" size=20 maxlength=40>         
                </td>
                <td width="34%" class=a>&nbsp;</td>
              </tr>
            </table>
			</TD>
        </TR>
        <TR> 
                <TD width="11%" class=a>&nbsp;</TD>
        </TR>
        </TBODY> 
      </TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="90%" align=center border=0>
        <TBODY>
        <TR class=a>
                <TD align=right class=a><FONT color=#000000><B>��ҹ����ҹ���͹����������������´��ҹ������ ��ͧ���Download 
                  File �ç�ҹ ��س����͡ <FONT 
            color=#0066cc>"����Ѻ"</FONT></B></FONT></TD>
              </TR>
        <TR class=a>
          <TD><IMG height=10 
            src="images/dot.gif" 
            width=1 border=0></TD></TR>
        
        <TR class=a>
                  <TD align=right> 
                    <div align="center">
					<INPUT TYPE="image" SRC="images/accept.gif" width=78 border=0>&nbsp;
					<a href='display1.php?id1=<?print($id1);?>'><IMG height=20 src="images/naccept.gif" width=78 border=0></a>
					</div>
                  </TD>
          </TR>
        <TR class=a>
          <TD><IMG height=10 
            src="images/dot.gif" 
            width=1 border=0></TD></TR></TBODY></TABLE>
      <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
        <TBODY>
        <TR class=a>
          <TD vAlign=top width="50%"><IMG height=8 
            src="images/ll3.gif" 
            width=8></TD>
          <TD vAlign=top align=right width="50%"><IMG height=8 
            src="images/ll4.gif" 
            width=8></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE cellSpacing=0 cellPadding=2 width="98%" align=center border=0>
  <TBODY>
  <TR vAlign=center bgColor=#0099ff>
    <TD colSpan=2 bgcolor="#FFFFFF" align=center>
	<table width="630" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class=a>&nbsp;</td>
  </tr>
  <tr>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="600" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</TD>
  </TR>
  </TBODY>
  </TABLE>
  <?
//�Դ�ҹ������
closedb();
?>
    </td>
  </tr>
</table>
 </form>
 <script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.download.name.value;
      var v2 = document.download.email.value;
      
        	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.download.name.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.download.emailname.focus();           
           return false;
           }
		else
           return true;
}
//-->
</script>
 </BODY>
 </HTML>