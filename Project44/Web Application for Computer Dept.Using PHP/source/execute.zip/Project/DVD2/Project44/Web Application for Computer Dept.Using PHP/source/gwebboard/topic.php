<?
session_start();
if($id[0])
{
 include("update.inc.php");
 include("connect.inc.php");
 include("smtpmail.inc.php");
 include("censor.inc.php");
 $dbname=gwebboard();
?>
<html>
<head>
<title>topic</title>
<META  http-equiv="content-type" content="text/html;charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<style>
.a1
  {
  color: #00458A; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: center;
  }   
.a2
  {
  color:#FFFFEE; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: left;
  }
.a3
  {
  color:#FF6666; /* ᴧ*/
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: left;
  }
.a4
  {
  color:#00356A; /* ��*/
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: left;
  }
 .a5
  {
  color: #0066FF; /* ����Թ */
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: right;
  }
 </style>
</head>
<body>
 <table border=0  width="760" align=center height="640">
  <tr class=a> 
    <td valign="top" height="97" width="414"><img src="images/logo.gif" width="305" height="74"> 
      <font color="#006291" ><b> </b></font></td>
    <td valign="middle" height="97" width="435"><font color="#FF0066" ><b>GROUP</b></font>&nbsp;<font color="#FF0066" ><b> 
      : 
      &nbsp;<?print($nameboards);?>
      </b></font></td>
  </tr>
  <tr class=a> 
    <td valign="top" colspan="2" height="18"> 
     
 <?
 $ip=1;
 $d=date("d-m-Y");
 $t=date("h:i:s a");
  //��Ǩ�ͺ id �ش���� �����ҡѺ $idreply_new
$sql="select * from $nameboards$id2 where id='$idreply_new'";
$dbquery=mysql_db_query($dbname,$sql)or die("error2");
$rows=mysql_num_rows($dbquery);	  
 if(($check_topic=='Submit')&&($rows==0))
  {
	//update num=1 ��� table admin
   $sql="update admin set num=1 where (nameboard='$nameboards' and email!='$id[0]')";
   $dbquery=mysql_db_query($dbname,$sql);

	//update date2=$d ��� table $nameboards
    $sql="update $nameboards set date2='$d',time2='$t' where (id='$id2')";
    $dbquery=mysql_db_query($dbname,$sql)or die("error0");


	if($filegroup_size<3072000)//check size
          {
     		//print($filegroup_size);
			if(($filegroup!='none')&&($filegroup!=''))
            //copy file
               {
     			  //���ҧ���硷���
                 //mkdir($nameboards.'/topic'.$idtopic_new,0777) or die("error8");
				//  $dh=opendir($nameboards.'/topic'.$id2);
				 mkdir($nameboards.'/topic'.$id2."/id".$idreply_new,0777) or die("error8");
				// closedir($dh);
				 copy($filegroup,$nameboards.'/topic'.$id2."/id".$idreply_new."/".$filegroup_name);
                }
   
   $sql="select * from $nameboards$id2 where id='1' ";
   $dbquery=mysql_db_query($dbname,$sql)or die("error3");
   $result=mysql_fetch_array($dbquery);
   if(($result[sent_mail]=='1') and ($result[email]!=$id[0]))
	  {
	        $d=date('d-m-Y');
              //�� email
              //$result=mysql_fetch_array($dbquery);
              $email=$result[email];
              //$recive=$result[firstname]." ".$result[surname]." ".$result[code]."<".$email.">";
              $subject="�駢��ǡ������¹�ŧ��� Topic �ͧ�س";
			
              $message.="���ͧ�ҡ���ա������¹�ŧ��� Topic �ͧ�س�ѧ���\n";
              $message.="Group  :  ".$nameboards."\n"; 
              $message.="Topic  :  ".$id2."\n"; 
			  $message.="DATE   :  ".$d."\n";

             smail($email,$subject,$message);// or die("�������ö�觨�������");
	  }
   
   if($sent_mail_all=='1')
	   {
		 //����ª�����Ҫԡ�ҡ���ҧ admin �Ѻ userboard
         $sql="select * from  admin,userboard where (admin.nameboard=userboard.nameboard and admin.nameboard='$nameboards' and admin.email!='$id[0]' and userboard.email!='$id[0]')";
         $dbquery=mysql_db_query($dbname,$sql)or die("error2");
         print('no');
		 while($result=mysql_fetch_array($dbquery))
		   {
	          $d=date('d-m-Y');
              //�� email
              //$result=mysql_fetch_array($dbquery);
              $email=$result[email];
              //$recive=$result[firstname]." ".$result[surname]." ".$result[code]."<".$email.">";
              $subject="�駢��ǡ������¹�ŧ��� Group �ͧ�س";
			
              $message.="���ͧ�ҡ���ա������¹�ŧ��� Group �ͧ�س�ѧ���\n";
              $message.="Group  :  ".$nameboards."\n"; 
              $message.="Topic  :  ".$id2."\n"; 
			  $message.="DATE   :  ".$d."\n";

             smail($email,$subject,$message);// or die("�������ö�觨�������");
			  
			  //print($result[email]);	   
		   }  	   
	   }
   
   // update($d,$t,$nameboard,$id,$email);
	 if($HTTP_X_FORWARDED_FOR=="")
       $REMOTE=$REMOTE_ADDR; 
     else
	   $REMOTE="$REMOTE_ADDR => $HTTP_X_FORWARDED_FOR ";
	 	 

     $data=htmlspecialchars($data);

	 $data=ereg_replace("\n","<br>",$data);
     $data=ereg_replace(" ","&nbsp;",$data);
     $data=censor($data);
	 
	 //��������ŧ���ҧ ����webbaorboard��ҧ�+id
    // $sql="insert into $nameboards$id2 (data,ip,email,date,time) values ('$data','$REMOTE','$id[0]','$d','$t')";
     $sql="insert into $nameboards$id2 (data,ip,email,date,time,icq,filegroup,logo) values ('$data','$REMOTE','$id[0]','$d','$t','$icq','$filegroup_name','$logo')";
	 $dbquery=mysql_db_query($dbname,$sql)or die("error1");
  	  }//check file size
	else
		{
		  $fileerror='1';
		}
	}
if($fileerror!='1')
  {	 
 //��Ҥ��topic㹵��ҧ ����webbaorboard��ҧ� ����� id=$id
 $sql1="select * from  $nameboards where id=$id2";
 $dbquery1=mysql_db_query($dbname,$sql1)or die("error2");
 $result1=mysql_fetch_array($dbquery1); 

 //�ʴ�������㹵��ҧ ����webbaorboard��ҧ�+id
 $sql="select * from $nameboards$id2 order by id asc";
 $dbquery=mysql_db_query($dbname,$sql)or die("error3");
 $num_rows=mysql_num_rows($dbquery);	   
 $c=0;
        while($c<$num_rows)
		   {
		     $result=mysql_fetch_array($dbquery);
             if(strlen($result[ip])>16)
			   $ip=2;
			  
			  if($c==0)
                {
			    ?>  
				  
      <table border=0 align=center width=760 cellspacing=1 bordercolor=#FFFFFF cellpadding="0" >
        <tr  height=25 bgcolor=#C4E1E1> 
          <td class=a1 width=59 align=right> 
            <div align="right"><b><font color="#003F7D">Topic :</font></b>&nbsp;</div>
          </td>
          <td class=a2 bgcolor="#C4E1E1" colspan="5">&nbsp;<b><font color="#003F7D"> 
            <?$result1[topic]=ereg_replace("&nbsp;"," ",$result1[topic]);
			 	 $result1[topic]=ereg_replace("<br>","#",$result1[topic]);
				 $result1[topic]=wordwrap($result1[topic],85,'<br>',1);
			     
				 $result1[topic]=ereg_replace(" ","&nbsp;",$result1[topic]);
			 	 $result1[topic]=ereg_replace("#","<br>",$result1[topic]);
			 
			     
		         print($result1[topic]);?>
            </font></b></td>
        </tr>
        <tr bgcolor=#E4E4E4> 
          <td valign=middle class=a align=left width="60" height="105">&nbsp; </td>
          <td valign=top class=a3 height="101" bgcolor="#E4E4E4" colspan="5"><img src='pic\post1.gif' width="15" height="15">&nbsp;posted 
            <?print($result[date]);?>
            : 
            <?print($result[time]);?>
            <hr width=510>
            &nbsp;<font class=a4><b> 
            <?
			     
		         $result[data]=ereg_replace("&nbsp;"," ",$result[data]);
			 	 $result[data]=ereg_replace("<br>","#",$result[data]);
				 $result[data]=wordwrap($result[data],85,'<br>',1);
			     
				 $result[data]=ereg_replace(" ","&nbsp;",$result[data]);
			 	 $result[data]=ereg_replace("#","<br>",$result[data]);
			   // ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
                 $result[data] = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])","<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>",$result[data]);
                 $result[data] = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>",$result[data]); 
				 print($result[data]);?>
            </b></font> 
            <p class=a5>&nbsp;&nbsp;</p>
          </td>
        </tr>
        
				 
		<tr  height=25 bgcolor=#C4E1E1 valign=middle> 
          <td class=a1 width=59 bgcolor="#C4E1E1" > 
            <div align="right"><b><font color="#003F7D">E-Mail :</font></b><font color="#003F7D">&nbsp;</font></div>
          </td>
          
		<td class=a2 width="231" bgcolor="#EDF5F5" ><b>&nbsp; <font color=#000000 > 
            <?print($result[email]);?>
            <a href='mailto:<?print($result[email]);?>'><img src='pic\mail.gif' border=0></a> 
            </font></b> </td>
        
			<td class=a2 width="43" bgcolor="#C4E1E1" > 
            <div align="center"><b><font color="#003F7D">ICQ :</font></b></div>
          </td>
        
		
		<td class=a2 width="74" bgcolor="#EDF5F5" > 
            <div align="center"><b><font color=#000000 > 
              <?if($result[icq]!='0')
		         {
	            //print($result[icq]);
                 print("<img src='http://web.icq.com/whitepages/online?icq=$result[icq]&img=5' alt='ICQ-$result[icq]'>"); 
                 }//icq
			    else
                  print("-"); 
			?>
              </font></b></div>
          </td>
        	
			
   		<td class=a2 width="40" bgcolor="#C4E1E1" > 
            <div align="center"><b><font color="#003F7D">File :</font></b></div>
          </td>
        <?if($result[filegroup]!='')
		       {
		?>  
		<td class=a2 width="309" bgcolor="#EDF5F5" >&nbsp; <a href="<?print($nameboards.'/topic'.$id2.'/id'.$result[id].'/'.$result[filegroup]);?>"  class=filelink><font style='font-size:13'><b> 
            <?print($result[filegroup]);?>
            </b></font></a></td>
        <?}
			else
			 {
			?>
   		<td class=a2 width="309" bgcolor="#EDF5F5" >&nbsp; <font color=#000000 ><b>-
            </b></font></td>
			<?
			 }
		?>
			</tr>
       </table>
	  <?
				 }
               else
			     {
		       ?>
        
      <table border=0 align=center width=760 cellspacing=1 bordercolor=#FFFFFF cellpadding="0" >
        <tr bgcolor=#E4E4E4> 
          <td valign=middle class=a align=left width="60" height="105" bgcolor="#F2F2F2">&nbsp; 
          </td>
          <td valign=top class=a3 height="101" bgcolor="#F2F2F2" colspan="5"><img src='pic/post2.gif' width="15" height="15">&nbsp;posted 
            <?print($result[date]);?>
            : 
            <?print($result[time]);?>
            <hr width=510>
            &nbsp;<font class=a4><b> 
            <?
			     
		         $result[data]=ereg_replace("&nbsp;"," ",$result[data]);
			 	 $result[data]=ereg_replace("<br>","#",$result[data]);
				 $result[data]=wordwrap($result[data],85,'<br>',1);
			     
				 $result[data]=ereg_replace(" ","&nbsp;",$result[data]);
			 	 $result[data]=ereg_replace("#","<br>",$result[data]);
			   // ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
                 $result[data] = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])","<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>",$result[data]);
                 $result[data] = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>",$result[data]); 
				 print($result[data]);?>
            </b></font> 
            <p class=a5>&nbsp;&nbsp;</p>
          </td>
        </tr>
        
				 
		<tr  height=25 bgcolor=#C4E1E1 valign=middle> 
          <td class=a1 width=59 bgcolor="#C4E1E1" > 
            <div align="right"><b><font color="#003F7D">E-Mail :</font></b><font color="#003F7D">&nbsp;</font></div>
          </td>
          
		<td class=a2 width="231" bgcolor="#EDF5F5" ><b>&nbsp; <font color=#000000 > 
            <?print($result[email]);?>
            <a href='mailto:<?print($result[email]);?>'><img src='pic\mail.gif' border=0></a> 
            </font></b> </td>
        
		
		
		<td class=a2 width="43" bgcolor="#C4E1E1" > 
            <div align="center"><b><font color="#003F7D">ICQ :</font></b></div>
          </td>
        
		
		<td class=a2 width="74" bgcolor="#EDF5F5" > 
            <div align="center"><b><font color=#000000 > 
              <?if($result[icq]!='0')
		         {
	            //print($result[icq]);
                 print("<img src='http://web.icq.com/whitepages/online?icq=$result[icq]&img=5' alt='ICQ-$result[icq]'>"); 
                 }//icq
			    else
                  print("-"); 
			?>
              </font></b></div>
          </td>
        	
			
   		<td class=a2 width="40" bgcolor="#C4E1E1" > 
            <div align="center"><b><font color="#003F7D">File :</font></b></div>
          </td>
        <?if($result[filegroup]!='')
		       {
		?>  
		<td class=a2 width="309" bgcolor="#EDF5F5" >&nbsp; <a href="<?print($nameboards.'/topic'.$id2.'/id'.$result[id].'/'.$result[filegroup]);?>"  class=filelink><font style='font-size:13'><b> 
            <?print($result[filegroup]);?>
            </b></font></a></td>
        <?}
			else
			 {
			?>
   		<td class=a2 width="309" bgcolor="#EDF5F5" >&nbsp; <font color=#000000 ><b>-
            </b></font></td>
			<?
			 }
		?>
			</tr>
       </table>
      <?
				 }
 			  $c++;
		   }//while
  ?>
      <br>
      <table cellspacing=0 cellpadding=4 width=760 border=1 align=center bordercolor=#FFFFFF>
        <form method=post action='topic.php' name=topic onsubmit="return check();" enctype="multipart/form-data">
  <INPUT TYPE="hidden" name=nameboards value=<?print($nameboards);?>>
        <TR   bgcolor=#C4E1E1 class=a> 
          <TD  colspan=2 align=center class=h height=20><B><font color="#003F7D">Reply</font></b> 
          </TD>
        </TR>

		<TR vAlign=top bgcolor="#F2F2F2"> 
          <TD align=right><FONT 
            face="Tahoma,Ms Sans Serif"><FONT 
            style="FONT-SIZE: 13px"><B>��ͤ����ͺ��Ѻ <FONT 
            face=verdana>:</FONT></B></FONT></FONT></TD>
          <TD><FONT style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <TEXTAREA style="FONT-SIZE: 18px; Tahoma,Ms Sans Serif" name=data rows=10 wrap=VIRTUAL cols=65></TEXTAREA>
            </FONT><FONT 
            style="FONT-SIZE: 13px" face=verdana,arial color=#ff0000 
            >&nbsp;*</FONT></TD>
        </TR>
        
		<tr bgcolor="#F2F2F2"> 
          <td align=right height="39"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>ICQ <font 
            face=verdana>:</font></b></font></font></td>
          <td height="39"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <input 
            style="FONT-SIZE: 10px; Tahoma,Ms Sans Serif" name=icq size=25 maxlength=100>
            </font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <INPUT 
            style="FONT-SIZE: 8pt; FONT-FAMILY: verdana" type=checkbox CHECKED 
            name=sent_mail_all value=1>
            &nbsp;<FONT color=#990033><FONT 
            face=Verdana>(</FONT>��Ш�¢��������Ҫԡ�ء����Һ<FONT 
            face=Verdana>)</FONT></FONT></FONT></td>
        </tr>
        
		<?
			//�� admin 㹵��ҧ admin
	//	   $sql="select * from admin where nameboard='$nameboards' and email='$id[0]'";
	//	   $dbquery=mysql_db_query($dbname,$sql)or die("error");
	//		$rows=mysql_num_rows($dbquery);	  
	//		if($rows>0)
	//		{
			?>
        <tr bgcolor="#F2F2F2"> 
          <td align=right><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 14px"><b>File <font 
            face=verdana>:</font></b></font></font></td>
          <td><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
            <input style="FONT-SIZE: 13px; WIDTH: 250px; height:22px;Tahoma,Ms Sans Serif" type=file  name="filegroup">
            &nbsp;<FONT color=#990033><FONT 
            face=Verdana>(</FONT>upload ������Թ 3 M<FONT 
            face=Verdana>)</FONT></FONT></FONT> </font></td>
        </tr>
        <?
	//		}//����� admin ��Ṻ file ��
			?>        
	
        
		<tr valign=top bordercolor="#FFFFFF"> 
          <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp;</font></td>
          <td><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
            <font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
        </tr>
        <tr bordercolor="#FFFFFF"> 
          <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp;</font></td>
          <td><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit name=check_topic value=Submit>
            &nbsp;&nbsp; 
            <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=Cancle name=cancle>
            </font></td>
        </tr>
 <?
  print("<input type=hidden name=id2 value='$id2'>");
  	//�� id ����ҡ�ش�ҡ���ҧ nameboard
    $sql="select * from $nameboards$id2 order by id Desc";
	$dbquery=mysql_db_query($dbname,$sql)or die("error");
	$result=mysql_fetch_array($dbquery);
	$idreply_new=$result[id]+1;
   ?>
	<INPUT TYPE="hidden" name=idreply_new value=<?print($idreply_new);?>>
 <?
 // print("<input type=hidden name=top value=2>");
  ?>
</table>
  </form>
  
<?
}//fileerror==1
else
{
?>  
</td>
</tr>
<tr class=a> 
    <td valign="top" colspan="2" > 
<div align="center"> 
<p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
<p><font class=a><font  color="#FF0000"><b>��سҵ�Ǩ�ͺ��Ҵ File �ͧ�س��ͧ����Թ 3M </b></font></font></p>
<p><font class=a><font  color="#FF0000"><b>(��Ң�Ҵ File �ͧ�س�Թ 3M ��õԴ��� admin) </b></font></font></p>
<br>
<br>
<br>
 </div>
<?      
}
?>
 <table width="760" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr class=a> 
          <td height="8">&nbsp;</td>
        </tr>
        <tr class=a> 
          <td class=a> 
            <div align="center"><font color="#000080">Department of Computer Engineering 
              Faculty of Engineering King Mongkut's Institute of Technology<br>
              Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
          </td>
        </tr>
        <tr> 
          <td height="8" class=a> 
            <hr align="center" width="550" >
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center"></div>
          </td>
        </tr>
      </table>
  </td>
  </tr>
  </table>
<script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.topic.data.value;
          	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.topic.data.focus();           
		   return false;
           }
     	else
            return true;
}
//-->
</script>
</body>
</html>
<?
//�Դ�ҹ������
 closedb();
}
?>