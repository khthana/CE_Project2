<html>
<head>
<title>�ʴ�����������ԪҢͧ��ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
<?
	include ("connect_course.inc.php");
	echo"
	<tr>
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='134' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='show_select_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
	  <a href='show_select_category.php?course_year=$course_year'>��������Ǵ�Ԫ�</a><br>
      <a href='show_select_group.php?course_year=$course_year'>�����š�����Ԫ� </a><br>
		����������Ԫ�<br>
      <a href='tendency.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a></font> <font size='2' face='Tahoma'><br>
         <a href='index.php'>��Ѻ˹����ѡ </a></font></font><br>
      </td>
    <td width='619' valign='top' > 
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr valign='middle'> 
            <td colspan='8' height='103' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵúѳ�Ե 
                �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ�$course_year<br>
                ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
            </td>
          </tr>
          <tr bgcolor='#D2F8FD'> 
            <td colspan='8' height='21'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font> 
              </div>
              <div align='center'></div>
            </td>
          </tr>";
		$pass ="";
	$number =0;
//start check string x 
	if (strstr($code,'x'))
	{
		$scode = eregi_replace("x","%",$code);
		// start check subject select
		$query = MYSQL_DB_QUERY($dbName,"Select * From $Subjecttable Where Code Like '$scode' AND Course_year='$course_year' ");
		$number = MYSQL_NUMROWS($query);
		if ($number >0) {	 $check ='pass';	}
	}
			// select vaules in subjecttable
				$query = "Select * From $Subjecttable Where Code='$code' AND Course_year='$course_year' ";
				$result = mysql_query($query);
	if ($result)
	{
		while ($row = mysql_fetch_array($result)) 
	{
	$category = htmlspecialchars($row[Category]);
	$gsubject = htmlspecialchars($row[Gsubject]);
	$code = htmlspecialchars($row[Code]);
	$name = htmlspecialchars($row[Name]);
	$ename = htmlspecialchars($row[Ename]);
	$unit = htmlspecialchars($row[Unit]);
	$unit_detail = htmlspecialchars($row[Unit_detail]);
	$unit_operation = htmlspecialchars($row[Unit_operation]);
	$url = htmlspecialchars($row[Url]);

	$code_subject_to = htmlspecialchars($row[Code_subject_to]);
	$name_subject_to = htmlspecialchars($row[Name_subject_to]);
	$ename_subject_to = htmlspecialchars($row[Ename_subject_to]);
	
	$subject_detail = $row[Subject_detail];
	
   	$sum = $sum+$unit;
	$sum_detail = $sum_detail+ $unit_detail;
	$sum_operation = $sum_operation+ $unit_operation;
		echo"
          <tr> 
            <td colspan='2' height='19'  bgcolor='#D2F8FD'> 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;������Ǵ�Ԫ�</font></div>
            </td>
             <td colspan='6' height='19' bgcolor='#F7F7F7'><font size='2' face='Tahoma'>&nbsp;$category &nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���͡�����Ԫ�</font></div>
            </td>
          <td bgcolor='#F7F7F7' height='19' colspan='6'><font size='2' face='Tahoma'>&nbsp;$gsubject &nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����Ԫ�</font></div>
            </td>
          <td bgcolor='#F7F7F7' height='19' colspan='6'><font size='2' face='Tahoma'>&nbsp;$code&nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����Ԫ�������</font></div>
            </td>
            <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma'>&nbsp;$name&nbsp;</font></td>
          </tr>

          <tr> 
           <td colspan='2' bgcolor='#D2F8FD' height='19' > 
   <div align='center'><font size='2' face='Tahoma'>�����Ԫ������ѧ���</font></div>
            </td>
            
          <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma'>&nbsp;$ename&nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;˹��¡Ե</font></div>
            </td>
            <td width='35' bgcolor='#F7F7F7' height='19'>
			  <div align='center'><font size='2' face='Tahoma'>&nbsp;$unit&nbsp;</font></div></td>
            <td width='99' bgcolor='#D2F8FD' height='19'> 
              <div align='center'><font size='2' face='Tahoma'>������</font></div>
            </td>
            <td width='37' bgcolor='#F7F7F7' height='19'><div align='center'><font size='2' face='Tahoma'>&nbsp;$unit_detail&nbsp;</font></div></td>
            <td width='98' bgcolor='#D2F8FD' height='19'> 
              <div align='center'><font size='2' face='Tahoma'>��Ժѵ�</font></div>
            </td>
            <td width='38' bgcolor='#F7F7F7' height='19'><div align='center'><font size='2' face='Tahoma'>&nbsp;$unit_operation&nbsp;</font></div></td>
            <td width='124' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font face='Tahoma' size='2'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���ྨ����Ԫ�</font></div>
            </td>
            
          <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma'><A href='http://$url'  target ='_PARENT'>&nbsp;$url&nbsp; </font></A></font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ԪҺѧ�Ѻ��͹</font></div>
            </td>
            <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma'><a href='show_subject.php?code=$code_subject_to&&course_year=$course_year'>&nbsp;$code_subject_to $name_subject_to $ename_subject_to&nbsp;</a></font> </td>
          </tr>";
		  if($check == 'pass')
		  {
echo "
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��ª����Ԫ����Ǵ</font></div>
            </td>
             <td colspan='6' bgcolor='#F7F7F7' height='19'>";
				$number =0;
				$query = MYSQL_DB_QUERY($dbName,"Select * From $Subjecttable Where Code Like '$scode' AND Course_year='$course_year' ");
				$number = MYSQL_NUMROWS($query);
				if ($number <= 1)
				{
					echo "<font size='2' face='Tahoma'>&nbsp;</font></td>";
				}
			else
				{			
						$query1 = "Select * From $Subjecttable Where Code Like '$scode' AND Course_year='$course_year' ";
						$result1 = mysql_query($query1);
						$n = 0;
				while ( $row = mysql_fetch_array($result1)) 
				{		
						$gcode = htmlspecialchars($row[Code]);
						$gname = htmlspecialchars($row[Name]);
						$gename = htmlspecialchars($row[Ename]);
						if (($n == 0)&&($code !=  $gcode))
						{
						echo "<font size='2' face='Tahoma'><a href='show_subject.php?code=$gcode&&course_year=$course_year'>&nbsp;$gcode $gname $gename</font></A>";
						}
						$n =$n +1;
				}//end of while					
			}//end of if
			echo "</td></tr>";
}//end of check
echo "
			<tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19'   valign='top'> 
              <div align='left'><font size='2' face='Tahoma'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����������Ԫ�</font></div>
            </td>
            <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma'> &nbsp;$subject_detail&nbsp;</font></td>
           </tr>
          <tr bgcolor='#D2F8FD'> 
            <td colspan='8' height='9'>&nbsp;</td>
          </tr>
          <tr> 
            <td colspan='8' bgcolor='#F7F7F7' height='10'>&nbsp;</td>
          </tr>";
		} // end of while
	mysql_free_result($result);
	MYSQL_CLOSE();
	} //end of if result
  ?>
        </table>
    </td>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut"s Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
