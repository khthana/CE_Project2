<?php
	session_start();
	include("webboard.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	if(($ad_code!=$id) or ($tmp!=$id)){
		require ('overtime.php');
		exit;
	}
	if($name=='root'){
		require ('headroot.php');
	}else{
		require ('head.php');
	}
	if (empty($page)){
		$page=1;
	}
	$q_sql = "select * from question";
	$q_db_query = mysql_db_query ($dbname, $q_sql);
	$num_rows = mysql_num_rows($q_db_query);
	$rt = $num_rows%$pagesize;
	if($rt!=0) 
		{ 
			$totalpage = floor($num_rows/$pagesize)+1; 
		}
	else
		{
			$totalpage = floor($num_rows/$pagesize); 
		}
	$goto = ($page-1)*$pagesize;
	$sql = "select * from question order by q_id desc limit $goto,$pagesize";
	$db_query = mysql_db_query ($dbname, $sql);
	if (!$db_query){
		print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
		exit;
	}
	else{
		$nums_rows = mysql_num_rows($db_query);
		print "<form name='weblogin'  method='post'  action='del_question.php?id=$id&name=$name'  autocomplete='off' >";
		print "<table border=0  width=100% cellspacing=1 cellpadding=4>";
		print "<tr ><td bgcolor=$corlor_head align=center width=10><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B><CENTER>ź</CENTER></B></FONT></td>";
		print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Created</b></font></td>";
		print "<td bgcolor=$corlor_head width=40%><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Topic</b></font></td>";
		print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Topic Starter</b></font></td>";
		print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Last Post</b></font></td>";
		print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>R</b></font></td></tr>";
		for ($i=0;$i<$nums_rows;$i++){
			$result = mysql_fetch_array($db_query);
			$q_id = $result[q_id];
			$q_topic = $result[q_topic];
			$q_name = $result[q_name];
			$q_email = $result[q_email];
			$q_ip = $result[q_ip];
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];
			$q_update = $result[q_update];
			$q_post = $result[q_post];
			$q_reng = $result[q_reng];

			$q_id = stripslashes($q_id);
			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);
			$q_date = stripslashes($q_date);
			$q_update = stripslashes($q_update);
			$q_post = stripslashes($q_post);

				print "<Tr> <Td bgcolor=$bg1 width=10><input type='checkbox' name='delq[$i]' value=$q_id>";
				print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
				print "<Td  bgcolor=$bg3 width=40%><a href='admin_view_answer.php?q_id=$q_id&id=$tmp&name=$name' target=\"_blank\">";
				print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
				print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
				print "<Td  bgcolor=$bg3 ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_update1</font></Td>";
				print "<Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
		}	// end for
	print "</table>";
	} // end else

	print "<table border=0 width=100%><tr>";
	print"<td></td>";
	print "<td align=right>";
	print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Page </font>";
	for($i=1 ; $i<$page ; $i++){
		print "<a href='$PHP_SELF?page=$i&id=$id&name=$name'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
	}
	print "<font face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1  color=red><b>$page</b></font> ";
	for($i=$page+1 ; $i<=$totalpage ; $i++){
		print "<a href='$PHP_SELF?page=$i&id=$id&name=$name'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
	}
	print"</td>";
	print"</tr></table>";
	print "<center><hr width='80%'><input type='submit' name='Submit' value='Delect'>";
	 print "</center>";
	print "</form>";
?>