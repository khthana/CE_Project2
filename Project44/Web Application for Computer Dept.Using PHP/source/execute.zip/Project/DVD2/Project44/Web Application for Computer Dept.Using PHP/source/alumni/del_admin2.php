<?
session_start();
include("alumni.inc");
include("md5.js");
if($mem[n]&&$mem[p]){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$mem[n]'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	$pwd1=$row["ad_passwd"];
	$pwd1=MD5($pwd1).$mem[c];
	$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
	if($mem[n]==$row["ad_user"] && $mem[p]==$pwd1) { 
//		print "$mem[n],$mem[p],$mem[c]<br>";

		$sql1 = "select * from administrator";
		$db_query1 = mysql_db_query ($dbname, $sql1);
		$num_rows1 = mysql_num_rows($db_query1);
		if($num_rows1==0){ 
		}
		else{
			for ($i=0;$i<$num_rows1;$i++){
				print "<META http-equiv=refresh content=\"0; URL=admin.php\">";
				$sql = "delete from administrator where ad_id='$delad[$i]'";
				$dbquery = mysql_db_query($dbname, $sql);
			}
		}
	}
	else{
		print "no";
	}
}
?>