<html>
<head>
<title>ź�������ǡ�èѴ�Ԫ����¹��ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<?
include ("connect_course.inc.php");
if ($Cancel != '  ¡��ԡ  ')
{
$query = MYSQL_DB_QUERY($dbName,"Select * From $Coursetable Where Type ='$type' AND Year ='$year' AND Term ='$term' AND Course_year = '$course_year' "); 
	$number = MYSQL_NUMROWS($query); 
	if ($number >0)
	{ 
$query_delete_course = "Delete From $Coursetable Where Type ='$type' AND Year ='$year' AND Term ='$term' AND Course_year = '$course_year' ";
$result_delete_course = mysql_db_query($dbName,$query_delete_course);
echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>�������ǡ�èѴ�Ԫ����¹��١ź�͡�ҡ�ҹ���������º��������<BR></font></font></div>
			</td>
			</tr> 
			</table>";

	}
	else
	{
		echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>����բ������ǡ�èѴ�Ԫ����¹����к�<BR></font></font></div>
			</td>
			</tr> 
			</table>";

	}
	echo "	<table width='600' border='0' cellspacing='0' cellpadding='0'>
		  <tr>
			<td>&nbsp;</td>
		  </tr>
		  <tr>
			<td>
			  <div align='center'><font face='Tahoma' size='1'>Department of Computer 
				Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
				Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
				�觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
			</td>
		  </tr>
		  <tr>
			<td height='8'>
			  <hr align='center' width='95%' size='2'>
			</td>
		  </tr>
		  <tr>
			<td>
			  <div align='center'></div>
			</td>
		  </tr>
		</table>";
	}
	$query_delete_temp = "Delete From $Temptable ";
		$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);
			MYSQL_CLOSE();
?>
</body>
</html>
