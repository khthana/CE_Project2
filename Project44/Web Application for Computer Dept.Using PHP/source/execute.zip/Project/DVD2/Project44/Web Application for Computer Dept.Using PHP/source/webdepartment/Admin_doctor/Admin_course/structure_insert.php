<html>
<head>
<title>���������š�����Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>
<style type='text/css'>
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor='#FFFFFF'>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td height='13' width='96'>&nbsp;</td>
    <td height='13' width='321'>&nbsp;</td>
    <td height='13' width='36'>&nbsp;</td>
    <td width='108' height='13'>&nbsp;</td>
    <td width='2' height='13'>&nbsp;</td>
    <td width='106' height='13'>&nbsp;</td>
    <td width='107' height='13'>&nbsp;</td>
  </tr>
  <tr> 
    <td width='96'><img src='images/logo-kmitl0.gif' width='109' height='97'></td>
    <td width='321'> 
      <div align='center'><img src='images/CE.gif' width='265' height='70'></div>
    </td>
    <td width='36'>&nbsp;</td>
    <td width='108'><img src='images/r4.gif' width='108' height='80'></td>
    <td width='2'>&nbsp;</td>
    <td width='106'><img src='images/kingrama4-005.jpg' width='100' height='80'></td>
    <td width='107'><img src='images/kingrama4-012.jpg' width='100' height='80'></td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0' height='13'>
  <tr> 
    <td height='5' width='111'>&nbsp;</td>
    <td height='5' width='27'><font size='2' face='Tahoma'></font></td>
    <td height='5' width='200'><font size='2' face='Tahoma'>�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height='5' width='440'><font size='2' face='Tahoma'>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr bgcolor='#3E3EA8'> 
    <td width='10' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='95' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>˹���á</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>����Ԫ�</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font face='Tahoma' size='2'><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>��дҹ����</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>����ǡѺ���</font></font></font></font></div>
    </td>
    <td width='2'> 
      <div align='center'><font size='1'><font size='1'><font color='#FFFFFF'><font face='MS Sans Serif'><font face='MS Sans Serif'><font size='3'><font size='3'><font color='#FFFFFF'><font face='BrowalliaUPC'><font face='BrowalliaUPC'><font size='3'><font size='3'><font face='BrowalliaUPC'><font face='BrowalliaUPC'><font size='3'><img src='images/l.gif' width='1' height='20'></font></font></font><font color='#FFFFFF'></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width='10'>&nbsp;</td>
    <td width='95'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='2'>&nbsp;</td>
  </tr>
</table>
<table width='775' border='0' cellspacing='0' cellpadding='0' >
<?
include ('connect_course.inc.php');
	echo "
	  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_insert.html'>��ѡ�ٵû�ԭ���͡</a></font> 
      <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_insert_course.php'>�ç���ҧ��ѡ�ٵ�</a><br>
	  <a href='select_course_category.php'>������Ǵ�Ԫ�����</a><br>
      ����������Ԫ�����<br>
	  <a href='Doctor/Insert/Subject/select_course.php' >��������Ԫ����� </a><br>
     <a href='Doctor/Insert/Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a></font><br>
    <font color='#9900CC' face='Tahoma' size='2'><a href='detail.html'>��������´�Ԫ����¹</a> 
    <br>
      <a href='index.php'>��Ѻ˹����ѡ </a><BR>&nbsp;
    </font></td>
    <td width='619' valign='top' > ";

$ugs = strlen($gsubject);
$up1 = strlen($gprogram1_unit);
$up2 = strlen($gprogram2_unit);
$gsubject = htmlspecialchars($gsubject);
$gprogram1_unit = htmlspecialchars($gprogram1_unit);
$gprogram2_unit = htmlspecialchars($gprogram2_unit);
$gdetail = htmlspecialchars($gdetail);
$gdetail = eregi_replace(" ","&nbsp;",$gdetail);

if(($ugs != 0)&&($up1 != 0)&&($up2 != 0))
{
	$query_gsubject = "Select * From $Gsubjecttable Where Course_year  =  '$course_year' AND Category  =  '$category' AND Gsubject  =  '$gsubject'";
	$result_gsubject = mysql_query($query_gsubject);
	$number_gsubject = mysql_numrows($result_gsubject);
	$i_gsubject = 0;
	if ($i_gsubject == $number_gsubject)
		{
				$sql = "INSERT INTO $Gsubjecttable(Course_year,Category,Gsubject,Gprogram1_unit,Gprogram2_unit,Gdetail) VALUES ('$course_year','$category','$gsubject','$gprogram1_unit','$gprogram2_unit','$gdetail')";
				$result = mysql_db_query($dbName,$sql);

echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>��������ѡ�ٵ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'Doctor/insert/subject/select_course.php' target ='_parent'>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
		}
		else  if ($i_gsubject  <  $number_gsubject)
	    {
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>�բ�������Ǵ�Ԫҷ���к���������</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}
}
else {
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			 MYSQL_CLOSE();
        }
?>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut"s Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>