<?
 session_start();
//print($emails);
//print($pass);
?>
<html>
<head>
<META  http-equiv="content-type" content="text/html;charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<title>showuser</title>
<style>
.a1
  {
  color:#FFFFFF; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13px;
  text-align: center;
  }   
.a2
  {
  color:#FF33FF; /* ��ǧ */
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13px;
  text-align: center;
  }   
.a3
  {
  color:#006AD5; /* green */
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13px;
  text-align: center;
  }   
</style>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: none}
a:hover { color: #0099FF; text-decoration: none}
-->
</style>
</head>
<body>
<table border=0  width="760" align=left height="640">
  <tr class=a> 
    <td valign="top" height="97" width="414"><img src="images/logo.gif" width="305" height="74"> 
      <font color="#006291" ><b> </b></font></td>
    <td valign="middle" height="97" width="435"><font color="#FF0066" ><b>GROUP</b></font>&nbsp;<font color="#FF0066" ><b> 
      : 
      &nbsp;<?print($nameboards);?>
      </b></font></td>
  </tr>
  <tr class=a> 
    <td valign="top" colspan="2" height="19"> 
      <table border=0 width="760" align=left cellspacing="1" cellpadding="0">
        <tr height=22 bgcolor=#0053A6> 
          <th align=center width=200 class=a1>�ѹ-���� ���������� Group</th>
          <th align=center width=300 class=a1>Email</th>
          <th align=center width=200 class=a1>
            <div align="center">ʶҹ�</div>
          </th>
        </tr>
        <?
		include("connect.inc.php");
        $dbname=gwebboard();
		
		//�� admin 㹵��ҧ admin
		  $sql="select * from admin where nameboard='$nameboards'";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error");
		
			  while($result=mysql_fetch_array($dbquery))
			  {
		        print("<tr height=20><td  align=center width=225 bgcolor=#EEF3FD><font class=a3>$result[date1]</font>&nbsp;&nbsp;&nbsp;<font class=a2>$result[time1]</font></td>");
                print("<td  align=center width=300 class=a3 bgcolor=#DBE6FD>$result[email]</td>");
                print("<td  align=center width=225 class=a3 bgcolor=#EEF3FD>admin</td></tr>");
          	  } 
  	  
	   //�� user 㹵��ҧ userboard
		  $sql="select * from userboard where nameboard='$nameboards'";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error");
		
			  while($result=mysql_fetch_array($dbquery))
			  {
		        print("<tr height=20><td  align=center width=225 bgcolor=#EEF3FD><font class=a3>$result[date]</font>&nbsp;&nbsp;&nbsp;<font class=a2>$result[time]</font></td>");
                print("<td  align=center width=300 class=a3 bgcolor=#DBE6FD>$result[email]</td>");
                print("<td  align=center width=225 class=a3 bgcolor=#EEF3FD>user</td></tr>");
          	  }
//�Դ�ҹ������
     closedb();
?>
  </table>
</td> 
 </tr>

  <tr class=a> 
  <td valign="bottom" colspan="2"> 
 <table width="760" border="0" cellspacing="0" cellpadding="0">
    <tr class=a>
    <td>&nbsp;</td>
  </tr>
  <tr class=a>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8" class=a>
      <hr align="center" width="550" >
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
	</td>
  </tr>
</table>
</body>
</html>