<HTML>
<HEAD>
<TITLE>changepass</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</HEAD>
<BODY bgcolor=ffffff>
<table border=0  width="760" align=left height="640">
  <tr class=a> 
    <td valign="top" height="950"> <img src="images/logo.gif" width="305" height="74"> 
      <br>
<?
if($submit=='Submit')
{
include("connect.inc.php");
$dbname=gwebboard(); 
$sql="select * from user where email='$email'";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");
$rows=mysql_num_rows($dbquery);	
if($rows!=0)
 {
  $sql="select * from user where pass='$oldcode' and email='$email' and own='$status'";
  $dbquery=mysql_db_query($dbname,$sql)or die("error1");
  $rows1=mysql_num_rows($dbquery);	
    
	if(($newcode==$recode)&&($rows1==1))
	 {
            //update pass table regis
		    $sql="update user set pass='$newcode' where email='$email' and own='$status'";
            $dbquery=mysql_db_query($dbname,$sql)or die("error2");	    
            ?>
           <div align="center">
           <p>
		   <br>
          <br> 
         <br>
         <br>
			<font class=h><font  color="#0033FF">Complete</font></font></p>
         <p><font class=a><font color="#0033FF"><b>password �ͧ�س��١����¹���º��������</b></font></font></p>
         <hr width="400">
<br>
<br>
<br>  
<br>
<br>  
<br>
			</div>
       <?
	 }
  else
   {
?>
 <div align="center">
  <br>
  <br>
  <br> 
<br>  
<p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>��سҵ�Ǩ�ͺ password �ͧ�س�����ա����</b></font></font></p>
<br>
<br>
<br>  
<br>
<br>  
<br>
</div> 
<?
 }
 }//if
else
   {
?>
 <div align="center">
<br>
<br>
<br>  
<br>
<p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡ����� E-Mail �ͧ�س㹰ҹ������</b></font></font></p>
<br>
<br>
<br>  
<br>
<br>  
<br>
</div> 
<?
 }
//�Դ�ҹ������
closedb();
}
else//if(!$submit)
{
?>
      <table border=0 align=center width="760" height=350>
        <tr class=a>
          <td valign=top height='350'> 
            <table border=0 align=center width="80%" height='200'>
  <tr class=a>
    <td valign="top"> 
      <table bgcolor=#6666FF border=1 align=center>
<tr class=a>
<td>
<FORM name=create_login onsubmit="return check();" action='changepass.php' method=post>
<TABLE width=488 align=center>
  <TBODY>
  <TR class=a>
    <TD class=a align=right colSpan=2>&nbsp;</TD></TR>
  <TR bgColor=#ffffcc>
    <TD class=a align=right colSpan=2>
      <DIV align=center><FONT color=#ffff00><B><FONT color=#0033cc >Change password</FONT></B></FONT></DIV></TD></TR>
    <TR>
                        <TD class=a align=right width="176">&nbsp;</TD>
                        <TD class=a width="300">&nbsp;</TD>
                      </TR>
  
	
	                    <TD class=a align=right width="176"><B><FONT color=#cccc00>E-Mail 
                          :</FONT></B></TD>
                        <TD class=a width="300"><FONT color=#cccc00> 
                          <INPUT name=email size=20 maxlength=30></FONT></TD></TR>
      <TR> 
                              <TD class=a align=right width="169" height="26"><B><font color="#cccc00">Status 
                                Group :</font></B></TD>
                              <TD class=main width="307" height="26" valign="middle"> 
                                <select name="status" size="1">
                                  <option selected>---status---</option>
                                  <option>admin</option>
                                  <option>user</option>
                                </select>
                              </TD>
                            </TR>
						
						<TR>
                        <TD class=a align=right width="176"><B><FONT color=#cccc00>old-password 
                          :</FONT></B></TD>
                        <TD class=a width="300"> 
                          <INPUT type=password name=oldcode maxlength=10 size=12> 
      </TD></TR>
  <TR>
                        <TD class=a align=right width="176"><B><FONT color=#cccc00>new-password 
                          :</FONT></B></TD>
                        <TD class=a width="300"> 
                          <INPUT type=password name=newcode maxlength=10 size=12>  
      </TD></TR>
  <TR>
                        <TD class=a align=right width="176"><B><FONT color=#cccc00>re-password 
                          :</FONT></B></TD>
                        <TD class=a width="300"> 
                          <INPUT type=password name=recode maxlength=10 size=12> 
      </TD></TR>
   <TR>
                        <TD class=a align=right width="176">&nbsp;</TD>
                        <TD class=a width="300">&nbsp;</TD>
                      </TR>
  <TR>
                        <TD class=a align=middle colSpan=2> 
                          <div align="center">
                            <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
                            &nbsp;&nbsp;
                            <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=Cancel name=cancel>
                          </div>
                        </TD></TR>
   <TR>
                        <TD class=a align=right width="176">&nbsp;</TD>
                        <TD class=a width="300">&nbsp;</TD>
                      </TR>
  <TR bgColor=#ffffcc>
    <TD class=a align=middle colSpan=2><a href='index.php'><FONT color=#663300><b>HOME</b></FONT></a></TD></TR></TBODY></TABLE></FORM>
	</td>
	</tr>
</table>
<script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.create_login.email.value;
      var v2 = document.create_login.status;
	  var v3 = document.create_login.oldcode.value;
  	  var v4 = document.create_login.newcode.value;
      var v5= document.create_login.recode.value;
  
        	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.email.focus();           
		   return false;
           }
         else if (v2.selectedIndex==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.status.focus();           
		   return false;
           }
		else if ( v3.length==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.oldcode.focus();           
           return false;
           }
       else if (v4.length==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.newcode.focus();           
		   return false;
           }
		else if (v5.length==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.recode.focus();           
		   return false;
           }
		
		else
           return true;
}
//-->
</script>
</div>
</td>
</tr>
</table>
</td>
</tr>
</table>
<?
}
?>
 <table width="760" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class=a> 
            <div align="center"><font color="#000080">Department of Computer Engineering 
              Faculty of Engineering King Mongkut's Institute of Technology<br>
              Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
          </td>
        </tr>
        <tr> 
          <td height="8"> 
            <hr align="center" width="550" size="2">
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center"></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</BODY>
</HTML>