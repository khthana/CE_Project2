<?
			session_start();
?>
<html>
<head>
<title>Un title page</title>
<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>
<style type='text/css'>
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor='#FFFFFF'>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94" align="center">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width='778' border='0' align='center' cellpadding='0' cellspacing='2'>
  <tr> 
    <td width='127' height='30'>&nbsp;</td>
    <td width='206' height='30'>&nbsp;</td>
    <td width='236' height='30'><b><font face='Tahoma' size='3'> ������Administrator</font></b></td>
<?
echo "
	<td height='30' width='77' valign='bottom'> <font face='Tahoma' size='2'> 
      <b><font color='#FF0000'>! </font></b><a href='insert_form.php'>����Admin</a></font></td>";
	  ?>
    <td height='30' width='120'>&nbsp;</td>
  </tr>
  <tr> 
    <td width='127' height='39'> 
      <div align='left'><font face='Tahoma'><font face='Tahoma'></font></font></div>
    </td>
    <td colspan='3' height='39'> 
      <div align='left'><font face='Tahoma'><font face='Tahoma'></font></font></div>
      <table width='100%' border='0' cellspacing='1' cellpadding='1'>
        <tr> 
          <td height='53'> 
            <table width='100%' border='1' cellspacing='0' cellpadding='0' align='center' bgcolor='#FFFFFF' bordercolor='#FFFFFF'>
              <tr> 
                <td height='20' bgcolor='#336699' width='17%'> 
                  <div align='center'><font face='Tahoma' size='2' color='#FFFFFF'>����Admin</font> 
                  </div>
                </td>
                <td width='50%' height='25' bgcolor='#336699'> 
                  <div align='center'><font face='Tahoma' size='2' color='#FFFFFF'>���� 
                    - ���ʡ�� </font></div>
                </td>
                <td width='17%' height='25' bgcolor='#336699'> 
                  <div align='center'><font size='2' face='Tahoma' color='#FFFFFF'>���ʼ�ҹ</font></div>
                </td>
                <td height='25' bgcolor='#336699' colspan='2'> 
                  <div align='center'><font face='Tahoma' size='2' color='#FFFFFF'>���͡</font></div>
                </td>
              </tr>
<?
  if ($user[1] == 'administrator' )
{
	include ("connect_admin.inc.php");
}
	$query = "Select * From $Admintable Where Status = '$user[1]' ";
	$result = mysql_query($query);
	if ($result)
	{
		$i = "white";
		while ($row = mysql_fetch_array($result)) 
			{
			$user_name = htmlspecialchars($row[Username]);
			$name = htmlspecialchars($row[Name]);
			$passwd = htmlspecialchars($row[Password]);
			if ($i == 'white')
			{
		echo"
              <tr> 
                <td height='15' width='17%'> 
                  <div align='center'><font size='2' face='Tahoma'>$user_name</font></div>
                </td>
                <td width='50%' height='20'> <font size='2'><font size='2'><font face='Tahoma'>&nbsp;$name</font></font></font></td>
                <td width='17%' height='20'> 
                  <div align='center'><font face='Tahoma' size='2'>$passwd</font></div>
                </td>
                <td width='8%' height='20'> 
                  <div align='center'><font face='Tahoma'><font face='Tahoma'><font size='2'><font size='2'><font size='2'><font face='Tahoma'><A HREF='update_form.php?user_name=$user_name'>���</A></font></font></font></font></font></font></div>
                </td>
                <td width='10%' height='20'> 
                  <div align='center'><font size='2'><font size='2'><font face='Tahoma'><A HREF='delete_form.php?user_name=$user_name'>ź</A></font></font></font></div>
                </td>
              </tr>";
				  $i = "gray";
			}
			else
			{
		echo "
              <tr bgcolor='#EFEFEF'> 
                <td height='15' width='17%'> 
                  <div align='center'><font size='2' face='Tahoma'>$user_name </font></div>
                </td>
                <td width='50%' height='20'> <font size='2'><font size='2'><font face='Tahoma'>&nbsp;$name</font></font></font></td>
                <td width='17%' height='20'> 
                  <div align='center'><font face='Tahoma' size='2'>$passwd</font></div>
                </td>
                <td width='8%' height='20'> 
                  <div align='center'><font face='Tahoma'><font face='Tahoma'><font size='2'><font size='2'><font size='2'><font face='Tahoma'><A HREF='update_form.php?user_name=$user_name'>���</A></font></font></font></font></font></font></div>
                </td>
                <td width='10%' height='20'> 
                  <div align='center'><font size='2'><font size='2'><font face='Tahoma'><A HREF='delete_form.php?user_name=$user_name'>ź</A></font></font></font></div>
                </td>
              </tr>";
			$i = "white";
		}
	}
}
?>
            </table>
					  </td>
					</tr>
				  </table>
				  <font face='Tahoma'><font face='Tahoma'> </font></font></td>
				
    <td height='39' width='120'>&nbsp;</td>
			  </tr>
			</table>
	
<table width='778' border='0' cellspacing='0' cellpadding='0' align = 'center'>
  <tr> 
    <td width='140'>&nbsp;</td>
    <?
	echo "
    <td width='638'><font face='Tahoma' size='2'><a href='../../index.php'>&lt;&lt; ��Ѻ˹�ҡ�͹</a></font></td>	";
	?>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr>
    <td width='140'>&nbsp;</td>
  </tr>
  <tr> 
    <td colspan='2'> 
      <div align='center'><font face='Tahoma' size='1'>Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height='8' colspan='2'> 
      <hr align='center' width='95%' size='2'>
    </td>
  </tr>
  <tr> 
    <td colspan='2'> 
      <div align='center'></div>
    </td>
  </tr>
</table>
</body>
</html>
