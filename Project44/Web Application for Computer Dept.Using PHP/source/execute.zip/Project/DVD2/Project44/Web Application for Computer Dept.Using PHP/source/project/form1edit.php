<?session_start();
 if($id[0]!='')
  {
 include("connect.inc.php");
$dbname=project();
//�֧�����Ũҡ���ҧ userregister
$sql="select * from userregister where (code1='$id[0]' or code2='$id[0]' or code3='$id[0]' or code4='$id[0]')";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");
$rows=mysql_num_rows($dbquery);	 
?>
<html>
<head>
<title>form ����ç�ҹ-�.�.</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874" >
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</head>
<?
if(($rows!=0)or($id[1]=='admin'))
  {
 if((($file=='')&&($reset=='')&&($submit=='')) or ($reset=='cancel'))//load data defult
	 {
$sql="select * from  register,userregister where (userregister.id=register.id and (userregister.code1='$id[0]' or userregister.code2='$id[0]' or userregister.code3='$id[0]' or userregister.code4='$id[0]'))or(userregister.id=register.id and register.id='$id1')";
$dbquery=mysql_db_query($dbname,$sql)or die("error2");
$result=mysql_fetch_array($dbquery);			 

$result[abst]=ereg_replace("<br>","\n",$result[abst]);
$result[abse]=ereg_replace("<br>","\n",$result[abse]);

$abst=ereg_replace("&nbsp;"," ",$result[abst]);
$abse=ereg_replace("&nbsp;"," ",$result[abse]);

$result[name1]=ereg_replace(" ","&nbsp;",$result[name1]);
$result[name2]=ereg_replace(" ","&nbsp;",$result[name2]);
$result[name3]=ereg_replace(" ","&nbsp;",$result[name3]);
$result[name4]=ereg_replace(" ","&nbsp;",$result[name4]);

$result[namept]=ereg_replace(" ","&nbsp;",$result[namept]);
$result[namepe]=ereg_replace(" ","&nbsp;",$result[namepe]);
$result[advisor1]=ereg_replace(" ","&nbsp;",$result[advisor1]);
$result[advisor2]=ereg_replace(" ","&nbsp;",$result[advisor2]);

$name1=$result[name1];
$name2=$result[name2];
$name3=$result[name3];
$name4=$result[name4];
$code1=$result[code1];
$code2=$result[code2];
$code3=$result[code3];
$code4=$result[code4];
$email1=$result[email1];
$email2=$result[email2];
$email3=$result[email3];
$email4=$result[email4];
$namept=$result[namept];
$namepe=$result[namepe];
$advisor1=$result[advisor1];
$advisor2=$result[advisor2];
$year=$result[year];
$id1=$result[id];   
$key1=$result[key1];
$key2=$result[key2];
$key3=$result[key3];
$key4=$result[key4];
$key5=$result[key5];
$dh=opendir('id'.$id1);
    while($file=readdir($dh))
        {
            if(($file!='.')&&($file!='..'))
                 {
                      $sql="select * from register where id=$id1 and (doc='$file' or chap1='$file' or chap2='$file' or chap3='$file' or chap4='$file' or chap5='$file' or chap6='$file' or chap7='$file' or chap8='$file' or chap9='$file' or chap10='$file'or chap11='$file' or chap12='$file' or chap13='$file' or chap14='$file' or chap15='$file' or chap16='$file' or chap17='$file' or chap18='$file' or chap19='$file' or chap20='$file')";
                      $dbquery=mysql_db_query($dbname,$sql)or die("error3");
                      $rows=mysql_num_rows($dbquery);	 
            	      if($rows==0)
					   {
					       unlink('id'.$id1.'/'.$file); 
					   }
            	  }
    	}
closedir($dh);
}//load data defult

  if($file=='Submit')//addfile
     {
      $dh=opendir('id'.$id1);
 if(($filedata_name=="chap1.pdf")||($filedata_name=="document.pdf")||($filedata_name=="chap2.pdf")||($filedata_name=="chap3.pdf")||($filedata_name=="chap4.pdf")||($filedata_name=="chap5.pdf")||($filedata_name=="chap6.pdf")||($filedata_name=="chap7.pdf")||($filedata_name=="chap8.pdf")||($filedata_name=="chap9.pdf")||($filedata_name=="chap10.pdf")||($filedata_name=="chap11.pdf")||($filedata_name=="chap12.pdf")||($filedata_name=="chap13.pdf")||($filedata_name=="chap14.pdf")||($filedata_name=="chap15.pdf")||($filedata_name=="chap16.pdf")||($filedata_name=="chap17.pdf")||($filedata_name=="chap18.pdf")||($filedata_name=="chap19.pdf")||($filedata_name=="chap20.pdf"))
      copy($filedata,'id'.$id1.'/'.$filedata_name);
      closedir($dh);
     }//addfile
?>
<body  bgcolor=ffffff>
<?
if($submit!='Submit')
    {
?>
<table border="0" cellspacing="0" cellpadding="0" width="760" align=left>
  <tr class=a> 
    <td valign="top"> 
<form method="post" action="form1edit.php" enctype="multipart/form-data" onsubmit="return check()" name=form1>
   <INPUT TYPE="hidden" name=id1 value=<?print($id1);?>>
	<table width="760" border="1" bordercolor="#0058B0" cellspacing="0" cellpadding="0" height="600" align=center>
    <tr class=a>
      <td bordercolor="#0000FF" valign="top"> 
              <table width="760" border="1" cellpadding="0" cellspacing="1" height="150" bordercolor="#CCCCCC">
                <tr height='32' bgcolor="#003F7D" valign="middle" class=a> 
                  <td colspan="6" align=center height="29"><b><font style='font-size:18px'>����ç�ҹ</font></b> 
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="28%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "  size=25 maxlength=40 value=<?print($name1);?> >
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                  <td width="11%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="18%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code1);?>>
                    <font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font> </td>
                  <td width="7%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="24%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email1);?>>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="26%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name2);?>>
                  </td>
                  <td width="11%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="16%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code2);?>>
                  </td>
                  <td width="7%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="24%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email2);?>>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="8%" align=center bgcolor="#0053A6"><font class=a>����/ʡ��</font>&nbsp;</td>
                  <td width="26%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name3);?>>
                  </td>
                  <td width="11%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="16%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code3);?>>
                  </td>
                  <td width="7%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="24%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email3"  style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email3);?>>
                  </td>
                </tr>
                <tr height='32' class=a> 
                  <td width="8%" align=center bgcolor="#0053A6"><font size="2" color="#FFFFFF" face="Tahoma,Ms Sans Serif">����/ʡ��</font>&nbsp;</td>
                  <td width="26%" bgcolor="#F6F6F6" align=left> &nbsp;&nbsp; 
                    <input type="text" name="name4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=25 maxlength=40 value=<?print($name4);?>>
                  </td>
                  <td width="11%" align=center bgcolor="#0053A6"><font class=a>���ʹѡ�֡��</font>&nbsp;</td>
                  <td width="16%" bgcolor="#F6F6F6" align=left>&nbsp; 
                    <input type="text" name="code4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=15 maxlength=10 value=<?print($code4);?>>
                  </td>
                  <td width="7%" align=center bgcolor="#0053A6"><font class=a>Email</font>&nbsp;</td>
                  <td width="24%" bgcolor="#F6F6F6" align=left>&nbsp;&nbsp; 
                    <input type="text" name="email4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size=20 maxlength=40 value=<?print($email4);?>>
                  </td>
                </tr>
              </table>
    
		      <table width="760" border="1" cellpadding="5" cellspacing="1" bordercolor="#CCCCCC">
                <tr class=a> 
                  <td width="25%" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�����ç�ҹ(������)&nbsp;&nbsp;</font></div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input type="text" name="namept" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="70" maxlength=200 value=<?print($namept);?>><font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font>
            </td>
          </tr>
                <tr class=a> 
                  <td width="18%" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�����ç�ҹ(�����ѧ���)</font></div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input type="text" name="namepe" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="70" maxlength=200 value=<?print($namepe);?>><font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font>
            </td>
          </tr>
                <tr class=a> 
                  <td width="18%" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�Ҩ�������֡��&nbsp;&nbsp;</font></div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input type="text" name="advisor1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=40 value=<?print($advisor1);?>><font style="FONT-SIZE: 13px" 
            face="verdana" color=#ff0000>&nbsp;*</font>
            </td>
          </tr>
                <tr class=a> 
                  <td width="18%" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�Ҩ�������֡��&nbsp;&nbsp;</font></div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input type="text" name="advisor2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=40 value=<?print($advisor2);?>>
            </td>
          </tr>
                <tr class=a> 
                  <td width="18%" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>�ա���֡�� &nbsp;&nbsp;</font></div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <input type="text" name="year" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="12" maxlength=5 value=<?print($year);?>><font style="FONT-SIZE: 13px" 
            face="verdana,arial" color=#ff0000>&nbsp;*</font>
            </td>
          </tr>
                <tr class=a> 
                  <td width="18%" bgcolor="#0053A6" class=a> 
                    <div align="center"><font style='font-size:16px'>���Ѵ���&nbsp;&nbsp;</font> </div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <textarea rows=15 cols=85 name="abst"  wrap=physical style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "><?print($abst);?></textarea>
            </td>
          </tr>
		  
		        <tr class=a> 
                  <td width="18%" bgcolor="#0053A6" class=a> 
                    <div align="center"><font style='font-size:16px'>abstract&nbsp;&nbsp;</font> </div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6">&nbsp;&nbsp; 
                    <textarea rows=15 cols=85 name="abse"  wrap=physical style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "><?print($abse);?></textarea>
            </td>
          </tr>
		  
		        <tr class=a> 
                  <td width="18%" bgcolor="#0053A6" class=a> 
                    <div align="center"><font style='font-size:16px'>Display &nbsp;&nbsp;</font> </div>
               </td>
                  <td colspan="2" bgcolor="#F6F6F6" valign=top>&nbsp;&nbsp; 
                    
					<table width='550' height=200 border=1 cellspacing="0" cellpadding="0">
					 <tr class=a>
                      <td valign=top>
					  <p><font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">#���� file �������öṺ���մѧ���</font></p>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">1.document.pdf&nbsp;&nbsp;&nbsp;2.chap1.pdf&nbsp;&nbsp;&nbsp;3.chap2.pdf&nbsp;&nbsp;&nbsp;4.chap3.pdf&nbsp;&nbsp;&nbsp;5.chap4.pdf</font><br>                   	
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">6.chap5.pdf&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.chap6.pdf&nbsp;&nbsp;&nbsp;8.chap7.pdf&nbsp;&nbsp;&nbsp;9.chap8.pdf&nbsp;&nbsp;&nbsp;10.chap9.pdf</font><br>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">11.chap10.pdf&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12.chap11.pdf&nbsp;&nbsp;&nbsp;13.chap12.pdf&nbsp;&nbsp;&nbsp;14.chap13.pdf&nbsp;&nbsp;&nbsp;15.chap14.pdf</font><br>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">16.chap15.pdf&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;17.chap16.pdf&nbsp;&nbsp;&nbsp;18.chap17.pdf&nbsp;&nbsp;&nbsp;19.chap18.pdf&nbsp;&nbsp;&nbsp;20.chap19.pdf</font><br>
					  <font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">21.chap20.pdf</font><br>
					  <p><font style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066">#���� file ��������������</font></p>	  
					   
					  <?			  
			       $dh=opendir('id'.$id1);
                   $c=1;
				   while($file=readdir($dh))
                       {
                           if(($file!='.')&&($file!='..'))
						   {
						      print("<font style='FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif ;color=#FF0066'>".$c.'.'.$file."</font><br>"); 
                               $c++;
						   }
						}
                    closedir($dh);
              ?>
			</td>
			</tr>
			</table>
			  </td>
          </tr>
            
		        <tr class=a> 
                  <td width="18%" bgcolor="#0053A6"> 
                    <div align="center"><font class=a>File &nbsp;&nbsp;</font></div>
            </td>
                  <td colspan="2" bgcolor="#F6F6F6" class=a>&nbsp;&nbsp; 
                    <input style="FONT-SIZE: 13px; WIDTH: 250px; height:25px;FONT-FAMILY: verdana" type=file  name="filedata">&nbsp;<input style="FONT-SIZE: 13px; WIDTH: 70px;height:25px; FONT-FAMILY: verdana" type=submit value=Submit name="file">&nbsp;<font style="FONT-SIZE: 13px" 
             color=#330099><font face=Verdana>(</font><FONT COLOR="#330000" >&nbsp;update file �¡�� upload �Ѻ file ��� &nbsp;</FONT><font face=Verdana>)</font></font>    
            </td>
          </tr>
	 
	         <tr bgcolor="#0099E3" bordercolor="#CCCCCC" class=a> 
                  <td width="18%" bgcolor="#0053A6" valign="middle" height="83" > 
                    <div align="center"><font  class=a>Keyword 
                      search </font></font></div>
                  </td>
                  <td bgcolor="#F6F6F6" colspan="2" height="83" valign="top"> 
                    <table width="99%" border="0" height="61" cellpadding="0" cellspacing="0">
                      <tr class=a> 
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;1.</font> 
                          <input type="text" name="key1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " value="<?print($key1);?>" maxlength=80>
                        </td>
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;2.</font> 
                          <input type="text" name="key2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " value="<?print($key2);?>" maxlength=80>
                        </td>
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;3.</font> 
                          <input type="text" name="key3" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " value="<?print($key3);?>" maxlength=80>
                        </td>
                      </tr>
                      <tr> 
                        <td width="29%" height="38" class=a> <font color=#000000>&nbsp;4. </font> 
                          <input type="text" name="key4" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " value="<?print($key4);?>" maxlength=80>
                        </td>
                        <td colspan="2" height="38" class=a> <font color=#000000>&nbsp;5.</font> 
                          <input type="text" name="key5" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " value="<?print($key5);?>" maxlength=80>
                        </td>
                      </tr>
                    </table>
                    
                  </td>
                </tr>
				
				<tr valign=top height=50 bordercolor="#FFFFFF" class=a> 
                  <td align=right>&nbsp;</td>
                  <td colspan=2 align=center  valign=middle><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#666666><b><u>������</u>��</b> ��سҡ�͡������㹪�ͧ���������ͧ���� 
                    <font style="FONT-SIZE: 13px" face="verdana,arial" color=#ff0000 >&nbsp;*</font> 
                    ��ҡѺ�������ú��ǹ����ó�</font></td>
    </tr>
	            <tr bordercolor="#FFFFFF" class=a> 
                  <td width="18%" height="32" class=a>&nbsp;</td>
                  <td width="60%" height="32" class=a> 
                    <div align="center">&nbsp;&nbsp;&nbsp;&nbsp;
                      <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
                      &nbsp;&nbsp;<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=cancel name=reset>
				
              </div>
            </td>
                  <td width="28%" height="32" class=a>&nbsp;</td>
          </tr>
        </table>
        
      </td>
    </tr>
  </table>
  <br>
 <br>
</form>

	
</td>
</tr>
</table>
	<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.form1.name1.value;
      var v2 = document.form1.code1.value;
      
	  var v4 = document.form1.namept.value;
  	  var v5 = document.form1.namepe.value;
      var v6 = document.form1.advisor1.value;
      var v7 = document.form1.year.value;
	
	    	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.name1.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.code1.focus();           
           return false;
           }
      
		else if (v4.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.namept.focus();           
		   return false;
           }
      	else if (v5.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.namepe.focus();           
		   return false;
           }
      	else if (v6.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.advisor1.focus();           
		   return false;
           }
      	else if (v7.length==0)
           {
           alert("��س������������ú��ǹ");
           document.form1.year.focus();           
		   return false;
           }
		else
           return true;
}
//-->
</script>
<?
}//!=submit
else
  {
$dh=opendir('id'.$id1);
    while($file=readdir($dh))
        {
            if(($file!='.')&&($file!='..'))
                 {
            	    if($file=='document.pdf')
						$filedoc=$file;
                    elseif($file=='chap1.pdf')
					     $filechap1=$file;
                    elseif($file=='chap2.pdf')
					     $filechap2=$file;
                    elseif($file=='chap3.pdf')
					     $filechap3=$file;
                    elseif($file=='chap4.pdf')
					     $filechap4=$file;
                    elseif($file=='chap5.pdf')
					     $filechap5=$file;
                    elseif($file=='chap6.pdf')
					     $filechap6=$file;
                    elseif($file=='chap7.pdf')
					     $filechap7=$file;
                     elseif($file=='chap8.pdf')
					     $filechap8=$file; 
					 elseif($file=='chap9.pdf')
					     $filechap9=$file; 
					 elseif($file=='chap10.pdf')
					     $filechap10=$file; 
            	  elseif($file=='chap11.pdf')
					     $filechap11=$file;
                    elseif($file=='chap12.pdf')
					     $filechap12=$file;
                    elseif($file=='chap13.pdf')
					     $filechap13=$file;
                    elseif($file=='chap14.pdf')
					     $filechap14=$file;
                    elseif($file=='chap15.pdf')
					     $filechap15=$file;
                    elseif($file=='chap16.pdf')
					     $filechap16=$file;
                    elseif($file=='chap17.pdf')
					     $filechap17=$file;
                     elseif($file=='chap18.pdf')
					     $filechap18=$file; 
					 elseif($file=='chap19.pdf')
					     $filechap19=$file; 
					 elseif($file=='chap20.pdf')
					     $filechap20=$file;
				  }
    	}
closedir($dh);

$abst=htmlspecialchars($abst);
$abse=htmlspecialchars($abse);

$abst=ereg_replace("\n","<br>",$abst);
$abse=ereg_replace("\n","<br>",$abse);

$abst=ereg_replace(" ","&nbsp;",$abst);
$abse=ereg_replace(" ","&nbsp;",$abse);

 //update ���ҧ register
$sql="update register set advisor1='$advisor1',advisor2='$advisor2'  ,namept='$namept' ,namepe='$namepe' ,year='$year' ,abst='$abst' ,abse='$abse' ,doc='$filedoc' ,chap1='$filechap1' ,chap2='$filechap2' ,chap3='$filechap3' ,chap4='$filechap4' ,chap5='$filechap5' ,chap6='$filechap6' ,chap7='$filechap7' ,chap8='$filechap8' ,chap9='$filechap9' ,chap10='$filechap10',chap11='$filechap11' ,chap12='$filechap12' ,chap13='$filechap13' ,chap14='$filechap14' ,chap15='$filechap15' ,chap16='$filechap16' ,chap17='$filechap17' ,chap18='$filechap18' ,chap19='$filechap19' ,chap20='$filechap20' ,key1='$key1' ,key2='$key2' ,key3='$key3' ,key4='$key4' ,key5='$key5'where id='$id1'";
$dbquery=mysql_db_query($dbname,$sql)or die("error4");
		       
//update ���ҧ userregister
 $sql="update userregister set name1='$name1' ,name2='$name2' ,name3='$name3' ,name4='$name4' ,code1='$code1' ,code2='$code2' ,code3='$code3' ,code4='$code4' ,email1='$email1' ,email2='$email2' ,email3='$email3' ,email4='$email4' where id='$id1'";
$dbquery=mysql_db_query($dbname,$sql)or die("error5");
         
?>
<div align="center">
<br>
 <br>  
<p>
	<font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#0033FF"><b>Complete</b></font></font></p>
  <p><font class=a><font color="#0033FF">�����Ţͧ�س�١�Ѵ��ŧ�ҹ���º��������</font></font></p>  
  <a href='indexs.php' class=home>HOME</a>
  <hr width="400">
  <br>
</div>
<?  
  }//==submit
 }//if($rows!=0)
else
{
?>
<div align="center">
  <p><br>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">���ͧ�ҡ�����ʢͧ�س����㹰ҹ�����Ţͧ��� register ����</font></font></p>
 <a href='indexs.php' class=home>HOME</a>   
 <hr width="400" color=#000000>
  <p>&nbsp;</p>
</div>
<?
}
//�Դ�ҹ������    
 closedb();
?>
</body>
</html>
<?
}
else
   {
?>
   <div align="center">
  <p><br>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">���ͧ�ҡ�س�ӼԴ��鹵͹��� register �ͧ�к�</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div>
<?   
   }
?>
