<?php
	include("smtpmail.inc.php");
	$to="s2015318@hotmail.com";
	$s="send mail";
	$body="i want to work";
	smail($to,$s,$body)
?>