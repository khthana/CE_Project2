<html>
<head>
<title>��䢢�������Ǵ�Ԫ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
 echo "
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='134' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_update.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font> 
      <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_update_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
	  �����Ǵ�Ԫ�<br>
      <a href='structure_update_group.php?course_year=$course_year'>��䢡�����Ԫ� </a><br>
	  <a href='Bachelor/Update/Subject/update_subject.php?course_year=$course_year'>�������Ԫ�</a><br>
		<a href='Bachelor/Update/Course/update_course.php?course_year=$course_year'> �ǡ�èѴ�Ԫ����¹</a><br>
		<a href='index.php'>��Ѻ˹����ѡ </a>
    <br>
    </font></td>
    <td width='619' valign='top' >	
	     <form name='form' method='post' action='update_structure_category.php'>
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr> 
            <td height='21' colspan='11' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵúѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year<br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ </font><font size='2' face='Tahoma'><br>&nbsp;
                </font></div>
            </td>
          </tr>
          <tr>
            <td height='31' colspan='11' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>14.2 
              �ç���ҧ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td height='31' width='33' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='31' width='169' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2' face='Tahoma'>������Ǵ�Ԫ�</font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' colspan='4'> 
              <div align='center'><font face='Tahoma' size='2'>���������֡�ҷ�� 
                1</font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' colspan='5'> 
              <div align='center'><font face='Tahoma' size='2'>���������֡�ҷ�� 
                2</font></div>
            </td>
          </tr> ";
	// select data from category 
	$query_category = "Select * From $Categorytable Where Course_year = '$course_year' ";
	$result_category = mysql_query($query_category); 
    $cnumber = mysql_numrows($result_category);
	$ci = 0;
	if ($ci < $cnumber) 
        {
			$count = 1;
		while ($row = mysql_fetch_array($result_category))
		{
		$category = htmlspecialchars($row[Category]); 
        $cprogram1_unit = htmlspecialchars($row[Cprogram1_unit]); 
		$cprogram2_unit = htmlspecialchars($row[Cprogram2_unit]);
	echo "
          <tr> 
            <td height='31' width='33' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
            </td>
            <td height='31' width='169' bgcolor='#F7F7F7'> 
              <div align='center'> <font size='2' face='Tahoma'> 
                <input type='text' name='category_new[$count]' size='20' value='$category'>
                </font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' width='45'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' width='40'> 
              <div align='center'><font size='2' face='Tahoma'> 
                <input type='text' name='cprogram1_unit_new[$count]' size='3' maxlength='3' value='$cprogram1_unit'>
                </font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' width='57'> 
              <div align='center'><font face='Tahoma' size='2'>˹��¡Ե</font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' bordercolor='#FFFFFF' width='47'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' width='48'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' width='37'> 
              <div align='center'><font size='2' face='Tahoma'> 
                <input type='text' name='cprogram2_unit_new[$count]' size='3' maxlength='3' value='$cprogram2_unit'>
                </font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' width='56'> 
              <div align='center'><font face='Tahoma' size='2'>˹��¡Ե</font></div>
            </td>
            <td height='31' bgcolor='#D2F8FD' colspan='2' width='46'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
            </td>
          </tr>";
				$category_old_temp[$count] = $category;
				echo "<input type='hidden' name='category_old[$count]' value='$category_old_temp[$count]'>";
			$count++;
					}
			echo"<input type='hidden' name='count' value='$count'> 
			<tr> 
            <td height='30' width='33' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
            <td height='30' width='169' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
           <td height='30' bgcolor='#D2F8FD' colspan='4'><font size='2' face='Tahoma'></font></td>
		    <td height='30' bgcolor='#D2F8FD' colspan='5'><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            <td height='42' colspan='11' bgcolor='#F7F7F7'> 
              <div align='center'> 
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
              </div>
            </td>
          </tr>
	        </table>
				<input type='hidden' name='course_year' value='$course_year'>
		      </form>
		    </td>
		  </tr>
		</table>";
		}
		else { 
	 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>����բ�������Ǵ�Ԫ�</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			}
?>
			
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
