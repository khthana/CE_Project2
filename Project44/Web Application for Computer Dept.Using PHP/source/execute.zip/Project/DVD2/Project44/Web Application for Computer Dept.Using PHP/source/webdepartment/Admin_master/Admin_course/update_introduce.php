<html>
<head>
<title>��䢢�������ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
echo "
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='11' bgcolor='#DAEEFE' >&nbsp;</td>
    <td width='140' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>�����ѡ�ٵû�ԭ���<br>
       <a href='structure_update_course.php?course_year=$course_year' target ='_parent'>����ç���ҧ��ѡ�ٵ�</a><br>
	 <a href='structure_update_category.php?course_year=$course_year' target ='_parent'>�����Ǵ�Ԫ�</a><br>
	  <a href='structure_update_group.php?course_year=$course_year' target ='_parent'>����Ң��Ԫ�</a><br>
		<a href='Master/Update/Subject/update_subject.php?course_year=$course_year' target ='_parent'>�������Ԫ�</A><br>
	  <a href='Master/Update/Course/update_course.php?course_year=$course_year' target ='_parent'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;
		</td>
    <td width='619' valign='top' > ";

$ct = strlen($ctname);
$ce = strlen($cename);
$ft = strlen($ftname);
$st = strlen($stname);
$fe = strlen($fename);
$se = strlen($sename);
$accept = htmlspecialchars($accept);
$philosophy_article = htmlspecialchars($philosophy_article);
$program = htmlspecialchars($program);
$property = htmlspecialchars($property);
$test = htmlspecialchars($test);
$csystem = htmlspecialchars($csystem);
$ctime = htmlspecialchars($ctime);
$register = htmlspecialchars($register);
$process = htmlspecialchars($process);
$place_tool = htmlspecialchars($place_tool);


$accept = eregi_replace(chr(13),"<br>",$accept);
$accept = eregi_replace(" ","&nbsp;",$accept);
$philosophy_article = eregi_replace(chr(13),"<br>",$philosophy_article);
$philosophy_article = eregi_replace(" ","&nbsp;",$philosophy_article);
$program = eregi_replace(chr(13),"<br>",$program);
$program = eregi_replace(" ","&nbsp;",$program);
$property = eregi_replace(chr(13),"<br>",$property);
$property = eregi_replace(" ","&nbsp;",$property);
$test = eregi_replace(chr(13),"<br>",$test);
$test = eregi_replace(" ","&nbsp;",$test);
$csystem = eregi_replace(chr(13),"<br>",$csystem);
$csystem = eregi_replace(" ","&nbsp;",$csystem);
$ctime = eregi_replace(chr(13),"<br>",$ctime);
$ctime = eregi_replace(" ","&nbsp;",$ctime);
$register = eregi_replace(chr(13),"<br>",$register);
$register = eregi_replace(" ","&nbsp;",$register);
$process = eregi_replace(chr(13),"<br>",$process);
$process = eregi_replace(" ","&nbsp;",$process);
$place_tool = eregi_replace(chr(13),"<br>",$place_tool);
$place_tool = eregi_replace(" ","&nbsp;",$place_tool);

if(($ct != 0)&&($ce != 0)&&($ft != 0)&&($st != 0)&&($fe != 0)&&($se != 0))
{
$query_delete = "DELETE  FROM $Introducetable Where Course_year = '$course_year'"; 
$result_delete = mysql_db_query($dbName,$query_delete);
	$sql = "INSERT INTO $Introducetable(Course_year,Ctname,Cename,Ftname,Stname,Fename,Sename,Accept,Philosophy_Article,Program,Property,Test,Csystem,Ctime,Register,Process,Year1,Year2,Year3,Year4,Year5,A_year1,A_year2,A_year3,A_year4,A_year5,B_year1,B_year2,B_year3,B_year4,B_year5,Sum1,Sum2,Sum3,Sum4,Sum5,End1,End2,End3,End4,End5,Place_Tool) VALUES ('$course_year','$ctname','$cename','$ftname','$stname','$fename','$sename','$accept','$philosophy_article','$program','$property','$test','$csystem','$ctime','$register','$process','$year1','$year2','$year3','$year4','$year5','$a_year1','$a_year2','$a_year3','$a_year4','$a_year5','$b_year1','$b_year2','$b_year3','$b_year4','$b_year5','$sum1','$sum2','$sum3','$sum4','$sum5','$end1','$end2','$end3','$end4','$end5','$place_tool')";
$result = mysql_db_query($dbName,$sql);
	
//$query_introduce="Update $Introducetable Set Course_year = '$course_year_new' Where Course_year = '$course_year' ";
//$result_introduce = mysql_db_query($dbName,$query_introduce);

//$query_structure="Update $Structuretable Set Course_year = '$course_year_new' Where Course_year = '$course_year' ";
//$result_structure = mysql_db_query($dbName,$query_structure);

//$query_category="Update $Categorytable  Set Course_year = '$course_year_new' Where Course_year = '$course_year' ";
//$result_category = mysql_db_query($dbName,$query_category);

//$query_gsubject ="Update $Gsubjecttable  Set Course_year = '$course_year_new' Where Course_year = '$course_year' ";
//$result_gsubject = mysql_db_query($dbName,$query_gsubject);

//$query_select_course ="Update $Select_coursetable  Set Course_year = '$course_year_new' Where Course_year = '$course_year' ";
//$result_select_course = mysql_db_query($dbName,$query_select_course);

echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>��������ѡ�ٵ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'introduce_update.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
		}
else {
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			 MYSQL_CLOSE();
        }
?>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align='center'><font face='Tahoma' size='1'>Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height='8'> 
      <hr align='center' width='95%' size='2'>
    </td>
  </tr>
  <tr> 
    <td> 
      <div align='center'></div>
    </td>
  </tr>
</table>
</body>
</html>