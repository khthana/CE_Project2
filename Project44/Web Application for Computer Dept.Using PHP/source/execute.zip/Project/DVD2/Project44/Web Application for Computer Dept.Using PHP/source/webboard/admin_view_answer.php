<?php
	session_start();
	include("webboard.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	if(($ad_code!=$id) or ($tmp!=$id)){
		require ('overtime.php');
		exit;
	}
	if($name=='root'){
		require ('headroot.php');
	}else{
		require ('head.php');
	}
	$sql = "select * from answer where a_qid='$q_id'";
	$db_query = mysql_db_query ($dbname, $sql);
	if (!$db_query){
		print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
		exit;
	}
	else{
		$nums_rows = mysql_num_rows($db_query);
				print "<form name='weblogin'  method='post'  action='del_answer.php?q_id=$q_id&id=$id&name=$name'  autocomplete='off' >";
				print "<table border=0  width=100% cellspacing=1 cellpadding=4>";
				print "<tr ><td bgcolor=$corlor_head align=center width=10><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B><CENTER>ź</CENTER></B></FONT></td>";
				print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Created</b></font></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Name</b></font></td>";
				print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Ip</b></font></td></tr>";
				for ($i=0;$i<$nums_rows;$i++){
				$result1 = mysql_fetch_array($db_query);
				$a_message = $result1[a_message];
				$a_email = $result1[a_email];
				$a_name = $result1[a_name];
				$a_date = $result1[a_datetime];
				$a_icq = $result1[a_icq];
				$a_id = $result1[a_id];
				$a_ip = $result1[a_ip];
				
				$a_name = stripslashes($a_name);
				$a_email = stripslashes($a_email);
				$a_ip = stripslashes($a_ip);
				$a_date = stripslashes($a_date);
				$a_icq = stripslashes($a_icq);
				$a_message = stripslashes($a_message);
					print "<Tr> <Td bgcolor=$bg1 width=10><input type='checkbox' name='dela[$i]' value=$a_id>";
					print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_date</font></Td>";
					print "<Td bgcolor=$bg1><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_name</font></Td>";
					print "<Td  bgcolor=$bg2 ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_ip</font></Td></tr>";
		}	// end for
	print "</table>";
	} // end else
	print "<center><hr width='80%'><input type='submit' name='Submit' value='Delect'>";
	 print "</center>";
	print "</form>";
?>