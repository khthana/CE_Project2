<?session_start();
if($admin[0]=='1')
{
?>
<html>
<head>
<META  http-equiv="content-type" content="text/html;charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
<title>ADMIN</title>
<script>
<!-- START HIDE
var tick;
function stop() {
	clearTimeout(tick);
}
function usnotime(){
	var ut=new Date();
	var h,m,s;
	var time='';
	h=ut.getHours();
	m=ut.getMinutes();
	s=ut.getSeconds();
	if(s<=9) s='0'+s;
	if(m<=9) m='0'+m;
	if(h<=9) h='0'+h;
	time+=h+':'+m+':'+s;
    document.rclock.rtime.value=time;
	tick=setTimeout('usnotime()',1000);
}
// STOP HIDE -->
</script>

<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function NewWindow(mypage, myname, w, h, scroll) {
var winl = (screen.width - w) / 2;
var wint = (screen.height - h) / 2;
winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
win = window.open(mypage, myname, winprops)
if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}
//  End -->
</script>
</HEAD>

<style>
.a1
  {
  color:#FFFFFF; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: center;
  }   
.a2
  {
  color:#FF33FF; /* ��ǧ */
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: center;
  }   
.a3
  {
  color:#006AD5; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 13;
  text-align: center;
  }   

.a4
  {
  color:#0063C6; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 80;
  text-align: center;
  }   
</style>
<SCRIPT LANGUAGE="JavaScript">
function expandingWindow(website) {
var heightspeed = 2; // vertical scrolling speed (higher = slower)
var widthspeed = 7;  // horizontal scrolling speed (higher = slower)
var leftdist = 0;    // distance to left edge of window
var topdist = 0;     // distance to top edge of window
if (document.all) {
var winwidth = window.screen.availWidth - leftdist;
var winheight = window.screen.availHeight - topdist;
var sizer = window.open("","","left=" + leftdist + ",top=" + topdist + ",width=1,height=1,scrollbars=yes");
for (sizeheight = 1; sizeheight < winheight; sizeheight += heightspeed) {
sizer.resizeTo("1", sizeheight);
}
for (sizewidth = 1; sizewidth < winwidth; sizewidth += widthspeed) {
sizer.resizeTo(sizewidth, sizeheight);
}
sizer.location = website;
}
else
window.location = website;
}
</script>
<?
include("connect.inc.php");
$dbname=gwebboard();
			if($submit)
			{
			$c=0;
			  while($c<$row)
               {
			     if($check[$c]!="")
				  {
                   $sql="select * from admin where email ='$check[$c]'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error2");
		           $result=mysql_fetch_array($dbquery);
				   $nameboards=$result[nameboard];
				  
				   //źsub���������ǡѺ nameboard
	               $dirname=$nameboards;
                   $dh=opendir($dirname);
                   while($file=readdir($dh))
                      {
                        if(($file!='.')&&($file!='..'))
						  {
					         $dirname2=$file;
							 $dh2=opendir($dirname.'/'.$dirname2);
						      while($file2=readdir($dh2))
                                  {
                                     if(($file2!='.')&&($file2!='..'))
									   {     
									    $dirname3=$file2;
							            $dh3=opendir($dirname.'/'.$dirname2.'/'.$dirname3);
                                              while($file3=readdir($dh3))
                                                 {
                                                    if(($file3!='.')&&($file3!='..'))
						                                unlink($dirname.'/'.$dirname2.'/'.$dirname3.'/'.$file3); 
												 }//while3	
				                               rmdir($dirname.'/'.$dirname2.'/'.$dirname3);
					                           //closedir($dh3);
									   }//if3
								  }//while2
						   rmdir($dirname.'/'.$dirname2);
				           //closedir($dh2);
						   }//if2
						}//while1
                     rmdir($dirname);
					closedir($dh);

				   $sql="select * from  $nameboards";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error3");
		           $num_rows=mysql_num_rows($dbquery);
				   
				   $c2=0;
				   while($c2<$num_rows)
				      {
				       $result=mysql_fetch_array($dbquery);
				       
	   				   //źtable �ͧ topic
				       $sql1="drop table $nameboards$result[id]";
		               $dbquery1=mysql_db_query($dbname,$sql1)or die("error4");
                       $c2++; 				     
					 }
				   //źtable �ͧ nameboard
				   $sql="drop table $nameboards";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error5");
				   
	    		   //ź record 㹵��ҧ admin 
		           $sql="delete from admin where email ='$check[$c]'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error6");
				  
				   //ź record 㹵��ҧ user 
		           $sql="delete from user where email ='$check[$c]' and own='admin'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error7");
				 
				   //ź record 㹵��ҧ user 
		           $sql="delete from user where name ='' and own='user' and request='$nameboards'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error8");
				   
				   //ź record 㹵��ҧ userboard 
		           $sql="delete from userboard where nameboard='$nameboards'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error9");
				 
				   //update request table user
		           $sql="update user set request='' where request='$nameboards' and name!=''";
                   $dbquery=mysql_db_query($dbname,$sql)or die("error10");
				 
				  
				 
				 }//if check
			    $c++;
			   }//while
			}//if($submit=='Delete')
			 include("dateth.inc.php");
		    $p=dateth();	
	?>		
		    <BODY bgcolor='#FFFFFF' onload='usnotime()' onunload='stop()'>            
<table border=0  width="760" align=left height="640">
  <tr class=a> 
    <td valign="top" height="164">
      <table width="760" border="0">
        <tr> 
          <td width="357"><img src="images/logo.gif" width="305" height="74"></td>
          <td><font color="#FF0066" style="font-size:18px"><b>ADMIN</b></font> 
          </td>
        </tr>
      </table>
      <table width="760" border=0 cellspacing=1 cellpadding=1 height="37">
        <tr class=a> 
          <td  valign=middle align=left width="100%" class=a height="41"><b><font color=#003C77 style="font-size:16px"> 
            <?print($p);?>
            </font></b></td>
          <td align=right width='100%' height="41"> 
            <form name='rclock'>
              <input type='text' name='rtime' size='8'>
            </form>
          </td>
        </tr>
      </table>
      <form action='admin.php' method=post>
        <table border=0 align=center cellspacing=1 width="760">
          <tr height=25 bgcolor=#0053A6> 
            <th  align=center width=50 class=a1 height="18">C</th>
            <th  align=center width=100 class=a1 height="18">�ѹ������ҧ</th>
            <th  align=center width=300 class=a1 height="18">Email</th>
            <th  align=center width=210 class=a1 height="18">���� group</th>
            <th  align=center width=100 class=a1 height="18">Update����ش</th>
          </tr>
          <?	
			//�Ҩӹǹ record �ͧ���ҧadmin����ա�� record 
		    $sql="select * from admin";
		    $dbquery=mysql_db_query($dbname,$sql)or die("error");
		    $num_rows=mysql_num_rows($dbquery);
			$c=0;
			while($c<$num_rows)
               { 
				 $result=mysql_fetch_array($dbquery);
				 ?>
          <tr height=20> 
            <td align=center width=50 class=a1 bgcolor=#EEF3FD> 
              	<?
				print("<input type=checkbox value=$result[email] name='check[$c]'>");
                 ?>
			</td>
            <td  align=center width=150 class=a3 bgcolor=#DBE6FD> 
              <?print($result[date1]);?>
            </td>
            <td  align=center width=200 class=a3 bgcolor=#EEF3FD> 
              <?print($result[email]);?>
            </td>
            <td  align=center width=200 class=a3 bgcolor=#DBE6FD> 
              <?print($result[nameboard]);?>
            </td>
            <td  align=center width=150 class=a3 bgcolor=#EEF3FD> 
              <?print($result[date2]);?>
            </td>
          </tr>
          <?
				 $c++;  			   
			   }
			?>
        </table>
        <!--<input type=hidden value='$email' name='email'>
			<input type=hidden value='$pass' name='pass'>-->
        <input type=hidden value=<?print($num_rows);?> name=row>
        <br>
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value='Delete' name=submit>
      </form>
      <?
 //�Դ�ҹ������
     closedb();
?>
    </td>
  </tr>
<tr>
    <td valign="top"> 
      <table width="760" border="0" cellspacing="0" cellpadding="0">
          <tr class=a>
    <td>&nbsp;</td>
  </tr>
  <tr class=a>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8" class=a>
      <hr align="center" width="550" >
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
    </td>
</tr>
</table>
</body>
</html>
<?
}
?>