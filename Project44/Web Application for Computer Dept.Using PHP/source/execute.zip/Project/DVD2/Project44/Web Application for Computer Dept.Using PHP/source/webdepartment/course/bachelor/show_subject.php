<html>
<head>
<title>�ʴ�����������ԪҢͧ��ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="../script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94" align="center">
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="772" border="0" cellspacing="0" cellpadding="0" align="center">
<?
	include ("connect_course.inc.php");
	echo "
   <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='130' bgcolor='#D2F8FD' valign='top' ><font size='2' face='Tahoma, Microsoft Sans Serif'><br>
      <a href='index.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='structure.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
     <a href='tendency.php?course_year=$course_year'> Ἱ����֡��</a><br>
      <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
		&nbsp;</td>
   <td width='10' valign='top' >&nbsp; </td>
    <td width='609' valign='top' > 
        <table width='100%' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
         <tr> 
          <td height='54' colspan='11' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵ��ѳ�Ե 
              �Ң��Ԫ����ǡ������������� <br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp; </font></div>
          </td>
        </tr>
		<tr bgcolor='#D2F8FD'> 
            <td colspan='8' height='21'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></font> 
              </div>
              <div align='center'></div>
            </td>
          </tr>";
		$pass ="";
	$number =0;
//start check string x 
	if (strstr($code,'x'))
	{
		$scode = eregi_replace("x","%",$code);
		// start check subject select
		$query = MYSQL_DB_QUERY($dbName,"Select * From $Subjecttable Where Code Like '$scode' AND Course_year='$course_year' ");
		$number = MYSQL_NUMROWS($query);
		if ($number >0) {	 $check ='pass';	}
	}
			// select vaules in subjecttable
				$query = "Select * From $Subjecttable Where Code='$code' AND Course_year='$course_year' ";
				$result = mysql_query($query);
	if ($result)
	{
		while ($row = mysql_fetch_array($result)) 
	{
	$category = htmlspecialchars($row[Category]);
	$gsubject = htmlspecialchars($row[Gsubject]);
	$code = htmlspecialchars($row[Code]);
	$name = htmlspecialchars($row[Name]);
	$ename = htmlspecialchars($row[Ename]);
	$unit = htmlspecialchars($row[Unit]);
	$unit_detail = htmlspecialchars($row[Unit_detail]);
	$unit_operation = htmlspecialchars($row[Unit_operation]);
	$url = htmlspecialchars($row[Url]);

	$code_subject_to = htmlspecialchars($row[Code_subject_to]);
	$name_subject_to = htmlspecialchars($row[Name_subject_to]);
	$ename_subject_to = htmlspecialchars($row[Ename_subject_to]);
	
	$subject_detail = $row[Subject_detail];
	
   	$sum = $sum+$unit;
	$sum_detail = $sum_detail+ $unit_detail;
	$sum_operation = $sum_operation+ $unit_operation;
		echo"
          <tr> 
            <td colspan='2' height='19'  bgcolor='#D2F8FD'> 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;������Ǵ�Ԫ�</font></div>
            </td>
             <td colspan='6' height='19' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$category &nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���͡�����Ԫ�</font></div>
            </td>
          <td bgcolor='#F7F7F7' height='19' colspan='6'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$gsubject &nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����Ԫ�</font></div>
            </td>
          <td bgcolor='#F7F7F7' height='19' colspan='6'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$code&nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����Ԫ�������</font></div>
            </td>
            <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$name&nbsp;</font></td>
          </tr>

          <tr> 
           <td colspan='2' bgcolor='#D2F8FD' height='19' > 
   <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�����Ԫ������ѧ���</font></div>
            </td>
            
          <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$ename&nbsp;</font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;˹��¡Ե</font></div>
            </td>
            <td width='35' bgcolor='#F7F7F7' height='19'>
			  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$unit&nbsp;</font></div></td>
            <td width='99' bgcolor='#D2F8FD' height='19'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>������</font></div>
            </td>
            <td width='37' bgcolor='#F7F7F7' height='19'><div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$unit_detail&nbsp;</font></div></td>
            <td width='98' bgcolor='#D2F8FD' height='19'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>��Ժѵ�</font></div>
            </td>
            <td width='38' bgcolor='#F7F7F7' height='19'><div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$unit_operation&nbsp;</font></div></td>
            <td width='124' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
          </tr>
          <tr> 
            
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���ྨ����Ԫ�</font></div>
            </td>
            
          <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma, Microsoft Sans Serif'><A href='http://$url'  target ='_PARENT'>&nbsp;$url&nbsp; </font></A></font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ԪҺѧ�Ѻ��͹</font></div>
            </td>
            <td colspan='6' bgcolor='#F7F7F7' height='19'><font size='2' face='Tahoma, Microsoft Sans Serif'><a href='show_subject.php?code=$code_subject_to&&course_year=$course_year'>&nbsp;$code_subject_to $name_subject_to $ename_subject_to&nbsp;</a></font> </td>
          </tr>";
		  if($check == 'pass')
		  {
echo "
          <tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��ª����Ԫ����Ǵ</font></div>
            </td>
             <td colspan='6' bgcolor='#F7F7F7' height='19'>";
				$number =0;
				$query = MYSQL_DB_QUERY($dbName,"Select * From $Subjecttable Where Code Like '$scode' AND Course_year='$course_year' ");
				$number = MYSQL_NUMROWS($query);
				if ($number <= 1)
				{
					echo "<font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></td>";
				}
			else
				{			
						$query1 = "Select * From $Subjecttable Where Code Like '$scode' AND Course_year='$course_year' ";
						$result1 = mysql_query($query1);
						$n = 0;
				while ( $row = mysql_fetch_array($result1)) 
				{		
						$gcode = htmlspecialchars($row[Code]);
						$gname = htmlspecialchars($row[Name]);
						$gename = htmlspecialchars($row[Ename]);
						if (($n == 0)&&($code !=  $gcode))
						{
						echo "<font size='2' face='Tahoma, Microsoft Sans Serif'><a href='show_subject.php?code=$gcode&&course_year=$course_year'>&nbsp;$gcode $gname $gename</font></A>";
						}
						$n =$n +1;
				}//end of while					
			}//end of if
			echo "</td></tr>";
}//end of check
echo "
			<tr> 
            <td colspan='2' bgcolor='#D2F8FD' height='19'   valign='top'> 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����������Ԫ�</font></div>
            </td>
            <td colspan='6' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$subject_detail</font></td>
           </tr>
          <tr bgcolor='#D2F8FD'> 
            <td colspan='8' height='9'>&nbsp;</td>
          </tr>
          <tr> 
            <td colspan='8' bgcolor='#F7F7F7' height='10'>&nbsp;</td>
          </tr>";
		} // end of while
	mysql_free_result($result);
	MYSQL_CLOSE();
	} //end of if result
  ?>
        </table>
    </td>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut"s Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
