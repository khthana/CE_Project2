<html>
<head>
<title>��䢢�������ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
   <?
	 include ("connect_course.inc.php");
     echo "
	 <tr>
    <td width='11'>&nbsp;</td>
    <td width='9' bgcolor='#EAEAFF'>&nbsp;</td>
    <td width='140' bgcolor='#EAEAFF' valign='top'><font face='Tahoma' size='2' color='#9900CC'><br>
      �����ѡ�ٵû�ԭ���͡</font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_update_course.php?course_year=$course_year'>����ç���ҧ��ѡ�ٵ�</a><br>
	  	  <a href='structure_update_msubject.php?course_year=$course_year'>����Ԫ���ѡ</a><br>
	  <a href='structure_update_category.php?course_year=$course_year'>�����Ǵ�Ԫ�</a><br>
	  <a href='structure_update_group.php?course_year=$course_year'>����Ң��Ԫ�</a><br>
	  <a href='Doctor/Update/Subject/update_subject.php?course_year=$course_year'>�������Ԫ�</a><br>
	  <a href='Doctor/Update/Course/update_course.php?course_year=$course_year'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;
	</td>
    <td width='619' valign='top'>";
	
	$query = "Select * From $Introducetable Where Course_year = '$course_year'order by Ctname ASC LIMIT 0, 50 ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$ctname = htmlspecialchars($row[Ctname]);
	$cename = htmlspecialchars($row[Cename]);
	$ftname = htmlspecialchars($row[Ftname]);
	$stname = htmlspecialchars($row[Stname]);
	$fename = htmlspecialchars($row[Fename]);
	$sename = htmlspecialchars($row[Sename]);
	$accept = $row[Accept];
	$philosophy_article = $row[Philosophy_Article];
	$program = $row[Program];
	$property = $row[Property];
	$test = $row[Test];
	$csystem = $row[Csystem];
	$ctime = $row[Ctime];
	$register = $row[Register];
	$process = $row[Process];

	$myear1 = $row[Myear1];
	$myear2 = $row[Myear2];
	$myear3 = $row[Myear3];
	$myear4 = $row[Myear4];
	$myear5 = $row[Myear5];

	$m1_year1 = $row[M1_year1];
	$m1_year2 = $row[M1_year2];
	$m1_year3 = $row[M1_year3];
	$m1_year4 = $row[M1_year4];
	$m1_year5 = $row[M1_year5];
	
	$m2_year1 = $row[M2_year1];
	$m2_year2 = $row[M2_year2];
	$m2_year3 = $row[M2_year3];
	$m2_year4 = $row[M2_year4];
	$m2_year5 = $row[M2_year5];

	$m3_year1 = $row[M3_year1];
	$m3_year2 = $row[M3_year2];
	$m3_year3 = $row[M3_year3];
	$m3_year4 = $row[M3_year4];
	$m3_year5 = $row[M3_year5];

	$msum1 = $row[Msum1];
	$msum2 = $row[Msum2];
	$msum3 = $row[Msum3];
	$msum4 = $row[Msum4];
	$msum5 = $row[Msum5];

	$mend1 = $row[Mend1];
	$mend2 = $row[Mend2];
	$mend3 = $row[Mend3];
	$mend4 = $row[Mend4];
	$mend5 = $row[Mend5];
	

	$dyear1 = $row[Dyear1];
	$dyear2 = $row[Dyear2];
	$dyear3 = $row[Dyear3];
	$dyear4 = $row[Dyear4];
	$dyear5 = $row[Dyear5];

	$d1_year1 = $row[D1_year1];
	$d1_year2 = $row[D1_year2];
	$d1_year3 = $row[D1_year3];
	$d1_year4 = $row[D1_year4];
	$d1_year5 = $row[D1_year5];
	
	$d2_year1 = $row[D2_year1];
	$d2_year2 = $row[D2_year2];
	$d2_year3 = $row[D2_year3];
	$d2_year4 = $row[D2_year4];
	$d2_year5 = $row[D2_year5];

	$d3_year1 = $row[D3_year1];
	$d3_year2 = $row[D3_year2];
	$d3_year3 = $row[D3_year3];
	$d3_year4 = $row[D3_year4];
	$d3_year5 = $row[D3_year5];

	$d4_year1 = $row[D4_year1];
	$d4_year2 = $row[D4_year2];
	$d4_year3 = $row[D4_year3];
	$d4_year4 = $row[D4_year4];
	$d4_year5 = $row[D4_year5];

	$d5_year1 = $row[D5_year1];
	$d5_year2 = $row[D5_year2];
	$d5_year3 = $row[D5_year3];
	$d5_year4 = $row[D5_year4];
	$d5_year5 = $row[D5_year5];


	$dsum1 = $row[Dsum1];
	$dsum2 = $row[Dsum2];
	$dsum3 = $row[Dsum3];
	$dsum4 = $row[Dsum4];
	$dsum5 = $row[Dsum5];

	$dend1 = $row[Dend1];
	$dend2 = $row[Dend2];
	$dend3 = $row[Dend3];
	$dend4 = $row[Dend4];
	$dend5 = $row[Dend5];
	$place_tool = $row[Place_Tool];

	$accept = eregi_replace('<br>',chr(13),$row[Accept]);
	$philosophy_article = eregi_replace('<br>',chr(13),$row[Philosophy_Article]);
	$program = eregi_replace('<br>',chr(13),$row[Program]);
	$property = eregi_replace('<br>',chr(13),$row[Property]);
	$test = eregi_replace('<br>',chr(13),$row[Test]);
	$csystem = eregi_replace('<br>',chr(13),$row[Csystem]);
	$ctime = eregi_replace('<br>',chr(13),$row[Ctime]);
	$register = eregi_replace('<br>',chr(13),$row[Register]);
	$process = eregi_replace('<br>',chr(13),$row[Process]);

	$place_tool= eregi_replace('<br>',chr(13),$row[Place_Tool]);
	
	  echo "<form name='form' method='post' action='update_introduce.php'>
      <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr valign='middle'> 
            <td colspan='2' height='103' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե               �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
			   ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� </font> <font face='Tahoma' size='2' color='#515151' ><br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
          </td>
        </tr>
          <tr bgcolor='#F7F7F7'> 
            <td colspan='2' height='26'><b><font size='2' color='#000000' face='Tahoma'>1. 
              ������ѡ�ٵ� </font></b></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>����������</font></td>
          <td width='496' bgcolor='#EAEAFF' height='34'> 
              <input type='text' name='ctname' size='50' value='$ctname'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>���������ѧ���</font></td>
          <td width='496' bgcolor='#EAEAFF' height='34'> 
              <input type='text' name='cename' size='50' value='$cename'>
          </td>
        </tr>
        <tr> 
            <td colspan='2' height='26' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'><b>2. 
              ���ͻ�ԭ��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='496' bgcolor='#EAEAFF' height='34'> 
              <input type='text' name='ftname' size='50' value='$ftname'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='496' bgcolor='#EAEAFF' height='34'> 
              <input type='text' name='stname' size='50' value='$stname'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
            (�ѧ���)</font></td>
          <td width='496' bgcolor='#EAEAFF' height='34'> 
              <input type='text' name='fename' size='50' value='$fename'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font face='Tahoma' size='2' color='#000000'>������� 
            (�ѧ���)</font></td>
          <td width='496' bgcolor='#EAEAFF' bordercolor='#FFFFFF' height='34'> 
              <input type='text' name='sename' size='50' value='$sename'>
          </td>
        </tr>
        <tr> 
          <td colspan='2' height='26' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>3. 
            ˹��§ҹ�Ѻ�Դ�ͺ</b></font></td>
        </tr>
        <tr> 
          <td width='98' height='52' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='496' height='52' bgcolor='#EAEAFF'> 
              <textarea name='accept' cols='80'>$accept</textarea>
          </td>
        </tr>
		   <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2' color='#000000'><b>4. 
              ��Ѫ������ѵ�ػ��ʧ��ͧ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#EAEAFF' height='132'><font face='Tahoma' size='2'> 
              <textarea name='philosophy_article' cols='80' rows='7'>$philosophy_article</textarea>
              </font></td>
          </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>5. 
              ��˹�����Դ�͹</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='34'><font face='Tahoma' size='2'> 
              <input type='text' name='program' size='50' value='$program'>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'>�<b>6. 
              �س���ѵԢͧ�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='52'><font face='Tahoma' size='2'> 
              <textarea name='property' cols='80'>$property</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>7. 
              ��äѴ���͡�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='52'><font face='Tahoma' size='2'> 
              <textarea name='test' cols='80'>$test</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>8. 
              �к�����֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='52'><font face='Tahoma' size='2'> 
              <textarea name='csystem' cols='80'>$csystem</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>9. 
              �������ҡ���֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='52'><font face='Tahoma' size='2'> 
              <textarea name='ctime' cols='80'>$ctime</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>10. 
              ���ŧ����¹���¹</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='52'><font face='Tahoma' size='2'> 
              <textarea name='register' cols='80'>$register</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><b><font face='Tahoma' size='2'>11. 
              ����Ѵ����С������稡���֡��</font></b></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#EAEAFF' height='52'><font face='Tahoma' size='2'> 
              <textarea name='process' cols='80'>$process</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='27'><b><font face='Tahoma' size='2'>12. 
              �ӹǹ�ѡ�֡��</font></b></td>
          </tr>
          <tr> 
            <td width='98' bgcolor='#F7F7F7' height='399'><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#EAEAFF' height='399'> 
              <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center'>
                <tr> 
                  <td colspan='6' height='25'> <b><font size='2' face='Tahoma'>����Ѻ��騺��ԭ��� 
                    (3 ��) </font></b> </td>
                </tr>
                <tr> 
                  <td rowspan='2'> 
                    <div align='center'></div>
                    <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                  </td>
                  <td colspan='5' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>�ա���֡��</font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='myear1' size='4' maxlength='4' value='$myear1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='myear2' size='4' maxlength='4' value='$myear2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='myear3' size='4' maxlength='4' value='$myear3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='myear4' size='4' maxlength='4' value='$myear4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='myear5' size='4' maxlength='4' value='$myear5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      1</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m1_year1' size='4' maxlength='3'  value='$m1_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m1_year2' size='4' maxlength='3' value='$m1_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m1_year3' size='4' maxlength='3' value='$m1_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m1_year4' size='4' maxlength='3' value='$m1_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m1_year5' size='4' maxlength='3' value='$m1_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      2</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m2_year1' size='4' maxlength='3' value='$m2_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m2_year2' size='4' maxlength='3' value='$m2_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m2_year3' size='4' maxlength='3' value='$m2_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m2_year4' size='4' maxlength='3' value='$m2_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m2_year5' size='4' maxlength='3' value='$m2_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      3</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m3_year1' size='4' maxlength='3' value='$m3_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m3_year2' size='4' maxlength='3' value='$m3_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m3_year3' size='4' maxlength='3' value='$m3_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m3_year4' size='4' maxlength='3' value='$m3_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='m3_year5' size='4' maxlength='3' value='$m3_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>���</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='msum1' size='4' maxlength='3' value='$msum1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='msum2' size='4' maxlength='3' value='$msum2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='msum3' size='4' maxlength='3' value='$msum3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='msum4' size='4' maxlength='3' value='$msum4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='msum5' size='4' maxlength='3' value='$msum5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>�Ҵ��ҨШ�����֡��</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='mend1' size='4' maxlength='3' value='$mend1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='mend2' size='4' maxlength='3' value='$mend2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='mend3' size='4' maxlength='3' value='$mend3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='mend4' size='4' maxlength='3' value='$mend4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='mend5' size='4' maxlength='3' value='$mend5'>
                      </font></div>
                  </td>
                </tr>
              </table>
              <b></b> 
              <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center'>
                <tr> 
                  <td colspan='6' height='25'> <b><font size='2' face='Tahoma'>����Ѻ��騺��ԭ�ҵ�� 
                    (5 ��) </font></b> </td>
                </tr>
                <tr> 
                  <td rowspan='2'> 
                    <div align='center'></div>
                    <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                  </td>
                  <td colspan='5' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>�ա���֡��</font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dyear1' size='4' maxlength='4' value='$dyear1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dyear2' size='4' maxlength='4' value='$dyear2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dyear3' size='4' maxlength='4' value='$dyear3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dyear4' size='4' maxlength='4' value='$dyear4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dyear5' size='4' maxlength='4' value='$dyear5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      1</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d1_year1' size='4' maxlength='3' value='$d1_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d1_year2' size='4' maxlength='3' value='$d1_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d1_year3' size='4' maxlength='3' value='$d1_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d1_year4' size='4' maxlength='3' value='$d1_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d1_year5' size='4' maxlength='3' value='$d1_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      2</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d2_year1' size='4' maxlength='3' value='$d2_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d2_year2' size='4' maxlength='3' value='$d2_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d2_year3' size='4' maxlength='3' value='$d2_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d2_year4' size='4' maxlength='3' value='$d2_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d2_year5' size='4' maxlength='3' value='$d2_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      3</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d3_year1' size='4' maxlength='3' value='$d3_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d3_year2' size='4' maxlength='3' value='$d3_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d3_year3' size='4' maxlength='3' value='$d3_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d3_year4' size='4' maxlength='3' value='$d3_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='d3_year5' size='4' maxlength='3' value='$d3_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      4 </font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d4_year1' size='4' maxlength='3' value='$d4_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d4_year2' size='4' maxlength='3' value='$d4_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d4_year3' size='4' maxlength='3' value='$d4_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d4_year4' size='4' maxlength='3' value='$d4_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d4_year5' size='4' maxlength='3' value='$d4_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      5 </font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d5_year1' size='4' maxlength='3' value='$d5_year1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d5_year2' size='4' maxlength='3' value='$d5_year2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d5_year3' size='4' maxlength='3' value='$d5_year3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d5_year4' size='4' maxlength='3' value='$d5_year4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='d5_year5' size='4' maxlength='3' value='$d5_year5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>���</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dsum1' size='4' maxlength='3' value='$dsum1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dsum2' size='4' maxlength='3' value='$dsum2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dsum3' size='4' maxlength='3' value='$dsum3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dsum4' size='4' maxlength='3' value='$dsum4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dsum5' size='4' maxlength='3' value='$dsum5'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='142' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'>�Ҵ��ҨШ�����֡��</font></div>
                  </td>
                  <td width='75' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dend1' size='4' maxlength='3' value='$dend1'>
                      </font></div>
                  </td>
                  <td width='68' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dend2' size='4' maxlength='3' value='$dend2'>
                      </font></div>
                  </td>
                  <td width='73' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dend3' size='4' maxlength='3' value='$dend3'>
                      </font></div>
                  </td>
                  <td width='63' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dend4' size='4' maxlength='3' value='$dend4'>
                      </font></div>
                  </td>
                  <td width='64' height='30'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='dend5' size='4' maxlength='3' value='$dend5'>
                      </font></div>
                  </td>
                </tr>
              </table>
              <b></b> </td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='27'><font face='Tahoma' size='2'><b>13. 
              ����ӹ�¤����дǡ㹡���֡�� �鹤�������Ԩ��</b></font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#EAEAFF' height='132'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'> 
              <textarea name='place_tool' cols='80' rows='7'>$place_tool</textarea>
              </font></td>
          </tr>
         <tr> 
          <td colspan='2' bgcolor='#F7F7F7'>
              <div align='center'>
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
              </div>
            </td>
        </tr>
      </table>
		<input type=hidden name=course_year value='$course_year'>
	  </form>";
		  	}
	}
	MYSQL_CLOSE();
	  ?>
    </td>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font size="1"><font size="1"><font face="Tahoma"></font></font></font></div>
    </td>
  </tr>
</table>

</body>
</html>
