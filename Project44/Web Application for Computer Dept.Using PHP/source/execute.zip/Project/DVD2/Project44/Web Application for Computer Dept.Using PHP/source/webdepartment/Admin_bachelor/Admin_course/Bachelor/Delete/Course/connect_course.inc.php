<?
	$hostname = "localhost";
	$username = "root";
	$password = "webmaster123";
	$Coursetable= "Course";
	$Subjecttable= "Subject";
	$Introducetable= "Introduce";
	$Structuretable= "Structure";
	$Categorytable= "Category";
	$Gsubjecttable= "Gsubject";
	$Select_coursetable= "Select_course";
	$Temptable= "Temp";
    $dbName = "Bachelor";
	MYSQL_CONNECT($hostname,$username,$password)
	OR DIE("Unable to connect to database");
	@mysql_select_db("$dbName") or die
	("Unable to select database");
?>