<?
session_start();
$m=session_id();
if($m==$mem[id1]){
}else{
	exit;
}
//print "".session_id();
include("alumni.inc");
include("md5.js");
if($name&&$pwd){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from data_alumni where std_username='$name'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	if($NRow==0){ 
?><title>Login Administrator</title>
			
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
		  <META http-equiv=refresh content="3; URL=login.php">
 <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
<?php
	}
	else{
		$row = mysql_fetch_array($result);
		$pwd1=$row["std_password1"];
		$std_n=$row["std_username"];
		$pwd1=$row["std_password1"];
		$pwd1=MD5($pwd1).$challenge;
		$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
		if($name==$std_n && $pwd==$pwd1) { 
	$sql1= "SELECT * FROM data_alumni WHERE std_username='$name'"; 
	$db_query1 = mysql_db_query($dbname, $sql1);
	$nums_rows1 = mysql_num_rows($db_query1);
		for ($i=0;$i<$nums_rows1;$i++){
		$result = mysql_fetch_array($db_query1);
		$std_number = $result[std_number];
			$mem[n]=$name;
			$mem[p]=$pwd;
			$mem[c]=$challenge;
			$mem[1]=$std_number;
		$std_id = $result[std_id ];
		$mem[id]=$std_id;
		$std_class = $result[std_class];
		$std_fullname = $result[std_fullname];
		$std_type1 = $result[std_type1];
		$std_nick = $result[std_nick];
		$std_type = $result[std_type];
		$std_days  = $result[std_days];
		$std_day  = $result[std_day];
		$std_mount  = $result[std_mount];
		$std_year  = $result[std_year];
		$std_position = $result[std_position ];
		$std_address_born = $result[std_address_born];
		$std_address_now= $result[std_address_now];
		$std_tel_home= $result[std_tel_home];
		$std_tel_work = $result[std_tel_work];
		$std_pager  = $result[std_pager];
		$std_icq  = $result[std_icq];
		$std_email  = $result[std_email];
		$std_homepage  = $result[std_homepage];
		$std_username  = $result[std_username];
		$std_password1 = $result[std_password1];
		$std_password2  = $result[std_password2];
		$std_question  = $result[std_question];
		$std_answer  = $result[std_answer];

		$std_id=stripslashes($std_id);
		$std_class = stripslashes($std_class);
		$std_fullname = stripslashes($std_fullname);
		$std_type1 = stripslashes($std_type1);
		$std_nick = stripslashes($std_nick);
		$std_type = stripslashes($std_type);
		$std_days  = stripslashes($std_days);
		$std_day  = stripslashes($std_day);
		$std_mount  = stripslashes($std_mount);
		$std_year  = stripslashes($std_year);
		$std_position = stripslashes($std_position );
		$std_address_born = stripslashes($std_address_born);
		$std_address_now= stripslashes($std_address_now);
		$std_tel_home= stripslashes($std_tel_home);
		$std_tel_work = stripslashes($std_tel_work);
		$std_pager  = stripslashes($std_pager);
		$std_icq  = stripslashes($std_icq);
		$std_email  = stripslashes($std_email);
		$std_homepage   = stripslashes($std_homepage);
		$std_question   = stripslashes($std_question);
		$std_answer   = stripslashes($std_answer);

		print "<Form Action=\"to_edit.php\" Method=Post>";
		print "<Center>";
        print "<table width=100% border=0 cellspacing=0 cellpadding=0>";
		print "<tr>";
		print "<td>";
       print "<table width=100% border=0 cellspacing=0 cellpadding=0>";
      print "<tr>";
     print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\" size=3>���ʹѡ�֡��<font color=#FF0000> * </font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
     print "<input size=30 name=std_id value='$std_id'>";
     print "</font></td>";
     print "</tr>";
     print "<tr>";
     print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>��蹷��<font color=#FF0000> ";
      print "*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
	  print "<input type=text size=30 name=std_class value='$std_class' >";
      print "</font></td>";
      print "</tr>";
	  print " <tr>";
      print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\" size=3>�ѡ�֡�� <font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\" size=3>";                                 
	  print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
	  if($std_type=="������ͧ"){
	  print "<input type=radio name=std_type value='������ͧ' checked>";
	  print "������ͧ <input type=radio name=std_type value='����'> ���� </font>";
	  }
	  else{
	  print "<input type=radio name=std_type value='������ͧ'>";
	  print "������ͧ <input type=radio name=std_type value='����' checked> ���� </font>";
	  }
	  print " </td></tr> <tr>";
      print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����-���ʡ��";
      print "<font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
      print "<input size=30 name=std_fullname value='$std_fullname'>";
      print "</font></td>";
      print "</tr>";
      print "<tr>";
      print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�� ";
      print "<font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
      print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
	  if($std_type1=="���"){
		print "<input type=radio name=std_type1 value='���' checked>";
		print "���";
		print "<input type=radio name=std_type1 value='˭ԧ'>";
		print "˭ԧ </font>";
	  }
	  else{
		print "<input type=radio name=std_type1 value='���'>";
		print "���";
		print "<input type=radio name=std_type1 value='˭ԧ' checked>";
		print "˭ԧ </font>";
	  }
      print "</td></tr>";
      print "<tr>";
      print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>������� ";
      print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
      print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
      print "<input size=30 name=std_nick value='$std_nick'>";
      print "</font></td>";
      print "</tr>";
     print "<tr>";
     print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ѹ�Դ ";
     print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
     print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ѹ ";
     print "<select name=days>";

	if($std_days=="�ѹ���"){
		 print "<option value='�ѹ��� 'selected>�ѹ��� ";
	}
	else{
		 print "<option value='�ѹ���'>�ѹ��� ";
	}

	if($std_days=="�ѧ���"){
	     print "<option value='�ѧ���' selected>�ѧ��� ";
	}
	else{
	     print "<option value='�ѧ���'>�ѧ��� ";
	}

	if($std_days=="�ظ"){
     print "<option value='�ظ' selected>�ظ ";
	}
	else{
     print "<option value='�ظ'>�ظ ";
	}
	
	if($std_days=="����ʺ��"){
     print "<option value='����ʺ��' selected>����ʺ�� ";
	}
	else{
     print "<option value='����ʺ��'>����ʺ�� ";
	}
	
	if($std_days=="�ء��"){
     print "<option value='�ء��' selected>�ء�� ";
	}
	else{
     print "<option value='�ء��'>�ء�� ";
	}
	
	if($std_days=="�����"){
     print "<option value='�����' selected>�����";
	}
	else{
     print "<option value='�����'>����� ";
	}
	
	if($std_days=="�ҷԵ��"){
	     print "<option value='�ҷԵ��' selected>�ҷԵ��";
	}
	else{
		 print "<option value='�ҷԵ��'>�ҷԵ�� ";
	}
     print "</select>";
     print "��� ";
     print "<select name=day>";
	 if($std_day=="1"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>1 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>1 ";
     print "</font>";
}
	 if($std_day=="2"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>2 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>2 ";
     print "</font>";
}
	 if($std_day=="3"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>3 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>3 ";
     print "</font>";
}
	 if($std_day=="4"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>4 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>4 ";
     print "</font>";
}
	 if($std_day=="5"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>5 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>5 ";
     print "</font>";
}
	 if($std_day=="6"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>6 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>6 ";
     print "</font>";
}
	 if($std_day=="7"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>7 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>7 ";
     print "</font>";
}
	 if($std_day=="8"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>8 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>8 ";
     print "</font>";
}
	 if($std_day=="9"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>9 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>9 ";
     print "</font>";
}
	 if($std_day=="10"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>10 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>10 ";
     print "</font>";
}
	 if($std_day=="11"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>11 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>11 ";
     print "</font>";
}
	 if($std_day=="12"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>12 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>12 ";
     print "</font>";
}
	 if($std_day=="13"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>13 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>13";
     print "</font>";
}
	 if($std_day=="14"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>14 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>14 ";
     print "</font>";
}
	 if($std_day=="15"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>15 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>15 ";
     print "</font>";
}
	 if($std_day=="16"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>16 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>16 ";
     print "</font>";
}
	 if($std_day=="17"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>17 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>17 ";
     print "</font>";
}
	 if($std_day=="18"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>18 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>18 ";
     print "</font>";
}
	 if($std_day=="19"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>19 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>19 ";
     print "</font>";
}
	 if($std_day=="20"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>20 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>20 ";
     print "</font>";
}
	 if($std_day=="21"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>21 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>21 ";
     print "</font>";
}
	 if($std_day=="22"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>22 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>22 ";
     print "</font>";
}
	 if($std_day=="23"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>23 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>23 ";
     print "</font>";
}
	 if($std_day=="24"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>24 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>24 ";
     print "</font>";
}
	 if($std_day=="25"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>25 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>25 ";
     print "</font>";
}
	 if($std_day=="26"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>26 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>26 ";
     print "</font>";
}
	 if($std_day=="27"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>27 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>27";
     print "</font>";
}
	 if($std_day=="28"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>28";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>28";
     print "</font>";
}
	 if($std_day=="29"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>29 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>29";
     print "</font>";
}
	 if($std_day=="30"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>30";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>30";
     print "</font>";
}
	 if($std_day=="31"){
     print "<option selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>31 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>31 ";
     print "</font>";
}
    print "</select>";
    print "<select name=mount>";
if($std_mount=="���Ҥ�"){
	print "<option value=���Ҥ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���Ҥ� </font>";
}
else{
	print "<option value=���Ҥ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���Ҥ� </font>";
}
if($std_mount=="����Ҿѹ��"){
    print "<option value=����Ҿѹ�� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����Ҿѹ�� </font>";
}
else{
    print "<option value=����Ҿѹ��><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����Ҿѹ�� </font>";
}
if($std_mount=="�չҤ�"){
    print "<option value=�չҤ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�չҤ� </font>";
}
else{
    print "<option value=�չҤ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�չҤ� </font>";
}
if($std_mount=="����¹"){
	print "<option value=����¹ selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����¹</font>";
}
else{
	print "<option value=����¹><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����¹</font>";
}
if($std_mount=="����Ҥ�"){
print "<option value=����Ҥ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����Ҥ� </font>";
}
else{
print "<option value=����Ҥ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����Ҥ� </font>";
}
if($std_mount=="�Զع�¹"){
print "<option value=�Զع�¹ selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�Զع�¹ </font>";
}
else{
print "<option value=�Զع�¹><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�Զع�¹ </font>";
}
if($std_mount=="�á�Ҥ�"){
print "<option value=�á�Ҥ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�á�Ҥ�</font>";
}
else{
print "<option value=�á�Ҥ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�á�Ҥ�</font>";
}
if($std_mount=="�ԧ�Ҥ�"){
print "<option value=�ԧ�Ҥ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ԧ�Ҥ� </font>";
}
else{
print "<option value=�ԧ�Ҥ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ԧ�Ҥ� </font>";
}
if($std_mount=="�ѹ��¹"){
print "<option value=�ѹ��¹ selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ѹ��¹ </font>";
}
else{
print "<option value=�ѹ��¹><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ѹ��¹ </font>";
}
if($std_mount=="���Ҥ�"){
print "<option value=���Ҥ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���Ҥ� </font>";
}
else{
print "<option value=���Ҥ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���Ҥ� </font>";
}
if($std_mount=="��Ȩԡ�¹"){
print "<option value=��Ȩԡ�¹ selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>��Ȩԡ�¹ </font>";
}
else{
print "<option value=��Ȩԡ�¹><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>��Ȩԡ�¹ </font>";
}
if($std_mount=="�ѹ�Ҥ�"){
print "<option value=�ѹ�Ҥ� selected><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ѹ�Ҥ� </font>";
}
else{
print "<option value=�ѹ�Ҥ�><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>�ѹ�Ҥ� </font>";
}
print "</select>";
 print "�.�. ";
 print "<input size=10 name=year value=$std_year></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>����ѷ(���ӧҹ) ";
 print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
 print "<textarea name=std_work rows=3 cols=40>$std_work</textarea>";
 print "</font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���˹� ";
 print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
 print "<input size=30 name=std_position value='$std_position'></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>������� ";
  print "(��������)</font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<textarea name=std_address_born rows=3 cols=40>$std_address_born</textarea>";
  print "</font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>������� ";
  print "(�Ѩ�غѹ)</font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<textarea name=std_address_now rows=3 cols=40>$std_address_now</textarea>";
  print "</font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���Ѿ�� ";
  print "(��ҹ�ѡ)</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<input size=30 name=std_tel_home value='$std_tel_home'></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���Ѿ�� ";
  print "(���ӧҹ) </font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
 print "<input size=30 name=std_tel_work value='$std_tel_work'></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>��Ͷ��,ྨ���� ";
 print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
 print "<input size=30 name=std_pager value='$std_pager'></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Icq</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<input size=30 name=std_icq value=$std_icq></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Email ";
  print "<font color=#FF0000>*</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
  print "<input size=30 name=std_email value='$std_email'>";
  print "<font color=#990000><br>��س���������� �������ö�Դ��������͡óշ���ҹ��� ";
  print "password</font></font> </td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>���ྨ </font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
  print "<input name=std_homepage value='$std_homepage' size=50></font></td>";
  print "</tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Login ";
  print "<font color=#FF0000>*</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<input size=30 name=std_username value='$std_username'></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Password<font color=#FF0000> *</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
  print "<input size=30 name=std_password1 type=password value='$std_password1'>";
  print "<font color=#990000>��Ҵ����ա���դ����Ӥѭ�������ö����ѭ�ѡɳ�������</font></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Password ";
  print "agian<font color=#FF0000> *</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<input size=30 name=std_password2 type=password value='$std_password2'>";
  print "</font><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
  print "<font color=#990000> ��Ǩ�ͺ������촴�������������������ѧ�������</font></font> ";
  print "</td></tr>";
  print "<tr><td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Question ";
  print "<font color=#FF0000> *</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<input size=30 name=std_question value='$std_question'>";
  print "</font>";
  print "</td></tr>";
  print "<tr><td width=24%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>Answer ";
  print "<font color=#FF0000> *</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3>";
  print "<input size=30 name=std_answer value='$std_answer'>";
  print "</font>";
  print "<font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
  print "<font color=#990000>��سҨӤӵͺ���ͷ�ҹ��� password</font></font> ";
  print "</td></tr>";
  print "</table></td></tr><tr><td>";
  print "<div align=center><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3> ";
  print "<input type=submit value=Submit name=submit>";
  print "<input type=reset value=Reset name=reset>";
  print "</font></div></td></tr></table>";
   print"</center></form>";
 }
		}
		else{
?>
</font> 
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
		  <META http-equiv=refresh content="3; URL=login.php">
<font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
<?php
	 }	
}
}
?>
</font>