<HTML>
<HEAD>
<TITLE>create database project</TITLE>
</HEAD>
<BODY>
<?
  $handle=mysql_connect("localhost","root","one410")or die("error1");
//create db "project"
  $dbname="gwebboard";
  mysql_create_db($dbname,$handle)or die("error2");

//���ҧ���ҧ admin
$sql="CREATE TABLE admin (email varchar(30) NOT NULL,nameboard varchar(13) NOT NULL,date1 varchar(10) NOT NULL,time1 varchar(11),date2 varchar(10) NOT NULL,time2 varchar(11) NOT NULL,num int(3) NOT NULL,name varchar(40) NOT NULL,comment varchar(50) NOT NULL,PRIMARY KEY (email, nameboard),KEY email (email),KEY nameboard (nameboard))";
$dbquery=mysql_db_query($dbname,$sql) or die("error3");

//���ҧ���ҧ user
$sql="CREATE TABLE user (email varchar(30) NOT NULL,pass varchar(6) NOT NULL,date varchar(10) NOT NULL,time varchar(11) NOT NULL,own varchar(5) NOT NULL,name varchar(40) NOT NULL,request varchar(13) NOT NULL,PRIMARY KEY (email, own, request))";
$dbquery=mysql_db_query($dbname,$sql) or die("error4");

//���ҧ���ҧ userboard
$sql="CREATE TABLE userboard (email varchar(30) NOT NULL,nameboard varchar(13) NOT NULL,date varchar(10) NOT NULL,time varchar(11) NOT NULL,PRIMARY KEY (nameboard, email),KEY email (email),KEY nameboard (nameboard))";
$dbquery=mysql_db_query($dbname,$sql) or die("error5");

mysql_close($handle);
?>
<div align="center">
  <p><br>
    <br>
    <font face="tahoma" color="#0033FF"><b><font style='font-size:14px'>Complete</font></b></font></p>
  <p><font color="#0033FF" face="tahoma" style='font-size:12px'>Database 'PROJECT' �١���ҧ���º��������</font></p>
  <hr width="400">
  <br>
</div>
</BODY>
</HTML>