<html>
<head>
<title>��������������Ԫ���ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778"  border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
<?
include ("connect_course.inc.php");
	echo "
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='17' bgcolor='#DAEEFE' >&nbsp;</td>
   <td width='134' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='../../../introduce_insert.php'>��ѡ�ٵû�ԭ���</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='../../../structure_insert_course.php'>�ç���ҧ��ѡ�ٵ�</a><br>
	     <a href='../../../select_course_type.php'>�����ç���ҧ����</a><br>
	  <a href='../../../insert_category.php'>������Ǵ�Ԫ�����</a><br>
      <a href='../../../select_course_group.php'>�����Ң��Ԫ����� </a><br>
		��������Ԫ����� <br>
      <a href='../Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a></font> <font size='2' face='Tahoma'><br>
      <a href='../../../index.php'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;
      </td>
	<td width='619' valign='top' > 
	       <div align='center'>";
$ca = strlen($category);
$gs = strlen($gsubject);

if(($ca != 0))
{
		
$co = strlen($code);
$cst = strlen($code_subject_to);
$na = strlen($name);
$un = strlen($unit);
$un_de = strlen($unit_detail);
$un_op = strlen($unit_operation);
if(($co != 0)&&($na != 0)&&($un != 0)&&($un_de != 0)&&($un_op != 0))
{
	$code = htmlspecialchars($code);
	$name = htmlspecialchars($name);
	$ename = htmlspecialchars($ename);
	$unit = htmlspecialchars($unit);
	$unit_detail = htmlspecialchars($unit_detail);
	$unit_operation = htmlspecialchars($unit_operation);
	$url = htmlspecialchars($url);
	$subject_detail = htmlspecialchars($subject_detail);
	$subject_detail = eregi_replace(chr(13),"<br>",$subject_detail);
		// check subject_to repeating
	
	$query = MYSQL_DB_QUERY($dbName,"Select * From $Subjecttable Where Code='$code_subject_to' AND Course_year ='$course_year'  "); 
	$number = MYSQL_NUMROWS($query); 
	if (($number >0)||($cst==0))
	{ 
		if ($cst ==0)
		{
			$name_subject_to = '';
			$ename_subject_to = '';
		}
			    // check code subject repeating
		$query_subject = "Select * From $Subjecttable Where Course_year  =  '$course_year' AND Code  =  '$code' AND Code != '$code_old' AND Category ='$category' ";
	$result_subject = mysql_query($query_subject);
	$number_subject = mysql_numrows($result_subject);
	$i_subject = 0;
	if ($i_subject < $number_subject)
		{
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>�բ���������ԪҢͧ�����Ԫҷ���к������͹����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}
		else
		{
		/*	if ($gs == 0) 			// insert gsubject = "�����"
		{
				$gsubject = "�����";
				$sql = "INSERT INTO $Gsubjecttable(Course_year,Category,Gsubject,Gprogram1_unit,Gprogram2_unit,Gdetail) VALUES ('$course_year','$category','$gsubject','$gprogram1_unit','$gprogram2_unit','$gdetail')";
				$result = mysql_db_query($dbName,$sql);
		}*/
	$sql_subject = "INSERT INTO $Subjecttable(Course_year,Category,Gsubject,Code,Name,Ename,Unit,Unit_detail,Unit_operation,Url,Code_subject_to,Name_subject_to,Ename_subject_to,Subject_detail) VALUES ('$course_year','$category','$gsubject','$code','$name','$ename','$unit','$unit_detail','$unit_operation','$url','$code_subject_to','$name_subject_to','$ename_subject_to','$subject_detail')";
	$result_2 = mysql_db_query($dbName,$sql_subject);

	echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>��������ѡ�ٵ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'insert_subject.php?course_year=$course_year' target ='_parent'>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
			}
	}
	else
		{
		echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>����բ���������ԪҢͧ�����Ԫҷ���к����ԪҺѧ�Ѻ��͹</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}//end else of check subject_to repeating
	
}
else
{
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			 MYSQL_CLOSE();
	 }
}
else
{
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
			<div align='center'><font size='2'><font size='2'><font face='Tahoma'>��س����͡��Ǵ�Ԫ�����Ң��Ԫҷ���ͧ�����������������Ԫ����¹��͹</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			</tr></table>";
		$query_delete_temp = "Delete From $Temptable ";
		$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);
			MYSQL_CLOSE();
}
?>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
