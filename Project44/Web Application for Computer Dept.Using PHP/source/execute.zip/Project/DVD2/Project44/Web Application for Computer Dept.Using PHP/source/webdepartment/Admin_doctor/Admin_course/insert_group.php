<html>
<head>
<title>�����������Ң��Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<form name="a" action="structure_insert_group.php"  method="post" target ='_parent'>
<script language="javascript" >
function Brand(tSystem,tBrand,nn)
{
     this.System=tSystem;
     this.Brand=tBrand;
	 this.apid=nn;
}
function Model(tId,tModel,tSystem,tBrand){
     this.ID=tId;
     this.Model=tModel;
     this.System=tSystem;
     this.Brand=tBrand;
}
function getBrands()
{
  var sSelect="<select name='category' class='input200'><option value='' selected></option>";
  var obj0=document.a.msubject;
  var iSystem=obj0.options[obj0.selectedIndex].value;
   for (var x=1;x<aBrands.length;x++)
    {
           if (aBrands[x].System==iSystem)
           {
                 sSelect=sSelect+"<option value='"+aBrands[x].apid+"'>"+aBrands[x].Brand+"</option>";
           }
     }
    sSelect=sSelect+"</select>";
    document.all.Brands.innerHTML=sSelect;
	
}
var aBrands=new Array();
	<?
include ("connect_course.inc.php");
	$query_msubject = "Select * From $Msubjecttable Where Course_year = '$course_year' ";
		$result_msubject = mysql_query($query_msubject); 
        $number_msubject = mysql_numrows($result_msubject);
		$i_msubject = 0; 
		$c = 1;						
		$g = 1;
		//$c = 2;						
		//$g = 2;
		//$temp[1] = "�����";
		//print "aBrands[1] = new  Brand('�����','�����','�����');";
		if ($i_msubject < $number_msubject)
		{
			while ($row  = mysql_fetch_array($result_msubject)) 
			{
			$cate = htmlspecialchars($row[Msubject]); 
			$temp[$c] = $cate;
			$c++;
					$query_category = "Select  Distinct Category From $Categorytable Where Course_year = '$course_year' AND Msubject = '$cate' ";
					$result_category = mysql_query($query_category); 
					$number_category = mysql_numrows($result_category);
					$i_category=0; 
					if ($i_category < $number_category)
					{
						while ($row  = mysql_fetch_array($result_category)) 
						{
						$gsub = htmlspecialchars($row[Category]); 
						print "aBrands[".$g."] = new  Brand('".$cate."','".$gsub."','".$gsub."'".');';
						$g++;
						}
					}
			}  
        }

?>	
function fsubmit(){
if ((a.msubject.value!="")&&(a.category.value!="")&&(a.name.value!="")&&(a.add.value!="")&&(a.reg.value!="")&&(a.email.value!="")){
a.submit()
}else{
alert("��سҡ�͡���������ú")
}
}
</script>

<script type="text/javascript" language="JavaScript">init()</script>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" align ='center'>
<?
include ("connect_course.inc.php");
 echo "
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_insert.php'>��ѡ�ٵû�ԭ���͡</a></font> 
      <font face='Tahoma' size='2' color='#9900CC'><br>
    <a href='structure_insert_course.php'>�ç���ҧ��ѡ�ٵ�</a><br>
	   <a href='structure_insert_main_subject.php'>�����Ԫ���ѡ����</a><br>
	   <a href='select_course_category.php'>������Ǵ�Ԫ�����</a><br>
		�����Ң��Ԫ�����<br>
	  <a href='Doctor/Insert/Subject/select_course.php' >��������Ԫ����� </a><br>
      <a href='Doctor/Insert/Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a><br>
      <a href='index.php'>��Ѻ˹����ѡ </a>
    <br>&nbsp;
    </font></td>
    <td width='619' valign='top' > ";
echo "
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr> 
            <td height='21' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year<br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ </font><font size='2' face='Tahoma'><br>
                &nbsp;</font></div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td height='25' colspan='4'><font size='2' face='Tahoma'><b>14.3 ����Ԫ����ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td height='198' rowspan='7' bgcolor='#F7F7F7' width='12'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
              <font size='2' face='Tahoma'></font></td>
            <td height='22' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'>�����Ԫ���ѡ&nbsp;</font></div>
            </td>
            <td height='97' rowspan='4' bgcolor='#F7F7F7' width='372'> 
              <div align='center'></div>
              <div align='center'><font size='2' face='Tahoma'></font></div>
              <div align='center'><font size='2' face='Tahoma'> </font></div>
            </td>
          </tr>
          <tr> 
            <td height='25' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2' face='Tahoma'></font> <font size='2' face='Tahoma'> 
               <select name='msubject' onChange='getBrands();' class='input200' >
                  <option selected value=''></option>";
				for ($n=1;$n<$c;$n++)
				{
            echo "
                  <option  value='$temp[$n]' ><span id='c_country' name='c_country'>$temp[$n]</span></option>";
				}
			echo"
                  </select>
                </font></div>
            </td>
          </tr>
          <tr> 
            <td height='25' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'>������Ǵ�Ԫ�</font></div>
            </td>
          </tr>
          <tr> 
            <td height='25' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2' face='Tahoma'><b> </b></font> 
                <span id='Brands' name='Brands'> 
                <select name='category' class='input200'>
                  <option value='' selected></option>
                </select>
                </span>
              </div>
            </td>
          </tr>
          <tr> 
            <td height='25' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2' face='Tahoma'> �����Ң��Ԫ� </font></div>
            </td>
            <td height='25' bgcolor='#EAEAFF' width='372'> 
              <div align='center'></div>
              <div align='center'></div>
              <div align='center'></div>
              <div align='center'><font size='2' face='Tahoma'>�ӹǹ˹��¡Ե</font></div>
            </td>
          </tr>
          <tr> 
            <td height='25' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2' face='Tahoma'> </font></div>
              <div align='center'><font size='2' face='Tahoma'> 
                <input type='text' name='gsubject' size='30'>
                </font></div>
            </td>
            <td height='25' bgcolor='#EAEAFF' width='372'> 
              <div align='center'><font face='Tahoma' size='2'> 
                <input type='text' name='gprogram_unit' size='3' maxlength='3'>
                ˹��¡Ե</font></div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td height='51'> 
              <div align='center'><font face='Tahoma' size='2'>��͸Ժ��</font></div>
            </td>
            <td height='51' bgcolor='#EAEAFF' colspan='2' width='372'> 
              <div align='center'> 
                <textarea name='gdetail' cols='55' rows='2'></textarea>
              </div>
            </td>
          </tr>
          <tr> 
            <td height='42' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'> 
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
              </div>
            </td>
          </tr>
        </table>
	<input type=hidden name='course_year' value='$course_year'>	

    </td>
  </tr>  
	</table>	";
?>
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut"s Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
	     </form>
</body>
</html>
