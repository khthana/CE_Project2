<? 
    session_start();
if($id[0])
{
?>
<html>
<head>
<title>Del user</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<?
include("connect.inc.php");
include("update.inc.php");
$dbname=gwebboard();
?>
<body bgcolor="#FFFFFF">
<table width="640" cellspacing=0 border=1 align=left>
<tr>
<td bordercolor=#3300FF border=1>
<FORM METHOD=POST ACTION="deluser.php" target=body >
<table width="640" cellspacing=0 border=0 align=center>
        <tr bgcolor=#391E8C class=a > 
          <td height=15 align=center colspan=3 ><font class=h>ź��Ҫԡ Group</font></td>
        </tr>
        <tr bgcolor=#F0F0FF > 
          <td height=20 align=center width="12%" valign=middle class=a bgcolor="#F0F0FF"><font color="#0000FF"><b>���͡</b></font></td>
          <td height=20 align=center width="68%" valign=middle class=a><font color="#0000FF"><b>��ª�����Ҫԡ</b></font></td>
          <td height=20 align=center width="20%" valign=middle class=a><font color="#0000FF"><b>�ѹ�������Ҫԡ</b></font></td>
        </tr>  
<?
//ź���������ö�� group 			
			$c=0;
			  while($c<$row)
               {
			     if($check[$c]!="")
				  {                
				  //ź���������ö�� group ��� table ��� userboard
				    $sql="delete from userboard where email ='$check[$c]' and nameboard='$nameboards'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error1");
   				  }
			    $c++;
			   }
          //�Ҩӹǹ record �ͧ���ҧuserboard����ա�� record 
		    $sql="select * from userboard where nameboard='$nameboards' ";
		    $dbquery=mysql_db_query($dbname,$sql)or die("error5");
		    $num_rows=mysql_num_rows($dbquery);
			$c=0;
			while($c<$num_rows)
               { 
				 $result=mysql_fetch_array($dbquery);
				 print("<tr bgcolor='#EEFAFF' ><td align=center width='12%' ><input type=checkbox value=$result[email]  name='check[$c]' </td>");
                 print("<td width='68%' ><div align='center'><font class=info>$result[email]</font></div></td>");
                 print("<td width='20%' ><div align='center'><font class=info>$result[date]</font></div></td></tr>");
   				 $c++;  			   
			   }
			//print("<input type=hidden value='$email' name='email'>");
			print("<input type=hidden value='$nameboards' name='nameboards'>");
			print("<input type=hidden value='$num_rows' name='row'>");
			
?>
 <tr  valign="middle" align=center > 
    <td colspan="3" class=a> 
        <br>
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>&nbsp;&nbsp;
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancel>
    </td>
  </tr>
</table>
</form>
<?
//�Դ�ҹ������
     closedb();
?>
 </td>
  </tr>
</table>
</body>
</html>
<?
}
?>