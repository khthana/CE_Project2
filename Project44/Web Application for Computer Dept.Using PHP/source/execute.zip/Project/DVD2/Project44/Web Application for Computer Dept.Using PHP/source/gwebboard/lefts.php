<?session_start();
?>
<html>
<head>
<title>left</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor=#ffffff>
<table width='20%' border="0" cellspacing="0" cellpadding="0" align=left height="100%">
  <tr class=a> 
    <td valign="top" align="left" bgcolor="#391E8C" height="351"> 
      <table width="100" border="0" height="63" align="center" cellpadding="0" cellspacing="0">
        <tr class=A> 
          <td height="21" colspan="2"> 
            <div align="center" valign=top><font size="2"><b><img src="images/lhead0.gif" width="125" height="18"></b></font></div>
          </td>
        </tr>
        <tr class=A> 
          <td height="25" width="9%" valign="middle"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td height="25" width="91%" valign="middle">&nbsp;<a href="showuserall.php" class=a target=_parent>�ʴ���Ҫԡ������</a></td>
        </tr>
      <tr class=A> 
          <td height="19" width="9%" valign="middle"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td height="19" width="91%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>Home</a></td>
        </tr>
	  </table>
      <div align="center"><br>
      </div>
    </td>
  </tr>
</table>
</body>
</html>