<html>
<head>
<title>Post to Question</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<?php
	include("webboard.inc");
	include("censor.php");
	include("thai.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
		print "<body bgcolor=#FFFFFF>";
		$a2 = date("j")*1440;
		$b2 = strftime("%m")*44640;	
		$c2 = (strftime("%Y")+543)*535680;
		$d2 = date("H")*60;	 // ���Ҫ������
		$f2 = date("i");	 // ���ҹҷ�
		$q_update = $a2+$b2+$c2+$d2+$f2;

		if (getenv(HTTP_X_FORWARDED_FOR)){ 
			$ip=getenv(HTTP_X_FORWARDED_FOR); 
		} else { 
			$ip=getenv(REMOTE_ADDR); 
		} 
		$ip = $ip." -->".gethostbyaddr($ip).""; 
//		$ip = "$ip[$ip1]";

//		$q_ip =getenv(REMOTE_ADDR); 
		$q_ip = $ip; 

		$message =trim($q_message);
		$topic = trim($q_topic);
		$name = trim($q_name);
		$name = eregi_replace(" ","",$name);
		$message = eregi_replace(" ","",$message);
		$topic = eregi_replace(" ","",$topic);

		if(($q_message=="") or ($q_name=="") or ($q_topic=="") or ($topic=="") or ($name=="") or ($message=="")){
			print"��سҡ�͡��ͤ������١��ͧ";
			print "<META http-equiv=refresh content=\"0; URL=index.php\">";
			exit;
		}else{
		}

		$q_message = htmlspecialchars($q_message);
		$q_name = htmlspecialchars($q_name);
		$q_topic = htmlspecialchars($q_topic);
		$q_email = htmlspecialchars($q_email);
		$q_icq = htmlspecialchars($q_icq);

		$q_message = nl2br($q_message);

		$q_message = censor($q_message);
		$q_name = censor($q_name);
		$q_email = censor($q_email);
		$q_topic = censor($q_topic);
		$q_icq = censor($q_icq);

	$txt = array(":smile:", ":sad:",":red:", ":big:", ":ent:", ":shy:", ":sleepy:", ":sun:", ":sg:", ":embarass:", ":dead:", ":cool:", ":clown:", ":pukey:", ":eek:", ":roll:", ":smoke:", ":angry:", ":confused:", ":cry:", ":lol:", ":yawn:", ":devil:", ":tongue:", ":alien:", ":tasty:", ":crazy:");
	$pic = array("smile.gif","frown.gif","redface.gif","biggrin.gif","blue.gif","shy.gif","sleepy.gif","sunglasses.gif","supergrin.gif","embarass.gif","dead.gif","cool.gif","clown.gif","pukey.gif","eek.gif","sarcblink.gif","smokin.gif","reallymad.gif","confused.gif","crying.gif","lol.gif","yawn.gif","devil.gif","tongue.gif","aysmile.gif","tasty.gif","grazy.gif");
	for ($a=0 ; $a<sizeof($txt) ; $a++) {
		$q_message= eregi_replace($txt[$a],"<img src=\"pics/$pic[$a]\">",$q_message);
	}

	// ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
	$q_message = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])","<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>",$q_message);
	$q_message = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>",$q_message); 
	$q_message = preg_replace('#\[b](.+?)\[/b]#is', '<b>\\1</b>', $q_message);
	$q_message = preg_replace('#\[i](.+?)\[/i]#is', '<i>\\1</i>', $q_message);
	$q_message = preg_replace('#\[u](.+?)\[/u]#is', '<u>\\1</u>', $q_message);

		setlocale("LC_TIME","th");	
		$a = date("j");	 // �ѹ���
		$e = date("m")-1;	//�������͹����ѡ�Ժ
		$b = $ThaiShortMonth[$e];
		$c = strftime("%Y")+543;	 // �� �.�.
		$d = date("H:i");	 // ����
		$q_date = "$a $b $c";
		$q_date1= "$a $b $c:$d";
		
		$q_reng = "0";

		$sql3 = "select * from question where q_name = '$q_name' and q_topic='$q_topic' and q_message='$q_message'";
		$db_query3 = mysql_db_query ($dbname, $sql3);
		$q_r3 = mysql_num_rows($db_query3);
		$q_updatemail="update";
		if($q_r3=="0"){
			if($q_email==""){
					$sql = "insert into question (q_id, q_post, q_topic, q_message, q_name, q_email, q_icq, q_ip, q_datetime, q_time, q_update, q_reng) values  ('0','$q_update','$q_topic','$q_message','$q_name','$q_email','$q_icq','$q_ip','$q_date','$d', '$q_update','$q_reng')";
					$result = mysql_db_query($dbname, $sql) or die("�Դ��Ͱҹ����������� 80");
					print "<META http-equiv=refresh content=\"0; URL=index.php\">";
				}
				else{
					if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])",$q_email)){
						$sql = "insert into question (q_id, q_post, q_topic, q_message, q_name, q_email, q_icq, q_ip, q_datetime, q_time, q_update, q_reng, q_updatemail) values  ('0','$q_update','$q_topic','$q_message','$q_name','$q_email','$q_icq','$q_ip','$q_date','$d', '$q_update','$q_reng', '$q_updatemail')";
						$result = mysql_db_query($dbname, $sql) or die("�Դ��Ͱҹ�����������86");
						print "<META http-equiv=refresh content=\"0; URL=index.php\">";
					}
					else{
						echo "<br><center><font  size=4> ��سҡ�͡ Email �ͧ��ҹ����</font><br><br>";
						print "<META http-equiv=refresh content=\"0; URL=form_qusetion.php\">";
					}
				}
		}
		else{
			print "<META http-equiv=refresh content=\"0; URL=index.php\">";
}

?>
</body>
</html>