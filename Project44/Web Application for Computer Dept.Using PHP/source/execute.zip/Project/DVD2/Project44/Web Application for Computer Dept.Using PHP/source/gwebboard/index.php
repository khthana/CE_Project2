<?session_start();
    session_unset();
   session_destroy();
if($id[0]=='')
  {
?>
<html>
<head>
<title>Group Webboard</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<frameset rows="105,*" cols="*" frameborder="NO" border="0" framespacing="0"> 
  <frame name="top" scrolling="NO" noresize src="top.php" >
  <frameset cols="135,*" frameborder="NO" border="0" framespacing="0"> 
    <frame name="left" noresize scrolling="NO" src="left.php">
    <frame name="body" noresize scrolling="yes" src="body.php">
  </frameset>
</frameset>
</html>
<?
  }
?>