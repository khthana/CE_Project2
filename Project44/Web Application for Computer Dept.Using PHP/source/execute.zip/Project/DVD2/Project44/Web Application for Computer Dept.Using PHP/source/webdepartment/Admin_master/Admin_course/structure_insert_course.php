<html>
<head>
<title>�����ç���ҧ��ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
	<tr> 
    <td width='11'  >&nbsp;</td>
    <td width='14' bgcolor='#DAEEFE'  >&nbsp;</td>
    <td width='134' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_insert.php'>��ѡ�ٵû�ԭ���</a><br>
      �ç���ҧ��ѡ�ٵ�<br>
      <a href="select_course_type.php">�����ç���ҧ����</a><br>
      <a href='insert_category.php'>������Ǵ�Ԫ�����</a><br>
      <a href='select_course_group.php'>�����Ң��Ԫ����� </a><br>
      <a href='Master/Insert/Subject/select_course.php' >��������Ԫ����� </a><br>
      <a href='Master/Insert/Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a><br>
      <a href='index.php'>��Ѻ˹����ѡ </a> <br>
      </font></td>
    <td width='619' valign='top' > 
<?
include ("connect_course.inc.php");
echo"
	<form name='form1' method='post' action='insert_course.php'>
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF' >
          <tr bgcolor='#F7F7F7'> 
            <td height='123' colspan='5'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font size='2' face='Tahoma'></font><font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵ���Һѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ� 
                <select name='course_year' size='1'>";
		$query = "Select Course_year From $Introducetable ";
		$result = mysql_query($query); 
        $number = mysql_numrows($result);
		$i =0 ; 
		if ($i < $number)
		{
			while ($row  = mysql_fetch_array($result)) 
			{
			$course_year = htmlspecialchars($row[Course_year]); 
			echo "
                  <option value='$course_year'><font size='2' face='Tahoma'>$course_year</font></option>";
			}  
		}
			echo "
                  
                </select>
                <br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ <br>
                &nbsp; </font></div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td height='30' colspan='5'><font size='2' face='Tahoma'><b>14. ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr bgcolor='#DAEEFE'> 
            <td height='30' colspan='4' bgcolor='#F7F7F7'><font size='2'><font size='2'><font face='Tahoma'><b>14.1 
              �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font></font></font></td>
            <td height='30' width='15' bgcolor='#F7F7F7' rowspan='2'>&nbsp;</td>
          </tr>
          <tr bgcolor='#DAEEFE'> 
            <td height='20' width='13' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='20' colspan='3'><font size='2' face='Tahoma'>�ӹǹ˹��¡Ե��ʹ��ѡ�ٵ÷����������¡��� 
              <input type='text' name='unit_sum_all' size='3' maxlength='3' >
              ˹��¡Ե </font></td>
          </tr>
          <tr> 
            <td height='30' colspan='5' bgcolor='#F7F7F7'> 
              <div align='left'><font size='2'><font size='2'><font face='Tahoma'><b>14.2 
                �ç���ҧ��ѡ�ٵ� </b></font></font></font></div>
            </td>
          </tr>
          <tr> 
            <td height='11' width='13' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='30' colspan='3' bgcolor='#DAEEFE'> 
              <div align='left'><font size='2' face='Tahoma'><b>&nbsp;- Ἱ �1 
                (Research 1)</b></font><b><font size='2' face='Tahoma' color='#0000FF'> 
                </font></b><font size='2' face='Tahoma'>��Ἱ����֡�ҷ���鹡���Ԩ�����ա�÷��Է�ҹԾ�������ѡ</font></div>
            </td>
            <td height='11' width='15' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='2' width='13' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='2' width='286' bgcolor='#DAEEFE'><font size='2' face='Tahoma'>&nbsp;�ӹǹ˹��¡Ե��ʹ��ѡ�ٵ�</font></td>
            <td height='2' width='172' bgcolor='#DAEEFE'>&nbsp; 
              <input type='text' name='program1_unit' size='3' maxlength='3' >
              <font size='2' face='Tahoma'> ˹��¡Ե </font></td>
            <td height='2' width='102' bgcolor='#DAEEFE'> 
              <div align='center'></div>
            </td>
            <td height='2' width='15' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='15' width='13' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
            <td height='30' colspan='3' bgcolor='#DAEEFE'> 
              <div align='left'><font size='2' face='Tahoma'><b>&nbsp;- Ἱ �2 
                (Research 2)</b></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'> 
                ��Ἱ����֡�ҷ���鹡���Ԩ�����ա�÷��Է�ҹԾ�����С���֡������Ԫ�</font></div>
            </td>
            <td height='15' width='15' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='8' width='13' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='2' width='286' bgcolor='#DAEEFE'><font size='2' face='Tahoma'>&nbsp;�ӹǹ˹��¡Ե��ʹ��ѡ�ٵ�</font></td>
            <td height='0' width='172' bgcolor='#DAEEFE'>&nbsp; 
              <input type='text' name='program2_unit' size='3' maxlength='3'>
              <font size='2' face='Tahoma'> ˹��¡Ե </font></td>
            <td height='0' width='102' bgcolor='#DAEEFE'> 
              <div align='center'><font face='Tahoma' size='2'> </font></div>
            </td>
            <td height='0' width='15' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='7' colspan='4' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>��͸Ժ������˵ؼŷ��е�ͧ�֡���Ԫҵ�ҧ� 
              �մѧ��� </b></font></td>
            <td height='7' width='15' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='90' width='13' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='90' colspan='3' bgcolor='#DAEEFE'> 
              <div align='center'> 
                <textarea name='detail' cols='85' rows='4'></textarea>
              </div>
            </td>
            <td height='7' width='15' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='42' colspan='5' bgcolor='#F7F7F7'> 
              <div align='center'> </div>
              <div align='center'> 
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
              </div>
            </td>
          </tr>
        </table>
	   </form>";
	   ?>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
