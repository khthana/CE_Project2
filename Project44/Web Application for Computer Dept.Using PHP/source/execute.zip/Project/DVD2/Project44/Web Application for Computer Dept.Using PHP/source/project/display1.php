<?
session_start();
?>
<html>
<head>
<title>Display1</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<?
include("connect.inc.php");
$dbname=project();

//�֧�����Ũҡ���ҧ register,userregister ��� id
$sql="select * from register,userregister where register.id='$id1' and register.id=userregister.id";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");
$result=mysql_fetch_array($dbquery);

//$result[abst]=ereg_replace("&nbsp;"," ",$result[abst]);
//$result[abse]=ereg_replace("&nbsp;"," ",$result[abse]);
//$result[abse]=ereg_replace("<br>","~",$result[abse]);

?>
<body bgcolor="#FFFFFF">
<table width="760" border="0" cellSpacing=0 cellPadding=0>
  <tr class=a>    
    <td  align=left width="306"> 
      <div align="left"><img src="images/logo.gif" width="310" height="76"></div>
       </td>
	  
    <td width="473" height="94" class=a> 
      <div align="center">&nbsp;</div>
      </td>
    </tr>
  </table>
  <br>
  
<table width="760" border="0" height="772" cellSpacing=1 cellPadding=3>
  <tr class=a> 
    <td width="27%" class=d1head>&nbsp;�����ç�ҹ(������)</td>
    <td class=detail bgcolor="#F1F1F1" >&nbsp; 
      <?$result[namept]=wordwrap($result[namept],100,"<br>",1);
	       $result[namept]=ereg_replace(" ","&nbsp;",$result[namept]);
		   print($result[namept]);
	  ?>
    </td>
  </tr>
  <tr class=a> 
    <td width="27%" class=d1head>&nbsp;�����ç�ҹ(�����ѧ���)</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?$result[namepe]=wordwrap($result[namepe],100,"<br>",1);
	      $result[namepe]=ereg_replace(" ","&nbsp;",$result[namepe]);
		  print($result[namepe]);?>
    </td>
  </tr>
  <?
	if($result[advisor1])
	 {
	?>
  <tr> 
    <td width="27%" class=d1head>&nbsp;�Ҩ�������֡��</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?print($result[advisor1]);?>
    </td>
  </tr>
  <?
	 }
	if($result[advisor2])
	 {
	?>
  <tr> 
    <td width="27%" class=d1head>&nbsp;</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?print($result[advisor2]);?>
    </td>
  </tr>
  <?
	 }
	if($result[name1])
	 {
	?>
  <tr> 
    <td width="27%" class=d1head>&nbsp;��ª��͹ѡ�֡��</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?if(!$result[email1]) 
		     print($result[name1]);
	       else
             print("<a href='mailto:$result[email1]' class=home>$result[name1]</a>");
	  ?>
      &nbsp;&nbsp;����&nbsp;&nbsp;<?print($result[code1]);?></td>
  </tr>
  <?
	 }
	if($result[name2])
	 {
	?>
  <tr> 
    <td width="27%">&nbsp;</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?if(!$result[email2]) 
		     print($result[name2]);
	       else
             print("<a href='mailto:$result[email2]' class=home>$result[name2]</a>");
	  ?>
    &nbsp;&nbsp;����&nbsp;&nbsp;<?print($result[code2]);?>
	  </td>
  </tr>
  <?
	 }
	if($result[name3])
	 {
	?>
  <tr> 
    <td width="27%">&nbsp;</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?if(!$result[email3]) 
		     print($result[name3]);
	       else
             print("<a href='mailto:$result[email3]' class=home>$result[name3]</a>");
	  ?>
    &nbsp;&nbsp;����&nbsp;&nbsp;<?print($result[code3]);?>
	  </td>
  </tr>
  <?
	 }
	if($result[name4])
	 {
	?>
  <tr> 
    <td width="27%">&nbsp;</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?if(!$result[email4]) 
		     print($result[name4]);
	       else
             print("<a href='mailto:$result[email4]' class=home>$result[name4]</a>");
	  ?>
    &nbsp;&nbsp;����&nbsp;&nbsp;<?print($result[code4]);?>
	  </td>
  </tr>
  <?
	 }
	?>
  <tr> 
    <td width="27%" class=d1head>&nbsp;�ա���֡��</td>
    <td class=detail bgcolor="#F1F1F1">&nbsp; 
      <?print($result[year]);?>
    </td>
  </tr>
  <tr valign="bottom"> 
    <td colspan="2"> <br>
      <br>
      <hr width="700" height="5" color=#6699FF>
      <br>
      <br>
    </td>
  </tr>
  <tr> 
    <td width="27%" class=d1head>&nbsp;���Ѵ���</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2"> 
      <table width="760" border="0" align="center">
        <tr> 
          <td> 
            <table width="620" border="0" align="center">
              <tr> 
                <td class=detailpt bgcolor="#F1F1F1" width=600>
                  <?print($result[abst]);?>
                  
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td width="27%" class=d1head>&nbsp;abstract</td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="2"> 
      <table width="760" border="0" align="center">
        <tr> 
          <td> 
            <table width="620" border="0" align="center">
              <tr> 
                <td class=detailpe bgcolor="#F1F1F1" width=600>
                  <?$c=0;
				       $arr=explode("<br>",$result[abse]);
					   while($arr[$c]!='')
					   {
					   $arr[$c]=ereg_replace("&nbsp;"," ",$arr[$c]);
                       //$arr[$c]=ereg_replace("<br>","~",$arr[$c]);
				       $arr[$c]=wordwrap($arr[$c],85,"<br>",1);
				       $arr[$c]=ereg_replace(" ","&nbsp;",$arr[$c]);
					   //$arr[$c]=ereg_replace("~","<br>",$arr[$c]);
					   print($arr[$c].'<br>');
				       
					   $c++;
					   }
				  ?>
			   </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="760" border="0">
  <tr class=a>
      <td height="10" align=center> 
      <br>	<?if(($result[doc]=='document.pdf')||($result[chap1]=='chap1.pdf')||($result[chap2]=='chap2.pdf')||($result[chap3]=='chap3.pdf')||($result[chap4]=='chap4.pdf')||($result[chap5]=='chap5.pdf')||($result[chap6]=='chap6.pdf')||($result[chap7]=='chap7.pdf')||($result[chap8]=='chap8.pdf')||($result[chap9]=='chap9.pdf')||($result[chap10]=='chap10.pdf')||($result[chap11]=='chap11.pdf')||($result[chap12]=='chap12.pdf')||($result[chap13]=='chap13.pdf')||($result[chap14]=='chap14.pdf')||($result[chap15]=='chap15.pdf')||($result[chap16]=='chap16.pdf')||($result[chap17]=='chap17.pdf')||($result[chap18]=='chap18.pdf')||($result[chap19]=='chap19.pdf')||($result[chap20]=='chap20.pdf'))
	     {
	?>	
      <table width="50" border="0" height="10">
        <tr > 
          <td valign=top align=center><? if($id[1]=='')
		                                                           {?><a href='filedownload.php?id1=<?print($id1);?>' class=home>Download File</a>
		                                                           <?
		                                                           }else  
		                                                            {?><a href='download.php?id1=<?print($id1);?>' class=home>Download File</a>
		                                                           <? 
		                                                           }?>
		                                                           </td>
        </tr>
        <tr> 
          <td height="35"><br>
            <hr width="700" height="5" color=#6699FF>
            <br>
          </td>
        </tr>
      </table>
    <?}
	else
	   {
	?>
	<br>
    <hr width="700" height="5" color=#6699FF>
    <br>
	<?}
	?>
	</td>
    </tr>
  </table>

<?
//�Դ�ҹ������
closedb();
?>
</body>
</html>
