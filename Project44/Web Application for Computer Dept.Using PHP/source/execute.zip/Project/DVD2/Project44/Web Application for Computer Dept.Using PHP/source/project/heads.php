<?session_start();
?>
 <html>
<head>
<title>head</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #FF0000; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width='100%' border="0" cellspacing="0" cellpadding="0" align="left" >
  <tr> 
  <td>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" height="100%">
  <tr> 
    <td align="left" height="226" valign="top"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="75" align="center">
        <tr align="left"> 
          <td width="313"> 
            <div align="left"><img src="images/logo.gif" width="310" height="76"></div>
          </td>
          <td width="704"> 
            <div align="left"></div>
          </td>
        </tr>
      </table>
<table width="793" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8" class=A> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
         <td width="107" bgcolor="#3E3EA8" height="20"> 
            <div align="center"><a href='http://www.ce.kmitl.ac.th' target=_parent class=A>˹���á</a></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"  height="20" > 
            <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
        <td width="107" bgcolor="#3E3EA8" height="20"  class=A> 
            <div align="center"><a href='http://161.246.4.7/webdepartment/course/homepage/subject/index.php' target=_blank class=A>����Ԫ�</a></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"  height="20" > 
            <div align="center"><img src="images/l.gif" width="1" height="20"></font></div>
          </td>
          <td width="107" bgcolor="#3E3EA8" height="20"  class=A> 
            <div align="center"><a href='http://161.246.4.7/webdepartment/course/index.php' target=_blank class=A>��ѡ�ٵ�</a></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"  height="20" > 
            <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
          <td width="107" bgcolor="#3E3EA8" height="20"  class=A> 
            <div align="center"><a href='http://161.246.4.7/webdepartment/course/homepage/person/index.php' target=_blank class=A>�ؤ�ҡ�</a></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"  height="20" > 
            <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
          <td width="118" bgcolor="#3E3EA8" height="20" class=A> 
            <div align="center"><a href='http://161.246.4.7/gwebboard/index.php' target=_blank class=A>Gwebboard</a></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"  height="20"> 
            <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
          <td width="107" bgcolor="#3E3EA8" height="20" > 
            <div align="center"><a href='http://161.246.4.7/webboard/index.php' target=_blank class=A>��дҹ����</a></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"  height="20" > 
            <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
          <td width="80" bgcolor="#3E3EA8" height="20" > 
            <div align="center" valign=top>&nbsp;&nbsp;&nbsp;<a href='index.php' class=A target=_parent>Logout</a></div>
          </td>
          <td width="16"  height="20" bgcolor="#3E3EA8" > 
            <div align="center"><img src="images/l.gif" width="1" height="20"></div>
          </td>
        </tr>
        <tr> 
          <td width="10" height="20">&nbsp;</td>
          <td width="107" height="20" >&nbsp;</td>
          <td width="1" class=normal height="20">&nbsp;</td>
          <td width="107" height="20"  >&nbsp;</td>
          <td width="1" class=normal height="20" >&nbsp;</td>
          <td width="107" height="20"  >&nbsp;</td>
          <td width="1" class=normal height="20" >&nbsp;</td>
          <td width="107" height="20" >&nbsp;</td>
          <td width="1" class=normal height="20" >&nbsp;</td>
          <td width="118" height="20" >&nbsp;</td>
          <td width="1" class=normal height="20">&nbsp;</td>
          <td width="107" height="20" >&nbsp;</td>
          <td width="1" class=normal height="20" >&nbsp;</td>
          <td width="80" height="20" >&nbsp;</td>
          <td width="16" class=normal height="20" >&nbsp;</td>
        </tr>
      </table>
  </td>
  </tr>
  </table>
</body>
</html>


