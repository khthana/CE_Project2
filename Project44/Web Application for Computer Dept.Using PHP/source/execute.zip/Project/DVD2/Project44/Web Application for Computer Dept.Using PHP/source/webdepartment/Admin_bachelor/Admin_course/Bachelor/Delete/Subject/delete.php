<html>
<head>
<title>ź����������Ԫ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<?
include ("connect_course.inc.php");
$i =1;
$pass ="no";
while( $i <= $sum)
{
if($check[$i] != "")
{
$query_delete_temp = "DELETE FROM $Temptable ";
$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);

$query_delete_course = "Delete  From $Coursetable Where Code ='$check[$i]' AND Course_year = '$course_year' ";
$result_delete_course = mysql_db_query($dbName,$query_delete_course);

$query_delete_subject = "Delete  From $Subjecttable Where Code ='$check[$i]' AND Course_year = '$course_year' ";
$result_delete = mysql_db_query($dbName,$query_delete_subject);

$query ="Update $Subjecttable Set  Code_subject_to ='',Name_subject_to ='',Ename_subject_to =''  Where Code_subject_to='$check[$i]' AND Course_year = '$course_year' ";
$result= mysql_db_query($dbName,$query);

$pass="yes";
}
$i = $i +1;
}
			if($pass == "yes")
			{	
			echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>����������Ԫ���١ź�͡�ҡ�ҹ���������º��������<BR><A HREF = 'delete_subject.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
			}
			else
			{
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��س����͡����Ԫҷ���ͧ���ź�����š�͹</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			 MYSQL_CLOSE();
		     }
?>
<table width="600" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
