<?
	$hostname = "localhost";
	$username = "root";
	$password = "webmaster123";
	$Registable= "regis";
    $dbName = "register";
	MYSQL_CONNECT($hostname,$username,$password)
	OR DIE("Unable to connect to database");
	@mysql_select_db("$dbName") or die
	("Unable to select database");
?>