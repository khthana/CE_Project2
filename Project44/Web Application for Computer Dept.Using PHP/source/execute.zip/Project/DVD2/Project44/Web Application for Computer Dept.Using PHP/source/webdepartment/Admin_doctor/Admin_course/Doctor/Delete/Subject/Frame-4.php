<html>
<head>
<title>��ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<script type="text/javascript" language="JavaScript"> id = new Array();desc = new Array();credit = new Array();detail = new Array();operation = new Array()
<?
include ("connect_course.inc.php");

$query_delete_temp = "DELETE FROM $Temptable ";
$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);

$query = "Select * From $Subjecttable Where Course_year= '$course_year' ";
$result = mysql_query($query);
$number = mysql_numrows($result);
		$co = 0;
	while ($co < $number) 
		{
	$row = mysql_fetch_array($result);
	$code = htmlspecialchars($row[Code]);
	$name = htmlspecialchars($row[Name]);
	$unit = htmlspecialchars($row[Unit]);
	$udetail = htmlspecialchars($row[Unit_detail]);
	$uoperation = htmlspecialchars($row[Unit_operation]);
	print "id[".$co.']="'.$code.'"; desc['.$co.']="'.$name.'"; credit['.$co."]=$unit; detail[".$co."]=$udetail; operation[".$co."]=$uoperation;"; 
	$co++;
	}
	mysql_free_result($result);
	MYSQL_CLOSE();
	$co++;
print 'minCredit=1;' ;
print 'maxCredit=30; max = '.$co.'; pop = 0;';
print 'function isBlank(s) { var len = s.length; for (var i = 0; i < len; i++)';
print '{ if (s.charAt(i) != " ") return false; } return true; }';
print 'function checkSubject(code) { for (var i = 0; i < '.$co.'; i++) ';
?>
{ if (code == id[i]) { return i } } return -1 }
				function checkdetail(index)
 { if (isBlank(document.a.elements[index].value) ) 
	{ return true; }
				var sect = document.a.elements[index +3].value;
 if (isBlank(sect) ) { document.a.elements[index +3].value = "01"; return true; }
				var s = new Number(sect.valueOf() ); var c = checkSubject(document.a.elements[index].value);
 if ( (s > detail[c].valueOf() ) || (s == 0) ) 
	 { alert("Invalid detail " + sect + " �����Ԫ� " + document.a.elements[index].value); return false;  }
 if (s < 10) {
	' document.a.elements[index +3].value =  "0" + s.toString();'
	 document.a.elements[index +3].value =  "" + s.toString();
					}
		 else  {
	document.a.elements[index +3].value =  s.toString();
					} return true; }
function validateForm()
	{  'start function'
		var totalCredit=0; for (var j = 0; j < 51; j += 5) { var index=validate(j);
 if (index==-1 || !checkdetail(j) ) { return; }
 if (index!=-2) { totalCredit += credit[index] }; }
 if (totalCredit > maxCredit) { alert("ŧ����¹������Թ " + maxCredit + " ˹��¡Ե ���͵Դ��ͷ���¹��� / �ӹѡ����¹�"); return; } 
if (totalCredit < minCredit) { alert("ŧ����¹��ͧ����ӡ��� " + minCredit + " ˹��¡Ե ���͵Դ��ͷ���¹��� / �ӹѡ����¹�"); return; } document.a.submit();
 if (pop > 0) { subjectLizst.close(); } }
function validate(j) {var code = document.a.elements[j].value; 
if (isBlank(code) )
	{' document.a.elements[j + 1].value = "";'
	  'document.a.elements[j + 2].value = "";'
	  'document.a.elements[j + 3].value = "";'
return -2; } 
		index = checkSubject(code); 
if (index == -1)
	{ alert("��辺�����Ţͧ�����Ԫ�" + code); document.a.elements[j].focus(); return -1; } 
else { 
	document.a.elements[j + 1].value = desc[index] ;
	document.a.elements[j + 2].value = credit[index] ; 
	document.a.elements[j + 3].value = detail[index] ;
	document.a.elements[j + 4].value = operation[index] ;
	return index;
		} 
	} 'end function'
function init() 
{ 

 } 
</script>
</HEAD>
<style type="text/css">
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color:#FFFFFF; text-decoration: none}
a:visited { color:#FFFFFF; text-decoration: none}
a:active { color: #FFFFFF; text-decoration: none}
a:hover { color: #FF0000; text-decoration: none}
</style>
<body bgcolor="#FFFFFF">
 <form  method="post" name="a" action="Frame-2.php" target =mainFrame>
  <script type="text/javascript" language="JavaScript">init()</script>
  <table width="600" border="0" cellspacing="0" cellpadding="0" align="left">
    <tr>
      <td width="11">&nbsp;</td>
    <td width="600">
        <table cellpadding="2" cellspacing="2" width="592" align="center" bordercolor="#FFFFFF">
          <tr bgcolor="#EAEAFF"> 
    <td align="middle" width="84"> 
      <div align="center"><font face="Tahoma" size="2">�����Ԫ�</font></div>
    </td>
    <td align="middle" width="239" bgcolor="#EAEAFF"> 
      <div align="center"><font face="Tahoma" size="2">�����Ԫ�</font></div>
    </td>
    <td align="middle" width="59"> 
      <div align="center"><font face="Tahoma" size="2">˹��¡Ե</font></div>
    </td>
    <td align="middle" width="54"> 
      <div align="center"><font face="Tahoma" size="2">��Ժѵ�</font></div>
    </td>
    <td align="middle" width="54"> 
      <div align="center"><font size="2" face="Tahoma">������</font></div>
    </td>
    <td align="middle" width="70"> 
      <div align="center"><font size="1" face="MS Sans Serif"><font face="Tahoma"><font face="Tahoma"><font size="1"><font face="Tahoma"><font face="Tahoma"><font size="3"><font size="2"></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr bgcolor="#EAEAFF"> 
    <td width="84"> 
      <div align="center"> <font face="Tahoma" size="2"> 
        <input maxlength="8" name="code" onChange="validate(0)" size="8">
        </font></div>
    </td>
    <td width="239"> 
      <div align="center"> <font face="Tahoma" size="2"> 
        <input name="name"  size="40" readonly>
        </font></div>
    </td>
    <td width="59"> 
      <div align="center"> <font face="Tahoma" size="2"> 
        <input maxlength="2" name="subjectCredit1" size="2" readonly>
        </font></div>
    </td>
    <td width="54"> 
      <div align="center"> <font face="Tahoma" size="2"> 
        <input maxlength="2" name="subjectdetail1" readonly size="2">
        </font></div>
    </td>
    <td width="54"> 
      <div align="center"> <font face="Tahoma" size="2"> 
        <input maxlength="2" name="subjectopreation1" readonly size="2">
        </font></div>
    </td>
    <td width="70"> 
      <div align="center"> <font face="Tahoma" size="2"> 
        <input type="submit" name="Submit" value="���͡�Ԫ�">
<?
	echo "<input type='hidden' name='course_year' value='$course_year'>";
?>
		</font></div>
    </td>
  </tr>
</table>
</td>
  </tr>
</table>
     </form>       
</body>
</html>
