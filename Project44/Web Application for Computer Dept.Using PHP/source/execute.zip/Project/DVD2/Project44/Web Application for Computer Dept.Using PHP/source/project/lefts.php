<?session_start();
?>
<html>
<head>
<title>lefts</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<!--<body background="images/bg_left.gif">-->
 <body bgcolor=#391E8C> 
<table width='100%' border="0" cellspacing="0" cellpadding="0" >
<tr>
<td>

 <?
 include("connect.inc.php");
 $dbname=project();

				  if($id[1]=='student')
				   {
				  ?>
				  
<table width="29%" border="0" height="137" align="center" cellpadding="0" cellspacing="0">
  <tr class=A> 
  <td height="21" colspan="2"> 
                        
      <div align="left"><font size="2"><b><img src="images/lhead1.gif" width="125" height="18"></b></font></div>
                      </td>
                    </tr>
                    <tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="91%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>���ǻ�С��</a></td>
                    </tr>
					<tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="91%" valign="middle">&nbsp;<a href="form1.php" class=a target=_parent>�����ç�ҹ �.�.</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
            
    <td width="91%" height="20" valign="middle">&nbsp;<a href="form1edit.php" class=a target=_parent>����ç�ҹ �.�.</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="91%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=1" class=a target=body>��Ǣ���ç�ҹ</a></td>
                    </tr>
       <tr class=A> 
       <td width="9%" height="20" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
    <td width="91%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=13" class=a target=body>�çҹ���١���͡</a></td>
      </tr>

	<tr class=A> 
                      
    <td width="9%" height="20" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="91%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=2" class=a target=body>��Ǩ�ͺ������</a></td>

                    </tr>
   
					</table>
                <?
				   }//student
				  elseif($id[1]=='teacher')
				  {
				  ?>
                  
<table width="29%" border="0" cellspacing="0" height="125" cellpadding="0" align="center">
  <tr class=A> 
                      <td height="21" colspan="2"> 
                        
      <div align="left"><font size="2"><b><img src="images/lhead1.gif" width="125" height="18"></b></font></div>
                      </td>
                    </tr>
                    <tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="89%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>���ǻ�С�� 
      </a></td>
                    </tr>
					<tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="89%" valign="middle">&nbsp;<a href="bodys.php?select=3" class=a target=body>��С�Ȣ���</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="89%" height="20" valign="middle">&nbsp;<a href="teacherregis.php" class=a target=_parent>������Ǣ���ç�ҹ</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="89%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=5" class=a target=body>�����Ǣ���ç�ҹ</a></td>
    
	</tr>
    
	<tr class=A> 
      <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
      </td>
     <td width="89%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=4" class=a target=body>�ç�ҹ����ʹ�</a></td>
	</tr>
    
	</table>  
				
				<?
				   }//teacher
				  elseif($id[1]=='admin')
				  {
				  ?>
				  
<table width="29%" border="0" cellspacing="0" height="125" align="center" cellpadding="0">
  <tr class=A> 
                      <td height="21" colspan="2"> 
                        
      <div align="left"><font size="2"><b><img src="images/lhead1.gif" width="125" height="18"></b></font></div>
                      </td>
                    </tr>
                    <tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="91%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>���ǻ�С�� 
      </a></td>
                    </tr>
					<tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="91%" valign="middle">&nbsp;<a href="bodys.php?select=3" class=a target=body>��С�Ȣ���</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="91%" height="20" valign="middle">&nbsp;<a href="form1.php" class=a target=_parent>�����ç�ҹ</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="91%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=6" class=a target=body>����ç�ҹ</a></td>
                    	</table>
                 <?
				   }//admin
				  elseif($id[1]=='library')
				  {
				  ?>
				  
<table width="29%" border="0" cellspacing="0" height="125" align="center" cellpadding="0">
  <tr class=A> 
                      <td height="21" colspan="2"> 
                        
      <div align="left"><font size="2"><b><img src="images/lhead1.gif" width="125" height="18"></b></font></div>
                      </td>
                    </tr>
                    <tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="92%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>���ǻ�С�� 
      </a></td>
                    </tr>
					<tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="92%" valign="middle">&nbsp;<a href="bodys.php?select=3" class=a target=body>��С�Ȣ���</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="92%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=7" class=a target=body>������</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="92%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=8" class=a target=body>��ä׹</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" height="20" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="92%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=9" class=a target=body>��Ǩ�ͺ������</a></td>
                    </tr>
                  </table>
				  <?
				   }//library
				  elseif($id[1]=='store')
				  {
				  ?>
				 
<table width="29%" border="0" cellspacing="0" height="125" align="center" cellpadding="0">
  <tr class=A> 
                      <td height="21" colspan="2"> 
                        
      <div align="left"><font size="2"><b><img src="images/lhead1.gif" width="125" height="18"></b></font></div>
                      </td>
                    </tr>
                    <tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="92%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>���ǻ�С�� 
      </a></td>
                    </tr>
					<tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="92%" valign="middle">&nbsp;<a href="bodys.php?select=3" class=a target=body>��С�Ȣ���</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="92%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=10" class=a target=body>������</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="92%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=11" class=a target=body>��ä׹</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" height="20" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="92%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=9" class=a target=body>��Ǩ�ͺ������</a></td>
                    </tr>
                  </table>
				  <?
				   }//store
				  elseif($id[1]=='hardware')
				  {
				  ?>
			 
<table width="29%" border="0" cellspacing="0" height="125" align="center" cellpadding="0">
  <tr class=A> 
                      <td height="21" colspan="2"> 
                        
      <div align="left"><font size="2"><b><img src="images/lhead1.gif" width="125" height="18"></b></font></div>
                      </td>
                    </tr>
                    <tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="93%" valign="middle">&nbsp;<a href="bodys.php" class=a target=body>���ǻ�С�� 
      </a></td>
                    </tr>
					<tr class=A> 
                      
    <td height="20" width="9%" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td height="20" width="93%" valign="middle">&nbsp;<a href="bodys.php?select=3" class=a target=body>��С�Ȣ���</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="93%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=10" class=a target=body>������</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" valign="middle" height="20"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
                      
    <td width="93%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=11" class=a target=body>��ä׹</a></td>
                    </tr>
                    <tr class=A> 
                      
    <td width="9%" height="20" valign="middle"> 
      <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
                      </td>
    <td width="93%" height="20" valign="middle">&nbsp;<a href="bodys.php?select=9" class=a target=body>��Ǩ�ͺ������</a></td>
                    </tr>
                  </table>
				  <?
				  }//hardware
				  ?>
 <table width="75%" border="0" cellspacing="0" align="center" height="100" valign=top>
  <tr class=A> 
       <form method="post" action='bodys.php' target=body name=form1>
	   <td width="4%" align="center" valign="middle" height=20><font class=A> 
            <select name=year1 size="1">
              <?	
						 //�֧������ year �ҡ���ҧ register
                         $sql="select Distinct year from register order by year desc";
                         $dbquery=mysql_db_query($dbname,$sql)or die("error2");
                        ?>
              <option selected>-�ҡ�ա���֡��-</option>
              <?
			               while($result=mysql_fetch_array($dbquery))
		                       {				  
              ?>
              <option> 
              <?print($result[year]);?>
              </option>
              <?
		                  		 }
			  ?>
            </select>
            </font></td>
        </tr>
        <tr class=A> 
          <td width="4%" height="26" valign="middle"> 
            <div align="center"><font color="#FFFFFF" class=A>&nbsp;�֧</font></div>
          </td>
        </tr>
        <tr class=A> 
          <td width="4%" height="8" valign="middle" align="center"> 
            <div align="center"><font class=A>
              <select name=year2 size="1">
                <?	
						 //�֧������ year �ҡ���ҧ register
                         $sql="select Distinct year from register order by year desc";
                         $dbquery=mysql_db_query($dbname,$sql)or die("error2");
                ?>
                <option selected>-�֧�ա���֡��-</option>
                <?
			               while($result=mysql_fetch_array($dbquery))
		                       {				  
                ?>
                <option> 
                <?print($result[year]);?>
                </option>
                <?
		                     }
			    ?>
              </select>
            </font></div>
          </td>
        </tr>
        <tr class=A> 
          <td width="4%" height="34" valign="middle"> 
            <div align="center"> 
              <input type="image" src="images/go.gif" name="image">
            </div>
          </td>
        </form>
		</tr>
		<tr class=A> 
          <form method="post" action='bodys.php' target=body name=form2>
		  <td height="35" valign="middle"> 
            <div align="center"> 
              <input type="text" name="word" size="15">
            </div>
          </td>
        </tr>
        <tr class=A> 
          <td width="4%" height="38" valign="middle"> 
            <div align="center"> 
              <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'ms Sans Serif', system; font-size: 9pt; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Search name=search>
            </div>
          </td>
        </form> 
		</tr>
	  </table>        
 </td>
 </tr>
 </table>
 </body>
</html>
