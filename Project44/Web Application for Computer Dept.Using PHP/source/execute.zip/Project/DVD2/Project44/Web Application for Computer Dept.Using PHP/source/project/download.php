<?
session_start();
?>
<html>
<head>
<title>Display1</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<?
if(((ereg("^.[a-zA-Z0-9]+@.+\..+$",$email))&&($status=='user'))||($id[1]))
  {
    include("connect.inc.php");
    $dbname=project();
   //�֧�����Ũҡ���ҧ register,userregister ��� id
   $sql="select * from register,userregister where register.id='$id1' and register.id=userregister.id";
   $dbquery=mysql_db_query($dbname,$sql)or die("error1");
   $result=mysql_fetch_array($dbquery);
 
   if($status=='user')
	 {  
   
   //��Ǩ�ͺ�����ū��
   $sql="select * from  member_download  where email='$email' and project='$result[namept]'";
   $dbquery=mysql_db_query($dbname,$sql)or die("error01");
   $rows=mysql_num_rows($dbquery);
 
   if($rows==0)
	 {
   //��������ŧ���ҧ user_download   
   $sql="insert into member_download (name,email,project) values ('$name','$email','$result[namept]')";
   $dbquery=mysql_db_query($dbname,$sql)or die("error0");	    
	 }
	 }//status==user
    
?>
<body bgcolor="#FFFFFF">
  
<table width="760" border="0" cellSpacing=0 cellPadding=0>
  <tr class=a>    
      
    <td  align=left width="306"> 
      <div align="left"><img src="images/logo.gif" width="310" height="76"></div>
       </td>
	  
    <td width="473" height="94" class=h> 
      <div align="center"><div align="center"><FONT  COLOR="#CA0065" ><b><?print($result[namept]);?></b></FONT><br><FONT  COLOR="#CA0065" ><b><?print($result[namepe]);?></b></font>
        </div>
    </td>
    </tr>
  </table>
  <br>
  <table width="760" border="0">
  <tr class=a>
      <td > 
        <br>
		<table width="760" border="0" >
          <tr> 
            <td width="15%" valign=top class=d1head>Download File</td>
            <td colspan="2">&nbsp;</td>
          </tr>
          <?if($result[doc]=='document.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%" class=a>&nbsp;</td>
            <td width="2%" valign=middle > <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td width="87%" valign=middle ><a href="id<?print($id1);?>/document.pdf" class=filelink>Document</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap1]=='chap1.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap1.pdf" class=filelink>Chapter 
              1</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap2]=='chap2.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap2.pdf" class=filelink>Chapter 
              2</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap3]=='chap3.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap3.pdf" class=filelink>Chapter 
              3</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap4]=='chap4.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap4.pdf" class=filelink>Chapter 
              4</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap5]=='chap5.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap5.pdf" class=filelink>Chapter 
              5</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap6]=='chap6.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap6.pdf" class=filelink>Chapter 
              6</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap7]=='chap7.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap7.pdf" class=filelink>Chapter 
              7</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap8]=='chap8.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap8.pdf" class=filelink>Chapter 
              8</a></td>
          </tr>
          <?
			 }
		  ?>
              <?if($result[chap9]=='chap9.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap9.pdf" class=filelink>Chapter 
              9</a></td>
          </tr>
          <?
			 }
		  ?>
			      <?if($result[chap10]=='chap10.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap10.pdf" class=filelink>Chapter 
              10</a></td>
          </tr>
          <?
			 }
		  ?>
		  <?if($result[chap11]=='chap11.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap11.pdf" class=filelink>Chapter 
              11</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap12]=='chap12.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap12.pdf" class=filelink>Chapter 
              12</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap13]=='chap13.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap13.pdf" class=filelink>Chapter 
              13</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap14]=='chap14.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap14.pdf" class=filelink>Chapter 
              14</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap15]=='chap15.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap15.pdf" class=filelink>Chapter 
              15</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap16]=='chap16.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap16.pdf" class=filelink>Chapter 
              16</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap17]=='chap17.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap17.pdf" class=filelink>Chapter 
              17</a></td>
          </tr>
          <?
			 }
		  ?>
          <?if($result[chap18]=='chap18.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap18.pdf" class=filelink>Chapter 
              18</a></td>
          </tr>
          <?
			 }
		  ?>
              <?if($result[chap19]=='chap19.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap19.pdf" class=filelink>Chapter 
              19</a></td>
          </tr>
          <?
			 }
		  ?>
			      <?if($result[chap20]=='chap20.pdf')
		     {		  
		  ?>
          <tr> 
            <td width="11%">&nbsp;</td>
            <td width="2%" valign=middle> <img src="images/icon3.gif" width="13" height="11" border="0"> 
            </td>
            <td valign=middle width="87%"><a href="id<?print($id1);?>/chap20.pdf" class=filelink>Chapter 
              20</a></td>
          </tr>
          <?
			 }
		  ?>
		  <tr> 
            <td colspan="3" height="35"> <br>
              <hr width="700" height="5" color=#6699FF>
              <br>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>

<?
//�Դ�ҹ������
closedb();
}
else
{
?>
 <div align="center">
  <br>
  <p><br><font style='font-size:15' color="#FF0000"><b>�����żԴ��Ҵ</b></font></p>
  <p><font class=a><font  color="#FF0000">��س������������١��ͧ��������繨�ԧ</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div> 
<?
}
?>
</body>
</html>
