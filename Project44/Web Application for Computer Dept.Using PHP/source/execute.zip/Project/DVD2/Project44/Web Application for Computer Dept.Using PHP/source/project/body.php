<?session_start();
?>
<html>
<head>
<title>�ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF" >
  
  <table width="630" border="0"  valign=top>
  <tr class=A>
    <td valign="top"> 
      <?
          include("connect.inc.php");
		  $dbname=project();	
		   if($word)
		    {
		    $sql="select * from register where (key1 Like '%$word%' or key2 Like '%$word%' or key3 Like '%$word%' or key4 Like '%$word%' or key5 Like '%$word%') order by year asc,namepe asc";
   	        $dbquery=mysql_db_query($dbname,$sql)or die("error01");
		    $rows=mysql_num_rows($dbquery);	 
		    if($rows!=0)
			  {
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		          if($temp!=$result1[year])
				  {
			?>
		 <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			<tr height='20'> 
                <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
             </tr>
			<?
				 $temp=$result1[year]; 
			     }
			   ?>
		<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
          <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>		  		
		<?
		 }//while1     
		  }//if0
		   
		   
		   else
			  {
			    $sql="select * from register where (namepe Like '%$word%' or namept Like '%$word%') order by year asc,namepe asc";
				$dbquery=mysql_db_query($dbname,$sql)or die("error02");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("advisor");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		           if($temp!=$result1[year])
				  {
			   ?>
		        <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20'> 
                      <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
                </tr>
			     </table>
					  <?
				 $temp=$result1[year]; 
			     }
			   ?>
             <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
		<table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while2     
		 }//if1
		   
		   else
			  {
			    $sql="select * from register where (advisor1 Like '%$word%' or advisor2 Like '%$word%') order by year asc,namepe asc";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error02");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("advisor");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		           if($temp!=$result1[year])
				  {
			   ?>
		        <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20' class=A> 
                      <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
                </tr>
			     </table>
					  <?
				 $temp=$result1[year]; 
			     }
			   ?>
             <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
		<hr width="500" noshade color=#666600>
		<?
		  }//while2     
		 }//if2
	    
else
			  {
			    $sql="select * from userregister where (name1 Like '%$word%' or name2 Like '%$word%' or name3 Like '%$word%' or name4 Like '%$word%') ";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error04");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("name");
			  //print($rows); 
			   $temp='';
			   while($result=mysql_fetch_array($dbquery))
			     {
		         $sql1="select * from register where id='$result[id]' order by year asc,namepe asc";
  	             $dbquery1=mysql_db_query($dbname,$sql1)or die("error03");
			     $result1=mysql_fetch_array($dbquery1);
			    if($temp!=$result1[year])
				  {
			     ?>
		          <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20'> 
                     <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT  COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
                   </tr>
			       </table>
					 <?
				 $temp=$result1[year]; 
			     }
				 ?>
              <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
               <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
          <hr width="500" noshade color=#666600>
		<?
		  }//while3     
		 }//if3
	    
else
			  {
			    $sql="select * from userregister where (code1 Like '%$word%' or code2 Like '%$word%' or code3 Like '%$word%' or code4 Like '%$word%')";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error05");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("code");			   
			   //print($rows);
			   $temp='';
			   while($result=mysql_fetch_array($dbquery))
			     {
		         $sql1="select * from register where id='$result[id]' order by year asc,namepe asc";
  	             $dbquery1=mysql_db_query($dbname,$sql1)or die("error03");
			     $result1=mysql_fetch_array($dbquery1);
			     if($temp!=$result1[year])
				  {
			    ?>
		           <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			         <tr height='20'> 
                      <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT  COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
                    </tr>
			      </table>
					  <?
				 $temp=$result1[year]; 
			     }
				 ?>
            <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                  <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>

			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
          <hr width="500" noshade color=#666600>
		<?
		  }//while4     
		 }//if4
	   else
			  {
			    $sql="select * from register where (abst Like '%$word%' or abse Like '%$word%') order by year asc,namepe asc";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error03");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("abst");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		       
                 if($temp!=$result1[year])
				  {
			?>
		 <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			<tr height='20'> 
                <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT  COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
             </tr>
			 </table>
				<?
				 $temp=$result1[year]; 
			     }
			?>
			<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                  <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
	     <hr width="500" noshade color=#666600> 	   
		<?
		  }//while5     
		 }//if5
	   
		}//else0
		}//else1
        }//else2
		}//else3 
		}//else4 
	    }//if(!word)
		  else
		  {
		  //�֧�����Ũҡ���ҧ register
		  if(($year1!='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-')&&($year1)&&($year2))
           $sql="select * from register where (year between '$year1' and '$year2') or (year between '$year2' and '$year1') "; 
		  elseif(($year1=='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year2' "; 
		  elseif(($year1!='-�ҡ�ա���֡��-')&&($year2=='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year1' "; 
		  else		  
			  {
		  $sql="select year from register order by year Desc,namepe asc";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error1");		  
		  $re=mysql_fetch_array($dbquery);
           
		  $sql="select * from register where year='$re[year]'";
			  }
		  $dbquery=mysql_db_query($dbname,$sql)or die("error1");
		  $rows=mysql_num_rows($dbquery);	
		  if(($year1!='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-')&&($year1!="")&&($year2!=""))
           $sql="select * from register where (year between '$year1' and '$year2') or (year between '$year2' and '$year1') order by year asc,namepe asc "; 
		  elseif(($year1=='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year2' order by namepe asc "; 
		  elseif(($year1!='-�ҡ�ա���֡��-')&&($year2=='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year1' order by namepe asc "; 
		   else    
		      
		    $sql="select * from register where year='$re[year]'order by namepe asc ";
            $dbquery=mysql_db_query($dbname,$sql)or die("error2");
		    $temp='';
			while($result1=mysql_fetch_array($dbquery))
			  {	    
              if($temp!=$result1[year])
				  {
			?>
		 <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			<tr height='20'> 
                <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT  COLOR="ffffff" class=A><b>�ա���֡�� <?print($result1[year]);?></b></FONT></td>
             </tr>
			 </table>
				<?
				 $temp=$result1[year]; 
			     }
			?>
			
			<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                  <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
          <hr width="500" noshade color=#666600>		 	   
		<?
		 }//while
		}//if
		?>
		<br>
<br>

<table width="630" border="0" cellspacing="0" cellpadding="0">
  <tr class=A>
    <td>&nbsp;</td>
  </tr>
  <tr class=A>
    <td>
      <div align="center" class=A><font color="#000080" >Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr class=A>
    <td height="8">
      <hr align="center" width="550" size="2">
    </td>
  </tr>
  <tr class=A>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
   
   </td>
  </tr>
</table>
<?
//�Դ�ҹ������
closedb();
?>
</body>
</html>