<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="620" border="0" cellspacing="0" cellpadding="0" align="left">
<tr> 
    <td>
<? 
include ("connect_course.inc.php");
echo "<form name='form1' method='post' action='delete.php'>
<table width='600' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center'>
  <tr bgcolor='#F7F7F7'> 
    <td colspan='6' height='48'> 
      <div align='center'><font face='Tahoma' size='2' color='#515151'><br>
        ��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
        ��ѡ�ٵ�$course_year<br>
        ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
        ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> <br>
        &nbsp; </div>
    </td>
  </tr>";

  $i=1;
	if ($name !='')
	{
	$sql_temp = "INSERT INTO $Temptable(Code) VALUES ('$code')"; 
   $result_temp = mysql_db_query($dbName,$sql_temp);
	$query = "Select * From $Subjecttable,$Temptable Where $Subjecttable.Code=$Temptable.Code AND  $Subjecttable.Course_year='$course_year' order by $Temptable.Code ASC LIMIT 0, 50 ";
	$result = mysql_db_query($dbName,$query);
	if ($result)
	{
		echo "	
     <tr bgcolor='#EAEAFF'> 
    <td width='34' height='20' bgcolor='#EAEAFF'> 
      <div align='center'><font size='2' face='Tahoma'>���͡</font></div>
    </td>
    <td width='94' height='20' bgcolor='#EAEAFF'> 
      <div align='center'><font size='2' face='Tahoma'>������Ǵ�Ԫ�</font></div>
    </td>
    <td width='98' height='20'> 
      <div align='center'><font size='2' face='Tahoma'>�����Ң��Ԫ�</font></div>
    </td>
    <td width='63' height='20'> 
      <div align='center'><font size='2' face='Tahoma'>�����Ԫ�</font></div>
    </td>
    <td width='199' height='20'> 
      <div align='center'><font size='2' face='Tahoma'>�����Ԫ�</font></div>
    </td>
    <td width='98' height='20'> 
      <div align='center'><font size='2' face='Tahoma'>˹��¡Ե<br>
        (������ - ��Ժѵ�)</font></div>
    </td>
  </tr>";
	 	while ($row = mysql_fetch_array($result)) 
			{
						  $category = htmlspecialchars($row[Category]); 
						  $gsubject = htmlspecialchars($row[Gsubject]); 
						  $code = htmlspecialchars($row[Code]); 
						  $name = htmlspecialchars($row[Name]);
						  $ename = htmlspecialchars($row[Ename]); 
						  $unit = htmlspecialchars($row[Unit]); 
						  $unit_detail = htmlspecialchars($row[Unit_detail]); 
						  $unit_operation = htmlspecialchars($row[Unit_operation]);
			echo " 
					<tr bgcolor='#F7F7F7'> 
					<td height='23' width='34'>
					<div align='center'><font size='2' face='Tahoma'> 
					<input type='checkbox' name='check[$i]' value='$code'>
					</font></div>
					</td>
					<td height='23' width='94'>
					<div align='center'><font face='Tahoma' size='2'>$category</font></td></div>
					<td height='23' width='98'>
					<div align='center'><font face='Tahoma' size='2'>$gsubject</font></td></div>
					<td height='23' width='63'>
					<div align='center'><font face='Tahoma' size='2'>$code</font></td></div>
					<td height='23' width='199'>
					<div align='center'><font face='Tahoma' size='2'>$name $ename</font></td></div>
					<td height='23' width='98'>
					<div align='center'><font face='Tahoma' size='2'>$unit($unit_detail-$unit_operation)</font></td></div>
				  </tr>
				 <input type='hidden' name='sum' value='$i'>
				 <input type='hidden' name='cate[$i]' value='$category'>";
							$i =$i +1;	  
				}
				echo " 
				  <tr bgcolor='#EAEAFF'> 
					<td height='19' width='34'><font size='2' face='Tahoma'></font></td>
					<td height='19' width='94'>&nbsp;</td>
					<td height='19' width='98'><font face='Tahoma' size='2'></font></td>
					<td height='19' width='63'><font face='Tahoma' size='2'></font></td>
					<td height='19' width='199'><font face='Tahoma' size='2'></font></td>
					<td height='19' width='98'><font face='Tahoma' size='2'></font></td>
				  </tr>
				  <tr bgcolor='#F7F7F7'> 
					<td colspan='6' height='2'> 
					  <div align='center'><font size='2' face='Tahoma'><br>
						<input type='submit' name='Submit' value='ź������'>
						<input type='reset' name='Submit2' value='  ¡��ԡ  '>
						</font></div>
					</td>
				  </tr>
				</table>
					<input type='hidden' name='course_year' value='$course_year'>";
	}
	}
	?>
</form>
<table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</td>
<tr>
</table>
</body>
</html>
