<?
    function gwebboard()
    {
		$dbname="gwebboard";
        $handle=mysql_connect("localhost","root","webmaster123");
		mysql_select_db($dbname,$handle); 
	    return($dbname);  
	}

	function project()
    {
		$dbname="project";
        $handle=mysql_connect("localhost","root","webmaster123");
		mysql_select_db($dbname,$handle); 
	    return($dbname);  
	}

	function register()
    {
		$dbname="register";
        $handle=mysql_connect("localhost","root","webmaster123");
		mysql_select_db($dbname,$handle); 
	    return($dbname);  
	}

   function closedb()
   {
	    $handle=mysql_connect("localhost","root","webmaster123");
		mysql_close($handle);   
   }

function checkd($d2)
 {
    $d=date('d');
    $m=date('m');
    $y=date('y');
    $arr=explode("-",$d2);
	if($y>$arr[0])
	  $m+=($y-$arr[0])*12;
    if($m>$arr[1])
      $d+=($m-$arr[1])*30;	
	if(($d-$arr[2])>=3)   //�礻�С������Т�� new �����ҡ���� 3 �ѹ ������� new
	    return(1); 	    
 }

function compareday($d1,$d2)
 {
    $arr1=explode("-",$d1);
	$arr2=explode("-",$d2);
	if($arr2[2]>$arr1[2])
	  $arr2[1]+=($arr2[2]-$arr1[2])*12;
    if($arr2[1]>$arr1[1])
      $arr2[0]+=($arr2[1]-$arr1[1])*30;	
	if(($arr2[0]-$arr1[0])<0)   //���º��º�ѹ������ ��� ��˹��׹ ��ҹ��¡��� 0 �ʴ���� �Թ��˹�
	    return(1); 	    
 }

function zerofront($temp)
 {
    if(strlen($temp)==1)
     {  
	   $temp=('0'.$temp);  
	   return($temp);
	 }
   else
      return($temp);
 }

function genpassword()
{
  srand(time());
  $list="abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for($r=0;$r<6;$r++)
	{
	 $index=rand() % 62;
	 $pass.=substr($list,$index,1);
	}
return($pass);
}
?>