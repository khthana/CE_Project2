<html>
<head>
<title>ź�������ç���ҧ��ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
	echo"
	<tr> 
    <td width='11'  >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD'  >&nbsp;</td>
    <td width='134' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
	<a href='introduce_delete.php?course_year=$course_year' target ='_parent'>ź��ѡ�ٵû�ԭ�ҵ��</a><br>
      ź�ç���ҧ��ѡ�ٵ�<br>
	  <a href='structure_delete_category.php?course_year=$course_year' target ='_parent'>ź��������Ǵ�Ԫ�</a><br>
      <a href='structure_delete_group.php?course_year=$course_year' target ='_parent'>ź�����š�����Ԫ� </a><br>
	 <a href='Bachelor/Delete/Subject/delete_subject.php?course_year=$course_year' target ='_parent'>ź����������Ԫ� <br>
      <a href='Bachelor/Delete/Course/delete_course.php?course_year=$course_year' target ='_parent'>�ǡ�èѴ�Ԫ����¹</a><br>
		<a href='index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;
      </td>
    <td width='619' valign='top'> 
		<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF' >
          <tr bgcolor='#F7F7F7'> 
            <td height='21' colspan='4'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font size='2' face='Tahoma'></font><font face='Tahoma' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵúѳ�Ե 
                �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year <br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ <br>&nbsp; </font></div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'>
            <td height='27' colspan='4'><font size='2' face='Tahoma'><b>14. ��ѡ�ٵ�</b></font></td>
          </tr>";
	// select data from all table by course_year

	$query = "Select * From $Structuretable Where Course_year = '$course_year' ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$program1_unit = htmlspecialchars($row[Program1_unit]);
	$program2_unit = htmlspecialchars($row[Program2_unit]);
	$detail = $row[Detail];

echo "
          <tr bgcolor='#D2F8FD'> 
            <td  width='38' bgcolor='#F7F7F7'>&nbsp;</td>
            <td  colspan='2'> 
              <div align='left'><font size='2' face='Tahoma'>$detail</font></div>
            </td>
            <td  width='36' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='27' colspan='4' bgcolor='#F7F7F7'> 
              <div align='left'><font size='2'><font size='2'><font face='Tahoma'><b>14.1 
                �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font></font></font></div>
            </td>
          </tr>
          <tr> 
            <td height='22' width='38' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='22' width='180' bgcolor='#D2F8FD'> 
              <div align='left'><font size='2' face='Tahoma'>- ���������֡�ҷ�� 
                1</font></div>
            </td>
            <td height='22' width='336' bgcolor='#D2F8FD'><font size='2' face='Tahoma'>&nbsp; &nbsp;$program1_unit ˹��¡Ե </font></td>
            <td height='22' width='36' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='30' width='38' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
            <td height='30' width='180' bgcolor='#D2F8FD'> 
              <div align='left'><font size='2' face='Tahoma'>- ���������֡�ҷ�� 
                2</font></div>
            </td>
            <td height='30' width='336' bgcolor='#D2F8FD'><font size='2' face='Tahoma'>&nbsp; &nbsp;$program2_unit ˹��¡Ե </font></td>
            <td height='30' width='36' bgcolor='#F7F7F7'>&nbsp;</td>
          </tr>
		<tr bgcolor='#F7F7F7'>
            <td height='27' colspan='4'>
			<div align='center'><font size='2' face='Tahoma'><A HREF='check_delete_course.php?course_year=$course_year'>ź�������ç���ҧ��ѡ�ٵ�</A></font></div>
			</td>
          </tr>
         </table>";
		}
	}	else { 
	 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>����բ������ç���ҧ��ѡ�ٵ�</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr>
				</table>";
			}

	   ?>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
