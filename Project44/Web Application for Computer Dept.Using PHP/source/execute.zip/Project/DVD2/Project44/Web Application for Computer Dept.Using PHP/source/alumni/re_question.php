<?php
	session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left"> 
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><img src="image/logo-kmitl.jpg" width="139" height="137"></font></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="137">
                <tr> 
                  <td><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><img src="image/logo-alumni.jpg" width="600" height="80"></font></td>
                </tr>
                <tr> 
                  <td> 
                    <table width="100%" border="0" cellspacing="1" cellpadding="1"align="left" bordercolor="#000000" bgcolor="#000000">
                      <tr class = BNFont1 align="center"> 
                        <td bgcolor="#99CCFF" width="25%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="index.php"><b>Home</b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="register_form.php"><b>ŧ����¹</b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="login.php"><b>��䢢�����</b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td> 
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000" height="100%">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></font></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="normal.php"><b>�Ҥ����</b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><a href="cont.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></font></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"><a href="cont.php"><b>�Ҥ������ͧ</b></a></font> 
                        </td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                        <td width="78%" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        <td bgcolor="#CCCCFF" height="15"> 
                          <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="1" color="#FFFFFF" class="fsize8" align="center"><b>&nbsp;<font color="#000000" size="2">����</font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                    </font></div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                    </font></div>
                                </td>
                              </tr>
                            </table>
                          </td>
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF" height="100%">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624" valign="top"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                <tr> 
                  <td> 
                    <div align="center"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
                      <?php
	include("alumni.inc");
	include("smtpmail.inc.php");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql1= "SELECT * FROM data_alumni WHERE std_id = '$login[1]'"; 
	$db_query1 = mysql_db_query($dbname, $sql1);
	$nums_rows1 = mysql_num_rows($db_query1);
	if($nums_rows1!="0"){
		for ($i=0;$i<$nums_rows1;$i++){
		$result = mysql_fetch_array($db_query1);
		$std_number = $result[std_number];
		$std_id = $result[std_id ];
		$std_class = $result[std_class];
		$std_fullname = $result[std_fullname];
		$std_type1 = $result[std_type1];
		$std_nick = $result[std_nick];
		$std_type = $result[std_type];
		$std_days  = $result[std_days];
		$std_day  = $result[std_day];
		$std_mount  = $result[std_mount];
		$std_year  = $result[std_year];
		$std_work  = $result[std_work];
		$std_position = $result[std_position ];
		$std_address_born = $result[std_address_born];
		$std_address_now= $result[std_address_now];
		$std_tel_home= $result[std_tel_home];
		$std_tel_work = $result[std_tel_work];
		$std_pager  = $result[std_pager];
		$std_icq  = $result[std_icq];
		$std_email  = $result[std_email];
		$std_homepage = $result[std_homepage];
		$std_username = $result[std_username];
		$std_password1 = $result[std_password1];
		$std_password2  = $result[std_password2];
		$std_datetime = $result[std_datetime];
		$std_question = $result[std_question];

		$std_id=stripslashes($std_id);
		$std_class = stripslashes($std_class);
		$std_fullname = stripslashes($std_fullname);
		$std_type1 = stripslashes($std_type1);
		$std_nick = stripslashes($std_nick);
		$std_type = stripslashes($std_type);
		$std_days  = stripslashes($std_days);
		$std_day  = stripslashes($std_day);
		$std_mount  = stripslashes($std_mount);
		$std_year  = stripslashes($std_year);
		$std_position = stripslashes($std_position );
		$std_address_born = stripslashes($std_address_born);
		$std_address_now= stripslashes($std_address_now);
		$std_tel_home= stripslashes($std_tel_home);
		$std_tel_work = stripslashes($std_tel_work);
		$std_pager  = stripslashes($std_pager);
		$std_icq  = stripslashes($std_icq);
		$std_email  = stripslashes($std_email);
		$std_homepage   = stripslashes($std_homepage);
		$std_username   = stripslashes($std_username);
		$std_password1   = stripslashes($std_password1);
		$std_password2   = stripslashes($std_password2);
		$std_question = stripslashes($std_question);

		$subject="<br>���ʼ�ҹ�ͧ�س $std_fullname";
		$msg="<table cellspacing='1' border='0' cellpadding='1' align='center'><tr><td>Username</td><td><b>$std_username</b></td></tr><td>Password</td><td><b>$std_password1</b></td></tr></table><hr width='80%'>";
	if($std_question==""){
			print "<font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3 color=#003399>��س����䢢�������ǹ��ǡ�͹���ͧ�ҡ�ѧ����駤Ӷ��</font>";
			print "<META http-equiv=refresh content=\"2; URL=login.php\">";
			exit;
		}else{
		}
		if($std_question==$re_question){
			print "$subject<br>";
			print "$msg<br>";
		}else{
			print "<font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3 color=#003399>�Ӷ�����ç�ѹ</font>";
			print "<META http-equiv=refresh content=\"2; URL=re_pwd.php\">";
		}
//		smail($std_email,$subject,$msg);
//		print "<br><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3 color=#003399>�������ö�����ʼ�ҹ���س���سҵԴ��� Webmaster</font>";
//		print "<META http-equiv=refresh content=\"2; URL=re_pwd.php\">";
}
}
else{
	      echo"<br><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep\"size=3 color=#003399>����բ����Ţͧ��ҹ ��سҵ�Ǩ�ͺ���ʹѡ�֡�������ա����</font>";
}
?>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td height="100%">&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>
  <div align="center"> </div>
</center>
</body>
</html>
