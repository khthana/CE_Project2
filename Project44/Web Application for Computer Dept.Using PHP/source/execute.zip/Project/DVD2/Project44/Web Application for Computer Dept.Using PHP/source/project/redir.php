<?   session_start();
		include ("md5.js");
		include("connect.inc.php");
		if($login=='Submit')
		 {
			session_unset();
			$dbname=register();
			$sql="select * from regis where username='$username'";
            $dbquery=mysql_db_query($dbname,$sql)or die("error1");
            $rows=mysql_num_rows($dbquery);
			if($rows==1)
			 {
			   $result=mysql_fetch_array($dbquery);   
		       $pwd2=MD5(MD5($result[pass]).$random);
			   if($pwd2==$pwd)
			     { 
			      session_unset();
			      //session_start();
			     //session_destroy();
		         $id=array($result[code],$result[status]);
                 session_register(id);
			     }
			 }
			//�Դ�ҹ������
            closedb();
		 }
?>
<html>
<head>
<title>�ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</head>
<?
if($id[1])
 {
 ?>        
  <body bgcolor="#FFFFFF">
     <?print("<META HTTP-EQUIV='REFRESH' Content=0;URL=indexs.php>");?>
 </body>
</html>
<?
 }	
else
{
?>
<br>
<div align="center">
  <p><br><font class=h><font  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font  color="#FF0000">��سҵ�Ǩ�ͺ username&password �ͧ�س�����ա����</font></font></p>
  <a href='login.php' class=home>BACK</a>
<hr width="400">
  <p>&nbsp;</p>

 </div>
<?
 }
?>