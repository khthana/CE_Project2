<?
session_start();
$m=session_id();
if($m==$mem[id]){
}else{
	exit;
}
include("alumni.inc");
include("md5.js");
if($name&&$pwd){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="select * from administrator where ad_user='$name'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	if($NRow==0){ 
?><title>Login Administrator</title>
			
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="3; URL=logina.php">
<font face="MS Sans Serif, Microsoft Sans Serif" size="3"> 
<?php
	}
	else{
		$row = mysql_fetch_array($result);
		$pwd1=$row["ad_passwd"];
		$pwd1=MD5($pwd1).$challenge;
		$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
		if($name==$row["ad_user"] && $pwd==$pwd1) { 
			print "<META http-equiv=refresh content=\"2; URL=index.php\">";
			$sql1 = "delete from data_alumni where std_number='$login[id]'";
			$dbquery1 = mysql_db_query($dbname, $sql1)or die("ź�����");
			print "<br><br><center><font color='#000000' face='MS Sans Serif, Microsoft Sans Serif' size=3>�����Ŷ١ź���º�������Ǥ�Ѻ</font></center>";
		}
		else{
?>
</font> 
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="3; URL=logina.php">
<font face="MS Sans Serif, Microsoft Sans Serif" size="3"> 
<?php
	 }	
}
}
?>
</font>