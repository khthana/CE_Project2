<?session_start();
    session_unset();
   session_destroy();
if($id[1]=='')
  {
?>
<html>
<head>
<title>�ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<frameset rows="105,*" frameborder="no" border="0" framespacing="0" cols="*"> 
  <frame name="head" scrolling="NO" noresize src="head.php" >
  <frameset cols="125,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
    <frame name="left" src="left.php" scrolling="no" noresize>
    <frame name="body" src="body.php" scrolling="yes" noresize>
  </frameset>
  </frameset>
</html>
<?
  }
?>