<html>
<head>
<title>������������ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<?
echo "
<table width='778' border='0' cellspacing='0' cellpadding='0' >
  <tr>
    <td width='11'  >&nbsp;</td>
    <td width='14' bgcolor='#DAEEFE'  >&nbsp;</td>
    <td width='134' bgcolor='#DAEEFE' valign='top'  ><font face='Tahoma' size='2' color='#9900CC'><br>
      ��ѡ�ٵû�ԭ���</font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_insert_course.php'>�ç���ҧ��ѡ�ٵ�</a><br>
	   <a href='select_course_type.php'>�����ç���ҧ����</a><br>
	  <a href='insert_category.php'>������Ǵ�Ԫ�����</a><br>
      <a href='select_course_group.php'>�����Ң��Ԫ����� </a><br>
	  <a href='Master/Insert/Subject/select_course.php' >��������Ԫ����� </a><br>
	   <a href='Master/Insert/Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a><br>
       <a href='index.php'>��Ѻ˹����ѡ </a></font>
      <br>
      </td>
	        <form name='form' method='post' action='insert_introduce.php'>
      <td width='619' valign='top'> 
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr valign='middle' bgcolor='#F7F7F7'> 
            <td colspan='2' height='103'> 
              <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵ���Һѳ�Ե 
                �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ� 
                <input type='text' name='course_year' size='30'>
                <br>
                ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td colspan='2' height='29'><b><font size='2' color='#000000' face='Tahoma'>1. 
              ������ѡ�ٵ� </font></b></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>����������</font></td>
            <td width='502' bgcolor='#DAEEFE' height='34'> <font size='2' face='Tahoma'> 
              <input type='text' name='ctname' value='' size='50'>
              </font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>���������ѧ���</font></td>
            <td width='502' bgcolor='#DAEEFE' height='34'> <font size='2' face='Tahoma'> 
              <input type='text' name='cename' value='' size='50'>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' height='23' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'><b>2. 
              ���ͻ�ԭ��</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
              (��)</font></td>
            <td width='502' bgcolor='#DAEEFE' height='34'> <font size='2' face='Tahoma'> 
              <input type='text' name='ftname' value='' size='50'>
              </font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
              (��)</font></td>
            <td width='502' bgcolor='#DAEEFE' height='34'> <font size='2' face='Tahoma'> 
              <input type='text' name='stname' value='' size='50'>
              </font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
              (�ѧ���)</font></td>
            <td width='502' bgcolor='#DAEEFE' height='34'> <font size='2' face='Tahoma'> 
              <input type='text' name='fename' value='' size='50'>
              </font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font face='Tahoma' size='2' color='#000000'>������� 
              (�ѧ���)</font></td>
            <td width='502' bgcolor='#DAEEFE' bordercolor='#FFFFFF' height='34'> 
              <font size='2' face='Tahoma'> 
              <input type='text' name='sename' value='' size='50'>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' height='26' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>3. 
              ˹��§ҹ�Ѻ�Դ�ͺ</b></font></td>
          </tr>
          <tr> 
            <td width='106' height='132' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
            <td width='502' height='132' bgcolor='#DAEEFE'> <font size='2' face='Tahoma'> 
              <textarea name='accept' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>4. 
              ��Ѫ������ѵ�ػ��ʧ��ͧ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td width='106'  height='132' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#DAEEFE'  height='132' width='502'><font face='Tahoma' size='2'> 
              <textarea name='philosophy_article' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>5. 
              ��˹�����Դ�͹</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='34'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='34'><font face='Tahoma' size='2'> 
              <input type='text' name='program' size='50' value=''>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>�<b>6. 
              �س���ѵԢͧ�������֡��</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='132'><font face='Tahoma' size='2'> 
              <textarea name='property' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>7. 
              ��äѴ���͡�������֡��</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='132'><font face='Tahoma' size='2'> 
              <textarea name='test' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>8. 
              �к�����֡��</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='132'><font face='Tahoma' size='2'> 
              <textarea name='csystem' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>9. 
              �������ҡ���֡��</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='132'><font face='Tahoma' size='2'> 
              <textarea name='ctime' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>10. 
              ���ŧ����¹���¹</b></font></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='132'><font face='Tahoma' size='2'> 
              <textarea name='register' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><b><font face='Tahoma' size='2'>11. 
              ����Ѵ����С������稡���֡��</font></b></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='132'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='132'><font face='Tahoma' size='2'> 
              <textarea name='process' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><b><font face='Tahoma' size='2'>12. 
              �ӹǹ�ѡ�֡��</font></b></td>
          </tr>
          <tr> 
            <td width='106' bgcolor='#F7F7F7' height='207'><font face='Tahoma' size='2'></font></td>
            <td width='502' bgcolor='#DAEEFE' height='207'> 
              <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='left'>
                <tr> 
                  <td rowspan='2' width='124'> 
                    <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                  </td>
                  <td colspan='5' height='37'> 
                    <div align='center'><font face='Tahoma' size='2'>�ա���֡��</font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='72' height='37'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='year1' size='4' maxlength='4'>
                      </font></div>
                  </td>
                  <td width='72' height='37'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='year2' size='4' maxlength='4'>
                      </font></div>
                  </td>
                  <td width='72' height='37'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='year3' size='4' maxlength='4'>
                      </font></div>
                  </td>
                  <td width='72' height='37'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='year4' size='4' maxlength='4'>
                      </font></div>
                  </td>
                  <td width='95' height='37'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='year5' size='4' maxlength='4'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='124' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      1</font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='a_year1' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='a_year2' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='a_year3' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='a_year4' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='95' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='a_year5' size='4' maxlength='3'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='124' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                      2</font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='b_year1' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='b_year2' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='b_year3' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='b_year4' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='95' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='b_year5' size='4' maxlength='3'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='124' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>���</font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='sum1' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='sum2' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='sum3' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='sum4' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='95' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='sum5' size='4' maxlength='3'>
                      </font></div>
                  </td>
                </tr>
                <tr> 
                  <td width='124' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>�Ҵ��ҨШ�����֡��</font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='end1' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='end2' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='end3' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='72' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'> 
                      <input type='text' name='end4' size='4' maxlength='3'>
                      </font></div>
                  </td>
                  <td width='95' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>
                      <input type='text' name='end5' size='4' maxlength='3'>
                      </font></div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>13. 
              ʶҹ�������ػ�ó����͹</b></font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7'  height='132' width='106'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'></font></td>
            <td bgcolor='#DAEEFE'  height='132' width='106'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'> 
              <textarea name='place_tool' cols='80' rows='7'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font> 
              <div align='center'> 
                <input type='submit' name='Submit' value='�ѹ�֡������'>
                <input type='reset' name='Submit2' value='¡��ԡ������'>
              </div>
            </td>
          </tr>
        </table>
    </td>
		  </form>
  </tr>
</table>";
?>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
