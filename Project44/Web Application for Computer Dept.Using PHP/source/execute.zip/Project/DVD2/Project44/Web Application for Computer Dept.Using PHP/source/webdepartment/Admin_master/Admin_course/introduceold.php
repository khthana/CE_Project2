<html>
<head>
<title>�ʴ���ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2" bgcolor="#3E3EA8"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<font face="Tahoma" size="2"><table width="778" border="0" cellspacing="0" cellpadding="0"> 
</font> 
<tr> 
  <td width='11'>&nbsp;</td>
  <td width='14' bgcolor='#DAEEFE'>&nbsp;</td>
  <td width='134' bgcolor='#DAEEFE' valign='top'><font face='Tahoma' size='2' color='#9900CC'><br>
    ��ѡ�ٵû�ԭ���</font> <font face='Tahoma' size='2' color='#9900CC'><br>
   <a href='show_select_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
   <a href='show_select_category.php?course_year=$course_year'>��������Ǵ�Ԫ�</a><br>
      <a href='show_select_group.php?course_year=$course_year'>�����š�����Ԫ� </a><br>
	   <a href='show_select_subject.php?course_year=$course_year'>����������Ԫ� </a><br>
    <a href='tendency.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a></font> <font face='Tahoma' size='2'><br>
      <a href='index.php'>��Ѻ˹����ѡ </a></font></font></td>
    <td width='619' valign='top'>
	  <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
        <tr valign='middle'> 
          <td colspan='2' height='103' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵ���Һѳ�Ե 
              �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
              ��ѡ�ٵ�$course_year&nbsp;<br>
              ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
          </td>
        </tr>
        <tr bgcolor='#F7F7F7'> 
          <td colspan='2' height='29'><b><font size='2' color='#000000' face='Tahoma'>1. 
            ������ѡ�ٵ� </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'>����������</font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$ctname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'>���������ѧ���</font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$cename&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' height='23' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'><b>2. 
            ���ͻ�ԭ��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$ftname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$stname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'>������� 
            (�ѧ���)</font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$fename&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'>������� 
            (�ѧ���)</font></td>
          <td width='503' bgcolor='#DAEEFE' bordercolor='#FFFFFF'><font face='Tahoma' size='2'>$sename&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' height='26' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>3. 
            ˹��§ҹ�Ѻ�Դ�ͺ</b></font></td>
        </tr>
        <tr> 
          <td height='42' bgcolor='#F7F7F7'></td>
          <td height='42' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$accept&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>4. 
            ��Ѫ������ѵ�ػ��ʧ��ͧ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'><b>4.1 
            ��Ѫ�Ңͧ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$philosophy&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'><b>4.2 
            �ѵ�ػ��ʧ��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'>&nbsp;</td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$article&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>5. 
            ��˹�����Դ�͹ </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$program&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>6.</b></font><b><font face='Tahoma' size='2'> 
            �س���ѵԢͧ�������֡�� </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$property&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>7. 
            ��äѴ���͡�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$test&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>8. 
            �к�����֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$csystem&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>9. 
            �������ҡ���֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='29'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE' height='29'><font face='Tahoma' size='2'>$ctime&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>10.</b></font><b><font face='Tahoma' size='2'> 
            ���ŧ����¹���¹ </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$register&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>11. 
            ����Ѵ����С������稡���֡��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$process&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>12. 
            �ӹǹ�ѡ�֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'>&nbsp;</td>
          <td width='503' bgcolor='#DAEEFE'> 
            <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF'>
              <tr> 
                <td rowspan='2'> 
                  <div align='center'><font face='Tahoma' size='2'></font></div>
                  <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                </td>
                <td colspan='4'> 
                  <div align='center'><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'></font><font face='Tahoma' size='2'></font><font face='Tahoma'><font face='Tahoma'><font size='2'>�ա���֡��</font></font></font><font face='Tahoma' size='2'></font></div>
                </td>
              </tr>
              <tr> 
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    1</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d1_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d1_year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d1_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d1_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    2</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d2_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d2_year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d2_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d2_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    3 </font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d3_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d3_year&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d3_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d3_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    4 </font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d4_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d4_year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d4_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$d4_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    1P</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p1_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p1_year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p1_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p1_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    2P</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p2_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p2_year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p2_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p2_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    3P</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p3_year1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p3_year2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p3_year3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$p3_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>���</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$sum1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$sum2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$sum3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$sum4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%'> 
                  <div align='center'><font face='Tahoma' size='2'>�������稡���֡��</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$end1&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$end2&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$end3&nbsp;</font></div>
                </td>
                <td width='20%'> 
                  <div align='center'><font face='Tahoma' size='2'>$end4&nbsp;</font></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>13. 
            ʶҹ������</b></font><b><font face='Tahoma' size='2'>�ػ�ó����͹</font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'>&nbsp;</td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'> 
            <b>13.1 ʶҹ��� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'>&nbsp;</td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'>$place&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'>&nbsp;</td>
          <td width='503' bgcolor='#DAEEFE'><font face='Tahoma' size='2'><b>13.2 �ػ�ó����͹ </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='27'>&nbsp;</td>
          <td width='503' bgcolor='#DAEEFE' height='27'><font face='Tahoma' size='2'>$tool&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
          <div align="center"><font face="Tahoma" size="1">Department of Computer 
            Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
            Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
            �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
          <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
