<html>
<head>
<title>�ç���ҧ��ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
  echo "
	<tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#DAEEFE' >&nbsp;</td>
    <td width='134' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce.php?course_year=$course_year'>��ѡ�ٵû�ԭ���</a></font> 
      <font face='Tahoma' size='2' color='#9900CC'><br>
      �ç���ҧ��ѡ�ٵ�<br>
      <a href='tendency.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a></font><br>
    <font color='#9900CC' face='Tahoma' size='2'><a href='?course_year=$course_year'>��������´�Ԫ����¹</a> 
    <br>
      <a href='index.php'>��Ѻ˹����ѡ </a>
    <br>&nbsp;    </font></td>
    <td width='619' valign='top' >
	<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
        <tr> 
          <td height='54' colspan='11' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵ���Һѳ�Ե 
              �Ң��Ԫ����ǡ������������� <br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp; </font></div>
          </td>
        </tr>";

// select data from all table by course_year
$query = "Select * From $Structuretable Where Course_year = '$course_year' ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$program1_unit = htmlspecialchars($row[Program1_unit]);
	$program2_unit = htmlspecialchars($row[Program2_unit]);
	$detail = $row[Detail];
	//$detail = eregi_replace('<br>',chr(13),$row[Detail]);
echo "
        <tr> 
          <td height='29' colspan='11' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>14. 
            ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td width='33' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
          <td colspan='9'  bgcolor='#F7F7F7' height='29'> 
            <div > 
              <font face='Tahoma' size='2'>$detail</font></div>
          </td>
          <td bgcolor='#F7F7F7' width='27'><font face='Tahoma' size='2'></font></td>
        </tr>
        <tr> 
          <td height='22' colspan='11' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>14.1 
            �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font><font size='2' face='Tahoma'></font></td>
        </tr>
        <tr> 
          <td height='11' width='33' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
          <td height='11' width='169' bgcolor='#F7F7F7'><font size='2' face='Tahoma'>- 
            ���������֡�ҷ�� 1</font></td>
          <td height='11' colspan='4' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma'> $program1_unit &nbsp; ˹��¡Ե</font></div>
          </td>
          <td height='11' colspan='5' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
        </tr>
        <tr> 
          <td height='6' bgcolor='#F7F7F7' width='33'><font size='2' face='Tahoma'></font></td>
          <td height='6' bgcolor='#F7F7F7' width='169'><font size='2' face='Tahoma'>- 
            ���������֡�ҷ�� 2</font></td>
          <td height='6' bgcolor='#F7F7F7' colspan='4'> 
            <div align='center'><font size='2' face='Tahoma'> $program2_unit &nbsp; ˹��¡Ե</font></div>
          </td>
          <td height='6' bgcolor='#F7F7F7' colspan='5'><font size='2' face='Tahoma'></font></font></td>
        </tr>
        <tr> 
          <td height='18' bgcolor='#F7F7F7' colspan='11'><font size='2' face='Tahoma'><b>14.2 
            �ç���ҧ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td height='46' colspan='2' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2'><font face='Tahoma'></font></font></div>
          </td>
          <td height='46' bgcolor='#DAEEFE' colspan='4'> 
            <div align='center'><font size='2' face='Tahoma'>���������֡�ҷ�� 
              1 </font></div>
          </td>
          <td height='46' bgcolor='#DAEEFE' colspan='5'> 
            <div align='center'><font size='2' face='Tahoma'>���������֡�ҷ�� 
              2 </font></div>
          </td>
        </tr>";
	// select data from category 
	$query_category = "Select * From $Categorytable Where Course_year = '$course_year' ";
	$result_category = mysql_query($query_category);
	$cnumber = mysql_numrows($result_category);
	$ci=0;
	if ($ci < $cnumber) {
	while ($row = mysql_fetch_array($result_category))
		{
	$category = htmlspecialchars($row[Category]);
	$cprogram1_unit = htmlspecialchars($row[Cprogram1_unit]);
	$cprogram2_unit = htmlspecialchars($row[Cprogram2_unit]);
		echo "<tr> 
          <td height='28' colspan='2' bgcolor='#F7F7F7'> <font size='2' face='Tahoma'><b>&nbsp;$category</b></font></td>
          <td height='28' width='37' bgcolor='#F7F7F7'> <font size='2' face='Tahoma'></font></td>
          <td height='28' width='40' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma'> <b>$cprogram1_unit</b></font></div>
          </td>
          <td height='28' width='74' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma'> <b>˹��¡Ե</b> </font></div>
          </td>
          <td height='28' width='38' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td height='28' width='35' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2'><font face='Tahoma'></font></font></div>
          </td>
          <td height='28' width='41' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma'><b>$cprogram2_unit</b></font></div>
          </td>
          <td height='28' width='78' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma'><b>˹��¡Ե</b> </font></div>
          </td>
          <td height='28' bgcolor='#F7F7F7' colspan='2'><font face='Tahoma' size='2'></font></td>
        </tr>";
// select data from Gsubject table
	$query_group = "Select * From $Gsubjecttable Where Course_year = '$course_year' AND Category = '$category' ";
	$result_group = mysql_query($query_group);
	$gnumber = mysql_numrows($result_group);
	$gi=0;
	if ($gi < $gnumber) {
	while ($row = mysql_fetch_array($result_group))
		{
	$category = htmlspecialchars($row[Category]);
	$gsubject = htmlspecialchars($row[Gsubject]);
	$gprogram1_unit = htmlspecialchars($row[Gprogram1_unit]);
	$gprogram2_unit = htmlspecialchars($row[Gprogram2_unit]);
	echo "
        <tr> 
          <td height='36' width='33' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2'><font face='Tahoma'></font></font></div>
          </td>
          <td height='36' width='169' bgcolor='#F7F7F7'> 
            <div align='left'><font face='Tahoma' size='2'><A HREF='Show_group.php?gsubject=$gsubject&&course_year=$course_year&&category=$category'> $gsubject</A></font></div>
          </td>
          <td height='36' bgcolor='#DAEEFE' width='37'> <font size='2' face='Tahoma'></font></td>
          <td height='36' bgcolor='#DAEEFE' width='40'> 
            <div align='center'><font size='2' face='Tahoma'> $gprogram1_unit</font></div>
          </td>
          <td height='36' bgcolor='#DAEEFE' width='74'> 
            <div align='center'><font size='2' face='Tahoma'> ˹��¡Ե </font></div>
          </td>
          <td height='36' bgcolor='#DAEEFE' width='38'><font face='Tahoma' size='2'></font></td>
          <td height='36' width='35' bgcolor='#DAEEFE'> 
            <div align='center'><font size='2'><font face='Tahoma'></font></font></div>
          </td>
          <td height='36' width='41' bgcolor='#DAEEFE'> 
            <div align='center'><font size='2' face='Tahoma'> $gprogram2_unit</font></div>
          </td>
          <td height='36' width='78' bgcolor='#DAEEFE'> 
            <div align='center'><font size='2' face='Tahoma'> ˹��¡Ե </font></div>
          </td>
          <td height='36' bgcolor='#DAEEFE' colspan='2'><font face='Tahoma' size='2'></font></td>
        </tr>";
		}
	}
		}
	}
        echo "
		<tr> 
          <td height='28' bgcolor='#F7F7F7' width='33'><font face='Tahoma' size='2'></font></td>
          <td height='28' bgcolor='#F7F7F7' width='169'> 
            <div align='center'><font face='Tahoma' size='2'><b>��ʹ��ѡ�ٵ�</b></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' width='37'><font face='Tahoma' size='2'></font></td>
          <td height='28' bgcolor='#DAEEFE' width='40'> 
            <div align='center'><font face='Tahoma' size='2'><b> $program1_unit</b></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' width='74'> 
            <div align='center'><font face='Tahoma' size='2'><b>˹��¡Ե</b></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' width='38'> 
            <div align='center'><font size='2'><font face='Tahoma'></font></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' width='35'> 
            <div align='center'><font size='2'><font face='Tahoma'></font></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' width='41'> 
            <div align='center'><font face='Tahoma' size='2'><b> $program2_unit</b></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' width='78'> 
            <div align='center'><font face='Tahoma' size='2'><b>˹��¡Ե</b></font></div>
          </td>
          <td height='28' bgcolor='#DAEEFE' colspan='2'><font face='Tahoma' size='2'></font></td>
        </tr>
      </table>";
		}
	   	}
		else { 
	 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>����բ������ç���ҧ��ѡ�ٵ�</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			}
	mysql_free_result($result);
	MYSQL_CLOSE();
?>
	</td>
	</tr>
	</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
