var aTags = new Array(4);
var bHasQuad;
var oBody;
window.onload = fnLoad;

function fnLoad()
{
	for(var i=0; i<aCats.length; i++)
	{
		aTags[i] = document.getElementById("c" + aCats[i]);
	}
	bHasQuad = (aTags[0] && aTags[1] && aTags[2] && aTags[3])

	oBody = document.getElementById("oBodyTag");
	oBody.onresize = fnResize;
	fnResize();
	fnSetHeight();
}

function fnResize()
{
	var sNew = "640";
	var sOld = oBody.className;
	var iWide = oBody.clientWidth;
	if (iWide >= 772) {sNew = "800";}
	if (sNew !== sOld) {oBody.className = sNew; fnSetHeight();}
}

function fnSetHeight()
{
	if (bHasQuad)
	{
		if (oBody.className == "800")
		{
			var iTop = Math.max(aTags[0].clientHeight, aTags[1].clientHeight);
			var iBot = Math.max(aTags[2].clientHeight, aTags[3].clientHeight);
			aTags[0].style.height = iTop + "px";
			aTags[1].style.height = (iTop + 1) + "px";
			aTags[2].style.height = iBot + "px";
			aTags[3].style.height = (iBot + 1) + "px";
		}
		else
		{
			aTags[0].style.height = "auto";
			aTags[1].style.height = "auto";
			aTags[2].style.height = "auto";
			aTags[3].style.height = "auto";
		}
	}
}