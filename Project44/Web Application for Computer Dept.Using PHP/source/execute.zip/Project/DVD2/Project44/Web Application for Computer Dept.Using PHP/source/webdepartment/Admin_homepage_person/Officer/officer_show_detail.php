<?
			session_start();
?>
<html>
<head>
<title>�ʴ����������˹�ҷ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;���ྨ���˹�ҷ��</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
  <tr>
    <td width="11" >&nbsp;</td>
    <td width="14" bgcolor="#D2F8FD" >&nbsp;</td>
    <td width="134" bgcolor="#D2F8FD" valign="top" ><font face="Tahoma, Microsoft Sans Serif" size="2" color="#9900CC"><br>
      </font><font face="Tahoma, Microsoft Sans Serif" size="2" color="#9900CC"><a href="officer_insert.php">�������������˹�ҷ��</a><br>
      <a href="officer_show_update.php">��䢢��������˹�ҷ��</a><br>
      <a href="officer_show_delete.php">ź���������˹�ҷ��</a><br>
      �ʴ����������˹�ҷ��<br>
       <a href="officer_show.php">��Ѻ˹����ѡ </a></font>
      <br>
      </td>
    <td width="619" valign="top"> 
<?	
if ($user[1] == 'administrator' )
{
		include ("connect_officer.inc.php");
}
		  		$query_select = "Select * From $Officertable Where ID = '$id' AND Status = '$user[5]' ";
					$result_select = mysql_query($query_select);
					$snumber = mysql_numrows($result_select);
					$si=0;
						if ($si < $snumber)
						{
							while ($row = mysql_fetch_array($result_select))
								{
								   $show_order = $row[Show_order];
								$id = htmlspecialchars($row[ID]);
								$last_update = htmlspecialchars($row[Last_update]);
								$picture = htmlspecialchars($row[Picture]);
								$user_name = htmlspecialchars($row[Username]);
								$name = htmlspecialchars($row[Name]);
								$email = htmlspecialchars($row[Email]);
								$level = htmlspecialchars($row[Level]);
								$tlink = htmlspecialchars($row[Tlink]);
								$telephone = htmlspecialchars($row[Telephone]);
								$graduation = $row[Graduation];
								$address = $row[Address];
										}
						}

		echo "
		<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
  <tr valign='middle' bgcolor='#F7F7F7'> 
    <td colspan='3' height='35' > 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�����Ţͧ���˹�ҷ���Ш��Ҥ�Ԫ����ǡ�������������</font></div>
    </td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;�ӴѺ���</font></div>
    </td>
    <td width='282' bgcolor='#D2F8FD' height='25'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
      $show_order </font></td>
    <td rowspan='5' bgcolor='#D2F8FD' height='80' width='164'> 
      <div align='center'><img src='Picture_officer_$id/$picture' width='130' align='middle'></div>
    </td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;��䢤����ش����</font></div>
    </td>
    <td width='282' bgcolor='#D2F8FD' height='25'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
      $last_update </font> </td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;������͡�Թ&nbsp;</font></div>
    </td>
    <td width='282' bgcolor='#D2F8FD' height='25'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
      $user_name </font> </td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='28'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;����-���ʡ��</font></div>
    </td>
    <td width='282' bgcolor='#D2F8FD' height='28'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
      $name</font></td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'>
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;Email-Address</font></div>
    </td>
    <td width='282' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
      <a href='mailto:$email'> $email </a></font></td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;���˹�/˹�ҷ��</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='25' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
      $level </font></td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;�س�ز� 
        �Ң��Ԫ� ʶҹ����֡��</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='25' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
      $graduation </font></td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif'><font face='Tahoma, Microsoft Sans Serif'><font size='2'>�������Ѿ��</font></font></font></div>
    </td>
    <td bgcolor='#D2F8FD' height='25' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
      $telephone </font></td>
  </tr>
  <tr> 
    <td width='146' bgcolor='#F7F7F7' height='25'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�������Ե��</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='25' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
      $address </font></td>
  </tr>
          <tr> 
            <td width='146' bgcolor='#F7F7F7' height='25'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�ԧ����ǹ���</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='25' colspan='2'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; ";
            $link = explode(",",$tlink);
								$co = strlen($link);
								for($l = 0;$l<=$co;$l++)
							{
									if ($l == 0)
								{
										echo "<A HREF='http://$link[$l]'>$link[$l]</A>";
								}
								else
									if ($link [ $l] != '')
								{
									   echo ",<A HREF='http://$link[$l]'>$link[$l]</A>";
								}
							}
		echo "
			</font>
			</td>
          </tr>
        <tr> 
            <td colspan='3' bgcolor='#F7F7F7' height='25'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'></font><font face='Tahoma, Microsoft Sans Serif' size='2'> 
                &nbsp; </font></div>
            </td>
          </tr></table>";
?>
    </td>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>


