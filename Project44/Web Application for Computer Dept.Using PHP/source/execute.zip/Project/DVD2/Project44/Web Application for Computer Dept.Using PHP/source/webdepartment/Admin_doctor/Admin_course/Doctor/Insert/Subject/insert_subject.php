<html>
<head>
<title>��������������Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>
<script type="text/javascript" language="JavaScript"> id = new Array();desc = new Array();sename = new Array();credit = new Array();
<?
include ("connect_course.inc.php");

$query_delete_temp = "DELETE FROM $Temptable ";
$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);

$query = "Select * From $Subjecttable Where Course_year= '$course_year' ";
$result = mysql_query($query);
$number = mysql_numrows($result);
		$co = 0;
	while ($co < $number) 
		{
	$row = mysql_fetch_array($result);
	$tcode = htmlspecialchars($row[Code]);
	$tname = htmlspecialchars($row[Name]);
	$tename = htmlspecialchars($row[Ename]);
	$tunit = htmlspecialchars($row[Unit]);
	print "id[".$co.']="'.$tcode.'"; desc['.$co.']="'.$tname.'"; sename['.$co.']="'.$tename.'"; credit['.$co."]=$tunit;"; 
	$co++;
	}
	mysql_free_result($result);
	MYSQL_CLOSE();
	$co++;
print 'minCredit=1;' ;
print 'maxCredit=30; max = '.$co.'; pop = 0;';
print 'function isBlank(s) { var len = s.length; for (var i = 0; i < len; i++)';
print '{ if (s.charAt(i) != " ") return false; } return true; }';
print 'function checkSubject(code) { for (var i = 0; i < '.$co.'; i++) ';
?>
{ if (code == id[i]) { return i } } return -1 }
				function checkdetail(index)
 { if (isBlank(document.a.elements[index].value) ) 
	{ return true; }
				var sect = document.a.elements[index +3].value;
 if (isBlank(sect) ) { document.a.elements[index +3].value = "01"; return true; }
				var s = new Number(sect.valueOf() ); var c = checkSubject(document.a.elements[index].value);
 if ( (s > detail[c].valueOf() ) || (s == 0) ) 
	 { alert("Invalid detail " + sect + " �����Ԫ� " + document.a.elements[index].value); return false;  }
 if (s < 10) {
	' document.a.elements[index +3].value =  "0" + s.toString();'
	 document.a.elements[index +3].value =  "" + s.toString();
					}
		 else  {
	document.a.elements[index +3].value =  s.toString();
					} return true; }
function validateForm()
	{  'start function'
		var totalCredit=0; for (var j = 0; j < 51; j += 5) { var index=validate(j);
 if (index==-1 || !checkdetail(j) ) { return; }
 if (index!=-2) { totalCredit += credit[index] }; }
 if (totalCredit > maxCredit) { alert("ŧ����¹������Թ " + maxCredit + " ˹��¡Ե ���͵Դ��ͷ���¹��� / �ӹѡ����¹�"); return; } 
if (totalCredit < minCredit) { alert("ŧ����¹��ͧ����ӡ��� " + minCredit + " ˹��¡Ե ���͵Դ��ͷ���¹��� / �ӹѡ����¹�"); return; } document.a.submit();
 if (pop > 0) { subjectLizst.close(); } }
function validate(j) {var code = document.a.elements[j].value; 
if (isBlank(code) )
	{' document.a.elements[j + 1].value = "";'
	  'document.a.elements[j + 2].value = "";'
	  'document.a.elements[j + 3].value = "";'
return -2; } 
		index = checkSubject(code); 
if (index == -1)
	{ alert("��辺�����Ţͧ�����Ԫ�" + code); document.a.elements[j].focus(); return -1; } 
else { 
	document.a.elements[j + 1].value = desc[index] ;
	document.a.elements[j + 2].value = credit[index] ;
	document.a.elements[j + 3].value = sename[index] ; 
	'document.a.elements[j + 4].value = operation[index] ;'
	return index;
		} 
	} 'end function'
function init() 
{ 

 } 
</script>
</HEAD>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
<body bgcolor="#FFFFFF">

<form name="a" action="insert.php"  method="post" target ='_parent'>
<script language="javascript" >
function Brand(tSystem,tBrand,nn)
{
     this.System=tSystem;
     this.Brand=tBrand;
	 this.apid=nn;
}
function Model(tId,tModel,tSystem,tBrand){
     this.ID=tId;
     this.Model=tModel;
     this.System=tSystem;
     this.Brand=tBrand;
}
function getBrands()
{
  var sSelect="<select name='gsubject' class='input200'><option value='' selected></option>";
  var obj0=document.a.category;
  var iSystem=obj0.options[obj0.selectedIndex].value;
   for (var x=1;x<aBrands.length;x++)
    {
           if (aBrands[x].System==iSystem)
           {
                 sSelect=sSelect+"<option value='"+aBrands[x].apid+"'>"+aBrands[x].Brand+"</option>";
           }
     }
    sSelect=sSelect+"</select>";
    document.all.Brands.innerHTML=sSelect;
	
}
var aBrands=new Array();
	<?
include ("connect_course.inc.php");
	$query_category = "Select Distinct Category From $Categorytable Where Course_year = '$course_year' ";
		$result_category = mysql_query($query_category); 
        $number_category = mysql_numrows($result_category);
		$i_category = 0; 
		$c = 2;						
		$g = 2;
		$temp[1] = "�����";
		print "aBrands[1] = new  Brand('�����','�����','�����');";
		if ($i_category < $number_category)
		{
			while ($row  = mysql_fetch_array($result_category)) 
			{
			$cate = htmlspecialchars($row[Category]); 
			$temp[$c] = $cate;
			$c++;
					$query_gsubject = "Select  Distinct Gsubject From $Gsubjecttable Where Course_year = '$course_year' AND Category = '$cate' ";
					$result_gsubject = mysql_query($query_gsubject); 
					$number_gsubject = mysql_numrows($result_gsubject);
					$i_gsubject=0; 
					if ($i_gsubject < $number_gsubject)
					{
						while ($row  = mysql_fetch_array($result_gsubject)) 
						{
						$gsub = htmlspecialchars($row[Gsubject]); 
						print "aBrands[".$g."] = new  Brand('".$cate."','".$gsub."','".$gsub."'".');';
						$g++;
						}
					}
			}  
        }

?>	
function fsubmit(){
if ((a.category.value!="")&&(a.gsubject.value!="")&&(a.name.value!="")&&(a.add.value!="")&&(a.reg.value!="")&&(a.email.value!="")){
a.submit()
}else{
alert("��سҡ�͡���������ú")
}
}
</script>

<script type="text/javascript" language="JavaScript">init()</script>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
<?
	echo "
      <tr>
      <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='../../../introduce_insert.php'>��ѡ�ٵû�ԭ���͡</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='../../../structure_insert_course.php'>�ç���ҧ��ѡ�ٵ�</a><br>
	  	  	   <a href='../../../structure_insert_main_subject.php'>�����Ԫ���ѡ����</a><br>
	  <a href='../../../select_course_category.php'>������Ǵ�Ԫ�����</a><br>
      <a href='../../../select_course_group.php'>�����Ң��Ԫ����� </a><br>
		��������Ԫ����� <br>
      <a href='../Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a>
	 </font> <font size='2' face='Tahoma'><br>
      <a href='../../../index.php'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;
      </td>
    <td width='619' valign='top' >
	    <table width='608' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='right'>
          <tr> 
            <td colspan='7' height='48' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ�������������</font> 
                <font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ�$course_year<br>
                ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> <br>
                &nbsp; </div>
            </td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font face='Tahoma' size='2'>��͵�ŧ</font></div>
            </td>
            <td bgcolor='#EAEAFF' colspan='6' height='30'><font size='2' face='Tahoma' color='#FF0000'> 
              &nbsp;*</font><font size='2' face='Tahoma'> ���¶֧ �����ҧ��,<font color='#FF0000'>** 
              </font>���¶֧ ���������ҧ,<font color='#FF0000'>***</font> ���¶֧ 
              �������բ�����������͡</font></td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font face='Tahoma' size='2'>�Ԫ���ѡ</font></div>
            </td>
            <td colspan='3' height='30'> 
              <div align='center'> 
                <select name='msubject'>
				<option value='�����'>�����</option>";
		$query = "Select * From $Msubjecttable Where Course_year = '$course_year'";
		$result = mysql_query($query); 
        $number = mysql_numrows($result);
		$i =0 ; 
		if ($i < $number)
		{
			while ($row  = mysql_fetch_array($result)) 
			{
			$msubject = htmlspecialchars($row[Msubject]); 
			echo "<option value='$msubject'>$msubject</option>";
			}
		}
		echo "
                </select>
              </div>
            </td>
            <td colspan='3' height='30'>&nbsp;	</td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>��Ǵ�Ԫ�</font></div>
            </td>
            <td colspan='3' height='30'><font size='2' face='Tahoma'></font> 
              <div align='center'>
                <select name='category' onChange='getBrands();' class='input200' >
                  <option selected value=''></option>";
				for ($n=1;$n<$c;$n++)
				{
            echo "
                  <option  value='$temp[$n]' ><span id='c_country' name='c_country'>$temp[$n]</span></option>";
				}
			echo"
                  </select></div>
            </td>
            <td colspan='3' height='30'> 
              <div align='center'><font size='2'><font size='2'></font></font></div>
              <div align='center'><font face='Tahoma' size='2'>  </font></div>
            </td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>�Ң��Ԫ�</font></font></font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='3' height='30'> 
              <div align='center'><font face='Tahoma' size='2'><span id='Brands' name='Brands'> 
                <select name='gsubject' class='input200'>
                  <option value='' selected></option>
                </select>
                </span></font></div>
            </td>
            <td colspan='3' height='30'>&nbsp;</td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>�����Ԫ�</font></div>
            </td>
            <td colspan='6' height='30'><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='1' face='MS Sans Serif' color='#FFFFFF'> 
              &nbsp;<font face='Tahoma'> 
              <input type='text' name='code' size='8' maxlength='8'>
              </font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'>**</font></font><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>�����Ԫ�������</font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29'><font size='1' face='Tahoma' color='#FFFFFF'> 
              &nbsp; 
              <input type='text' name='name' size='40'>
              <font color='#FF0000'>**</font></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>�����Ԫ������ѧ���</font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29'><font face='MS Sans Serif' size='1' color='#FFFFFF'> 
              <font face='Tahoma'>&nbsp; 
              <input type='text' name='ename' size='40'>
              </font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'>*</font></font><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>˹��¡Ե</font></div>
            </td>
            <td bgcolor='#F7F7F7' width='42' height='29'><font size='1' face='Tahoma'>&nbsp; 
              <input type='text' name='unit' size='3' maxlength='3'>
              </font> </td>
            <td bgcolor='#EAEAFF' width='75' height='29'> 
              <div align='center'><font face='Tahoma' size='2'>������</font></div>
            </td>
            <td bgcolor='#F7F7F7' width='42' height='29'><font size='1' face='Tahoma'>&nbsp; 
              <input type='text' name='unit_detail' size='3' maxlength='3'>
              </font> </td>
            <td bgcolor='#EAEAFF' width='75' height='29'> 
              <div align='center'><font size='2' face='Tahoma'>��Ժѵ�</font></div>
            </td>
            <td bgcolor='#F7F7F7' width='42' height='29'><font size='1' face='Tahoma'>&nbsp; 
              <input type='text' name='unit_operation' size='3' maxlength='3'>
              </font> </td>
            <td bgcolor='#F7F7F7' width='186' height='29'><font size='1' face='MS Sans Serif' color='#FFFFFF'><font color='#FF0000' face='Tahoma'>**</font></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>URL Link </font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29'><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font face='MS Sans Serif' color='#FF0000'><font size='1'><font size='1'> 
              &nbsp;<font face='Tahoma'> 
              <input type='text' name='url' size='40'>
              </font></font></font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'>***</font></font><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font face='Tahoma' size='2'>�����ԪҺѧ�Ѻ��͹</font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29'><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font face='MS Sans Serif' color='#FF0000'><font size='1'><font size='1'> 
              &nbsp;<font face='Tahoma'> 
              <input type='text' name='code_subject_to' onChange='validate(9)' size='8' maxlength='8'>
              </font></font></font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'>***</font></font><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font face='Tahoma' size='2'>�����ԪҺѧ�Ѻ��͹������</font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29'><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font face='MS Sans Serif' size='1' color='#FF0000'> 
              &nbsp;<font face='Tahoma'> 
              <input type='text' name='name_subject_to' readonly size='40'>
              </font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'></font></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>�����ԪҺѧ�Ѻ��͹�����ѧ���</font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29'><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font size='2' face='Tahoma'></font><font face='MS Sans Serif' size='1' color='#FF0000'> 
              &nbsp;<font face='Tahoma'> 
              <input type='hidden' name='no_use' readonly size='40'>
              <input type='text' name='ename_subject_to' readonly size='40'>
              </font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'></font></font></td>
          </tr>
          <tr> 
            <td bgcolor='#EAEAFF' width='199' height='30'> 
              <div align='center'><font size='2' face='Tahoma'>����������Ԫ�</font></div>
            </td>
            <td bgcolor='#F7F7F7' colspan='6' height='29' valign='top'><font size='1' face='MS Sans Serif' color='#FF0000'> 
              &nbsp;<font face='Tahoma'> 
              <textarea name='subject_detail' cols='70' rows='5'></textarea>
              </font></font><font size='1' face='Tahoma' color='#FFFFFF'><font color='#FF0000'>*</font></font><font size='1' face='Tahoma' color='#FF0000'> 
              </font><font size='2' face='Tahoma'></font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' colspan='7' height='29'><font size='2' face='Tahoma'></font> 
              <div align='center'> 
                <input type='submit' name='Submit' value='��������Ԫ�'>
                <input type='reset' name='Cancel' value='¡��ԡ������'>
              </div>
            </td>
          </tr>
          <input type='hidden' name='course_year' value='$course_year'>
        </table>
        ";
	?>
	</td>
  </tr>
  
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</form>
</body>
</html>
