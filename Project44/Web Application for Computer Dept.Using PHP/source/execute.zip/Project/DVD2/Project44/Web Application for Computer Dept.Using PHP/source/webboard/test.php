<?php
	$a="adda<br>dadasd";
	if(ereg("<br>",$a)){
		print "adsadyes$a";
	}else{
		print "no$a";
	}
?>