<html>
<head>
<title>�ç���ҧ��ѡ�ٵ�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="../script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="772" border="0" cellspacing="0" cellpadding="0" align="center">
<?
include ("connect_course.inc.php");
echo "
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='130' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='index.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font><br>
      <font face='Tahoma, Microsoft Sans Serif' size='2'> �ç���ҧ��ѡ�ٵ�</font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='tendency.php?course_year=$course_year'>Ἱ����֡��</a><br>
      <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
      &nbsp;</td>
    <td width='10' valign='top' >&nbsp; </td>
    <td width='609' valign='top' > 
      <table width='100%' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
        <tr> 
          <td height='54' colspan='11' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵ��ѳ�Ե 
              �Ң��Ԫ����ǡ������������� <br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp; </font></div>
          </td>
        </tr>";
// select data from all table by course_year
$query = "Select * From $Structuretable Where Course_year = '$course_year' ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$program1_unit = htmlspecialchars($row[Program1_unit]);
	$program2_unit = htmlspecialchars($row[Program2_unit]);
	$detail = $row[Detail];
	//$detail = eregi_replace('<br>',chr(13),$row[Detail]);
echo "
        <tr> 
          <td height='27' colspan='11' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14. 
            ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td width='33' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
          <td colspan='9'  bgcolor='#D2F8FD' height='29'> 
            <div > 
              <font face='Tahoma, Microsoft Sans Serif' size='2'>$detail</font></div>
          </td>
          <td bgcolor='#F7F7F7' width='27'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
        </tr>
        <tr> 
          <td height='22' colspan='11' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14.1 
            �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
        </tr>
        <tr> 
          <td height='11' width='33' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
          <td height='11' width='169' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'>- 
            ���������֡�ҷ�� 1</font></td>
          <td height='11' colspan='4' bgcolor='#D2F8FD'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> $program1_unit &nbsp; ˹��¡Ե</font></div>
          </td>
          <td height='11' colspan='5' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
        </tr>
        <tr> 
          <td height='6' bgcolor='#F7F7F7' width='33'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
          <td height='6' bgcolor='#F7F7F7' width='169'><font size='2' face='Tahoma, Microsoft Sans Serif'>- 
            ���������֡�ҷ�� 2</font></td>
          <td height='6' bgcolor='#D2F8FD' colspan='4'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> $program2_unit &nbsp; ˹��¡Ե</font></div>
          </td>
          <td height='6' bgcolor='#F7F7F7' colspan='5'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></font></td>
        </tr>
        <tr> 
          <td height='18' bgcolor='#F7F7F7' colspan='11'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14.2 
            �ç���ҧ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td height='27' colspan='2' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></div>
          </td>
          <td height='27' bgcolor='#D2F8FD' colspan='4'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���������֡�ҷ�� 
              1 </font></div>
          </td>
          <td height='27' bgcolor='#D2F8FD' colspan='5'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���������֡�ҷ�� 
              2 </font></div>
          </td>
        </tr>";
	// select data from category 
	$query_category = "Select * From $Categorytable Where Course_year = '$course_year' ";
	$result_category = mysql_query($query_category);
	$cnumber = mysql_numrows($result_category);
	$ci=0;
	if ($ci < $cnumber) {
	while ($row = mysql_fetch_array($result_category))
		{
	$category = htmlspecialchars($row[Category]);
	$cprogram1_unit = htmlspecialchars($row[Cprogram1_unit]);
	$cprogram2_unit = htmlspecialchars($row[Cprogram2_unit]);
		echo "  
			<tr> 
          <td height='25' colspan='2' bgcolor='#F7F7F7'> <font size='2' face='Tahoma, Microsoft Sans Serif'><b>&nbsp;$category</b></font></td>
          <td height='25' width='37' bgcolor='#F7F7F7'> <font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
          <td height='25' width='40' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> <b>$cprogram1_unit</b></font></div>
          </td>
          <td height='25' width='74' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> <b>˹��¡Ե</b> 
              </font></div>
          </td>
          <td height='25' width='38' bgcolor='#F7F7F7'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td height='25' width='35' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></div>
          </td>
          <td height='25' width='41' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>$cprogram2_unit</b></font></div>
          </td>
          <td height='25' width='78' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>˹��¡Ե</b> </font></div>
          </td>
          <td height='25' bgcolor='#F7F7F7' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
        </tr>";
// select data from Gsubject table
	$query_group = "Select * From $Gsubjecttable Where Course_year = '$course_year' AND Category = '$category' ";
	$result_group = mysql_query($query_group);
	$gnumber = mysql_numrows($result_group);
	$gi=0;
	if ($gi < $gnumber) {
	while ($row = mysql_fetch_array($result_group))
		{
	$category = htmlspecialchars($row[Category]);
	$gsubject = htmlspecialchars($row[Gsubject]);
	$gprogram1_unit = htmlspecialchars($row[Gprogram1_unit]);
	$gprogram2_unit = htmlspecialchars($row[Gprogram2_unit]);
	echo "
         <tr> 
          <td height='25' width='33' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></div>
          </td>
          <td height='25' width='169' bgcolor='#F7F7F7'> 
            <div align='left'><font face='Tahoma, Microsoft Sans Serif' size='2'><A HREF='show_group.php?gsubject=$gsubject&&course_year=$course_year&&category=$category'> 
              $gsubject</A></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='37'> <font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
          <td height='25' bgcolor='#D2F8FD' width='40'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> $gprogram1_unit</font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='74'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> ˹��¡Ե </font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='38'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td height='25' width='35' bgcolor='#D2F8FD'> 
            <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></div>
          </td>
          <td height='25' width='41' bgcolor='#D2F8FD'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> $gprogram2_unit</font></div>
          </td>
          <td height='25' width='78' bgcolor='#D2F8FD'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'> ˹��¡Ե </font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
        </tr>";
		}
	}
		}
	}
        echo "
		<tr> 
          <td height='25' bgcolor='#F7F7F7' width='33'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td height='25' bgcolor='#F7F7F7' width='169'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>��ʹ��ѡ�ٵ�</b></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='37'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td height='25' bgcolor='#D2F8FD' width='40'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b> $program1_unit</b></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='74'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>˹��¡Ե</b></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='38'> 
            <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='35'> 
            <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='41'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b> $program2_unit</b></font></div>
          </td>
          <td height='25' bgcolor='#D2F8FD' width='78'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>˹��¡Ե</b></font></div>
          </td>
          <td height='28' bgcolor='#D2F8FD' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
        </tr>
      </table>";
		}
	   	}
		else { 
	 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma, Microsoft Sans Serif'>����բ������ç���ҧ��ѡ�ٵ�</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			}
	mysql_free_result($result);
	MYSQL_CLOSE();
?>
	</td>
	</tr>
	</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
