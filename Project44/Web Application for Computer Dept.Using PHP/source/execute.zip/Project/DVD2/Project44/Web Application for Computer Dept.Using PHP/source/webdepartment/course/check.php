<?
	session_start();
	session_unset();
include ("connect_admin.inc.php");
function no_auth_msg() 
	{
   global $PHP_SELF;
   $page = basename($PHP_SELF);

   echo "<h1>401 Authorization Required</h1>";
   echo "This server could not verify that you are authorized to access the document requested. ";
   echo "Either you supplied the wrong credentials (e.g., bad password), or your browser doesn't ";
   echo "understand how to supply the credentials required. Please ";
   echo "<a href=\"loginadmin/$page\">";
   echo "click here</a> to try again.";
}

function authenticate()
{
   Header("WWW-Authenticate: Basic realm=\"Administrator Area\",strftime('%c',time())");
   Header("HTTP/1.0 401 Unauthorized");
   no_auth_msg();
   exit;
}

if (isset($PHP_AUTH_USER))
{
	$user_name = $PHP_AUTH_USER;
	$passwd = $PHP_AUTH_PW;
		$query = "Select Status,Name,Email From $Admintable Where  Username = '$user_name' AND Password = '$passwd' "; 
		$result = mysql_query($query);
		$number = mysql_numrows($result);
		if ($number > 0)
		{
				$row = mysql_fetch_array($result); 
				$status = htmlspecialchars($row[Status]);
				$id = htmlspecialchars($row[ID]);
				$name = htmlspecialchars($row[Name]);
				$email = htmlspecialchars($row[Email]);
		 }
		if ($number == 0)
		 {
				      // User is not valid
				authenticate();
		}
		 if ($status == 'administrator' )
			{
					$user = array($id,$status,$name,$email);
					session_register(user);
			}
	 	if ($user[1] == 'administrator' )
			{
					  header("Location: ../index.php");
			}
}
else 
{
      // User is not valid
	  authenticate();
}
?>

