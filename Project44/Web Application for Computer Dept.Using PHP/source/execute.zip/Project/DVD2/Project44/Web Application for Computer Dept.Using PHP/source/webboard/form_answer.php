<?php
	session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
   <?php
	include("webboard.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql = "select * from question where q_id = '$q_id'";
	$db_query = mysql_db_query ($dbname, $sql);
	$nums_rows = mysql_num_rows($db_query);
	if ($nums_rows < 1 )
		{
			echo ("<font color=\"red\">����բ������ʴ�</font>");
			exit;
		}	// �� if
?>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="770" border="0" cellpadding="0" cellspacing="0">
          <tr> 
            <td> </td>
          </tr>
          <tr> 
            <td> 
              <?php
	for ($i=0;$i<$nums_rows;$i++){
			$result = mysql_fetch_array($db_query);
			$q_id = $result[q_id];
			$q_topic = $result[q_topic];
			$q_message = $result[q_message];
			$q_name = $result[q_name];
			$q_email = $result[q_email];
			$q_icq = $result[q_icq];
			$q_ip = $result[q_ip];
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];

			$q_id = stripslashes($q_id);
			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);
			$q_date = stripslashes($q_date);
			$q_update = stripslashes($q_update);
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];
}

	print "<table border=0  width=100% cellspacing=1 cellpadding=4   align=center>";
	print "<tr>";
	print "<td bgcolor=$bgt4 width=20%><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Author</font></td>";
	print "<td bgcolor=$bgt4><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></td>";
	print "</tr>";
	
	print "<tr>";
	print "<td bgcolor=$bgt1 width=20% valign='top'>";
	print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
    print "<tr><td>";
	if ($q_email==""){
		print "<img src='image/mail.gif' width='33' height='11' border='0'>";
	}else{
		print "<a href='mailto:$q_email'><img src='image/mail.gif' width='33' height='11' border='0'></a>";
	}
	print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>$q_name</b></font>";
    print "</td></tr><tr>";
    print " <td>&nbsp;</td>";
    print "</tr></table>";
	print "</td>";
	print "<td bgcolor=$bgt1>";
	print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
    print "<tr><td>";
	print "<IMG SRC=$post align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Posted: $q_date:$q_time</font><hr>";
    print "</td></tr><tr>";
    print " <td>";
	print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_message</font></td></tr><tr><td align='right'>";
	print "<IMG SRC=$ip align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> $q_ip</font>";
    print "</td></tr></table>";
	print "</td>";
	print "</tr>";


	$sql1 = "select * from answer where a_qid = '$q_id' order by a_id asc";
	$db_query1 = mysql_db_query ($dbname, $sql1);
	if (!$db_query1)
		{
			echo ("��硫Ԥ�ǵ����� SQL �����");
			exit;
		}	// end if

	$num_rows1 = mysql_num_rows($db_query1);
	if ($num_rows1 != 0 )
		{
			for ($i=0;$i<$num_rows1;$i++)	// �Ѻ��Ң����Ũҡ��Ŵ��ҧ � 㹵��ҧ Answer
			{
				$result1 = mysql_fetch_array($db_query1);
				$a_message = $result1[a_message];
				$a_email = $result1[a_email];
				$a_name = $result1[a_name];
				$a_date = $result1[a_datetime];
				$a_icq = $result1[a_icq];
				$a_ip = $result1[a_ip];

				$a_name = stripslashes($a_name);
				$a_email = stripslashes($a_email);
				$a_ip = stripslashes($a_ip);
				$a_date = stripslashes($a_date);
				$a_icq = stripslashes($a_icq);

				$set_color=$i%2;
				if ($set_color!=0){
					print "<tr>";
					print "<td bgcolor=$bgt3 width=20% valign='top'>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
	if ($a_email==""){
		print "<img src='image/mail.gif' width='33' height='11' border='0'>";
	}else{
		print "<a href='mailto:$a_email'><img src='image/mail.gif' width='33' height='11' border='0'></a>";
	}
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>$a_name</b></font>";
				    print "</td></tr><tr>";
				    print " <td>&nbsp;</td>";
				    print "</tr></table>";
					print "</td>";
					print "<td bgcolor=$bgt3>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
					print "<IMG SRC=$post1 align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> Posted:$a_date</font><hr>";
				    print "</td></tr><tr>";
				    print " <td>";
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_message</font></td></tr><tr><td align='right'>";
					print "<IMG SRC=$ip align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> $a_ip</font>";
				    print "</td></tr></table>";
					print "</td>";
					print "</tr>";
				}
				else{
					print "<tr>";
					print "<td bgcolor=$bgt2 width=20% valign='top'>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
	if ($a_email==""){
		print "<img src='image/mail.gif' width='33' height='11' border='0'>";
	}else{
		print "<a href='mailto:$a_email'><img src='image/mail.gif' width='33' height='11' border='0'></a>";
	}
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>$a_name</b></font>";
				    print "</td></tr><tr>";
				    print " <td>&nbsp;</td>";
				    print "</tr></table>";
					print "</td>";
					print "<td bgcolor=$bgt2>";
					print"<table width='100%' border='0' cellpadding='0' cellspacing='0'>";
				    print "<tr><td>";
					print "<IMG SRC=$post1 align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> Posted:$a_date</font><hr>";
				    print "</td></tr><tr>";
				    print " <td>";
					print "<FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$a_message</font></td></tr><tr><td align='right'>";
					print "<IMG SRC=$ip align='texttop'><FONT color=#000000 face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> $a_ip</font>";
				    print "</td></tr></table>";
					print "</td>";
					print "</tr>";
				}
			}	// �� for
		print "</table>";
	}	// �� if
?>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>

  <div align="center"><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760><TBODY>
    <tr align="left" valign="top"> 
      <td colspan="3" align="left"> 
        <p><br>
          <br>
        </p>
        <table width="80%" border="0" cellpadding="0" cellspacing="0" align="center">
          <tr> 
            <td> </td>
          </tr>
          <tr> 
            <td> 
              <?php	
							print "<FORM name=answer action='to_answer.php?q_id=$q_id'' method=post onSubmit='return check()'  autocomplete='off'>";
							?>
              <table cellspacing=0 cellpadding=0 width="100%" border=0 height="100%">
                <tbody> 
                <tr class=header bgcolor="#67a6c7"> 
                  <td colspan=2 align=center><font size="4" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�����ʴ������Դ���</font></td>
                </tr>
                <tr class=tablerow> 
                  <td width="24%" bgcolor=#dedfdf> 
                    <div align="right"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Name<font color="#FF0000">*</font> 
                      :</font></div>
                  </td>
                  <td bgcolor=#dedfdf width="76%"> 
                    <input size=25 name=a_name>
                    <span size=2> </span> </td>
                </tr>
                <tr class=tablerow> 
                  <td bgcolor=#dedfdf width="24%"> 
                    <div align="right"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Email 
                      :</font></div>
                  </td>
                  <td bgcolor=#dedfdf width="76%"> 
                    <input type=text size=25 name=a_email>
                  </td>
                </tr>
                <tr class=tablerow> 
                  <td valign=top bgcolor=#dedfdf width="24%"> 
                    <div align="right"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Message<font color="#FF0000">*</font>:<br>
                      </font></div>
                  </td>
                  <td bgcolor=#dedfdf width="76%"> 
                    <textarea name=a_message rows=9 cols=80></textarea>
                  </td>
                </tr>
                </tbody> 
              </table>
            </td>
          </tr>
          <tr> 
            <td bgcolor="#dedfdf"> 
              <div align="center">  
  <a href="javascript:setsmile(':smile:')"><img src="pics/smile.gif" border=0></a>
	<a href="javascript:setsmile(':big:')"><img src="pics/biggrin.gif" border=0></a>
	<a href="javascript:setsmile(':ent:')"><img src="pics/blue.gif" border=0></a>
	<a href="javascript:setsmile(':shy:')"><img src="pics/shy.gif" border=0></a>
	<a href="javascript:setsmile(':sun:')"><img src="pics/sunglasses.gif" border=0></a>
	<a href="javascript:setsmile(':sg:')"><img src="pics/supergrin.gif" border=0></a>
	<a href="javascript:setsmile(':embarass:')"><img src="pics/embarass.gif" 	border=0></a>
	<a href="javascript:setsmile(':dead:')"><img src="pics/dead.gif" border=0></a>
	<a href="javascript:setsmile(':cool:')"><img src="pics/cool.gif" border=0></a>
	<a href="javascript:setsmile(':clown:')"><img src="pics/clown.gif" border=0></a>
	<a href="javascript:setsmile(':pukey:')"><img src="pics/pukey.gif" border=0></a><br>
                <a href="javascript:setsmile(':eek:')"><img src="pics/eek.gif" border=0></a> 
                <a href="javascript:setsmile(':roll:')"><img src="pics/sarcblink.gif" border=0></a> 
                <a href="javascript:setsmile(':smoke:')"><img src="pics/smokin.gif" border=0></a> 
                <a href="javascript:setsmile(':angry:')"><img src="pics/reallymad.gif" border=0></a> 
                <a href="javascript:setsmile(':confused:')"><img src="pics/confused.gif" 	border=0></a> 
                <a href="javascript:setsmile(':cry:')"><img src="pics/crying.gif" border=0></a> 
                <a href="javascript:setsmile(':lol:')"><img src="pics/lol.gif" border=0></a> 
                <a href="javascript:setsmile(':yawn:')"><img src="pics/yawn.gif" border=0></a> 
                <a href="javascript:setsmile(':devil:')"><img src="pics/devil.gif" border=0></a> 
                <a href="javascript:setsmile(':tongue:')"><img src="pics/tongue.gif" border=0></a> 
                <a href="javascript:setsmile(':alien:')"><img src="pics/aysmile.gif" border=0></a> 
                <a href="javascript:setsmile(':tasty:')"><img src="pics/tasty.gif" border=0></a> 
                <a href="javascript:setsmile(':crazy:')"><img src="pics/grazy.gif" border=0></a><br>
    <font color="blue" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��ԡ����ٻ�����á�ٻŧ㹢�ͤ���</font>
				</div>
            </td>
          </tr>
          <tr>
            <td bgcolor="#dedfdf" nowrap> 
              <div align="center">
                <input type=submit value=Submit name=topicsubmit>
                <input type=reset value=reset name=topicreset>
              </div>
            </td>
          </tr>
        </table>
        <?php print "</form>"; ?>
      </td>
    </tr>
  </table>
      </td>
    </tr>
    </TBODY> 
  </table>
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.answer .a_name.value;
      var v2 = document.answer .a_message.value;
   
	  
        if ( v1.length==0)
           {
           alert("��سһ�͹ Name");
           document.answer .a_name.focus();           
           return false;
           }
        else if (v2.length==0)
           {
           alert("��سһ�͹ Message");
           document.answer .a_message.focus();           
		   return false;
           }
}
function setsmile(what)
{
	document.answer.a_message.value = document.answer.elements.a_message.value+" "+what;
	document.answer.a_message.focus();
}

//-->
</script> 
 </center>
 </div>
 </center> </div>
 </center>
 </body>
</html>
