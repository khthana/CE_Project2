<HTML>
<HEAD>
<TITLE>create database project</TITLE>
</HEAD>
<BODY>
<?
  $handle=mysql_connect("localhost","root","webmaster123")or die("error1");

//create db "project"
  $dbname="project";
  mysql_create_db($dbname,$handle)or die("error2");

//���ҧ���ҧ news
$sql="CREATE TABLE news (topic varchar(60) DEFAULT 'no' NOT NULL,detail longtext NOT NULL,name varchar(40) DEFAULT 'no' NOT NULL,vardate varchar(50) DEFAULT 'no' NOT NULL,id int(3) NOT NULL auto_increment,newsfile varchar(20) DEFAULT 'no' NOT NULL,date1 varchar(10) NOT NULL,PRIMARY KEY (id),UNIQUE id (id))";
$dbquery=mysql_db_query($dbname,$sql) or die("error3");

//���ҧ���ҧ register
$sql="CREATE TABLE register (advisor1 varchar(40) DEFAULT 'no' NOT NULL,advisor2 varchar(40) DEFAULT 'no' NOT NULL,namept varchar(200) DEFAULT 'no' NOT NULL,namepe varchar(200) DEFAULT 'no' NOT NULL,abst longtext NOT NULL,abse longtext NOT NULL,chap1 varchar(20) DEFAULT 'no' NOT NULL,chap2 varchar(20) DEFAULT 'no' NOT NULL,chap3 varchar(20) DEFAULT 'no' NOT NULL,chap4 varchar(20) DEFAULT 'no' NOT NULL,chap5 varchar(20) DEFAULT 'no' NOT NULL,chap6 varchar(20) DEFAULT 'no' NOT NULL,doc varchar(20) DEFAULT 'no' NOT NULL,year varchar(5) DEFAULT 'no' NOT NULL,id int(5) NOT NULL auto_increment,check int(1) NOT NULL,chap7 varchar(20) NOT NULL,chap8 varchar(20) NOT NULL,chap9 varchar(20) NOT NULL,chap10 varchar(20) NOT NULL,chap11 varchar(20) DEFAULT 'no' NOT NULL,chap12 varchar(20) DEFAULT 'no' NOT NULL,chap13 varchar(20) DEFAULT 'no' NOT NULL,chap14 varchar(20) DEFAULT 'no' NOT NULL,chap15 varchar(20) DEFAULT 'no' NOT NULL,chap16 varchar(20) DEFAULT 'no' NOT NULL,chap17 varchar(20) DEFAULT 'no' NOT NULL,chap18 varchar(20) DEFAULT 'no' NOT NULL,chap19 varchar(20) DEFAULT 'no' NOT NULL,chap20 varchar(20) DEFAULT 'no' NOT NULL,PRIMARY KEY (id, namepe),key1 varchar(80) NOT NULL,key2 varchar(80) NOT NULL, key3 varchar(80) NOT NULL,key4 varchar(80) NOT NULL,key5 varchar(80) NOT NULL)";
$dbquery=mysql_db_query($dbname,$sql) or die("error4");

//���ҧ���ҧ services
$sql="CREATE TABLE services (room varchar(10) NOT NULL,date1 varchar(10) NOT NULL,date2 varchar(10) NOT NULL,devices varchar(200) NOT NULL,code varchar(10) NOT NULL,id int(5) NOT NULL auto_increment,num int(2) DEFAULT '1' NOT NULL,PRIMARY KEY (id),UNIQUE id (id))";
$dbquery=mysql_db_query($dbname,$sql) or die("error5");

//���ҧ���ҧ stuproject
$sql="CREATE TABLE stuproject (id int(3) NOT NULL auto_increment,gpa1 varchar(6) NOT NULL,gpa2 varchar(6) NOT NULL,gpa3 varchar(6) NOT NULL,gpa4 varchar(6) NOT NULL,topicid int(3) NOT NULL,name1 varchar(40) NOT NULL,name2 varchar(40) NOT NULL,name3 varchar(40) NOT NULL,name4 varchar(40) NOT NULL,code1 varchar(10) NOT NULL,code2 varchar(10) NOT NULL,code3 varchar(10) NOT NULL,code4 varchar(10) NOT NULL,year varchar(4) NOT NULL,PRIMARY KEY (id),UNIQUE id (id))";
$dbquery=mysql_db_query($dbname,$sql) or die("error6");

//���ҧ���ҧ topicproject
$sql="CREATE TABLE topicproject (topic_t varchar(200) DEFAULT 'no' NOT NULL,topic_e varchar(200) DEFAULT 'no' NOT NULL,num char(1) NOT NULL,advisor1 varchar(40) DEFAULT 'no' NOT NULL,advisor2 varchar(40) DEFAULT 'no' NOT NULL,id int(3) NOT NULL auto_increment,check char(1) NOT NULL,date varchar(10) DEFAULT 'no' NOT NULL,detail longtext NOT NULL,make1 longtext NOT NULL,make2 longtext NOT NULL,codeadmin varchar(20) NOT NULL,PRIMARY KEY (id, topic_e, codeadmin),UNIQUE id (id))";
$dbquery=mysql_db_query($dbname,$sql) or die("error7");

//���ҧ���ҧ userregister
$sql="CREATE TABLE userregister (name1 varchar(40) DEFAULT 'no' NOT NULL,name2 varchar(40) DEFAULT 'no' NOT NULL,name3 varchar(40) DEFAULT 'no' NOT NULL,name4 varchar(40) DEFAULT 'no' NOT NULL,code1 varchar(10) DEFAULT 'no' NOT NULL,code2 varchar(10) DEFAULT 'no' NOT NULL,code3 varchar(10) DEFAULT 'no' NOT NULL,code4 varchar(10) DEFAULT 'no' NOT NULL,email1 varchar(40) DEFAULT 'no' NOT NULL,email2 varchar(40) DEFAULT 'no' NOT NULL,email3 varchar(40) DEFAULT 'no' NOT NULL, email4 varchar(40) DEFAULT 'no' NOT NULL,id int(5) NOT NULL,PRIMARY KEY (id),UNIQUE id (id))";
$dbquery=mysql_db_query($dbname,$sql) or die("error8");

//���ҧ���ҧ user_download
$sql="CREATE TABLE member_download (email varchar(40) NOT NULL,name varchar(40) NOT NULL,PRIMARY KEY (email))";
$dbquery=mysql_db_query($dbname,$sql) or die("error9");


//create db "register"
  $dbname="register";
  mysql_create_db($dbname,$handle)or die("error10");

//���ҧ���ҧ regis
$sql="CREATE TABLE regis (firstname varchar(40) NOT NULL,code varchar(20) NOT NULL,surname varchar(40) NOT NULL,pass varchar(10) NOT NULL,date varchar(10) NOT NULL,username varchar(20) NOT NULL,status varchar(10) NOT NULL,PRIMARY KEY (username))";
$dbquery=mysql_db_query($dbname,$sql) or die("error11");

mysql_close($handle);
?>
<div align="center">
  <p><br>
    <br>
    <font face="MS Sans Serif, Microsoft Sans Serif" size="4" color="#0033FF"><b><font size="5">Complete</font></b></font></p>
  <p><font color="#0033FF">Database 'PROJECT' �١���ҧ���º��������</font></p>
  <hr width="400">
  <br>
</div>
</BODY>
</HTML>
