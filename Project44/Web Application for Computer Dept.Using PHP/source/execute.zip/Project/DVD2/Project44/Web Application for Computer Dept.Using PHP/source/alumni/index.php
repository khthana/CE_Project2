<?php
	session_start();
	session_destroy();
	session_unset();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><img src="image/logo-kmitl.jpg" width="139" height="137"></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="137">
                <tr> 
                  <td><img src="image/logo-alumni.jpg" width="600" height="80"></td>
                </tr>
                <tr> 
                  <td>
                    <table width="100%" border="0" cellspacing="1" cellpadding="1"align="left" bordercolor="#000000" bgcolor="#000000">
                      <tr class = BNFont1 align="center"> 
                        <td bgcolor="#99CCFF" width="25%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="index.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Home</font></b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="register_form.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">ŧ����¹</font></b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="login.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��䢢�����</font></b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td>
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="normal.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�Ҥ����</font></b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="cont.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="cont.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�Ҥ������ͧ</font></b></a></font> 
                        </td>
                      </tr>
                      <tr>
                        <td width="20" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                        <td width="78%" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        
                          <td bgcolor="#CCCCFF" height="15"> 
                            <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1" color="#FFFFFF" class="fsize8" align="center"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">&nbsp;<font color="#000000" size="2">����</font></font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                  </div>
                                </td>
                              </tr>
                            </table>
                          </td>
                        
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624"> 
              <div align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                  <tr> 
                    <td height="120"> 
                      <div align="center"><img src="image/alumnilogo.jpg" width="361" height="120"></div>
                    </td>
                  </tr>
                  <tr> 
                    <td>
                      <div align="center"><font size="1" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Department 
                        of Computer Engineering Faculty of Engineering King Mongkut's 
                        Institute of Technology<br>
                        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400</font><font size="1" face="MS Sans Serif, Microsoft Sans Serif"><br>
                        </font><font size="2" face="MS Sans Serif, Microsoft Sans Serif"> 
                        </font></div>
                    </td>
                  </tr>
                  <tr> 
                    <td height="100%">&nbsp;</td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>

  <div align="center"> </div>
 </center>
 <script language="JavaScript">
<!--
function checks()
{
      var v1 = document.SearchForm.search.value;
        if ( v1.length==0)
           {
           alert("��سһ�͹�ӷ���ͧ��ä���");
           document.SearchForm.search.focus();
           return false;
           }
		 else
           return true;
}
//-->
</script>

</body>
</html>
