<html>
<head>
<title>�ʴ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><img src="images/l.gif" width="1" height="20"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width='772' border='0' cellspacing='0' cellpadding='0' align ='center'>
<?
echo "
	<tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='130' bgcolor='#EAEAFF' valign='top' ><font size='2' face='Tahoma, Microsoft Sans Serif' color='#9900CC'><br>
     <a href='index.php?course_year=$course_year'>��ѡ�ٵû�ԭ���͡</a><br>
      <a href='structure.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br></font><font face='Tahoma, Microsoft Sans Serif' size='2' >
	Ἱ����֡��<br></font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'>
		 <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
</font></td>
	  	<td width='10' valign='top' >&nbsp; </td>
    <td width='609' valign='top' >
      <table width='100%' border='0' cellspacing='0' cellpadding='0'>
        <tr> 
          <td colspan='5' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><br>
              ��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ�������������<br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>
              &nbsp; </font></div>
          </td>
        </tr>";
?>
        <tr> 
          <td width="39%" bgcolor="#F7F7F7"> 
            <div align="left"><font size="2" face="Tahoma, Microsoft Sans Serif"><b>14.3 Ἱ����֡��</b></font></div>
          </td>
          <td width="12%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="13%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="13%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="21%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
        </tr>
        <tr> 
          <td width="39%" bgcolor="#F7F7F7"> 
            <div align="left"><font size="2" face="Tahoma, Microsoft Sans Serif"><b>14.3.1 ���������֡�ҷ�� 
              1</b></font></div>
          </td>
          <td width="12%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="13%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="13%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="21%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
        </tr>
		</table>
	      
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor='#F7F7F7'> 
          
    <td width="51%" bgcolor="#F7F7F7"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><b>��ѡ�ٵû�ԭ���͡����Ѻ��騺��ԭ��� 
              (3��)</b></font></div>
          </td>
          
    <td width="9%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          
    <td width="11%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          
    <td width="7%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          
    <td width="22%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
        </tr>
  <tr bgcolor="#F7F7F7"> 
          <td width="39%">&nbsp;</td>
          <td width="12%">&nbsp;</td>
          <td width="13%">&nbsp;</td>
          <td width="13%">&nbsp;</td>
          <td width="21%">&nbsp;</td>
        </tr>
        <tr bgcolor="#F7F7F7"> 
          <td colspan="5"><font size="2" face="Tahoma, Microsoft Sans Serif"></font><font size="2" face="Tahoma, Microsoft Sans Serif"></font><font size="2" face="Tahoma, Microsoft Sans Serif"></font><font size="2" face="Tahoma, Microsoft Sans Serif"></font> 
<?
 	include ("connect_course.inc.php");
	$year=1;
	$term=1;
	$sum=0;
	$sum_detail=0;
	$sum_operation=0;
	$type="����Ѻ��騺��ԭ���";
	while($year <= 3 )
	{
		while($term <=2)
	{
			$query = "Select Code,Name From $Coursetable Where Type = '$type' AND Term = '$term' AND Year ='$year' AND Course_year = '$course_year' order by Code ";
	/*	
	$query = "Select * From $Coursetable,$Subjecttable Where $Coursetable.Course_year = '$course_year' AND $Subjecttable.Course_year = '$course_year' AND $Coursetable.Code=$Subjecttable.Code AND $Coursetable.Year='$year' AND $Coursetable.Term='$term'  AND $Coursetable.Type='$type' order by $Subjecttable.Code ASC LIMIT 0, 50  ";
	*/
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) { //bgcolor='#D4D4D4'
echo "
			<table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF'>
              <tr bgcolor='#EEEEEE'> 
                <td width='20%' height='25'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></div>
                </td>
                <td width='54%' height='25'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>��鹻շ�� $year 
                    �Ҥ���¹��� $term</font></div>
                </td>
                <td width='26%' height='25'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></div>
                </td>
              </tr>
              <tr bgcolor='#F2F2F2'> 
                <td width='20%' height='20' > 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�����Ԫ�</font></div>
                </td>
                <td width='54%' height='20' > 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�����Ԫ�</font></div>
                </td>
                <td width='26%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>˹��¡Ե(������-��Ժѵ�)</font></div>
                </td>
              </tr>";
while ($row = mysql_fetch_array($result)) 
	{
	$code = htmlspecialchars($row[Code]);
	$name = htmlspecialchars($row[Name]); 
	$name = eregi_replace("amp;","",$name);
	$query_subject = "Select Ename,Unit,Unit_detail,Unit_operation From $Subjecttable Where Code = '$code' ";
	$result_subject = mysql_query($query_subject);
	$row = mysql_fetch_array($result_subject);
	$ename = htmlspecialchars($row[Ename]); 
	$unit = htmlspecialchars($row[Unit]);
	$unit_detail = htmlspecialchars($row[Unit_detail]); 
	$unit_operation = htmlspecialchars($row[Unit_operation]);
   	$sum = $sum+$unit;
	$sum_detail = $sum_detail+ $unit_detail;
	$sum_operation = $sum_operation+ $unit_operation;
 echo "<tr bgcolor='#EAEAFF'> 
                <td width='20%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$code</font></div>
                </td>
				<td width='54%' height='20'> ";
				if ($ename == '')
					{
					echo "<div align='left'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;$name</font></div>";
					}
					else
					{
					echo "<div align='left'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;$name ($ename)</font></div>";
					}
echo "</td>
                <td width='26%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>$unit ($unit_detail-$unit_operation)&nbsp;</font></div>
                </td>
              </tr>";
}
echo "
              <tr bgcolor='#F2F2F2'> 
                <td width='20%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>˹��¡Ե���&nbsp;</font></div>
                </td>
                <td width='54%' height='20'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></td>
                <td width='26%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>$sum ($sum_detail-$sum_operation)&nbsp;</font></div>
                </td>
              </tr>
            </table><BR>	";
	}
	$term = $term +1;
		$sum=0;
	$sum_detail=0;
	$sum_operation=0;

	}//end of while term <= 2
	$term = 1;
	$year = $year +1;
	}	//end of while year <= 3
	?>
            <font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
        </tr>
        <tr bgcolor="#F7F7F7"> 
          <td width="39%"> 
            <div align="left"><font size="2" face="Tahoma, Microsoft Sans Serif"><b>14.3.2 ���������֡�ҷ�� 
              2</b></font></div>
          </td>
          <td width="12%"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="13%"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="13%"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          <td width="21%"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
        </tr>
         <tr bgcolor='#F7F7F7'> 
          
    <td width="51%" bgcolor="#F7F7F7"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><b>��ѡ�ٵû�ԭ���͡����Ѻ��騺��ԭ�ҵ��
              (4��)</b></font></div>
          </td>
          
    <td width="9%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          
    <td width="11%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          
    <td width="7%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
          
    <td width="22%" bgcolor="#F7F7F7"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
        </tr>
        <tr bgcolor="#F7F7F7"> 
          <td width="39%">&nbsp;</td>
          <td width="12%">&nbsp;</td>
          <td width="13%">&nbsp;</td>
          <td width="13%">&nbsp;</td>
          <td width="21%">&nbsp;</td>
        </tr>
        <tr bgcolor="#F7F7F7"> 
          <td colspan="5"> 
            <?
		$year=1;
	$term=1;
	$sum=0;
	$sum_detail=0;
	$sum_operation=0;
	$type="����Ѻ��騺��ԭ�ҵ��";
	while($year <= 4 )
	{
		while($term <=2)
	{
		$query = "Select Code,Name From $Coursetable Where Type = '$type' AND Term = '$term' AND Year ='$year' AND Course_year = '$course_year' order by Code ";
	/*
	$query = "Select * From $Coursetable,$Subjecttable Where $Coursetable.Course_year = '$course_year' AND $Subjecttable.Course_year = '$course_year' AND $Coursetable.Code=$Subjecttable.Code AND $Coursetable.Year='$year' AND $Coursetable.Term='$term'  AND $Coursetable.Type='$type' order by $Subjecttable.Code ASC LIMIT 0, 50  ";
	*/
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
echo "
	<table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF'>
              <tr bgcolor='#EEEEEE'> 
                <td width='20%' height='25'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></div>
                </td>
                <td width='54%' height='25'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>��鹻շ�� $year 
                    �Ҥ���¹��� $term</font></div>
                </td>
                <td width='26%' height='25'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></div>
                </td>
              </tr>
              <tr bgcolor='#F2F2F2'> 
                <td width='20%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�����Ԫ�</font></div>
                </td>
                <td width='54%' height='20' > 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�����Ԫ�</font></div>
                </td>
                <td width='26%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>˹��¡Ե(������-��Ժѵ�)</font></div>
                </td>
              </tr>";
	while ($row = mysql_fetch_array($result)) 
	{
	$code = htmlspecialchars($row[Code]);
	$name = htmlspecialchars($row[Name]); 
			$name = eregi_replace("amp;","",$name);
	$query_subject = "Select Ename,Unit,Unit_detail,Unit_operation From $Subjecttable Where Code = '$code' ";
	$result_subject = mysql_query($query_subject);
	$row = mysql_fetch_array($result_subject);
	$ename = htmlspecialchars($row[Ename]); 
	$unit = htmlspecialchars($row[Unit]);
	$unit_detail = htmlspecialchars($row[Unit_detail]); 
	$unit_operation = htmlspecialchars($row[Unit_operation]);
   	$sum = $sum+$unit;
	$sum_detail = $sum_detail+ $unit_detail;
	$sum_operation = $sum_operation+ $unit_operation;
 echo "
              <tr bgcolor='#EAEAFF'> 
                <td width='20%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;$code</font></div>
                </td>
	 				<td width='54%' height='20'>";
					if ($ename == '')
					{
					echo "<div align='left'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;$name</font></div>";
					}
					else
					{
					echo "<div align='left'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;$name ($ename)</font></div>";
					}
	echo "</td>
                <td width='26%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>$unit ($unit_detail-$unit_operation)&nbsp;</font></div>
                </td>
              </tr>";
}
echo "
              <tr bgcolor='#F2F2F2'> 
                <td width='20%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>˹��¡Ե���&nbsp;&nbsp;</font></div>
                </td>
                <td width='54%' height='20'><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;</font></td>
                <td width='26%' height='20'> 
                  <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>$sum ($sum_detail-$sum_operation)&nbsp;</font></div>
                </td>
              </tr>
            </table><BR>";
	}
	$term = $term +1;
		$sum=0;
	$sum_detail=0;
	$sum_operation=0;

	}//end of while term <= 2
	$term = 1;
	$year = $year +1;
	}	//end of while year <= 4
	MYSQL_CLOSE();
?>
          </td>
        </tr>
        <tr> 
          <td width="39%">&nbsp;</td>
          <td width="12%">&nbsp;</td>
          <td width="13%">&nbsp;</td>
          <td width="13%">&nbsp;</td>
          <td width="21%">&nbsp;</td>
        </tr>
      </table>
    </td>
        </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
