<?
			session_start();
?>
<html>
<head>
<title>���͡���˹��Ҩ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="772" border="0" cellspacing="0" cellpadding="0" align ='center'>
	<tr> 
    <td width="10" >&nbsp;</td>
    <td width="14" bgcolor="#D2F8FD" >&nbsp;</td>
    <td width="128" bgcolor="#D2F8FD" valign="top" ><font face="Tahoma, Microsoft Sans Serif" size="2" color="#9900CC"><br>
      </font><font face="Tahoma, Microsoft Sans Serif" size="2" color="#9900CC">
	  <a href="teacher_insert.php">�����������Ҩ����</a><br>
      <a href="teacher_show_update.php">��䢢������Ҩ����</a><br>
      <a href="teacher_show_delete.php" >ź�������Ҩ����</a><br>
		���͡���˹��Ҩ����<br>
      <a href='teacher_show.php'>�ʴ��������Ҩ����</a><br>
      <a href="../../show_select_person.php">��Ѻ˹����ѡ </a></font> <br>&nbsp;
      <br>
    </td>
    <td width="28" valign="top" >&nbsp;</td>
    <form name="form" method="post" action="select.php" >
      <td width="598" valign="top"> 
        <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#FFFFFF">
          <tr> 
            <td colspan="4" height="30" bgcolor="#F7F7F7"> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2">�����Ţͧ�Ҩ�����Ш��Ҥ�Ԫ����ǡ�������������</font></div>
            </td>
          </tr>
          <tr> 
            <td width="8%" bgcolor="#D2F8FD"> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2">�ӴѺ���</font></div>
            </td>
            <td width="39%" bgcolor="#D2F8FD"> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2">����-���ʡ��</font></div>
            </td>
            <td width="25%" bgcolor="#D2F8FD"> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2">���˹���Ҥ�Ԫ�</font></div>
            </td>
            <td width="25%" bgcolor="#D2F8FD"> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2">�Ţҹء���Ҥ�Ԫ�</font></div>
            </td>
          </tr>
<?
  if ($user[1]== 'administrator')
{
include ("connect_home.inc.php");
}
					$query = "Select * From $Officertable Where Status = '$user[4]' order by Show_order";
					$result = mysql_query($query);
					$snumber = mysql_numrows($result);
					$si=0;
						if ($si < $snumber)
						{
							while ($row = mysql_fetch_array($result))
								{
								$id = htmlspecialchars($row[ID]);
								$show_order = $row[Show_order];
								$name = htmlspecialchars($row[Name]);
								$select1 = "";
								$select2 = "";
					$query_select = "Select * From $Select_teachertable Where ID = '$id' ";
					$result_select = mysql_query($query_select);
					$tnumber = mysql_numrows($result_select);
					if ( $tnumber > 0)
						{
							while ($row = mysql_fetch_array($result_select))
								{
								$head = htmlspecialchars($row[Head]);
								$second = htmlspecialchars($row[Second]);
								if ($head == '���˹���Ҥ�Ԫ�')
									{
									$select1 = "checked";
									}
								if ($second == '�Ţҹء���Ҥ�Ԫ�')
									{
									$select2 = "checked";
									}
								}
						}
					
         echo "
			 <tr> 
            <td width='8%' bgcolor='#F7F7F7'>
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$show_order</font></div>
            </td>
            <td width='39%' bgcolor='#F7F7F7'> <font face='Tahoma, Microsoft Sans Serif' size='2'><a href='teacher_show_detail.php?id=$id'>&nbsp;$name</a></font></td>
            <td width='25%' bgcolor='#F7F7F7'>
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>
                <input type='radio' name='head' value='$id' $select1>
                </font></div>
            </td>
            <td width='25%' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>
                <input type='radio' name='second' value='$id' $select2>
                </font></div>
            </td>
          </tr>";
									}
						}
?>
          <tr> 
            <td width="8%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;</font></td>
            <td width="39%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;</font></td>
            <td width="25%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;</font></td>
            <td width="25%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;</font></td>
          </tr>
		  <tr> 
            <td colspan="4" bgcolor="#F7F7F7">
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"></font><font face="Tahoma, Microsoft Sans Serif" size="2"></font><font face="Tahoma, Microsoft Sans Serif" size="2"></font><font face="Tahoma, Microsoft Sans Serif" size="2"> 
                <input type="submit" name="Submit" value="Submit">&nbsp;
                <input type="reset" name="Submit2" value="Reset">
                </font></div>
            </td>
          </tr>          <tr> 
            <td width="8%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
            <td width="39%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
            <td width="25%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
            <td width="25%" bgcolor="#F7F7F7"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
          </tr>
        </table>
      </td>
    </form>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
