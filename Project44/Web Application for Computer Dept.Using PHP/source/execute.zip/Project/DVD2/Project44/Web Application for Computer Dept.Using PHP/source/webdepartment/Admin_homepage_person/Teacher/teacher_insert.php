<?
			session_start();
?>
<html>
<head>
<title>�����������Ҩ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="5" width="96">&nbsp;</td>
    <td height="5" width="321">&nbsp;</td>
    <td height="5" width="36">&nbsp;</td>
    <td width="108" height="5">&nbsp;</td>
    <td width="2" height="5">&nbsp;</td>
    <td width="106" height="5">&nbsp;</td>
    <td width="107" height="5">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="2"><font face="Microsoft Sans Serif"><font face="Tahoma, Microsoft Sans Serif"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0' align = 'center'>
  <tr> 
    <td width='10' height='572' >&nbsp;</td>
    <td width='10' bgcolor='#D2F8FD' height='572' >&nbsp;</td>
    <td width='160' bgcolor='#D2F8FD' valign='top' height='572' ><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      �����������Ҩ����<br>
      <a href='teacher_show_update.php'>��䢢������Ҩ����</a><br>
      <a href='teacher_show_delete.php' >ź�������Ҩ����</a><br>
      <a href='teacher_select.php' >���͡���˹��Ҩ����</a><br>
      <a href='teacher_show.php'>�ʴ��������Ҩ����</a><br>
      <a href='../../show_select_person.php'>��Ѻ˹����ѡ </a></font> <font face='Microsoft Sans Serif' size='2'><br>
      </font></td>
  <?
  if ($user[1] == 'administrator' )
{
		include ("connect_home.inc.php");
}
	  
echo "
    <form name='form' method='post' action='insert_teacher.php' enctype='multipart/form-data'>
      <td width='594' valign='top' height='572'> 
        <table width='580' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr valign='middle' bgcolor='#F7F7F7'> 
            <td colspan='2' height='35' > 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��͡�����Ţͧ�Ҩ�����Ш��Ҥ�Ԫ����ǡ�������������</font></div>
            </td>
          </tr>
          <tr valign='middle'> 
            <td height='34' bgcolor='#F7F7F7' > 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif'><font face='Tahoma, Microsoft Sans Serif'><font size='2'>�ӴѺ���</font></font></font></div>
            </td>
            <td height='34' bgcolor='#D2F8FD' ><font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp;&nbsp; 
              <input type='text' name='show_order' value='$show_order' size='5' maxlength='3'>
              </font></td>
          </tr>
          <tr valign='middle'> 
            <td height='34' bgcolor='#F7F7F7' > 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�ٻ�Ҿ</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='34' > 
              <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'> 
                &nbsp;&nbsp; 
                <input type='file' name='picture'>
                </font></div>
            </td>
          </tr>
          <tr valign='middle'> 
            <td height='34' bgcolor='#F7F7F7' > 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>������͡�Թ</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='34' ><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
              <input type='text' name='user_name' value='' size='25' maxlength='8'>
              <font color='#FF6600'>*����Թ 8 ����ѡ��</font></font></td>
          </tr>
          <tr valign='middle'> 
            <td height='17' bgcolor='#F7F7F7' > 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>���ʼ�ҹ</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='17' ><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
              <input type='password' name='passwd1' value='' size='25' maxlength='8'>
              <font color='#FF6600'>*����Թ 8 ����ѡ��</font></font></td>
          </tr>
          <tr valign='middle'> 
            <td height='17' bgcolor='#F7F7F7' > 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>���ʼ�ҹ�ա����</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='17' ><font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
              <input type='password' name='passwd2' value='' size='25' maxlength='8'>
              <font color='#FF6600'> *����Թ 8 ����ѡ��</font></font></td>
          </tr>
          <tr> 
            <td width='184' bgcolor='#F7F7F7' height='34'> 
              <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;����-���ʡ��</font></div>
            </td>
            <td width='410' bgcolor='#D2F8FD' height='34'> <font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
              <input type='text' name='name' value='' size='50' maxlength='100'>
              </font></td>
          </tr>
          <tr> 
            <td width='184' bgcolor='#F7F7F7' height='34'> 
              <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;Email-Address</font></div>
            </td>
            <td width='410' bgcolor='#D2F8FD' height='34'> <font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
              <input type='text' name='email' value='' size='50' maxlength='50'>
              </font></td>
          </tr>
          <tr> 
            <td width='184' bgcolor='#F7F7F7' height='34'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;���˹�/˹�ҷ��</font></div>
            </td>
            <td width='410' bgcolor='#D2F8FD' height='34'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
              <input type='text' name='level' value='' size='50' maxlength='100'>
              </font></td>
          </tr>
          <tr> 
            <td width='168' bgcolor='#F7F7F7' height='30'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�͹��дѺ</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='30' colspan='3'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
                <input type='checkbox' name='bachelor' value='��ԭ�ҵ��' >
                ��ԭ�ҵ�� &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                <input type='checkbox' name='master' value='��ԭ���' >
                ��ԭ��� &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; 
                <input type='checkbox' name='doctor'  value='��ԭ���͡'>
                ��ԭ���͡</font></div>
            </td>
          </tr>
          <tr> 
            <td width='184' bgcolor='#F7F7F7' height='105'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;�س�ز� 
                �Ң��Ԫ� ʶҹ����֡��</font></div>
            </td>
            <td width='410' bgcolor='#D2F8FD' height='105'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp; 
              <textarea name='graduation' cols='60' rows='5'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='168' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;�ŧҹ�ҧ�Ԫҡ��</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
              &nbsp;&nbsp; 
              <textarea name='research' cols='60' rows='5'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='168' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
                &nbsp; ���ҧ�͹</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='3'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
              &nbsp; 
              <textarea name='course' cols='60' rows='5'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='168' bgcolor='#F7F7F7' height='50'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���Ҿ����Ե</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='50' colspan='3'><font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp; 
              <textarea name='meeting' cols='60' rows='5'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='168' bgcolor='#F7F7F7' height='50'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>����ʹ�</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='50' colspan='3'><font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp; 
              <textarea name='interest' cols='60' rows='5'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='168' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���ʺ��ó�����</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='3'><font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp; 
              <textarea name='experience' cols='60' rows='5'></textarea>
              </font> </td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='52'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�������Ѿ��</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='52'> <font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp; 
              <input type='text' name='telephone' size='30' maxlength='30'>
              </font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='53'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;�������Դ��� 
                </font></div>
            </td>
            <td bgcolor='#D2F8FD' height='53'><font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp; 
              <textarea name='address' cols='60' rows='5'></textarea>
              </font></td>
          </tr>
          <tr> 
            <td bgcolor='#F7F7F7' height='34'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�ԧ����ǹ���</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='34'> <font size='2' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp; 
              </font> <font size='2' face='Tahoma, Microsoft Sans Serif'> 
              <input type='text' name='tlink' size='30' maxlength='100'>
              ������ҡ���� 1 �ԧ�� ��سҤ�蹴�������ͧ���� , �� www.yahoo.com,www.ce.kmitl.ac.th 
              �繵� </font></td>
          </tr>
          <tr> 
            <td height='26' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Microsoft Sans Serif'><font face='Microsoft Sans Serif'><font size='2'><font face='Tahoma, Microsoft Sans Serif'></font></font></font></font></div>
            </td>
            <td height='26' bgcolor='#D2F8FD'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          </tr>
          <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='34'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
                <input type='submit' name='Submit' value='�ѹ�֡'>
                &nbsp; 
                <input type='reset' name='Submit2' value='¡��ԡ'>
                </font></div>
            </td>
          </tr>
        </table>
      </td>
    </form>";
		mySql_close();
	?>
  </tr>
</table>

<table width='778' border='0' cellspacing='0' cellpadding='0' align ='center'>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align='center'><font face='Tahoma' size='1'>Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height='8'>
      <hr align='center' width='95%' size='2'>
    </td>
  </tr>
  <tr>
    <td>
      <div align='center'></div>
    </td>
  </tr>
</table>

</body>
</html>
