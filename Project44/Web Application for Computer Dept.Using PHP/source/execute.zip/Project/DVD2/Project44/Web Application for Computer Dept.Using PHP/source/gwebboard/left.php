<?session_start();
?>
<html>
<head>
<title>left</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor=#ffffff>
<table width='20%' border="0" cellspacing="0" cellpadding="0" align=left height="100%">
  <tr class=a> 
    <td valign="top" align="left" bgcolor="#391E8C" height="351"> 
      <table width="100" border="0" height="137" align="center" cellpadding="0" cellspacing="0">
        <tr class=A> 
          <td height="21" colspan="2"> 
            <div align="center" valign=top><font size="2"><b><img src="images/lhead0.gif" width="125" height="18"></b></font></div>
          </td>
        </tr>
        <tr class=A> 
          <td height="20" width="9%" valign="middle"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td height="20" width="91%" valign="middle">&nbsp;<a href="newgroup.php" class=a target=_parent>���ҧ 
            group</a></td>
        </tr>
        <tr class=A> 
          <td height="20" width="9%" valign="middle"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td height="20" width="91%" valign="middle">&nbsp;<a href="request.php" class=a target=_parent>������� 
            group</a></td>
        </tr>
        <tr class=A> 
          <td width="9%" valign="middle" height="20"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td width="91%" height="20" valign="middle">&nbsp;<a href="newuser.php" class=a target=_parent>��Ѥü���� 
            group</a></td>
        </tr>
      <tr class=A> 
          <td height="19" width="9%" valign="middle"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td height="19" width="91%" valign="middle">&nbsp;<a href="body.php" class=a target=body>Home</a></td>
        </tr>
        <tr class=A> 
          <td width="9%" height="20" valign="middle"> 
            <div align="right"><img src="images/dot1.gif" width="5" height="5"></div>
          </td>
          <td width="91%" height="20" valign="middle">&nbsp;<a href="help.php" class=a target=body>Help</a></td>
        </tr>
      
	  </table>
      <div align="center"><br>
      </div>
      <form method="post" action='body.php' target=body name=form1>
        <table width=131 border="0" height=124 align="center">
          <tr class=A> 
            <td valign="bottom" height=59 align="left"> 
              <div align="center"> 
                <input type="text" name="word" size="15">
              </div>
            </td>
          </tr>
          <tr class=A> 
            <td valign="middle" height=61 align="left" class=a> 
              <div align="center"> 
                <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 13px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Search name=search>
              </div>
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
</table>
</body>
</html>