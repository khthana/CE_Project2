<?session_start();
?>
<html>
<head>
<title>body</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#ffffFF">
<table width="635" cellspacing=0 border=0 align=left>
<tr class=a>
<td >

<table width="635" cellspacing=0 border=1 align=left>
  <tr class=a>
<td bordercolor=#3300FF border=1>
<?
if(($word=='')||(!$word))
{
?>
	  <table width="635" cellspacing=0 border=0 align=center>
        <tr bgcolor=#391E8C > 
          <td height=15 align=center colspan=3 ><font class=h>Group ������</font></td>
        </tr>
        <tr bgcolor=#F0F0FF > 
          <td height=20 align=center width="12%" valign=middle class=A bgcolor="#F0F0FF"><font color="#0000FF"><b>Group</b></font></td>
          <td height=20 align=center width="32%" valign=middle class=a><font color="#0000FF"><b>���� 
            Group</b></font></td>
          <td height=20 align=center width="56%" valign=middle class=a><font color="#0000FF"><b>��������´ 
            Group</b></font></td>
        </tr>
<?
}
else
{
?> 
    <table width="635" cellspacing=0 border=0 align=center>
        <tr bgcolor=#391E8C > 
          <td height=15 align=center colspan=3 ><font class=h>Group ������</font></td>
        </tr>
        <tr bgcolor=#F0F0FF > 
          <td height=20 align=center width="12%" valign=middle class=A bgcolor="#F0F0FF"><font color="#0000FF"><b>Group</b></font></td>
          <td height=20 align=center width="32%" valign=middle class=a><font color="#0000FF"><b>���� 
            Group</b></font></td>
          <td height=20 align=center width="56%" valign=middle class=a><font color="#0000FF"><b>��������´ 
            Group</b></font></td>
        </tr>
<?
}
include("connect.inc.php");
include("update.inc.php");
$dbname=gwebboard();   
if(!$page)    //�ͧ pagging
   $page=1; 

if($word!='')
{
    $sql="select * from admin  where (nameboard Like '%$word%')";
}
else
{
  $sql="select * from  admin";
}
$per_page=10;
if(!$page)
   $page=1;

$prev=$page-1;
$next=$page+1;

$dbquery=mysql_db_query($dbname,$sql)or die("error1");

$p_start=($per_page * $page)-$per_page;
$rows=mysql_num_rows($dbquery);	

if($rows<=$per_page)
    $n_page=1;
else if (($rows%$per_page)==0)
           $n_page=($rows/$per_page);
        else
		   $n_page=($rows/$per_page)+1;
 $n_page=(int)$n_page;
if($word!='')
{
   $sql="select * from admin  where (nameboard Like '%$word%') order by nameboard asc LIMIT $p_start, $per_page";
}
else
{
 $sql="select * from admin order by nameboard asc LIMIT $p_start, $per_page";
}
 $dbquery=mysql_db_query($dbname,$sql)or die("error2");
 
 while($result=mysql_fetch_array($dbquery))
    {

  if((c_d($result[date2]))!='6')
		{
  ?>
        <tr bgcolor=#ffffff> 
          <td height=30 align=center width="12%"  class=a><a href="request.php?nameboards=<?print($result[nameboard]);?>" target=_parent>
			                   <?if((c_d($result[date2]))!='5')
                                             		{
                                                     ?>
													 <img src="images/docbut.gif" border=0></a></td>
													<?
													 }  
		                                            else
			                                          {
													?>
		                                           <img src="images/docbut2.gif" border=0></a></td>
													<?
													 }
													?>
		                     
          <td height=15 align=center width="32%" class=a><FONT  COLOR="#FFAC84" ><b> 
            <?print($result[nameboard]);?>
            </b></FONT></td>
          <td height=15 align=center width="56%" class=a><FONT  COLOR="#333399" ><b> 
            <?print($result[comment]);?>
            </b></font></td>
        </tr>
   <?
		}//if
else
		{
	               //ź group ���������ա������¹�ŧ�Թ 65 �ѹ
				  //źsub���������ǡѺ nameboard
	               $nameboards=$result[nameboard];
				   $dirname=$nameboards;
                   $dh=opendir($dirname);
                   while($file=readdir($dh))
                      {
                        if(($file!='.')&&($file!='..'))
						  {
					         $dirname2=$file;
							 $dh2=opendir($dirname.'/'.$dirname2);
						      while($file2=readdir($dh2))
                                  {
                                     if(($file2!='.')&&($file2!='..'))
									   {     
									    $dirname3=$file2;
							            $dh3=opendir($dirname.'/'.$dirname2.'/'.$dirname3);
                                              while($file3=readdir($dh3))
                                                 {
                                                    if(($file3!='.')&&($file3!='..'))
						                                unlink($dirname.'/'.$dirname2.'/'.$dirname3.'/'.$file3); 
												 }//while3	
				                               rmdir($dirname.'/'.$dirname2.'/'.$dirname3);
					                           //closedir($dh3);
									   }//if3
								  }//while2
						   rmdir($dirname.'/'.$dirname2);
				           //closedir($dh2);
						   }//if2
						}//while1
                     rmdir($dirname);
					closedir($dh);
					
					
				   $sql="select * from  $nameboards";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error3");
		           $num_rows=mysql_num_rows($dbquery);
				   
				   $c2=0;
				   while($c2<$num_rows)
				      {
				       $result=mysql_fetch_array($dbquery);
				       
	   				   //źtable �ͧ topic
				       $sql1="drop table $nameboards$result[id]";
		               $dbquery1=mysql_db_query($dbname,$sql1)or die("error4");
                       $c2++; 				     
					 }
				   //źtable �ͧ nameboard
				   $sql="drop table $nameboards";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error5");
				   
	    		   //�� email �ͧ��Ңͧ $nameboards
				   $sql="select * from  admin where nameboard='$nameboards'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error3");
                   $result=mysql_fetch_array($dbquery);
                    
				   //ź record 㹵��ҧ admin 
		           $sql="delete from admin where email ='$result[email]'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error6");
				  
				   //ź record 㹵��ҧ user 
		           $sql="delete from user where email ='$result[email]' and own='admin'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error7");
				 
				   //ź record 㹵��ҧ user 
		           $sql="delete from user where name ='' and own='user' and request='$nameboards'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error8");
				   
				   //ź record 㹵��ҧ userboard 
		           $sql="delete from userboard where nameboard='$nameboards'";
		           $dbquery=mysql_db_query($dbname,$sql)or die("error9");
				 
				   //update request table user
		           $sql="update user set request='' where request='$nameboards' and name!=''";
                   $dbquery=mysql_db_query($dbname,$sql)or die("error10");
				 
				   
		  }//else
   }//while
		?>
        <tr bgcolor=#ffffFF valign="bottom" > 
          <td height=50 align=left colspan=3 class=a>&nbsp;
            <? if($prev!=0) print("<a href='$PHP_SELF?page=$prev' class=a1>&lt;&lt;</a>&nbsp;");?>
            <FONT  color="#006699"><b>Page : </b></font> 
            <?for($i=1;$i<=$n_page;$i++)
           {
             if($i!=$page)
		       print("<a href='$PHP_SELF?page=$i' class=a1><b>$i </b></a>");
	         else
		       print("<font class=a><FONT COLOR='#FF0000'><b>$i </b></FONT></FONT>");
           }
    if($page!=$n_page)  print("<a href='$PHP_SELF?page=$next' class=a1>&gt;&gt;</a>");
    //�Դ�ҹ������
     closedb();
 ?>
          </td>
        </tr>
      </table>
  </td>  
  </tr>
 
 </table>
</td>
</tr>
 <tr class=a>
 <td class=a>
 <br>
 <table width="635" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class=a> 
            <div align="center"><font color="#000080">Department of Computer Engineering 
              Faculty of Engineering King Mongkut's Institute of Technology<br>
              Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              �觤ӵ�����  <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
          </td>
        </tr>
        <tr> 
          <td height="8"> 
            <hr align="center" width="550" size="2">
          </td>
        </tr>
        <tr> 
          <td> 
            <div align="center"></div>
          </td>
        </tr>
      </table>
 
  </td>  
  </tr>
 </table>
</body>
</html>