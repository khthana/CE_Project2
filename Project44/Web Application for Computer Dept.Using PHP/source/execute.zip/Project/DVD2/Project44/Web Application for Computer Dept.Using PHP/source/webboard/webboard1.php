<?php
	session_start();
	session_destroy();
	session_unset();
	include("webboard.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	setlocale("LC_TIME","th");	//������Ẻ�� 
	$a2 = date("j")*1440;
	$b2 = strftime("%m")*44640;	
	$c2 = (strftime("%Y")+543)*535680;
	$d2 = date("H")*60;	 // ���Ҫ������
	$f2 = date("i");	 // ���ҹҷ�
	$gif_up = $a2+$b2+$c2+$d2+$f2;

	if (empty($page)){
		$page=1;
	}
	$q_sql = "select * from question";
	$q_db_query = mysql_db_query ($dbname, $q_sql);
	$num_rows = mysql_num_rows($q_db_query);
	$rt = $num_rows%$pagesize;
	if($rt!=0) 
		{ 
			$totalpage = floor($num_rows/$pagesize)+1; 
		}
	else
		{
			$totalpage = floor($num_rows/$pagesize); 
		}
	$goto = ($page-1)*$pagesize;
	$sql = "select * from question order by q_topic asc limit $goto,$pagesize";
	$db_query = mysql_db_query ($dbname, $sql);
	if (!$db_query){
		print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
		exit;
	}
	else{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
        
<table width="770" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td> 
      <div align="center"><?php print "<img src='image/ce1.jpeg'>"; ?></div>
    </td>
  </tr>
  <tr> 
    <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="48%"> 
            <div align="left"><?php print "<a href='form_qusetion.php'><img src='image/newtopic.gif' border='0'></a>";
			?>
			</div>
          </td>
          <td width="52%"> 
            <div align="right">
			<a href="help.php"><font 
      size=$textsize><b><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=2><?php print "Help";?></font></b></font></a><?php print "<a href='help.php'><img src='image/Help.gif' border='0'></a>"; ?></div>
          </td>
        </tr>
      </table>
    </td>
  </tr><td>

<?php
		$nums_rows = mysql_num_rows($db_query);
		print "<table border=0  width=100% cellspacing=1 cellpadding=4>";
		print "<tr ><td bgcolor=$corlor_head align=center width=10><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B><CENTER>S</CENTER></B></FONT></td>";
		print "<td bgcolor=$corlor_head ><a href=\"index.php\"><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Created</b></font></a></td>";
		print "<td bgcolor=$corlor_head width=40%><a href=\"webboard1.php\"><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Topic</b></font></a></td>";
		print "<td bgcolor=$corlor_head><a href=\"webboard2.php\"><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Topic Starter</b></font></a></td>";
		print "<td bgcolor=$corlor_head ><a href=\"webboard3.php\"><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Last Post</b></font></a></td>";
		print "<td bgcolor=$corlor_head ><a href=\"webboard4.php\"><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>R</b></font></a></td></tr>";
		for ($i=0;$i<$nums_rows;$i++){
			$result = mysql_fetch_array($db_query);
			$q_id = $result[q_id];
			$q_topic = $result[q_topic];
			$q_name = $result[q_name];
			$q_email = $result[q_email];
			$q_ip = $result[q_ip];
			$q_date = $result[q_datetime];
			$q_time = $result[q_time];
			$q_update = $result[q_update];
			$q_post = $result[q_post];
			$q_reng = $result[q_reng];

			$sql6 = "select max(a_datetime) from answer where a_qid='$q_id'";
			$query6 = mysql_db_query ($dbname, $sql6);
			$result6 = mysql_fetch_array($query6);
			
			$sql7 = "select * from answer where a_qid='$q_id'";
			$query7 = mysql_db_query ($dbname, $sql7);
			$nums_rows7 = mysql_num_rows($query7);

			if($nums_rows7!="0"){
				$q_update1 = $result6[0];
			}
			else{
				$q_update1 = "$q_date:$q_time";
				$q_reng = "0";
		}
			$q_id = stripslashes($q_id);
			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);
			$q_date = stripslashes($q_date);
			$q_update = stripslashes($q_update);
			$q_post = stripslashes($q_post);

			$sql1 = "select * from answer where a_id='i'";
			$db_query1 = mysql_db_query ($dbname, $sql1);
			$nums_rows1 = mysql_num_rows($db_query1);

			$up=$gif_up-$q_update;
			if($up<=4320){
				print "<Tr> <Td bgcolor=$bg1 width=10><img src=$new>";
				print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
				print "<Td  bgcolor=$bg3 width=40%><a href=\"view_answer.php?q_id=$q_id\" target=\"_blank\">";
				print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
				print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
				print "<Td  bgcolor=$bg3 ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_update1</font></Td>";
				print "<Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
			}
			else if($up>21600){
				$sql5 = "delete from question where q_id = '$q_id'";
				$db_query5 = mysql_db_query ($dbname, $sql5);
				
				$sql4 = "delete from answer where a_qid = '$q_id'";
				$db_query4 = mysql_db_query ($dbname, $sql4);
			}
			else{
				print "<Tr> <Td bgcolor=$bg1 width=10><img src=$normal>";
				print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
				print "<Td  bgcolor=$bg3 width=40%><a href=\"view_answer.php?q_id=$q_id\" target=\"_blank\">";
				print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
				print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
				print "<Td  bgcolor=$bg3 ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_update1</font></Td>";
				print "<Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
			}
		
		}	// end for
	print "</table>";
	} // end else
	print "<table border=0 width=100%><tr>";
	print"<td><div align=left><img src=$new align=bottom><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> ��Ǣ������ (�ա�� update ���������� 3 �ѹ)</font><br>";
	print"<img src=$normal align=bottom><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1> ��Ǣ�� (����ա�� update �������Թ 3 �ѹ)</font></div></td>";
	print "<td align=right>";
	print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Page </font>";
	for($i=1 ; $i<$page ; $i++){
		print "<a href='$PHP_SELF?page=$i'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
	}
	print "<font face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1  color=red><b>$page</b></font> ";
	for($i=$page+1 ; $i<=$totalpage ; $i++){
		print "<a href=$PHP_SELF?page=$i><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
	}
	print"</td>";
	print"</tr></table>";
?></td></tr>
    <tr> 
      <td> 
        <div align="center"><font  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' color="gray" size="1"><b><br>
          <font size="1"><?php print "Computer Engineering Department King Mongkut's Institue of Technology Ladkrabang<br>Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400"; ?></font> 
          </b></font></div>
      </td>
    </tr>
  </table>
<div align="center"> </div>
 
 </body>
</html>
