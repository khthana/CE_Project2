<html>
<head>
<title>��駤�Ҫ�����͡�Թ������ʼ�ҹ�ͧ�������к�</title>
<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>
<style type='text/css'>
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor='#FFFFFF'><table width="778" border="0" cellspacing="0" cellpadding="0" height="94" align="center">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="6" width="111">&nbsp;</td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
  
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td colspan="4" height="25"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><b>���������Ţͧ 
        Administrator ��觴���</b></font></div>
    </td>
  </tr>
  <tr> 
    <td height="25" colspan="2"> 
      <div align="center"></div>
    </td>
    <td width="291" height="25"><font face="Tahoma, Microsoft Sans Serif" size="2">- 
      �к���ѡ�ٵ� </font></td>
    <td width="292" height="25"><font face="Tahoma, Microsoft Sans Serif" size="2">- 
      �к��ç�ҹ</font></td>
  </tr>
  <tr> 
    <td height="25" colspan="2"> 
      <div align="center"></div>
    </td>
    <td width="291" height="25"><font face="Tahoma, Microsoft Sans Serif" size="2">- 
      �к����ྨ����Ԫ�</font></td>
    <td width="292" height="25">&nbsp;</td>
  </tr>
  <tr> 
    <td height="25" colspan="2"> 
      <div align="center"></div>
    </td>
    <td width="291" height="25"><font face="Tahoma, Microsoft Sans Serif" size="2">- 
      �к����ྨ�ؤ�ҡ�</font></td>
    <td width="292" height="25">&nbsp;</td>
  </tr>
</table>
<form name="form" method="post" action="insert.php" target ="_parent">
  <table width='778' border='0' cellspacing='0' cellpadding='0' align ='center'>
    <tr> 
      <td width='23%' height='56'>&nbsp;</td>
      <td width='55%' height='56'> 
        <table width='100%' border='1' cellspacing='1' cellpadding='1' bordercolor='#CCCCCC' align = 'center'>
          <tr> 
            <td colspan='2' height='14' bgcolor='#336699'> 
              <div align='center'><font face='Tahoma' size='3' color='#FFFFFF'>������ 
                Administrator</font></div>
            </td>
          </tr>
          <tr> 
            <td height='30' bgcolor='#336699' width="32%"> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2" color="#FFFFFF">Status</font></div>
            </td>
            <td height='30' bgcolor='#F7F7F7' width="68%"><font face="Tahoma, Microsoft Sans Serif" size="2"> 
              <select name="status">
                <option value="administrator">administrator</option>
                <option value="teacher">teacher</option>
                <option value="store">store</option>
                <option value="hardware">hardware</option>
                <option value="library">library</option>
              </select>
              </font></td>
          </tr>
          <tr> 
            <td width='32%' height='30' bgcolor='#336699'> 
              <div align='center'><font face="Tahoma" size="2" color="#FFFFFF">username</font></div>
            </td>
            <td height='30' bgcolor='#F7F7F7' width="68%"> 
              <input type='text' name='user_name' maxlength='8' size="10">
              <font face='Tahoma' size='2'> ���繪�����͡�Թ</font></td>
          </tr>
          <tr> 
            <td width='32%' height='14' bgcolor='#336699'> 
              <div align='center'><font face='Tahoma' size='2' color='#FFFFFF'>����</font></div>
            </td>
            <td height='14' bgcolor='#F7F7F7' width="68%"> 
              <input type='text' name='name' size='20' maxlength='50'>
            </td>
          </tr>
          <tr> 
            <td width='32%' height='15' bgcolor='#336699'> 
              <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2" color="#FFFFFF">���ʡ��</font></div>
            </td>
            <td height='15' bgcolor='#F7F7F7' width="68%"> 
              <input type='text' name='lastname' size='20' maxlength='50'>
            </td>
          </tr>
          <tr> 
            <td width='32%' height='30' bgcolor='#336699'> 
              <div align='center'><font face='Tahoma' size='2' color='#FFFFFF'>Email</font></div>
            </td>
            <td height='30' bgcolor='#F7F7F7' width="68%"> 
              <input type='text' name='email' size='15' maxlength='50'>
              <font size="2"> <font face="Tahoma, Microsoft Sans Serif">@ce.kmitl.ac.th</font></font> 
            </td>
          </tr>
          <tr> 
            <td width='32%' height='30' bgcolor='#336699'> 
              <div align='center'><font color='#FFFFFF'><font size='2' face='Tahoma'>���ʼ�ҹ</font></font></div>
            </td>
            <td height='30' bgcolor='#F7F7F7' width="68%"> 
              <input type='password' name='passwd1' maxlength='8' size="10">
            </td>
          </tr>
          <tr> 
            <td width='32%' height='30' bgcolor='#336699'> 
              <div align='center'><font face='Tahoma' size='2' color='#FFFFFF'>���ʼ�ҹ�ա����</font></div>
            </td>
            <td height='30' bgcolor='#F7F7F7' width="68%"> 
              <input type='password' name='passwd2' maxlength='8' size="10">
            </td>
          </tr>
          <tr> 
            <td colspan='2' height='30' bgcolor='#336699'> 
              <div align="center"> 
                <input type='submit' name='Submit2' value=' �ѹ�֡ '>
                &nbsp; &nbsp; 
                <input type='reset' name='Reset' value=' ¡��ԡ '>
              </div>
            </td>
          </tr>
        </table>
      </td>
      <td width='22%' height='56'>&nbsp;</td>
    </tr>
    <tr> 
      <td width='23%'> 
        <div align="right"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></div>
      </td>
      <td colspan="2" height="25"> <font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;&nbsp;&nbsp;<b>�����˵� 
        :</b> ������͡�Թ������ʼ�ҹ����͡㹤��駹�������<font color="#FF0000">����������</font>��ҹ��</font></td>
    </tr>
    <tr> 
      <td width='23%'>&nbsp;</td>
      <td colspan="2"><font face="Tahoma, Microsoft Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��������ա����䢢�����������к����������Ǣ�ͧ�Ѻ�к�����</font></td>
    </tr>
  </table>
</form>
<table width='778' border='0' cellspacing='0' cellpadding='0' align = 'center'>
  <tr> 
      <td height='27'>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align='center'><font face='Tahoma' size='1'>Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height='8'> 
      <hr align='center' width='95%' size='2'>
    </td>
  </tr>
  <tr> 
    <td> 
      <div align='center'></div>
    </td>
  </tr>
</table>
</body>
</html>
