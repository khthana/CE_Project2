<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="154" border="0" cellspacing="0" cellpadding="0" height="100%" align="right">
  <tr> 
    <td width="8%" bgcolor="#D2F8FD">&nbsp;</td>
    <td width="86%" bgcolor="#D2F8FD" valign="top"><font face="Tahoma" size="2" color="#9900CC"><br>
	 <a href='../../../introduce_insert.php' target ='_parent'>��ѡ�ٵû�ԭ�ҵ��</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
	<a href='../../../structure_insert_course.php' target ='_parent'>
      �ç���ҧ��ѡ�ٵ�</a><br>
      <a href='../../../insert_category.php' target ='_parent'>������Ǵ�Ԫ�����</a><br>
      <a href='../../../select_course_group.php' target ='_parent'>����������Ԫ����� 
      </a><br>
      <a href='../Subject/select_course.php' target ='_parent'>��������Ԫ����� 
      </a><br>�ǡ�èѴ�Ԫ����¹<br>
      <a href='../../../index.php' target ='_parent'>��Ѻ˹����ѡ 
      </a></font></td>
   
  </tr>
</table>
</body>
</html>
