<?
			session_start();
?>
<html>
<head>
<title>��䢢������Ҩ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111"><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
    <td height="6" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="99" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif"><font face="Tahoma, Microsoft Sans Serif"><font size="2"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="99">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
<?
if ($user[1] == 'administrator' )
{
include ("connect_home.inc.php");
include ("dateth.inc.php");
}
echo "
  <tr>
    <td width='10' >&nbsp;</td>
    <td width='10' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='160' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='teacher_insert.php'>�����������Ҩ����</a><br>
      ��䢢������Ҩ����<br>
      <a href='teacher_show_delete.php' >ź�������Ҩ����</a><br>
      <a href='teacher_select.php' >���͡���˹��Ҩ����</a><br>
      <a href='teacher_show.php'>�ʴ��������Ҩ����</a><br>
      <a href='../../show_select_person.php'>��Ѻ˹����ѡ </a></font> <br>
      &nbsp;
      </td>
      <form name='form' method='post' action='update_teacher.php' enctype='multipart/form-data'>
    <td width='594' valign='top'> ";
					$query_select = "Select * From $Officertable Where ID ='$id' AND Status = '$user[4]' ";
					$result_select = mysql_query($query_select);
					$snumber = mysql_numrows($result_select);
					$si=0;
						if ($si < $snumber)
						{
							while ($row = mysql_fetch_array($result_select))
								{
								$id = htmlspecialchars($row[ID]); 
								$show_order = $row[Show_order];
								$last_update = htmlspecialchars($row[Last_update]); 
   								$user_name = htmlspecialchars($row[Username]);
								$passwd = htmlspecialchars($row[Password]);
								$picture = htmlspecialchars($row[Picture]); 
								$name = htmlspecialchars($row[Name]);
								$email = htmlspecialchars($row[Email]);
								$level = htmlspecialchars($row[Level]);
								$bachelor = htmlspecialchars($row[Bachelor]);
								$master = htmlspecialchars($row[Master]);
								$doctor = htmlspecialchars($row[Doctor]);
								$tlink = htmlspecialchars($row[Tlink]);
								$telephone = htmlspecialchars($row[Telephone]);
								$graduation = $row[Graduation];
								$research = $row[Research];
								$course = $row[Course];
								$meeting = $row[Meeting];
								$interest = $row[Interest];
								$experience = $row[Experience];
								$address = $row[Address];
								$graduation = eregi_replace('<br>',chr(13),$graduation);
								$research = eregi_replace('<br>',chr(13),$research);
								$course = eregi_replace('<br>',chr(13),$course);
								$meeting = eregi_replace('<br>',chr(13),$meeting);
								$interest = eregi_replace('<br>',chr(13),$interest);
								$experience = eregi_replace('<br>',chr(13),$experience);
								$address = eregi_replace('<br>',chr(13),$address);
								$temp = $user_name;
								}
						}

	echo "
	<table width='580' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF' height='164'>
  <tr valign='middle' bgcolor='#F7F7F7'> 
    <td colspan='3' height='35' > 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��䢢����Ţͧ�Ҩ�����Ш��Ҥ�Ԫ����ǡ�������������</font></div>
    </td>
  </tr>
  <tr valign='middle' bgcolor='#F7F7F7'> 
    <td bgcolor='#F7F7F7' height='35' width='166' > 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�ӴѺ���</font></div>
    </td>
    <td colspan='2' height='35' bgcolor='#D2F8FD' ><font face='Tahoma, Microsoft Sans Serif' size='2' color = '#FF6600'> &nbsp;&nbsp;
        <input type='show_order' name='show_order' value='$show_order' size='5' maxlength='3'>
      </font></td>
  </tr>
  <tr> 
    <td width='166' bgcolor='#F7F7F7' height='35'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>��䢤����ش����</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='35' width='245'> 
      <div align='center'> <font face='Tahoma, Microsoft Sans Serif' size='2'> 
        <input type='text' name='last_update' value='$last_update' size='30' maxlength='100' readonly>
        </font></div>
    </td>
    <td bgcolor='#D2F8FD' height='95' rowspan='3' width='161'> 
      <div align='center'><img src='Picture_teacher_$id/$picture' width='130' align='middle'></div>
    </td>
  </tr>
  <tr> 
    <td width='166' bgcolor='#F7F7F7' height='35'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>������͡�Թ</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='35' width='245'>&nbsp;&nbsp; <font face='Tahoma, Microsoft Sans Serif' size='2' color = '#FF6600'> 
      <input type='text' name='user_name' value='$user_name' size='10' maxlength='8'>
      * ����Թ 8 ����ѡ�� </font> </td>
  </tr>
  <tr> 
    <td width='166' bgcolor='#F7F7F7' height='35'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>���ʼ�ҹ</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='35' width='245'>&nbsp;&nbsp; <font face='Tahoma, Microsoft Sans Serif' size='2' color = '#FF6600'> 
      <input type='password' name='passwd1' value='$passwd' size='10' maxlength='8'>
      * ����Թ 8 ����ѡ�� </font> </td>
  </tr>
  <tr> 
    <td width='166' bgcolor='#F7F7F7' height='2'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>���ʼ�ҹ�ա����&nbsp;</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='2' width='245'>&nbsp;&nbsp; <font face='Tahoma, Microsoft Sans Serif' size='2' color = '#FF6600'> 
      <input type='password' name='passwd2' value='$passwd' size='10' maxlength='8'>
      * ����Թ 8 ����ѡ�� </font> </td>
    <td bgcolor='#D2F8FD' height='2' width='161'> 
      <div align='center'> 
        <input type='file' name='picture' size='12'>
      </div>
    </td>
  </tr>
  <tr> 
    <td width='166' bgcolor='#F7F7F7' height='15'> 
      <div align='center'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>&nbsp;&nbsp;&nbsp;����-���ʡ��</font></div>
    </td>
    <td bgcolor='#D2F8FD' height='15' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;&nbsp; 
      <input type='text' name='name' value='$name' size='30' maxlength='100'>
      </font></td>
  </tr>
  <tr> 
    <td width='166' bgcolor='#F7F7F7' height='15'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;<font color='#000000'>Email-Address</font></font></div>
    </td>
    <td bgcolor='#D2F8FD' height='15' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp; 
      &nbsp; 
      <input type='text' name='email' value='$email ' size='30' maxlength='100'>
      </font></td>
  </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='30'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;���˹�/˹�ҷ��</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='30' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;&nbsp; 
              <input type='text' name='level' value='$level ' size='30' maxlength='100'>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='30'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�͹��дѺ</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='30' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp; 
              &nbsp; ";
			  $bselect = "";
			  $mselect = "";
			  $dselect = ""; 
			  if ($bachelor == '��ԭ�ҵ��')
				{	
					$bselect = "checked"; 
				}
				if ($master == '��ԭ���') 
              { 
				  $mselect = "checked"; 
				}
				if ($doctor == '��ԭ���͡')
				{
					$dselect = "checked"; 
				}
				echo" 
              <input type='checkbox' name='bachelor' value='��ԭ�ҵ��' $bselect>
              ��ԭ�ҵ�� &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
              <input type='checkbox' name='master' value='��ԭ���' $mselect>
              ��ԭ��� &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; 
              <input type='checkbox' name='doctor'  value='��ԭ���͡' $dselect>
              ��ԭ���͡</font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='30'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�ԧ����ǹ���</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='30' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;&nbsp;&nbsp; 
              <input type='text' name='tlink' value='$tlink' size='30' maxlength='100'>
              ������ҡ���� 1 �ԧ�� ��سҤ�蹴�������ͧ���� , �� www.yahoo.com,www.ce.kmitl.ac.th 
              �繵�</font> </td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;�س�ز� 
                �Ң��Ԫ� ʶҹ����֡��</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
              &nbsp;&nbsp; 
              <textarea name='graduation' rows='5' cols='60'>$graduation </textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;�ŧҹ�ҧ�Ԫҡ��</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='2'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
              &nbsp;&nbsp; 
              <textarea name='research' cols='60' rows='5'>$research</textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'> 
                &nbsp; ���ҧ�͹</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp;
<textarea name='course' cols='60' rows='5'>$course</textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���Ҿ����Ե</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
              <textarea name='meeting' cols='60' rows='5'>$meeting</textarea>
              </font></td>
          </tr>
		   <tr> 
            <td width='168' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>����ʹ�</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='3'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
              <textarea name='interest' cols='60' rows='5'>$interest</textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>���ʺ��ó�����</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
              <textarea name='experience' cols='60' rows='5'>$experience</textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='30'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�������Ѿ��</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='30' colspan='2'> <font size='2' face='Tahoma, Microsoft Sans Serif'> 
              &nbsp;&nbsp; 
              <input type='text' name='telephone' value='$telephone' size='30' maxlength='30'>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='100'> 
              <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>�������Դ���</font></div>
            </td>
            <td bgcolor='#D2F8FD' height='100' colspan='2'> <font face='Tahoma, Microsoft Sans Serif' size='2'>&nbsp;&nbsp; 
              <textarea name='address' cols='60' rows='5'>$address</textarea>
              </font></td>
          </tr>
          <tr> 
            <td width='166' bgcolor='#F7F7F7' height='30'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
            <td bgcolor='#D2F8FD' height='30' colspan='2'> 
              <div align='center'> <font face='Tahoma, Microsoft Sans Serif' size='2'> 
                <input type='submit' name='Submit' value='�ѹ�֡'>
                &nbsp; 
                <input type='reset' name='Submit2' value='¡��ԡ'>
                <input type='hidden' name='temp' value='$temp'>
                <input type='hidden' name='idold' value='$id'>
                <input type='hidden' name='pictureold' value='$picture'>
                </font></div>
            </td>
          </tr>
        </table>";
		?>
    </td>
		  </form>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
