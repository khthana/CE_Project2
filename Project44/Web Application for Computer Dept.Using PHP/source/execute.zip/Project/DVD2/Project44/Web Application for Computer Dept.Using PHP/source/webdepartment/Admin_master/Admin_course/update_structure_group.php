<html>
<head>
<title>��䢢������Ң��Ԫ���ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0"  align = 'center'>
<?
include ("connect_course.inc.php");
 echo "
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='11' bgcolor='#DAEEFE' >&nbsp;</td>
    <td width='142' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
       <a href='introduce_update.php?course_year=$course_year'
		target ='_parent'>�����ѡ�ٵû�ԭ���</a><br>
      <a href='structure_update_course.php?course_year=$course_year' target ='_parent'>����ç���ҧ��ѡ�ٵ�</a><br>
		<a href='structure_update_category.php?course_year=$course_year' target ='_parent'>�����Ǵ�Ԫ�</a><br>
	  ����Ң��Ԫ�<br>
		<a href='Master/Update/Subject/update_subject.php?course_year=$course_year' target ='_parent'>�������Ԫ�</A><br>
	  <a href='Master/Update/Course/update_course.php?course_year=$course_year' target ='_parent'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;
		</td>
    <td width='619' valign='top' > ";
					$pass = "yes";
for ($cindex = 1; $cindex < $category_index; $cindex++)
{
					$gindex = 1;					
		while (($gindex < $group_count[$cindex]) &&($pass != 'no'))
		{
					$gs = strlen($gsubject_new[$cindex][$gindex]);
					//$p = strlen($gprogram_unit_new[$cindex][$gindex]);
					if ((($gs == 0)) AND ($category_have_group[$cindex] == 'YES' ))
							{
									$pass = "no";
							}
					$gindex++;
		}
} //end of for
$c = 1;
$pass_repeat = "yes";
while(($c<$category_index)&&($pass_repeat == 'yes'))
{
					$g1 = 1;
			while(($g1<$group_count[$c])&&($pass_repeat == 'yes'))
			{
					$g2 = $g1+1;
					while(($g2<$group_count[$c])&&($pass_repeat == 'yes'))
					{
						if (($gsubject_new[$c][$g1]) == ($gsubject_new[$c][$g2]))
							{
								$pass_repeat = "no";
							}
					$g2++;
					}
					$g1++;
			}
					$c++;
}
$cin = 1;
while (($cin < $category_index)&&($pass == 'yes')&&($pass_repeat == 'yes'))
{
		$gin = 1;
		while ($gin < $group_count[$cin])
		{
			if ($category_have_group[$cin] == 'YES' )
			{
			$gsubject_new[$cin][$gin] = htmlspecialchars($gsubject_new[$cin][$gin]);
			$gprogram_unit_new[$cin][$gin] = htmlspecialchars($gprogram_unit_new[$cin][$gin]);
			$gdetail_new[$cin][$gin] = htmlspecialchars($gdetail_new[$cin][$gin]);
			$gdetail_new[$cin][$gin] = eregi_replace(" ","&nbsp;",$gdetail_new[$cin][$gin]);
			$gsubject = $gsubject_new[$cin][$gin];
			$gprogram_unit = $gprogram_unit_new[$cin][$gin];
			$gdetail = $gdetail_new[$cin][$gin];
			$group_old = $group[$cin][$gin];
			$query_delete = "DELETE  FROM $Gsubjecttable Where Course_year = '$course_year' AND Category = '$category_old[$cin]' AND Gsubject = '$group_old' "; 
		    $result_delete = mysql_db_query($dbName,$query_delete);
			
			$sql = "INSERT INTO $Gsubjecttable(Course_year,Category,Gsubject,Gprogram_unit,Gdetail) VALUES ('$course_year','$category_old[$cin]','$gsubject','$gprogram_unit','$gdetail')";
			$result = mysql_db_query($dbName,$sql);
			$query_update = "Update $Subjecttable Set Gsubject = '$gsubject' Where Course_year = '$course_year' AND Category = '$category_old[$cin]' AND Gsubject = '$group_old' ";
		   $result_update = mysql_db_query($dbName,$query_update);  
		   }
			$gin++;
		}
	$cin++;
}
if ($pass == 'no')
{
		echo"
			 <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
 }
 else if ($pass_repeat == 'no')
{
		echo"
			 <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������Ң��Ԫҫ�����Ǵ�Ԫ����ǡѹ��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
 }
 else if ( $pass == 'yes' )
{
echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
			<div align='center'><font size='2'><font face='Tahoma'>��������ѡ�ٵ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'structure_update_group.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			</tr></table>";
			MYSQL_CLOSE();
			}
?>
			
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
