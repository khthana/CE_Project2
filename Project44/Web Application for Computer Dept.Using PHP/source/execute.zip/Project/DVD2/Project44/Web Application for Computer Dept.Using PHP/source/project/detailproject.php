<?session_start();
  if($id[0]!='')
  {
 ?>        
<html>
<head>
<title>detailproject</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
 </head>
<?
$error=0;
 include("connect.inc.php");
$dbname=project();
$y=date("Y");
if($submit)
{
   //ź������ç�ҹ�ѵ���ѵ�����ͨ� 1 ��
 //  $sql="select * from  stuproject  where year!='$y'";
 //  $dbquery=mysql_db_query($dbname,$sql)or die("error01");
 //  $rows=mysql_num_rows($dbquery);
 //   if($rows!=0)
//	{
//	  $result=mysql_fetch_array($dbquery);
	   //ź record 㹵��ҧ stuproject 
//	  $sql="delete from stuproject where year ='$result[year]'";
//	  $dbquery=mysql_db_query($dbname,$sql)or die("error6"); 
//	}
   if($num==1)
	{
	if(($name[1]!='')&&($code[1]!='')&&($gpa[1]!=''))
	 {
	//��������ŧ���ҧ stuproject
   $sql="insert into stuproject (name1,code1,gpa1,topicid,year) values ('$name[1]','$code[1]','$gpa[1]','$id1','$y')";
   $dbquery=mysql_db_query($dbname,$sql)or die("error0"); 
	 }
    else
	 {
	  $error='1';	
     }
   }
   elseif($num==2)
    {
    if(($name[1]!='')&&($code[1]!='')&&($gpa[1]!='')&&($name[2]!='')&&($code[2]!='')&&($gpa[2]!='')&&($code[1]!=$code[2]))
	  {
	//��������ŧ���ҧ stuproject
   $sql="insert into stuproject (name1,code1,gpa1,name2,code2,gpa2,topicid,year) values ('$name[1]','$code[1]','$gpa[1]','$name[2]','$code[2]','$gpa[2]','$id1','$y')";
   $dbquery=mysql_db_query($dbname,$sql)or die("error0");
	 }
      else
	 {
	  $error='1';	
     }   
	} 
    elseif($num==3)
    {
   if(($name[1]!='')&&($code[1]!='')&&($gpa[1]!='')&&($name[2]!='')&&($code[2]!='')&&($gpa[2]!='')&&($name[3]!='')&&($code[3]!='')&&($gpa[3]!='')&&($code[1]!=$code[2])&&($code[2]!=$code[3])&&($code[3]!=$code[1]))
	  {
	//��������ŧ���ҧ stuproject
   $sql="insert into stuproject (name1,code1,gpa1,name2,code2,gpa2,name3,code3,gpa3,topicid,year) values ('$name[1]','$code[1]','$gpa[1]','$name[2]','$code[2]','$gpa[2]','$name[3]','$code[3]','$gpa[3]','$id1','$y')";
   $dbquery=mysql_db_query($dbname,$sql)or die("error0");
      }
      else
	 {
	  $error='1';	
     }  
	} 
    elseif($num==4)
      {
  if(($name[1]!='')&&($code[1]!='')&&($gpa[1]!='')&&($name[2]!='')&&($code[2]!='')&&($gpa[2]!='')&&($name[3]!='')&&($code[3]!='')&&($gpa[3]!='')&&($name[4]!='')&&($code[4]!='')&&($gpa[4]!='')&&($code[1]!=$code[2])&&($code[1]!=$code[3])&&($code[2]!=$code[3])&&($code[3]!=$code[4])&&($code[4]!=$code[1])&&($code[4]!=$code[2]))
	  {
	//��������ŧ���ҧ stuproject
   $sql="insert into stuproject (name1,code1,gpa1,name2,code2,gpa2,name3,code3,gpa3,name4,code4,gpa4,topicid,year) values ('$name[1]','$code[1]','$gpa[1]','$name[2]','$code[2]','$gpa[2]','$name[3]','$code[3]','$gpa[3]','$name[4]','$code[4]','$gpa[4]','$id1','$y')";
   $dbquery=mysql_db_query($dbname,$sql)or die("error0");
      }
      else
	 {
	  $error='1';	
     }
	}
  if($error=='1')
    {
?>
    <div align="center">
  <br>
  <p><br><font face="Tahoma,Ms Sans Serif" size="5" color="#FF0000">�����żԴ��Ҵ</font></p>
  <p><font face="Tahoma,Ms Sans Serif" size="2" color="#FF0000"><b>��س������������ú��ǹ����ó�</b></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div> 
<?	
  }
else
  {
	?>
<div align="center">
  <p><br>
    <br>
    <font face="Tahoma,Ms Sans Serif" size="4" color="#0033FF"><b><font size="5">Complete</font></b></font></p>
  <p><font color="#0033FF" face="Tahoma,Ms Sans Serif" size=3>����� project �ͧ�س�١�Ѵ�����º��������</font></p>
 <p><font color="#0033FF" face="Tahoma,Ms Sans Serif" size=3>��سҵ�Ǩ�ͺ����� project �ͧ�س��Ҷ١���͡�������</font></p>  
 <a href='indexs.php' class=home>BACK TO HOME</a>
	<hr width="400">
  <br>
</div>
<?
 }
}
else
{
$sql="select * from topicproject where id='$id1' ";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");
$result=mysql_fetch_array($dbquery);
$result[make1]=ereg_replace("&nbsp;"," ",$result[make1]);
$result[make2]=ereg_replace("&nbsp;"," ",$result[make2]);
$result[detail]=ereg_replace("&nbsp;"," ",$result[detail]);

?>
<body bgcolor="#FFFFFF">
<table width="760" border="0" align=center height="600">
  <tr> 
      
    <td height="758"> 
      <table width="760" border="0">
    <tr> 
      <td width="18%"> 
        <div align="center"><img src="images/logo-kmitl.gif" width="139" height="137"></div>
      </td>
      <td width="13%"><br></td>
      <td width="46%">
        <div align="center">
          <p><font face="Tahoma,Ms Sans Serif" size="4"><b>�ʹ��ç�ҹ<br><br>
            �Ҥ�Ԫ����ǡ�������������</b></font> </p>
        </div>
      </td>
      <td width="23%">&nbsp;</td>
    </tr>
  </table>
<br>  
  
      <table width="760" border="1" height="40%" cellspacing="1" cellpadding="3">
        <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3" >�����ç�ҹ(��)</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?print($result[topic_t]);?>
      </b></font></td>
  </tr>
  <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�����ç�ҹ(�ѧ���)</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?print($result[topic_e]);?>
      </b></font></td>
  </tr>
  <?
	if($result[advisor1])
	  {
	?>
  <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�Ҩ�������֡��</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?print($result[advisor1]);?>
      </b></font></td>
  </tr>
  <?
	  }
	
	if($result[advisor2])
	  {
	?>
  <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�Ҩ�������֡��</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?print($result[advisor2]);?>
      </b></font></td>
  </tr>
  <tr> 
    <?
	  }
	?>
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�ӹǹ�ѡ�֡�ҷ���ͧ���</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?print($result[num]);?>
      &nbsp;&nbsp;�� </b></font>&nbsp;&nbsp;</td>
  </tr>
  <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�ѵ�ػ��ʧ��</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?$result[make1]=ereg_replace(" ","&nbsp;",$result[make1]);print($result[make1]);?>
      </b></font></td>
  </tr>
  <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�ŷ������Ѻ</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?$result[make2]=wordwrap($result[make2],140,"<br>",1);$result[make2]=ereg_replace(" ","&nbsp;",$result[make2]);print($result[make2]);?>
      </b></font></td>
  </tr>
  <tr> 
    <td width="35%" valign=top> 
      <div align="left"><b>&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="3">�����������</font></b></div>
    </td>
    <td valign=top width="65%" bgcolor="#F6F6F6">&nbsp;&nbsp;<font face="Tahoma,Ms Sans Serif" size="2" color=#535353><b> 
      <?$result[detail]=ereg_replace(" ","&nbsp;",$result[detail]);print($result[detail]);?>
      </b></font></td>
  </tr>
</table>
        
<font face="Tahoma,Ms Sans Serif" size="3"><br>
</font>
<table width="760" border="0">
  <tr>
    <td>
      <div align="center"><font face="Tahoma,Ms Sans Serif" size="3"><font color="#FF0000" size="4">���͡�ç�ҹ</font></font> 
      </div>
    </td>
  </tr>
</table>
<br>
   
  <FORM METHOD=POST ACTION="detailproject.php">
  <table width="766" border="0" cellspacing="1" cellpadding="3" bordercolor="#FFFFFF">
    <?print("<INPUT TYPE='hidden' name=num value=$result[num]>");
		       print("<INPUT TYPE='hidden' name=id1 value=$id1>");
		       $c=1;
		       while($result[num]>=$c)
			   {
          ?>
    <tr> 
            
      <td width="12%" bgcolor="#CCCCCC"> 
        <div align="center"><font face="Tahoma,Ms Sans Serif" size="2">����/ʡ��</font></div>
            </td>
            
      <td width="29%"><font face="Tahoma,Ms Sans Serif" size="3"> 
        <?print("<input type='text' name='name[$c]' size='40' maxlength='40'>");?>
        </font></td>
            
      <td width="6%" bgcolor="#CCCCCC"> 
        <div align="center"><font face="Tahoma,Ms Sans Serif" size="2">����</font></div>
            </td>
            
      <td width="22%"><font face="Tahoma,Ms Sans Serif" size="3"> 
        <?print("<input type='text' name='code[$c]' size='30' maxlength='10'>");?>
        </font></td>
            
      <td width="17%" bgcolor="#CCCCCC"> 
        <div align="center"><font face="Tahoma,Ms Sans Serif" size="2">�ô�����</font></div>
            </td>
            
      <td width="14%"><font face="Tahoma,Ms Sans Serif" size="3"> 
        <?print("<input type='text' name='gpa[$c]' size='6' maxlength='6'>");?>
        </font></td>
          </tr>
          <?
		    $c++;
			  }//while
		  ?>          
        </table>
             

        <div align="center"><br>
          <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
          &nbsp; 
          <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=Cancle name=cancle>
        </div>
</form>
<br>
 <br>
<?
}
  //�Դ�ҹ������
closedb();
?>
   </td>
</tr>

</table>
</body>
</html>
<?
}
else
   {
?>
     <div align="center">
  <p><br>
    <font face="Tahoma,Ms Sans Serif" size="3" color="#FF0000">�����żԴ��Ҵ</font></p>
  <p><font face="Tahoma,Ms Sans Serif" size="2" color="#FF0000">���ͧ�ҡ�س�ӼԴ��鹵͹��ô���������´��Ǣ���ç�ҹ�ͧ�к�</font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div>
<?   
   }
?>