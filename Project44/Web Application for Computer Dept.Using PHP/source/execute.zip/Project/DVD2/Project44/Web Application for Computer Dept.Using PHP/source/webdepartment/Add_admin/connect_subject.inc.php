<?
	$hostname = "localhost";
	$username = "root";
	$password = "webmaster123";
	
	$Assignmenttable = "Assignment";
	$Examinetable = "Examine";
	$Linkstable = "Links";
	$Membertable = "Member";
	$Newstable = "News";
	$Scheduletable = "Schedule";
	$Scoretable = "Score";
	$Studenttable = "Student";
	$Subjecttable= "Subject";
	$Worktable = "Work";
    $dbName = "Homepage";
	MYSQL_CONNECT($hostname,$username,$password)
	OR DIE("Unable to connect to database");
	@mysql_select_db("$dbName") or die
	("Unable to select database");
?>