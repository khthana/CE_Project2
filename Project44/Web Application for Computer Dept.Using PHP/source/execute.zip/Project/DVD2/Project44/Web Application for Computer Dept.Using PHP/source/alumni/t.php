<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<form method=post action="re_question.php" name="ReForm1" onSubmit="return check()">
  <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="80" cellpadding="1" align="center">
    <td bgcolor="#CCCCFF" height="15"> 
      <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="1" color="#FFFFFF" class="fsize8" align="center"><b><font size="3" color="#333333">������ʹѡ�֡��</font></b></font></div>
    </td>
    </tr>
    <tr valign="top"> 
      <td height="59" bgcolor="#FFFFFF"> 
        <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
          <tr> 
            <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
              <div align="center"> 
                <div align="center"><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="1"> 
                  <input type="text" name="re_question" size="14">
                  </font> </div>
              </div>
            </td>
          </tr>
          <tr> 
            <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
              <div align="center"> <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
                <input type='image' border='0' name='imageField12' src='image/go.jpg' width='19' height='19' alt='re_passwd'>
                </font></div>
            </td>
          </tr>
        </table>
      </td>
  </table>
  <hr width="80%">
</form>
<script language="JavaScript">
<!--
function check()
{
      var v1 = document.ReForm1.re_question.value;
        if ( v1.length==0)
           {
           alert("��س�������ʹѡ�֡�Ңͧ��ҹ");
           document.ReForm1.re_question.focus();
           return false;
           }
		 else
           return true;
}
//-->
</script>
</body>
</html>
