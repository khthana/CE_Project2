<html>
<head>
<title>���͡��ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><img src="images/l.gif" width="1" height="20"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
  <tr> 
    <td width="1" >&nbsp;</td>
    <td width="16" bgcolor="#D2F8FD" >&nbsp;</td>
    <td width="150" bgcolor="#D2F8FD" valign="top" ><font size="2" face="Tahoma"><br>
      <a href="introduce_insert.php">���ҧ��ѡ�ٵû�ԭ�ҵ��</a></font><font face="Tahoma" size="2" color="#9900CC"><br>
      �����ѡ�ٵû�ԭ�ҵ��<br>
        <a href="show_delete.php">ź��ѡ�ٵû�ԭ�ҵ��</a><br>
      <a href="index.php">�ʴ���ѡ�ٵû�ԭ�ҵ��</a> <br>
      <a href="select_course.php">���͡����ѡ�ٵûѨ�غѹ</a><br>
	  <a href='../../index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;</td>
    <td width="611" valign="top" >
      <table width="600" border="1" cellspacing="0" cellpadding="0" align="center" bordercolor="#FFFFFF">
        <tr bgcolor="#F7F7F7"> 
          <td colspan="3" height="38"> 
            <div align="center"><font size="2" face="Tahoma">��ѡ�ٵû�ԭ�ҵ�շ���������Ҥ�Ԫ����ǡ��������������Դ�͹</font></div>
          </td>
        </tr>
        <tr bgcolor="#D2F8FD">
          <td colspan="3" height="30">
            <div align="center"><font face="Tahoma" size="2" color="#0000FF">���͡��ѡ�ٵû�ԭ�ҵ�շ���ͧ�����䢢�����</font></div>
          </td>
        </tr>
        <tr bgcolor="#D2F8FD"> 
          <td width="125" height="32"> 
            <div align="center"><font size="2" face="Tahoma">�ӴѺ���</font></div>
          </td>
          <td width="285" height="32"> 
            <div align="center"><font size="2" face="Tahoma">������ѡ�ٵ�</font></div>
          </td>
          <td width="182" height="32"> 
            <div align="center"><font size="2" face="Tahoma">ʶҹ�</font></div>
          </td>
        </tr>
        <?
	include ("connect_course.inc.php");

	$query = "Select * From $Introducetable";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	$count=1;
	if ($i < $number) {
			// select course_year from select_course table	
					$query_select = "Select * From $Select_coursetable";
					$result_select = mysql_query($query_select);
					$snumber = mysql_numrows($result_select);
					$si=0;
						if ($si < $snumber)
						{
							while ($row = mysql_fetch_array($result_select))
								{
								$course_year_select = htmlspecialchars($row[Course_year]);
								}
						}
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
		echo "
		<tr bgcolor='#F7F7F7'> 
          <td width='125' height='30'> 
            <div align='center'><font size='2' face='Tahoma'>$count</font></div>
          </td>
          <td width='285' height='30' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma'><A HREF='introduce_update.php?course_year=$course_year'>��ѡ�ٵ�$course_year</A></font></div>
          </td>";
			if ($course_year == $course_year_select)
			{
		echo "
          <td width='182' height='30'> 
            <div align='center'><font size='2' face='Tahoma'>��ѡ�ٵûѨ�غѹ</font></div>
          </td></tr>";
			}
		  else
			  {
		echo "
          <td width='182' height='30'> 
            <div align='center'><font size='2' face='Tahoma'>��ѡ�ٵ����</font></div>
          </td></tr>";
			}
        $count++;
		}
	}

		?>
        <tr bgcolor="#D2F8FD"> 
          <td width="125" height="30"><font size="2" face="Tahoma">&nbsp;</font></td>
          <td width="285" height="30"><font size="2" face="Tahoma">&nbsp;</font></td>
          <td width="182" height="30"><font size="2" face="Tahoma">&nbsp;</font></td>
        </tr>
        <tr bgcolor="#F7F7F7"> 
          <td width="125" ><font size="2" face="Tahoma">&nbsp;</font></td>
          <td width="285" ><font size="2" face="Tahoma">&nbsp;</font></td>
          <td width="182" ><font size="2" face="Tahoma">&nbsp;</font></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
