<?   session_start();
		include ("md5.js");
		include("connect.inc.php");
		if($login=='Submit')
		 {
			session_unset();
			$dbname=gwebboard();
			  $sql="select * from user where email ='$email'";
	          $dbquery=mysql_db_query($dbname,$sql) or die("error1");
	          $rows=mysql_num_rows($dbquery);
			if($rows>0)
			 {
			   while($result=mysql_fetch_array($dbquery))
				 { 
		       $pwd2=MD5(MD5($result[pass]).$random);
			   if($pwd2==$pwd)
			     { 
			      session_unset();
			      //session_start();
			     //session_destroy();
		         $id=array($result[email]);
                 session_register(id);
			     }
				 }//while
			 }
			//�Դ�ҹ������
            closedb();
		 }
?>
<html>
<head>
<title>Group Webboard</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</head>
<?
if($id[0])
 {
 ?>        
  <body bgcolor="#FFFFFF">
     <?print("<META HTTP-EQUIV='REFRESH' Content=0;URL=indexs.php>");?>
 </body>
</html>
<?
 }	
else
{
?>
<body bgcolor="#FFFFFF">
<table width="640" cellspacing=0 border=0 align=left>
<tr class=a>
<td>
<br>
<div align="center">
  <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>��سҵ�Ǩ�ͺ username&password �ͧ�س�����ա����</b></font></font></p>
  <a href='login.php' class=home>BACK</a>
<hr width="400">
  <p>&nbsp;</p>

 </div>
</body>
</html>
<?
 }
?>