<?session_start();
    session_unset();
   session_destroy();

include ("md5.js");
$rn=rand();
?>
<HTML>
<HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</HEAD>
<BODY text=#ffff00 bgColor=#ffffFF leftMargin=0 topMargin=0>
<table border=0  width="760" align=left height="640">
  <tr class=a>
    <td valign="top"> 
<img src="images/logo.gif" width="305" height="74">
<br>
<br>
      <br>
      <br>     
	  <table border=0 align=center width="760" height="260" >
        <tr class=a>
          <td valign="top" height="220"> 
            <table bgcolor=#6666FF border=1 align=center cellspacing="0" cellpadding="0" bordercolor="#FFFFFF" height="100" width="484">
        <tr class=a>
          <td bgcolor="#FFFFFF" height="209" valign="top"> 
            <FORM name=login onsubmit="return check();" 
action='indexs.php' method=post  autocomplete="off">
<INPUT type=hidden  name='random' value=<?print("$rn");?>>
              <TABLE width=316 align=center height="166" cellspacing="0" bordercolor="#000099" border="1" cellpadding="0">
                <TBODY> 
                <TR bgcolor="#003060"> 
                  <TD  align=right colSpan=3 height="15" class=a> 
                    <DIV align=center><B><font color="#FFFFFF" >LOGIN</font></B></FONT></DIV>
                  </TD>
                </TR>
                <tr bordercolor="#F5F5F5" bgcolor="#F5F5F5"> 
                  <TD  align=right height="30" width="117" bordercolor="#F5F5F5" class=a><font color="#0000FF" >E-Mail
                    :</font><FONT color=#cccc00>&nbsp;</FONT></TD>
                  <TD class=a height="30" width="126">&nbsp; 
                    <INPUT TYPE="text" style="FONT-SIZE: 10pt; FONT-FAMILY:Tahoma,Ms Sans Serif " NAME="email" size=15>
                   </TD>
                  <TD class=a height="30" width="65">&nbsp;</TD>
                </TR>
                <TR bordercolor="#F5F5F5" bgcolor="#F5F5F5"> 
                  <TD  align=right height="32" width="117" bordercolor="#F5F5F5" class=a><font color="#0000FF" >password 
                    :</font><b><FONT color=#cccc00>&nbsp;</FONT></b></TD>
                  <TD class=a height="32" width="126">&nbsp; 
                    <INPUT TYPE="password" style="FONT-SIZE: 10pt; FONT-FAMILY:Tahoma,Ms Sans Serif "  NAME="pwd" size=15 maxlength=6 >
                   </TD>
                  <TD class=a height="32" width="65">&nbsp;</TD>
                </TR>
                <TR bgcolor="#F5F5F5" bordercolor="#F5F5F5"> 
                  <TD class=a align=middle colSpan=3 height="31"> 
                    <div align="center"> 
                      <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; width:52px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=login>&nbsp;
                      <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; width:52px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel>
                    </div>
                  </TD>
                </TR>
                <TR align="left" valign="top" bgcolor="#006A9D"> 
                  <TD  colspan="3" height="26" class=a> 
                          <div align="center"><b><font color="#00CC00"><a href="changepass.php" class=help>change 
                            password</a> <font color="#FF6666" >|</font> <a href="forgetpass.php" class=help>forget 
                            password</a> </font></b></div>
                  </TD>
                </TR>
                <TR bgcolor="#003060"> 
                  <TD class=a align=middle height="17" colSpan=3> 
                    <div align="center" valign=middle><a href='index.php' class=help><b>HOME<b></a></div>
                  </TD>
                </TR>
                </TBODY> 
              </TABLE>
            </FORM>
	</td>
	</tr>
</table>
    
<script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.login.email.value;
      var v2 = document.login.pwd.value;
  	      	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.login.email.focus();           
		   return false;
           }
        else if ( v2.length==0)
           {
           alert("��س������������ú��ǹ");
           document.login.pwd.focus();           
           return false;
           }
    	else
           return hash(login,'redir.php');
}
//-->
</script></div>
            <br>
            <table width="760" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td class=a> 
                  <div align="center"><font color="#000080">Department of Computer 
                    Engineering Faculty of Engineering King Mongkut's Institute 
                    of Technology<br>
                    Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
                    �觤ӵ����� </font><a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a> </div>
                </td>
              </tr>
              <tr> 
                <td height="8" class=a> 
                  <hr align="center" width="550" >
                </td>
              </tr>
              <tr> 
                <td> 
                  <div align="center"></div>
                </td>
              </tr>
            </table>
          </td>
</tr>
</table>
    </td>
</tr>
</table>
</BODY>
</HTML>