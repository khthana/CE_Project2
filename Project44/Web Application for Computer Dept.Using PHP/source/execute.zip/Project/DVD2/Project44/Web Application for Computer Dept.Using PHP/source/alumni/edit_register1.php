<?php
	session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><img src="image/logo-kmitl.jpg" width="139" height="137"></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="137">
                <tr> 
                  <td><img src="image/logo-alumni.jpg" width="600" height="80"></td>
                </tr>
                <tr> 
                  <td>
                    <table width="100%" border="0" cellspacing="1" cellpadding="1"align="left" bordercolor="#000000" bgcolor="#000000">
                      <tr class = BNFont1 align="center"> 
                        <td bgcolor="#99CCFF" width="25%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="index.php"><b>Home</b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="register_form.php"><b>ŧ����¹</b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="login.php"><b>��䢢�����</b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td>
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000" height="100%">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="normal.php"><b>�Ҥ����</b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="cont.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="cont.php"><b>�Ҥ������ͧ</b></a></font> 
                          <font face="MS Sans Serif, CordiaUPC" size=3><a href="normal.php"><b></b></a></font></td>
                      </tr>
                      <tr>
                        <td width="20" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                        <td width="78%" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        
                          <td bgcolor="#CCCCFF" height="15"> 
                            <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1" color="#FFFFFF" class="fsize8" align="center"><b>&nbsp;<font color="#000000" size="2">����</font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                  </div>
                                </td>
                              </tr>
                            </table>
                          </td>
                        
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF" height="100%">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624"> 
              <div align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                  <tr>
                    <td> 
                      <div align="center">
                        <?php
	include("alumni.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql1= "SELECT * FROM data_alumni WHERE 
    std_username = '$login[name]' AND 
    std_password1 = '$login[password]'"; 
	$db_query1 = mysql_db_query($dbname, $sql1);
	$nums_rows1 = mysql_num_rows($db_query1);
	if($nums_rows1=="1"){
		for ($i=0;$i<$nums_rows1;$i++){
		$result = mysql_fetch_array($db_query1);
		$std_number = $result[std_number];
		$login[1]=$std_number;
		$std_id = $result[std_id ];
		$std_class = $result[std_class];
		$std_fullname = $result[std_fullname];
		$std_sname = $result[std_sname];
		$std_type1 = $result[std_type1];
		$std_nick = $result[std_nick];
		$std_type = $result[std_type];
		$std_days  = $result[std_days];
		$std_day  = $result[std_day];
		$std_mount  = $result[std_mount];
		$std_year  = $result[std_year];
		$std_position = $result[std_position ];
		$std_address_born = $result[std_address_born];
		$std_address_now= $result[std_address_now];
		$std_tel_home= $result[std_tel_home];
		$std_tel_work = $result[std_tel_work];
		$std_pager  = $result[std_pager];
		$std_icq  = $result[std_icq];
		$std_email  = $result[std_email];
		$std_homepage  = $result[std_homepage];
		$std_username  = $result[std_username];
		$std_password1 = $result[std_password1];
		$std_password2  = $result[std_password2];
		if ($std_password1 == $login[password]){ 

		
		$std_id=stripslashes($std_id);
		$std_class = stripslashes($std_class);
		$std_fullname = stripslashes($std_fullname);
		$std_sname = stripslashes($std_sname);
		$std_type1 = stripslashes($std_type1);
		$std_nick = stripslashes($std_nick);
		$std_type = stripslashes($std_type);
		$std_days  = stripslashes($std_days);
		$std_day  = stripslashes($std_day);
		$std_mount  = stripslashes($std_mount);
		$std_year  = stripslashes($std_year);
		$std_position = stripslashes($std_position );
		$std_address_born = stripslashes($std_address_born);
		$std_address_now= stripslashes($std_address_now);
		$std_tel_home= stripslashes($std_tel_home);
		$std_tel_work = stripslashes($std_tel_work);
		$std_pager  = stripslashes($std_pager);
		$std_icq  = stripslashes($std_icq);
		$std_email  = stripslashes($std_email);
		$std_homepage   = stripslashes($std_homepage);

		print "<Form Action=\"to_edit.php\" Method=Post>";
		print "<Center>";
        print "<table width=100% border=0 cellspacing=0 cellpadding=0>";
		print "<tr>";
		print "<td>";
       print "<table width=100% border=0 cellspacing=0 cellpadding=0>";
      print "<tr>";
     print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\" size=3>���ʹѡ�֡��<font color=#FF0000> * </font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
     print "<input size=30 name=std_id value=$std_id>";
     print "</font></td>";
     print "</tr>";
     print "<tr>";
     print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>��蹷��<font color=#FF0000> ";
      print "*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
	  print "<input type=text size=30 name=std_class value=$std_class >";
      print "</font></td>";
      print "</tr>";
	  print " <tr>";
      print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\" size=3>�ѡ�֡�� <font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\" size=3>";                                 
	  print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
	  if($std_type=="������ͧ"){
	  print "<input type=radio name=std_type value=������ͧ checked>";
	  print "������ͧ <input type=radio name=std_type value=����> ���� </font>";
	  }
	  else{
	  print "<input type=radio name=std_type value=������ͧ>";
	  print "������ͧ <input type=radio name=std_type value=���� checked> ���� </font>";
	  }
	  print " </td></tr> <tr>";
      print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���� ";
      print "<font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
      print "<input size=30 name=std_fullname value=$std_fullname>";
      print "</font></td>";
      print "</tr>";
      print "<tr>";
      print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���ʡ�� ";
      print "<font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
      print "<input size=30 name=std_sname value=$std_sname>";
      print "</font></td>";
      print "</tr>";
      print "<tr>";
      print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�� ";
      print "<font color=#FF0000>*</font></font> </td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
      print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
	  if($std_type1=="���"){
		print "<input type=radio name=std_type1 value=��� checked>";
		print "���";
		print "<input type=radio name=std_type1 value=˭ԧ>";
		print "˭ԧ </font>";
	  }
	  else{
		print "<input type=radio name=std_type1 value=���>";
		print "���";
		print "<input type=radio name=std_type1 value=˭ԧ checked>";
		print "˭ԧ </font>";
	  }
      print "</td></tr>";
      print "<tr>";
      print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>������� ";
      print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
      print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
      print "<input size=30 name=std_nick value=$std_nick>";
      print "</font></td>";
      print "</tr>";
     print "<tr>";
     print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ѹ�Դ ";
     print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
     print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ѹ ";
     print "<select name=days>";

	if($std_days=="�ѹ���"){
		 print "<option value=�ѹ��� selected>�ѹ��� ";
	}
	else{
		 print "<option value=�ѹ���>�ѹ��� ";
	}

	if($std_days=="�ѧ���"){
	     print "<option value=�ѧ��� selected>�ѧ��� ";
	}
	else{
	     print "<option value=�ѧ���>�ѧ��� ";
	}

	if($std_days=="�ظ"){
     print "<option value=�ظ selected>�ظ ";
	}
	else{
     print "<option value=�ظ>�ظ ";
	}
	
	if($std_days=="����ʺ��"){
     print "<option value=����ʺ�� selected>����ʺ�� ";
	}
	else{
     print "<option value=����ʺ��>����ʺ�� ";
	}
	
	if($std_days=="�ء��"){
     print "<option value=�ء�� selected>�ء�� ";
	}
	else{
     print "<option value=�ء��>�ء�� ";
	}
	
	if($std_days=="�����"){
     print "<option value=����� selected>�����";
	}
	else{
     print "<option value=�����>����� ";
	}
	
	if($std_days=="�ҷԵ��"){
	     print "<option value=�ҷԵ�� selected>�ҷԵ��";
	}
	else{
		 print "<option value=�ҷԵ��>�ҷԵ�� ";
	}
     print "</select>";
     print "��� ";
     print "<select name=day>";
	 if($std_day=="1"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>1 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>1 ";
     print "</font>";
}
	 if($std_day=="2"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>2 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>2 ";
     print "</font>";
}
	 if($std_day=="3"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>3 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>3 ";
     print "</font>";
}
	 if($std_day=="4"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>4 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>4 ";
     print "</font>";
}
	 if($std_day=="5"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>5 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>5 ";
     print "</font>";
}
	 if($std_day=="6"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>6 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>6 ";
     print "</font>";
}
	 if($std_day=="7"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>7 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>7 ";
     print "</font>";
}
	 if($std_day=="8"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>8 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>8 ";
     print "</font>";
}
	 if($std_day=="9"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>9 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>9 ";
     print "</font>";
}
	 if($std_day=="10"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>10 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>10 ";
     print "</font>";
}
	 if($std_day=="11"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>11 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>11 ";
     print "</font>";
}
	 if($std_day=="12"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>12 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>12 ";
     print "</font>";
}
	 if($std_day=="13"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>13 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>13";
     print "</font>";
}
	 if($std_day=="14"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>14 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>14 ";
     print "</font>";
}
	 if($std_day=="15"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>15 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>15 ";
     print "</font>";
}
	 if($std_day=="16"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>16 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>16 ";
     print "</font>";
}
	 if($std_day=="17"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>17 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>17 ";
     print "</font>";
}
	 if($std_day=="18"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>18 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>18 ";
     print "</font>";
}
	 if($std_day=="19"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>19 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>19 ";
     print "</font>";
}
	 if($std_day=="20"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>20 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>20 ";
     print "</font>";
}
	 if($std_day=="21"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>21 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>21 ";
     print "</font>";
}
	 if($std_day=="22"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>22 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>22 ";
     print "</font>";
}
	 if($std_day=="23"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>23 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>23 ";
     print "</font>";
}
	 if($std_day=="24"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>24 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>24 ";
     print "</font>";
}
	 if($std_day=="25"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>25 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>25 ";
     print "</font>";
}
	 if($std_day=="26"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>26 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>26 ";
     print "</font>";
}
	 if($std_day=="27"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>27 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>27";
     print "</font>";
}
	 if($std_day=="28"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>28";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>28";
     print "</font>";
}
	 if($std_day=="29"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>29 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>29";
     print "</font>";
}
	 if($std_day=="30"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>30";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>30";
     print "</font>";
}
	 if($std_day=="31"){
     print "<option selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>31 ";
     print "</font>";
}
else{
     print "<option><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>31 ";
     print "</font>";
}
    print "</select>";
    print "<select name=mount>";
if($std_mount=="���Ҥ�"){
	print "<option value=���Ҥ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���Ҥ� </font>";
}
else{
	print "<option value=���Ҥ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���Ҥ� </font>";
}
if($std_mount=="����Ҿѹ��"){
    print "<option value=����Ҿѹ�� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����Ҿѹ�� </font>";
}
else{
    print "<option value=����Ҿѹ��><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����Ҿѹ�� </font>";
}
if($std_mount=="�չҤ�"){
    print "<option value=�չҤ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�չҤ� </font>";
}
else{
    print "<option value=�չҤ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�չҤ� </font>";
}
if($std_mount=="����¹"){
	print "<option value=����¹ selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����¹</font>";
}
else{
	print "<option value=����¹><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����¹</font>";
}
if($std_mount=="����Ҥ�"){
print "<option value=����Ҥ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����Ҥ� </font>";
}
else{
print "<option value=����Ҥ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����Ҥ� </font>";
}
if($std_mount=="�Զع�¹"){
print "<option value=�Զع�¹ selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�Զع�¹ </font>";
}
else{
print "<option value=�Զع�¹><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�Զع�¹ </font>";
}
if($std_mount=="�á�Ҥ�"){
print "<option value=�á�Ҥ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�á�Ҥ�</font>";
}
else{
print "<option value=�á�Ҥ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�á�Ҥ�</font>";
}
if($std_mount=="�ԧ�Ҥ�"){
print "<option value=�ԧ�Ҥ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ԧ�Ҥ� </font>";
}
else{
print "<option value=�ԧ�Ҥ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ԧ�Ҥ� </font>";
}
if($std_mount=="�ѹ��¹"){
print "<option value=�ѹ��¹ selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ѹ��¹ </font>";
}
else{
print "<option value=�ѹ��¹><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ѹ��¹ </font>";
}
if($std_mount=="���Ҥ�"){
print "<option value=���Ҥ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���Ҥ� </font>";
}
else{
print "<option value=���Ҥ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���Ҥ� </font>";
}
if($std_mount=="��Ȩԡ�¹"){
print "<option value=��Ȩԡ�¹ selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>��Ȩԡ�¹ </font>";
}
else{
print "<option value=��Ȩԡ�¹><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>��Ȩԡ�¹ </font>";
}
if($std_mount=="�ѹ�Ҥ�"){
print "<option value=�ѹ�Ҥ� selected><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ѹ�Ҥ� </font>";
}
else{
print "<option value=�ѹ�Ҥ�><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>�ѹ�Ҥ� </font>";
}
print "</select>";
 print "�.�. ";
 print "<input size=10 name=year value=$std_year></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>����ѷ(���ӧҹ) ";
 print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
 print "<textarea name=std_work rows=3 cols=40>$std_work</textarea>";
 print "</font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���˹� ";
 print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
 print "<input size=30 name=std_position value=$std_position></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>������� ";
  print "(��������)</font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
  print "<textarea name=std_address_born rows=3 cols=40>$std_address_born</textarea>";
  print "</font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>������� ";
  print "(�Ѩ�غѹ)</font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
  print "<textarea name=std_address_now rows=3 cols=40>$std_address_now</textarea>";
  print "</font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���Ѿ�� ";
  print "(��ҹ�ѡ)</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
  print "<input size=30 name=std_tel_home value=$std_tel_home></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���Ѿ�� ";
  print "(���ӧҹ) </font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
 print "<input size=30 name=std_tel_work value=$std_tel_work></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>��Ͷ��,ྨ���� ";
 print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
 print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
 print "<input size=30 name=std_pager value=$std_pager></font></td></tr><tr>";
 print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>Icq</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
  print "<input size=30 name=std_icq value=$std_icq></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>Email ";
  print "<font color=#FF0000>*</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
  print "<input size=30 name=std_email value=$std_email>";
  print "<font color=#990000><br>��س���������� �������ö�Դ��������͡óշ���ҹ��� ";
  print "password</font></font> </td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>���ྨ </font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
  print "<input name=std_homepage value='$std_homepage' size=50></font></td>";
  print "</tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>Login ";
  print "<font color=#FF0000>*</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
  print "<input size=30 name=std_username value=$std_username></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>Password<font color=#FF0000> *</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
  print "<input size=30 name=std_password1 type=password value=$std_password1>";
  print "<font  color=#990000> ��Ҵ����ա���դ����Ӥѭ</font></font></td></tr><tr>";
  print "<td width=24%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>Password ";
  print "agian<font color=#FF0000> *</font></font></td>";
  print "<td width=76%><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>";
  print "<input size=30 name=std_password2 type=password value=$std_password2>";
  print "</font><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
  print "<font color=#990000> ��Ǩ�ͺ������촴�������������������ѧ�������</font></font> ";
  print "</td></tr></table></td></tr><tr><td>";
  print "<div align=center><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3> ";
  print "<input type=submit value=Submit name=submit>";
  print "<input type=reset value=Reset name=reset>";
  print "</font></div></td></tr></table>";
   print"</center></form>";
}
 else{
	session_destroy();
	session_unset();
	print "<center><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=4 color=#003399> ";
	print "<b>USER ���� PASSWORD ���١��ͧ</b></font></center>";
	print "<META http-equiv=refresh content=\"3; URL=login.php\">";
 }	
 }
}
 else{
	session_destroy();
	session_unset();
	print "<center><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=4 color=#003399> ";
	print "<b>USER ���� PASSWORD ���١��ͧ</b></font></center>";
	print "<META http-equiv=refresh content=\"3; URL=login.php\">";
 }	
?>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td height="100%">&nbsp;</td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>

  <div align="center"> </div>
 </center>
  <script language="JavaScript">
<!--
function checks()
{
      var v1 = document.SearchForm.search.value;
        if ( v1.length==0)
           {
           alert("��سһ�͹�ӷ���ͧ��ä���");
           document.SearchForm.search.focus();
           return false;
           }
		 else
           return true;
}
//-->
</script>

</body>
</html>
