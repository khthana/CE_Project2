<?php
	session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760><TBODY>
    <tr align="left" valign="top"> 
      <td colspan="3" align="left"> 
        <p><br>
          <br>
        </p>
        <table width="80%" border="0" cellpadding="0" cellspacing="0" align="center">
          <tr> 
            <td> </td>
          </tr>
          <tr> 
            <td> 
              <?php	
							print "<FORM name=answer action='to_answer.php' method=post onSubmit='return check()'  autocomplete='off'>";
							?>
              <table cellspacing=0 cellpadding=0 width="100%" border=0 height="100%">
                <tbody> 
                <tr class=header bgcolor="#67a6c7"> 
                  <td colspan=2 align=center><font size="4" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�����ʴ������Դ���</font></td>
                </tr>
                <tr class=tablerow> 
                  <td width="24%" bgcolor=#dedfdf> 
                    <div align="right"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Name<font color="#FF0000">*</font> 
                      :</font></div>
                  </td>
                  <td bgcolor=#dedfdf width="76%"> 
                    <input size=25 name=a_name>
                    <span size=2> </span> </td>
                </tr>
                <tr class=tablerow> 
                  <td bgcolor=#dedfdf width="24%"> 
                    <div align="right"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Email 
                      :</font></div>
                  </td>
                  <td bgcolor=#dedfdf width="76%"> 
                    <input type=text size=25 name=a_email>
                  </td>
                </tr>
                <tr class=tablerow> 
                  <td valign=top bgcolor=#dedfdf width="24%"> 
                    <div align="right"><font size="2" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Message<font color="#FF0000">*</font>:<br>
                      </font></div>
                  </td>
                  <td bgcolor=#dedfdf width="76%"> 
                    <textarea name=a_message rows=9 cols=80></textarea>
                  </td>
                </tr>
                </tbody> 
              </table>
            </td>
          </tr>
          <tr> 
            <td bgcolor="#dedfdf"> 
              <div align="center">  
  <a href="javascript:setsmile(':smile:')"><img src="pics/smile.gif" border=0></a>
	<a href="javascript:setsmile(':big:')"><img src="pics/biggrin.gif" border=0></a>
	<a href="javascript:setsmile(':ent:')"><img src="pics/blue.gif" border=0></a>
	<a href="javascript:setsmile(':shy:')"><img src="pics/shy.gif" border=0></a>
	<a href="javascript:setsmile(':sun:')"><img src="pics/sunglasses.gif" border=0></a>
	<a href="javascript:setsmile(':sg:')"><img src="pics/supergrin.gif" border=0></a>
	<a href="javascript:setsmile(':embarass:')"><img src="pics/embarass.gif" 	border=0></a>
	<a href="javascript:setsmile(':dead:')"><img src="pics/dead.gif" border=0></a>
	<a href="javascript:setsmile(':cool:')"><img src="pics/cool.gif" border=0></a>
	<a href="javascript:setsmile(':clown:')"><img src="pics/clown.gif" border=0></a>
	<a href="javascript:setsmile(':pukey:')"><img src="pics/pukey.gif" border=0></a><br>
                <a href="javascript:setsmile(':eek:')"><img src="pics/eek.gif" border=0></a> 
                <a href="javascript:setsmile(':roll:')"><img src="pics/sarcblink.gif" border=0></a> 
                <a href="javascript:setsmile(':smoke:')"><img src="pics/smokin.gif" border=0></a> 
                <a href="javascript:setsmile(':angry:')"><img src="pics/reallymad.gif" border=0></a> 
                <a href="javascript:setsmile(':confused:')"><img src="pics/confused.gif" 	border=0></a> 
                <a href="javascript:setsmile(':cry:')"><img src="pics/crying.gif" border=0></a> 
                <a href="javascript:setsmile(':lol:')"><img src="pics/lol.gif" border=0></a> 
                <a href="javascript:setsmile(':yawn:')"><img src="pics/yawn.gif" border=0></a> 
                <a href="javascript:setsmile(':devil:')"><img src="pics/devil.gif" border=0></a> 
                <a href="javascript:setsmile(':tongue:')"><img src="pics/tongue.gif" border=0></a> 
                <a href="javascript:setsmile(':alien:')"><img src="pics/aysmile.gif" border=0></a> 
                <a href="javascript:setsmile(':tasty:')"><img src="pics/tasty.gif" border=0></a> 
                <a href="javascript:setsmile(':crazy:')"><img src="pics/grazy.gif" border=0></a><br>
    <font color="blue" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��ԡ����ٻ�����á�ٻŧ㹢�ͤ���</font>
				</div>
            </td>
          </tr>
          <tr>
            <td bgcolor="#dedfdf" nowrap> 
              <div align="center">
                <input type=submit value=Submit name=topicsubmit>
                <input type=reset value=reset name=topicreset>
              </div>
            </td>
          </tr>
        </table>
        <?php print "</form>"; ?>
      </td>
    </tr>
  </table>
      </td>
    </tr>
    </TBODY> 
  </table>
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.answer .a_name.value;
      var v2 = document.answer .a_message.value;
   
	  
        if ( v1.length==0)
           {
           alert("��سһ�͹ Name");
           document.answer .a_name.focus();           
           return false;
           }
        else if (v2.length==0)
           {
           alert("��سһ�͹ Message");
           document.answer .a_message.focus();           
		   return false;
           }
}
function setsmile(what)
{
	document.answer.a_message.value = document.answer.elements.a_message.value+" "+what;
	document.answer.a_message.focus();
}

//-->
</script> 
 </center>
 </body>
</html>
