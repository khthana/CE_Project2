<?
session_start();
session_destroy();
session_unset();
?>
<html>
<head>
<title>Login Administrator</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>

<body bgcolor="#FFFFFF">
<?php
	print "<form name='weblogin'  method='post'  action='index1.php'>";
?>
  <table width="35%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr> 
      <td height="30" bgcolor="#99CCFF"> 
        <div align="center"><b><font face="MS Sans Serif" size="3">Login</font></b></div>
    </td>
  </tr>
  <tr valign="top" bgcolor="#CCFFFF"> 
    <td height="45"> 
        <table width="100%" border="0" cellspacing="1" cellpadding="4" bgcolor="#CCCCFF">
          <tr>
            <td width="31%" bgcolor="#CCCCFF"> 
              <div align="right"><font face="MS Sans Serif" size="1">Username</font></div>
          </td>
            <td width="69%" bgcolor="#CCCCFF"> 
              <input type="text" name="name" size="15" maxlength="20">
            </td>
        </tr>
        <tr>
            <td width="31%" bgcolor="#CCCCFF"> 
              <div align="right"><font face="MS Sans Serif" size="1">Password</font></div>
          </td>
            <td width="69%" bgcolor="#CCCCFF"> 
              <input type="password" name="pwd" size="15" maxlength="20">
            </td>
        </tr>
      </table>
      
    </td>
  </tr>
  <tr valign="bottom"> 
      <td height="35" bgcolor="#CCCCFF" valign="middle"> 
        <div align="center"> 
		   <input type="submit" name="Submit" value="Login">
	        <input type="reset" name="Submit2" value="¡��ԡ">
      </div>
    </td>
  </tr>
</table>

</form>
</body>
</html>
