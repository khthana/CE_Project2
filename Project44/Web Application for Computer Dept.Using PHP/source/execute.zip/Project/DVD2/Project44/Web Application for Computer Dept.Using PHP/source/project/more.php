<?session_start();
?>
<html>
<head>
<title>more...</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: none}
a:hover { color: #0099FF; text-decoration: none}
-->
</style>
</head>
<?
  include("connect.inc.php");
  $dbname=project();
   $sql="select * from news order by id Desc  LIMIT 20,100";
   $dbquery=mysql_db_query($dbname,$sql)or die("error2");
   $rows=mysql_num_rows($dbquery);

?>
<body bgcolor="#FFFFFF">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font  color="#000000" style='font-size:19px'><b>���ǻ�С�� more...</b></font>
<br>
<table border=0 width='640'>
<tr>
<td>
<table width="640" border="1" cellpadding="0" cellspacing="0" bgcolor="#D9FFFF" bordercolor="#00D7D7">
  
 <?
 while($result=mysql_fetch_array($dbquery))
  {
 ?>
  <tr> 
    <td width="22%" align="center"  class=a><b><font color="#000000" ><?print($result[date1]);?></font></b></td>
    <td width="78%" bgcolor="#D9FFFF" valign=middle >&nbsp;&nbsp;<a href="display2.php?id1=<?print($result[id]);?>" ><font  color="#006666" style='font-size:19px'><?print($result[topic]);?></font></a></td>
  </tr>
<?
  }
?>
</td>
</tr>
</table>
</table>
</body>
</html>
