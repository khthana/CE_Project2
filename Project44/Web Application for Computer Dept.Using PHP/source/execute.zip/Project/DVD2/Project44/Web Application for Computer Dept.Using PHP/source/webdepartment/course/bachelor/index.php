<html>
<head>
<title>�ʴ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="../script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><img src="images/l.gif" width="1" height="20"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<?
include ("connect_course.inc.php");
echo "
<table width='772' border='0' cellspacing='0' cellpadding='0' align = 'center'>
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='130' bgcolor='#D2F8FD' valign='top' ><font size='2' face='Tahoma, Microsoft Sans Serif'><br>
		��ѡ�ٵû�ԭ�ҵ��</font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='structure.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
      <a href='tendency.php?course_year=$course_year'>Ἱ����֡��</a><br>
      <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
		&nbsp;</td>
	<td width='10' valign='top' >&nbsp; </td>
    <td width='609' valign='top' >";
	$query = "Select * From $Introducetable Where Course_year = '$course_year' order by Ctname ASC LIMIT 0, 50 ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$ctname = htmlspecialchars($row[Ctname]);
	$cename = htmlspecialchars($row[Cename]);
	$ftname = htmlspecialchars($row[Ftname]);
	$stname = htmlspecialchars($row[Stname]);
	$fename = htmlspecialchars($row[Fename]);
	$sename = htmlspecialchars($row[Sename]);
	$accept = $row[Accept];
	$philosophy_article = $row[Philosophy_Article];
	$program = $row[Program];
	$property = $row[Property];
	$test = $row[Test];
	$csystem = $row[Csystem];
	$ctime = $row[Ctime];
	$register = $row[Register];
	$process = $row[Process];
	$year1 = $row[Year1];
	$year2 = $row[Year2];
	$year3 = $row[Year3];
	$year4 = $row[Year4];
	$d1_year1 = $row[D1_year1];
	$d1_year2 = $row[D1_year2];
	$d1_year3 = $row[D1_year3];
	$d1_year4 = $row[D1_year4];
	$d2_year1 = $row[D2_year1];
	$d2_year2 = $row[D2_year2];
	$d2_year3 = $row[D2_year3];
	$d2_year4 = $row[D2_year4];
	$d3_year1 = $row[D3_year1];
	$d3_year2 = $row[D3_year2];
	$d3_year3 = $row[D3_year3];
	$d3_year4 = $row[D3_year4];
	$d4_year1 = $row[D4_year1];
	$d4_year2 = $row[D4_year2];
	$d4_year3 = $row[D4_year3];
	$d4_year4 = $row[D4_year4];
	$p1_year1 = $row[P1_year1];
	$p1_year2 = $row[P1_year2];
	$p1_year3 = $row[P1_year3];
	$p1_year4 = $row[P1_year4];
	$p2_year1 = $row[P2_year1];
	$p2_year2 = $row[P2_year2];
	$p2_year3 = $row[P2_year3];
	$p2_year4 = $row[P2_year4];
	$p3_year1 = $row[P3_year1];
	$p3_year2 = $row[P3_year2];
	$p3_year3 = $row[P3_year3];
	$p3_year4 = $row[P3_year4];
	$sum1 = $row[Sum1];
	$sum2 = $row[Sum2];
	$sum3 = $row[Sum3];
	$sum4 = $row[Sum4];
	$end1 = $row[End1];
	$end2 = $row[End2];
	$end3 = $row[End3];
	$end4 = $row[End4];
	$place_tool = $row[Place_Tool];

	echo "
	  <table width='100%' border='0' cellspacing='1' cellpadding='4' align='center' bordercolor='#FFFFFF'>
        <tr> 
          <td height='54' colspan='11' bgcolor='#F7F7F7'> 
            <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵ��ѳ�Ե 
              �Ң��Ԫ����ǡ������������� <br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp; </font></div>
          </td>
        </tr>
        <tr bgcolor='#F7F7F7'> 
          <td colspan='2' height='25'><b><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>1. 
            ������ѡ�ٵ� </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>����������</font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$ctname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>���������ѧ���</font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$cename&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' height='25' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'><b>2. 
            ���ͻ�ԭ��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>������� 
            (��)</font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$ftname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>������� 
            (��)</font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$stname&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font size='2' color='#000000' face='Tahoma, Microsoft Sans Serif'>������� 
            (�ѧ���)</font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$fename&nbsp;</font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#000000'>������� 
            (�ѧ���)</font></td>
          <td width='503' bgcolor='#D2F8FD' bordercolor='#FFFFFF' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$sename&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#000000'><b>3. 
            ˹��§ҹ�Ѻ�Դ�ͺ</b></font></td>
        </tr>
        <tr> 
          <td  bgcolor='#F7F7F7' height='25'></td>
          <td  bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$accept&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2' color='#000000'><b>4. 
            ��Ѫ������ѵ�ػ��ʧ��ͧ��ѡ�ٵ�</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$philosophy_article&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>5. 
            ��˹�����Դ�͹ </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$program&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>6.�س���ѵԢͧ�������֡�� </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$property&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>7. 
            ��äѴ���͡�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$test&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>8. 
            �к�����֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$csystem&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>9. 
            �������ҡ���֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$ctime&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>10.���ŧ����¹���¹ </font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$register&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>11. 
            ����Ѵ����С������稡���֡��</b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$process&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>12. 
            �ӹǹ�ѡ�֡�� </b></font></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7'>&nbsp;</td>
          <td width='503' bgcolor='#D2F8FD'> 
            <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF'>
              <tr> 
                <td rowspan='2'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'></font></div>
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�ӹǹ�ѡ�֡��</font></div>
                </td>
                <td colspan='4'height='26'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�ա���֡��</font></div>
                </td>
              </tr>
              <tr> 
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    1D</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d1_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d1_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d1_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d1_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    2D</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d2_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d2_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d2_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d2_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    3D</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d3_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d3_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d3_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d3_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    4D</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d4_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d4_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d4_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$d4_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    1P</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p1_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p1_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p1_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p1_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    2P</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p2_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p2_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p2_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p2_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>��鹻շ�� 
                    3P</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p3_year1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p3_year2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p3_year3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$p3_year4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>���</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$sum1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$sum2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$sum3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$sum4&nbsp;</font></div>
                </td>
              </tr>
              <tr> 
                <td width='25%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>�������稡���֡��</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$end1&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$end2&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$end3&nbsp;</font></div>
                </td>
                <td width='20%' height='25'> 
                  <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'>$end4&nbsp;</font></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>13. 
            ʶҹ�������ػ�ó����͹</font></b></td>
        </tr>
        <tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'>&nbsp;</td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma, Microsoft Sans Serif' size='2'>$place_tool&nbsp;</font></td>
        </tr>
        <tr> 
          <td colspan='2' bgcolor='#F7F7F7'>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>";
		}
	}
	MYSQL_CLOSE();
  ?>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
