<html>
<head>
<title>��䢢������ǡ�èѴ�Ԫ����¹��ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<?
include ("connect_course.inc.php");
$ty = strlen($type);
$ye = strlen($year);
$te = strlen($term);
if(($ty != 0)&&($ye != 0)&&($te != 0))
{
			$i =1;
			$t =1;
			$pass = "no";
			while( $i <= $count)
			{
			if($check[$i] != '')
			{
				$query_delete_course = "Delete From $Temptable Where Address ='$i'  AND Code ='$check[$i]' ";
			$result_delete_course = mysql_db_query($dbName,$query_delete_course);
			$t = $t +1;
			$pass = "yes";
			}
			$i = $i +1;
			}
			if ($pass == 'yes')
			{
			$del =1;
			$query_delete_course = "Delete From $Coursetable Where Type ='$type' AND Year ='$year' AND Term ='$term' AND Course_year = '$course_year' ";
			$result_delete_course = mysql_db_query($dbName,$query_delete_course);

			$query_temp = "Select * From $Temptable";
			$result_temp = mysql_db_query($dbName,$query_temp);
					while ($row = mysql_fetch_array($result_temp)) 
					{
						$code = htmlspecialchars($row[Code]);
						$name = htmlspecialchars($row[Name]);
						$sql_course = "INSERT INTO $Coursetable(Type,Year,Term,Code,Course_year,Name) VALUES ('$type','$year','$term','$code','$course_year','$name')";
						$result_course= mysql_db_query($dbName,$sql_course);
					}
			$query_delete_course = "Delete From $Temptable ";
			$result_delete_course = mysql_db_query($dbName,$query_delete_course);
echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>�������ǡ�èѴ�Ԫ����¹��١�ѹ�֡ŧ�ҹ���������º��������<BR></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			MYSQL_CLOSE();
		}
		else
		{
		echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
					<tr>
					<td height='32' colspan='4' bgcolor='#F7F7F7'> 
					  <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��س����͡����Ԫҷ���ͧ���ź�������ǡ���Ԫ����¹��͹</font></font></font></div>
					</td>
					</tr> 
					</table>
					</td>
					 </tr></table>";
		}

}
else
{
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
			<div align='center'><font size='2'><font size='2'><font face='Tahoma'>��س����͡��������Ъ�鹻շ���ͧ�����䢢������ǡ�èѴ�Ԫ����¹��͹</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			</tr></table>";
		$query_delete_temp = "Delete From $Temptable ";
		$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);
			MYSQL_CLOSE();
}
?>
<table width="600" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
