<html>
<head>
<title>�ʴ�����������Ԫ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #9900CC; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
  <?
	include ("connect_course.inc.php");
	echo "
  <tr> 
    <td width='11'>&nbsp;</td>
    <td width='10' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='138' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
     <a href='show_select_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
	  <a href='show_select_category.php?course_year=$course_year'>��������Ǵ�Ԫ�</a><br>
       �����š�����Ԫ� <br>
	   <a href='show_select_subject.php?course_year=$course_year'>����������Ԫ� </a><br>
      <a href='tendency.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a></font> <font face='Tahoma' size='2'><br>
      <a href='index.php'>��Ѻ˹����ѡ </a></font></font><br>
   </td>
    <td width='619' valign='top' >
	<table width='600' border='0' cellspacing='0' cellpadding='0' align='center'>
        <tr> 
          <td bgcolor='#F7F7F7' height='103'> 
            <div align='center'><font face='Tahoma' size='2' color='#515151'><br>��ѡ�ٵ����ǡ�����ʵúѳ�Ե 
              �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� </font> <font size='2' color='#515151' face='Tahoma'><br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>&nbsp;</font> </div>
          </td>
        </tr>
      </table>";
    
	$query_group = "Select * From $Gsubjecttable Where Course_year  =  '$course_year' AND Category  =  '$category' AND Gsubject  =  '$gsubject'";
	$result_group = mysql_query($query_group);
	$gnumber = mysql_numrows($result_group);
	$gi=0;
	if ($gi < $gnumber) 
	{
	echo "	<table width='600' cellspacing='0' cellpadding='0' align='center' border='1' bordercolor='#FFFFFF'>";
	while ($row = mysql_fetch_array($result_group))
		{
	$category = htmlspecialchars($row[Category]);
	$gsubject = htmlspecialchars($row[Gsubject]);
	$gdetail = $row[Gdetail];
	$gdetail = eregi_replace('<br>',chr(13),$row[Gdetail]);
	echo "
	<tr> 
   <td colspan='7' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>$category</b></font></td>
     </tr>
	<tr> 
	<td width='14' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>&nbsp;</font></td>
    <td colspan='6' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>$gsubject</font> 
    </td>
   </tr>
	<tr> 
    <td colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
    <td bgcolor='#F7F7F7' colspan='5' width='561'><font face='Tahoma' size='2'>$gdetail&nbsp;</font></td>
  </tr>";
		$query = "Select * From $Subjecttable Where Gsubject = '$gsubject' AND Course_year  =  '$course_year'  order by Code";
		$result = mysql_query($query); 
        $number = mysql_numrows($result);
		$i=0; 
		if ($i < $number)
		{
			while ($row  = mysql_fetch_array($result)) 
			{
			$code = htmlspecialchars($row[Code]); 
			$name = htmlspecialchars($row[Name]);
			$ename = htmlspecialchars($row[Ename]); 
			$unit = htmlspecialchars($row[Unit]); 
			$unit_detail = htmlspecialchars($row[Unit_detail]); 
			$unit_operation = htmlspecialchars($row[Unit_operation]); 
		echo "
			<tr bgcolor='#D2F8FD'> 
			<td colspan='3'><font face='Tahoma' size='2'>&nbsp;</font> 
			</td>
			<td width='57'> 
			  <div align='center'><font face='Tahoma' size='2'>$code</font></div>
			</td>
			<td width='212'><font face='Tahoma' size='2'><a href='show_subject.php?code=$code&&course_year=$course_year'>$name</a></font></td>
			<td width='136'> 
			  <div align='center'><font face='Tahoma' size='2'>$unit ($unit_detail-$unit_operation)</font></div>
			</td>
			<td width='133'> 
			  <div align='center'></div>
			</td>
		  </tr>
		<tr bgcolor='#D2F8FD'> 
			<td colspan='4'><font face='Tahoma' size='2'></font></td>
			<td width='212'><font face='Tahoma' size='2'>$ename&nbsp;</font></td>
			<td width='136'> 
			  <div align='center'></div>
			</td>
			<td width='133'> 
			  <div align='center'></div>
			</td>
		  </tr>";
			}//end while of select subject;
		}//end if of select subject;
		else { 
		 echo"
			<tr> 
			<td colspan='7' bgcolor='#F7F7F7'>
			<div align='center'><font face='Tahoma' size='2'>����բ���������Ԫ�</font></div>
			</td>
			</tr>";
				}//end else if of select subject;
		}//end while of select group;
		echo "<tr> 
				<td colspan='7' bgcolor='#F7F7F7'><font face='Tahoma' size='2'>&nbsp;</font></td>
				 </tr></table>";
		}//end if of select group;
	mysql_free_result($result);
	MYSQL_CLOSE();
?>
</td>
</tr></table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
