<html>
<head>
<title>����ç���ҧ��ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
echo "
	<tr> 
    <td width='11'  >&nbsp;</td>
    <td width='9' bgcolor='#EAEAFF'  >&nbsp;</td>
    <td width='155' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_update.php?course_year=$course_year'
		target ='_parent'>�����ѡ�ٵû�ԭ���͡</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
		����ç���ҧ��ѡ�ٵ�<br>
	  	  <a href='structure_update_msubject.php?course_year=$course_year'>����Ԫ���ѡ</a><br>
	  <a href='structure_update_category.php?course_year=$course_year'>�����Ǵ�Ԫ�</a><br>
	  <a href='structure_update_group.php?course_year=$course_year'>����Ң��Ԫ�</a><br>
	  <a href='Doctor/Update/Subject/update_subject.php?course_year=$course_year'>�������Ԫ�</a><br>
	  <a href='Doctor/Update/Course/update_course.php?course_year=$course_year'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;
	</td>
    <td width='619' valign='top'> ";
		$query_structure = "Select * From $Structuretable Where Course_year  =  '$course_year' ";
	$result_structure = mysql_query($query_structure);
	$number_structure = mysql_numrows($result_structure);
	if ($number_structure > 0)
		{
			while ($row  = mysql_fetch_array($result_structure)) 
			{
			$program1_unit = htmlspecialchars($row[Program1_unit]); 
			$program2_unit = htmlspecialchars($row[Program2_unit]); 
			$detail = $row[Detail];
			$detail = eregi_replace('<br>',chr(13),$row[Detail]);
			$detail_master = $row[Detail_master];
			$detail_master = eregi_replace('<br>',chr(13),$row[Detail_master]);
			$detail_bachelor = $row[Detail_bachelor];
			$detail_bachelor = eregi_replace('<br>',chr(13),$row[Detail_bachelor]);
			
			}
		}
echo "
	  <form name='form1' method='post' action='update_structure_course.php'>
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF' >
          <tr> 
            <td height='21' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font size='2' face='Tahoma'></font><font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year<br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ <br>
                &nbsp; </font></div>
            </td>
          </tr>
          <tr> 
            <td height='25' colspan='4' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>14. 
              ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td height='25' colspan='4' bgcolor='#F7F7F7'> 
              <div align='left'><font size='2'><font size='2'><font face='Tahoma'><b>14.1 
                �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font></font></font></div>
            </td>
          </tr>
          <tr> 
            <td height='52' rowspan='2' bgcolor='#F7F7F7' width='28'><font size='2' face='Tahoma'></font></td>
            <td height='22' width='189' bgcolor='#EAEAFF'> 
              <div align='left'><font size='2' face='Tahoma'>- ����Ѻ��騺��ԭ���</font></div>
            </td>
            <td height='22' width='349' bgcolor='#EAEAFF'> &nbsp; 
              <input type='text' name='program1_unit' size='3' maxlength='3' value='$program1_unit'>
              <font face='Tahoma' size='2'>˹��¡Ե </font></td>
            <td height='52' rowspan='2' bgcolor='#F7F7F7' width='24'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='30' width='189' bgcolor='#EAEAFF'> 
              <div align='left'><font size='2' face='Tahoma'>- ����Ѻ��騺��ԭ�ҵ��</font></div>
            </td>
            <td height='30' width='349' bgcolor='#EAEAFF'> &nbsp; 
              <input type='text' name='program2_unit' size='3' maxlength='3' value='$program2_unit'>
              <font face='Tahoma' size='2'> ˹��¡Ե </font></td>
          </tr>
          <tr> 
            <td height='25' colspan='3' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>14.2 
              �ç���ҧ��ѡ�ٵ�</b></font></td>
            <td height='202' rowspan='7' bgcolor='#F7F7F7' width='24'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='292' rowspan='6' bgcolor='#F7F7F7' width='28'><font size='2' face='Tahoma'></font><font face='Tahoma' size='2'></font> 
            </td>
            <td height='25' colspan='2' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>����Ѻ��騺��ԭ���</b></font> 
            </td>
          </tr>
          <tr> 
            <td height='80' colspan='2' bgcolor='#EAEAFF'> 
              <div align='center'> 
                <textarea name='detail_bachelor' cols='80' rows='3'>$detail_bachelor</textarea>
              </div>
            </td>
          </tr>
          <tr> 
            <td height='25' colspan='2' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>����Ѻ��騺��ԭ�ҵ��</b></font></td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td height='80' colspan='2' bgcolor='#EAEAFF'> 
              <div align='center'> 
                <textarea name='detail_master' cols='80' rows='3'>$detail_master</textarea>
              </div>
            </td>
          </tr>
          <tr> 
            <td height='25' colspan='2' bgcolor='#F7F7F7'><font face='Tahoma' size='2'><b>��͸Ժ������˵ؼŷ��е�ͧ�֡���Ԫҵ�ҧ� 
              �մѧ��� </b></font></td>
          </tr>
          <tr> 
            <td height='80' colspan='2' bgcolor='#EAEAFF'> 
              <div align='center'> 
                <textarea name='detail' cols='80' rows='3'>$detail</textarea>
              </div>
            </td>
          </tr>
          <tr> 
            <td height='42' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'> 
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
                <input type='hidden' name='course_year' value='$course_year'>
              </div>
            </td>
          </tr>
        </table>
	   </form>";
	   ?>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
