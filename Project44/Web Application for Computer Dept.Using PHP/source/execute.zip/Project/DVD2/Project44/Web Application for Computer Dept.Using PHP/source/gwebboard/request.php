<html>
<head>
<title>request</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
.a1
  {
  color:#600060; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 14px;
  
  }   
.a2
  {
  color:#FF33FF; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 14px;
  
  }   

</style>
<SCRIPT LANGUAGE="JavaScript">
<!-- Original: wsabstract.com -->

function checkrequired(which) {
var pass=true;
if (document.images) {
for (i=0;i<which.length;i++) {
var tempobj=which.elements[i];
if ((tempobj.type=="text"&&
tempobj.value=='')||(tempobj.type.toString().charAt(0)=="s"&&
tempobj.selectedIndex==0)||(tempobj.type=="password"&&
tempobj.value=='')) {
pass=false;
break;
         }
    }
}
if (!pass) {
shortFieldName=tempobj.name.substring(8,30).toUpperCase();
alert("��س������������ú��ǹ");
return false;
}
else
return true;
}
</script>

</head>
<?
include("smtpmail.inc.php");
include("connect.inc.php");
$dbname=gwebboard();
?>
<body bgcolor="#FFFFFF">
<table border=0  width="760" align=left height="640">
  <tr class=a>
    <td valign="top"> 
<img src="images/logo.gif" width="305" height="74">
<br>
<br>
<br>
<center>
<?
if((!$submit)&&(!$nameboards))
{
?>
<form  action='request.php' method=post onSubmit="return checkrequired(this)">
        <table cellspacing=1 cellpadding=13 width=550 border=0>
          <tr> 
      <td align=right bgcolor=#D0E8FF ><font style="font-size:13px" face="Tahoma,Ms Sans Serif"><b>������ <font 
            face=verdana>:</font></b></font></td>
      <td bgcolor=#EEF7FF><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >
        <input 
            style="FONT-SIZE: 10pt; FONT-FAMILY: Tahoma,Ms Sans Serif" maxlength=40 
            size=30 name=email>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font></td>
    </tr>
  <tr> 
      <td align=right bgcolor=#D0E8FF><font 
            face="Tahoma,Ms Sans Serif" size=1><font 
            style="FONT-SIZE: 13px"><b>���� group <font 
            face=verdana>:</font></b></font></font></td>
      <td bgcolor=#EEF7FF><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">
	  <?
		   //��Ǩ�ͺemail&pass�������㹵��ҧ user  ����� userboard ������������
		     $sql="select * from admin ";
		     $dbquery=mysql_db_query($dbname,$sql)or die("error");
		     $num_rows=mysql_num_rows($dbquery);
	      
	         print("<SELECT NAME='nameboards'>");
		     print("<option  selected>====group====");
                                   $c=0;
									while($c<$num_rows) 
									{
			                             $result=mysql_fetch_array($dbquery);  						    
										print("<option >$result[nameboard] ");  
								        $c++;  
									}	
			 print("</select>");		
	      ?>
		
             </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" size=1>&nbsp; <font color=#990033><font 
            face=Verdana>(</font>���� group �����ͧ��������� <font 
            face=Verdana>)</font></font></font></td>
    </tr>
	<tr> 
      <td align=right bgcolor=#D0E8FF><font 
            face="Tahoma,Ms Sans Serif" ><font 
            style="FONT-SIZE: 13px"><b>Password <font 
            face=verdana>:</font></b></font></font></td>
      <td bgcolor=#EEF7FF><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >
        <input 
            style="FONT-SIZE: 13px; FONT-FAMILY: Tahoma,Ms Sans Serif" type=password maxlength=6 
            size=15 name=pass>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 size=1>&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >&nbsp;<INPUT 
            style="FONT-SIZE: 8pt; FONT-FAMILY: verdana" type=checkbox CHECKED 
            name=sent_mail value=1>&nbsp;<FONT color=#990033><FONT 
            face=Verdana>(</FONT>��������֧��Ңͧ group<FONT 
            face=Verdana>)</FONT></FONT></FONT></td>
    </tr>
	
    <tr valign=top> 
      <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" size=1>&nbsp;</font></td>
      <td><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
        <font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
    </tr>
    <tr> 
            <td align=right height="51"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >&nbsp;</font></td>
            <td height="40"><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" > 
              <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>&nbsp;&nbsp;
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancel>
              </font></td>
    </tr>
  </form>
</table>
					
<?
}//if(!$submit)&&(!$nameboard)
elseif((!$submit)&&($nameboards))
{
?>
<form  action='request.php' method=post onSubmit="return checkrequired(this)">
        <table cellspacing=1 cellpadding=13 width=550 border=0>
          <tr> 
      <td align=right bgcolor=#D0E8FF ><font style="font-size:13px" face="Tahoma,Ms Sans Serif"><b>������ <font 
            face=verdana>:</font></b></font></td>
      <td bgcolor=#EEF7FF><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >
        <input 
            style="FONT-SIZE: 10pt; FONT-FAMILY: Tahoma,Ms Sans Serif" maxlength=40 
            size=30 name=email>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font></td>
    </tr>
 <tr> 
      <td align=right bgcolor=#D0E8FF><font 
            face="Tahoma,Ms Sans Serif" ><font 
            style="FONT-SIZE: 13px"><b>���� group <font 
            face=verdana>:</font></b></font></font></td>
      <td bgcolor=#EEF7FF><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" color=#3333FF><b><?print($nameboards);?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <INPUT TYPE="hidden" name=nameboards value=<?print($nameboards);?>>
		</font><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" ><font color=#990033><font face=Verdana>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;(</font>���� group �����ͧ���������<font face=Verdana>)</font></font></font></td>
    </tr>
	<tr> 
      <td align=right bgcolor=#D0E8FF><font 
            face="Tahoma,Ms Sans Serif" ><font 
            style="FONT-SIZE: 13px"><b>Password <font 
            face=verdana>:</font></b></font></font></td>
      <td bgcolor=#EEF7FF><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >
        <input 
            style="FONT-SIZE: 13px; FONT-FAMILY: Tahoma,Ms Sans Serif" type=password maxlength=6 
            size=15 name=pass>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >&nbsp;<INPUT 
            style="FONT-SIZE: 13px; Tahoma,Ms Sans Serif" type=checkbox CHECKED 
            name=sent_mail value=1>&nbsp;<FONT color=#990033><FONT 
            face=Verdana>(</FONT>��������֧��Ңͧ group<FONT 
            face=Verdana>)</FONT></FONT></FONT></td>
    </tr>
	
    <tr valign=top> 
      <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" size=1>&nbsp;</font></td>
      <td><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
        <font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 size=1>&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
    </tr>
    <tr> 
      <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" size=1>&nbsp;</font></td>
      <td><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" >
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>&nbsp;&nbsp;
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancel>
					</font></td>
    </tr>
  </form>
					</table>

<?
}//if(!$submit)&&($nameboard)
elseif($submit)
{
		$d=date("d-m-Y");
		 $t=date("h:i:s a");
		 
		 //��Ǩ�ͺ email and pass �ͧ��� request
		  $sql1="select * from user where own='user' and pass='$pass' and email='$email' ";
		  $dbquery1=mysql_db_query($dbname,$sql1)or die("error");
		  $num_rows1=mysql_num_rows($dbquery1);
		  $result=mysql_fetch_array($dbquery1);
		  if($num_rows1>0)
		   {
		 //��Ǩ�ͺ���ҧ userboard �ͧ��� request
		  $sql0="select * from user,userboard where (userboard.nameboard='$nameboards' and userboard.email='$email' ) or (user.email='$email' and user.request='$nameboards')";
		  $dbquery0=mysql_db_query($dbname,$sql0)or die("error");
		  $num_rows0=mysql_num_rows($dbquery0);
		    if($num_rows0==0)
		      {
		
		  //��Ǩ�ͺ��Ҽ�� request �� admin �ͧ nameboard �ͧ��� request �������
		  $sql="select * from admin where nameboard='$nameboards' and email='$email' ";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error");
		  $num_rows=mysql_num_rows($dbquery);
		  if($num_rows==0)
				 {
			//�������� request �����ҧ user
		     $sql1="insert into user (email,pass,date,time,own,request) values ('$email','$pass','$d','$t','user','$nameboards')";
             $dbquery1=mysql_db_query($dbname,$sql1);
			 
			 if($sent_mail==1)
		       {
		    //�� email �ͧ admin group ���ͷ����� mail ���
			$sql2="select * from admin where nameboard='$nameboards'";
		    $dbquery2=mysql_db_query($dbname,$sql2)or die("error1");
		    $result2=mysql_fetch_array($dbquery2);
            
			//$recive=$result2[name]."<".$result2[email].">";
			
			$subject="�駡�â�������� group";
			
			$message="���ʴդ�Ѻ\n";
			$message.="��й�����ռ���������� group �ͧ�س\n";
            $message.="������������� group ���\n";
            $message.="NAME  :  ".$result[name]."\n"; 
			$message.="EMAIL  :  ".$email."\n";
			$message.="DATE   :  ".$d."\n";
			$message.="TIME    :  ".$t."\n"; 

			 smail($result2[email],$subject,$message);
			 //mail($recive,$subject,$message,"Form : ".$email) or print("�������ö�觨�������"); 
		        }  
?>
<font style="font-size:18px" color=#0077EE  face="Tahoma,Ms Sans Serif"><center><b>Request Complete</b></center></font>
<br>
        <table border="1" align="center" bordercolor="#005EBB">
          <tr>
    <td valign="top">
              <table width="380" border="0" height="200" cellspacing="0" cellpadding="5" >
                <tr> 
                  <td width="41%" align="right" class=a1 bgcolor=#FFF0F8 height="20">Email 
                    �س���</td>
                  <td colspan="2" width="59%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($email);?>
                  </td>
        </tr>
        <tr> 
                  <td width="41%" align="right" class=a1 bgcolor=#FFF0F8 height="20">Group 
                    request �س���</td>
                  <td colspan="2" width="59%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($nameboards);?>
                  </td>
        </tr>
         <tr> 
                  <td width="41%" align="right" class=a1 bgcolor=#FFF0F8 height="20">�ѹ��� 
                    request</td>
                  <td colspan="2" width="59%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($d);?>
                  </td>
        </tr>
        <tr> 
                  <td width="41%" align="right" class=a1 bgcolor=#FFF0F8 height="20">���ҷ�� 
                    request</td>
                  <td colspan="2" width="59%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($t);?>
                  </td>
        </tr>
        <tr align="center" bgcolor=#FFF0F8> 
                  <td colspan="3" class=home height="20">&lt;<a href="index.php">HOME</a>&gt;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
<?
}
   else
    {
   ?>		
  
   <div align="center">
  <br>
  <br>
<br>
   <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡ�س�� admin �ͧ group ������� �������ö request �� ��س� request group ����</b></font></font></p>
<br>
<br>
	   <br>
<br>
	   <br>
<br>
  
</div>  
  <? 
   }   
   }
   else
    {
   ?>		
  
   <div align="center">
  <br>
  <br>
<br>
   <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡ�س����ª������� group ������� ���� ���ա�� request �ҡ�س����</b></font></font></p>
<br>
<br>
	   <br>
<br>
	   <br>
<br>
  
</div>  
  <? 
   }
   }
   else
	{      
     ?>
   <div align="center">
  <br>
  <br>
<br>
	 <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡ����բ����Ţͧ�س��к�</b></font></font></p>
  <br>
<br>
  <br>
<br>
		 <br>
<br>
	 
  </div> 
	<?
	}
}//if($submit)
?>
</center>
<?
//�Դ�ҹ������
     closedb();
?>

 <table width="760" border="0" cellspacing="0" cellpadding="0">
  <tr class=a>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8" class=a>
      <hr align="center" width="550" >
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</td>
</tr>
</table>
</body>
</html>