<?
	$hostname = "localhost";
	$username = "root";
	$password = "webmaster123";
	$Admintable= "Admin";
    $dbName = "Admin_course";
	MYSQL_CONNECT($hostname,$username,$password)
	OR DIE("Unable to connect to database");
	@mysql_select_db("$dbName") or die
	("Unable to select database");
?>