<HTML>
<HEAD>
<TITLE>forgetpass</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</HEAD>
<BODY text=#ffff00 bgColor=#ffffFF leftMargin=0 topMargin=0>
<table border=0  width="760" align=left height="640">
  <tr class=a> 
    <td valign="top" height="1195"> <img src="images/logo.gif" width="305" height="74"> 
      <br>
      <br>
      <br>
	  <?
include("smtpmail.inc.php");
if($submit=='Submit')
{
include("connect.inc.php");
$dbname=gwebboard(); 
$sql="select * from user where email='$email' and own='$status'";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");
$rows=mysql_num_rows($dbquery);	
if($rows!=0)
 {
 $d=date('d-m-Y');
 //�� email
$result=mysql_fetch_array($dbquery);
 $email=$email;
 //$recive=$result[firstname]." ".$result[surname]." ".$result[code]."<".$email.">";
 $subject="repassword";
			
$message.="username&password �ͧ�س���\n";
$message.="username  :  ".$email."\n"; 
$message.="pass  :  ".$result[pass]."\n";
$message.="status  :  ".$status."\n";
$message.="DATE   :  ".$d."\n";

smail($email,$subject,$message);// or die("�������ö�觨�������");
//mail($recive,$subject,$message,"Form : ".$email) or die("�������ö�觨�������");        
?>
      <div align="center"> 
        <p><br>
          <br>
          <br>
          <font class=h><font  color="#0033FF">Complete</font></font></p>
        <p><font class=a><font color="#0033FF" ><b>password �ͧ�س��١��价�� 
          E-mail �ͧ�س���º��������</b></font></font></p>
        <br>
	    <br>
        <br>
        <br>
	   <br>
	   <br>       
</div>
      <?
 }//if
else
   {
?>
      <div align="center"> 
        <p><br>
         <br>
	   <br>
	    <font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
        <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡ����բ����Ţͧ�س㹰ҹ������</b></font></font></p>
       <br>
	   <br>
	   <br> 
      <br>
	   <br>
	   <br> 
      </div>
      <?
 }
//�Դ�ҹ������
closedb();
}//if(submit)
else
{
?>
      <table border=0 align=center width="760" >
        <tr class=a> 
          <td valign=top height="299"> 
            <table border=0 align=center width="80%" >
              <tr class=a> 
                <td valign=top height="276"> 
                  <table bgcolor=#6666FF border=1 align=center>
                    <tr class=a> 
                      <td> 
                        <FORM name=create_login onsubmit="return check();" action='forgetpass.php' method=post>
                          <TABLE width=488 align=center>
                            <TBODY> 
                            <TR class=a> 
                              <TD class=a align=right colSpan=2>&nbsp;</TD>
                            </TR>
                            <TR bgColor=#ffffcc> 
                              <TD class=a align=right colSpan=2> 
                                <DIV align=center><B><FONT color=#0033cc 
      >Forget password</FONT></B></FONT></DIV>
                              </TD>
                            </TR>
                            <TR> 
                              <TD class=a align=right>&nbsp;</TD>
                              <TD class=a>&nbsp;</TD>
                            </TR>
                            <TR> 
                              <TD class=a align=right height=29>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B><FONT 
      color=#cccc00>E-Mail :</FONT></B></TD>
                              <TD class=a height=29 valign="middle"> 
                                <INPUT maxLength=30 size=20 
      name=email>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            <TR> 
                              <TD class=a align=right width="169" height="26"><B><font color="#cccc00">Status 
                                Group :</font></B></TD>
                              <TD class=main width="307" height="26" valign="middle"> 
                                <select name="status" size="1">
                                  <option selected>---status---</option>
                                  <option>admin</option>
                                  <option>user</option>
                                </select>
                              </TD>
                            </TR>
                            <TR> 
                              <TD class=a align=right width="169" height="32">&nbsp;</TD>
                              <TD class=a align=right width="307" valign="bottom" height="32"> 
                                <div align="left"> 
                                  <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
                                </div>
                              </TD>
                            </TR>
                            <TR> 
                              <TD class=a align=right colspan="2" height="17">&nbsp; 
                              </TD>
                            </TR>
                            <TR bgColor=#ffffcc> 
                              <TD class=a align=middle colSpan=2> 
                                <div align="center"><a href='index.php'><FONT color=#663300><b>HOME</b></FONT></a></div>
                              </TD>
                            </TR>
                            </TBODY> 
                          </TABLE>
                        </FORM>
                      </td>
                    </tr>
                  </table>
           
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <?
}
?>
      <table width="760" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class=a> 
            <div align="center"><font color="#000080">Department of Computer Engineering 
              Faculty of Engineering King Mongkut's Institute of Technology<br>
              Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
              �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
          </td>
        </tr>
        <tr> 
          <td height="30"> 
            <hr align="center" width="550" size="2">
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
       <script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.create_login.email.value;
      var v2 = document.create_login.status;
      
        	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.email.focus();           
		   return false;
           }
        else if (v2.selectedIndex==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.status.focus();           
		   return false;
           }
		else
		return true;
}
//-->
</script>
</BODY>
</HTML>