<html>
<head>
<title>��䢢����š�����Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" align = 'center'>
<?
include ("connect_course.inc.php");
 echo "
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='9' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='155' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
       <a href='introduce_update.php?course_year=$course_year'
		target ='_parent'>�����ѡ�ٵû�ԭ���͡</a><br>
      <a href='structure_update_course.php?course_year=$course_year' target ='_parent'>����ç���ҧ��ѡ�ٵ�</a><br>
	  	     <a href='structure_update_msubject.php?course_year=$course_year'>����Ԫ���ѡ </a><br>
		<a href='structure_update_category.php?course_year=$course_year' target ='_parent'>�����Ǵ�Ԫ�</a><br>
	  ����Ң��Ԫ�<br>
		<a href='Doctor/Update/Subject/update_subject.php?course_year=$course_year' target ='_parent'>�������Ԫ�</A><br>
	  <a href='Doctor/Update/Course/update_course.php?course_year=$course_year' target ='_parent'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;
		</td>
    <td width='619' valign='top' > ";
$pass = "yes";
for ($mindex = 1; $mindex < $msubject_index; $mindex++)
{
for ($cindex = 1; $cindex < $csubject_index[$mindex]; $cindex++)
{
					$gindex = 1;					
		while (($gindex < $group_count[$mindex][$cindex]) &&($pass != 'no'))
		{
					$gs = strlen($gsubject_new[$mindex][$cindex][$gindex]);
					if (($gs == 0) AND ($category_have_group[$mindex][$cindex] == 'YES' ))
							{
									$pass = "no";
							}
					$gindex++;
		}
} //end  for of category
} //end  for of msubject
$pass_repeat = "yes";
$m = 1;
while(($m<$msubject_index)&&($pass_repeat == 'yes'))
{
					$c = 1;
while(($c<$csubject_index[$m])&&($pass_repeat == 'yes'))
{
					$g1 = 1;
			while(($g1<$group_count[$m][$c])&&($pass_repeat == 'yes'))
			{
					$g2 = $g1+1;
					while(($g2<$group_count[$m][$c])&&($pass_repeat == 'yes'))
					{
					if (($gsubject_new[$m][$c][$g1]) == ($gsubject_new[$m][$c][$g2]))
							{
								$pass_repeat = "no";
							}
					$g2++;
					}
					$g1++;
			}
					$c++;
	}
					$m++;
}
$min = 1;
while (($min < $msubject_index)&&($pass == 'yes')&&($pass_repeat == 'yes'))
{
		$cin = 1;
while (($cin < $csubject_index[$min])&&($pass == 'yes')&&($pass_repeat == 'yes'))
{
		$gin = 1;
		while ($gin < $group_count[$min][$cin])
		{
			if ($category_have_group[$min][$cin] == 'YES' )
			{
			$gsubject_new[$min][$cin][$gin] = htmlspecialchars($gsubject_new[$min][$cin][$gin]);
			$gprogram_unit_new[$min][$cin][$gin] = htmlspecialchars($gprogram_unit_new[$min][$cin][$gin]);
			$gdetail_new[$min][$cin][$gin] = htmlspecialchars($gdetail_new[$min][$cin][$gin]);
			$gdetail_new[$min][$cin][$gin] = eregi_replace(" ","&nbsp;",$gdetail_new[$min][$cin][$gin]);
			$gsubject = $gsubject_new[$min][$cin][$gin];
			$gprogram_unit = $gprogram_unit_new[$min][$cin][$gin];
			$gdetail = $gdetail_new[$min][$cin][$gin];
			$g_old = $group[$min][$cin][$gin];
			$c_old = $category_old[$min][$cin];
			$m_old = $msubject_old[$min];
			
			$query_delete_group = "Delete  From $Gsubjecttable Where Category ='$c_old' AND Gsubject ='$g_old' AND Course_year = '$course_year' AND Msubject ='$m_old' ";
			$result_delete_group = mysql_db_query($dbName,$query_delete_group);
			
			$sql = "INSERT INTO $Gsubjecttable(Course_year,Msubject,Category,Gsubject,Gprogram_unit,Gdetail) VALUES ('$course_year','$m_old','$c_old','$gsubject','$gprogram_unit','$gdetail')";
			$result = mysql_db_query($dbName,$sql);
			
			$query_update = "Update $Subjecttable Set Gsubject = '$gsubject' Where Category ='$c_old' AND Gsubject ='$g_old' AND Course_year = '$course_year' AND Msubject ='$m_old' ";
		   $result_update = mysql_db_query($dbName,$query_update);  
		     }
			$gin++;
		}
	$cin++;
}
$min++;
}
if ($pass == 'no')
{
		echo"
			 <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
 }
 else if ($pass_repeat == 'no')
{
		echo"
			 <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������Ң��Ԫҫ�����Ǵ�Ԫ����ǡѹ��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
 }
 else if ( $pass == 'yes' )
{
echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
			<div align='center'><font size='2'><font face='Tahoma'>�������Ң��Ԫ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'structure_update_group.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			</tr></table>";
			MYSQL_CLOSE();
			}
?>
			
<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
