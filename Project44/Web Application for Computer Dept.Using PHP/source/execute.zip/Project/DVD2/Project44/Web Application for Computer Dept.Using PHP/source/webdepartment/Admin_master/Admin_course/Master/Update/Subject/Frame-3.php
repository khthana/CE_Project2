<html>
<head>
<title>��ѡ�ٵû�ԭ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="154" border="0" cellspacing="0" cellpadding="0" height="100%" align="right">
<?
	echo"
	<tr> 
    <td width='8%' bgcolor='#DAEEFE'>&nbsp;</td>
    <td width='86%' bgcolor='#DAEEFE' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
     <a href='../../../introduce_update.php?course_year=$course_year'
		target ='_parent'>�����ѡ�ٵû�ԭ���</a><br>
       <a href='../../../structure_update_course.php?course_year=$course_year' target ='_parent'>����ç���ҧ��ѡ�ٵ�</a><br>
	  <a href='../../../structure_update_category.php?course_year=$course_year' target ='_parent'>�����Ǵ�Ԫ�</a><br>
	  <a href='../../../structure_update_group.php?course_year=$course_year' target ='_parent'>����Ң��Ԫ�</a><br>
		�������Ԫ�<br>
	  <a href='../Course/update_course.php?course_year=$course_year' target ='_parent'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='../../../index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>
	</td></tr>";
  ?>
</table>
</body>
</html>
