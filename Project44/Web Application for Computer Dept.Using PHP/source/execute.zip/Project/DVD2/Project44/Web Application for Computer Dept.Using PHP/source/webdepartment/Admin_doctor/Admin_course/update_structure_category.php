<html>
<head>
<title>��䢢�������Ǵ�Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
 echo "
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='9' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='155' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
       <a href='introduce_update.php?course_year=$course_year'
		target ='_parent'>�����ѡ�ٵû�ԭ���͡</a><br>
      <a href='structure_update_course.php?course_year=$course_year' target ='_parent'>����ç���ҧ��ѡ�ٵ�</a><br>
	     <a href='structure_update_msubject.php?course_year=$course_year'>����Ԫ���ѡ </a><br>
		�����Ǵ�Ԫ�<br>
		<a href='structure_update_group.php?course_year=$course_year' target ='_parent'>����Ң��Ԫ�</a><br>
		<a href='Doctor/Update/Subject/update_subject.php?course_year=$course_year' target ='_parent'>�������Ԫ�</A><br>
	  <a href='Doctor/Update/Course/update_course.php?course_year=$course_year' target ='_parent'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php' target ='_parent'>��Ѻ˹����ѡ </a></font><br>&nbsp;
		</td>
    <td width='619' valign='top' > ";
					$pass = "yes";
for ($cindex = 1; $cindex < $msubject_index; $cindex++)
{
					$gindex = 1;					
		while (($gindex < $category_count[$cindex]) &&($pass != 'no'))
		{
					$gs = strlen($category_new[$cindex][$gindex]);
				 if ((($gs == 0)) AND ($msubject_have_category[$cindex] == 'YES' ))
							{
									$pass = "no";
							}
					$gindex++;
		}
} //end of for
$c = 1;
$pass_repeat = "yes";
while(($c<$msubject_index)&&($pass_repeat == 'yes'))
{
					$g1 = 1;
			while(($g1<$category_count[$c])&&($pass_repeat == 'yes'))
			{
					$g2 = $g1+1;
					while(($g2<$category_count[$c])&&($pass_repeat == 'yes'))
					{
						if (($category_new[$c][$g1]) == ($category_new[$c][$g2]))
							{
								$pass_repeat = "no";
							}
					$g2++;
					}
					$g1++;
			}
					$c++;
}
$cin = 1;
while (($cin < $msubject_index)&&($pass == 'yes')&&($pass_repeat == 'yes'))
{
		$gin = 1;
		while ($gin < $category_count[$cin])
		{
			if ($msubject_have_category[$cin] == 'YES' )
			{
			$category_new[$cin][$gin] = htmlspecialchars($category_new[$cin][$gin]);
			$cprogram_unit_new[$cin][$gin] = htmlspecialchars($cprogram_unit_new[$cin][$gin]);
			$detail_new[$cin][$gin] = htmlspecialchars($detail_new[$cin][$gin]);
			$detail_new[$cin][$gin] = eregi_replace(" ","&nbsp;",$detail_new[$cin][$gin]);
			$category = $category_new[$cin][$gin];
			$cprogram_unit = $cprogram_unit_new[$cin][$gin];
			$detail = $detail_new[$cin][$gin];
			$category_old = $tmpcategory[$cin][$gin];
			$query_delete = "DELETE  FROM $Categorytable Where Course_year = '$course_year' AND Msubject = '$msubject_old[$cin]' AND Category = '$category_old' "; 
		    $result_delete = mysql_db_query($dbName,$query_delete);
			
			$sql = "INSERT INTO $Categorytable(Course_year,Msubject,Category,Cprogram_unit,Detail) VALUES ('$course_year','$msubject_old[$cin]','$category','$cprogram_unit','$detail')";
			$result = mysql_db_query($dbName,$sql);
			$query_update = "Update $Gsubjecttable Set Category = '$category' Where Course_year = '$course_year' AND Msubject = '$msubject_old[$cin]' AND Category = '$category_old' ";
		   $result_update = mysql_db_query($dbName,$query_update);  
			$query_update = "Update $Subjecttable Set Category = '$category' Where Course_year = '$course_year' AND Msubject = '$msubject_old[$cin]' AND Category = '$category_old' ";
		   $result_update = mysql_db_query($dbName,$query_update);  
		   }
			$gin++;
		}
	$cin++;
}
if ($pass == 'no')
{
		echo"
			 <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
 }
 else if ($pass_repeat == 'no')
{
		echo"
			 <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡��������Ǵ�Ԫҫ�������Ԫ���ѡ���ǡѹ��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
 }
 else if ( $pass == 'yes' )
{
echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
			<div align='center'><font size='2'><font face='Tahoma'>��������Ǵ�Ԫ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'structure_update_category.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			</tr></table>";
			MYSQL_CLOSE();
			}
?>
			
<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
