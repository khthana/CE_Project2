<html>
<head>
<title>�ʴ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="../script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><img src="images/l.gif" width="1" height="20"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width='772' border='0' cellspacing='0' cellpadding='0' align ='center'>
<?
echo "
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='130' bgcolor='#D2F8FD' valign='top' ><font size='2' face='Tahoma, Microsoft Sans Serif'><br>
      <a href='index.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ��</a></font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='structure.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a></font><font face='Tahoma, Microsoft Sans Serif' size='2'><br>
      Ἱ����֡��<br>
      <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
      &nbsp;</font></td>
	  	
    <td width='10' valign='top' >&nbsp; </td>
    <td width='609' valign='top'   > 
      <table width='100%' border='0' cellspacing='1' cellpadding='3'>
        <tr> 
          <td colspan='3' bgcolor='#F7F7F7'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><br>
              ��ѡ�ٵ����ǡ�����ʵúѳ�Ե �Ң��Ԫ����ǡ�������������<br>
              ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� <br>
              ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ<br>
              &nbsp; </font></div>
          </td>
        </tr>
        <tr> 
          <td colspan='3' bgcolor='#F7F7F7'> 
            <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14.3 
              Ἱ����֡��</b></font></div>
          </td>
        </tr>
        <tr> 
          <td width='10%' bgcolor='#F7F7F7'> </td>
          <td bgcolor='#F7F7F7' colspan='2'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14.3.1 
            ���������֡�ҷ�� 1</b></font><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
        </tr>
	    <tr> 
          <td width='10%' bgcolor='#F7F7F7'>&nbsp;</td>
          <td bgcolor='#D2F8FD' width='80%'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>- 
              <a href='program1.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ���Ҥ���� (4��)</a>&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
          </td>
          <td width='10%' bgcolor='#F7F7F7'>&nbsp;</td>
        </tr>
        <tr> 
          <td width='10%' bgcolor='#F7F7F7' height='15'>&nbsp;</td>
          <td bgcolor='#F7F7F7' height='15' colspan='2'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14.3.2 
            ���������֡�ҷ�� 2 </b></font></td>
        </tr>
			<tr> 
          <td width='10%' bgcolor='#F7F7F7'>&nbsp;</td>
          <td bgcolor='#D2F8FD' width='80%'> 
            <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'>- 
              <a href='program2.php?course_year=$course_year'>��ѡ�ٵû�ԭ�ҵ���Ҥ������ͧ 
              (3��)</a></font></div>
          </td>
          <td width='10%' bgcolor='#F7F7F7'>&nbsp;</td>
        </tr>";
?> 
        <tr> 
          <td colspan="3" bgcolor="#F7F7F7">&nbsp;</td>
        </tr>
      </table>
		      
    </td>
        </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
