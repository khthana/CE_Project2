<?
			session_start();
?>
<html>
<head>
<title>��䢢������Ҩ����</title>
<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>
<style type='text/css'>
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor='#FFFFFF'>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td height='13' width='96'>&nbsp;</td>
    <td height='13' width='321'>&nbsp;</td>
    <td height='13' width='36'>&nbsp;</td>
    <td width='108' height='13'>&nbsp;</td>
    <td width='2' height='13'>&nbsp;</td>
    <td width='106' height='13'>&nbsp;</td>
    <td width='107' height='13'>&nbsp;</td>
  </tr>
  <tr> 
    <td width='96'><img src='images/logo-kmitl0.gif' width='109' height='97'></td>
    <td width='321'> 
      <div align='center'><img src='images/CE.gif' width='265' height='70'></div>
    </td>
    <td width='36'>&nbsp;</td>
    <td width='108'><img src='images/r4.gif' width='108' height='80'></td>
    <td width='2'>&nbsp;</td>
    <td width='106'><img src='images/kingrama4-005.jpg' width='100' height='80'></td>
    <td width='107'><img src='images/kingrama4-012.jpg' width='100' height='80'></td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0' height='13'>
  <tr> 
    <td height='5' width='111'>&nbsp;</td>
    <td height='5' width='27'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
    <td height='5' width='200'><font size='2' face='Tahoma, Microsoft Sans Serif'>�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height='5' width='440'><font size='2' face='Tahoma, Microsoft Sans Serif'>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr bgcolor='#3E3EA8'> 
    <td width='10' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='95' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>˹���á</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>����Ԫ�</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>��дҹ����</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma, Microsoft Sans Serif'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>&nbsp;����ǡѺ���</font></font></font></font></div>
    </td>
    <td width='2'> 
      <div align='center'><font size='1'><font size='1'><font color='#FFFFFF'><font face='MS Sans Serif'><font face='MS Sans Serif'><font size='3'><font size='3'><font color='#FFFFFF'><font face='BrowalliaUPC'><font face='BrowalliaUPC'><font size='3'><font size='3'><font face='BrowalliaUPC'><font face='BrowalliaUPC'><font size='3'><img src='images/l.gif' width='1' height='20'></font></font></font><font color='#FFFFFF'></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width='10'>&nbsp;</td>
    <td width='95'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='2'>&nbsp;</td>
  </tr>
</table>
<table width='775' border='0' cellspacing='0' cellpadding='0' align ='center'>
<?
if ($user[1] == 'administrator' )
{
include ("connect_home.inc.php");
include ("dateth.inc.php");
}
	echo "
  <tr> 
    <td width='10' >&nbsp;</td>
    <td width='10' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='160' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      <a href='teacher_insert.html' >�����������Ҩ����</a><br>
		��䢢������Ҩ����<br>
      <a href='teacher_show_delete.php' >ź�������Ҩ����</a><br>
	   <a href='teacher_select.php' >���͡���˹��Ҩ����</a><br>
      <a href='teacher_show.php'>�ʴ��������Ҩ����</a><br>
       <a href='../../show_select_person.php'>��Ѻ˹����ѡ </a></font>
      <br>&nbsp;
      </td>
   <td width='594' valign='top' > ";

$last_update = dateth($x);
$sh = strlen($show_order);
$us = strlen($user_name);
$pw1 = strlen($passwd1);
$pw2 = strlen($passwd2);
$na = strlen($name);
$le = strlen($level);
$ba = strlen($bachelor);
$ma = strlen($master);
$do = strlen($doctor);
$name = htmlspecialchars($name);
$email = htmlspecialchars($email);
$level = htmlspecialchars($level);
$graduation = htmlspecialchars($graduation);
$research = htmlspecialchars($research);
$course = htmlspecialchars($course);
$meeting = htmlspecialchars($meeting);
$interest = htmlspecialchars($interest);
$experience = htmlspecialchars($experience);
$address = htmlspecialchars($address);
$tlink = htmlspecialchars($tlink);
$telephone = htmlspecialchars($telephone);
$graduation = eregi_replace(chr(13),"<br>",$graduation);
$graduation = eregi_replace(" ","&nbsp;",$graduation);
$research = eregi_replace(chr(13),"<br>",$research);
$research = eregi_replace(" ","&nbsp;",$research);
$course = eregi_replace(chr(13),"<br>",$course);
$course = eregi_replace(" ","&nbsp;",$course);
$meeting = eregi_replace(chr(13),"<br>",$meeting);
$meeting = eregi_replace(" ","&nbsp;",$meeting);
$interest = eregi_replace(chr(13),"<br>",$interest);
$interest = eregi_replace(" ","&nbsp;",$interest);
$experience = eregi_replace(chr(13),"<br>",$experience);
$experience = eregi_replace(" ","&nbsp;",$experience);
$address = eregi_replace(chr(13),"<br>",$address);
$address = eregi_replace(" ","&nbsp;",$address);
if((($sh != 0)&&($us != 0)&&($pw1 != 0)&&($pw2 != 0)&&($na != 0)&&($le != 0))&&(($ba != 0)||($ma != 0)||($do != 0)))
{
	if ($passwd1 == $passwd2)
	{
  $query_course = "Select * From $Officertable Where Username = '$user_name' AND Username != '$temp' ";
	$result_course = mysql_query($query_course);
	$number = mysql_numrows($result_course);
	$i=0;
	if ($i == $number) 
	{
		if (($pictureold != '')&&($picture!='none'))
		{
		   unlink("Picture_teacher_$idold/".$pictureold);
		  rmdir("Picture_teacher_$idold");
		}
		  $query_delete = "Delete  From $Officertable Where ID ='$idold' AND Status = '$user[4]' ";
	 	  $result_delete = mysql_db_query($dbName,$query_delete);
		
		if (($pictureold == '')&&($picture_name==''))
		{
		  $sql = "INSERT INTO $Officertable(Show_order,Username,Password,Status,Picture,Name,Email,Level,Graduation,Research,Bachelor,Master,Doctor,Course,Meeting,Interest,Experience,Address,Tlink,Last_update,Telephone) VALUES ('$show_order','$user_name','$passwd1','teacher','$pictureold','$name','$email','$level','$graduation','$research','$bachelor','$master','$doctor','$course','$meeting','$interest','$experience','$address','$tlink','$last_update','$telephone') ";
			$result = mysql_db_query($dbName,$sql);
			$query = "Select * From $Officertable Where Status = '$user[4]' order by ID Desc";
			$result = mysql_query($query);
			$number = mysql_numrows($result);
			$row = mysql_fetch_array($result);
			$id = $row[ID];
			$query_update = "Update $Select_teachertable Set ID = '$id' Where  ID = '$idold' ";
			$result_update = mysql_db_query($dbName,$query_update);
		}
		else
		if (($pictureold !='')&&(($picture_name=='')||($picture_name=='none')))
			{			
			 $sql = "INSERT INTO $Officertable(Show_order,Username,Password,Status,Picture,Name,Email,Level,Graduation,Research,Bachelor,Master,Doctor,Course,Meeting,Interest,Experience,Address,Tlink,Last_update,Telephone) VALUES ('$show_order','$user_name','$passwd1','teacher','$pictureold','$name','$email','$level','$graduation','$research','$bachelor','$master','$doctor','$course','$meeting','$interest','$experience','$address','$tlink','$last_update','$telephone') ";
			$result = mysql_db_query($dbName,$sql);
			$query = "Select * From $Officertable Where Status = '$user[4]' order by ID Desc";
					$result = mysql_query($query);
					$number = mysql_numrows($result);
					$row = mysql_fetch_array($result);
					$id = $row[ID];
					mkdir("Picture_teacher_$id",0777);
					copy("Picture_teacher_$idold/".$pictureold,"Picture_teacher_$id/".$pictureold);
					unlink("Picture_teacher_$idold/".$pictureold);
					rmdir("Picture_teacher_$idold");
					$query_update = "Update $Select_teachertable Set ID = '$id' Where  ID = '$idold' ";
					$result_update = mysql_db_query($dbName,$query_update);

		}
		else
		if ((($pictureold !='')&&($picture_name!=''))||(($pictureold =='')&&($picture_name!='')))
		{	
			$sql = "INSERT INTO $Officertable(Show_order,Username,Password,Status,Picture,Name,Email,Level,Graduation,Research,Bachelor,Master,Doctor,Course,Meeting,Interest,Experience,Address,Tlink,Last_update,Telephone) VALUES ('$show_order','$user_name','$passwd1','teacher','$picture_name','$name','$email','$level','$graduation','$research','$bachelor','$master','$doctor','$course','$meeting','$interest','$experience','$address','$tlink','$last_update','$telephone')";
			$result = mysql_db_query($dbName,$sql);
			$query = "Select * From $Officertable Where Status = '$user[4]' order by ID Desc";
					$result = mysql_query($query);
					$number = mysql_numrows($result);
					$row = mysql_fetch_array($result);
					$id = $row[ID];
					mkdir("Picture_teacher_$id",0777);
					copy($picture,"Picture_teacher_$id/".$picture_name);
			$query_update = "Update $Select_teachertable Set ID = '$id' Where  ID = '$idold' ";
			$result_update = mysql_db_query($dbName,$query_update);

		}
			echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma, Microsoft Sans Serif'>�������Ҩ������١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'teacher_show.php' target ='_parent'>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
		}
		else
	    {
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma, Microsoft Sans Serif'>�ժ�����͡�Թ�����������</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}
	}
			else
			{
				 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma, Microsoft Sans Serif'>��͡���������ʼ�ҹ�������͹�ѹ��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			}
		}
else {
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma, Microsoft Sans Serif'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			 MYSQL_CLOSE();
        }
?>
<table width='778' border='0' cellspacing='0' cellpadding='0' align ='center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align='center'>
	  <font face='Tahoma, Microsoft Sans Serif' size='1'>Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height='8'> 
      <hr align='center' width='95%' size='2'>
    </td>
  </tr>
  <tr> 
    <td> 
      <div align='center'></div>
    </td>
  </tr>
</table>
</body>
</html>