<?php
	session_start();
	include("webboard.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$query=mysql_db_query($dbname,$sql);
	$numrows = mysql_num_rows($query);
	$result = mysql_fetch_array($query);
	$ad_code = $result[ad_code];
	$tmp=session_id(); 
	if(($ad_code!=$id) or ($tmp!=$id)){
		require ('overtime.php');
		exit;
	}
	if($name=='root'){
		require ('head.php');
	}else{
		require ('head.php');
	}
				print "<form name='weblogin'  method='post'  action='del_admin2.php?q_id=$q_id&id=$tmp&name=$name''>";
				$sql = "select * from administrator";
				$db_query = mysql_db_query ($dbname, $sql) or die("�Դ��Ͱҹ�����������50");
				$nums_rows = mysql_num_rows($db_query);
				print "<table border=0  width=100% cellspacing=1 cellpadding=4>";
				print "<tr ><td bgcolor=$corlor_head align=center width=10><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B><CENTER>ź</CENTER></B></FONT></td>";
				print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>����-���ʡ��</b></font></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>User Name</b></font></td></tr>";
				for ($i=0;$i<$nums_rows;$i++){
				$result1 = mysql_fetch_array($db_query) or die("�Դ��Ͱҹ����������63");
				$ad_id = $result1[ad_id];
				$ad_name = $result1[ad_name];
				$ad_surname = $result1[ad_surname];
				$ad_user = $result1[ad_user];
				$ad_passwd = $result1[ad_passwd];
				$ad_passwd2 = $result1[ad_passwd2];

				$ad_id = stripslashes($ad_id);
				$ad_name = stripslashes($ad_name);
				$ad_surname = stripslashes($ad_surname);
				$ad_user = stripslashes($ad_user);
				$ad_passwd = stripslashes($ad_passwd);
				$ad_passwd2 = stripslashes($ad_passwd2);
				if($ad_user!="root"){
					print "<Tr> <Td bgcolor=$bg1 width=10><input type='checkbox' name='delad[$i]' value=$ad_id>";
					print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$ad_name $ad_surname</font></Td>";
					print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$ad_user</font></Td></tr>";
				}
		}	// end for
		print "</table>";
		print "<center><hr width='80%'>";
		print "<input type='submit' name='del' value='Delect'></center>";
		print "</form>";
?>