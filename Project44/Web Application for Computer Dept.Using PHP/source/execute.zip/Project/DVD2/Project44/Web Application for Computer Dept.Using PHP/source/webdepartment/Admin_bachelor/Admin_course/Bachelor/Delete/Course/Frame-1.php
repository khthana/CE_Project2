<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="600" border="0" cellspacing="0" cellpadding="0" align="left">
  <tr>
    <td>
      <table width="778" border="0" cellspacing="0" cellpadding="0" height="94" align="center">
        <tr> 
          <td height="12" width="96">&nbsp;</td>
        </tr>
        <tr> 
          <td width="96" height="98"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
          <td width="321" height="98"> 
            <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
          </td>
          <td width="36" height="98">&nbsp;</td>
          <td width="108" height="98"><img src="images/r4.gif" width="108" height="80"></td>
          <td width="2" height="98">&nbsp;</td>
          <td width="106" height="98"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
          <td width="107" height="98"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
        </tr>
      </table>
      <table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
        <tr> 
          <td height="19" width="111">&nbsp;</td>
          <td height="19" width="27"><font size="2" face="Tahoma"></font></td>
          <td height="19" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
          <td height="19" width="486"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
        </tr>
      </table>
      <table width="778" border="0" cellspacing="0" cellpadding="0" align="center" height="36">
        <tr> 
          <td width="10" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="109" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="109" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
          </td>
          <td width="10" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="108" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="108" bgcolor="#3E3EA8"> 
            <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="108" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="108" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
          </td>
          <td width="1" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
          <td width="111" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
          </td>
          <td width="10" bgcolor="#3E3EA8"> 
            <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
          </td>
        </tr>
        <tr> 
          <td width="10" height="0">&nbsp;</td>
          <td width="109" height="0">&nbsp;</td>
          <td width="1" height="0">&nbsp;</td>
          <td width="109" height="0">&nbsp;</td>
          <td width="10" height="0">&nbsp;</td>
          <td width="108" height="0">&nbsp;</td>
          <td width="1" height="0">&nbsp;</td>
          <td width="108" height="0">&nbsp;</td>
          <td width="1" height="0">&nbsp;</td>
          <td width="108" height="0">&nbsp;</td>
          <td width="1" height="0">&nbsp;</td>
          <td width="108" height="0">&nbsp;</td>
          <td width="1" height="0">&nbsp;</td>
          <td width="111" height="0">&nbsp;</td>
          <td width="10" height="0">&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
