<html>
<head>
<title>������ѡ�ٵû�ԭ���͡</title>
<meta http-equiv='Content-Type' content='text/html; charset=windows-874'>
<style type='text/css'>
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor='#FFFFFF'>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td height='13' width='96'>&nbsp;</td>
    <td height='13' width='321'>&nbsp;</td>
    <td height='13' width='36'>&nbsp;</td>
    <td width='108' height='13'>&nbsp;</td>
    <td width='2' height='13'>&nbsp;</td>
    <td width='106' height='13'>&nbsp;</td>
    <td width='107' height='13'>&nbsp;</td>
  </tr>
  <tr> 
    <td width='96'><img src='images/logo-kmitl0.gif' width='109' height='97'></td>
    <td width='321'> 
      <div align='center'><img src='images/CE.gif' width='265' height='70'></div>
    </td>
    <td width='36'>&nbsp;</td>
    <td width='108'><img src='images/r4.gif' width='108' height='80'></td>
    <td width='2'>&nbsp;</td>
    <td width='106'><img src='images/kingrama4-005.jpg' width='100' height='80'></td>
    <td width='107'><img src='images/kingrama4-012.jpg' width='100' height='80'></td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0' height='13'>
  <tr> 
    <td height='5' width='111'>&nbsp;</td>
    <td height='5' width='27'><font size='2' face='Tahoma'></font></td>
    <td height='5' width='200'><font size='2' face='Tahoma'>�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height='5' width='440'><font size='2' face='Tahoma'>ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr bgcolor='#3E3EA8'> 
    <td width='10' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='95' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>˹���á</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>����Ԫ�</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font face='Tahoma' size='2'><font color='#FFFFFF'>�ؤ�ҡ�</font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>��дҹ����</font></font></font></font></div>
    </td>
    <td width='1' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><img src='images/l.gif' width='1' height='20'></font></font></font></div>
    </td>
    <td width='94' bgcolor='#3E3EA8'> 
      <div align='center'><font size='2' face='Tahoma'><font color='#FFFFFF'><font color='#FFFFFF'><font color='#FFFFFF'>����ǡѺ���</font></font></font></font></div>
    </td>
    <td width='2'> 
      <div align='center'><font size='1'><font size='1'><font color='#FFFFFF'><font face='MS Sans Serif'><font face='MS Sans Serif'><font size='3'><font size='3'><font color='#FFFFFF'><font face='BrowalliaUPC'><font face='BrowalliaUPC'><font size='3'><font size='3'><font face='BrowalliaUPC'><font face='BrowalliaUPC'><font size='3'><img src='images/l.gif' width='1' height='20'></font></font></font><font color='#FFFFFF'></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width='10'>&nbsp;</td>
    <td width='95'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='1'>&nbsp;</td>
    <td width='94'>&nbsp;</td>
    <td width='2'>&nbsp;</td>
  </tr>
</table>
<table width='775' border='0' cellspacing='0' cellpadding='0' >
<?
include ('connect_course.inc.php');
	echo "
  <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF' >&nbsp;</td>
    <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      ��ѡ�ٵû�ԭ���͡</font> 
      <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_insert_course.php'>�ç���ҧ��ѡ�ٵ�</a><br>
	     <a href='structure_insert_main_subject.php'>�����Ԫ���ѡ����</a><br>
	  <a href='select_course_category.php'>������Ǵ�Ԫ�����</a><br>
     <a href='select_course_group.php'>�����Ң��Ԫ����� </a><br>
	  <a href='Doctor/Insert/Subject/select_course.php' >��������Ԫ����� </a><br>
     <a href='Doctor/Insert/Course/select_course.php'>�ǡ�èѴ�Ԫ����¹</a></font><br>
    <font color='#9900CC' face='Tahoma' size='2'><a href='detail.html'>��������´�Ԫ����¹</a> 
    <br>
	<a href='../../index.php'>��Ѻ˹����ѡ </a>
    <br>&nbsp;
    </font></td>
   <td width='619' valign='top' > ";

$co = strlen($course_year);
$ct = strlen($ctname);
$ce = strlen($cename);
$ft = strlen($ftname);
$st = strlen($stname);
$fe = strlen($fename);
$se = strlen($sename);
$course_year = htmlspecialchars($course_year);
$ctname = htmlspecialchars($ctname);
$cename = htmlspecialchars($cename);
$ftname = htmlspecialchars($ftname);
$stname = htmlspecialchars($stname);
$fename = htmlspecialchars($fename);
$sename = htmlspecialchars($sename);
$accept = htmlspecialchars($accept);
$philosophy_article = htmlspecialchars($philosophy_article);
$program = htmlspecialchars($program);
$property = htmlspecialchars($property);
$test = htmlspecialchars($test);
$csystem = htmlspecialchars($csystem);
$ctime = htmlspecialchars($ctime);
$register = htmlspecialchars($register);
$process = htmlspecialchars($process);
$place_tool = htmlspecialchars($place_tool);


$accept = eregi_replace(chr(13),"<br>",$accept);
$accept = eregi_replace(" ","&nbsp;",$accept);
$philosophy_article = eregi_replace(chr(13),"<br>",$philosophy_article);
$philosophy_article = eregi_replace(" ","&nbsp;",$philosophy_article);
$program = eregi_replace(chr(13),"<br>",$program);
$program = eregi_replace(" ","&nbsp;",$program);
$property = eregi_replace(chr(13),"<br>",$property);
$property = eregi_replace(" ","&nbsp;",$property);
$test = eregi_replace(chr(13),"<br>",$test);
$test = eregi_replace(" ","&nbsp;",$test);
$csystem = eregi_replace(chr(13),"<br>",$csystem);
$csystem = eregi_replace(" ","&nbsp;",$csystem);
$ctime = eregi_replace(chr(13),"<br>",$ctime);
$ctime = eregi_replace(" ","&nbsp;",$ctime);
$register = eregi_replace(chr(13),"<br>",$register);
$register = eregi_replace(" ","&nbsp;",$register);
$process = eregi_replace(chr(13),"<br>",$process);
$process = eregi_replace(" ","&nbsp;",$process);
$place_tool = eregi_replace(chr(13),"<br>",$place_tool);
$place_tool = eregi_replace(" ","&nbsp;",$place_tool);

if(($co != 0)&&($ct != 0)&&($ce != 0)&&($ft != 0)&&($st != 0)&&($fe != 0)&&($se != 0))
{
   $query_course = "Select * From $Introducetable Where Course_year  =  '$course_year'";
	$result_course = mysql_query($query_course);
	$number = mysql_numrows($result_course);
	$i=0;
	if ($i == $number) {
	$sql = "INSERT INTO $Introducetable(Course_year,Ctname,Cename,Ftname,Stname,Fename,Sename,Accept,Philosophy_Article,Program,Property,Test,Csystem,Ctime,Register,Process,Myear1,Myear2,Myear3,Myear4,Myear5,M1_year1,M1_year2,M1_year3,M1_year4,M1_year5,M2_year1,M2_year2,M2_year3,M2_year4,M2_year5,M3_year1,M3_year2,M3_year3,M3_year4,M3_year5,Msum1,Msum2,Msum3,Msum4,Msum5,Mend1,Mend2,Mend3,Mend4,Mend5,Dyear1,Dyear2,Dyear3,Dyear4,Dyear5,D1_year1,D1_year2,D1_year3,D1_year4,D1_year5,D2_year1,D2_year2,D2_year3,D2_year4,D2_year5,D3_year1,D3_year2,D3_year3,D3_year4,D3_year5,D4_year1,D4_year2,D4_year3,D4_year4,D4_year5,D5_year1,D5_year2,D5_year3,D5_year4,D5_year5,Dsum1,Dsum2,Dsum3,Dsum4,Dsum5,Dend1,Dend2,Dend3,Dend4,Dend5,Place_Tool) VALUES ('$course_year','$ctname','$cename','$ftname','$stname','$fename','$sename','$accept','$philosophy_article','$program','$property','$test','$csystem','$ctime','$register','$process','$myear1','$myear2','$myear3','$myear4','$myear5','$m1_year1','$m1_year2','$m1_year3','$m1_year4','$m1_year5','$m2_year1','$m2_year2','$m2_year3','$m2_year4','$m2_year5','$m3_year1','$m3_year2','$m3_year3','$m3_year4','$m3_year5','$msum1','$msum2','$msum3','$msum4','$msum5','$mend1','$mend2','$mend3','$mend4','$mend5','$dyear1','$dyear2','$dyear3','$dyear4','$dyear5','$d1_year1','$d1_year2','$d1_year3','$d1_year4','$d1_year5','$d2_year1','$d2_year2','$d2_year3','$d2_year4','$d2_year5','$d3_year1','$d3_year2','$d3_year3','$d3_year4','$d3_year5','$d4_year1','$d4_year2','$d4_year3','$d4_year4','$d4_year5','$d5_year1','$d5_year2','$d5_year3','$d5_year4','$d5_year5','$dsum1','$dsum2','$dsum3','$dsum4','$dsum5','$dend1','$dend2','$dend3','$dend4','$dend5','$place_tool')";
$result = mysql_db_query($dbName,$sql);
	echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>��������ѡ�ٵ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'structure_insert_course.php' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
		}
		else
	    {
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>�բ�������ѡ�ٵù����������</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}
		}
else {
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
			 MYSQL_CLOSE();
        }
?>
<table width='778' border='0' cellspacing='0' cellpadding='0'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align='center'><font face='Tahoma' size='1'>Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height='8'> 
      <hr align='center' width='95%' size='2'>
    </td>
  </tr>
  <tr> 
    <td> 
      <div align='center'></div>
    </td>
  </tr>
</table>
</body>
</html>