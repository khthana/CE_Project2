<HTML>
<HEAD>
<TITLE>forgetpass</TITLE>
<META http-equiv=Content-Type content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</HEAD>
<?
include("smtpmail.inc.php");
if($submit=='Submit')
{
print("<BODY text=#ffff00 bgColor=#ffffFF leftMargin=0 topMargin=0>");
include("connect.inc.php");
$dbname=register();
$sql="select * from regis where username='$login'";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");
$rows=mysql_num_rows($dbquery);	
if($rows!=0)
 {
 $d=date('d-m-Y');
 //�� email
$result=mysql_fetch_array($dbquery);
 $email=$login."@ce.kmitl.ac.th";
 $subject="repassword";
			
$message.="username&password �ͧ�س���\n";
$message.="username  :  ".$login."\n"; 
$message.="pass  :  ".$result[pass]."\n";
$message.="DATE   :  ".$d."\n";

smail($email,$subject,$message);// or die("�������ö�觨�������");
?>
     <div align="center">
          <br>
          <br> 
         <br>
          <p>
	<font style='font-size:15'><font face="tahoma"  color="#0033FF"><b>Complete</b></font></font></p>
         <p><font class=a><font color="#0033FF">username&password �ͧ�س��١��价�� server diamon ���º��������</font></font></p>
         <hr width="400">
        <br>
        </div>

<?
 }//if
else
   {
?>
<div align="center">
<br>  
<p><font style='font-size:15'><font face="tahoma"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="tahoma"  color="#FF0000">���ͧ�ҡ����բ����Ţͧ�س㹰ҹ������</font></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div>  

<?
 }
//�Դ�ҹ������
closedb();
}//if(submit)
else
{
?>
<br>
<table border=0 align=center width="760" >
<tr class=a>
<td valign=top class=a>

<table border=0 align=center width="80%" height='100%'>
<tr class=a>
<td valign=top class=a>

<table bgcolor=#6666FF border=1 align=center>
<tr class=a>
<td>
<FORM name=create_login onsubmit="return check();" 
action='forgetpass.php' method=post>
<TABLE width=488 align=center>
  <TBODY>
  <TR class=a>
    <TD class=a align=right colSpan=2>&nbsp;</TD></TR>
  <TR bgColor=#ffffcc>
    <TD class=a align=right colSpan=2>
      <DIV align=center><FONT color=#ffff00><B><FONT color=#0033cc 
      >Forget password</FONT></B></FONT></DIV></TD></TR>
  <TR class=a>
    <TD class=a align=right>&nbsp;</TD>
    <TD class=a>&nbsp;</TD></TR>
  <TR class=a>
    <TD class=a align=right height=2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B><FONT 
      color=#cccc00>E-Mail :</FONT></B></TD>
    <TD class=a height=2><FONT color=#cccc00><INPUT maxLength=8 size=8 
      name=login> @ce.kmitl.ac.th</FONT>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'tahoma', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
   <TR class=a>
    <TD class=a align=right>&nbsp;</TD>
    <TD class=a>&nbsp;</TD></TR>
  <TR bgColor=#ffffcc class=a>
    <TD class=a align=middle colSpan=2><a href='../project/index.php'><FONT color=#663300><b>HOME</b></FONT></a></TD></TR></TBODY></TABLE></FORM>
	</td>
	</tr>
</table>
<br>
<br>
<br>
<br>
<br>
<br>

<table width="760" border="0" cellspacing="0" cellpadding="0">
          <tr class=a>
    <td class=a>&nbsp;</td>
  </tr>
  <tr>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="550" size="2">
    </td>
  </tr>
  <tr class=a>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
<script language="JavaScript">
<!--
	function check()
{
	  var v1 = document.create_login.login.value;
      
        	   
	    if (v1.length==0)
           {
           alert("��س������������ú��ǹ");
           document.create_login.login.focus();           
		   return false;
           }
        else
           return true;
}
//-->
</script>
</td>
</tr>
</table>
</td>
</tr>
</table>

<?
}
?>
</BODY>
</HTML>