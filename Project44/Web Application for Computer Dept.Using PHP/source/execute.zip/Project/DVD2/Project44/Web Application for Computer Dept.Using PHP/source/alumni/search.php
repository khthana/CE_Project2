<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" "width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><img src="image/logo-kmitl.jpg" width="139" height="137"></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" height="137">
                <tr> 
                  <td><img src="image/logo-alumni.jpg" width="600" height="80"></td>
                </tr>
                <tr> 
                  <td>
                    <table width="100%" border="0" cellspacing="1" cellpadding="1"align="left" bordercolor="#000000" bgcolor="#000000">
                      <tr class = BNFont1 align="center"> 
                        <td bgcolor="#99CCFF" width="25%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="index.php"><b>Home</b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="register_form.php"><b>ŧ����¹</b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="login.php"><b>��䢢�����</b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td>
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000" height="100%">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="normal.php"><b>�Ҥ����</b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="cont.php"><img src="image/expand.jpg" width="16" height="15" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><b><a href="cont.php">�Ҥ������ͧ</a></b></font> 
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        
                          <td bgcolor="#CCCCFF" height="15"> 
                            <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1" color="#FFFFFF" class="fsize8" align="center"><b>&nbsp;<font color="#000000" size="2">����</font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                  </div>
                                </td>
                              </tr>
                            </table>
                          </td>
                        
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF" height="100%">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624"> 
              <div align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                  <tr>
                    <td> 
                      <div align="center">
     <?php
	include("alumni.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	if($select=="all"){
	$sql1= "SELECT * FROM data_alumni where std_id like '%$search%' or std_class like '%$search%' or std_fullname like '%$search%' or std_type1 like '%$search%' or std_nick like '%$search%' or std_type like '%$search%' or std_days like '%$search%' or std_day like '%$search%' or   std_mount like '%$search%' or std_year like '%$search%' or std_work like '%$search%' or std_position like '%$search%' or std_address_born like '%$search%' or std_address_now like '%$search%' or std_tel_home like '%$search%' or std_tel_work like '%$search%' or std_pager like '%$search%' or std_icq like '%$search%' or std_email like '%$search%' or std_homepage like '%$search%' order by std_id asc"; 
	}
	else if($select=="std_nick"){
	$sql1= "SELECT * FROM data_alumni WHERE std_nick like '%$search%' order by std_id asc"; 
	}
	else if($select=="std_fullname"){
	$sql1= "SELECT * FROM data_alumni WHERE std_fullname like '%$search%' order by std_id asc"; 
	}
	else{
	$sql1= "SELECT * FROM data_alumni WHERE std_id like '%$search%' order by std_id asc"; 
	}
	$db_query1 = mysql_db_query($dbname, $sql1) or die("�Դ��Ͱҹ�����������140");
	$nums_rows1 = mysql_num_rows($db_query1);
	if($nums_rows1!="0"){
     print "<center><table width=500 border=0 cellspacing=0 cellpadding=0>";
	print "<tr><td><center><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3 color=#003399><b>����</b></font></center></td><td><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3 color=#003399><b>����-���ʡ��</b></font></td><td><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3 color=#003399><b>�������</b></font></td><td><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3 color=#003399><b>��������</b></font></td></tr>";
		for ($i=0;$i<$nums_rows1;$i++){
		$result = mysql_fetch_array($db_query1);
		$std_number = $result[std_number];
		$std_id = $result[std_id ];
		$std_class = $result[std_class];
		$std_fullname = $result[std_fullname];
		$std_type1 = $result[std_type1];
		$std_nick = $result[std_nick];
		$std_type = $result[std_type];
		$std_days  = $result[std_days];
		$std_day  = $result[std_day];
		$std_mount  = $result[std_mount];
		$std_year  = $result[std_year];
		$std_position = $result[std_position ];
		$std_address_born = $result[std_address_born];
		$std_address_now= $result[std_address_now];
		$std_tel_home= $result[std_tel_home];
		$std_tel_work = $result[std_tel_work];
		$std_pager  = $result[std_pager];
		$std_icq  = $result[std_icq];
		$std_email  = $result[std_email];
		$std_homepage   = $result[std_homepage];
		$std_username  = $result[std_username];
		$std_password1 = $result[std_password1];
		$std_password2  = $result[std_password2];
		$std_datetime = $result[std_datetime];
		print "<tr><td align=center><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3><a href=\"show_std.php?std_id=$std_id\">$std_id</a></font></td><td><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>$std_fullname $std_sname</font></td><td><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>$std_nick</font></td><td><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=3>$std_datetime</font></td></tr>";
}
print "</table></center>";
}
 else{
	print "<br><center><font face=\"MS Sans Serif, Microsoft Sans Serif\"size=4 color=#003399> ";
	print "<b>��辺�����Źѡ�֡����蹹��</b></font></center>";
}	
?>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td height="100%">&nbsp;</td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>

  <div align="center"> </div>
 </center>
  <script language="JavaScript">
<!--
function checks()
{
      var v1 = document.SearchForm.search.value;
        if ( v1.length==0)
           {
           alert("��سһ�͹�ӷ���ͧ��ä���");
           document.SearchForm.search.focus();
           return false;
           }
		 else
           return true;
}
//-->
</script>

</body>
</html>
