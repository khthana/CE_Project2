<?php
session_start();
session_register("mem");
$m=session_id();
if($m==$mem[id1]){
}else{
	exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Administrator Tool</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<!-- �ѡ������͹仾���� Status Bar-->
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<p align="center"><img src="image/admin.jpg" width="480" height="65"></p>
<hr width="80%">
<?php
include("alumni.inc");
include("md5.js");
if($name&&$pwd){
	$pagesize = 30;
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$name'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	if($NRow==0){ 
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=login_edit.php">
<?php
	}
	else{
		$row = mysql_fetch_array($result);
		$pwd1=$row["ad_passwd"];
		$pwd1=MD5($pwd1).$challenge;
		$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
		if($name==$row["ad_user"] && $pwd==$pwd1) { 
			if($name=="root"){
?>
<p align="center"><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"><a href="regis_admin.php">Register</a> 
  | <a href="del_admin.php">ź��Ҫԡ</a> </font><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"> 
  | </font></b></font><font size="2"><a href="cont_edit.php">�ѡ�֡�ҵ�����ͧ</a></font> 
  | <a href="normal_edit.php"><font size="2">�ѡ�֡�һ���</font></a></b></font></p>
<?php
		}
		else{
?>
<p align="center"><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"><a href="cont_edit.php">�ѡ�֡�ҵ�����ͧ</a></font> 
  | <a href="normal_edit.php"><font size="2">�ѡ�֡�һ���</font></a></b></font></b></font></p>
<?php
}
			$mem[n]=$name;
			$mem[p]=$pwd;
			$mem[c]=$challenge;
//			print "$mem[n] $mem[p]";

			$gif_up = $a+($b*31)+$c;

			if (empty($page)){
				$page=1;
			}
			$q_sql = "select * from data_alumni";
			$q_db_query = mysql_db_query ($dbname, $q_sql);
			$num_rows = mysql_num_rows($q_db_query);
			$rt = $num_rows%$pagesize;
			if($rt!=0) { 
				$totalpage = floor($num_rows/$pagesize)+1; 
			}
			else{
				$totalpage = floor($num_rows/$pagesize); 
			}
			$goto = ($page-1)*$pagesize;
			$sql = "select * from data_alumni order by std_id desc limit $goto,$pagesize";
			$db_query = mysql_db_query ($dbname, $sql);
			if (!$db_query){
				print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
				exit;
			}
			else{
				$nums_rows = mysql_num_rows($db_query);
				print "<table border=0  width=780 cellspacing=1 cellpadding=4 align=center>";
				print "<tr><td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>���</b></font></td>";
//				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>�ѡ�֡��</b></font></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B>���ʹѡ�֡��</B></FONT></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>����-���ʡ��</b></font></td>";
				print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Ip</b></font></td></tr>";
				for ($i=0;$i<$nums_rows;$i++){
					$result = mysql_fetch_array($db_query);
					$std_number = $result[std_number];
					$mem[n]=$name;
					$mem[p]=$pwd;
					$mem[c]=$challenge;
					$std_id = $result[std_id ];
					$std_class = $result[std_class];
					$std_fullname = $result[std_fullname];
					$std_type1 = $result[std_type1];
					$std_nick = $result[std_nick];
					$std_type = $result[std_type];
					$std_days  = $result[std_days];
					$std_day  = $result[std_day];
					$std_mount  = $result[std_mount];
					$std_year  = $result[std_year];
					$std_position = $result[std_position ];
					$std_address_born = $result[std_address_born];
					$std_address_now= $result[std_address_now];
					$std_tel_home= $result[std_tel_home];
					$std_tel_work = $result[std_tel_work];
					$std_pager  = $result[std_pager];
					$std_icq  = $result[std_icq];
					$std_email  = $result[std_email];
					$std_homepage  = $result[std_homepage];
					$std_username  = $result[std_username];
					$std_password1 = $result[std_password1];
					$std_password2  = $result[std_password2];
					$std_question  = $result[std_question];
					$std_answer  = $result[std_answer];

					$std_id=stripslashes($std_id);
					$std_class = stripslashes($std_class);
					$std_fullname = stripslashes($std_fullname);
					$std_type1 = stripslashes($std_type1);
					$std_nick = stripslashes($std_nick);
					$std_type = stripslashes($std_type);
					$std_days  = stripslashes($std_days);
					$std_day  = stripslashes($std_day);
					$std_mount  = stripslashes($std_mount);
					$std_year  = stripslashes($std_year);
					$std_position = stripslashes($std_position );
					$std_address_born = stripslashes($std_address_born);
					$std_address_now= stripslashes($std_address_now);
					$std_tel_home= stripslashes($std_tel_home);
					$std_tel_work = stripslashes($std_tel_work);
					$std_pager  = stripslashes($std_pager);
					$std_icq  = stripslashes($std_icq);
					$std_email  = stripslashes($std_email);
					$std_homepage   = stripslashes($std_homepage);
					$std_question   = stripslashes($std_question);
					$std_answer   = stripslashes($std_answer);
/*					print "<Tr> <Td bgcolor=$bg1><input type='radio' name='delq[$i]' value=$q_id>";
					print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
					print "<Td  bgcolor=$bg3 width=40%><a href=\"admin_view_answer.php?q_id=$q_id\" target=\"_blank\">";
					print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
					print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
					print "<Td  bgcolor=$bg3 ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_ip</font></Td>";
					print "<Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
*/				}	// end for
				print "</table>";
			} // end else
			print "<table border=0 width=100%><tr>";
			print"<td><div align=left><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1></font></td>";
			print "<td align=right>";
//			print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Page </font>";
			for($i=1 ; $i<$page ; $i++){
//				print "<a href='$PHP_SELF?page=$i'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
			}
//			print "<font face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1  color=red><b>$page</b></font> ";
			for($i=$page+1 ; $i<=$totalpage ; $i++){
//				print "<a href=$PHP_SELF?page=$i><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
			}
			print"</td>";
			print"</tr></table></td></tr></table>";
		 }	
		else{
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=login_edit.php">

<?php
		}
	}
}
?>
</body>
</html>