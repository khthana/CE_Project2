<html>
<head>
<title>��ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="154" border="0" cellspacing="0" cellpadding="0" height="100%" align="right">
<?
	echo"
	<tr> 
    <td width='8%' bgcolor='#EAEAFF'>&nbsp;</td>
    <td width='86%' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='../../../introduce_delete.php?course_year=$course_year' target ='_parent'>ź��ѡ�ٵû�ԭ���͡</a></font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='../../../structure_delete_course.php?course_year=$course_year' target ='_parent'>ź�ç���ҧ��ѡ�ٵ�</a><br>
	    <a href='../../../structure_delete_main_subject.php?course_year=$course_year' target ='_parent'> ź�������Ԫ���ѡ</a><br>
	  <a href='../../../structure_delete_category.php?course_year=$course_year' target ='_parent'>ź��������Ǵ�Ԫ�</a><br>
      <a href='../../../structure_delete_group.php?course_year=$course_year' target ='_parent'>ź�������Ң��Ԫ� </a><br>
		ź����������Ԫ� <br>
      <a href='../Course/delete_course.php?course_year=$course_year'  target ='_parent'>ź�ǡ�èѴ�Ԫ����¹</a></font> <font size='2' face='Tahoma'><br>
      <a href='../../../index.php' target ='_parent'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;
      </td></tr>";
  ?>
</table>
</body>
</html>
