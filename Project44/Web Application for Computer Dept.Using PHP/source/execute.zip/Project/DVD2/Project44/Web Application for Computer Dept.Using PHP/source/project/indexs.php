<?   session_start();
		if($id[1])
         { 
		?>
<html>
<head>
<title>�ç�ҹ</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
</head>
<frameset rows="105,*" frameborder="no" border="0" framespacing="0" cols="*"> 
  <frame name="head" scrolling="NO" noresize src="heads.php" >
  <frameset cols="125,*" frameborder="NO" border="0" framespacing="0" rows="*"> 
    <frame name="left" src="lefts.php" scrolling="no" noresize>
    <frame name="body" src="bodys.php" scrolling="yes" noresize>
  </frameset>
</frameset>
<?
 }	
?>
