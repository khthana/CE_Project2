<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">USER</font><font color="#FF0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep"><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></font></div>
    </td>
  </tr>
</table>
</body>
</html>
