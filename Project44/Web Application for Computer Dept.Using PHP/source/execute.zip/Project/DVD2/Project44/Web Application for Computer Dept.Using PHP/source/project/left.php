<?session_start();
?>
<html>
<head>
<title>left</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<!---body background="images/bg_left.gif">-->
<body bgcolor=#391E8C>
<table width='100%' border="0" cellspacing="0" cellpadding="0" >
<tr>
<td>
<?
 include("connect.inc.php");
 $dbname=project();
?>
<form method="post" action='body.php' target=body name=form1>
<table width=95 border="0" height=600 align="center">
  <tr class=A> 
    <td valign="middle" height="13"><br><br>&nbsp;</td>
  </tr>
   <tr class=A> 
    <td valign="top" height=150>    
        <table width=95 border="0" cellspacing="0" align="center" height=118>
          <tr class=A> 
            <td width=20 align="center" valign="middle" height=23><font class=A> 
              <select name=year1 size="1">
                <?	
						 //�֧������ year �ҡ���ҧ register
                         $sql="select Distinct year from register order by year desc";
                         $dbquery=mysql_db_query($dbname,$sql)or die("error2");
                        ?>
                <option selected>-�ҡ�ա���֡��-</option>
                <?
			               while($result=mysql_fetch_array($dbquery))
		                       {				  
                                 ?>
                <option> 
                <?print($result[year]);?>
                </option>
                <?
		                  		 }
			             ?>
              </select>
              </font></td>
          </tr>
          <tr class=A> 
            <td width=130 height=36 valign="middle" > 
              <div align="center"><font color="#FFFFFF" class=A>�֧&nbsp;</font></div>
            </td>
          </tr>
          <tr class=A> 
            <td width=20 height=8 valign="middle"> 
              <div align="center"> 
                <select name=year2 size="1"><font class=A>
                  <?	
						 //�֧������ year �ҡ���ҧ register
                         $sql="select Distinct year from register order by year desc";
                         $dbquery=mysql_db_query($dbname,$sql)or die("error2");
                        ?>
                  <option selected>-�֧�ա���֡��-</option>
                  <?
			               while($result=mysql_fetch_array($dbquery))
		                       {				  
                                 ?>
                  <option> 
                  <?print($result[year]);?>
                  </option>
                  <?
		                  		 }
			             ?>
                </font>
				</select>
              </div>
            </td>
          </tr>
          <tr class=A> 
            <td width=130 height=50 valign="middle"> 
              <div align="center"> 
                <input type="image" src="images/go.gif" name="image">
              </div>
            </td>
          </tr>
        </table>
        <div align="center">&nbsp;</div>
      
    <td height="51"></form>
  
    </td>
    <td height="61"></tr>
  
  <tr class=A> 
    <td valign="middle" height=59 align="center"><form method="post" action='body.php' target=body name=form2> 
      <div align="center"> 
          <input type="text" name="word" size="15">
        </div>
    </td>
  </tr>
  <tr class=A> 
    <td valign="top" height=40> 
      <div align="center"> 
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'ms Sans Serif', system; font-size: 9pt; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Search name=search>
      </div>
    </td>
  </tr>
  <tr class=A> 
    <td>&nbsp;
  </td>
  </tr>
</table>
</form>
</td>
  </tr>
</table>
</body>
</html>
