<?php
	session_start();
	session_destroy();
	session_unset();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Welcome to Alumni computer engineering.</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad=""><center>
  <table  border="0" cellpadding="0" cellspacing="0" width=760>
    <TBODY> 
    <tr align="left" valign="top"> 
      <td colspan="3" align="left">
        <table width="780" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td width="150"><img src="image/logo-kmitl.jpg" width="139" height="137"></td>
            <td width="624"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" h                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">Home</font></b></a></font></td>
                        <td bgcolor="#99CCFF" width="37%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="register_form.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">ŧ����¹</font></b></a></font></td>
                        <td bgcolor="#99CCFF" width="38%"><font face="MS Sans Serif, CordiaUPC" size=3><a href="login.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">��䢢�����</font></b></a></font></td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td>
                    <hr width="100%" align="left">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td width="150" height="187"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" bgcolor="#000000">
                <tr> 
                  <td height="20" bgcolor="#f7f7f7"> 
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="normal.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="normal.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�Ҥ����</font></b></a></font></td>
                      </tr>
                      <tr> 
                        <td width="20" bgcolor="#FFFFFF"><a href="cont.php"><img src="image/expand.jpg" width="16" height="16" border="0"></a></td>
                        <td width="78%" bgcolor="#FFFFFF"><font face="MS Sans Serif, CordiaUPC" size=3><a href="cont.php"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">�Ҥ������ͧ</font></b></a></font> 
                          <font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"></font></td>
                      </tr>
                      <tr>
                        <td width="20" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                        <td width="78%" bgcolor="#FFFFFF" height="20">&nbsp;</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#ffffff"> 
                    <form method=post action="search.php" name="SearchForm" onSubmit="return checks()">
                      <table width="150" cellspacing="1" border="0" bordercolor="#000000" bgcolor="#000000" height="110" cellpadding="1" align="center">
                        
                          <td bgcolor="#CCCCFF" height="15"> 
                            <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1" color="#FFFFFF" class="fsize8" align="center"><b><font face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep">&nbsp;<font color="#000000" size="2">����</font></font></b></font></div>
                        </td>
                        </tr>
                        <tr valign="top"> 
                          <td height="0" bgcolor="#FFFFFF"> 
                            <table width="100%" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <div align="center"><font face="MS Sans Serif, CordiaUPC" size="1"> 
                                      <input type="text" name="search" size="14">
                                      </font> </div>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <select name="select">
                                      <option value="all" selected>- - - - all 
                                      - - - - </option>
                                      <option value="std_nick">�������</option>
                                      <option value="std_fullname">���ͨ�ԧ</option>
                                      <option value="std_sname">���ʡ��</option>
                                      <option value="std_id">���ʹѡ�֡��</option>
                                    </select>
                                  </div>
                                </td>
                              </tr>
                              <tr> 
                                <td bgcolor="#FFFFFF" bordercolor="#FFFFFF"> 
                                  <div align="center"> 
                                    <input type='image' border='0' name='imageField1' src='image/go.jpg' width='19' height='19' alt='search'>
                                  </div>
                                </td>
                              </tr>
                            </table>
                          </td>
                        
                      </table>
                    </form>
                  </td>
                </tr>
                <tr> 
                  <td align=center bgcolor="#FFFFFF">&nbsp;</td>
                </tr>
              </table>
            </td>
            <td bgcolor="#FFFFFF" width="624"> 
              <div align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                  <tr> 
                    <td> 
                      <div align="center"> 
<?php
	include("alumni.inc");
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	If (($std_id=="") or ($std_type=="") or ($std_class=="") or ($std_fullname=="") or ($std_email=="")or ($std_password1=="") or ($std_password2=="") or ($std_username=="") or ($std_answer=="") or ($std_question==""))	{
		echo "<br><center><font  size=4>�ô��͡���������ú (��੾�п�Ŵ����� *)</font>";
		echo "<br><a href =\"am_form.html\"><font  >��͡����������</font></a></center><br>";
		print "<META http-equiv=refresh content=\"2; URL=index.html\">";
		exit;
	}
	ElseIf ($std_password1<>$std_password2)	{
		echo "<br><center><font  >��Ŵ� Login_password ��� Password Again ���ç�ѹ</font>";
		echo "<br><a href =\"am_form.html\"><font size=4 >��͡����������</font></a></center><br>";
		print "<META http-equiv=refresh content=\"2; URL=index.html\">";
		exit;
	}
Else	{ 
		if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])",$std_email)){
		$std_id = htmlspecialchars($std_id);
		$std_class = htmlspecialchars($std_class);
		$std_fullname = htmlspecialchars($std_fullname);
		$std_nick = htmlspecialchars($std_nick);
		$std_type = htmlspecialchars($std_type);
		$std_type1 = htmlspecialchars($std_type1);
		$days= htmlspecialchars($days);
		$day= htmlspecialchars($day);
		$mount= htmlspecialchars($mount);
		$year= htmlspecialchars($year);
		$std_work = htmlspecialchars($std_work);
		$std_position = htmlspecialchars($std_position);
		$std_address_now = htmlspecialchars($std_address_now);
		$std_tel_home = htmlspecialchars($std_tel_home);
		$std_tel_work = htmlspecialchars($std_tel_work);
		$std_pager = htmlspecialchars($std_pager);
		$sstd_icq = htmlspecialchars($sstd_icq);
		$std_email = htmlspecialchars($std_email);
		$std_username = htmlspecialchars($std_username);
		$std_password1 = htmlspecialchars($std_password1);
		$std_password2 = htmlspecialchars($std_passwrk2);
		$std_homepage = htmlspecialchars($std_homepage);
		$std_question = htmlspecialchars($std_question);
		$std_answer = htmlspecialchars($std_answer);

		$std_id = nl2br($std_id);
		$std_class = nl2br($std_class);
		$std_fullname = nl2br($std_fullname);
		$std_nick = nl2br($std_nick);
		$std_type = nl2br($std_type);
		$std_type1 = nl2br($std_type1);
		$days= nl2br($days);
		$day= nl2br($day);
		$mount= nl2br($mount);
		$year= nl2br($year);
		$std_work = nl2br($std_work);
		$std_position = nl2br($std_position);
		$std_address_now = nl2br($std_address_now);
		$std_tel_home = nl2br($std_tel_home);
		$std_tel_work = nl2br($std_tel_work);
		$std_pager = nl2br($std_pager);
		$sstd_icq = nl2br($sstd_icq);
		$std_email = nl2br($std_email);
		$std_username = nl2br($std_username);
		$std_password1 = nl2br($std_password1);
		$std_password2 = nl2br($std_passwrk2);
		$std_homepage = nl2br($std_homepage);
		$std_question = nl2br($std_question);
		$std_answer = nl2br($std_answer);

		$std_id = addslashes($std_id);
		$std_class = addslashes($std_class);
		$std_fullname = addslashes($std_fullname);
		$std_nick = addslashes($std_nick);
		$std_type = addslashes($std_type);
		$std_type1 = addslashes($std_type1);
		$days= addslashes($days);
		$day= addslashes($day);
		$mount= addslashes($mount);
		$year= addslashes($year);
		$std_work = addslashes($std_work);
		$std_position = addslashes($std_position);
		$std_address_now = addslashes($std_address_now);
		$std_tel_home = addslashes($std_tel_home);
		$std_tel_work = addslashes($std_tel_work);
		$std_pager = addslashes($std_pager);
		$sstd_icq = addslashes($sstd_icq);
		$std_email = addslashes($std_email);
		$std_username = addslashes($std_username);
		$std_password1 = addslashes($std_password1);
		$std_password2= addslashes($std_passwrk2);
		$std_homepage = addslashes($std_homepage);
		$std_question = addslashes($std_question);
		$std_answer = addslashes($std_answer);

		$std_id = eregi_replace(" ","&nbsp;",$std_id);
		$std_class = eregi_replace(" ","&nbsp;",$std_class);
		$std_fullname = eregi_replace(" ","&nbsp;",$std_fullname);
		$std_nick = eregi_replace(" ","&nbsp;",$std_nick);
		$std_type = eregi_replace(" ","&nbsp;",$std_type);
		$std_type1 = eregi_replace(" ","&nbsp;",$std_type1);
		$days= eregi_replace(" ","&nbsp;",$days);
		$day= eregi_replace(" ","&nbsp;",$day);
		$mount= eregi_replace(" ","&nbsp;",$mount);
		$year= eregi_replace(" ","&nbsp;",$year);
		$std_work = eregi_replace(" ","&nbsp;",$std_work);
		$std_position = eregi_replace(" ","&nbsp;",$std_position);
		$std_address_now = eregi_replace(" ","&nbsp;",$std_address_now);
		$std_tel_home = eregi_replace(" ","&nbsp;",$std_tel_home);
		$std_tel_work = eregi_replace(" ","&nbsp;",$std_tel_work);
		$std_pager = eregi_replace(" ","&nbsp;",$std_pager);
		$sstd_icq = eregi_replace(" ","&nbsp;",$sstd_icq);
		$std_ip = getenv(remote_addr);

		setlocale("LC_TIME","th");	
		$a = date("j");
		$b = strftime("%m");
		$c = strftime("%y");
		$d = date("H:i:s");
		$std_datetime = "$a/$b/$c:$d";
		$sql3= "SELECT * FROM data_alumni WHERE std_username = '$std_username'"; 
		$db_query3 = mysql_db_query($dbname, $sql3);
		$nums_rows3 = mysql_num_rows($db_query3);
		if($nums_rows3=="0"){
		if($std_type=="������ͧ"){
			if(($std_class<=$maxcon) and ($std_class>=$mincon)){
				$sql1= "SELECT * FROM data_alumni WHERE std_id = '$std_id'"; 
				$db_query1 = mysql_db_query($dbname, $sql1);
				$nums_rows1 = mysql_num_rows($db_query1);
				if($nums_rows1=="0"){
					$sql2= "SELECT * FROM data_alumni WHERE std_fullname = '$std_fullname' and std_class='$std_class'"; 
					$db_query2 = mysql_db_query($dbname, $sql2);
					$nums_rows2 = mysql_num_rows($db_query2);
					if($nums_rows2=="0"){
						$sql = "insert into $tblname (std_number, std_id, std_class, std_fullname, std_type1, std_nick, std_type, std_days, std_day, std_mount, std_year, std_work, std_position, std_address_born, std_address_now, std_tel_home, std_tel_work, std_pager, std_icq, std_email, std_homepage, std_username, std_password1, std_password2, std_datetime, std_ip, std_question,std_answer) values ('', '$std_id', '$std_class', '$std_fullname', '$std_type1', '$std_nick', '$std_type', '$days', '$day', '$mount', '$year', '$std_work', '$std_position', '$std_address_born', '$std_address_now', '$std_tel_home', '$std_tel_work', '$std_pager', '$std_icq', '$std_email', '$std_homepage', '$std_username', '$std_password1', '$std_password2', '$std_datetime', '$std_ip', '$std_question', '$std_answer')";	
						$dbquery = mysql_db_query($dbname, $sql);
						echo "<br><center><font size=4>�����ŧ�ͧ��ҹŧ DATABASE ���º�������Ǥ�Ѻ</font><br>";
						print "<META http-equiv=refresh content=\"2; URL=index.html\">";
					}//end post repeat;
					else{
						echo "<br><center><font size=4>�������ö�Ӣ�����ŧ DATABASE ��</font><br>";
						echo "<br><center><font size=4>���ͧ�ҡ�ա�â����Ţͧ��ҹ��������</font><br>";
						print "<META http-equiv=refresh content=\"2; URL=index.html\">";
					} // end post repeat;
				}// end if id repeat;
				else{
					echo "<br><center><font size=4>�������ö�Ӣ�����ŧ DATABASE ��</font><br>";
					echo "<br><center><font size=4>���ͧ�ҡ���ʹ���դ�����������</font><br>";
					print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				}// end id repeat;
			}//end if check size con
			else{
				echo "<br><center><font  size=4>�ѡ�֡�ҵ�����ͧ��蹴ѧ������������Ҥ�Ԫ�</font><br>";
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			} // end check size con
		}// end if check con
		else{
			if(($std_class<=$maxnormal) and ($std_class>=$minnormal)){
				$sql1= "SELECT * FROM data_alumni WHERE std_id = '$std_id'"; 
				$db_query1 = mysql_db_query($dbname, $sql1);
				$nums_rows1 = mysql_num_rows($db_query1);
				if($nums_rows1=="0"){
					$sql2= "SELECT * FROM data_alumni WHERE std_fullname = '$std_fullname' and std_class='$std_class'"; 
					$db_query2 = mysql_db_query($dbname, $sql2);
					$nums_rows2 = mysql_num_rows($db_query2);
					if($nums_rows2=="0"){
						$sql = "insert into $tblname (std_number, std_id, std_class, std_fullname, std_type1, std_nick, std_type, std_days, std_day, std_mount, std_year, std_work, std_position, std_address_born, std_address_now, std_tel_home, std_tel_work, std_pager, std_icq, std_email, std_homepage, std_username, std_password1, std_password2, std_datetime, std_ip,std_question,std_answer) values ('', '$std_id', '$std_class', '$std_fullname', '$std_type1', '$std_nick', '$std_type', '$days', '$day', '$mount', '$year', '$std_work', '$std_position', '$std_address_born', '$std_address_now', '$std_tel_home', '$std_tel_work', '$std_pager', '$std_icq', '$std_email', '$std_homepage', '$std_username', '$std_password1', '$std_password2', '$std_datetime', '$std_ip', '$std_question', '$std_answer')";	
						$dbquery = mysql_db_query($dbname, $sql);
						echo "<br><center><font  size=4>�����ŧ�ͧ��ҹŧ DATABASE ���º�������Ǥ�Ѻ</font><br>";
						print "<META http-equiv=refresh content=\"2; URL=index.html\">";
					}//end post repeat;
					else{
						echo "<br><center><font size=4>�������ö�Ӣ�����ŧ DATABASE ��</font><br>";
						echo "<br><center><font size=4>���ͧ�ҡ�ա�â����Ţͧ��ҹ��������</font><br>";
						print "<META http-equiv=refresh content=\"2; URL=index.html\">";
					} // end post repeat;
				}// end if id repeat;
				else{
					echo "<br><center><font  size=4>�������ö�Ӣ�����ŧ DATABASE ��</font><br>";
					echo "<br><center><font size=4>���ͧ�ҡ���ʹ���դ�����������</font><br>";
					print "<META http-equiv=refresh content=\"2; URL=index.html\">";
				}// end id repeat;
			} // end if check size normal
			else{
				echo "<br><center><font  size=4>�ѡ�֡���Ҥ������蹴ѧ������������Ҥ�Ԫ�</font><br>";
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			} // end check size normal
		} //end normal 
		} // end check username
		else{
				echo "<br><center><font  size=4 color=#FF0000> USER NAME ����դ������Ǥ�Ѻ</font><br><br>";
				print "<META http-equiv=refresh content=\"2; URL=index.html\">";
			} // end check size normal

}// end if check email
else{
		echo "<br><center><font  size=4> ��سҡ�͡ Email �ͧ��ҹ����</font><br><br>";
		print "<META http-equiv=refresh content=\"2; URL=index.html\">";
} // end check email
}// end check repeat;
?>
                      </div>
                    </td>
                  </tr>
                  <tr> 
                    <td>
                      <div align="center">
                        <input type=button onClick="history.back();" value="Back" name="button">
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td height="100%">&nbsp;</td>
                  </tr>
                </table>
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    </TBODY> 
  </table>

  <div align="center"> </div>
 </center>
 <script language="JavaScript">
<!--
function checks()
{
      var v1 = document.SearchForm.search.value;
        if ( v1.length==0)
           {
           alert("��سһ�͹�ӷ���ͧ��ä���");
           document.SearchForm.search.focus();
           return false;
           }
		 else
           return true;
}
//-->
</script>

</body>
</html> 