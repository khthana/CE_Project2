<html>
<head>
<title>�ç���ҧ��ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = 'WNFont'>  
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../index.php">��ѡ�ٵ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../../../about/index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
<?
include ("connect_course.inc.php");
    $query = "Select * From $Structuretable Where Course_year = '$course_year' ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) 
	{
	while ($row = mysql_fetch_array($result))
		{
	$detail = $row[Detail];
	$detail_bachelor = $row[Detail_bachelor];
	$detail_master = $row[Detail_master];
	$program1_unit = htmlspecialchars($row[Program1_unit]);
	$program2_unit = htmlspecialchars($row[Program2_unit]);
		}
	}

echo "
	<tr> 
    <td width='11'  >&nbsp;</td>
    <td width='14' bgcolor='#EAEAFF'  >&nbsp;</td>
    <td width='134' bgcolor='#EAEAFF' valign='top' ><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'><br>
     <a href='index.php?course_year=$course_year'>��ѡ�ٵû�ԭ���͡</a></font><font face='Tahoma, Microsoft Sans Serif' size='2' ><br>�ç���ҧ��ѡ�ٵ�<br></font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#9900CC'>
      <a href='tendency.php?course_year=$course_year'>Ἱ����֡��</a><br>
      <a href='show_group_all.php?course_year=$course_year'>��������´�Ԫ�</a><br>
</font></td>
    <td width='619' valign='top'>         
      <table width='600' border='0' cellspacing='1' cellpadding='4' align='center' bordercolor='#FFFFFF' >
        <tr> 
            <td height='21' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma, Microsoft Sans Serif' size='2'><font size='2'><font size='2'></font></font></font> 
                <font size='2' face='Tahoma, Microsoft Sans Serif'></font><font face='Tahoma, Microsoft Sans Serif' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵô�ɮպѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year<br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ <br>
                &nbsp; </font></div>
            </td>
          </tr>
          <tr> 
            <td height='25' colspan='4' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>14. 
              ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td height='25' colspan='4' bgcolor='#F7F7F7'> 
              <div align='left'><font size='2'><font size='2'><font face='Tahoma, Microsoft Sans Serif'><b>14.1 
                �ӹǹ˹��¡Ե�����ʹ��ѡ�ٵ�</b></font></font></font></div>
            </td>
          </tr>
          <tr> 
            <td height='52' rowspan='2' bgcolor='#F7F7F7' width='28'><font size='2' face='Tahoma, Microsoft Sans Serif'></font></td>
            
          <td height='25' width='189' bgcolor='#EAEAFF'> 
            <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>- ����Ѻ��騺��ԭ���</font></div>
            </td>
            
          <td height='25' width='349' bgcolor='#EAEAFF'> &nbsp; <font face='Tahoma, Microsoft Sans Serif' size='2'> 
            $program1_unit ˹��¡Ե </font></td>
            <td height='52' rowspan='2' bgcolor='#F7F7F7' width='24'>&nbsp;</td>
          </tr>
          <tr> 
            
          <td height='25' width='189' bgcolor='#EAEAFF'> 
            <div align='left'><font size='2' face='Tahoma, Microsoft Sans Serif'>- ����Ѻ��騺��ԭ�ҵ��</font></div>
            </td>
            
          <td height='25' width='349' bgcolor='#EAEAFF'> &nbsp;<font face='Tahoma, Microsoft Sans Serif' size='2'> 
            $program2_unit ˹��¡Ե </font></td>
          </tr>
          <tr> 
            <td height='25' colspan='3' bgcolor='#F7F7F7'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>14.2 
              �ç���ҧ��ѡ�ٵ�</b></font></td>
            <td height='202' rowspan='7' bgcolor='#F7F7F7' width='24'>&nbsp;</td>
          </tr>
          <tr> 
            <td height='292' rowspan='6' bgcolor='#F7F7F7' width='28'><font size='2' face='Tahoma, Microsoft Sans Serif'></font><font face='Tahoma, Microsoft Sans Serif' size='2'></font> 
            </td>
            <td height='25' colspan='2' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>����Ѻ��騺��ԭ���</b></font> 
            </td>
          </tr>
          <tr> 
            <td height='25' colspan='2' bgcolor='#EAEAFF'> <font size='2' face='Tahoma, Microsoft Sans Serif'>$detail_master 
              </font></td>
          </tr>
          <tr> 
            <td height='25' colspan='2' bgcolor='#F7F7F7'><font size='2' face='Tahoma, Microsoft Sans Serif'><b>����Ѻ��騺��ԭ�ҵ��</b></font></td>
          </tr>
          <tr bgcolor='#F7F7F7'> 
            <td height='25' colspan='2' bgcolor='#EAEAFF'> <font face='Tahoma, Microsoft Sans Serif' size='2'>$detail_bachelor</font></td>
          </tr>
          <tr> 
            <td height='25' colspan='2' bgcolor='#F7F7F7'><font face='Tahoma, Microsoft Sans Serif' size='2'><b>��͸Ժ������˵ؼŷ��е�ͧ�֡���Ԫҵ�ҧ� 
              �մѧ��� </b></font></td>
          </tr>
          <tr> 
            <td height='25' colspan='2' bgcolor='#EAEAFF'> <font face='Tahoma, Microsoft Sans Serif' size='2'>$detail</font></td>
          </tr>
          <tr> 
            <td height='25' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'> </div>
            </td>
          </tr>
        </table>";
	   ?>
    </td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ�����webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
