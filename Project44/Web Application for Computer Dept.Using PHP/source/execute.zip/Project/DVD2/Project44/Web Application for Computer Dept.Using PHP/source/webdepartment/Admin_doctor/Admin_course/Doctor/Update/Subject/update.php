<html>
<head>
<title>��䢢���������Ԫ���ѡ�ٵû�ԭ���͡</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<?
include ("connect_course.inc.php");
$ca = strlen($category);
$gs = strlen($gsubject);
if(($ca != 0))
{
$co = strlen($code);
$cst = strlen($code_subject_to);
$na = strlen($name);
$un = strlen($unit);
$un_de = strlen($unit_detail);
$un_op = strlen($unit_operation);
if(($co != 0)&&($na != 0)&&($un != 0)&&($un_de != 0)&&($un_op != 0))
{
	$code = htmlspecialchars($code);
	$name = htmlspecialchars($name);
	$unit = htmlspecialchars($unit);
	$unit_detail = htmlspecialchars($unit_detail);
	$unit_operation = htmlspecialchars($unit_operation);
	$url = htmlspecialchars($url);
	$subject_detail = htmlspecialchars($subject_detail);
	$subject_detail = eregi_replace(chr(13),"<br>",$subject_detail);
	
	//check msubject not subport category
	$query_msubject = MYSQL_DB_QUERY($dbName,"Select * From $Categorytable Where Msubject = '$msubject' AND Category ='$category' AND Course_year ='$course_year' "); 
	$number_msubject = MYSQL_NUMROWS($query_msubject); 
	if (( $number_msubject > 0 ) ||(($msubject == '�����')AND($category == '�����')AND($gsubject == '�����')))
	{
    // check subject_to repeating
	$query = MYSQL_DB_QUERY($dbName,"Select * From $Subjecttable Where Code='$code_subject_to' AND Course_year ='$course_year' "); 
	$number = MYSQL_NUMROWS($query); 
	if ( ($number >0) || ($cst==0) ) 
	{ 
			if ($cst ==0)
		{
			$name_subject_to = '';
			$ename_subject_to = '';
		}
			    // check code subject repeating
		$query_subject = "Select * From $Subjecttable Where Course_year  =  '$course_year' AND Code  =  '$code' AND Code != '$code_old' AND Category = '$category'";
	$result_subject = mysql_query($query_subject);
	$number_subject = mysql_numrows($result_subject);
	$i_subject = 0;
		if ($i_subject < $number_subject)
		{
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>�բ���������ԪҢͧ�����Ԫҷ���к������͹����</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}
		else
		{

$query_delete_subject = "Delete  From $Subjecttable Where Code ='$code_old' AND Course_year = '$course_year'  AND Category  =  '$category_old' ";
$result_delete = mysql_db_query($dbName,$query_delete_subject);

$sql_subject = "INSERT INTO $Subjecttable(Course_year,Msubject,Category,Gsubject,Code,Name,Ename,Unit,Unit_detail,Unit_operation,Url,Code_subject_to,Name_subject_to,Ename_subject_to,Subject_detail) VALUES ('$course_year','$msubject','$category','$gsubject','$code','$name','$ename','$unit','$unit_detail','$unit_operation','$url','$code_subject_to','$name_subject_to','$ename_subject_to','$subject_detail')";
$result_2 = mysql_db_query($dbName,$sql_subject);

$query ="Update $Subjecttable Set  Code_subject_to ='$code',Name_subject_to ='$name',Ename_subject_to ='$ename'  Where Code_subject_to='$code_old' AND Course_year = '$course_year' ";
$result= mysql_db_query($dbName,$query);


$query ="Update $Coursetable Set  Code ='$code' Where Code='$code_old'";
$result= mysql_db_query($dbName,$query);

	echo "<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font face='Tahoma'>����������Ԫ���١�ѹ�֡ŧ�ҹ���������º��������<BR><A HREF = 'update_subject.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
	MYSQL_CLOSE();
			}
	}
	else
	{
		echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>����բ���������ԪҢͧ�����Ԫҷ���к����ԪҺѧ�Ѻ��͹</font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			 </tr></table>";
		}//end else of check subject_to repeating
	}
else
	{
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>
				��Ǵ�Ԫ����͡�����������Ԫ���ѡ����к�</font></font></font></div>
			</td>
			</tr> 
			</table>";
			 MYSQL_CLOSE();
	}
	
}
else
{
			 echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'>��͡�������������ó��سҡ�͡�ա����</font></font></font></div>
			</td>
			</tr> 
			</table>";
			 MYSQL_CLOSE();
	}
}
else
{
			echo"<table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
			<tr>
			<td height='32' colspan='4' bgcolor='#F7F7F7'> 
			<div align='center'><font size='2'><font size='2'><font face='Tahoma'>��س����͡��Ǵ�Ԫ���С�����Ԫҷ���ͧ�����䢢���������Ԫ����¹��͹<br><A HREF = 'update_subject.php?course_year=$course_year' target =_parent>Click Here!</A></font></font></font></div>
			</td>
			</tr> 
			</table>
			</td>
			</tr></table>";
		$query_delete_temp = "Delete From $Temptable ";
		$result_delete_temp = mysql_db_query($dbName,$query_delete_temp);
			MYSQL_CLOSE();
}

?>
<table width="600" border="0" cellspacing="0" cellpadding="0" align ='center'>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webDoctor@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>

</body>
</html>
