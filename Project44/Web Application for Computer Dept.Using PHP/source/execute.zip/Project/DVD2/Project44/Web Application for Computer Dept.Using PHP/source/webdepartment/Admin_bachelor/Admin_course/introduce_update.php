<html>
<head>
<title>��䢢�������ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" height="94">
  <tr> 
    <td height="8" width="96">&nbsp;</td>
    <td height="8" width="321">&nbsp;</td>
    <td height="8" width="36">&nbsp;</td>
    <td width="108" height="8">&nbsp;</td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8">&nbsp;</td>
    <td width="107" height="8">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96" height="8"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321" height="8"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36" height="8">&nbsp;</td>
    <td width="108" height="8"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2" height="8">&nbsp;</td>
    <td width="106" height="8"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107" height="8"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
    
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="6" width="111"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="6" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="6" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2" height="23"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
   <?
	 include ("connect_course.inc.php");
     echo "
	 <tr>
    <td width='11'>&nbsp;</td>
    <td width='9' bgcolor='#D2F8FD'>&nbsp;</td>
    <td width='140' bgcolor='#D2F8FD' valign='top'><font face='Tahoma' size='2' color='#9900CC'><br>
      �����ѡ�ٵû�ԭ�ҵ��</font> <font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='structure_update_course.php?course_year=$course_year'>����ç���ҧ��ѡ�ٵ�</a><br>
	  <a href='structure_update_category.php?course_year=$course_year'>�����Ǵ�Ԫ�</a><br>
	  <a href='structure_update_group.php?course_year=$course_year'>��䢡�����Ԫ�</a><br>
	  <a href='Bachelor/Update/Subject/update_subject.php?course_year=$course_year'>�������Ԫ�</a><br>
	  <a href='Bachelor/Update/Course/update_course.php?course_year=$course_year'> �ǡ�èѴ�Ԫ����¹</a><br>
	  <a href='index.php'>��Ѻ˹����ѡ </a></font></font><br>&nbsp;
	</td>
    <td width='619' valign='top'>";
	
	$query = "Select * From $Introducetable Where Course_year = '$course_year' order by Ctname ASC LIMIT 0, 50 ";
	$result = mysql_query($query);
	$number = mysql_numrows($result);
	$i=0;
	if ($i < $number) {
	while ($row = mysql_fetch_array($result))
		{
	$course_year = htmlspecialchars($row[Course_year]);
	$ctname = htmlspecialchars($row[Ctname]);
	$cename = htmlspecialchars($row[Cename]);
	$ftname = htmlspecialchars($row[Ftname]);
	$stname = htmlspecialchars($row[Stname]);
	$fename = htmlspecialchars($row[Fename]);
	$sename = htmlspecialchars($row[Sename]);
	$accept = $row[Accept];
	$philosophy_article = $row[Philosophy_Article];
	$program = $row[Program];
	$property = $row[Property];
	$test = $row[Test];
	$csystem = $row[Csystem];
	$ctime = $row[Ctime];
	$register = $row[Register];
	$process = $row[Process];
	$year1 = $row[Year1];
	$year2 = $row[Year2];
	$year3 = $row[Year3];
	$year4 = $row[Year4];
	$d1_year1 = $row[D1_year1];
	$d1_year2 = $row[D1_year2];
	$d1_year3 = $row[D1_year3];
	$d1_year4 = $row[D1_year4];
	$d2_year1 = $row[D2_year1];
	$d2_year2 = $row[D2_year2];
	$d2_year3 = $row[D2_year3];
	$d2_year4 = $row[D2_year4];
	$d3_year1 = $row[D3_year1];
	$d3_year2 = $row[D3_year2];
	$d3_year3 = $row[D3_year3];
	$d3_year4 = $row[D3_year4];
	$d4_year1 = $row[D4_year1];
	$d4_year2 = $row[D4_year2];
	$d4_year3 = $row[D4_year3];
	$d4_year4 = $row[D4_year4];
	$p1_year1 = $row[P1_year1];
	$p1_year2 = $row[P1_year2];
	$p1_year3 = $row[P1_year3];
	$p1_year4 = $row[P1_year4];
	$p2_year1 = $row[P2_year1];
	$p2_year2 = $row[P2_year2];
	$p2_year3 = $row[P2_year3];
	$p2_year4 = $row[P2_year4];
	$p3_year1 = $row[P3_year1];
	$p3_year2 = $row[P3_year2];
	$p3_year3 = $row[P3_year3];
	$p3_year4 = $row[P3_year4];
	$sum1 = $row[Sum1];
	$sum2 = $row[Sum2];
	$sum3 = $row[Sum3];
	$sum4 = $row[Sum4];
	$end1 = $row[End1];
	$end2 = $row[End2];
	$end3 = $row[End3];
	$end4 = $row[End4];
	$place_tool = $row[Place_Tool];

	$accept = eregi_replace('<br>',chr(13),$row[Accept]);
	$philosophy_article = eregi_replace('<br>',chr(13),$row[Philosophy_Article]);
	$program = eregi_replace('<br>',chr(13),$row[Program]);
	$property = eregi_replace('<br>',chr(13),$row[Property]);
	$test = eregi_replace('<br>',chr(13),$row[Test]);
	$csystem = eregi_replace('<br>',chr(13),$row[Csystem]);
	$ctime = eregi_replace('<br>',chr(13),$row[Ctime]);
	$register = eregi_replace('<br>',chr(13),$row[Register]);
	$process = eregi_replace('<br>',chr(13),$row[Process]);
	$place_tool= eregi_replace('<br>',chr(13),$row[Place_Tool]);

	
	  echo "<form name='form' method='post' action='update_introduce.php'>
      <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr valign='middle'> 
            <td colspan='2' height='103' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2' color='#515151'>��ѡ�ٵ����ǡ�����ʵúѳ�Ե 
              �Ң��Ԫ����ǡ�������������</font> <font face='Tahoma' size='2' color='#515151'><br>
			   ��ѡ�ٵ�$course_year<br>
              ������ǡ�����ʵ�� </font> <font face='Tahoma' size='2' color='#515151' ><br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font> </div>
          </td>
        </tr>
          <tr bgcolor='#F7F7F7'> 
            <td colspan='2' height='26'><b><font size='2' color='#000000' face='Tahoma'>1. 
              ������ѡ�ٵ� </font></b></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>����������</font></td>
          <td width='496' bgcolor='#D2F8FD' height='34'> 
              <input type='text' name='ctname' size='50' value='$ctname'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>���������ѧ���</font></td>
          <td width='496' bgcolor='#D2F8FD' height='34'> 
              <input type='text' name='cename' size='50' value='$cename'>
          </td>
        </tr>
        <tr> 
            <td colspan='2' height='26' bgcolor='#F7F7F7'><font size='2' color='#000000' face='Tahoma'><b>2. 
              ���ͻ�ԭ��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='496' bgcolor='#D2F8FD' height='34'> 
              <input type='text' name='ftname' size='50' value='$ftname'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
            (��)</font></td>
          <td width='496' bgcolor='#D2F8FD' height='34'> 
              <input type='text' name='stname' size='50' value='$stname'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font size='2' color='#000000' face='Tahoma'>������� 
            (�ѧ���)</font></td>
          <td width='496' bgcolor='#D2F8FD' height='34'> 
              <input type='text' name='fename' size='50' value='$fename'>
          </td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font face='Tahoma' size='2' color='#000000'>������� 
            (�ѧ���)</font></td>
          <td width='496' bgcolor='#D2F8FD' bordercolor='#FFFFFF' height='34'> 
              <input type='text' name='sename' size='50' value='$sename'>
          </td>
        </tr>
        <tr> 
          <td colspan='2' height='26' bgcolor='#F7F7F7'><font face='Tahoma' size='2' color='#000000'><b>3. 
            ˹��§ҹ�Ѻ�Դ�ͺ</b></font></td>
        </tr>
        <tr> 
          <td width='98' height='52' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='496' height='52' bgcolor='#D2F8FD'> 
              <textarea name='accept' cols='80' rows='7'>$accept</textarea>
          </td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2' color='#000000'><b>4. 
              ��Ѫ������ѵ�ػ��ʧ��ͧ��ѡ�ٵ�</b></font></td>
        </tr>
		<tr> 
          <td width='91' bgcolor='#F7F7F7' height='25'><font face='Tahoma' size='2'></font></td>
          <td width='503' bgcolor='#D2F8FD' height='25'><font face='Tahoma' size='2'><textarea name='philosophy_article' cols='80' rows='7'>$philosophy_article</textarea></font></td>
        </tr>        
		<tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>5. 
              ��˹�����Դ�͹</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='34'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='34'><font face='Tahoma' size='2'> 
              <input type='text' name='program' size='50' value='$program'>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'>�<b>6. 
              �س���ѵԢͧ�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='property' cols='80' rows='7'>$property</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>7. 
              ��äѴ���͡�������֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='test' cols='80' rows='7'>$test</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>8. 
              �к�����֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='csystem' cols='80' rows='7'>$csystem</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>9. 
              �������ҡ���֡��</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='ctime' cols='80' rows='7'>$ctime</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>10. 
              ���ŧ����¹���¹</b></font></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='register' cols='80' rows='7'>$register</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><b><font face='Tahoma' size='2'>11. 
              ����Ѵ����С������稡���֡��</font></b></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='process' cols='80' rows='7'>$process</textarea>
            </font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><b><font face='Tahoma' size='2'>12. 
              �ӹǹ�ѡ�֡��</font></b></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD'> 
              <table width='100%' border='1' cellspacing='0' cellpadding='0' bordercolor='#FFFFFF' align='center'>
                <tr> 
                <td rowspan='2' width='125'> 
                  <div align='center'><font face='Tahoma' size='2'>�ӹǹ�ѡ�֡��</font></div>
                </td>
                  <td colspan='4' height='35' > 
                    <div align='center'><font face='Tahoma'><font size='2'>�ա���֡��</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'><input type='text' name='year1' size='4' value='$year1' maxlength='4'></font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='year2' size='4' value='$year2' maxlength='4'></font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='year3' size='4' value='$year3' maxlength='4'></font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='year4' size='4' value='$year4' maxlength='4'>
						</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    1</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d1_year1' size='4' value='$d1_year1' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d1_year2' size='4' value='$d1_year2' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d1_year3' size='4' value='$d1_year3' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d1_year4' size='4' value='$d1_year4' maxlength='3'>
					</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    2</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d2_year1' size='4' value='$d2_year1' maxlength='3'>
                      </font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d2_year2' size='4' value='$d2_year2' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d2_year3' size='4' value='$d2_year3' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d2_year4' size='4' value='$d2_year4' maxlength='3'>
					</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    3</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d3_year1' size='4' value='$d3_year1' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d3_year2' size='4' value='$d3_year2' maxlength='3'>
			</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d3_year3' size='4' value='$d3_year3' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d3_year4' size='4' value='$d3_year4' maxlength='3'>
				</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    4</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d4_year1' size='4' value='$d4_year1' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d4_year2' size='4' value='$d4_year2' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d4_year3' size='4' value='$d4_year3' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='d4_year4' size='4' value='$d4_year4' maxlength='3'>
				</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    1P</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p1_year1' size='4' value='$p1_year1' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p1_year2' size='4' value='$p1_year2' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p1_year3' size='4' value='$p1_year3' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p1_year4' size='4' value='$p1_year4' maxlength='3'>
				</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    2P</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p2_year1' size='4' value='$p2_year1' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p2_year2' size='4' value='$p2_year2' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p2_year3' size='4' value='$p2_year3' maxlength='3'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p2_year4' size='4' value='$p2_year4' maxlength='3'>
			</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>��鹻շ�� 
                    3P</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p3_year1' size='4' value='$p3_year1' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p3_year2' size='4' value='$p3_year2' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p3_year3' size='4' value='$p3_year3' maxlength='3'>
				</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='p3_year4' size='4' value='$p3_year4' maxlength='3'>
					</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>���</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='sum1' size='4' value='$sum1' maxlength='4'>
				</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='sum2' size='4' value='$sum2' maxlength='4'>
					</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='sum3' size='4' value='$sum3' maxlength='4'>
				</font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='sum4' size='4' value='$sum4' maxlength='4'>
				</font></font></div>
                </td>
              </tr>
              <tr> 
                  <td width='125' height='36'> 
                    <div align='center'><font face='Tahoma' size='2'>�������稡���֡��</font></div>
                </td>
                  <td width='91' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='end1' size='4' value='$end1' maxlength='4'>
					</font></font></div>
                </td>
                  <td width='88' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='end2' size='4' value='$end2' maxlength='4'>
                   </font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='end3' size='4' value='$end3' maxlength='4'>
                    </font></font></div>
                </td>
                  <td width='90' height='36'> 
                    <div align='center'><font face='Tahoma'><font size='2'>
                      <input type='text' name='end4' size='4' value='$end4' maxlength='4'>
                    </font></font></div>
                </td>
              </tr>
            </table>
            <font face='Tahoma' size='2'></font></td>
        </tr>
        <tr> 
            <td colspan='2' bgcolor='#F7F7F7' height='26'><font face='Tahoma' size='2'><b>13. 
              ʶҹ������</b></font><b><font face='Tahoma' size='2'>�ػ�ó����͹</font></b></td>
        </tr>
        <tr> 
          <td width='98' bgcolor='#F7F7F7' height='52'><font face='Tahoma' size='2'></font></td>
          <td width='496' bgcolor='#D2F8FD' height='52'><font face='Tahoma' size='2'> 
              <textarea name='place_tool' cols='80' rows='7'>$place_tool</textarea>
            </font></td>
        </tr>
         <tr> 
          <td colspan='2' bgcolor='#F7F7F7'>
              <div align='center'>
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
              </div>
            </td>
        </tr>
      </table>
		<input type=hidden name=course_year value='$course_year'>
	  </form>";
		  	}
	}
	MYSQL_CLOSE();
	  ?>
    </td>
  </tr>
</table>

<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut's Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font size="1"><font size="1"><font face="Tahoma"></font></font></font></div>
    </td>
  </tr>
</table>

</body>
</html>
