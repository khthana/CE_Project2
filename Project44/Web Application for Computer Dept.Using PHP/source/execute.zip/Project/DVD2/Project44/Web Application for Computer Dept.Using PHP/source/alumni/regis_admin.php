<?
session_start();
include("alumni.inc");
include("md5.js");
if ($mem[n]=="root"){
	if($mem[n]&&$mem[p]){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$mem[n]'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	$pwd1=$row["ad_passwd"];
	$pwd1=MD5($pwd1).$mem[c];
	$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
	if($mem[n]==$row["ad_user"] && $mem[p]==$pwd1) { 
	print "<FORM name=register action='to_register.php' method=post onSubmit='return check()'  autocomplete='off'>";
?>
<Table border=0 cellspacing=1 cellpadding=4 Bgcolor=#FFFFFF align=center width=398>
  <Tr> 
      
    <Td bgcolor=#dedfdf width="158" ><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Name<font color="#FF0000"> 
      *</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_name Size=30>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158" ><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Surname<font color="#FF0000"> 
      *</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_surname Size=30>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Login_name 
      <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Text Name=ad_user Size=15>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Login_password 
      <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Password Name=ad_passwd Size=15>
      </Td>
    </Tr>
    <Tr> 
      
    <Td bgcolor=#dedfdf width="158"><font class="11px" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="2">Password 
      Again <font color="#FF0000">*</font></font></Td>
      <Td bgcolor=#f7f7f7 width="237"> 
        <Input Type=Password Name=ad_passwd2 Size=15>
      </Td>
    </Tr>
  </Table>
<br>
<div align="center">
<input type=submit value=Submit name=topicsubmit>
<input type=reset value=reset name=topicreset>
</div>
<?php
	print "</form>";
	}
	}
	else{
		print "no";
	}
}
else{
	?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000066" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">����Ѻ</font><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
        Root <font color="#000066">��ҹ�鹷��зӡ��</font> Register<font color="#000066"> 
        ��</font></font></div>
    </td>
  </tr>
</table>

		<?php
}
?>
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.register .ad_name.value;
      var v2 = document.register .ad_surname.value;
      var v3 = document.register .ad_user.value;
      var v4 = document.register .ad_passwd.value;
      var v5 = document.register .ad_passwd2.value;
	  
        if ( v1.length==0)
           {
           alert("��سһ�͹ ����");
           document.register .ad_name.focus();           
           return false;
           }
        else if (v2.length==0)
           {
           alert("��سһ�͹ ���ʡ��");
           document.register .ad_surname.focus();           
		   return false;
           }
        else if (v3.length==0)
           {
           alert("��سһ�͹ Login Name");
           document.register .ad_user.focus();           
		   return false;
           }
        else if (v4.length==0)
           {
           alert("��سһ�͹ Password");
           document.register .ad_passwd.focus();           
		   return false;
           }
        else if (v5.length==0)
           {
           alert("��سһ�͹ Password �ա����");
           document.register .ad_passwd2.focus();           
		   return false;
           }
        else if (v5!=v4)
           {
           alert("��سһ�͹ Password ���ç�ѹ");
           document.register .ad_passwd2.focus();           
		   return false;
           }
}
//-->
</script> 
</body>
</html>