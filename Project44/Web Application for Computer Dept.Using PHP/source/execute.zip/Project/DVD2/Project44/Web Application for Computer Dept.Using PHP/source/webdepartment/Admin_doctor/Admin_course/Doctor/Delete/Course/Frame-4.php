<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<form name="a" action="Frame-2.php" target ="mainFrame" method="post">
<script language="javascript" >
function Brand(tSystem,tBrand,nn)
{
     this.System=tSystem;
     this.Brand=tBrand;
	 this.apid=nn;
}
function Model(tId,tModel,tSystem,tBrand){
     this.ID=tId;
     this.Model=tModel;
     this.System=tSystem;
     this.Brand=tBrand;
}
function getBrands()
{
  var sSelect="<select name='year' class='input200'><option value='' selected></option>";
  var obj0=document.a.type;
  var iSystem=obj0.options[obj0.selectedIndex].value;
   for (var x=1;x<aBrands.length;x++)
    {
           if (aBrands[x].System==iSystem)
           {
                 sSelect=sSelect+"<option value='"+aBrands[x].apid+"'>"+aBrands[x].Brand+"</option>";
           }
     }
    sSelect=sSelect+"</select>";
    document.all.Brands.innerHTML=sSelect;
	
}
var aBrands=new Array();
aBrands[1] = new  Brand('����Ѻ��騺��ԭ�ҵ��','1','1');aBrands[2] = new  Brand('����Ѻ��騺��ԭ�ҵ��','2','2');aBrands[3] = new  Brand('����Ѻ��騺��ԭ�ҵ��','3','3');aBrands[4] = new  Brand('����Ѻ��騺��ԭ�ҵ��','4','4');aBrands[5] = new  Brand('����Ѻ��騺��ԭ�ҵ��','5','5');aBrands[6] = new  Brand('����Ѻ��騺��ԭ���','1','1');aBrands[7] = new  
Brand('����Ѻ��騺��ԭ���','2','2');aBrands[8] = new  
Brand('����Ѻ��騺��ԭ���','3','3');
function fsubmit(){
if ((a.type.value!="")&&(a.year.value!="")&&(a.name.value!="")&&(a.add.value!="")&&(a.reg.value!="")&&(a.email.value!="")){
a.submit()
}else{
alert("��سҡ�͡���������ú")
}
}
</script>
<body bgcolor="#FFFFFF">
<table width="612" border="0" cellspacing="0" cellpadding="0" align="left">
  <tr>
      <td width="11">&nbsp;</td>
      <td width="600"> 
        <table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr> 
            <td> 
              <table width="550" border="1" cellspacing="0" cellpadding="0" align="center" height="14" bordercolor="#FFFFFF">
                <tr> 
                  <td width="254" height="32"> 
                       <div align="center"><font size="2" face="Tahoma">��ѡ�ٵû�ԭ���͡ 
					<span id="c_country" name="c_country"> 
                    <select name="type" onChange="getBrands();" class="input200" >
                <option selected value=""></option>
                <option  value="����Ѻ��騺��ԭ�ҵ��" ><span id="c_country" name="c_country">����Ѻ��騺��ԭ�ҵ��</span></option>
                <option  value="����Ѻ��騺��ԭ���" ><span id="c_country" name="c_country">����Ѻ��騺��ԭ���</span></option>
              </select>
              </span>
                    </font> </div>
                  </td>
                  <td width="107" height="32"> 
        <div align="center"><font face="Tahoma" size="2">��鹻շ��
					<span id="Brands" name="Brands"> </font> 
                    <font face="Tahoma" size="2"> 
              <select name="year" class="input200">
                <option value="" selected>&nbsp;&nbsp;</option>
              </select>
              </span></font></div>
                  </td>
                  <td width="138" height="32"> 
                    <div align="center"><font size="2" face="Tahoma">�Ҥ���¹��� 
                      <select name="term">
                        <option value="1">1</option>
                        <option value="2">2</option>
                      </select>
                      </font></div>
                  </td>
                  <td width="34" height="32"> 
                    <input type="submit" name="Submit" value="   ���͡   ">
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
    </td>
  </tr>
</table>
<?
	echo "<input type='hidden' name='course_year' value='$course_year'>";
?>
</form>
</body>
</html>
