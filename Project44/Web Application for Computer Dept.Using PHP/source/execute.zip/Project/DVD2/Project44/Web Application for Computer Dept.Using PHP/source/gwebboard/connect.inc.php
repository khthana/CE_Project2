<?
    function gwebboard()
    {
		$dbname="gwebboard";
        $handle=mysql_connect("localhost","root","webmaster123");
		mysql_select_db($dbname,$handle); 
	    return($dbname);  
	}


   function closedb()
   {
	    $handle=mysql_connect("localhost","root","webmaster123");
		mysql_close($handle);   
   }

?>