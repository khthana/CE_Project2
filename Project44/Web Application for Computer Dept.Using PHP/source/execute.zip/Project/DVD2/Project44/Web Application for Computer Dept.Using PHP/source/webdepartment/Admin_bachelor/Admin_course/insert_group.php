<html>
<head>
<title>����������Ԫ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color: #9900CC; text-decoration: underline}
a:hover { color: #33CCFF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="13" width="96">&nbsp;</td>
    <td height="13" width="321">&nbsp;</td>
    <td height="13" width="36">&nbsp;</td>
    <td width="108" height="13">&nbsp;</td>
    <td width="2" height="13">&nbsp;</td>
    <td width="106" height="13">&nbsp;</td>
    <td width="107" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif" width="109" height="97"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3E3EA8"> 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="95" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">˹���á</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����Ԫ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��ѡ�ٵ�</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma" size="2"><font color="#FFFFFF">�ؤ�ҡ�</font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">�ҹ�Ԩ��</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">��дҹ����</font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><font size="1"><font size="1"><font color="#FFFFFF"><font face="MS Sans Serif"><font face="MS Sans Serif"><font size="3"><font size="3"><font color="#FFFFFF"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><font size="3"><font face="BrowalliaUPC"><font face="BrowalliaUPC"><font size="3"><img src="images/l.gif" width="1" height="20"></font></font></font><font color="#FFFFFF"></font></font></font></font></font></font></font></font></font></font></font></font></font></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="95">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width="775" border="0" cellspacing="0" cellpadding="0" >
<?
include ("connect_course.inc.php");
echo"
    <tr> 
    <td width='11' >&nbsp;</td>
    <td width='14' bgcolor='#D2F8FD' >&nbsp;</td>
    <td width='134' bgcolor='#D2F8FD' valign='top' ><font face='Tahoma' size='2' color='#9900CC'><br>
      <a href='introduce_insert.php'>��ѡ�ٵû�ԭ�ҵ��</a></font> 
      <font face='Tahoma' size='2' color='#9900CC'><br>
	  <a href='structure_insert_course.php?course_year=$course_year'>�ç���ҧ��ѡ�ٵ�</a><br>
	 <a href='insert_category.php?course_year=$course_year'>������Ǵ�Ԫ�����</a><br>
      ����������Ԫ����� <br>
	  <a href='Bachelor/Insert/Subject/select_course.php?course_year=$course_year' >��������Ԫ����� </a><br>
	  	<a href='Bachelor/Insert/Course/select_course.php?course_year=$course_year'>�ǡ�èѴ�Ԫ����¹</a><br>
      <a href='index.php'>��Ѻ˹����ѡ </a>
    <br>&nbsp;
    </font></td>
     <form name='form' method='post' action='structure_insert.php'>
    <td width='619' valign='top' > ";
echo "
        <table width='600' border='1' cellspacing='0' cellpadding='0' align='center' bordercolor='#FFFFFF'>
          <tr> 
            <td height='21' colspan='10' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'><font size='2'><font size='2'></font></font></font> 
                <font face='Tahoma' size='2' color='#515151'><br>
                ��ѡ�ٵ����ǡ�����ʵúѳ�Ե �Ң��Ԫ����ǡ������������� <br>
                ��ѡ�ٵ�$course_year
                <br>
                ������ǡ�����ʵ�� <br>
                ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ </font><font size='2' face='Tahoma'><br>&nbsp;
                </font></div>
            </td>
          </tr>
          <tr> 
            <td height='31' colspan='10' bgcolor='#F7F7F7'><font size='2' face='Tahoma'><b>14.2 
              �ç���ҧ��ѡ�ٵ�</b></font></td>
          </tr>
          <tr> 
            <td height='38' width='22' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='38' bgcolor='#F7F7F7' width='130'> 
              <div align='center'><font face='Tahoma' size='2'>������Ǵ�Ԫ�</font></div>
            </td>
            <td height='38' bgcolor='#D2F8FD' colspan='4'> 
              <div align='center'><font face='Tahoma' size='2'>���������֡�ҷ�� 
                1</font></div>
            </td>
            <td height='38' bgcolor='#D2F8FD' colspan='4'> 
              <div align='center'><font face='Tahoma' size='2'>���������֡�ҷ�� 
                2</font></div>
            </td>
          </tr>
          <tr> 
            <td height='29' width='22' bgcolor='#F7F7F7'> 
              <div align='center'><font size='2'><font size='2'><font face='Tahoma'></font></font></font></div>
            </td>
            <td height='29' bgcolor='#F7F7F7' width='130'> 
              <div align='center'><font size='2' face='Tahoma'><select name='category' size='1'>";
		//$query_category = "Select * From $Categorytable Where Course_year = '$course_year'";
		$query_category = "Select Category From $Categorytable Where Course_year = '$course_year' ";
		$result_category = mysql_query($query_category); 
        $number_category = mysql_numrows($result_category);
		$i_category=0; 
		if ($i_category < $number_category)
		{
			while ($row  = mysql_fetch_array($result_category)) 
			{
			$category = htmlspecialchars($row[Category]); 
			echo "<option value='$category'><font size='2' face='Tahoma'>$category</font></option>";
			}  
        }
		echo" </select>
			</font></div>
            </td>
            <td height='29' bgcolor='#D2F8FD' colspan='4'> 
              <div align='center'><font face='Tahoma' size='2'>&nbsp;</font></div>
            </td>
            <td height='29' bgcolor='#D2F8FD' colspan='4'> 
              <div align='center'><font face='Tahoma' size='2'>&nbsp;</font></div>
            </td>
          </tr>
          <tr> 
            <td height='31' width='22' bgcolor='#F7F7F7'><font size='2' face='Tahoma'></font></td>
            <td height='31' bgcolor='#F7F7F7' width='130'> 
              <div align='center'><font size='2' face='Tahoma'> ���͡�����Ԫ� 
                </font></div>
            </td>
            <td height='31' colspan='4' bgcolor='#D2F8FD'> 
              <div align='center'></div>
              
            </td>
            <td height='31' colspan='4' bgcolor='#D2F8FD'> 
              <div align='center'></div>
              
            </td>
          </tr>
          <tr> 
            <td height='28' bgcolor='#F7F7F7' width='22'>&nbsp;</td>
            <td height='28' bgcolor='#F7F7F7' width='130'> 
              <div align='center'><font size='2' face='Tahoma'> </font></div>
              <div align='center'><fon4t size='2' face='Tahoma'> 
                <input type='text' name='gsubject' size='20'>
              </div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='56'> 
              <div align='center'></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='31'> 
              <div align='center'><font size='2' face='Tahoma'> 
                <input type='text' name='gprogram1_unit' size='3' maxlength='3'>
                </font></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='74'> 
              <div align='center'><font face='Tahoma' size='2'>˹��¡Ե</font></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='60'> 
              <div align='center'></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='48'> 
              <div align='center'></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='31'> 
              <div align='center'><font size='2' face='Tahoma'> 
                <input type='text' name='gprogram2_unit' size='3' maxlength='3'>
                </font></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='71'> 
              <div align='center'><font face='Tahoma' size='2'>˹��¡Ե</font></div>
            </td>
            <td height='28' bgcolor='#D2F8FD' width='59'> 
              <div align='center'></div>
            </td>
          </tr>
          <tr> 
            <td height='51' width='22' bgcolor='#F7F7F7'>&nbsp;</td>
            <td height='51' width='130' bgcolor='#F7F7F7'> 
              <div align='center'><font face='Tahoma' size='2'>��͸Ժ��</font></div>
            </td>
            <td height='51' bgcolor='#D2F8FD' colspan='8'> 
              <div align='center'> 
                <textarea name='gdetail' cols='70' rows='2'></textarea>
              </div>
            </td>
          </tr>
          <tr> 
            <td height='42' colspan='10' bgcolor='#F7F7F7'> 
              <div align='center'> 
                <input type='submit' name='Submit' value='Submit'>
                <input type='reset' name='Submit2' value='Reset'>
              </div>
            </td>
          </tr>
        </table>
    </td>
	<input type='hidden' name='course_year' value='$course_year'>
	      </form>
  </tr>
</table>	";
?>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma" size="1">Department of Computer 
        Engineering Faculty of Engineering King Mongkut"s Institute of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� webmaster@ce.kmitl.ac.th</font> </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"></div>
    </td>
  </tr>
</table>
</body>
</html>
