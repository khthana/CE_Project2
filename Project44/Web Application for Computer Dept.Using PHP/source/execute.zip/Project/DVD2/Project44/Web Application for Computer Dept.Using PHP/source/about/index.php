<html>
<head>
<title>�ʴ������źؤ�ҡ�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="script/MenuStyle.css" rel=stylesheet  type=text/css>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #9900CC; text-decoration: none}
a:visited { color: #9900CC; text-decoration: none}
a:active { color:#000000; text-decoration: underline}
a:hover { color: #FF3300; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="96"><img src="images/logo-kmitl0.gif"></td>
    <td width="321"> 
      <div align="center"><img src="images/CE.gif" width="265" height="70"></div>
    </td>
    <td width="36">&nbsp;</td>
    <td width="108"><img src="images/r4.gif" width="108" height="80"></td>
    <td width="2">&nbsp;</td>
    <td width="106"><img src="images/kingrama4-005.jpg" width="100" height="80"></td>
    <td width="107"><img src="images/kingrama4-012.jpg" width="100" height="80"></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" height="13" align="center">
  <tr> 
    <td height="5" width="111">&nbsp;</td>
    <td height="5" width="27"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"></font></td>
    <td height="5" width="200"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif">�Ҥ�Ԫ����ǡ�������������</font></td>
    <td height="5" width="440"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif">ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</font></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr bgcolor="#3E3EA8" class = "WNFont" > 
    <td width="10" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="http://www.ce.kmitl.ac.th">˹���á</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../webdepartment/course/homepage/subject/index.php">����Ԫ�</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><A HREF="../webdepartment/course/index.php">��ѡ�ٵ�</A></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif" size="2"><font color="#FFFFFF"><a href="../webdepartment/course/homepage/person/index.php">�ؤ�ҡ�</a></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../project/index.php">�ҹ�Ԩ��</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="../webboard/index.php">��дҹ����</a></font></font></font></font></div>
    </td>
    <td width="1" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><img src="images/l.gif" width="1" height="20"></font></font></font></div>
    </td>
    <td width="94" bgcolor="#3E3EA8"> 
      <div align="center"><font size="2" face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif"><font color="#FFFFFF"><font color="#FFFFFF"><font color="#FFFFFF"><a href="index.php">����ǡѺ���</a></font></font></font></font></div>
    </td>
    <td width="2"> 
      <div align="center"><img src="images/l.gif" width="1" height="20"></div>
    </td>
  </tr>
  <tr> 
    <td width="10">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="94">&nbsp;</td>
    <td width="2">&nbsp;</td>
  </tr>
</table>
<table width='772' border='0' cellspacing='1' cellpadding='2' align="center" bordercolor="#FFFFFF" >
  <tr> 
    <td width='13' rowspan="7" >&nbsp;</td>
    <td bgcolor='#E9F7FE' height="30" colspan="5" > 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="3"><b>���Ѵ��</b></font></div>
    </td>
    <td rowspan="7" valign='top' width='16' ><font size='2' face='Tahoma, Microsoft Sans Serif, Microsoft Sans Serif'><br>
      </font><font face='Tahoma, Microsoft Sans Serif, Microsoft Sans Serif' size='2' color='#9900CC'><br>
      </font>&nbsp; </td>
  </tr>
  <tr> 
    <td width='119' bgcolor='#E9F7FE' height="30" > 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><b>�����ç�ҹ</b></font></div>
    </td>
    <td bgcolor='#E9F7FE' height="30" colspan="4" > <font face="Tahoma, Microsoft Sans Serif" size="2"> 
      ������ҧ����;���प������Ѻ�Ҥ�Ԫ������ PHP( Web Application for Computer 
      Dept. Using PHP)</font></td>
  </tr>
  <tr> 
    <td width='119' bgcolor='#E9F7FE' height="30" > 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif" size="2"><b>�Ҩ�������֡��</b></font></div>
    </td>
    <td bgcolor='#E9F7FE' height="30" colspan="4" ><font face="Tahoma, Microsoft Sans Serif" size="2">�Ҩ���츹� 
      ˧������ó <a href="mailto:thana@ce.kmitl.ac.th">thana@ce.kmitl.ac.th</a></font></td>
  </tr>
  <tr> 
    <td width='119' bgcolor='#E9F7FE' height="30" ><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
    <td bgcolor='#E9F7FE' height="30" width='178' ><font face="Tahoma, Microsoft Sans Serif" size="2">1.��¨���പ 
      �����زԤس</font></td>
    <td bgcolor='#E9F7FE' height="30" width='150' ><font face="Tahoma, Microsoft Sans Serif" size="2">���ʹѡ�֡�� 
      42015296</font></td>
    <td bgcolor='#E9F7FE' height="30" width='136' > <font face="Tahoma, Microsoft Sans Serif" size="2"><a href="mailto:s2015296@hotmail.com"><img src="images/email.gif" width="14" height="10" border="0"></a>&nbsp;<a href="mailto:jiradage@hotmail.com">jiradage@hotmail.com</a></font></td>
    <td bgcolor='#E9F7FE' height="30" width='136' > <font face="Tahoma, Microsoft Sans Serif" size="2"><img src="images/icq.gif" width="12" height="11"> 
      ICQ 107342665</font></td>
  </tr>
  <tr> 
    <td width='119' bgcolor='#E9F7FE' height="30" ><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
    <td bgcolor='#E9F7FE' height="30" width='178' ><font face="Tahoma, Microsoft Sans Serif" size="2">2.����Ѱ�� 
      ǧ������</font></td>
    <td bgcolor='#E9F7FE' height="30" width='150' ><font face="Tahoma, Microsoft Sans Serif" size="2">���ʹѡ�֡�� 
      42015312 </font></td>
    <td bgcolor='#E9F7FE' height="30" width='136' ><font face="Tahoma, Microsoft Sans Serif" size="2"><a href="mailto:s2015312@hotmail.com"><img src="images/email.gif" width="14" height="10" border="0"></a>&nbsp;<a href="mailto:s2015312@hotmail.com">s2015312@hotmail.com</a></font></td>
    <td bgcolor='#E9F7FE' height="30" width='136' ><font face="Tahoma, Microsoft Sans Serif" size="2"><img src="images/icq.gif" width="12" height="11"> 
      ICQ 96356438</font></td>
  </tr>
  <tr> 
    <td width='119' bgcolor='#E9F7FE' height="30" ><font face="Tahoma, Microsoft Sans Serif" size="2"></font></td>
    <td bgcolor='#E9F7FE' height="30" width='178' ><font face="Tahoma, Microsoft Sans Serif" size="2">3.�������ط� 
      ��з����</font></td>
    <td bgcolor='#E9F7FE' height="30" width='150' ><font face="Tahoma, Microsoft Sans Serif" size="2">���ʹѡ�֡�� 
      42015318</font></td>
    <td bgcolor='#E9F7FE' height="30" width='136' ><font face="Tahoma, Microsoft Sans Serif" size="2"> 
      <a href="mailto:s2015318@hotmail.com"><img src="images/email.gif" width="14" height="10" border="0"></a>&nbsp;<a href="mailto:s2015318@hotmail.com">s2015318@hotmail.com</a></font></td>
    <td bgcolor='#E9F7FE' height="30" width='136' ><font face="Tahoma, Microsoft Sans Serif" size="2"><img src="images/icq.gif" width="12" height="11"> 
      ICQ 43047136</font></td>
  </tr>
  <tr> 
    <td bgcolor='#E9F7FE' height="30" colspan="5" >&nbsp;</td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" align = 'center'>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><font face="Tahoma, Microsoft Sans Serif, Microsoft Sans Serif" size="1">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href="mailto:webmaster@ce.kmitl.ac.th">webmaster@ce.kmitl.ac.th</a></font> 
      </div>
    </td>
  </tr>
  <tr> 
    <td height="8"> 
      <hr align="center" width="95%" size="2">
    </td>
  </tr>
  <tr> 
    <td> 
      <div align="center"><img src="images/0.gif" width="24" height="20" border="0"></div>
    </td>
  </tr>
</table>
</body>
</html>
