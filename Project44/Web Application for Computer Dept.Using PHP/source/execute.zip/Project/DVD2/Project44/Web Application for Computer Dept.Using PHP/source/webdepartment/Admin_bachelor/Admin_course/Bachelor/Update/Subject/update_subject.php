<html>
<head>
<title>��䢢���������Ԫ���ѡ�ٵû�ԭ�ҵ��</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<?
echo "
<frameset rows='175,*' cols='*' frameborder='No' border='0' framespacing='0'> 
  <frame name='topFrame' scrolling='NO' noresize src='Frame-1.php' >
  <frameset cols='165,745*' frameborder='No' border='0' framespacing='0' rows='*'> 
    <frame name='leftFrame' noresize scrolling='NO' src='Frame-3.php?course_year=$course_year'>
    <frameset rows='69,*' frameborder='No' border='0' framespacing='0' cols='*'> 
      <frame name='topFrame1' scrolling='NO' noresize src='Frame-4.php?course_year=$course_year' >
      <frame name='mainFrame' scrolling='Yes' src='Frame-2.php?course_year=$course_year'>
    </frameset>
  </frameset>
</frameset>
<noframes>";
?>
<body bgcolor="#FFFFFF">
</body>
</noframes> 
</html>
