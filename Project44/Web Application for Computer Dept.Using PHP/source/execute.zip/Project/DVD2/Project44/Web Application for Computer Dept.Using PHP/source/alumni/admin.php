<?php
session_start();
//	print "$mem[n] $mem[p]";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Administrator Tool</title>
<meta http-equiv="Content-Type" content="text/html; charset=Windows-874">
<!-- �ѡ������͹仾���� Status Bar-->
</head>
<META name="robots" content="index, follow">
<META name="revisit" content="30 days">
<LINK href="script/menustyle.css" rel=stylesheet  type=text/css>
<BODY aLink=#666666 bgColor=white leftMargin=0 topMargin=0 link=blue 
vLink=#ff6600 marginwidth="0" marginheight="0" onLoad="">
<p align="center"><img src="image/admin.jpg" width="480" height="65"></p>
<hr width="80%">
<?php
include("alumni.inc");
include("md5.js");
if($mem[n]&&$mem[p]){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$mem[n]'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	$pwd1=$row["ad_passwd"];
	$pwd1=MD5($pwd1).$mem[c];
	$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
	if($mem[n]==$row["ad_user"] && $mem[p]==$pwd1) { 
			if($mem[n]=="root"){
?>
<p align="center"><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"><a href="regis_admin.php">Register</a> 
  | <a href="del_admin.php">ź��Ҫԡ</a> </font><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"> 
  | </font></b></font><font size="2"><a href="cont_edit.php">�ѡ�֡�ҵ�����ͧ</a></font> 
  | <a href="normal_edit.php"><font size="2">�ѡ�֡�һ���</font></a></b></font><font size="2"></font></b></font></p>
<?php
		}
		else{
?>
<font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font  face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size=1><b><font size="2"><a href="cont_edit.php">�ѡ�֡�ҵ�����ͧ</a></font> 
| <a href="normal_edit.php"><font size="2">�ѡ�֡�һ���</font></a></b></font></b></font> 
<?php		
	}
/*
		$pagesize = 30;
		$gif_up = $a+($b*31)+$c;
		if (empty($page)){
				$page=1;
			}
			$q_sql = "select * from question";
			$q_db_query = mysql_db_query ($dbname, $q_sql);
			$num_rows = mysql_num_rows($q_db_query);
			$rt = $num_rows%$pagesize;
			if($rt!=0) { 
				$totalpage = floor($num_rows/$pagesize)+1; 
			}
			else{
				$totalpage = floor($num_rows/$pagesize); 
			}
			$goto = ($page-1)*$pagesize;
			$sql = "select * from question order by q_id desc limit $goto,$pagesize";
			$db_query = mysql_db_query ($dbname, $sql);
			if (!$db_query){
				print("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() );
				exit;
			}
			else{
				$nums_rows = mysql_num_rows($db_query);
*/				print "<table border=0  width=780 cellspacing=1 cellpadding=4 align=center>";
				print "<tr><td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>���</b></font></td>";
//				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>�ѡ�֡��</b></font></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><B>���ʹѡ�֡��</B></FONT></td>";
				print "<td bgcolor=$corlor_head><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>����-���ʡ��</b></font></td>";
				print "<td bgcolor=$corlor_head ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1><b>Ip</b></font></td></tr>";
/*				for ($i=0;$i<$nums_rows;$i++){
					$result = mysql_fetch_array($db_query);
					$q_id = $result[q_id];
					$q_topic = $result[q_topic];
					$q_name = $result[q_name];
					$q_email = $result[q_email];
					$q_ip = $result[q_ip];
					$q_date = $result[q_datetime];
					$q_time = $result[q_time];
					$q_update = $result[q_update];
					$q_post = $result[q_post];
					$q_reng = $result[q_reng];

					$q_id = stripslashes($q_id);
					$q_topic = stripslashes($q_topic);
					$q_name = stripslashes($q_name);
					$q_email = stripslashes($q_email);
					$q_ip = stripslashes($q_ip);
					$q_date = stripslashes($q_date);
					$q_update = stripslashes($q_update);
					$q_post = stripslashes($q_post);
					print "<Tr> <Td bgcolor=$bg1 width=10><input type='radio' name='delq[$i]' value=$q_id>";
					print "</Td> <Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_date</font></Td>";
					print "<Td  bgcolor=$bg3 width=40%><a href=\"admin_view_answer.php?q_id=$q_id\" target=\"_blank\">";
					print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_topic</font></a></Td>";
					print "<Td bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_name</font></Td>";
					print "<Td  bgcolor=$bg3 ><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_ip</font></Td>";
					print "<Td  bgcolor=$bg2><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$q_reng</font></Td></Tr>";
				}	// end for
*/				print "</table>";
			} // end else
			print "<table border=0 width=780 align=center><tr>";
			print"<td><div align=left><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1></td>";
			print "<td align=right>";
//			print "<FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>Page </font>";
			for($i=1 ; $i<$page ; $i++){
				print "<a href='$PHP_SELF?page=$i'><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
			}
//			print "<font face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1  color=red><b>$page</b></font> ";
			for($i=$page+1 ; $i<=$totalpage ; $i++){
//				print "<a href=$PHP_SELF?page=$i><FONT  face='MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep' size=1>$i</font></a> ";
			}
			print"</td>";
			print"</tr></table></td></tr></table>";
	}
	else{
	?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000000" face="MS Sans Serif, Microsoft Sans Serif" size="3"><font color="#CC0000">USER</font><font color="#FF0000"> 
        <font color="#000000">����</font><font color="#CC0000"> PASSWORD</font></font><br>
        ���١��ͧ��سҵ�Ǩ�ͺ�����ա����</font></div>
    </td>
  </tr>
</table>
<META http-equiv=refresh content="2; URL=login.php">
	<?php
	}
//}
?>
</body>
</html>