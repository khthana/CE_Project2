<?session_start();
//print($id[1]);
?>
<html>
<head>
<title>���ྨ����Ԫ�</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" rel=stylesheet  type='text/css'>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#FFFFFF">
  <table width="630" border="0"  valign=top>
  <tr class=A>
    <td valign="top"> 
  <?
          include("connect.inc.php");
		  $dbname=project();	
		   if($word)
		    {
		    $sql="select * from register where (key1 Like '%$word%' or key2 Like '%$word%' or key3 Like '%$word%' or key4 Like '%$word%' or key5 Like '%$word%') order by year asc,namepe asc";
   	        $dbquery=mysql_db_query($dbname,$sql)or die("error01");
		    $rows=mysql_num_rows($dbquery);	 
		    if($rows!=0)
			  {
			   //print("namepe");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		          if($temp!=$result1[year])
				  {
			?>
		 <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			<tr height='20' class=a> 
                <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
             </tr>
			<?
				 $temp=$result1[year]; 
			     }
			   ?>
		 
		  
		  <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
		  
		  <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>		  		
		<?
		 }//while1     
		  }//if0
		   
		   
		   else
			  {
			    $sql="select * from register where (namepe Like '%$word%' or namept Like '%$word%') order by year asc,namepe asc";
				$dbquery=mysql_db_query($dbname,$sql)or die("error02");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("advisor");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		           if($temp!=$result1[year])
				  {
			   ?>
		        <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20'> 
                      <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
                </tr>
			     </table>
					  <?
				 $temp=$result1[year]; 
			     }
			   ?>
          
		  <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
		  
		  <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while2     
		 }//if1
		   
		   
		   else
			  {
			    $sql="select * from register where (advisor1 Like '%$word%' or advisor2 Like '%$word%') order by year asc,namepe asc";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error02");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("advisor");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		           if($temp!=$result1[year])
				  {
			   ?>
		        <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20'> 
                      <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
                </tr>
			     </table>
					  <?
				 $temp=$result1[year]; 
			     }
			   ?>
          
		  
		  <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
		  
		  <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while2     
		 }//if2
	    
else
			  {
			    $sql="select * from userregister where (name1 Like '%$word%' or name2 Like '%$word%' or name3 Like '%$word%' or name4 Like '%$word%') ";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error04");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("name");
			  //print($rows); 
			   $temp='';
			   while($result=mysql_fetch_array($dbquery))
			     {
		         $sql1="select * from register where id='$result[id]' order by year asc,namepe asc";
  	             $dbquery1=mysql_db_query($dbname,$sql1)or die("error03");
			     $result1=mysql_fetch_array($dbquery1);
			    if($temp!=$result1[year])
				  {
			     ?>
		          <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20'> 
                     <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
                   </tr>
			      <?
				 $temp=$result1[year]; 
			     }
				 ?>
          <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
		 <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while3     
		 }//if3
	    
else
			  {
			    $sql="select * from userregister where (code1 Like '%$word%' or code2 Like '%$word%' or code3 Like '%$word%' or code4 Like '%$word%')";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error05");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("code");			   
			   //print($rows);
			   $temp='';
			   while($result=mysql_fetch_array($dbquery))
			     {
		         $sql1="select * from register where id='$result[id]' order by year asc,namepe asc";
  	             $dbquery1=mysql_db_query($dbname,$sql1)or die("error03");
			     $result1=mysql_fetch_array($dbquery1);
			     if($temp!=$result1[year])
				  {
			    ?>
		           <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			         <tr height='20'> 
                      <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
                    </tr>
			      </table>
					<?
				 $temp=$result1[year]; 
			     }
				 ?>
        
          <table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
          <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while4     
		 }//if4
	   else
			  {
			    $sql="select * from register where (abst Like '%$word%' or abse Like '%$word%') order by year asc,namepe asc";
  	            $dbquery=mysql_db_query($dbname,$sql)or die("error03");
  		        $rows=mysql_num_rows($dbquery);	
                if($rows!=0)
    			  {
			   //print("abst");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
		       
                 if($temp!=$result1[year])
				  {
			?>
		 <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			<tr height='20'> 
                <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
             </tr>
			 </table>
				<?
				 $temp=$result1[year]; 
			     }
			?>
		<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
		  
		  <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while5     
		 }//if5
	  
	    }//else0
		}//else1
        }//else2
		}//else3 
		}//else4 
	    }//if(!word)
		 
		 elseif(($year1)or($year2))
		  {
		 //�֧�����Ũҡ���ҧ register
		  if(($year1!='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-')&&($year1)&&($year2))
           $sql="select * from register where (year between '$year1' and '$year2') or (year between '$year2' and '$year1') "; 
		  elseif(($year1=='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year2' "; 
		  elseif(($year1!='-�ҡ�ա���֡��-')&&($year2=='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year1' "; 
		  else		  
			  {
		  $sql="select year from register order by year Desc,namepe asc";
		  $dbquery=mysql_db_query($dbname,$sql)or die("error1");		  
		  $re=mysql_fetch_array($dbquery);
           
		  $sql="select * from register where year='$re[year]'";
			  }
		 
          $dbquery=mysql_db_query($dbname,$sql)or die("error1");
		  $rows=mysql_num_rows($dbquery);	
		  if(($year1!='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-')&&($year1!="")&&($year2!=""))
           $sql="select * from register where (year between '$year1' and '$year2') or (year between '$year2' and '$year1') order by year asc,namepe asc "; 
		  elseif(($year1=='-�ҡ�ա���֡��-')&&($year2!='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year2' order by namepe asc "; 
		  elseif(($year1!='-�ҡ�ա���֡��-')&&($year2=='-�֧�ա���֡��-'))
            $sql="select * from register where year='$year1' order by namepe asc "; 
		   else    
		      
		    $sql="select * from register where year='$re[year]'order by namepe asc ";
            $dbquery=mysql_db_query($dbname,$sql)or die("error2");
		    $temp='';
			while($result1=mysql_fetch_array($dbquery))
			  {	    
              if($temp!=$result1[year])
				  {
			?>
		 <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			<tr height='20'> 
                <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099"><FONT class=a>�ա���֡�� <?print($result1[year]);?></FONT></td>
             </tr>
			 </table>
				<?
				 $temp=$result1[year]; 
			     }
			?>
			
		<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%' class=A> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%' class=A> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1" class=A>&nbsp;<a href="display1.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
          </table>   
		  
				  
		<table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		 }//while
		}//if
		
	
elseif(($select=='13')&&($id[0]!='')&&($id[1]=='student'))//������ç�ҹ
		{
		?>
		
<table width="630" border="0">
  <tr>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">�ç�ҹ���١���͡</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='100%' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>
		<?
		  $y=date("Y");
		  //�֧ id �ͧ���ҧ �.�. ���١���͡
		  $sql="select * from topicproject,stuproject where (topicproject.check='1' and topicproject.id=stuproject.topicid and stuproject.year=$y) order by topicproject.id asc";
    	  $dbquery=mysql_db_query($dbname,$sql)or die("error4");
		  while($result1=mysql_fetch_array($dbquery))
			  {
		    //�֧�����Ţͧ�.�.���١���͡ ��� id 
			//$sql1="select * from stuproject where topicid='$result[id]'";
    	   // $dbquery1=mysql_db_query($dbname,$sql)or die("error4");
		   // $result1=mysql_fetch_array($dbquery1);
			?>  
			<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			
			   <tr height='2%'> 
                <td width="130" valign="top" height="20" class=topic2>�����ç�ҹ(��)</td>
                <td colspan="2" width="80%" valign="top" height="20" bgcolor="#F1F1F1" ><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;<?print($result1[topic_t]);?></font></td></tr>
              
				<td width="130" valign=top height="20" class=topic2>�Ҩ�������֡��</td> 
				<td colspan="2" width="80%" valign="top" height="20" bgcolor="#F1F1F1" ><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;<?print($result1[advisor1]);?></font>
			   <?if($result1[advisor2])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;<?print($result1[advisor2]);?></font>
				 <?	 
					 }
				?></td></tr>
              
				<td width="130" valign=top height="20" class=topic2>���͹ѡ�֡���ç�ҹ</td> 
				<td  width="200" valign="top" height="20" bgcolor="#F1F1F1" ><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;1.<?print($result1[name1]);?></font>
			   <?
					if($result1[name2])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;2.<?print($result1[name2]);?></font>
				 <?	 
					 }
				    if($result1[name3])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;3.<?print($result1[name3]);?></font>
				 <?	 
					 }
				 	if($result1[name4])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;4.<?print($result1[name4]);?></font>
				 <?	 
					 }
				?>
				</td>
				
				<td  width="330" valign="top" height="20" bgcolor="#F1F1F1" align=left><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;����&nbsp;<?print($result1[code1]);?></font>
			   <?
					if($result1[code2])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;����&nbsp;<?print($result1[code2]);?></font>
				 <?	 
					 }
				    if($result1[code3])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;����&nbsp;<?print($result1[code3]);?></font>
				 <?	 
					 }
				 	if($result1[code4])
				    {
				 ?>
				      <br><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;����&nbsp;<?print($result1[code4]);?></font>
				 <?	 
					 }
				?>
				</td>
					
				
				
				</tr>

		  </table>
          <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			  </td>
				 </tr>
		</table>		  
		<?
		  }//while
		}//������ç�ҹ
		


		elseif(($select==1)&&($id[0]!='')&&($id[1]=='student'))//��Ǣ���ç�ҹ
		{
		?>
		
<table width="630" border="0">
  <tr>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">��Ǣ���ç�ҹ</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='100%' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>
		<?
		  $sql="select * from topicproject where check=0";
    	  $dbquery=mysql_db_query($dbname,$sql)or die("error4");
		  while($result1=mysql_fetch_array($dbquery))
			  {
		    ?>  

			<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			
			   <tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="detailproject.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[topic_t]);?></a></td></tr>
              
				<td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="80%" valign="middle" height="20" bgcolor="#F1F1F1" >&nbsp;<a href="detailproject.php?id1=<?print($result1[id]);?>" class=namepe target=_parent><?$result1[topic_e]=wordwrap($result1[topic_e],80,"<br>",1);print($result1[topic_e]);?></a></td></tr>
              
			  <tr height='2%'> 
               <td width="130" valign="middle" height="20" class=topic2>�ӹǹ</td>
               <td colspan="2" width="80%" valign="middle" height="20" bgcolor="#F1F1F1" ><font face="Tahoma,Ms Sans Serif" size="2">&nbsp;<?print($result1[num]);?>&nbsp;&nbsp;��</font></td>
             </tr>
          </table>
          <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			  </td>
				 </tr>
		</table>		  
		<?
		  }//while
		}//��Ǣ���ç�ҹ
		  
		
		elseif(($select==2)&&($id[0]!='')&&($id[1]=='student'))//��Ǩ�ͺ������
		{
		?>
		
<table width="630" border="0">
  <tr>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">��Ǩ�ͺ������</div>
            </td>
          </tr>
		<tr>
		<td height="5%"  width='100%' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>
		  <?
          //����������´�������ҡ���ҧ services
			$sql="select * from services where code='$id[0]'  order by id asc";
		    $dbquery=mysql_db_query($dbname,$sql)or die("error5");  
		    $rows1=mysql_num_rows($dbquery);
		 ?>
		
<table width="630" border="1" height="9%" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
  <tr height='5%'> 
            <td width="3%" bgcolor="#005AB5" > 
              <div align="center"><font face="Tahoma,Ms Sans Serif" size="2" color="#FFFFFF">No.</font><font face="Tahoma,Ms Sans Serif" size="2"> 
                </font></div>
            </td>
            <td width="72%" bgcolor="#005AB5" > 
              <div align="center"><font size="2" face="Tahoma,Ms Sans Serif" color="#FFFFFF">��觷�����</font></div>
            </td>
            <td width="7%" bgcolor="#005AB5" > 
              <div align="center"><font size="2" face="Tahoma,Ms Sans Serif" color="#FFFFFF">�ӹǹ</font></div>
            </td>
            <td width="18%" bgcolor="#005AB5" > 
              <div align="center"><font size="2" face="Tahoma,Ms Sans Serif" color="#FFFFFF">��˹��׹</font></div>
            </td>
          </tr>
		   <?	
	      
	         $c=0;
               while($result=mysql_fetch_array($dbquery))	
				    { 
				       $c++;
			?>		
		<tr height='7%'> 
            <td width="5%"> 
              	  <div align="center"> 
                     <font size="1" face="Tahoma,Ms Sans Serif" color=#00008A><b><?print($c);?></b></font>
		          </div>
            </td>
            <td width="72%">&nbsp;&nbsp;<font size="1" face="Tahoma,Ms Sans Serif" color=#00008A><b><?$result[devices]=wordwrap($result[devices],80,"<br>",1);print($result[devices]);?></b></font></td>
            <td width="7%"> 
              <div align="center"><font size="1" face="Tahoma,Ms Sans Serif" color=#00008A><b><?print($result[num]);?></b></font></div>
            </td>
            <td width="18%"> 
               <?       
		           if(compareday($result[date1],$result[date2])==1)
                      print("<div align='center'><font size='1' face='Tahoma,Ms Sans Serif' color=#FF0000><b>$result[date2]</b></font></div>");          		           
		           else    
		             print("<div align='center'><font size='1' face='Tahoma,Ms Sans Serif'><b>$result[date2]</b></font></div>");          		           
				   ?>
		       
            </td>
          </tr>
        <?
		}//while
       ?>
		</table>
	   <?   
       }//��Ǩ�͡������
		
		
		elseif(($select=='3')&&($id[0]!='')&&(($id[1]=='teacher')or($id[1]=='admin')or($id[1]=='library')or($id[1]=='store')or($id[1]=='hardware')))//��С�Ȣ���
		 {
		?> 
		 
<table width="630" border="0">
  <tr class=a>         
		    <td  valign=TOP width='650' class=topic> 
              <div align="center">��С�Ȣ���</div>
            </td>
          </tr>
		<tr class=a>
		
		<td height="5%"  width='650' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>
	<?
	if($news=='Submit')
	   {
	     if(($topic!='')&&($detail!='')&&($name!=''))//check data
		   {  
	        if($filenews_size<=5120000)//check size
              {
		 include("dateth.inc.php");
		 //setlocale("LC_TIME","th");
         //$a=strftime("%A");//�����ѹ
         //$b=strftime("%d");//�ѹ���
         //$c=strftime("%B");//��͹���
         //$e=strftime("%Y")+543;//�վ.�.
         //$p="�ѹ".$a."��� ".$b." ".$c." �.�.".$e;
         $p=dateth();
		 $d=date("d-m-Y");	
	   
$detail=htmlspecialchars($detail);
$detail=ereg_replace("\n","<br>",$detail);
$detail=ereg_replace(" ","&nbsp;",$detail);

 //��������ŧ���ҧ news
$sql="insert into news (topic,detail,name,vardate,newsfile,date1) values ('$topic','$detail','$name','$p','$filenews_name','$d')";
$dbquery=mysql_db_query($dbname,$sql)or die("error6");
         
//�Ҩӹǹ record �ͧ���ҧ news ����ա�� record 
$sql="select * from news order by id Desc";
$dbquery=mysql_db_query($dbname,$sql)or die("error7");
$result=mysql_fetch_array($dbquery);

$numnews=$result[id];
 //���ҧ���硷���
  mkdir("news".$numnews,0777) or die("error8");
if($filenews!='none')
//copy file
  {
 copy($filenews,"news".$numnews."/".$filenews_name);
  }
?>
<table width="630" border="0">
  <tr class=a>         
    <td  > 
<div align="center">
<br>
 <br>  
<p>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#0033FF"><b>Complete</b></font></font></p>
  <p><font class=a><font color="#0033FF">��С�Ȣͧ�س�١�Ѵ�����º��������</font></font></p>
  <br>
</div>
</td>
</tr>
</table>	
<?

}//check size
else//check size
{
?>
<table width="630" border="0">
  <tr class=a>         
    <td  > 

<div align="center">
<br>  
<p>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҵ�Ǩ�ͺ��Ҵ File �ͧ�س��ͧ����Թ 5M </font></font></p>
	<p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">(��Ң�Ҵ File �ͧ�س�Թ 5M ��õԴ��� admin)</font></font></p>
 
  <p>&nbsp;</p>
</div>
</td>
</tr>
</table>	

  <?
}//check size

}//check data
else//check data
{
?>
<table width="630" border="0">
  <tr class=a>         
    <td  > 

<div align="center">
<br>  
<p>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҡ�͡������㹪�ͧ���������ͧ����
	&nbsp;*&nbsp; ��ҡѺ�������ú��ǹ����ó�</font></font></p>
	
  <p>&nbsp;</p>
</div>
</td>
</tr>
</table>	

  <?
}//check data

}//news=Submit

else	
	{	//no submit
   ?>
	
<table width="630" border="0"  cellspacing="1" cellpadding="0" borderColorDark=#DAD9D3>
  <tr class=a> 
        <td width="100%" valign="top" bordercolor=#FF9900> 
       
      <table cellspacing=1 cellpadding=5 width='630' border=0 borderColorDark=#ffffff >
        <form name='newsform' action='bodys.php' method=post enctype="multipart/form-data" target=body>
         <INPUT TYPE="hidden" name=select value=3>
			<tr> 
            <td align=right bgcolor=#0055AA width='20%' class=a><font 
            face="Tahoma,Ms Sans Serif"  color="#FFFFFF">��Ǣ�ͻ�С�� :</font></td>
                  <td bgcolor=#FFFFFf> 
                    <input 
            style="FONT-SIZE: 13px; FONT-FAMILY: Tahoma,Ms Sans Serif" maxlength=60 
            size=50 name=topic>
                    <font style="FONT-SIZE: 13px" 
            face='Tahoma,Ms Sans Serif' color=#ff0000 size=1>&nbsp;*</font></td>
          </tr>
          
			<tr valign=top> 
                  <td align=right bgcolor=#0055AA width='20%' class=a><font 
            face="Tahoma,Ms Sans Serif"  color="#FFFFFF">��������´ :</font></td>
                  <td bgcolor=#Ffffff> 
                    <textarea style="FONT-SIZE: 13px; FONT-FAMILY: Tahoma,Ms Sans Serif" name=detail rows=8 wrap=VIRTUAL cols=60></textarea>
                    <font 
            style="FONT-SIZE: 13px" face='Tahoma,Ms Sans Serif' color=#ff0000 
            >&nbsp;*</font></td>
          </tr>
          <tr> 
                  <td align=right bgcolor=#0055AA width='20%' class=a><font 
            face="Tahoma,Ms Sans Serif"  color="#FFFFFF">���ͼ���С�� :</font></td>
                  <td bgcolor=#Ffffff> 
                    <input 
            style="FONT-SIZE: 13px; FONT-FAMILY: Tahoma,Ms Sans Serif" maxlength=40 
            size=30 name=name>
                   <font style="FONT-SIZE: 13px" 
            face='Tahoma,Ms Sans Serif' color=#ff0000 >&nbsp;*</font></td>
          </tr>
          <tr> 
                  <td align=right bgcolor=#0055AA width='20%' class=a><font 
            face="Tahoma,Ms Sans Serif"  color="#FFFFFF">��� :</font></td>
                  <td bgcolor=#Ffffff> 
        
			<input type="file" name="filenews" size="25" maxlength="20">
	<font style="FONT-SIZE: 13px" face='verdana,arial' color=#ff0000 
            >&nbsp;(</font><font 
            face='Tahoma,Ms Sans Serif' style="FONT-SIZE: 13px" color="#330099">Limit 5 M</font><font style="FONT-SIZE: 13px" face='verdana,arial' color=#ff0000 
            >)</font></td>
          </tr>
          <tr valign=top> 
            <td align=right ><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >&nbsp;</font></td>
            <td><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
              <font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 >&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
          </tr>
          <tr> 
            <td align=right><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" >&nbsp;</font></td>
            <td align=left class=a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=news>&nbsp;&nbsp;<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancle>
			 </td>
          </tr>
        </form>
      </table>
	</td>
	</tr>
   </table>
<?
  }//no submit
}//��С�Ȣ���

		elseif(($select=='4')&&($id[0]!='')&&($id[1]=='teacher'))//������Ǣ���ç�ҹ
		{
           if(($select=='4')&&($id[0]!='')&&($id[1]=='teacher')&&($check='Submit')&&($idstu))//check
				  {
					   //����������´��������١���͡
	                   $sql="select * from stuproject where id='$idstu'";
                       $dbquery=mysql_db_query($dbname,$sql)or die("error9"); 
                       $result=mysql_fetch_array($dbquery);
	  
	                    //del ������.� ������١���͡
                        $sql2="delete from stuproject where id!='$idstu' and topicid='$result[topicid]'";
                        $dbquery2=mysql_db_query($dbname,$sql2)or die("error10");
	  
	                     //update check=1 table topicproject 
	                     $sql3="update topicproject set check=1 where  id='$result[topicid]' ";
                         $dbquery3=mysql_db_query($dbname,$sql3)or die("error11");				  
				  }  
	
    	if(($select=='4')&&($id[0]!='')&&($id[1]=='teacher')&&($check2=='Delete'))//check
				  {
						//delete ��Ǣ���ç�ҹ �����ҧ topicproject
                        $sql4="delete from topicproject where id='$idtopic'";
                        $dbquery4=mysql_db_query($dbname,$sql4)or die("error10");
						
						//delete ��Ǣ���ç�ҹ �����ҧ stuproject
                        $sql5="delete from stuproject where topicid='$idtopic'";
                        $dbquery5=mysql_db_query($dbname,$sql5)or die("error10");
				  }  
	?>	      
		 
<table width="630" border="0">
  <tr>         
		    <td  valign=TOP width='630' class=topic> 
              <div align="center">�ç�ҹ����ʹͷ�����</div>
            </td>
          </tr>
		<tr>
		
		<td height="20"  width='630' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>		
		
		  
<table width="630" border="1" height="12%" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
  <tr height='8' class=a> 
          
    <td width="70" bgcolor="#005AB5" height="5%"  > 
      <div align="center"><font class=a>ʶҹ�</font> 
            </div>
          </td>
          
    <td width="500" bgcolor="#005AB5" height="5%"  > 
      <div align="center"><font class=a>�����ç�ҹ����ʹ�</font></div>
          </td>
          
    <td width="70" bgcolor="#005AB5" height="5%"  > 
      <div align="center"><font class=a>�ѹ����ʹ�</font></div>
          </td>
          </tr>
           <? 
           $c=0;
		   $sql="select * from topicproject  where codeadmin='$id[0]'  order by id asc ";
		   $dbquery=mysql_db_query($dbname,$sql)or die("error13");  
		   $rows=mysql_num_rows($dbquery);	
			   if($rows>0)
			     {
	                  while($result=mysql_fetch_array($dbquery))
					   { 
						  $sql1="select * from stuproject  where topicid='$result[id]'";
                          $dbquery1=mysql_db_query($dbname,$sql1)or die("error14");  
		                  $rows1=mysql_num_rows($dbquery1);	
						  $c++;
	        ?>		
		 <tr height='8' class=a> 
                <td width="70" valign="bottom" height="26"> 
                  <div align="center"> <?if($result[check]>=1) 
			     print("<font color=#000000>���͡����</font>"); 
			      elseif($rows1==0) {print("<font color=#000000>�ѧ������͡</font>");} 
			      elseif($rows1>=1) {print("<font color=#000000>�ռ�����͡</font>");}?></div>
          </td>
                <td width="500" valign="bottom" height="26"><a href='stuproject.php?idtopic=<?print($result[id]);?>' class=a1 target=body>
<div align="left"><font style='font-size:14px'>&nbsp;&nbsp;<?$result[topic_t]=wordwrap($result[topic_t],50,"<br>",1);print($result[topic_t]);?></font></div></a>
          </td>
                	  
				  <td width="70" valign="bottom" height="26"> 
                  <div align="center"><font color=#000000><?print($result[date]);?></font></div>
          </td>
          </tr>
          <?}//while
		   }//if	
           
		   ?>
</table>
		<?
		}//������Ǣ���ç�ҹ
   
		 
			 elseif(($select=='5')&&($id[0]!='')&&($id[1]=='teacher'))//�����Ǣ���ç�ҹ
		      {
	     if($Delete=='Delete')
	       {
	            while($c!=0)
				    { 
				       if($del[$c]!='')
						{
						   //ź record 㹵��ҧ topicproject
		                   $sql="delete from topicproject where id ='$del[$c]'";
		                   $dbquery=mysql_db_query($dbname,$sql)or die("error7");
						}	  	  
					   $c--;  	                     
	                }
		   }
		 ?>            
         
<table width="630" border="0">
  <tr>         
		    <td  valign=TOP width='630' class=topic> 
              <div align="center">�����Ǣ���ç�ҹ</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='630' class=a> 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>		
		
 <form name='form5' action='bodys.php' method=post enctype="multipart/form-data" target=body>
<INPUT TYPE="hidden" name=select value=5>
<table width="630" border="1" height="12%" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
  <tr height='5%' class=a> 
          <td width="30" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>No.</font> 
            </div>
          </td>
          <td width="500" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>�����ç�ҹ</font></div>
          </td>
          <td width="70" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>�ѹ����ʹ�</font></div>
          </td>
          <td width="30" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>ź</font></div>
          </td> 
         </tr>
<? 
           $c=0;
		   $sql="select * from topicproject  where codeadmin='$id[0]'  order by id asc ";
		   $dbquery=mysql_db_query($dbname,$sql)or die("error15");  
		   $rows=mysql_num_rows($dbquery);	
			   if($rows>0)
			     {
	                  while($result=mysql_fetch_array($dbquery))
					   { 
						  $c++;
	   ?>		
		 <tr height='5%'> 
                <td width="30" valign="bottom" height="26" > 
                  <div align="center"><font class=a><font  color='#000000'><?print($c.'.')?></font></font></div>
          </td>
              <td width="500" valign="bottom" height="26" ><a href='teacheredit.php?idtopic=<?print($result[id]);?>' class=a1  target=_parent>
<div align="left"><font style='font-size:14px'>&nbsp;&nbsp;<?$result[topic_t]=wordwrap($result[topic_t],80,"<br>",1);print($result[topic_t]);?></font></div></a>
          </td>
          <td width="70" valign="bottom" height="26"> 
          <div align="center"><font class=a><font color=#000000><?print($result[date]);?></font></font></div>
          </td>
          <td width="30" valign="bottom" height="26"> 
          <div align="center"><INPUT TYPE="checkbox" NAME="del[<?print($c);?>]" value='<?print($result[id]);?>'></div>
          </td>
          </tr>
          <?}//while
		   }//if	
           ?>
    </table>
  <table width="630" border="0">
    <tr class=a>
	<td align=center>
           <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Delete name=Delete>&nbsp;
  <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancle>	 
	</td>
	</tr>		   
    </table>
    <INPUT TYPE="hidden" name=c value='<?print($c);?>'>
	 </form>  
	  <?
	   }//�����Ǣ���ç�ҹ	
	   
	   
	   
	   elseif(($select=='6')&&($id[0]!='')&&($id[1]=='admin'))//����ç�ҹ
		  {
	     if($year=='')
			 {
		 ?>
		 
<table width="630" border="0">
  <tr class=a>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">����ç�ҹ</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='100%' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>
<table width="630" border="0">
<tr class=a>
<td>			
<center>
	<select   name="popup" size="1"  onChange="window.open(this.options[this.selectedIndex].value,'body')">
          <option value="value"><font color="#FF8040" ><center>-�ա���֡��-</center></font></option>
          <?          
          	 //�֧������ year �ҡ���ҧ register
             $sql="select Distinct year from register order by year desc";
             $dbquery=mysql_db_query($dbname,$sql)or die("error2");    
		        while($result1=mysql_fetch_array($dbquery))
			      {
		    ?>
		 	      <option value="bodys.php?select=6&year=<?print($result1[year]);?>"><font color="#FF8040"></font><?print($result1[year]);?></option>  
			 <?
		       }//while
		      ?>
        </select>
</center>	   
</td>
</tr>
</table>				  
			  <?
	   }//if($year!='')
	  else
		{
               $sql="select * from register where year='$year' order by namepe asc";
   	           $dbquery=mysql_db_query($dbname,$sql)or die("error01");
			   $temp='';
			   while($result1=mysql_fetch_array($dbquery))
			     {
			    if($temp!=$result1[year])
				  {
			     ?>
		          <table width="630" border="1" height="20" cellSpacing=0 cellPadding=1 >
			       <tr height='20' class=a> 
                     <td  width="630" valign="middle" height="20"  align=center bgcolor="#330099" class=a><FONT class=a>�ա���֡�� <?print($result1[year]);?>(�ç�ҹ���)</FONT></td>
                   </tr>
			      </table>	 
					 <?
				 $temp=$result1[year]; 
			     }
				 ?>
			<table width="630" border="0" height="70" cellSpacing=0 cellPadding=0 >
			<tr height='2%'> 
                <td width="130" valign="middle" height="20" class=topic2>�����ç�ҹ(��)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="form1edit.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?print($result1[namept]);?></a></td></tr>
					
			<tr height='2%'> 
                 <td width="130" valign=middle height="20" class=topic2>�����ç�ҹ(�ѧ���)</td>
                 <td colspan="2" width="500" valign="middle" height="20" bgcolor="#F1F1F1">&nbsp;<a href="form1edit.php?id1=<?print($result1[id]);?>" class=namepe target=_blank><?$result1[namepe]=wordwrap($result1[namepe],100,"<br>",1);print($result1[namepe]);?></a></td></tr>
             
		  </table>
          <table width="630" border="0" height="20" cellSpacing=0 cellPadding=0>
			 <tr height='2%' valign=top> 
             <td >
			  <hr width="500" noshade color=#666600>		  
			 </td>
		   </tr>
		  </table>
		<?
		  }//while     
		 }//if
	     }//����ç�ҹ
	   
	   
	    elseif(($select=='7')&&($id[0]!='')&&($id[1]=='library'))//������
		      {
	     ?>            
         
<table width="670" border="0">
  <tr class=a>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">������</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='100%' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>		
	   
		<?
		$name1=strrpos($namepe1,"�Է�ҹԾ���1");
        $name2=strrpos($namepe2,"�Է�ҹԾ���2");
	 
	   if($namepe1==$namepe2)
        $name2=20;
	 
	   if(($name1!=20) && ($name2!=20))	   	
          $c=2;
		else
		if(($name1==20) && ($name2==20))
	   	  $c=0;
		else
		   $c=1;

       if($borrow!='Submit')
	     {
           //print($c);
		?>
		<form name='yermform' action='bodys.php'  method=post enctype="multipart/form-data" target=body>
       <INPUT TYPE="hidden" name=select value=7>
		
  <table  border="0" width='670'>
    <tr class=a>      
          <td width="23%"  valign="top">                
         <table cellspacing=1 cellpadding=5  border=0  width='100%' align="left">
          <tr  height="30"> 
                        
          <td align=right bgcolor=#0055AA  width="16%"  ><font 
            face="Tahoma,Ms Sans Serif"><font style="FONT-SIZE: 13px"><font color="#FFFFFF">����<font 
            face=verdana> :</font></font></font></font></td>
                  
          <td bgcolor=#ffffff colspan="2" width="97%" >
          <INPUT TYPE="text" NAME="code" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="10" maxlength="10">
		
		<font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 size=1>&nbsp;*</font></td>
 		</tr>
                
			<tr height="30" width="16%" class=a> 
                  
                
          <td align=right bgcolor=#0055AA   width="10%"  class=a><font class=a>�����Է�ҹԾ���1 <font 
            face=verdana>:</font></font></td>
                  
                
          <td bgcolor=#FFFFFF  colspan="2" width="90%"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" > 
            <select name="namepe1" size="1">
                      <option selected>--------------------�Է�ҹԾ���1--------------------</option>
                    <?
			        $sql="select * from register  where check!=1 order by namepe asc";
		            $dbquery=mysql_db_query($dbname,$sql)or die("error5");  
		               while($result=mysql_fetch_array($dbquery))	 
		                  print("<option select>".$result[namepe]."</option>"); 
		             ?>
			        </select>
            </font><font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 size=1>&nbsp;*</font></td>
                </tr>
              
			
			<tr height="30" width="16%" class=a> 
                  
                
          <td align=right bgcolor=#0055AA   width="10%"  class=a><font class=a>�����Է�ҹԾ���2 <font 
            face=verdana>:</font></font></td>
                  
                
          <td bgcolor=#FFFFFF  colspan="2" width="90%"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" size=1> 
            <select name="namepe2" size="1">
                      <option selected>--------------------�Է�ҹԾ���2--------------------</option>
                    <?
			        $sql="select * from register  where check!=1 order by namepe asc";
		            $dbquery=mysql_db_query($dbname,$sql)or die("error5");  
		               while($result=mysql_fetch_array($dbquery))	 
		                  print("<option select>".$result[namepe]."</option>"); 
		             ?>
			        </select>
            </font></td>
                </tr>
			<tr height="30" width="16%" class=a>           
          <td align=right  bgcolor=#0055AA  width="10%" class=a><font 
           class=a>��˹��ѹ�׹ <font face=verdana>:</font></font></td>
                  
                
          <td  bgcolor="#FFFFFF" width="90%" class=a> 
            <input type="text" name="day" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "  size="2" maxlength="2">
                    - 
                    <input type="text" name="month" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "  size="2" maxlength="2">
                    - 
                    <input type="text" name="year" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif "  size="4" maxlength="4">
            <font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 >&nbsp;*&nbsp;</font><font  color=#990033 
            face=Verdana>(</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif" color=#990033>�ѹ - ��͹ - �� �.�.</font><font 
            face=Verdana color=#990033 >)</font> </td>
            </tr>
            <tr> 
          <td align=right width="10%" class=a>&nbsp;</td>
          <td colspan="2" width="90%" ><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
            <font style="FONT-SIZE: 13px" face='verdana,arial' color=#ff0000 >&nbsp;*</font> 
            ��ҡѺ�������ú��ǹ����ó�</font></td>
                </tr>
                <tr> 
                
          <td align=right width="13%" class=a>&nbsp;</td>
                
          <td colspan="2" width="90%" class=a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif" > 
            <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; font-style: normal;width:55px; HEIGHT: 21px;  font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name="borrow">
        <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; font-style: normal; font-weight: bold;width:55px; HEIGHT: 21px;  color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=reset2>  
		            </font></td>             
					</tr>
               </table>
    </tr>
</table>
</form> 
	  <?
}//borrow!=Submit
else//borrow=Submit
	 {
	$dbname=project();
	if(($day!='')&&($month!='')&&($year!='')&&($code!='')&&($namepe1!=''))//check data
	 {
	if(($borrow=='Submit')&&($c!=0))
	 {
                    $c1=$c;  
					$d1=date("d-m-Y");
                    if(($year-date("Y"))>10)
						$year=$year-543;
					$d2=(zerofront($day)."-".zerofront($month)."-".$year);
		            
					 //��������ŧ���ҧ services
                     $sql="insert into services (room,date1,date2,devices,code) values ('library','$d1','$d2','$namepe1','$code')";
                     $dbquery=mysql_db_query($dbname,$sql)or die("error2");	    
        
		             //update check table register
		             $sql="update register set check=1 where namepe='$namepe1' ";
                     $dbquery=mysql_db_query($dbname,$sql)or die("error3");
                     $c1--;

                     if($c1==1)
			           {
					 //��������ŧ���ҧ services
                     $sql="insert into services (room,date1,date2,devices,code) values ('library','$d1','$d2','$namepe2','$code')";
                     $dbquery=mysql_db_query($dbname,$sql)or die("error2");	    
        
		             //update check table register
		             $sql="update register set check=1 where namepe='$namepe2' ";
                     $dbquery=mysql_db_query($dbname,$sql)or die("error3");
                       }
	 ?>
<div align="center">
<br>
 <br>  
<p>
	<font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#0033FF"><b>Complete</b></font></font></p>
  <p><font class=a><font color="#0033FF">�����Ţͧ�س�١�Ѵ��ŧ�ҹ���º��������</font></font></p>  
  <a href='indexs.php' target=_parent class=home>HOME</a>
  <hr width="400">
  <br>
</div>
	 
<?  
	 }
	 }
	 else//check data
       {
      ?>
	  <div align="center">
<br>  
<p>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҡ�͡������㹪�ͧ���������ͧ����
	&nbsp;*&nbsp; ��ҡѺ�������ú��ǹ����ó�</font></font></p>
	
  <p>&nbsp;</p>
</div> 

	 <?
    }//check data
	 }//borrow=Submit 
	 }//������   
	

      elseif(($select=='8')&&($id[0]!='')&&($id[1]=='library'))//��ä׹
		      {
	     ?>            
         
<table width="630" border="0">
  <tr class=a>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">��ä׹</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='100%' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		<br>		
        <?
			  if($submit=='�׹')
				   {
				    while($c!=0)
					   {
                          if($id1[$c]!="")
						   {
					        //�� devices �����ҧ services
							$sql="select * from services where id='$id1[$c]' ";
           		            $dbquery=mysql_db_query($dbname,$sql)or die("error18");  
		                    $result=mysql_fetch_array($dbquery);
				               			 
							 //update check table register =0
		                     $sql="update register set check=0 where  namepe='$result[devices]' ";
                             $dbquery=mysql_db_query($dbname,$sql)or die("error19");
					       
						     //del record table services
		                     $sql="delete from services where id='$id1[$c]'";
		                     $dbquery=mysql_db_query($dbname,$sql)or die("error20");
						   }
					   $c--;
					   }//while 
					}//submit=�׹		 	      
		   	//����������´�������ҡ���ҧ services
			  $sql="select * from services  where code='$code' and room='library' order by id asc";
		      $dbquery=mysql_db_query($dbname,$sql)or die("error21");  
              $rows1=mysql_num_rows($dbquery);	
		?>  
		 
		  
    <form method="post" action="bodys.php" enctype="multipart/form-data" target=body>  
    <INPUT TYPE="hidden" name=select value='8'>
    <table width="630" border="0">
      <tr class=a> 
            <td width="42%" class=a> 
              <div align="right"><font  color="#000000">���ʹѡ�֡��</font></div>
            </td>
  
           
        <td width="11%" class=a> 
          <INPUT TYPE="text" NAME="code" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="10" maxlength="10"> 
		    </td>
			  
        <td width="47%" class=a> 
          <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>	 
            </td>
          </tr>
        </table>
       </form>			
	
 <form method="post" action="bodys.php" enctype="multipart/form-data" target=body>
<INPUT TYPE="hidden" name=select value='8'>
<table width="630" border="1" height="25" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
        <tr height='25' class=a> 
           <td width="7%" bgcolor="#005AB5" class=a> 
               <div align="center"><font class=a>�׹</font></div>
            </td>
          <td width="77%" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>�����Է�ҹԾ���</font></div>
          </td>
          <td width="16%" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>��˹��׹</font></div>
          </td>
          </tr>
  <?
   		      print("<INPUT TYPE='hidden' name=code value='$result[code]'>");      
		      $c=0;
		      //����������´�������ҡ���ҧ services
			  $sql="select * from services  where code='$code' and room='library' order by id asc";
		      $dbquery=mysql_db_query($dbname,$sql)or die("error23");  
               while($result=mysql_fetch_array($dbquery))	
				    { 
				       $c++;
				  ?>
		 <tr height='5%' class=a> 
                
      <td width="30" valign="top" align=center class=a> 
        <?print("<input type='checkbox' name='id1[$c]' value='$result[id]'>");?>
      </td>
                 
      <td width="500" valign="top" class=a>&nbsp;&nbsp;<font color=#000000 > 
        <?$result[devices]=wordwrap($result[devices],80,"<br>",1);print($result[devices]);?>
        </font></td>
                
      <td width="701" valign="top" align=center class=a> 
        <?       
		           if(compareday($result[date1],$result[date2])==1)
                      print("<div align='center'><font  color=#FF0000>$result[date2]</font></div>");          		           
		           else    
		             print("<div align='center'><font color=#000000>$result[date2]</font></div>");          		           
				   ?>
      </td>
          </tr>
         <?}//while
		print("<INPUT TYPE='hidden' name=c value='$c'>");
		print("<INPUT TYPE='hidden' name=code value='$code'>");    
		?>
        </table>
              <br>
		     <center><input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value='�׹' name=submit>	
<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset  value='¡��ԡ' name=cancle></center>
	</form>
	  <?
	  }//��ä׹
		
		
		elseif(($select=='9')&&($id[0]!='')&&(($id[1]=='library')||($id[1]=='hardware')||($id[1]=='store')))//��Ǩ�ͺ������
		      {
	     ?>         
<table width="630" border="0" align=center>
  <tr class=a>         
		    <td  valign=TOP width='630' class=topic> 
              <div align="center">��Ǩ�ͺ������</div>
            </td>
          </tr>
		
		 <tr class=a>
		
		<td height="5%"  width='630' > 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>
		
		<table width="630" border="0" height="100%" align=center>
         <tr height='5%' class=a> 
          <td height="37" valign="bottom" colspan=2 class=a> 
            <div align="left"><font  color="#000066">|</font><a href='bodys.php?select=9&s=1' class=a2>
              �ʴ������������� </a><font  color="#000066">|</font><a href='bodys.php?select=9&s=2' class=a2> �ʴ����������Թ��˹� </a><font  color="#000066">|</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='bodys.php?select=9' target=_parent><IMG SRC="images/printer.jpg"  BORDER=0></a></div>
        </td>
			  </tr>
<? 
     if($id[1]=='library')
	    {
?>
 <tr class=a>
     <td valign="top" class=a>
     <table width="630" border="1" height="25" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
        <tr height='5%' class=a> 
          <td width="70" bgcolor="#005AB5" > 
            <div align="center" ><font class=a>����</font> 
            </div>
          </td>
          <td width="490" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>�����Է�ҹԾ���</font></div>
          </td>
          <td width="70" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>��˹��׹</font></div>
          </td>
          </tr>
<? 
		
if(($s==1)||($s==2))
				  {          
           $sql="select * from services  where room='library' order by code desc , devices asc ";
		   $dbquery=mysql_db_query($dbname,$sql)or die("error26");
		     while($result1=mysql_fetch_array($dbquery))
			  {
		        if((((compareday($result1[date1],$result1[date2]))==1)&&($s==2))||($s==1))
				  { 
?>
		  <tr height='5%' class=a> 
          <td width="70"  valign=top align=center class=a> 
            
            <div align="center"><font color=#000000><?print($result1[code]);?></font></div>
          </td>
          <td width="490" valign="top" class=a> 
            <div align="left">&nbsp;&nbsp;<font color=#000000><?$result1[devices]=wordwrap($result1[devices],80,"<br>",1);print($result1[devices]);?></font></div>
          </td>
          <td width="70" valign="top" class=a> 
              <?       
		           if(compareday($result1[date1],$result1[date2])==1)
                      print("<div align='center'><font  color=#FF0000>$result1[date2]</font></div>");          		           
		           else    
		             print("<div align='center'><font color=#000000>$result1[date2]</font></div>");          		           
				   ?>      
          </td>
        </tr>       
			    <?}//if
					}//while
	}//s==1||s==2//library 
?>
</table>
 </td>
 </tr>       
</table>				

<?
 } 
	  else
		{
		?>		  
<tr class=a>
     <td valign="top" class=a>
        <table width="630" border="1" height="25" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
          <tr height='5%' class=a> 
          <td width="70" bgcolor="#005AB5"  align=center> 
            <div align="center"><font class=a>����</font> 
            </div>
          </td>
          <td width="450" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>�����ػ�ó�</font></div>
          </td>
          <td width="30" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>�ӹǹ</font></div>
          </td>
          <td width="80" bgcolor="#005AB5"  > 
            <div align="center"><font class=a>��˹��׹</font></div>
          </td>
          </tr>
				  
				  
<?				  
		
if(($s==1)||($s==2))
				  {          
           $sql="select * from services  where room='$id[1]' order by code desc , devices asc ";
		   $dbquery=mysql_db_query($dbname,$sql)or die("error27");
		     while($result1=mysql_fetch_array($dbquery))
			  {
		        if((((compareday($result1[date1],$result1[date2]))==1)&&($s==2))||($s==1))
				  { 

?>
		  <tr height='5%' class=a> 
          <td width="70"  valign=top align=center class=a> 
            
            <div align="center"><font color=#000000><?print($result1[code]);?></font></div>
          </td>
          <td width="450" valign="top" class=a> 
            <div align="left">&nbsp;&nbsp;<font color=#000000><?$result1[devices]=wordwrap($result1[devices],80,"<br>",1);print($result1[devices]);?></font></div>
          </td>
          <td width="30"  valign=top align=center class=a> 
            
            <div align="center"><font color=#000000><?print($result1[num]);?></font></div>
          </td>
          
			<td width="80" valign="top" class=a> 
              <?       
		           if(compareday($result1[date1],$result1[date2])==1)
                      print("<div align='center'><font  color=#FF0000>$result1[date2]</font></div>");          		           
		           else    
		             print("<div align='center'><font color=#000000>$result1[date2]</font></div>");          		           
				   ?>      
          </td>
        </tr>       
			    <?}//if
					}//while
	}//s==1||s==2//hardware&&store 
?>
</table>
 </td>
 </tr>       
</table>				

<?
} 
 }//��Ǩ�ͺ������

		
		 elseif(($select=='10')&&($id[0]!='')&&(($id[1]=='store')or($id[1]=='hardware')))//������_store_hardware
       	{
       ?>  
		  
        <table width="630" border="0">
          <tr class=a>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">��Ǩ�ͺ������</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='100%' class=a> 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>     
	<?	if((($code!='')&&($device1!='')&&($num1!='')&&($day!='')&&($month!='')&&($year!='')&&($submit=='���'))or($submit==''))//check data
	  {
		if($device1==$device2)
        $device2='';
	 
	   if(($device1!='') && ($device2!=''))	   	
          $c=2;
		else
		if(($device1=='') && ($device2==''))
	   	  $c=0;
		else
		   $c=1;
		
	    if(($code)&&($c!=0))//check devicces
	       {
                    $c1=$c;  
					$d1=date("d-m-Y");
                    if(($year-date("Y"))>10)
						$year=$year-543;
					$d2=(zerofront($day)."-".zerofront($month)."-".$year);
		            
					 //��������ŧ���ҧ services
                     $sql="insert into services (room,date1,date2,devices,code,num) values ('$id[1]','$d1','$d2','$device1','$code','$num1')";
                     $dbquery=mysql_db_query($dbname,$sql)or die("error29");	    
        
		             $c1--;

                     if($c1==1)
			           {
					 //��������ŧ���ҧ services
                     $sql="insert into services (room,date1,date2,devices,code,num) values ('$id[1]','$d1','$d2','$device2','$code','$num2')";
                     $dbquery=mysql_db_query($dbname,$sql)or die("error30");	    
		               }
  }//check devices
	
	?>	      
 <br>
 <form name='yermform' action='bodys.php'  method=post enctype="multipart/form-data" target=body>					
 <INPUT TYPE="hidden" name=select value=10>
          <table width="630" border="0">
            <tr class=a> 
          <td width="79%"  valign="top" height=50 class==a> 
            <table cellspacing=1 cellpadding=5 width='100%' border=0>
           <tr width="18%" height="30" class=a> 
	       
                    
            <td align=right bgcolor=#0068D0   width="15%" class=a><font =class=a>����<font 
            face=verdana> :</font></font></td>
                  
           

		    <td bgcolor=#ffffff  colspan="4" class=a>
         <INPUT TYPE="text" NAME="code" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="10" maxlength="10"> 
      <font style="FONT-SIZE: 13px" face='verdana,arial' color=#ff0000 size=1>&nbsp;*</font>
			</td>       
		  </tr>
                
			<tr height="30" width="18%" class=a> 
                    
            <td align=right bgcolor=#0068D0   width="15%" ><font 
            class=a>�����ػ�ó�1 <font 
            face=verdana>:</font></font></td>
                  
                    <td bgcolor=#FfFfFF  colspan="2" class=a>
                      <INPUT TYPE="text" NAME="device1"  style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=200 size=50>
			       
                    <font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 size=1>&nbsp;*</font></td>
             
			        
            <td bgcolor=#0068D0  width="9%" class=a> 
              <div align="right"><font class=a">�ӹǹ </font><font 
            face=verdana color="#FFFFFF" style="FONT-SIZE: 13px"><b>:</b></font></div>
          </td>
                    
            <td bgcolor=#FfFfFF  width="18%" valign="middle" class=a> 
              <INPUT TYPE="text" NAME="num1" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=2 size=2 ><font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 >&nbsp;*</font>
			</td>
           </tr>
                
			<tr height="30" width="18%" class=a> 
                    
            <td align=right bgcolor=#0068D0   width="15%" class=a><font 
            class=a>�����ػ�ó�2 <font 
            face=verdana>:</font></font></td>
                  
                    <td bgcolor=#FfFfFF colspan="2">
                      <INPUT TYPE="text" NAME="device2" style="FONT-SIZE: 10pt; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=200 size=50>
			     </td>
           
			        
            <td bgcolor=#0068D0   width="9%" class=a> 
              <div align="right"><font class=a>�ӹǹ </font><font 
            face=verdana color="#FFFFFF" style="FONT-SIZE: 13px"><b>:</b></font></div>
          </td>
                    
            <td bgcolor=#FfFfFF  width="18%" valign="middle" class=a> 
              <INPUT TYPE="text" NAME="num2" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " maxlength=2 size=2>
	      </td>
           </tr>
			<tr height="30" width="18%"> 
                  
            <td align=right  bgcolor=#0068D0   width="15%" ><font 
            class=a>��˹��ѹ�׹ <font 
            face=verdana>:</font></font></td>
                  
                    <td  bgcolor=#FfFfFF colspan=4 class=a> 
                      <input type="text" name="day" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="2" maxlength="2">
                    - 
                    <input type="text" name="month" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="2" maxlength="2">
                    - 
                    <input type="text" name="year" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="4" maxlength="4">
                    <font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 >&nbsp;*&nbsp;</font><font  color=#990033 
            face=Verdana>(</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"  color=#990033>�ѹ - ��͹ - �� �.�.</font><font 
            face=Verdana color=#990033 >)</font> </td>
                </tr>
                <tr> 
                    
            <td colspan="4" class=a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font color=#666666><b><u>������</u>��</b></font> 
              ��سҡ�͡������㹪�ͧ���������ͧ���� <font style="FONT-SIZE: 13px" 
            face='verdana,arial' color=#ff0000 >&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
                </tr>
                <tr> 
			        
            <td align=right width="15%" class=a>&nbsp;</td>
                    <td colspan="2" align=center class=a> 
                      <center>
			 <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px;font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value='���' name=submit>

<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset  value='¡��ԡ' name=cancle></center>
                    </td>
    					</tr>
               </table>
    </tr>
</table>
</form>
<?

}//check data
else//check data
{
?>
<div align="center">
<br>  
<p>
    <font style='font-size:15'><font face="Tahoma,Ms Sans Serif"  color="#FF0000"><b>�����żԴ��Ҵ</b></font></font></p>
  <p><font class=a><font face="Tahoma,Ms Sans Serif"  color="#FF0000">��سҡ�͡������㹪�ͧ���������ͧ����
	&nbsp;*&nbsp; ��ҡѺ�������ú��ǹ����ó�</font></font></p>
	
  <p>&nbsp;</p>
</div> 
<?
}//check data
   }//������_store_hardware
	 
			
	 elseif(($select=='11')&&($id[0]!='')&&(($id[1]=='store')or($id[1]=='hardware')))//��ä׹_store_hardware
       	{
       ?>  
		  
        <table width="630" border="0">
          <tr class=a>         
		    <td  valign=TOP width='100%' class=topic> 
              <div align="center">��ä׹</div>
            </td>
          </tr>
		<tr>
		
		<td height="5%"  width='630' class=a> 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
		</table>     
      	<?  
		if($submit=='�׹')
				   {
				    while($c!=0)
					   {
                          if($id1[$c]!="")
						   {
					        //�� devices �����ҧ services
							$sql="select * from services where id='$id1[$c]' ";
           		            $dbquery=mysql_db_query($dbname,$sql)or die("error31");  
		                    $result=mysql_fetch_array($dbquery);
				               			 
							 //update check table register =0
		                     $sql="update register set check=0 where  namepe='$result[devices]' ";
                             $dbquery=mysql_db_query($dbname,$sql)or die("error32");
					       
						     //del record table services
		                     $sql="delete from services where id='$id1[$c]'";
		                     $dbquery=mysql_db_query($dbname,$sql)or die("error33");
						   }
					   $c--;
					   }//while 
					}//submit=�׹		 	      
		   	//����������´�������ҡ���ҧ services
			  $sql="select * from services  where code='$code' and room='$id[1]' order by id asc";
		      $dbquery=mysql_db_query($dbname,$sql)or die("error34");  
              $rows1=mysql_num_rows($dbquery);	
			?>	      				
		
<form method="post" action="bodys.php" enctype="multipart/form-data" target=body>
<INPUT TYPE="hidden" name=select value='11'>            
        <table width="630" border="0" height="10%">
              <tr class=a> 
            <td width="42%" class=a> 
              <div align="right"><font  color="#000000">���ʹѡ�֡��</font></div>
            </td>
 
		  <td width="11%"><INPUT TYPE="text" NAME="code" style="FONT-SIZE: 13px; FONT-FAMILY:Tahoma,Ms Sans Serif " size="10" maxlength="10">
          </td>  
		  <td class=a> 
                 <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>
            </td>
          </tr>
        </table>
</form>			

<form method="post" action="bodys.php" enctype="multipart/form-data" target=body>
<INPUT TYPE="hidden" name=select value='11'>
            <table width="630" border="1" height="25" bordercolor="#8484FF" cellpadding="0" cellspacing="0" borderColorDark=#ffffff >
              <tr height='25' class=a> 
           <td width="50" bgcolor="#005AB5" class=a> 
               <div align="center"><font class=a>�׹</font></div>
            </td>
          <td width="480" bgcolor="#005AB5"  class=a> 
            <div align="center"><font class=a>�����ػ�ó�</font></div>
          </td>
          <td width="30" bgcolor="#005AB5" class=a > 
            <div align="center"><font class=a>�ӹǹ</font></div>
          </td>                 
          <td width="70" bgcolor="#005AB5" class=a > 
            <div align="center"><font class=a>��˹��׹</font></div>
          </td>
          </tr>
  <?
			 print("<INPUT TYPE='hidden' name=code value='$result[code]'>");      
		      $c=0;
		      //����������´�������ҡ���ҧ services
			  $sql="select * from services  where code='$code' and room='$id[1]' order by id asc";
		      $dbquery=mysql_db_query($dbname,$sql)or die("error36");  
               while($result=mysql_fetch_array($dbquery))	
				    { 
				       $c++;
				  ?>
		 <tr height='5%' class=a> 
          <td width="50" valign="top" align=center class=a> 
                   <?print("<input type='checkbox' name='id1[$c]' value='$result[id]'>");?>
          </td>
                 <td width="480" valign="top" class=a>&nbsp;&nbsp;<font color=#000000><?$result[devices]=wordwrap($result[devices],80,"<br>",1);print($result[devices]);?></font></td>
          <td width="30" valign="top" align=center class=a> 
                    <div align="center"><font color=#000000><?print($result[num]);?></font></div>
          </td>
				 <td width="70" valign="top" align=center class=a> 
                   <?       
		           if(compareday($result[date1],$result[date2])==1)
                      print("<div align='center'><font  color=#FF0000>$result[date2]</font></div>");          		           
		           else    
		             print("<div align='center'><font color=#000000>$result[date2]</font></div>");          		           
				   ?>
          </td>
          </tr>
         <?}//while
		print("<INPUT TYPE='hidden' name=c value='$c'>");
		print("<INPUT TYPE='hidden' name=code value='$code'>");    
		?>
</table>

		<br>
		     <center>
		<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value='�׹' name=submit>	
<input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 9pt; width:55px; HEIGHT: 21px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset  value='¡��ԡ' name=cancle></center>
</form>
<?
		
		}//��ä׹
		
		else
		{
         $dbname=project();
         $sql="select * from news order by id Desc  LIMIT 0,20";
         $dbquery=mysql_db_query($dbname,$sql)or die("error1");
         $rows=mysql_num_rows($dbquery);	 
		?>      
        <table width="630" border="0">
          <tr class=a> 
        
		<td  valign=TOP width='100%' colspan=2 > 
              <div align="center"><a href="more.php" target=body class=filelink>���ǻ�С��</a></div>
            </td>
          </tr>
       
		<tr>
		
		<td height="5%"  width='100%' colspan=2> 
           <div align="center"><hr width="300" color=#000000></div>
         </td>
         </tr>
       
		<tr> 
        <?
		 while($result=mysql_fetch_array($dbquery))
		  {
        ?>
		<tr > 
      
	    <td width="27%" valign="middle" class=a>&nbsp; </td>
         <td width="73%" valign=top class=a><img src="images/icon.gif" width="13" height="11">&nbsp;<a href="display2.php?id1=<?print($result[id]);?>" class=newslink target=_blank><?print($result[topic]);?></a> 
         <?if(checkd($result[date1])!=1) 
	         { 	 
	           print("<img src='images/new.gif' width='28' height='11'>");
	         }
	     ?>
	     </font>
		</td>
         </tr>
         <?}//while
		 ?>      
	    </table>    
        <?
		}
		?>
<br>
        <table width="630" border="0" cellspacing="0" cellpadding="0">
          <tr class=a>
    <td class=a>&nbsp;</td>
  </tr>
  <tr class=a>
    <td class=a>
      <div align="center">
	  <font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font></div>
    </td>
  </tr>
  <tr>
    <td height="8">
      <hr align="center" width="550" size="2">
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
<?
//�Դ�ҹ������
closedb();
?>
 </td>
  </tr>
</table>
</body>
</html>