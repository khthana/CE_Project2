<HTML>
<HEAD>
<TITLE>create database register</TITLE>
</HEAD>
<BODY>
<?
  $handle=mysql_connect("localhost","root","webmaster123")or die("error1");
//create db "project"
  $dbname="register";
  mysql_create_db($dbname,$handle)or die("error2");;

//���ҧ���ҧ regis
  $sql="CREATE TABLE regis  (firstname varchar(40) NOT NULL,code varchar(20) NOT NULL,surname varchar(40) NOT NULL,pass varchar(10) NOT NULL,date varchar(10) NOT NULL,username varchar(20) NOT NULL,status varchar(10) NOT NULL,PRIMARY KEY (username))";
$dbquery=mysql_db_query($dbname,$sql) or die("error3");
mysql_close($handle);

?>
<div align="center">
  <p><br>
    <br>
    <font face="tahoma" size="4" color="#0033FF"><b><font size="5">Complete</font></b></font></p>
  <p><font color="#0033FF">Database 'PROJECT' �١���ҧ���º��������</font></p>
  <hr width="400">
  <br>
</div>
</BODY>
</HTML>
