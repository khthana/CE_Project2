<HTML>
<HEAD>
<TITLE>create</TITLE>
</HEAD>
<BODY bgcolor=ffffff>
<?
include("connect.inc.php");
include("smtpmail.inc.php");
$dbname=register();
$sql="select username from regis where username='$login'";
$dbquery=mysql_db_query($dbname,$sql)or die("error0");
$rows=mysql_num_rows($dbquery);	
if($rows==0)
 {
if($status=='student')
   $code='4'.substr($login,1);
$pass=genpassword();
$d=date('d-m-Y');
 //�� email
 $email=$login."@ce.kmitl.ac.th";
 //$recive=$firstname." ".$surname." ".$code."<".$email.">";
 $subject="register";
			
$message.="username&password �ͧ�س���\n";
$message.="username  :  ".$login."\n"; 
$message.="pass  :  ".$pass."\n";
$message.="date   :  ".$d."\n";
 smail($email,$subject,$message);// or die("�������ö�觨�������");        

//��������ŧ���ҧ regis
$sql="insert into regis (firstname,surname,code,pass,date,username,status) values ('$firstname','$surname','$code','$pass','$d','$login','$status')";
$dbquery=mysql_db_query($dbname,$sql)or die("error1");	    
?>
<div align="center">
  <p><br>
   <br> 
   <br>
    <font face="tahoma" size="5" color="#0033FF"><b>Complete</b></font></p>
  <p><font color="#0033FF" size=3><b>��سҵ�Ǩ�ͺ username&password �ͧ�س��� email �ͧserver diamon </b></font></p>
  <hr width="400">
  <br>
</div>
<?
 }//if
else
   {
?>
 <div align="center">
  <br>
  <p><br><font face="tahoma" size="5" color="#FF0000">�����żԴ��Ҵ</font></p>
  <p><font face="tahoma" size="2" color="#FF0000"><b>���ͧ�ҡ�բ����Ţͧ�س㹰ҹ����������</b></font></p>
  <hr width="400">
  <p>&nbsp;</p>
</div> 
<?
 }
//�Դ�ҹ������
closedb();
?>
</BODY>
</HTML>