<?
session_start();
include("alumni.inc");
include("md5.js");
if ($mem[n]=="root"){
	if($mem[n]&&$mem[p]){
	mysql_connect($hostname, $username, $passwdname) or die("�Դ��Ͱҹ�����������");
	mysql_select_db($dbname) or die("���͡�ҹ�����������");
	$sql="	select * from administrator where ad_user='$mem[n]'";
	$result=mysql_db_query($dbname,$sql);
	$NRow = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	$pwd1=$row["ad_passwd"];
	$pwd1=MD5($pwd1).$mem[c];
	$pwd1=MD5($pwd1);
		// ��Ǩ�ͺ��� Password �١�������	
	if($mem[n]==$row["ad_user"] && $mem[p]==$pwd1) { 
			$sql4 = "select * from administrator where ad_user='$ad_user'";
			$db_query4 = mysql_db_query ($dbname, $sql4);
			$num_rows4 = mysql_num_rows($db_query4);

			$ad_name = htmlspecialchars($ad_name);
			$ad_surname = htmlspecialchars($ad_surname);
			$ad_user = htmlspecialchars($ad_user);
			$ad_passwd = htmlspecialchars($ad_passwd);
			$ad_passwd2 = htmlspecialchars($ad_passwd2);

			if($num_rows4==0){
				$sql = "insert into administrator (ad_id, ad_name, ad_surname, ad_user, ad_passwd, ad_passwd2) values ('0','$ad_name','$ad_surname','$ad_user','$ad_passwd','$ad_passwd2')";
				$result = mysql_db_query($dbname,$sql) or die("�Դ��Ͱҹ�����������23");
				print "<META http-equiv=refresh content=\"0; URL=admin.php\">";
			}
			else{
?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
        USER <font color="#000066">������������ǡ�سҵ�� <font color="#CC0000">USER</font> 
        ����</font></font></div>
    </td>
  </tr>
</table>
<?php
				print "<META http-equiv=refresh content=\"3; URL=regis_admin.php\">";
			}
	}
	}
	else{
		print "no";
	}
}
else{
	?>
<table width="50%" border="1" cellspacing="0" cellpadding="0" align="center" bgcolor="#CCCCFF" bordercolor="#99CCFF">
  <tr> 
    <td height="80"> 
      <div align="center"><font color="#000066" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3">����Ѻ</font><font color="#CC0000" face="MS Sans Serif, EucrosiaUPC, Thonburi,Krungthep" size="3"> 
        Root <font color="#000066">��ҹ�鹷��зӡ��</font> Register<font color="#000066"> 
        ��</font></font></div>
    </td>
  </tr>
</table>

		<?php
}
?>
<script language="JavaScript">
<!--
function check()
{
	  var v1 = document.register .ad_name.value;
      var v2 = document.register .ad_surname.value;
      var v3 = document.register .ad_user.value;
      var v4 = document.register .ad_passwd.value;
      var v5 = document.register .ad_passwd2.value;
	  
        if ( v1.length==0)
           {
           alert("��سһ�͹ ����");
           document.register .ad_name.focus();           
           return false;
           }
        else if (v2.length==0)
           {
           alert("��سһ�͹ ���ʡ��");
           document.register .ad_surname.focus();           
		   return false;
           }
        else if (v3.length==0)
           {
           alert("��سһ�͹ Login Name");
           document.register .ad_user.focus();           
		   return false;
           }
        else if (v4.length==0)
           {
           alert("��سһ�͹ Password");
           document.register .ad_passwd.focus();           
		   return false;
           }
        else if (v5.length==0)
           {
           alert("��سһ�͹ Password �ա����");
           document.register .ad_passwd2.focus();           
		   return false;
           }
}
//-->
</script> 
</body>
</html>