<html>
<head>
<title>newgroup</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<LINK href="main.css" type='text/css' rel=STYLESHEET>
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
.a1
  {
  color:#600060; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 14px;
  }   
.a2
  {
  color:#FF33FF; 
  font-style: bold;
  font-family: "Tahoma,Ms Sans Serif";
  font-size: 14px;
  
  }   
</style>
<SCRIPT LANGUAGE="JavaScript">
<!-- Original: wsabstract.com -->

function checkrequired(which) {
var pass=true;
if (document.images) {
for (i=0;i<which.length;i++) {
var tempobj=which.elements[i];
if ((tempobj.type=="text")&&
(tempobj.value=='')||(tempobj.type=="password"&&
tempobj.value=='')) {
pass=false;
break;
         }
    }
}
if (!pass) {
shortFieldName=tempobj.name.substring(8,30).toUpperCase();
alert("��س������������ú��ǹ");
return false;
}
else
return true;
}
</script>

</head>
<body bgcolor="#FFFFFF">
<table border=0  width="760" align=left height="640">
  <tr class=a>
    <td valign="top"> 
<img src="images/logo.gif" width="305" height="74">
<center>
<?
include("connect.inc.php");
include("censor.inc.php");
$dbname=gwebboard();
if(!$submit)
 {
?>
<form  action='newgroup.php' method=post onSubmit="return checkrequired(this)">
          <table cellspacing=1 cellpadding=15 width=595 border=0>
            <tr> 
              <td align=right bgcolor=#D0E8FF width="128"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>����-ʡ�� <font 
            face=verdana>:</font></b></font></font></td>
              <td bgcolor=#EEF7FF width="414"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
                <input 
            style="FONT-SIZE: 10px;  Tahoma,Ms Sans Serif" maxlength=40
            size=30 name=name>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp; <font color=#990033><font 
            face=Verdana>(</font>��/eng  �����������Թ 40 ���<font 
            face=Verdana>)</font></font></font></td>
    </tr>
    <tr> 
              <td align=right bgcolor=#D0E8FF width="128"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>������ <font 
            face=verdana>:</font></b></font></font></td>
              <td bgcolor=#EEF7FF width="414"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
                <input 
            style="FONT-SIZE: 10px; Tahoma,Ms Sans Serif" maxlength=40 
            size=30 name=email>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font></td>
    </tr>
  <tr> 
              <td align=right bgcolor=#D0E8FF width="128"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>��������´ group <font 
            face=verdana>:</font></b></font></font></td>
              <td bgcolor=#EEF7FF width="414"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
                <input 
            style="FONT-SIZE: 10px; Tahoma,Ms Sans Serif" maxlength=50 
            size=30 name=comment>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp; <font color=#990033><font 
            face=Verdana>(</font>��/eng  �����������Թ 40 ���<font 
            face=Verdana>)</font></font></font></td>
    </tr>
<tr> 
              <td align=right bgcolor=#D0E8FF width="128"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>���� group <font 
            face=verdana>:</font></b></font></font></td>
              <td bgcolor=#EEF7FF width="414"><font style="FONT-SIZE: 8pt" 
            face="Tahoma,Ms Sans Serif"> 
                <input 
            style="FONT-SIZE: 10px; Tahoma,Ms Sans Serif" maxlength=10 
            size=15 name=nameboards>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp; <font color=#990033><font 
            face=Verdana>(</font>eng  only ������� 4-10 ���<font 
            face=Verdana>)</font></font></font></td>
    </tr>
	<tr> 
              <td align=right bgcolor=#D0E8FF width="128"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>Password <font 
            face=verdana>:</font></b></font></font></td>
              <td bgcolor=#EEF7FF width="414"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
                <input 
            style="FONT-SIZE: 10px;Tahoma,Ms Sans Serif" type=password maxlength=6 
            size=15 name=passadmin>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp; <font color=#990033><font 
            face=Verdana>(</font>eng only ������� 4-6 <font 
            face=Verdana>)</font></font></font></td>
    </tr>
	<tr> 
              <td align=right bgcolor=#D0E8FF width="128"><font 
            face="Tahoma,Ms Sans Serif"><font 
            style="FONT-SIZE: 13px"><b>Repassword <font 
            face=verdana>:</font></b></font></font></td>
              <td bgcolor=#EEF7FF width="414"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif"> 
                <input 
            style="FONT-SIZE: 10px; Tahoma,Ms Sans Serif" type=password maxlength=6 
            size=15 name=repassadmin>
        </font><font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font></td>
    </tr>
   
    <tr valign=top> 
              <td align=right width="128"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp;</font></td>
              <td width="414"><font style="FONT-SIZE: 11px" face="Tahoma,Ms Sans Serif" 
            color=#333333 ><font 
            color=#666666><b><u>������</u>��</b></font> ��سҡ�͡������㹪�ͧ���������ͧ���� 
                <font style="FONT-SIZE: 13px" 
            face=verdana,arial color=#ff0000 >&nbsp;*</font> ��ҡѺ�������ú��ǹ����ó�</font></td>
    </tr>
      <tr> 
              <td align=right width="128"><font style="FONT-SIZE: 13px" 
            face="Tahoma,Ms Sans Serif">&nbsp;</font></td>
              <td width="414"><font style="FONT-SIZE: 13px" face="Tahoma,Ms Sans Serif"> 
                <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes
; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=submit value=Submit name=submit>&nbsp;&nbsp;
                    <input style="BORDER-TOP-STYLE: yes; BORDER-RIGHT-STYLE: yes; BORDER-LEFT-STYLE: yes; BACKGROUND-COLOR: #eeeeee; BORDER-BOTTOM-STYLE: yes; font-family: 'Tahoma,Ms Sans Serif', system; font-size: 8pt;width:60px; HEIGHT: 25px; font-style: normal; font-weight: bold; color: #000000;list-style-position: inside; list-style-type: disc" type=reset value=cancel name=cancel>
        </font></td>
    </tr>
  
</table>
</form>
<?
 }//if(!$submit)
elseif($submit)
 {
//$checkemail=0;
//$checknameboard=0;
if((ereg("^.[a-zA-Z0-9_]+@.+\..+$",$email))&&($passadmin==$repassadmin)&&
(ereg("[a-zA-Z0-9_]{4,}",$passadmin))&&(ereg("[a-zA-Z0-9_]{4,}",$nameboards)))
    {
        
		 //��Ǩ�ͺemail��ҫ���������
		 $sql="select * from admin where email ='$email' ";
		 $dbquery=mysql_db_query($dbname,$sql);
		 $num_rows=mysql_num_rows($dbquery);
		 if($num_rows==0)
		   {  
		 //$checkemail=1;		  
		  
		  //��Ǩ�ͺnameboard��ҫ���������
		 $sql="select * from admin where nameboard ='$nameboards'";
		 $dbquery=mysql_db_query($dbname,$sql);
		 $num_rows=mysql_num_rows($dbquery);
		 if($num_rows==0)
			{  
		   $d=date('d-m-Y');
		   $t=date("h:i:s a");
		   //��������ŧ���ҧuser
           $sql="insert into user (email,pass,date,time,own,name) values ('$email','$passadmin','$d','$t','admin','$name')";
		   $dbquery=mysql_db_query($dbname,$sql) or die("error1");
		   
		   $comment=censor($comment);
		   //��������ŧ���ҧadmin
		   $sql="insert into admin (email,nameboard,date1,time1,date2,time2,name,comment) values ('$email','$nameboards','$d','$t','$d','$t','$name','$comment')";
		   $dbquery=mysql_db_query($dbname,$sql)  or die("error2");
           
		   //���ҧ���ҧ�������ǡѺnameboard
		  $sql="create table $nameboards (topic text NOT NULL,date1 varchar(10) NOT NULL,date2 varchar(10) NOT NULL,time1 varchar(11) NOT NULL,time2 varchar(11) NOT NULL,id int(3) DEFAULT '0' NOT NULL auto_increment,UNIQUE id(id),email varchar(30) NOT NULL)";
          $dbquery=mysql_db_query($dbname,$sql) or die("error3");
            		
          //���ҧ���硷��ժ������ǡѺnameboard 
          mkdir($nameboards,0777);  

?>
<font style="font-size:18px" color=#0077EE  face="Tahoma,Ms Sans Serif"><center><b>Create group Complete</b></center></font>
<br>
 <table border="1" align="center" bordercolor="#005EBB" width="418">
          <tr>
    <td valign="top">
              <table width="420" border="0" height="200" cellspacing="0" cellpadding="5" >
                <tr> 
                  <td width="40%" align="right" class=a1 bgcolor=#FFF0F8 height="20">���ͤس���</td>
                  <td colspan="2" width="60%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($name);?>
                  </td>
        </tr>
        <tr> 
                  <td width="40%" align="right" class=a1 bgcolor=#FFF0F8 height="20">Email 
                    �س���</td>
                  <td colspan="2" width="60%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($email);?>
                  </td>
        </tr>
        <tr> 
                  <td width="40%" align="right" class=a1 bgcolor=#FFF0F8 height="20">Group 
                    webboard �س���</td>
                  <td colspan="2" width="60%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($nameboards);?>
                  </td>
        </tr>
        <tr> 
                  <td width="40%" align="right" class=a1 bgcolor=#FFF0F8 height="20">�ѹ�����Ѥ�</td>
                  <td colspan="2" width="60%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($d);?>
                  </td>
        </tr>
        <tr> 
                  <td width="40%" align="right" class=a1 bgcolor=#FFF0F8 height="20">���ҷ����Ѥ�</td>
                  <td colspan="2" width="60%" class=a2 bgcolor=#FFF0F8 height="20"> 
                    <?print($t);?>
                  </td>
        </tr>
       <tr align="center" bgcolor=#FFF0F8> 
          <td colspan="3" class=home>&lt;<a href="index.php">HOME</a>&gt;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<br>
<?
   }
     else
    {
   ?>		
  
   <div align="center">
 <br>
  <br>
<br>
  <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡ���� Group �س��ӡ�س������� Group �ͧ�س�����ա����</b></font></font></p>
 <br>
  <br>
<br>
 <br>
  <br>
<br>

   </div>  
  <? 
   }
   
}
     else
    {
   ?>		
  
   <div align="center">
 <br>
  <br>
<br>
   <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>���ͧ�ҡEmail �س��ӡ�س���� Email �ͧ�س�����ա����</b></font></font></p>

  <br>
  <br>
<br>
 <br>
  <br>
<br>

 </div>  
  <? 
   }

   
   }
   else
	{      
     ?>
   <div align="center">
 <br>
  <br>
<br>

	 <p><br><font class=h><font  color="#FF0000">�����żԴ��Ҵ</font></font></p>
  <p><font class=a><font  color="#FF0000"><b>��س������������١��ͧ</b></font></font></p>
 <br>
  <br>
<br>
 <br>
  <br>
<br>
  
  </div> 
	<?
	}
   
 }//if($submit)
?>
</center>
<?
//�Դ�ҹ������
     closedb();
?>
 <table width="760" border="0" cellspacing="0" cellpadding="0">
  <tr class=a>
    <td class=a>
      <div align="center"><font color="#000080">Department 
        of Computer Engineering Faculty of Engineering King Mongkut's Institute 
        of Technology<br>
        Ladkrabang BKK 10520, Thailand. Tel. +662-3269969 Fax.+662-7392400<br>
        �觤ӵ����� <a href='mailto:webmaster@ce.kmitl.ac.th' class=email>webmaster@ce.kmitl.ac.th</a></font> </div>
    </td>
  </tr>
  <tr>
    <td height="8" class=a>
      <hr align="center" width="550" >
    </td>
  </tr>
  <tr>
    <td>
      <div align="center"></div>
    </td>
  </tr>
</table>
</td>
</tr>
</table>
</body>
</html>