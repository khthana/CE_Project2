#include "stdafx.h"
#include "CChar.h"
#include "Engine\Util.h"
#include "Engine\Triangle.h"
#include "Engine\Camera.h"

CChar::CChar()
{
	m_HP = 100;
	m_Range = 1.0f;
	m_fDesX = Px();
	m_fDesZ = Pz();
	m_IsToAttack = FALSE;
	m_status = STOP;
	m_Velocity = 1.2f;
	m_Power = 1;
}

CChar::CChar(float const Range,int const HP,float const Velocity,int const Power)
{
	m_HP = HP;
	m_Range = Range;
	m_fDesX = Px();
	m_fDesZ = Pz();
	m_IsToAttack = FALSE;
	m_status = STOP;
	m_Velocity = Velocity;
	m_Power = Power;
}

CChar::~CChar()
{
}

int CChar::DesHP(int const HP)
{
	m_HP = m_HP - HP;
	if (m_HP < 0) m_HP =0;
	return m_HP;
}

void CChar::SetHP(int const HP)
{
	m_HP = HP;
}

int CChar::getHP()
{
	return m_HP;
}

BOOL CChar::IsAlive()
{
	if ((m_HP > 0) && (m_status != DEAD)) return TRUE;
	else return FALSE;
}

BOOL CChar::CanAttack(CChar *enemy)
{
	if (IsAlive() == FALSE) return FALSE;
	if (enemy->GetStatus() == DEAD) return FALSE;
	D3DXVECTOR3 t_vec;
	t_vec.x = (enemy->Px()) - Px();
	t_vec.y = 0;
	t_vec.z = (enemy->Pz()) - Pz();
	float t_dis = Vec3::Length(&t_vec);
	if ((t_dis <= m_Range)) //&& (GetCurrentAnimationTime() >= GetCurrentMaxTime()))
		return TRUE;
	else return FALSE;
}

BOOL CChar::ChangeStatus(CHAR_STATUS const status)
{
	if (m_status != DEAD)
	{
		SetAnimation(status,FALSE,1.0f);
		m_status = status;
		return TRUE;
	}
	else return FALSE;
}

CHAR_STATUS CChar::GetStatus()
{
	return m_status;
}

float CChar::GetRange()
{
	return m_Range;
}

void CChar::SetRange(float const Range)
{
	m_Range = Range;
}

void CChar::SetDestination( float fDesX, float fDesZ )
{
	m_fDesX = fDesX;
	m_fDesZ = fDesZ;
}

void CChar::GetDestination( float *pfDesX, float *pfDesZ )
{
	*pfDesX = m_fDesX;
	*pfDesZ = m_fDesZ;
}

BOOL CChar::Attack(CChar *enemy)
{
	if ((CanAttack(enemy) == TRUE)) //&& (GetCurrentAnimationTime() >= GetCurrentMaxTime()))
	{
		enemy->DesHP(m_Power);
		return TRUE;
	}
	else return FALSE;
}
	
void CChar::FaceTo( float X, float Z )
{
	float DelX = X - CMovMat::Px();
	float DelZ = Z - CMovMat::Pz();
	
	if ( ( DelX == 0 ) && ( DelZ == 0 ) )
	{
		return;
	}

	float fZeta;
	if ( DelZ == 0.0f )
	{
		if ( DelX > 0.0f )
		{
			fZeta = 90.0f;
		}
		else
		{
			fZeta = 270;
		}
	}
	else
	{
		fZeta = cs::ToDeg * float(atan(DelX/DelZ));

		if (DelZ < 0.0f)
		fZeta += 180.0f;
	}

	CMovMat::SetRotation( CMovMat::Row(),
						  CMovMat::Phi(),	
						  fZeta );
}

void CChar::SetPower(int const Power)
{
	m_Power = Power;
}

int CChar::GetPower()
{
	return m_Power;
}

void CChar::SetVelocity(float const Vel)
{
	m_Velocity = Vel;
}

void CChar::GetVelocity(float *Vel)
{
	*Vel = m_Velocity;
}

void CChar::ProcessMove(float fElapsedTime)
{
		//FIRE = 0,
	//DEAD = 1, 
	//STOP = 2,
	//WALK = 3
	if (m_status == FIRE)
	{
		if (GetCurrentAnimationTime() >= GetCurrentMaxTime())
		{
			m_status = STOP;
			SetAnimation(m_status,FALSE,1.0f);
		}
	}

	if (m_status == WALK)
	{
		D3DXVECTOR3 t_vec,d_vec;
		t_vec.x = m_fDesX - Px();
		t_vec.z = m_fDesZ - Pz();
		t_vec.y = 0;
		Vec3::Normalize(&d_vec,&t_vec);
		CMovMat::SetPosition(Px() + (d_vec.x*m_Velocity*0.02f),Py(),
							Pz() + (d_vec.z *m_Velocity*0.02f));
		if (Vec3::Length(&t_vec) <= 0.4f)
		{
			m_status = STOP;
			SetAnimation(m_status,FALSE,1.0f);
		}
	}

	if (m_HP <= 0) ChangeStatus(DEAD);
	Process(fElapsedTime);
}

//CChar List
//----------------------
/*
CChList::CChList()
{
	cur_Char = 0;
}

CChList::~CChList()
{
	DestroyAllChar();
}

void CChList::DestroyAllChar()
{
	int nBound  = m_arChar.GetUpperBound();

	for ( int nCount = 0; nCount <= nBound; nCount++ )
	{
		delete ((CChar *)m_arChar.GetAt(nCount));
	}

	m_arChar.RemoveAll();
}

BOOL CChList::AddChar(char* filename)
{
	CChar *pChar = new CChar;
	pChar->LoadModel(filename);
	pChar->SetAnimationID(STOP);
	m_arChar.Add(pSoldier );
	return TRUE;
}

int  CChList::GetNumChar()
{
	return m_arChar.GetUpperBound()+1;
}

BOOL CChList::ProcessMove( float fElapseTime )
{
	int nBound = m_arChar.GetUpperBound();
	for( int i = 0; i <= nBound; i++ )
	{
		CChar *pChar = (CChar *)m_arChar[i];
		BOOL bOk = pChar->ProcessMove( fElapseTime );
		ASSERT( bOk );
	}
	return TRUE;
}

HRESULT CChList::Render( CCamera *pCamera )
{
	D3DXVECTOR3 vEyeAt     = pCamera->GetEyePt();
	D3DXVECTOR3 vLookAt	   = pCamera->GetLookatPt();
	D3DXVECTOR3 vEyeLookAt = D3DXVECTOR3( 
											vLookAt.x - vEyeAt.x , 
											vLookAt.y - vEyeAt.y , 
											vLookAt.z - vEyeAt.z 
										 );

	float ex = vEyeAt.x;
	float ey = vEyeAt.y;
	float ez = vEyeAt.z;

	D3DXVECTOR3 vDir  = pCamera->GetViewDir();
	D3DXVECTOR3 vToSoldier = cs::v3Zero;

	int nBound = m_arChar.GetUpperBound();
	for( int i = 0; i <= nBound; i++ )
	{
		CChar *pChar = (CSoldier *)m_arChar[i];
		
		float px = pChar->CMovMat::Px();
		float py = pChar->CMovMat::Py();
		float pz = pChar->CMovMat::Pz();

		vToSoldier = D3DXVECTOR3( px - ex,
							      py - ey,
								  pz - ez );

		float Angle = float(Vec3::RetAngleDeg( &vToSoldier, &vDir ));

		if( Tool::GetDistance( px, py, pz, ex, ey, ez ) < 400 )
		{
			//if ( (Angle*cs::ToDeg) < 10.0f )
			if( Angle < 60.0f ) pChar->Render();	
		}
	}
	
	return S_OK;
}
*/
