#pragma once

#include "Engine\DynamicModel.h"
//#include "Engine\StaticModel.h"
//#include "Engine\Texture.h"
//#include "Engine\Op.h"

enum CHAR_STATUS
{
	FIRE = 0,
	DEAD = 1, 
	STOP = 2,
	WALK = 3
};

class CChar : public CDObjModel  
{
public:
	CChar();
	CChar(float const Range,int const HP,float const Velocity,int const Power);
	~CChar();

	float GetRange();
	void SetRange(float const Range);

	int DesHP(int const HP);
	void SetHP(int const HP);
	int getHP();

	BOOL IsAlive();
	BOOL CanAttack(CChar *enemy);

	void SetDestination( float fDesX, float fDesZ );
	void GetDestination( float *pfDesX, float *pfDesZ );

	void SetVelocity(float const Vel);
	void GetVelocity(float *Vel);

	void SetPower(int const Power);
	int GetPower();

	void FaceTo( float X, float Z );

	void ProcessMove(float fElapsedTime);

	BOOL ChangeStatus(CHAR_STATUS const status);
	CHAR_STATUS GetStatus();

	BOOL Attack(CChar *enemy);
private:
	int m_HP;
	float m_Range;
	float m_fDesX, m_fDesZ;
	BOOL m_IsToAttack;
	CHAR_STATUS m_status;
	float m_Velocity;

	int m_Power;

public:
	//Sound id
	int AttackID;
	int DieID;
};

/*class CChList
{
private:
	CPtrArray m_arChar;
	int cur_Char;
public:
	CChList();
	~CChList();

	BOOL AddChar(char* filename);
	int  GetNumChar();

	BOOL    ProcessMove( float fElapseTime );
	HRESULT Render( CCamera *pCamera );

	void DestroyAllChar();

	inline CChar *GetAt( int i ) { return (CChar *)m_arChar.GetAt(i); };
	inline int GetUpperBound() { return m_arChar.GetUpperBound(); };

	//void setCurChar(int cur);
	inline int getCurChar() {return cur_Char);
};*/
