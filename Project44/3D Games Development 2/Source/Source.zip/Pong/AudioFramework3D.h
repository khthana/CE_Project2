#ifndef AUDIOFRAMEWORK3D_H
#define AUDIOFRAMEWORK3D_H

#include "CAudioEx.h"

extern HRESULT		DA_init(HWND hWnd);
extern void			DA_cleanup();




#endif