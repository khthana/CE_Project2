#ifndef CMEDIAEX_H
#define CMEDIAEX_H

#include "CMedia.h"

#define MainMedia CMFramework::getCMF()
#define MainMediaTable CMFramework::getCMF()->getMediaTable()

class CMFramework:public CMManager
{
private:
	static CMFramework* CMF;
public:
	CMFramework();
	static CMFramework* getCMF();
	void cleanup();
};

#endif