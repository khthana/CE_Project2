#include <afxwin.h>
#include "CAudioEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CAFramework* CAFramework::CAM=NULL;
CAFramework::CAFramework()
{
	CAM=this;
	NMTable.clear();
	TDTable.clear();
	NMhdGen.cleanup();
	TDhdGen.cleanup();
	curNMHandle = -1;
	cur3DHandle = -1;
}

CAFramework* CAFramework::getCAM()
{
	if(NULL==CAM){
		CAM=new CAFramework();
	}
	return CAM;
}

void CAFramework::cleanup()
{
	NMhdGen.cleanup();
	TDhdGen.cleanup();
	curNMHandle = -1;
	cur3DHandle = -1;

	NmSoundMap::iterator NMIT;
	NMIT = NMTable.begin();
	while(NMIT != NMTable.end())
	{
		if ((*NMIT).second != NULL)
		{
			(*NMIT).second->cleanup();
			SAFE_DELETE((*NMIT).second);
		};
		NMIT++;
    }
	NMTable.clear();

	TdSoundMap::iterator TDIT;
	TDIT = TDTable.begin();
	while(TDIT != TDTable.end())
	{
		if ((*TDIT).second != NULL)
		{
			(*TDIT).second->cleanup();
			SAFE_DELETE((*TDIT).second);
		};
		TDIT++;
    }
	TDTable.clear();


	SAFE_RELEASE(g_pLoader);
	//SAFE_DELETE(g_pListener);
	SAFE_RELEASE(g_pListener);
	SAFE_RELEASE(pDSBPrimary);
	SAFE_RELEASE(g_pDS);
	SAFE_DELETE(CAM);
    //CoUninitialize();

}

HRESULT CAFramework::addNM(TCHAR* filename,int& handle)
{
	HRESULT hr;
	TCHAR t_filename[MAX_PATH];

	strcpy(t_filename,filename);
	CAAudio* t_audio = new CAAudio;
	t_audio->init();
	if (FAILED(hr = t_audio->load(t_filename)))
	{
		t_audio->cleanup();
		SAFE_DELETE(t_audio);
		return E_FAIL;
	}

	int t_hd = NMhdGen.getHandle();
	NMTable.insert(NmSoundMap::value_type(t_hd,t_audio));
	handle = t_hd;

	if (curNMHandle == -1) curNMHandle = t_hd;
	return S_OK;
}

HRESULT CAFramework::cloneNM(int const handle,int& chandle)
{
	NmSoundMap::iterator IT;
	IT = NMTable.find(handle);
	if (IT == NMTable.end()) return E_FAIL;

	CAAudio* t_audio = NULL;
	t_audio = (*IT).second->clone();
	if (t_audio == NULL) return E_FAIL;
	int t_hd = NMhdGen.getHandle();
	NMTable.insert(NmSoundMap::value_type(t_hd,t_audio));
	chandle = t_hd;
	return S_OK;
}

HRESULT CAFramework::eraseNM(int const handle)
{
	NmSoundMap::iterator IT;
	IT = NMTable.find(handle);
	if (IT == NMTable.end()) return E_FAIL;
	else
	{
		(*IT).second->cleanup();
		SAFE_DELETE((*IT).second);
		IT = NMTable.erase(IT);
		NMhdGen.deleteHandle(handle);
		return S_OK;
	}
}

HRESULT CAFramework::add3D(TCHAR* filename,int& handle)
{
	HRESULT hr;
	TCHAR t_filename[MAX_PATH];

	strcpy(t_filename,filename);
	CA3daudio* t_audio = new CA3daudio;
	t_audio->init();
	//----adding
	t_audio->setRelativeMode();
	if (FAILED(hr = t_audio->load(t_filename)))
	{
		t_audio->cleanup();
		SAFE_DELETE(t_audio);
		return E_FAIL;
	}

	int t_hd = TDhdGen.getHandle();
	TDTable.insert(TdSoundMap::value_type(t_hd,t_audio));
	handle = t_hd;

	if (cur3DHandle == -1) cur3DHandle = t_hd;
	return S_OK;
}

HRESULT CAFramework::clone3D(int const handle,int& chandle)
{
	TdSoundMap::iterator IT;
	IT = TDTable.find(handle);
	if (IT == TDTable.end()) return E_FAIL;

	CA3daudio* t_audio = NULL;
	t_audio = (*IT).second->clone();
	if (t_audio == NULL) return E_FAIL;
	int t_hd = TDhdGen.getHandle();
	TDTable.insert(TdSoundMap::value_type(t_hd,t_audio));
	chandle = t_hd;
	return S_OK;
}

HRESULT CAFramework::erase3D(int const handle)
{
	TdSoundMap::iterator IT;
	IT = TDTable.find(handle);
	if (IT == TDTable.end()) return E_FAIL;
	else
	{
		(*IT).second->cleanup();
		SAFE_DELETE((*IT).second);
		IT = TDTable.erase(IT);
		TDhdGen.deleteHandle(handle);
		return S_OK;
	}
}

HRESULT CAFramework::setNMCurrent(int const handle)
{
	NmSoundMap::iterator IT;
	IT = NMTable.find(handle);
	if (IT == NMTable.end()) return E_FAIL;
	else
	{
		curNMHandle = (*IT).first;
		return S_OK;
	}
}

HRESULT CAFramework::getNMCurrent(int& handle)
{
	NmSoundMap::iterator IT;
	if (curNMHandle == -1) return E_FAIL;
	else 
	{
		IT = NMTable.find(curNMHandle);
		if (IT == NMTable.end()) return E_FAIL;
		handle = (*IT).first;
		return S_OK;
	}
}

HRESULT CAFramework::set3DCurrent(int const handle)
{
	TdSoundMap::iterator IT;
	IT = TDTable.find(handle);
	if (IT == TDTable.end()) return E_FAIL;
	else
	{
		cur3DHandle = (*IT).first;
		return S_OK;
	}
}

HRESULT CAFramework::get3DCurrent(int& handle)
{
	TdSoundMap::iterator IT;
	if (cur3DHandle == -1) return E_FAIL;
	else 
	{
		IT = TDTable.find(cur3DHandle);
		if (IT == TDTable.end()) return E_FAIL;
		handle = (*IT).first;
		return S_OK;
	}
}

CAAudio* CAFramework::getNMSound(int const handle)
{
	NmSoundMap::iterator IT;
	IT = NMTable.find(handle);
	if (IT == NMTable.end()) return NULL;
	else
	{
		return (*IT).second;
	}
}

CA3daudio* CAFramework::get3DSound(int const handle)
{
	TdSoundMap::iterator IT;
	IT = TDTable.find(handle);
	if (IT == TDTable.end()) return NULL;
	else
	{
		return (*IT).second;
	}
}

