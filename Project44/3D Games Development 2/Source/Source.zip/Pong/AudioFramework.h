#ifndef AUDIOFRAMEWORK_H
#define AUDIOFRAMEWORK_H

#include "CAudioEx.h"

namespace DA
{

int		init(HWND hWnd);
void		cleanup();

namespace Normal
{
int create(TCHAR* filename,int& handle);
int duplicate(int const s_handle,int& t_handle);
int destroy(int const handle);
int check(int const handle);

void play(int const handle);
void stop(int const handle);
int load(int const handle,TCHAR* filename);
int setloop(int const handle);
int setloop(int const handle,DWORD const loop);
int resetloop(int const handle);
int getloop(int const handle,DWORD& loop);

int isPlay(int const handle);
int getVolume(int const handle,LONG& vol);
int setVolume(int const handle,LONG const vol);

namespace Effect
{
int setChorus(int const handle,DSFXChorus const p);
int setCompressor(int const handle,DSFXCompressor const p);
int setDistortion(int const handle,DSFXDistortion const p);
int setEcho(int const handle,DSFXEcho const p);
int setFlanger(int const handle,DSFXFlanger const p);
int setGargle(int const handle,DSFXGargle const p);
int setParameq(int const handle,DSFXParamEq const p);
int setReverb(int const handle,DSFXWavesReverb const p);

int getChorus(int const handle,DSFXChorus& p);
int getCompressor(int const handle,DSFXCompressor& p);
int getDistortion(int const handle,DSFXDistortion& p);
int getEcho(int const handle,DSFXEcho& p);
int getFlanger(int const handle,DSFXFlanger& p);
int getGargle(int const handle,DSFXGargle& p);
int getParameq(int const handle,DSFXParamEq& p);
int getReverb(int const handle,DSFXWavesReverb& p);

int setChorus(int const handle);
int setCompressor(int const handle);
int setDistortion(int const handle);
int setEcho(int const handle);
int setFlanger(int const handle);
int setGargle(int const handle);
int setParameq(int const handle);
int setReverb(int const handle);

int isChorus(int const handle); 
int isCompressor(int const handle); 
int isDistortion(int const handle);
int isEcho(int const handle);
int isFlanger(int const handle);
int isGargle(int const handle);
int isParameq(int const handle);
int isReverb(int const handle);
int isEffect(int const handle);	

int enableChorus(int const handle);
int enableCompressor(int const handle);
int enableDistortion(int const handle);
int enableEcho(int const handle);
int enableFlanger(int const handle);
int enableGargle(int const handle);
int enableParameq(int const handle);
int enableReverb(int const handle);

int disableChorus(int const handle);
int disableCompressor(int const handle);
int disableDistortion(int const handle);
int disableEcho(int const handle);
int disableFlanger(int const handle);
int disableGargle(int const handle);
int disableParameq(int const handle);
int disableReverb(int const handle);
int disableAllEffect(int const handle);
}}

namespace ThreeD
{
namespace Listener
{
int		setOrientation(D3DVECTOR const front,D3DVECTOR const top);
int		setOrientation(D3DVALUE const fx,D3DVALUE const fy,D3DVALUE const fz,D3DVALUE const tx,D3DVALUE const ty,D3DVALUE const tz);
int		getOrientation(D3DVECTOR& fort,D3DVECTOR& tort);
int		setPosition(D3DVECTOR const pos);
int		setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
int		getPosition(D3DVECTOR& pos);
int		setVelocity(D3DVECTOR const vel);
int		setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
int		getVelocity(D3DVECTOR& vel);
int		setDoppler(D3DVALUE const dop);
int		getDoppler(D3DVALUE& dop);
int		setRolloff(D3DVALUE const rol);
int		getRolloff(D3DVALUE& rol);
}
int create(TCHAR* filename,int& handle);
int duplicate(int const s_handle,int& t_handle);
//int DAudio_duplicate3DSound(TCHAR* name,TCHAR* newsound,CA3DSoundAgent& agent);
int destroy(int const handle);
int check(int const handle);

void play(int const handle);
void stop(int const handle);
int load(int const handle,TCHAR* filename);
int setloop(int const handle);
int setloop(int const handle,DWORD const loop);
int resetloop(int const handle);
int getloop(int const handle,DWORD& loop);

int isPlay(int const handle);
int getVolume(int const handle,LONG& vol);
int setVolume(int const handle,LONG const vol);

namespace Effect
{
int setChorus(int const handle,DSFXChorus const p);
int setCompressor(int const handle,DSFXCompressor const p);
int setDistortion(int const handle,DSFXDistortion const p);
int setEcho(int const handle,DSFXEcho const p);
int setFlanger(int const handle,DSFXFlanger const p);
int setGargle(int const handle,DSFXGargle const p);
int setParameq(int const handle,DSFXParamEq const p);
int setReverb(int const handle,DSFXWavesReverb const p);

int getChorus(int const handle,DSFXChorus& p);
int getCompressor(int const handle,DSFXCompressor& p);
int getDistortion(int const handle,DSFXDistortion& p);
int getEcho(int const handle,DSFXEcho& p);
int getFlanger(int const handle,DSFXFlanger& p);
int getGargle(int const handle,DSFXGargle& p);
int getParameq(int const handle,DSFXParamEq& p);
int getReverb(int const handle,DSFXWavesReverb& p);

int setChorus(int const handle);
int setCompressor(int const handle);
int setDistortion(int const handle);
int setEcho(int const handle);
int setFlanger(int const handle);
int setGargle(int const handle);
int setParameq(int const handle);
int setReverb(int const handle);

int isChorus(int const handle); 
int isCompressor(int const handle); 
int isDistortion(int const handle);
int isEcho(int const handle);
int isFlanger(int const handle);
int isGargle(int const handle);
int isParameq(int const handle);
int isReverb(int const handle);
int isEffect(int const handle);	

int enableChorus(int const handle);
int enableCompressor(int const handle);
int enableDistortion(int const handle);
int enableEcho(int const handle);
int enableFlanger(int const handle);
int enableGargle(int const handle);
int enableParameq(int const handle);
int enableReverb(int const handle);

int disableChorus(int const handle);
int disableCompressor(int const handle);
int disableDistortion(int const handle);
int disableEcho(int const handle);
int disableFlanger(int const handle);
int disableGargle(int const handle);
int disableParameq(int const handle);
int disableReverb(int const handle);
int disableAllEffect(int const handle);

}
namespace Param3D
{
int setMaxDistance(int const handle,D3DVALUE const maxDist);
int getMaxDistance(int const handle,D3DVALUE& maxDist);
int setMinDistance(int const handle,D3DVALUE const minDist);
int getMinDistance(int const handle,D3DVALUE& minDist);
int setPosition(int const handle,D3DVECTOR const pos);
int setPosition(int const handle,D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
int movePosition(int const handle,D3DVECTOR const pos);
int movePosition(int const handle,D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
int getPosition(int const handle,D3DVECTOR& pos);

int setNormalMode(int const handle);
int setRelativeMode(int const handle);
int isNormalMode(int const handle);
int isRelativeMode(int const handle);

int setVelocity(int const handle,D3DVECTOR const vel);
int setVelocity(int const handle,D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
int getVelocity(int const handle,D3DVECTOR& vel);
int setConeAngles(int const handle,DWORD const in,DWORD const out);
int setConeOrientation(int const handle,D3DVECTOR const ort);
int setConeOutsideVolume(int const handle,LONG const vol);
int getConeAngles(int const handle,DWORD& in,DWORD& out);
int getConeOrientation(int const handle,D3DVECTOR& ort);
int getConeOutsideVolume(int const handle,LONG& vol);

}
}}

#endif