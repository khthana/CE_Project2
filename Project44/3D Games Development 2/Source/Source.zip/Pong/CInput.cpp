#include <afxwin.h>
#include "CInput.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//Class Input

CIManager* CIManager::CIM=NULL;
CIEffManager* CIManager::CIEM=NULL;
CIManager::	CIManager(){
	CIM=this;
	CIEM=getCIEM();
	g_pInput = NULL;
	joystickCount = 0;
	mouseCount = 0;
	keyboardCount = 0;
	enumCount =0;
	MainInput->clearArrKeyboard();
	MainInput->clearArrMouse();
	MainInput->clearArrJoystick();
	MainEffect->clearCIEffectTable();
};

CIEffManager::CIEffManager()
{
	curEffect = NULL;
	clearCIEffectTable();
};

CIEffManager::~CIEffManager()
{
	clearCIEffectTable();
	curEffect = NULL;
};

CIManager *CIManager::getCIM()
{
	if(NULL==CIM){
		CIM=new CIManager();
	}
	return CIM;
}

CIEffManager *CIManager::getCIEM()
{
	if(NULL==CIEM){
		CIEM=new CIEffManager();
	}
	return CIEM;
}

HRESULT CIManager::init (HWND const hwnd)
{
	HRESULT hr;
	hr = DirectInput8Create(GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
			    IID_IDirectInput8, (void**)&g_pInput, NULL); 
	if ((g_pInput == NULL) || (FAILED(hr)))
	{ 
		return E_FAIL;
	}
	MainInput->setHWND(hwnd);
	return S_OK;
}

void CIManager::cleanup()
{
	SAFE_RELEASE(g_pInput);
	joystickCount = 0;
	mouseCount = 0;
	keyboardCount = 0;
	enumCount =0;
	MainInput->clearArrKeyboard();
	MainInput->clearArrMouse();
	MainInput->clearArrJoystick();
	MainEffect->clearCIEffectTable();
	SAFE_DELETE(CIEM);
	SAFE_DELETE(CIM);
}

CIEffect* CIEffManager::findCIEffect(TCHAR* name,UINT& index)
{
	CIEFFECT_ROWS t_row;
	TCHAR t_name[MAX_PATH];
	for (UINT i=0;i<getCIEffectTableSize();i++)
	{
		t_row = CIEffectTable[i];
		strcpy(t_name,name);
		if (strcmp(t_row.EffName ,t_name) == 0)
		{
			index = i;
			return CIEffectTable[i].pCIEffect;
		}
	}
	return NULL;
}

HRESULT CIEffManager::setCurEffect(TCHAR* name)
{
	CIEffect* t_Eff;
	UINT t_Num;
	t_Eff = findCIEffect(name,t_Num);
	if (t_Eff != NULL)
	{
		curEffect = t_Eff;
		return S_OK;
	}
	else return E_FAIL;
}

HRESULT CIEffManager::getCIEffectName(CIEffect* pEffect,TCHAR* name)
{
	CIEFFECT_ROWS t_row;
	CIEffect* t_pEffect;
	for (UINT i=0;i<getCIEffectTableSize();i++)
	{
		t_row = CIEffectTable[i];
		t_pEffect = t_row.pCIEffect;
		if (t_pEffect == pEffect)
		{
			strcpy(name,t_row.EffName);
			return S_OK;
		}
	}
	return E_FAIL;
}

UINT CIEffManager::addCIEffectTable(TCHAR* name,CIEffect* const pCIEffect)
{
	CIEFFECT_ROWS t_CIEffectRow;
	t_CIEffectRow.pCIEffect = pCIEffect;
	strcpy(t_CIEffectRow.EffName,name);
	CIEffectTable.push_back(t_CIEffectRow);
	return CIEffectTable.size();
}

UINT CIEffManager::removeCIEffectTable(UINT const index)
{
	CIEffectTable[index].pCIEffect->cleanupAgent();
	CIEffectTable[index].pCIEffect->cleanup();
	SAFE_DELETE(CIEffectTable[index].pCIEffect)

	vector<CIEFFECT_ROWS> t_CIEffectTable;
	vector<CIEFFECT_ROWS> u_CIEffectTable;
	for (UINT i=index+1;i<getCIEffectTableSize();i++)
		t_CIEffectTable.push_back(CIEffectTable[i]);
	for (UINT j=0;j<index;j++)
		u_CIEffectTable.push_back(t_CIEffectTable[j]);

	CIEffectTable.clear();
	for (UINT k=0;k<u_CIEffectTable.size();k++)
		CIEffectTable.push_back(u_CIEffectTable[k]);
	for (UINT l=0;l<t_CIEffectTable.size();l++)
		CIEffectTable.push_back(t_CIEffectTable[l]);
	return getCIEffectTableSize();
}

CIDevice::CIDevice()
{
	g_pDevice = NULL;
}

LPDIRECTINPUT8 CIDevice::getDirectInput ()
{
	HRESULT hr;
	LPDIRECTINPUT8  g_pInput = NULL;
	hr = DirectInput8Create(GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
			    IID_IDirectInput8, (void**)&g_pInput, NULL); 
	if ((g_pInput == NULL) || (FAILED(hr)))
	{ 
		return NULL; 
	}
	return g_pInput;
}

void CIDevice::cleanup ()
{
	if (g_pDevice != NULL)
	{
		g_pDevice->Unacquire(); 
		SAFE_RELEASE(g_pDevice);
	};
}

HRESULT CIDevice::start()
{
	HRESULT hr;
	if (g_pDevice != NULL)
		hr = g_pDevice->Acquire();
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIDevice::stop()
{
	HRESULT hr;
	if (g_pDevice != NULL)
		hr = g_pDevice->Unacquire();
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::start()
{
	HRESULT hr;
	if (g_pDevice != NULL)
		hr = g_pDevice->Acquire();
	if (FAILED(hr)) return hr;
	else 
	{
		//if (FAILED(hr = g_pDevice->Poll())) return E_FAIL;
		//else return S_OK;
		return hr;
	}
}

HRESULT CIKeyboard::init ()
{
	HRESULT hr;
	if (MainInput->getDirectInput()== NULL) return E_FAIL;					

	SetEnumCount(0);
	hr = MainInput->getDirectInput()->EnumDevices(DI8DEVCLASS_KEYBOARD , EnumKeyboardCallback,
                       (void*)&g_pDevice, DIEDFL_ALLDEVICES );
	SetEnumCount(0);
	if (FAILED(hr) || g_pDevice == NULL)
		return E_FAIL;

	hr = g_pDevice->SetDataFormat(&c_dfDIKeyboard); 
	if (FAILED(hr))	
	{
		SetKeyboardCount(GetKeyboardCount() -1);
		SAFE_RELEASE(g_pDevice);
		return E_FAIL;
	}

	hr = g_pDevice->SetCooperativeLevel(MainInput->getHWND(),DISCL_NONEXCLUSIVE | DISCL_BACKGROUND);
	if (FAILED(hr))
	{
		SetKeyboardCount(GetKeyboardCount() -1);
		SAFE_RELEASE(g_pDevice);
		return E_FAIL;
	}
	else return S_OK;
}

BOOL CALLBACK CIKeyboard::EnumKeyboardCallback(LPCDIDEVICEINSTANCE pdidInstance, 
                              LPVOID pvRef) 
{
    HRESULT hr;
	SetEnumCount(GetEnumCount() +1);
	if (GetEnumCount() <= (GetKeyboardCount()))
		return DIENUM_CONTINUE;
	IDirectInputDevice8** ppInputDevice = (IDirectInputDevice8**)pvRef;

	hr = MainInput->getDirectInput()->CreateDevice(pdidInstance->guidInstance, ppInputDevice, NULL);
	if (FAILED(hr)) return DIENUM_STOP;
	SetKeyboardCount(GetKeyboardCount() +1);
	(*ppInputDevice)->Initialize(::GetModuleHandle(NULL), DIRECTINPUT_VERSION, pdidInstance->guidInstance);
	return DIENUM_STOP;
}

void CIKeyboard::cleanup ()
{
	SAFE_RELEASE(g_pDevice);
	SetKeyboardCount(GetKeyboardCount() -1);
}

HRESULT CIMouse::init ()
{
	HRESULT hr;
	if (MainInput->getDirectInput() == NULL) return E_FAIL;					

	SetEnumCount(0);
	hr = MainInput->getDirectInput()->EnumDevices(DI8DEVCLASS_POINTER  , EnumMouseCallback,
                       (void*)&g_pDevice, DIEDFL_ALLDEVICES );
	SetEnumCount(0);
	if (FAILED(hr) || g_pDevice == NULL)
		return E_FAIL;

	hr = g_pDevice->SetDataFormat(&c_dfDIMouse); 
	if (FAILED(hr))	
	{
		SetMouseCount(GetMouseCount() - 1);
		SAFE_RELEASE(g_pDevice);
		return E_FAIL;
	}
	hr = g_pDevice->SetCooperativeLevel(MainInput->getHWND(),DISCL_NONEXCLUSIVE | DISCL_BACKGROUND);
	if (FAILED(hr))
	{
		SetMouseCount(GetMouseCount() - 1);
		SAFE_RELEASE(g_pDevice);
		return E_FAIL;
	}
	else 
	{
		turnAutocenterOFF();
		return S_OK;
	}
}

BOOL CALLBACK CIMouse::EnumMouseCallback(LPCDIDEVICEINSTANCE pdidInstance, 
                              LPVOID pvRef) 
{
    HRESULT hr;
	SetEnumCount(GetEnumCount() +1);
	if (GetEnumCount() <= (GetMouseCount()))
		return DIENUM_CONTINUE;
	IDirectInputDevice8** ppInputDevice = (IDirectInputDevice8**)pvRef;
	hr = MainInput->getDirectInput()->CreateDevice(pdidInstance->guidInstance, ppInputDevice, NULL);
	if (FAILED(hr)) return DIENUM_STOP;
	SetMouseCount(GetMouseCount() + 1);
	//mouseCount++;
	(*ppInputDevice)->Initialize(::GetModuleHandle(NULL), DIRECTINPUT_VERSION, pdidInstance->guidInstance);
	return DIENUM_STOP;
}

void CIMouse::cleanup ()
{
	SAFE_RELEASE(g_pDevice);
	SetMouseCount(GetMouseCount() - 1);
}

HRESULT CIJoystick::init ()
{
	HRESULT hr;
	if (MainInput->getDirectInput() == NULL) return E_FAIL;					

	SetEnumCount(0);
	hr = MainInput->getDirectInput()->EnumDevices(DI8DEVCLASS_GAMECTRL  , EnumJoystickCallback,
                       (void*)&g_pDevice, DIEDFL_ALLDEVICES );
	SetEnumCount(0);
	if (FAILED(hr) || g_pDevice == NULL)
		return E_FAIL;

	hr = g_pDevice->SetDataFormat(&c_dfDIJoystick2); 
	if (FAILED(hr))	
	{
		SetJoystickCount(GetJoystickCount() - 1);
		SAFE_RELEASE(g_pDevice);
		return E_FAIL;
	}
	hr = g_pDevice->SetCooperativeLevel(MainInput->getHWND(),DISCL_EXCLUSIVE | DISCL_BACKGROUND);//DISCL_FOREGROUND);
	if (FAILED(hr))
	{
		SetJoystickCount(GetJoystickCount() - 1);
		SAFE_RELEASE(g_pDevice);
		return E_FAIL;
	}
	else 
	{
		turnAutocenterOFF();
		return S_OK;
	}
}

BOOL CALLBACK CIJoystick::EnumJoystickCallback(LPCDIDEVICEINSTANCE pdidInstance, 
                              LPVOID pvRef) 
{
    HRESULT hr;
	SetEnumCount(GetEnumCount() +1);
	IDirectInputDevice8** ppInputDevice = (IDirectInputDevice8**)pvRef;
	if (GetEnumCount() <= (GetJoystickCount()))
		return DIENUM_CONTINUE;
	hr = MainInput->getDirectInput()->CreateDevice(pdidInstance->guidInstance, ppInputDevice, NULL);
	if (FAILED(hr)) return DIENUM_STOP;
	SetJoystickCount(GetJoystickCount() + 1);
	hr = (*ppInputDevice)->Initialize(::GetModuleHandle(NULL), DIRECTINPUT_VERSION, pdidInstance->guidInstance);
	return DIENUM_STOP;
}

void CIJoystick::cleanup ()
{
	SAFE_RELEASE(g_pDevice);
	SetJoystickCount(GetJoystickCount() - 1);
}


HRESULT CIKeyboard::getState(BYTE* pBuffer)
{
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetDeviceState(256, pBuffer);
    if( FAILED(hr) ) 
    {
        hr = g_pDevice->Acquire();
        while( hr == DIERR_INPUTLOST ) 
            hr = g_pDevice->Acquire();
    }
    return hr;
}

HRESULT CIMouse::getState(DIMOUSESTATE2& buffer)
{
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetDeviceState(sizeof(DIMOUSESTATE2),&buffer);
    if( FAILED(hr) ) 
    {
        hr = g_pDevice->Acquire();
        while( hr == DIERR_INPUTLOST ) 
            hr = g_pDevice->Acquire();
    }	
	return hr;
}

HRESULT CIJoystick::getState(DIJOYSTATE2& buffer)
{
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->Poll();
	//if (hr == DIERR_INPUTLOST) 
    //{
	//	g_pDevice->Acquire();
    //    while( hr == DIERR_INPUTLOST ) 
    //        hr = g_pDevice->Acquire();
	//};
    while( hr == DIERR_INPUTLOST ) 
    {
		g_pDevice->Acquire();
		hr = g_pDevice->Poll();
	};
	if (FAILED(hr)) return hr;	
	hr = g_pDevice->GetDeviceState(sizeof(DIJOYSTATE2),&buffer);
	return hr;
}

HRESULT CIDevice::getInfoGuidProduct(GUID& guidProduct)
{
	DIDEVICEINSTANCE pdidi;
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	pdidi.dwSize = sizeof(DIDEVICEINSTANCE);
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else
	{
	guidProduct = pdidi.guidProduct;
	return S_OK;
	};
}

HRESULT CIDevice::getInfoGuidFFDriver(GUID& guidFFDriver)
{
	DIDEVICEINSTANCE pdidi;
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	pdidi.dwSize = sizeof(DIDEVICEINSTANCE);
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else
	{
	guidFFDriver = pdidi.guidFFDriver;
	return S_OK;
	};
}

HRESULT CIDevice::getInfoInstanceName(TCHAR* tszInstanceName)
{
	DIDEVICEINSTANCE pdidi;
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	pdidi.dwSize = sizeof(DIDEVICEINSTANCE);
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else
	{
	strcpy(tszInstanceName,pdidi.tszInstanceName);
	return S_OK;
	};
}

HRESULT CIDevice::getInfoProductName(TCHAR* tszProductName)
{
	DIDEVICEINSTANCE pdidi;
	HRESULT hr;
	if (g_pDevice == NULL) return E_FAIL;
	pdidi.dwSize = sizeof(DIDEVICEINSTANCE);
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else
	{
	strcpy(tszProductName,pdidi.tszProductName);
	return S_OK;
	};
}

HRESULT CIDevice::getInfoDeviceType(DWORD& type)
{
	HRESULT hr;
	DIDEVICEINSTANCE pdidi;
	pdidi.dwSize = sizeof(DIDEVICEINSTANCE);
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		type = pdidi.dwDevType ;
		return S_OK;
	}
}

HRESULT CIDevice::getInfoDeviceSubType(DWORD& subtype)
{
	HRESULT hr;
	WORD tmp_type;
	DIDEVICEINSTANCE pdidi;
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		tmp_type = LOWORD(pdidi.dwDevType);
		subtype = tmp_type;
		return S_OK;
	}
}

HRESULT CIDevice::getInfoDeviceMainType(DWORD& maintype)
{
	HRESULT hr;
	WORD tmp_type;
	DIDEVICEINSTANCE pdidi;
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetDeviceInfo(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		tmp_type = HIWORD(pdidi.dwDevType);
		maintype = tmp_type;
		return S_OK;
	}
}

BOOL CIDevice::isAttatch()
{
	HRESULT hr;
	DIDEVCAPS pdidi;
	DWORD t_flag,r_flag;
	pdidi.dwSize = sizeof(DIDEVCAPS);
	if (g_pDevice == NULL) return FALSE;
	hr = g_pDevice->GetCapabilities(&pdidi);
	if (FAILED(hr)) return FALSE;
	else 
	{
		t_flag = pdidi.dwFlags;
		r_flag = t_flag & DIDC_ATTACHED;
		if (r_flag != 0) return TRUE;
		else return FALSE;
	}
}


BOOL CIDevice::isFFSupport()
{
	HRESULT hr;
	DIDEVCAPS pdidi;
	DWORD t_flag,r_flag;
	pdidi.dwSize = sizeof(DIDEVCAPS);
	if (g_pDevice == NULL) return FALSE;
	hr = g_pDevice->GetCapabilities(&pdidi);
	if (FAILED(hr)) return FALSE;
	else 
	{
		t_flag = pdidi.dwFlags;
		r_flag = t_flag & DIDC_FORCEFEEDBACK;
		if (r_flag != 0) return TRUE;
		else return FALSE;
	}
}

HRESULT CIDevice::setFFFunction(DWORD const flag)
{
	HRESULT hr;
	if ((g_pDevice == NULL) || (isFFSupport() == FALSE)) return E_FAIL;
	if (FAILED(hr = g_pDevice->SendForceFeedbackCommand(flag)))
		return E_FAIL;
	else return S_OK;
}

HRESULT CIDevice::getFFFunction(DWORD const flag)
{
	HRESULT hr;
	DWORD t_flag;
	if ((g_pDevice == NULL) || (isFFSupport() == FALSE)) return E_FAIL;
	if (FAILED(hr = g_pDevice->GetForceFeedbackState(&t_flag)))
		return E_FAIL;
	else 
	{
		t_flag = t_flag & flag;
		if (t_flag != 0) return S_FALSE;
		else return S_OK;
	}
}

HRESULT CIDevice::setFFPause()
{
	return setFFFunction(DISFFC_PAUSE);
}

HRESULT CIDevice::setFFContinue()
{
	return setFFFunction(DISFFC_CONTINUE);
}

HRESULT CIDevice::setFFStop()
{
	return setFFFunction(DISFFC_STOPALL);
}

HRESULT CIDevice::setFFReset()
{
	return setFFFunction(DISFFC_RESET );

}
HRESULT CIDevice::setFFActuatorsON()
{
	return setFFFunction(DISFFC_SETACTUATORSON);

}

HRESULT CIDevice::setFFActuatorsOFF()
{
	return setFFFunction(DISFFC_SETACTUATORSOFF);
}

HRESULT CIDevice::getFFPause()
{
	return getFFFunction(DIGFFS_PAUSED);
}

HRESULT CIDevice::getFFActuatorsON()
{
	return getFFFunction(DIGFFS_ACTUATORSON);
}

HRESULT CIDevice::getFFActuatorsOFF()
{
	return getFFFunction(DIGFFS_ACTUATORSOFF);
}

HRESULT CINotKeyboard::getInfoAxes(DWORD& numAxes)
{
	HRESULT hr;
	DIDEVCAPS pdidi;
	pdidi.dwSize = sizeof(DIDEVCAPS);
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetCapabilities(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		numAxes = pdidi.dwAxes;
		return S_OK;
	}
}

HRESULT CINotKeyboard::getInfoPOVs(DWORD& numPOVs)
{
	HRESULT hr;
	DIDEVCAPS pdidi;
	pdidi.dwSize = sizeof(DIDEVCAPS);
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetCapabilities(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		numPOVs = pdidi.dwPOVs;
		return S_OK;
	}
}

HRESULT CINotKeyboard::getInfoButtons(DWORD& numButtons)
{
	HRESULT hr;
	DIDEVCAPS pdidi;
	pdidi.dwSize = sizeof(DIDEVCAPS);
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetCapabilities(&pdidi);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		numButtons = pdidi.dwButtons;
		return S_OK;
	}
}

HRESULT CINotKeyboard::turnAutocenterOFF()
{
	DIPROPDWORD dipdw;
	HRESULT hr;
    dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
    dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    dipdw.diph.dwObj        = 0;
    dipdw.diph.dwHow        = DIPH_DEVICE;
    dipdw.dwData            = DIPROPAUTOCENTER_OFF;

	if (g_pDevice == NULL) return E_FAIL;
    if( FAILED( hr = g_pDevice->SetProperty( DIPROP_AUTOCENTER, &dipdw.diph ) ) )
        return E_FAIL;
	else return S_OK;
}

HRESULT CINotKeyboard::turnAutocenterON()
{
	DIPROPDWORD dipdw;
	HRESULT hr;
    dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
    dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    dipdw.diph.dwObj        = 0;
    dipdw.diph.dwHow        = DIPH_DEVICE;
    dipdw.dwData            = DIPROPAUTOCENTER_ON;

	if (g_pDevice == NULL) return E_FAIL;
    if( FAILED( hr = g_pDevice->SetProperty( DIPROP_AUTOCENTER, &dipdw.diph ) ) )
        return E_FAIL;
	else return S_OK;
}

HRESULT CINotKeyboard::setDeadZone(LONG const deadzone)
{
	DIPROPDWORD dipdw;
	HRESULT hr;
	DWORD tmp_deadzone;

	if (g_pDevice == NULL) return E_FAIL;
	tmp_deadzone = deadzone;
    dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
    dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    dipdw.diph.dwObj        = 0;
    dipdw.diph.dwHow        = DIPH_DEVICE;	
    dipdw.dwData            = tmp_deadzone;

    if( FAILED( hr = g_pDevice->SetProperty( DIPROP_DEADZONE , &dipdw.diph ) ) )
        return E_FAIL;
	else return S_OK;
}

HRESULT CINotKeyboard::getDeadZone(LONG& deadzone)
{
	DIPROPDWORD dipdw;
	HRESULT hr;
	LONG tmp_range =0;
	if (g_pDevice == NULL) return E_FAIL;
    if( FAILED( hr = g_pDevice->GetProperty( DIPROP_DEADZONE , &dipdw.diph ) ) )
        return E_FAIL;
	else 
	{
		deadzone = dipdw.dwData;
		return S_OK;
	}
}

HRESULT CINotKeyboard::setSaturation(LONG const saturation)
{
	DIPROPDWORD dipdw;
	HRESULT hr;
	DWORD tmp_saturation;

	if (g_pDevice == NULL) return E_FAIL;
	tmp_saturation = saturation;
    dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
    dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    dipdw.diph.dwObj        = 0;
    dipdw.diph.dwHow        = DIPH_DEVICE;		
    dipdw.dwData            = tmp_saturation;

    if( FAILED( hr = g_pDevice->SetProperty( DIPROP_SATURATION , &dipdw.diph ) ) )
        return E_FAIL;
	else return S_OK;
}

HRESULT CINotKeyboard::getSaturation(LONG& saturation)
{
	DIPROPDWORD dipdw;
	HRESULT hr;
	LONG tmp_range =0;
	if (g_pDevice == NULL) return E_FAIL;
    if( FAILED( hr = g_pDevice->GetProperty( DIPROP_SATURATION , &dipdw.diph ) ) )
        return E_FAIL;
	else 
	{
		saturation = dipdw.dwData;
		return S_OK;
	}
}

HRESULT CINotKeyboard::setRange(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_DEVICE; 
	diprg.diph.dwObj        = 0; 
	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CINotKeyboard::getRange(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_DEVICE; 
	diprg.diph.dwObj        = 0; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIMouse::setRangeX(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIMOFS_X; 
	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIMouse::getRangeX(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIMOFS_X; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIMouse::setRangeY(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIMOFS_Y; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIMouse::getRangeY(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIMOFS_Y; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIMouse::setRangeZ(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIMOFS_Z; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIMouse::getRangeZ(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIMOFS_Z; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIJoystick::setRangeX(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_X ; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::getRangeX(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_X ; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIJoystick::setRangeY(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_Y ; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::getRangeY(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_Y ; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIJoystick::setRangeZ(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_Z; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::getRangeZ(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_Z; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIJoystick::setRangeRX(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_RX  ; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::getRangeRX(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_RX  ; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIJoystick::setRangeRY(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_RY ; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::getRangeRY(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_RY ; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

HRESULT CIJoystick::setRangeRZ(LONG const range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;
	
	if (range >= 0) tmp_range = range;
	else tmp_range = -range;
	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_RZ; 

	diprg.lMin              = -tmp_range; 
	diprg.lMax              = +tmp_range; 
	
	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->SetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else return S_OK;
}

HRESULT CIJoystick::getRangeRZ(LONG& range)
{
	DIPROPRANGE diprg; 
	HRESULT hr;
	DWORD type =0;
	LONG tmp_range =0;

	diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
	diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
	diprg.diph.dwHow        = DIPH_BYOFFSET; 
	diprg.diph.dwObj        = DIJOFS_RZ; 

	if (g_pDevice == NULL) return E_FAIL;
	hr = g_pDevice->GetProperty(DIPROP_RANGE, &diprg.diph);
	if (FAILED(hr)) return E_FAIL;
	else 
	{
		range = diprg.lMax;
		return S_OK;
	};
}

CIEffect::CIEffect()
{
    ZeroMemory( &m_pEffectsList, sizeof( EFFECTS_NODE ) );
    m_pEffectsList.pNext = &m_pEffectsList;
	loop = 1;
	ArrEffAgent.clear();
}

HRESULT CIEffect::init(CIDevice* const pFFDevice,const TCHAR* filename)
{
	HRESULT hr;
	if ((pFFDevice->getDevice() == NULL) || (pFFDevice->isFFSupport() == FALSE)) return E_FAIL;
	if (FAILED(hr = ReadFile(pFFDevice,filename))) return E_FAIL;
	else 
	{
		return S_OK;
	}
}

HRESULT CIEffect::ReadFile(CIDevice* const FFDevice,const TCHAR* filename)
{
	HRESULT hr;
	VOID* pvArr[2];
	pvArr[0] = FFDevice;
	pvArr[1] = &m_pEffectsList;
    EmptyEffectList();
	if(FAILED(hr = FFDevice->getDevice()->EnumEffectsInFile( filename, 
													EnumEffectsCallback, 
                                                    (void*)pvArr , 0 ) ) )
		return E_FAIL;
	else return S_OK;
}

BOOL CALLBACK CIEffect::EnumEffectsCallback(LPCDIFILEEFFECT pDIFileEffect, VOID* pvRef)
{
    HRESULT hr;
    LPDIRECTINPUTEFFECT pDIEffect = NULL;

	CIDevice* pDevice = (CIDevice*)((void**) pvRef)[0];
	EFFECTS_NODE* pEffectList = (EFFECTS_NODE*)((void**) pvRef)[1];

    if( FAILED( hr = (pDevice)->getDevice()->CreateEffect( pDIFileEffect->GuidEffect, 
												pDIFileEffect->lpDiEffect, 
                                                &pDIEffect, NULL ) ) )
        return DIENUM_CONTINUE;

    EFFECTS_NODE* pEffectNode = new EFFECTS_NODE;
    if( NULL == pEffectNode )
        return DIENUM_STOP;

    ZeroMemory( pEffectNode, sizeof( EFFECTS_NODE ) );
    pEffectNode->pDIEffect         = pDIEffect;
    pEffectNode->pNext  = pEffectList->pNext;
    pEffectList->pNext = pEffectNode;

    return DIENUM_CONTINUE;
}

void CIEffect::EmptyEffectList()
{
    EFFECTS_NODE* pEffectNode = m_pEffectsList.pNext;
    EFFECTS_NODE* pEffectDelete;

    while ( pEffectNode != &m_pEffectsList )
    {
        pEffectDelete = pEffectNode;       
        pEffectNode = pEffectNode->pNext;

        SAFE_RELEASE( pEffectDelete->pDIEffect );
        SAFE_DELETE( pEffectDelete );
    }

    m_pEffectsList.pNext = &m_pEffectsList;
}

void CIEffect::cleanup ()
{
    EmptyEffectList();
	loop = 1;
	cleanupAgent();
	ArrEffAgent.clear();
}

HRESULT CIEffect::play()
{
    EFFECTS_NODE*       pEffectNode = m_pEffectsList.pNext;
    LPDIRECTINPUTEFFECT pDIEffect   = NULL;
    HRESULT             hr;

    while ( pEffectNode != &m_pEffectsList )
    {
        pDIEffect = pEffectNode->pDIEffect;
        if( NULL != pDIEffect )
        {
            if( FAILED( hr = pDIEffect->Start(loop, 0 ) ) )
                return hr;
        }
        pEffectNode = pEffectNode->pNext;
    }
    return S_OK;
}

HRESULT CIEffect::setloop()
{
	loop = INFINITE;
	return S_OK;
}

HRESULT CIEffect::setloop(DWORD const dloop)
{
	loop = dloop;
	return S_OK;
}

HRESULT CIEffect::resetloop()
{
	loop = 1;
	return S_OK;
}

HRESULT CIEffect::isPlay()
{
	DWORD pdwFlags;
	DWORD result;
	HRESULT hr;
	if (m_pEffectsList.pNext == NULL) return E_FAIL;
	hr = m_pEffectsList.pNext->pDIEffect->GetEffectStatus(&pdwFlags);// return E_FAIL;
	result = pdwFlags; //& DIEGES_PLAYING ;
	if (result != 0) return S_OK;
	else return S_FALSE;
}

void CIEffect::cleanupAgent()
{
	for (UINT i=0;i<ArrEffAgent.size();i++)
	{
		if (ArrEffAgent[i] != NULL)
		{
			ArrEffAgent[i]->cleanup();
		}
	};
	ArrEffAgent.clear();
}

void CIEffect::removeAgent(CIEffAgent* const pToEffAgent)
{
	vector<CIEffAgent*> u_ArrEffAgent;
	UINT i=0;
	do
	{
		u_ArrEffAgent.push_back(ArrEffAgent[i]);
		if (ArrEffAgent[i] == pToEffAgent)
		{
			u_ArrEffAgent.pop_back();
			vector<CIEffAgent*> t_ArrEffAgent;
			for (UINT j=i+1;j<ArrEffAgent.size();j++)
				t_ArrEffAgent.push_back(ArrEffAgent[j]);
			ArrEffAgent.clear();
			for (UINT k=0;k<u_ArrEffAgent.size();k++)
				ArrEffAgent.push_back(u_ArrEffAgent[k]);
			for (UINT l=0;l<t_ArrEffAgent.size();l++)
				ArrEffAgent.push_back(t_ArrEffAgent[l]);
		}
		i++;
	}while (i<ArrEffAgent.size());
}

void CIEffect::addAgent(CIEffAgent* const pToEffAgent)
{
	ArrEffAgent.push_back(pToEffAgent);
}

BOOL CIEffect::findAgent(CIEffAgent* const pToEffAgent)
{
	for (UINT i=0;i<ArrEffAgent.size();i++)
		if (ArrEffAgent[i] == pToEffAgent) return TRUE;
	return FALSE;
}

CIEffAgent::CIEffAgent()
{
	pCIEffect = NULL;
}

HRESULT CIEffAgent::settoCIEffect(TCHAR* name)
{
	CIEffect* t_pEffect;
	UINT t_index;
	t_pEffect = MainEffect->findCIEffect(name,t_index);
	if (t_pEffect != NULL)
	{
		if (t_pEffect->findAgent(this) == TRUE) return E_FAIL;
		t_pEffect->addAgent(this);
		pCIEffect = t_pEffect;
		return S_OK;
	}
	else return E_FAIL;
}

//HRESULT CIEffAgent::settoCIEffect(CIEffect* pToCIEffect)
//{
//	pCIEffect = pToCIEffect;
//	return S_OK;
//}

void CIEffAgent::cleanup()
{
	if (pCIEffect != NULL)
	{
		pCIEffect->removeAgent(this);
		pCIEffect=NULL;
	}
}

HRESULT CIEffAgent::play()
{
	if (pCIEffect != NULL)
		return pCIEffect->play();
	else return E_FAIL;
}

HRESULT CIEffAgent::setloop()
{
	if (pCIEffect != NULL)
		return pCIEffect->setloop();
	else return E_FAIL;
}

HRESULT CIEffAgent::setloop(DWORD const dloop)
{
	if (pCIEffect != NULL)
		return pCIEffect->setloop(dloop);
	else return E_FAIL;
}

HRESULT CIEffAgent::resetloop()
{
	if (pCIEffect != NULL)
		return pCIEffect->resetloop();
	else return E_FAIL;
}

HRESULT CIEffAgent::isPlay()
{
	if (pCIEffect != NULL)
		return pCIEffect->isPlay();
	else return E_FAIL;
}

CIEffAgent* CIEffAgent::dupEffAgent()
{
	HRESULT hr;
	CIEffAgent* temp_agent = new CIEffAgent;
	TCHAR t_name[MAX_PATH];
	if (pCIEffect == NULL) 
	{
		SAFE_DELETE(temp_agent);
		return NULL;
	};
	if (FAILED(hr = getName(t_name))) 
	{
		SAFE_DELETE(temp_agent);
		return NULL;
	};
	if (FAILED(hr = temp_agent->settoCIEffect(t_name))) 
	{
		SAFE_DELETE(temp_agent);
		return NULL;
	};
	return temp_agent;
}

HRESULT CIEffAgent::getName(TCHAR* name)
{
	if (MainEffect->getCIEffectName(pCIEffect,name) != S_OK) return E_FAIL;
	else return S_OK;
}
