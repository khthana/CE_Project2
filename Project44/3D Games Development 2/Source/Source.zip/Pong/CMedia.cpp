#include <afxwin.h>
#include "CMedia.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMMedia::CMMedia()
{
	m_pGraphBuilder = NULL;
	m_pController = NULL;
	m_pSeeker= NULL;
	m_pAudio= NULL;
	m_pWindow = NULL;
	StartTime = 0;
}

HRESULT CMMedia::open(TCHAR* filename,HWND const hwnd)
{
	CoInitialize(NULL);
	HRESULT hr;
	if FAILED(hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, 
                    IID_IGraphBuilder, (void **)&m_pGraphBuilder))
					return E_FAIL;
	WCHAR wstrFilename[MAX_PATH];
	MultiByteToWideChar( CP_ACP, 0, filename, -1, 
                         wstrFilename, MAX_PATH );
	
    hr = m_pGraphBuilder->RenderFile(wstrFilename, NULL);
	if (FAILED(hr = m_pGraphBuilder->QueryInterface(IID_IMediaControl, (void **)&m_pController)))
	{
		close();
		return E_FAIL;
	};

	if (FAILED(hr = m_pGraphBuilder->QueryInterface(IID_IMediaSeeking, (void **)&m_pSeeker)))
	{
		close();
		return E_FAIL;
	};

	GUID t_format = TIME_FORMAT_MEDIA_TIME;
	if (m_pSeeker->IsFormatSupported(&t_format) != S_OK) 
	{
		close();
		return E_FAIL;
	};

	if (FAILED(hr = m_pSeeker->SetTimeFormat(&t_format)))
	{
		close();
		return E_FAIL;
	};

    if (FAILED(hr = m_pGraphBuilder->QueryInterface(IID_IBasicAudio, (void **)&m_pAudio)))
	{
		close();
		return E_FAIL;
	};

    hr = m_pGraphBuilder->QueryInterface(IID_IVideoWindow, (void **)&m_pWindow);
	hr = m_pWindow->put_Owner((OAHWND)hwnd);
	hr = m_pWindow->put_Visible(OAFALSE);
	hr = m_pWindow->put_WindowStyle(WS_CHILD & WS_DLGFRAME);
	hr = m_pWindow->put_MessageDrain((OAHWND) hwnd);
	return S_OK;
}

void CMMedia::close()
{
	StartTime = 0;
	if (m_pWindow != NULL) 
	{
		m_pWindow->put_Owner (NULL);
		SAFE_RELEASE(m_pWindow);
		//m_pWindow->Release();
	}
	if (m_pController != NULL) 
	{
		m_pController->Stop();
		SAFE_RELEASE(m_pController);
		//m_pController->Release();
	}
	if (m_pSeeker != NULL) 
		//m_pSeeker->Release();
		SAFE_RELEASE(m_pSeeker);
	if (m_pAudio != NULL) 
		//m_pAudio->Release();
		SAFE_RELEASE(m_pAudio);
	if (m_pGraphBuilder != NULL) 
		//m_pGraphBuilder->Release();
		SAFE_RELEASE(m_pGraphBuilder);
}

HRESULT CMMediaPlayer::play()
{
	HRESULT hr;
	if (m_pController == NULL) return E_FAIL;
	if (FAILED(hr = m_pController->Run())) return E_FAIL;
	else 
	{
		if (m_pWindow != NULL ) m_pWindow->put_Visible(OATRUE);
		return S_OK;
	};
}

HRESULT CMMediaPlayer::stop()
{
	HRESULT hr;
	if (m_pController == NULL) return E_FAIL;
	if (FAILED(hr = m_pController->Stop())) return E_FAIL;
	else 
	{
		if (FAILED(hr = setCurrentPosition(StartTime))) return S_FALSE;
		else 
		{
			//if (m_pWindow != NULL ) m_pWindow->put_Visible(OAFALSE);
			return S_OK;
		};
	};
}

HRESULT CMMediaPlayer::pause()
{
	HRESULT hr;
	if (m_pController == NULL) return E_FAIL;
	if (FAILED(hr = m_pController->Pause())) return E_FAIL;
	else return S_OK;
}

BOOL CMMediaPlayer::isPlay()
{
	HRESULT hr;
	if (m_pController == NULL) return FALSE;
	LONG state;
	if (FAILED(hr = m_pController->GetState(INFINITE,&state))) return FALSE;
	if (state == State_Running) return TRUE;
	else return FALSE;
}

BOOL CMMediaPlayer::isStop()
{
	HRESULT hr;
	if (m_pController == NULL) return FALSE;
	LONG state;
	if (FAILED(hr = m_pController->GetState(INFINITE,&state))) return FALSE;
	if (state == State_Stopped) return TRUE;
	else return FALSE;
}

BOOL CMMediaPlayer::isPause()
{
	HRESULT hr;
	if (m_pController == NULL) return FALSE;
	LONG state;
	if (FAILED(hr = m_pController->GetState(INFINITE,&state))) return FALSE;
	if (state == State_Paused) return TRUE;
	else return FALSE;
}

HRESULT CMMediaPlayer::setPlayRate(double const rate)
{
	HRESULT hr;
	double t_rate = rate;
	if (rate == 0) return E_FAIL;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->SetRate(t_rate))) return E_FAIL;
	return S_OK;
}

HRESULT CMMediaPlayer::getPlayRate(double& rate)
{
	HRESULT hr;
	double t_rate;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->GetRate(&t_rate))) return E_FAIL;
	rate = t_rate;
	return S_OK;
}

HRESULT CMMediaPlayer::getVolume(LONG& volume)
{
	HRESULT hr;
	LONG t_vol;
	if (m_pAudio == NULL) return E_FAIL;
	if (FAILED(hr = m_pAudio->get_Volume(&t_vol))) return E_FAIL;
	{
		volume = (t_vol + 10000) / 100;
		return S_OK;
	};
}

HRESULT CMMediaPlayer::setVolume(LONG const volume)
{
	HRESULT hr;
	LONG t_vol;
	t_vol = volume;
	if (t_vol < 0) t_vol = 0;
	else if (t_vol > 100) t_vol = 100;
	t_vol = ((t_vol*100) - 10000);
	if (m_pAudio == NULL) return E_FAIL;
	if (FAILED(hr = m_pAudio->put_Volume(t_vol))) return E_FAIL;
	return S_OK;
}

HRESULT CMMedia::getCurrentPosition(LONGLONG& pos)
{
	HRESULT hr;
	LONGLONG t_pos;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->GetCurrentPosition(&t_pos))) return E_FAIL;
	pos = t_pos;
	return S_OK;
}

HRESULT CMMedia::setCurrentPosition(LONGLONG const pos)
{
	HRESULT hr;
	LONGLONG c_pos = pos;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->SetPositions(&c_pos,AM_SEEKING_AbsolutePositioning,NULL,AM_SEEKING_NoPositioning))) 
		return E_FAIL;
	return S_OK;
}

HRESULT CMMedia::setStopPosition(LONGLONG const pos)
{
	HRESULT hr;
	LONGLONG c_pos = pos;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->SetPositions(NULL,AM_SEEKING_NoPositioning,&c_pos,AM_SEEKING_AbsolutePositioning))) 
		return E_FAIL;
	return S_OK;
}

HRESULT CMMedia::getStopPosition(LONGLONG& pos)
{
	HRESULT hr;
	LONGLONG t_pos;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->GetStopPosition(&t_pos))) return E_FAIL;
	pos = t_pos;
	return S_OK;
}

HRESULT CMMedia::getDuration(LONGLONG& dur)
{
	HRESULT hr;
	LONGLONG t_dur;
	if (m_pSeeker == NULL) return E_FAIL;
	if (FAILED(hr = m_pSeeker->GetDuration(&t_dur))) return E_FAIL;
	dur = t_dur;
	return S_OK;
}

HRESULT CMMedia::setStartPosition(LONGLONG const start)
{
	HRESULT hr;
	if (start < 0) return E_FAIL;
	StartTime = start;
	if (FAILED(hr = setCurrentPosition(StartTime))) return S_FALSE;
	else return S_OK;
}

HRESULT CMMedia::getStartPosition(LONGLONG& start)
{
	start = StartTime;
	return S_OK;
}

HRESULT CMMediaPlayer::setWindowPosition(WINDOW_POS const pos)
{
	HRESULT hr;
	long t_left = pos.left;
	long t_top = pos.top;
	long t_width = pos.width;
	long t_height = pos.height;
	if (m_pWindow == NULL) return E_FAIL;
	if (FAILED(hr = m_pWindow->SetWindowPosition(t_left,t_top,t_width,t_height))) return E_FAIL;
	return S_OK;
}

HRESULT CMMediaPlayer::getWindowPosition(WINDOW_POS& pos)
{
	HRESULT hr;
	WINDOW_POS t_pos;
	long t_left,t_top,t_width,t_height;
	if (m_pWindow == NULL) return E_FAIL;
	if (FAILED(hr = m_pWindow->GetWindowPosition(&t_left,&t_top,&t_width,&t_height))) return E_FAIL;
	t_pos.left = t_left;
	t_pos.top =  t_top;
	t_pos.width = t_width;
	t_pos.height = t_height;
	pos = t_pos;
	return S_OK;
}

HRESULT CMMediaPlayer::setForeground()
{
	HRESULT hr;
	if (m_pWindow == NULL) return E_FAIL;
	if (FAILED(hr = m_pWindow->SetWindowForeground(0))) return E_FAIL;
	return S_OK;
}


// MediaTable
///////////
CMMediaTable::~CMMediaTable()
{
	table.clear();
}

int CMMediaTable::add(MEDIA_ROW const row)
{
	int t_handle = hdGen.getHandle();
	table.insert(MediaMap::value_type(t_handle,row));
	return t_handle;
}

int CMMediaTable::add(TCHAR* filename)
{
	MEDIA_ROW t_row;
	strcpy(t_row.filename,filename);
	t_row.start = 0;
	t_row.end = -1;
	t_row.rate = 1;
	t_row.volume = 100;
	t_row.pos.top = 0;
	t_row.pos.left = 0;
	t_row.pos.height = 240;
	t_row.pos.width = 320;

	int t_handle = hdGen.getHandle();
	table.insert(MediaMap::value_type(t_handle,t_row));
	return t_handle;
}

HRESULT CMMediaTable::set(int const handle,MEDIA_ROW const row)
{
	MediaMap::iterator IT;
	IT = table.find(handle);
	if (IT != table.end())
	{
		IT = table.erase(IT);
		IT = table.insert(IT,MediaMap::value_type(handle,row));
		return S_OK;
	}
	else return E_FAIL;
}

HRESULT CMMediaTable::get(int const handle,MEDIA_ROW& row)
{
	MediaMap::iterator IT;
	IT = table.find(handle);
	if (IT != table.end())
	{
		row = (*IT).second;
		return S_OK;
	}
	else return E_FAIL;
}

HRESULT CMMediaTable::erase(int const handle)
{
	MediaMap::iterator IT;
	IT = table.find(handle);
	if (IT != table.end())
	{
		IT = table.erase(IT);
		hdGen.deleteHandle(handle);
		return S_OK;
	}
	else return E_FAIL;
}

void CMMediaTable::cleanup()
{
	hdGen.cleanup();
	table.clear();
}

//CMManager
//
/////////////
CMMediaPlayer* CMManager::getMediaPlayer(int const playhd)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(playhd);
	if (IT != PlayerTable.end()) return (*IT).second;
	else return NULL;
}

CMManager::CMManager()
{
	curPlayerHandle = -1;
	m_hwnd = 0;
}


HRESULT CMManager::init(HWND const hwnd)
{
	hdGen.cleanup();
	MediaTable.cleanup();
	m_hwnd = hwnd;
	return S_OK;
}

void CMManager::cleanup()
{
	hdGen.cleanup();
	MediaTable.cleanup();
	curPlayerHandle = -1;
	m_hwnd = 0;

	PlayerMap::iterator IT;
	IT = PlayerTable.begin();
	while(IT != PlayerTable.end())
	{
		if ((*IT).second != NULL)
		{
			(*IT).second->close();
			SAFE_DELETE((*IT).second);
		};
		IT++;
    }
	PlayerTable.clear();
}

HRESULT CMManager::load(int const loadhd,int& playhd)
{
	HRESULT hr;
	MEDIA_ROW t_row;
	if (FAILED(hr = MediaTable.get(loadhd,t_row))) 
		return E_FAIL;

	CMMediaPlayer* tempPlayer = new CMMediaPlayer;
	if (FAILED(hr = tempPlayer->open(t_row.filename,m_hwnd)))
	{
		SAFE_DELETE(tempPlayer);
		return E_FAIL;
	}
	//set video
	tempPlayer->setCurrentPosition(t_row.start);
	tempPlayer->setStartPosition(t_row.start);
	if (t_row.end != -1) 
		tempPlayer->setStopPosition(t_row.end);
	tempPlayer->setPlayRate(t_row.rate);
	tempPlayer->setVolume(t_row.volume);
	tempPlayer->setWindowPosition(t_row.pos);
	tempPlayer->setForeground();

	//add video
	int t_hd = hdGen.getHandle();
	PlayerTable.insert(PlayerMap::value_type(t_hd,tempPlayer));
	playhd = t_hd;

	if (curPlayerHandle == -1) curPlayerHandle = t_hd;
	return S_OK;
}

HRESULT CMManager::unload(int const playhd)
{	
	PlayerMap::iterator IT;
	IT = PlayerTable.find(playhd);
	if (IT == PlayerTable.end()) return E_FAIL;
	(*IT).second->close();
	SAFE_DELETE((*IT).second);
	IT = PlayerTable.erase(IT);
	hdGen.deleteHandle(playhd);
	return S_OK;
}

HRESULT CMManager::setCurrent(int const playhd)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(playhd);
	if (IT == PlayerTable.end()) return E_FAIL;
	curPlayerHandle = (*IT).first;
	return S_OK;
}

HRESULT CMManager::getCurrent(int& playhd)
{
	PlayerMap::iterator IT;
	if (curPlayerHandle == -1) return E_FAIL;
	else 
	{
		IT = PlayerTable.find(curPlayerHandle);
		if (IT == PlayerTable.end()) return E_FAIL;
		playhd = (*IT).first;
		return S_OK;
	}
}

HRESULT CMManager::play()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->play();
	}
}

HRESULT CMManager::pause()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->pause();
	}
}

HRESULT CMManager::stop()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->stop();
	}
}

HRESULT CMManager::isPlay()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		if (t_player->isPlay() == TRUE) return S_OK;
		else return S_FALSE;
	}
}

HRESULT CMManager::isPause()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		if (t_player->isPause() == TRUE) return S_OK;
		else return S_FALSE;
	}
}

HRESULT CMManager::isStop()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		if (t_player->isStop() == TRUE) return S_OK;
		else return S_FALSE;
	}
}

HRESULT CMManager::getCurrentPosition(LONGLONG& pos)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		LONGLONG t_pos;
		if (FAILED(hr = t_player->getCurrentPosition(t_pos))) return E_FAIL;
		pos = t_pos;
		return S_OK;
	}
}

HRESULT CMManager::getStopPosition(LONGLONG& pos)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		LONGLONG t_pos;
		if (FAILED(hr = t_player->getStopPosition(t_pos))) return E_FAIL;
		pos = t_pos;
		return S_OK;
	}
}

HRESULT CMManager::setPlayRate(double const rate)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->setPlayRate(rate);
	}
}

HRESULT CMManager::getPlayRate(double& rate)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		double t_rate;
		if (FAILED(hr = t_player->getPlayRate(t_rate))) return E_FAIL;
		rate = t_rate;
		return S_OK;
	}
}

HRESULT CMManager::setEnd(LONGLONG const end) //not for playing
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		if (t_player->isStop() == TRUE)
			return t_player->setStopPosition(end); 
		else return E_FAIL;
	}
}

HRESULT CMManager::getEnd(LONGLONG& end)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		LONGLONG t_end;
		if (FAILED(hr = t_player->getStopPosition(t_end))) return E_FAIL;
		end = t_end;
		return S_OK;
	}
}

HRESULT CMManager::setStart(LONGLONG const start)  //not for playing
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		if (t_player->isStop() == TRUE)
			return t_player->setStartPosition(start); 
		else return E_FAIL;
	}
}

HRESULT CMManager::getStart(LONGLONG& start)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		LONGLONG t_start;
		if (FAILED(hr = t_player->getStartPosition(t_start))) return E_FAIL;
		start = t_start;
		return S_OK;
	}
}

HRESULT CMManager::getVolume(LONG& volume)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		LONG t_volume;
		if (FAILED(hr = t_player->getVolume(t_volume))) return E_FAIL;
		volume = t_volume;
		return S_OK;
	}
}

HRESULT CMManager::setVolume(LONG const volume)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->setVolume(volume);
	}
}

HRESULT CMManager::setWindowPosition(WINDOW_POS const pos)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->setWindowPosition(pos);
	}
}

HRESULT CMManager::getWindowPosition(WINDOW_POS& pos)
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		HRESULT hr;
		WINDOW_POS t_pos;
		if (FAILED(hr = t_player->getWindowPosition(t_pos))) return E_FAIL;
		pos = t_pos;
		return S_OK;
	}
}

HRESULT CMManager::setForeground()
{
	PlayerMap::iterator IT;
	IT = PlayerTable.find(curPlayerHandle);
	if (IT == PlayerTable.end()) return E_FAIL;
	else
	{
		CMMediaPlayer* t_player = (*IT).second;
		return t_player->setForeground();
	}
}



