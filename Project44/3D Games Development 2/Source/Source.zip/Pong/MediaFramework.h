#ifndef MEDIAFRAMEWORK_H
#define MEDIAFRAMEWORK_H

#include "CMediaEx.h"

#ifndef CMEDIA_H
struct WINDOW_POS
{
	long left;
	long top;
	long width;
	long height;
};

struct MEDIA_ROW
{
	TCHAR filename[MAX_PATH];
	LONG volume;
	double rate;
	LONGLONG start;
	LONGLONG end;
	WINDOW_POS pos;
};
#endif


namespace DM
{
int init(HWND const hwnd);
void cleanup();

int load(int const loadhd,int& playhd);
int unload(int const playhd);
int setCurrent(int const playhd);
int getCurrent(int& playhd);

int play();
int pause();
int stop();

int isPlay();
int isPause();
int isStop();
	
int getCurrentPosition(LONGLONG& pos);
int getStopPosition(LONGLONG& pos);

int setPlayRate(double const rate);
int getPlayRate(double& rate);
int setEnd(LONGLONG const end); //not for playing
int getEnd(LONGLONG& end);
int setStart(LONGLONG const start);  //not for playing
int getStart(LONGLONG& start);
int setVolume(LONG const volume);
int getVolume(LONG& volume);

int setWindowPosition(WINDOW_POS const pos);
int getWindowPosition(WINDOW_POS& pos);
int setForeground();

namespace Table
{
int add(MEDIA_ROW const row);
int add(TCHAR* filename);
int set(int const handle,MEDIA_ROW const row);
int get(int const handle,MEDIA_ROW& row);
int erase(int const handle);
}}
#endif