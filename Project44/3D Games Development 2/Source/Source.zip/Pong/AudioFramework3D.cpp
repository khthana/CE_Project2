#include <afxwin.h>
#include "AudioFramework.h"
#include "FrameworEss.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int DA::ThreeD::create(TCHAR* filename,int& handle)
{
	return FWUtils::HRESULT2INT(MainAudioFM->add3D(filename,handle));
}

int DA::ThreeD::duplicate(int const s_handle,int& t_handle)
{
	return FWUtils::HRESULT2INT(MainAudioFM->clone3D(s_handle,t_handle));
}

//extern int DAudio_duplicate3DSound(TCHAR* name,TCHAR* newsound,CA3DSoundAgent& agent);
int DA::ThreeD::destroy(int const handle)
{
	return FWUtils::HRESULT2INT(MainAudioFM->erase3D(handle));
}

int DA::ThreeD::check(int const handle)
{
	if (MainAudioFM->get3DSound(handle) != NULL) return 0;
	else return -1;
}

int	DA::ThreeD::Listener::setOrientation(D3DVECTOR const front,D3DVECTOR const top)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setOrientation(front,top));
}

int	DA::ThreeD::Listener::setOrientation(D3DVALUE const fx,D3DVALUE const fy,D3DVALUE const fz,D3DVALUE const tx,D3DVALUE const ty,D3DVALUE const tz)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setOrientation(fx,fy,fz,tx,ty,tz));
}

int	DA::ThreeD::Listener::getOrientation(D3DVECTOR& fort,D3DVECTOR& tort)
{
	return FWUtils::HRESULT2INT(MainAudioFM->getOrientation(fort,tort));
}

int	DA::ThreeD::Listener::setPosition(D3DVECTOR const pos)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setPosition(pos));
}

int	DA::ThreeD::Listener::setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setPosition(x,y,z));
}

int	DA::ThreeD::Listener::getPosition(D3DVECTOR& pos)
{
	return FWUtils::HRESULT2INT(MainAudioFM->getPosition(pos));
}

int	DA::ThreeD::Listener::setVelocity(D3DVECTOR const vel)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setVelocity(vel));
}

int	DA::ThreeD::Listener::setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setVelocity(x,y,z));
}

int	DA::ThreeD::Listener::getVelocity(D3DVECTOR& vel)
{
	return FWUtils::HRESULT2INT(MainAudioFM->getVelocity(vel));
}

int	DA::ThreeD::Listener::setDoppler(D3DVALUE const dop)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setDoppler(dop));
}

int	DA::ThreeD::Listener::getDoppler(D3DVALUE& dop)
{
	return FWUtils::HRESULT2INT(MainAudioFM->getDoppler(dop));
}

int	DA::ThreeD::Listener::setRolloff(D3DVALUE const rol)
{
	return FWUtils::HRESULT2INT(MainAudioFM->setRolloff(rol));
}

int	DA::ThreeD::Listener::getRolloff(D3DVALUE& rol)
{
	return FWUtils::HRESULT2INT(MainAudioFM->getRolloff(rol));
}

int DA::ThreeD::isPlay(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->isPlay());
}

int DA::ThreeD::getVolume(int const handle,LONG& vol)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	CAAudio* t_sound = MainAudioFM->get3DSound(handle);
	vol = t_sound->getVolume();
	return 0;
}

int DA::ThreeD::setVolume(int const handle,LONG const vol)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setVolume(vol));
}

void DA::ThreeD::play(int const handle)
{
	if (MainAudioFM->get3DSound(handle) != NULL)
	MainAudioFM->get3DSound(handle)->play();
}

void DA::ThreeD::stop(int const handle)
{
	if (MainAudioFM->get3DSound(handle) != NULL)
	MainAudioFM->get3DSound(handle)->stop();
}

int DA::ThreeD::load(int const handle,TCHAR* filename)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->load(filename));
}

int DA::ThreeD::setloop(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setloop());
}

int DA::ThreeD::setloop(int const handle,DWORD const loop)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setloop(loop));
}

int DA::ThreeD::resetloop(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->resetloop());
}

int DA::ThreeD::getloop(int const handle,DWORD& loop)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getloop(loop));
}

int DA::ThreeD::Effect::setChorus(int const handle,DSFXChorus const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setChorus(p));
}

int DA::ThreeD::Effect::setCompressor(int const handle,DSFXCompressor const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setCompressor(p));
}

int DA::ThreeD::Effect::setDistortion(int const handle,DSFXDistortion const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setDistortion(p));
}

int DA::ThreeD::Effect::setEcho(int const handle,DSFXEcho const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setEcho(p));
}

int DA::ThreeD::Effect::setFlanger(int const handle,DSFXFlanger const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setFlanger(p));
}

int DA::ThreeD::Effect::setGargle(int const handle,DSFXGargle const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setGargle(p));
}

int DA::ThreeD::Effect::setParameq(int const handle,DSFXParamEq const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setParameq(p));
}

int DA::ThreeD::Effect::setReverb(int const handle,DSFXWavesReverb const p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setReverb(p));
}



int DA::ThreeD::Effect::setChorus(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setChorus());
}

int DA::ThreeD::Effect::setCompressor(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setCompressor());
}

int DA::ThreeD::Effect::setDistortion(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setDistortion());
}

int DA::ThreeD::Effect::setEcho(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setEcho());
}

int DA::ThreeD::Effect::setFlanger(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setFlanger());
}

int DA::ThreeD::Effect::setGargle(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setGargle());
}

int DA::ThreeD::Effect::setParameq(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setParameq());
}

int DA::ThreeD::Effect::setReverb(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setReverb());
}

int DA::ThreeD::Effect::getChorus(int const handle,DSFXChorus& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getChorus(p));
}

int DA::ThreeD::Effect::getCompressor(int const handle,DSFXCompressor& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getCompressor(p));
}

int DA::ThreeD::Effect::getDistortion(int const handle,DSFXDistortion& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getDistortion(p));
}

int DA::ThreeD::Effect::getEcho(int const handle,DSFXEcho& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getEcho(p));
}

int DA::ThreeD::Effect::getFlanger(int const handle,DSFXFlanger& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getFlanger(p));
}

int DA::ThreeD::Effect::getGargle(int const handle,DSFXGargle& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getGargle(p));
}

int DA::ThreeD::Effect::getParameq(int const handle,DSFXParamEq& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getParameq(p));
}

int DA::ThreeD::Effect::getReverb(int const handle,DSFXWavesReverb& p)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getReverb(p));
}

int DA::ThreeD::Effect::isChorus(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isChorus() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isCompressor(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isCompressor() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isDistortion(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isDistortion() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isEcho(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isEcho() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isFlanger(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isFlanger() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isGargle(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isGargle() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isParameq(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isParameq() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isReverb(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isReverb() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Effect::isEffect(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isEffect() == TRUE) return 0;
	else return 1;
}


int DA::ThreeD::Effect::enableChorus(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableChorus());
}

int DA::ThreeD::Effect::enableCompressor(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableCompressor());
}

int DA::ThreeD::Effect::enableDistortion(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableDistortion());
}

int DA::ThreeD::Effect::enableEcho(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableEcho());
}

int DA::ThreeD::Effect::enableFlanger(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableFlanger());
}

int DA::ThreeD::Effect::enableGargle(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableGargle());
}

int DA::ThreeD::Effect::enableParameq(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableParameq());
}

int DA::ThreeD::Effect::enableReverb(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->enableReverb());
}


int DA::ThreeD::Effect::disableChorus(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableChorus());
}

int DA::ThreeD::Effect::disableCompressor(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableCompressor());
}

int DA::ThreeD::Effect::disableDistortion(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableDistortion());
}

int DA::ThreeD::Effect::disableEcho(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableEcho());
}

int DA::ThreeD::Effect::disableFlanger(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableFlanger());
}

int DA::ThreeD::Effect::disableGargle(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableGargle());
}

int DA::ThreeD::Effect::disableParameq(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableParameq());
}

int DA::ThreeD::Effect::disableReverb(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableReverb());
}

int DA::ThreeD::Effect::disableAllEffect(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->disableAllEffect());
}

int DA::ThreeD::Param3D::setMaxDistance(int const handle,D3DVALUE const maxDist)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setMaxDistance(maxDist));
}

int DA::ThreeD::Param3D::getMaxDistance(int const handle,D3DVALUE& maxDist)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getMaxDistance(maxDist));
}

int DA::ThreeD::Param3D::setMinDistance(int const handle,D3DVALUE const minDist)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setMinDistance(minDist));
}

int DA::ThreeD::Param3D::getMinDistance(int const handle,D3DVALUE& minDist)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getMinDistance(minDist));
}

int DA::ThreeD::Param3D::setPosition(int const handle,D3DVECTOR const pos)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setPosition(pos));
}

int DA::ThreeD::Param3D::setPosition(int const handle,D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setPosition(x,y,z));
}

int DA::ThreeD::Param3D::movePosition(int const handle,D3DVECTOR const pos)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->movePosition(pos));
}

int DA::ThreeD::Param3D::movePosition(int const handle,D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->movePosition(x,y,z));
}

int DA::ThreeD::Param3D::getPosition(int const handle,D3DVECTOR& pos)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getPosition(pos));
}

int DA::ThreeD::Param3D::setNormalMode(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setNormalMode());
}

int DA::ThreeD::Param3D::setRelativeMode(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setRelativeMode());
}

int DA::ThreeD::Param3D::isNormalMode(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isNormalMode() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Param3D::isRelativeMode(int const handle)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	if (MainAudioFM->get3DSound(handle)->isRelativeMode() == TRUE) return 0;
	else return 1;
}

int DA::ThreeD::Param3D::setVelocity(int const handle,D3DVECTOR const vel)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setVelocity(vel));
}

int DA::ThreeD::Param3D::setVelocity(int const handle,D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setVelocity(x,y,z));
}

int DA::ThreeD::Param3D::getVelocity(int const handle,D3DVECTOR& vel)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getVelocity(vel));
}

int DA::ThreeD::Param3D::setConeAngles(int const handle,DWORD const in,DWORD const out)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setConeAngles(in,out));
}

int DA::ThreeD::Param3D::setConeOrientation(int const handle,D3DVECTOR const ort)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setConeOrientation(ort));
}

int DA::ThreeD::Param3D::setConeOutsideVolume(int const handle,LONG const vol)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->setConeOutsideVolume(vol));
}

int DA::ThreeD::Param3D::getConeAngles(int const handle,DWORD& in,DWORD& out)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getConeAngles(in,out));
}

int DA::ThreeD::Param3D::getConeOrientation(int const handle,D3DVECTOR& ort)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getConeOrientation(ort));
}

int DA::ThreeD::Param3D::getConeOutsideVolume(int const handle,LONG& vol)
{
	if (MainAudioFM->get3DSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->get3DSound(handle)->getConeOutsideVolume(vol));
}
