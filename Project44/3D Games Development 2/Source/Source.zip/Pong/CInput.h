#ifndef CINPUT_H
#define CINPUT_H

#include <dinput.h>
//#include "CDynamicArray.h"
#include <vector>

using namespace std;

#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

#define MainInput CIManager::getCIM ()
#define MainEffect CIManager::getCIEM ()
#define GetJoystickCount() CIManager::getCIM()->getjoystickCount() 
#define GetMouseCount() CIManager::getCIM()->getmouseCount()
#define GetKeyboardCount() CIManager::getCIM()->getkeyboardCount()
#define GetEnumCount() CIManager::getCIM()->getenumCount()

#define SetJoystickCount(c) CIManager::getCIM()->setjoystickCount(c) 
#define SetMouseCount(c) CIManager::getCIM()->setmouseCount(c)
#define SetKeyboardCount(c) CIManager::getCIM()->setkeyboardCount(c)
#define SetEnumCount(c) CIManager::getCIM()->setenumCount(c)

class CIKeyboard;
class CINotKeyboard;
class CIMouse;
class CIJoystick;
class CIEffect;
class CIEffAgent;
class CIEffManager;

struct CIEFFECT_ROWS
{
    CIEffect* pCIEffect;
    TCHAR EffName[MAX_PATH] ;
};

class CIManager
{
public:
	CIManager();
	HRESULT init(HWND const hwnd);
	void cleanup();

	IDirectInput8* getDirectInput(){return g_pInput;};
	static CIManager* getCIM();//{return *CAM;};
	static CIEffManager* getCIEM();

    DWORD getjoystickCount() {return joystickCount;};
    DWORD getmouseCount(){return mouseCount;};
    DWORD getkeyboardCount(){return keyboardCount;};
	DWORD getenumCount() {return enumCount;};

	void setjoystickCount(DWORD count) {joystickCount = count;};
	void setmouseCount(DWORD count){mouseCount = count;};
	void setkeyboardCount(DWORD count){keyboardCount = count;};
	void setenumCount(DWORD count) {enumCount = count;};

	void addArrKeyboard(CIKeyboard* keyboard) {ArrKeyboard.push_back(keyboard);};
	void addArrMouse(CIMouse* mouse) {ArrMouse.push_back(mouse);};
	void addArrJoystick(CIJoystick* joystick) {ArrJoystick.push_back(joystick);};

	UINT getArrKeyboardSize() {return ArrKeyboard.size();};
	UINT getArrMouseSize() {return ArrMouse.size();};
	UINT getArrJoystickSize() {return ArrJoystick.size();};

	void clearArrKeyboard() {ArrKeyboard.clear();};
	void clearArrMouse() {ArrMouse.clear();};
	void clearArrJoystick() {ArrJoystick.clear();};

	CIKeyboard* toKeyboard(DWORD handle) {return ArrKeyboard[handle];};
	CIMouse* toMouse(DWORD handle) {return ArrMouse[handle];};
	CIJoystick* toJoystick(DWORD handle) {return ArrJoystick[handle];};

	void setHWND(HWND const hwnd) {m_hWnd = hwnd;};
	HWND getHWND() {return m_hWnd;};
private:	
	static CIManager* CIM;
	static CIEffManager* CIEM;
	IDirectInput8* g_pInput;

	DWORD joystickCount;
	DWORD mouseCount;
	DWORD keyboardCount;
	DWORD enumCount;

	//typedef CDynamicArray<CIKeyboard*> Arr_Keyboard;
	//typedef CDynamicArray<CIMouse*> Arr_Mouse;
	//typedef CDynamicArray<CIJoystick*> Arr_Joystick;
	typedef vector <CIKeyboard*> Arr_Keyboard;
	typedef vector <CIMouse*> Arr_Mouse;
	typedef vector <CIJoystick*> Arr_Joystick;

	Arr_Keyboard ArrKeyboard;
	Arr_Mouse ArrMouse;
	Arr_Joystick ArrJoystick;

	HWND m_hWnd;
};

class CIEffManager
{
public:
	CIEffManager();
	~CIEffManager();
	CIEffect* findCIEffect(TCHAR* name,UINT& index);
	HRESULT getCIEffectName(CIEffect* pEffect,TCHAR* name);

	UINT addCIEffectTable(TCHAR* name,CIEffect* const pCIEffect);
	UINT removeCIEffectTable(UINT const index);
	void clearCIEffectTable() {CIEffectTable.clear();};
	UINT getCIEffectTableSize() {return CIEffectTable.size();};

	HRESULT setCurEffect(TCHAR* name);
	CIEffect* getCurEffect() {return curEffect;};
private:
	CIEffect* curEffect;

	//typedef CDynamicArray<CIEFFECT_ROWS> Arr_CIEffect;
	typedef vector<CIEFFECT_ROWS> Arr_CIEffect;
	Arr_CIEffect CIEffectTable;
};

class CIDevice
{
public:
	CIDevice();
	HRESULT init();
	void cleanup();

	//pass
	HRESULT start();
	HRESULT stop();
	//pass

	//pass
	HRESULT getInfoGuidProduct(GUID& guidProduct);
	HRESULT getInfoGuidFFDriver(GUID& guidFFDriver);
	HRESULT getInfoInstanceName(TCHAR* tszInstanceName); 
    HRESULT getInfoProductName(TCHAR* tszProductName);
	
	HRESULT getInfoDeviceMainType(DWORD& manintype);
	HRESULT getInfoDeviceSubType(DWORD& subtype);
	HRESULT getInfoDeviceType(DWORD& type);
	//pass

	IDirectInputDevice8* getDevice() {return g_pDevice;};

	// pass
	BOOL isAttatch();
	BOOL isFFSupport();
	// pass

	//pass
	HRESULT setFFPause();
	HRESULT setFFContinue();
	HRESULT setFFStop();
	HRESULT setFFReset();
	HRESULT setFFActuatorsON();
	HRESULT setFFActuatorsOFF();

	HRESULT getFFPause();
	HRESULT getFFActuatorsON();
	HRESULT getFFActuatorsOFF();
	//pass

protected:
	//not pass
	HRESULT setFFFunction(DWORD const flag);
	HRESULT getFFFunction(DWORD const flag);
	//not pass

	static LPDIRECTINPUT8 getDirectInput();
	//static BOOL CALLBACK  EnumDeviceCallback(const DIDEVICEINSTANCE* pdidInstance,
    //                                    VOID* pContext );
	IDirectInputDevice8*  g_pDevice;
};

class CINotKeyboard:public CIDevice
{
public:
	//Joy and Mouse
	//pass
	HRESULT getInfoAxes(DWORD& numAxes);
	HRESULT getInfoPOVs(DWORD& numPOVs);
	HRESULT getInfoButtons(DWORD& numButtons);
	//pass

	//pass
	HRESULT setRange(LONG const range);
	HRESULT getRange(LONG& range);
	HRESULT setDeadZone(LONG const deadzone);
	HRESULT getDeadZone(LONG& deadzone);
	HRESULT setSaturation(LONG const saturation);
	HRESULT getSaturation(LONG& saturation);
	//pass
protected:


	//pass
	HRESULT turnAutocenterOFF();
	HRESULT turnAutocenterON();
	//pass
};

class CIKeyboard:public CIDevice
{	
public:
	//CIKeyboard();
	HRESULT init();
	void cleanup();

	HRESULT getState(BYTE* pBuffer); //[256]

protected:
	static BOOL CALLBACK  EnumKeyboardCallback(const DIDEVICEINSTANCE* pdidInstance,
                                        VOID* pContext );
};

class CIMouse:public CINotKeyboard
{
public:
	//CIMouse();
	HRESULT init();
	void cleanup();

	//HRESULT setRange(LONG const range);
	HRESULT setRangeX(LONG const range);
	HRESULT getRangeX(LONG& range);
	HRESULT setRangeY(LONG const range);
	HRESULT getRangeY(LONG& range);
	HRESULT setRangeZ(LONG const range);
	HRESULT getRangeZ(LONG& range);

	HRESULT getState(DIMOUSESTATE2 &buffer);

protected:
	static BOOL CALLBACK  EnumMouseCallback(const DIDEVICEINSTANCE* pdidInstance,
                                        VOID* pContext );
};

class CIJoystick:public CINotKeyboard
{
public:
	//CIJoystick();
	HRESULT init();
	void cleanup();

	HRESULT start();

	HRESULT setRangeX(LONG const range);
	HRESULT getRangeX(LONG& range);
	HRESULT setRangeY(LONG const range);
	HRESULT getRangeY(LONG& range);
	HRESULT setRangeZ(LONG const range);
	HRESULT getRangeZ(LONG& range);
	HRESULT setRangeRX(LONG const range);
	HRESULT getRangeRX(LONG& range);
	HRESULT setRangeRY(LONG const range);
	HRESULT getRangeRY(LONG& range);
	HRESULT setRangeRZ(LONG const range);
	HRESULT getRangeRZ(LONG& range);
	//pass

	HRESULT getState(DIJOYSTATE2 &buffer);

protected:
	static BOOL CALLBACK  EnumJoystickCallback(const DIDEVICEINSTANCE* pdidInstance,
                                        VOID* pContext );
};

struct EFFECTS_NODE
{
    LPDIRECTINPUTEFFECT pDIEffect;
    EFFECTS_NODE*       pNext;
};

class CIEffect
{
public:
	CIEffect();
	HRESULT init(CIDevice* const FFDevice,const TCHAR* filename);
	void cleanup();
	HRESULT play();

	HRESULT setloop();
	HRESULT setloop(DWORD const dloop);
	HRESULT resetloop();

	HRESULT isPlay();

	void removeAgent(CIEffAgent* const pToEffAgent);
	void addAgent(CIEffAgent* const pToEffAgent);
	BOOL findAgent(CIEffAgent* const pToEffAgent);
	void cleanupAgent();
protected:
	DWORD loop;
private:
	EFFECTS_NODE m_pEffectsList;

	static BOOL CALLBACK EnumEffectsCallback(LPCDIFILEEFFECT pDIFileEffect, VOID* pvRef );
	HRESULT ReadFile(CIDevice* const FFDevice,const TCHAR* filename);
	void EmptyEffectList();

	//typedef CDynamicArray<CIEffAgent*> Arr_EffAgent;
	typedef vector<CIEffAgent*> Arr_EffAgent;
	Arr_EffAgent ArrEffAgent;
};

class CIEffAgent
{
public:
	CIEffAgent();
	void cleanup();

	HRESULT play();
	HRESULT setloop();
	HRESULT setloop(DWORD const dloop);
	HRESULT resetloop();
	HRESULT isPlay();

	CIEffAgent* dupEffAgent();
	HRESULT getName(TCHAR* name);
	HRESULT settoCIEffect(TCHAR* name);
private:
	CIEffect* pCIEffect;
};

#endif