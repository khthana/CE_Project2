#include <afxwin.h>
#include "CAudio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CAManager* CAManager::CAM=NULL;
CAManager::	CAManager(){
	CAM=this;
	g_pLoader = NULL;
	g_pDS = NULL;
	g_pListener = NULL;
	pDSBPrimary = NULL;
};

CAManager *CAManager::getCAM()
{
	if(NULL==CAM){
		CAM=new CAManager();
	}
	return CAM;
}

HRESULT CA3daudio::setNormalMode ()
{
	if (g_p3DBuffer != NULL)
		return g_p3DBuffer->SetMode (DS3DMODE_NORMAL ,DS3D_IMMEDIATE );
	else
		return E_FAIL;
}

HRESULT CA3daudio::setRelativeMode ()
{
	if (g_p3DBuffer != NULL)
		return g_p3DBuffer->SetMode (DS3DMODE_HEADRELATIVE  ,DS3D_IMMEDIATE );
	else
		return E_FAIL;
}

HRESULT CA3daudio::setVelocity(D3DVECTOR const vel)
{
	if (g_p3DBuffer != NULL)	
		return g_p3DBuffer->SetVelocity(vel.x,vel.y,vel.z,DS3D_IMMEDIATE );
	else
		return E_FAIL;
}

HRESULT CA3daudio::setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (g_p3DBuffer != NULL)
		return g_p3DBuffer->SetVelocity(x,y,z,DS3D_IMMEDIATE );
	else
		return E_FAIL;
}

HRESULT CA3daudio::getVelocity (D3DVECTOR& vel)
{
	if (g_p3DBuffer != NULL)
		return g_p3DBuffer->GetVelocity(&vel);
	else
		return E_FAIL;
}

CAAudio::CAAudio()
{
	loadDefaultFX(eSFX_chorus);
    loadDefaultFX(eSFX_compressor);
    loadDefaultFX(eSFX_distortion);
    loadDefaultFX(eSFX_echo);
    loadDefaultFX(eSFX_flanger);
    loadDefaultFX(eSFX_gargle);
    loadDefaultFX(eSFX_parameq);
    loadDefaultFX(eSFX_reverb);

	g_pSegment = NULL;
	g_pAudioPath = NULL;
	g_pSoundBuffer = NULL;
	g_pPerformance = NULL;
	volume = 100;
	for (DWORD i=0;i<=eNUM_SFX -1;i++)
		g_pLoaded[i] = FALSE;
	strcpy(m_filename,"");
}

void CAAudio::cleanup ()
{
	loadDefaultFX(eSFX_chorus);
    loadDefaultFX(eSFX_compressor);
    loadDefaultFX(eSFX_distortion);
    loadDefaultFX(eSFX_echo);
    loadDefaultFX(eSFX_flanger);
    loadDefaultFX(eSFX_gargle);
    loadDefaultFX(eSFX_parameq);
    loadDefaultFX(eSFX_reverb);

	volume = 100;
	for (DWORD i=0;i<=eNUM_SFX -1;i++)
		g_pLoaded[i] = FALSE;
	strcpy(m_filename,"");

	if (g_pPerformance!=NULL)
		if ((g_pPerformance->IsPlaying(g_pSegment, NULL)) == S_OK)
			g_pPerformance->Stop( g_pSegment, NULL, 0, 0 );

	if ((g_pAudioPath != NULL) && (g_pSegment != NULL)) 
		g_pSegment->Unload( g_pAudioPath );


	SAFE_RELEASE(g_pSoundBuffer);
	SAFE_RELEASE(g_pSegment);
	SAFE_RELEASE(g_pAudioPath);

	if (g_pPerformance != NULL)
	{
    g_pPerformance->Stop( NULL, NULL, 0, 0 );
    g_pPerformance->CloseDown();
	SAFE_RELEASE(g_pPerformance);
	};
}

LONG CAAudio::getVolume()
{
	return volume;
}

HRESULT CAAudio::setVolume(LONG const vol)
{
	LONG t_vol = vol;
	if (vol > 100)
		{t_vol = 100;}
	else if (vol <0)
		{t_vol = 0;}

	HRESULT hr;
	if (g_pAudioPath !=NULL)
	{
		hr = g_pAudioPath->SetVolume(((t_vol * 96) - 9600),0);
		if (hr == S_OK)
		{
			volume = vol;
			return S_OK;
		}
		else return E_FAIL;
	}
	else
		return E_FAIL;
}

CA3daudio::CA3daudio()
{
	g_p3DBuffer = NULL;
}

void CA3daudio::cleanup ()
{
	SAFE_RELEASE(g_p3DBuffer);
	CAAudio::cleanup ();
}

HRESULT CAManager::init(HWND const hWnd)
{
	HRESULT hr;
    //CoInitialize(NULL);
	if( FAILED( hr = DirectSoundCreate8( NULL, &g_pDS, NULL ) ) )
        return E_FAIL;

    if( FAILED( hr = g_pDS->SetCooperativeLevel( hWnd, DSSCL_PRIORITY  ) ) )
	{
		MainAudio->cleanup();
        return E_FAIL;
	};

    if( g_pDS == NULL )
	{
		MainAudio->cleanup();
        return E_FAIL;
	};

    DSBUFFERDESC dsbd;
    ZeroMemory( &dsbd, sizeof(DSBUFFERDESC) );
    dsbd.dwSize        = sizeof(DSBUFFERDESC);
    dsbd.dwFlags       = DSBCAPS_CTRL3D | DSBCAPS_PRIMARYBUFFER;
    dsbd.dwBufferBytes = 0;
    dsbd.lpwfxFormat   = NULL;
       
    if( FAILED( hr = g_pDS->CreateSoundBuffer( &dsbd, &pDSBPrimary, NULL ) ) )
	{
		MainAudio->cleanup();
        return E_FAIL;
	};

    WAVEFORMATEX wfx;
    ZeroMemory( &wfx, sizeof(WAVEFORMATEX) ); 
    wfx.wFormatTag      = WAVE_FORMAT_PCM; 
    wfx.nChannels       = 2; 
    wfx.nSamplesPerSec  = 22050; 
    wfx.wBitsPerSample  = 16; 
    wfx.nBlockAlign     = wfx.wBitsPerSample / 8 * wfx.nChannels;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    if( FAILED( hr = pDSBPrimary->SetFormat(&wfx) ) )
	{
		MainAudio->cleanup();
        return E_FAIL;
	};
	
	CoCreateInstance(CLSID_DirectMusicLoader, NULL, 
                     CLSCTX_INPROC, IID_IDirectMusicLoader8,
                     (void**)&g_pLoader);
	if (g_pLoader != NULL)
	{
		//g_pLoader->EnableCache(CLSID_DirectSoundWave, FALSE);
		g_pLoader->EnableCache(CLSID_DirectMusicSegment, FALSE);
	}

	/*
	IDirectMusicPerformance8* g_pPerformance;
	IDirectMusicAudioPath8* pAudioPath;
	g_pPerformance = NULL;
	pAudioPath = NULL;
    CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, 
                     IID_IDirectMusicPerformance8, (LPVOID*) &g_pPerformance );
	
	if (g_pPerformance != NULL)
	{
	g_pPerformance->InitAudio( NULL, NULL, NULL, 
                               0, 64,
                               DMUS_AUDIOF_ALL, NULL );
	g_pPerformance->CreateStandardAudioPath( 
						    DMUS_APATH_DYNAMIC_3D ,      
							64,                         
							TRUE,                       
							&pAudioPath);            
	
	pDSBPrimary->QueryInterface(
	hr = pAudioPath->GetObjectInPath(0, DMUS_PATH_PRIMARY_BUFFER,
        0, GUID_All_Objects, 0, IID_IDirectSound3DListener,
        (void **)&g_pListener);

	SAFE_RELEASE(pAudioPath);
	SAFE_RELEASE(g_pPerformance);
	*/
	//pDSBPrimary->QueryInterface(
	if (FAILED(hr = pDSBPrimary->QueryInterface(IID_IDirectSound3DListener8,(LPVOID *)&g_pListener)))
	{
		pDSBPrimary->Release();
	}


	if (hr == S_OK)
		return S_OK;
	//else
	//	return E_FAIL;
	//}
	else 
	{
		//SAFE_RELEASE(pAudioPath);
		//SAFE_RELEASE(g_pPerformance);
		MainAudio->cleanup();
		return E_FAIL;
	};
}

void CAManager::cleanup()
{
	SAFE_RELEASE(g_pListener);
	SAFE_RELEASE(g_pLoader);
	SAFE_RELEASE(pDSBPrimary);
	SAFE_RELEASE(g_pDS);
	SAFE_DELETE(CAM);
    //CoUninitialize();
}

HRESULT CAManager::setOrientation(D3DVECTOR const front,D3DVECTOR const top)
{
	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr = g_pListener->SetOrientation(front.x,front.y,front.z,top.x,top.y,top.z,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::setOrientation(D3DVALUE const fx,D3DVALUE const fy,D3DVALUE const fz,D3DVALUE const tx,D3DVALUE const ty,D3DVALUE const tz)
{
	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr = g_pListener->SetOrientation(fx,fy,fz,tx,ty,tz,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::getOrientation(D3DVECTOR& fort,D3DVECTOR& tort)
{
	if (g_pListener != NULL)
		return g_pListener->GetOrientation(&fort,&tort);
	else
		return E_FAIL;
}

HRESULT CAManager::setPosition(D3DVECTOR const pos)
{
	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr = g_pListener->SetPosition(pos.x,pos.y,pos.z,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr = g_pListener->SetPosition(x,y,z,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::getPosition(D3DVECTOR& pos)
{
	if (g_pListener != NULL)
		return g_pListener->GetPosition(&pos);
	else
		return E_FAIL;
}

HRESULT CAManager::setVelocity(D3DVECTOR const vel)
{
	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr = g_pListener->SetPosition(vel.x,vel.y,vel.z,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr = g_pListener->SetPosition(x,y,z,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::getVelocity(D3DVECTOR& vel)
{
	if (g_pListener != NULL)
		return g_pListener->GetPosition(&vel);
	else
		return E_FAIL;
}

HRESULT CAManager::setDoppler(D3DVALUE const dop)
{
	D3DVALUE tmpdop;
	if (dop > 10)
		{tmpdop = 10;}
	else if (dop < 0)
		{tmpdop =0;}
	else tmpdop = dop;

	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr =  g_pListener->SetDopplerFactor(tmpdop,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::getDoppler(D3DVALUE& dop)
{
	if (g_pListener != NULL)
		return g_pListener->GetDopplerFactor(&dop);
	else
		return E_FAIL;
}

HRESULT CAManager::setRolloff(D3DVALUE const rol)
{
	D3DVALUE tmprol;
	if (rol > 10)
		{tmprol = 10;}
	else if (rol < 0)
		{tmprol = 0;}
	else tmprol = rol;

	if (g_pListener != NULL)
	{
		HRESULT hr;
		hr =  g_pListener->SetRolloffFactor(tmprol,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CAManager::getRolloff(D3DVALUE& rol)
{
	if (g_pListener != NULL)
		return g_pListener->GetRolloffFactor(&rol);
	else
		return E_FAIL;
}

HRESULT CAAudio::init ()
{
	HRESULT hr;
    CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, 
                      IID_IDirectMusicPerformance8, (LPVOID*) &g_pPerformance );

	if (g_pPerformance != NULL)
		g_pPerformance->InitAudio( NULL, NULL, NULL, 
                               0, 64,
                               DMUS_AUDIOF_ALL, NULL );
	
	if (g_pPerformance)
	{
	g_pPerformance->CreateStandardAudioPath( 
    DMUS_APATH_SHARED_STEREOPLUSREVERB ,      
    64,                         
    TRUE,                       
    &g_pAudioPath);            
	};

	if (g_pAudioPath != NULL)
	{
		if (FAILED(hr = g_pAudioPath->GetObjectInPath(DMUS_PCHANNEL_ALL,DMUS_PATH_BUFFER 
										,0,GUID_NULL,0,IID_IDirectSoundBuffer8
										,(LPVOID*) &g_pSoundBuffer )))
			return E_FAIL;
		else
		{
			g_pAudioPath->SetVolume(0,0);
			return S_OK;
		};
	}
	else return E_FAIL;
}

HRESULT CA3daudio::init ()
{
	HRESULT hr;
    CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, 
                      IID_IDirectMusicPerformance8, (LPVOID*) &g_pPerformance );

	if (g_pPerformance != NULL)
		g_pPerformance->InitAudio( NULL, NULL, NULL, 
                               0, 64,
                               DMUS_AUDIOF_ALL, NULL );
	
	if (g_pPerformance != NULL)
	{
	g_pPerformance->CreateStandardAudioPath( 
    DMUS_APATH_DYNAMIC_3D ,      
    64,                         
    TRUE,                       
    &g_pAudioPath);            
	};

	if (g_pAudioPath != NULL)
	{
		if (FAILED(hr = g_pAudioPath->GetObjectInPath(DMUS_PCHANNEL_ALL,DMUS_PATH_BUFFER 
										,0,GUID_NULL,0,IID_IDirectSoundBuffer8
										,(LPVOID*) &g_pSoundBuffer )))
			return E_FAIL;
		else
		{
			hr = g_pAudioPath->GetObjectInPath( 0, DMUS_PATH_BUFFER, 0,
                                            GUID_NULL, 0, IID_IDirectSound3DBuffer, 
                                           (LPVOID*) &g_p3DBuffer );
			if (hr != S_OK)
				return E_FAIL;
			else
			{
				g_pAudioPath->SetVolume(0,0);
				setNormalMode();
				return S_OK;
			}
		};
	}
	else return E_FAIL;
}

HRESULT CAAudio::load (TCHAR* const filename)
{
	HRESULT               hr;
	if (g_pAudioPath != NULL)
	{
		if (MainAudio->getLoader() != NULL) //g_pLoader != NULL)
		{

		WCHAR wstrFilename[MAX_PATH];
		MultiByteToWideChar( CP_ACP, 0, filename, -1, 
                         wstrFilename, MAX_PATH );
 
		hr = MainAudio->getLoader()->LoadObjectFromFile( CLSID_DirectMusicSegment,
                                                     IID_IDirectMusicSegment8,
                                                     wstrFilename,
													 (LPVOID*)  &g_pSegment );
		if (hr != S_OK) return E_FAIL;
		};
		
		if (g_pSegment != NULL) 
		{
			hr = g_pSegment->Download(g_pAudioPath);
			if (hr != S_OK) 
				return E_FAIL;
			else 
			{
				strcpy(m_filename,filename);
				return S_OK;
			}
		}
		else return E_FAIL;
	}
	else return E_FAIL;
}

HRESULT CAAudio::setloop()
{
	if( g_pSegment == NULL )
        return E_FAIL;;
	return g_pSegment->SetRepeats( DMUS_SEG_REPEAT_INFINITE );
}

HRESULT CAAudio::setloop(DWORD const loop)
{
	if( g_pSegment == NULL )
        return E_FAIL;;
	return g_pSegment->SetRepeats( loop );
}

HRESULT CAAudio::resetloop()
{
	if( g_pSegment == NULL )
        return CO_E_NOTINITIALIZED;
	return g_pSegment->SetRepeats(0);
}

void CAAudio::play ()
{
    HRESULT hr;
	if( g_pSegment != NULL && g_pPerformance != NULL )
        hr = g_pPerformance->PlaySegmentEx( g_pSegment, NULL,NULL, 
                                          DMUS_SEGF_USE_AUDIOPATH , 0, NULL, g_pAudioPath, g_pAudioPath );
	//g_pSoundBuffer->Play(0,0,DSBPLAY_LOOPING );
}

void CAAudio::stop ()
{
    if( g_pSegment != NULL && g_pPerformance != NULL )
		g_pPerformance->Stop( g_pSegment, NULL, 0, 0 );
	//g_pSoundBuffer->Stop();
}

HRESULT CAAudio::isPlay ()
{
	if (g_pPerformance!=NULL)
	{
		return g_pPerformance->IsPlaying(g_pSegment, NULL);
	}
	else
		return E_FAIL;
}

HRESULT CA3daudio::setMaxDistance(D3DVALUE const maxDist)
{
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->SetMaxDistance (maxDist,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::getMaxDistance(D3DVALUE& maxDist)
{
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->GetMaxDistance(&maxDist);
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::setMinDistance(D3DVALUE const maxDist)
{
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->SetMinDistance (maxDist,DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::getMinDistance(D3DVALUE& minDist)
{
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->GetMinDistance(&minDist);
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::setPosition(D3DVECTOR const pos)
{
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->SetPosition(pos.x ,pos.y ,pos.z, DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->SetPosition(x ,y ,z, DS3D_IMMEDIATE );
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::getPosition(D3DVECTOR& Vt)
{
	if (g_p3DBuffer != NULL)
		return g_p3DBuffer->GetPosition(&Vt);
	else
		return E_FAIL;
}

HRESULT CA3daudio::movePosition(D3DVECTOR const pos)
{
	D3DVECTOR tmpVt;
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->GetPosition(&tmpVt );
		if (hr == S_OK)
		{
			hr = g_p3DBuffer->SetPosition(pos.x+tmpVt.x ,pos.y +tmpVt.y,pos.z+tmpVt.z, DS3D_IMMEDIATE );
			return hr;
		}
		else return E_FAIL;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::movePosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z)
{
	D3DVECTOR tmpVt;
	if (g_p3DBuffer != NULL)
	{
		HRESULT hr;
		hr = g_p3DBuffer->GetPosition(&tmpVt );
		if (hr == S_OK)
		{
			hr = g_p3DBuffer->SetPosition(x+tmpVt.x ,y+tmpVt.y ,z+tmpVt.z, DS3D_IMMEDIATE );
			return hr;
		}
		else return E_FAIL;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::setConeAngles(DWORD const in,DWORD const out)
{
	if (g_p3DBuffer != NULL)
	{
		return g_p3DBuffer->SetConeAngles(in,out,DS3D_IMMEDIATE);
	}
	else return E_FAIL;
}

HRESULT CA3daudio::getConeAngles(DWORD& in,DWORD& out)
{
	HRESULT hr;
	//LPDWORD t_in,t_out;
	if (g_p3DBuffer != NULL)
	{
		hr = g_p3DBuffer->GetConeAngles(&in,&out);
		return hr;
	}
	else return E_FAIL;
}

HRESULT CA3daudio::setConeOrientation(D3DVECTOR const ort)
{
	if (g_p3DBuffer != NULL)
	{
		return g_p3DBuffer->SetConeOrientation(ort.x,ort.y,ort.z,DS3D_IMMEDIATE);
	}
	else return E_FAIL;
}

HRESULT CA3daudio::getConeOrientation(D3DVECTOR& ort)
{
	if (g_p3DBuffer != NULL)
	{
		return g_p3DBuffer->GetConeOrientation(&ort);
	}
	else return E_FAIL;
}

HRESULT CA3daudio::setConeOutsideVolume(LONG const vol)
{
	if (g_p3DBuffer != NULL)
	{
		return g_p3DBuffer->SetConeOutsideVolume(vol,DS3D_IMMEDIATE);
	}
	else return E_FAIL;
}

HRESULT CA3daudio::getConeOutsideVolume(LONG& vol)
{
	HRESULT hr;
	if (g_p3DBuffer != NULL)
	{
		hr = g_p3DBuffer->GetConeOutsideVolume(&vol);
		return hr;
	}
	else return E_FAIL;
}

void CAAudio::clearFXData ()
{
    for (DWORD i=0;i<eNUM_SFX;i++)
	{
		g_pLoaded[i] = FALSE;
	}
}

void CAAudio::genDescFX (DSEFFECTDESC* dsEffect)
{
	DWORD k = 0;
	for (DWORD i=0;i<eNUM_SFX;i++)
	{
		if (g_pLoaded[i] == TRUE)
			{
				dsEffect[k].dwSize = sizeof(DSEFFECTDESC);
				dsEffect[k].dwFlags = 0;
				dsEffect[k].dwReserved1 = 0;
				dsEffect[k].dwReserved2 = 0;
				switch(i)
				{
				case eSFX_chorus:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_CHORUS;break;
				case eSFX_compressor:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_COMPRESSOR;break;
				case eSFX_distortion:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_DISTORTION;break;				
				case eSFX_echo:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_ECHO;break;				
				case eSFX_flanger:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_FLANGER;break;				
				case eSFX_gargle:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_GARGLE;break;				
				case eSFX_parameq:
					dsEffect[k].guidDSFXClass = GUID_DSFX_STANDARD_PARAMEQ;break;
				case eSFX_reverb:
					dsEffect[k].guidDSFXClass = GUID_DSFX_WAVES_REVERB;break;
				}
				k++;
			}
	}
}

DWORD CAAudio::checkFXNum()
{
	DWORD k=0;
	for (DWORD i=0;i<eNUM_SFX;i++)
	{
		if (g_pLoaded[i] == TRUE) k++;
	}
	return k;
}

HRESULT CAAudio::setFX()
{
	DSEFFECTDESC dsEffect[eNUM_SFX];
	DWORD dwResults[eNUM_SFX];
	DWORD fxNum;
	HRESULT hr;

	if (g_pAudioPath !=NULL)
	{
	g_pAudioPath->Activate(FALSE);
	if (g_pSoundBuffer != NULL)
			{
				genDescFX(dsEffect);
				fxNum = checkFXNum();
				if (fxNum != 0)
				{
				if ((FAILED(hr = (g_pSoundBuffer->SetFX(fxNum,&dsEffect[0],&dwResults[0])))))
				{
					g_pAudioPath->Activate(TRUE);
					return E_FAIL;
				}
				else
				{
					g_pAudioPath->Activate(TRUE);
					return S_OK;
				}
				}
				else
				{
					if ((FAILED(hr = (g_pSoundBuffer->SetFX(0,NULL,NULL)))))
					{
						g_pAudioPath->Activate(TRUE);
						return E_FAIL;
					}
					else
					{
						g_pAudioPath->Activate(TRUE);
						return S_OK;
					}
				}
			}
	else return E_FAIL;
	}
	else return E_FAIL;
}

void CAAudio::loadDefaultFX (ESFXType const FXType)
{
	switch(FXType)
		{
		case eSFX_chorus:
			m_paramsChorus.fWetDryMix = 50;
			m_paramsChorus.fDepth = 10;
			m_paramsChorus.fFeedback = 25;
			m_paramsChorus.fFrequency = float(1.1);
			m_paramsChorus.lWaveform = 1;
			m_paramsChorus.fDelay = 0;
			m_paramsChorus.lPhase = 3;
			break;
		case eSFX_compressor:
			m_paramsCompressor.fGain = 0;
			m_paramsCompressor.fAttack = 10;
			m_paramsCompressor.fRelease = 200;
			m_paramsCompressor.fThreshold = -20;
			m_paramsCompressor.fRatio = 3;
			m_paramsCompressor.fPredelay = 4;
			break;
		case eSFX_distortion:
			m_paramsDistortion.fGain = -18;
			m_paramsDistortion.fEdge = 15;
			m_paramsDistortion.fPostEQCenterFrequency = 2400;
			m_paramsDistortion.fPostEQBandwidth = 2400;
			m_paramsDistortion.fPreLowpassCutoff = 7350;
			break;				
		case eSFX_echo:
			m_paramsEcho.fWetDryMix = 50;
			m_paramsEcho.fFeedback = 50;
			m_paramsEcho.fLeftDelay = 500;
			m_paramsEcho.fRightDelay = 500;
			m_paramsEcho.lPanDelay = 0;
			break;				
		case eSFX_flanger:
			m_paramsFlanger.fWetDryMix  = 50;
			m_paramsFlanger.fDepth = 100;
			m_paramsFlanger.fFeedback = -50;
			m_paramsFlanger.fFrequency = 0.25;
			m_paramsFlanger.lWaveform = 1;
			m_paramsFlanger.fDelay = 2;
			m_paramsFlanger.lPhase = 2;
			break;				
		case eSFX_gargle:
			m_paramsGargle.dwRateHz = 20;
			m_paramsGargle.dwWaveShape = 0;
			break;				
		case eSFX_parameq:
			m_paramsParamEq.fCenter = 7350 ;
			m_paramsParamEq.fBandwidth = 12 ;
			m_paramsParamEq.fGain = 0;
			break;
		case eSFX_reverb:
			m_paramsReverb.fInGain = 0;
			m_paramsReverb.fReverbMix = 0;
			m_paramsReverb.fReverbTime = 1000;
			m_paramsReverb.fHighFreqRTRatio = float(0.001);
			break;
		}
}

DWORD CAAudio::checkFXOrder(ESFXType const FXType)
{
	DWORD MaxCount=0;
	DWORD Count=0;
	MaxCount=FXType;
	for (DWORD i=1;i<=MaxCount;i++)
	{
		if (g_pLoaded[i] == TRUE)
		{
			Count++;
		}
	}
	return Count;
}

HRESULT	CAAudio::setParamFX(ESFXType const FXType)
{
	HRESULT hr;
	IDirectSoundFXChorus8*			fxChorus= NULL;
	IDirectSoundFXCompressor8*		fxCompressor = NULL;
	IDirectSoundFXDistortion8*		fxDistortion = NULL;
	IDirectSoundFXEcho8*			fxEcho = NULL;
	IDirectSoundFXFlanger8*			fxFlanger = NULL;
	IDirectSoundFXGargle8*			fxGargle = NULL;
	IDirectSoundFXParamEq8*			fxParameq = NULL;
	IDirectSoundFXWavesReverb8*		fxReverb = NULL;
	
	DWORD order=0;
	order = checkFXOrder(FXType);

	if (g_pSoundBuffer != NULL)
	{
	switch(FXType)
		{
		case eSFX_chorus:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXChorus8,(LPVOID*) &fxChorus)))
				return E_FAIL;
			else
			{
				hr = fxChorus->SetAllParameters(&m_paramsChorus);
			}
			break;
		case eSFX_compressor:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXCompressor8,(LPVOID*) &fxCompressor)))
				return E_FAIL;
			else
			{
				hr = fxCompressor->SetAllParameters(&m_paramsCompressor);
			}
			break;
		case eSFX_distortion:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXDistortion8,(LPVOID*) &fxDistortion)))
				return E_FAIL;
			else
			{
				hr = fxDistortion->SetAllParameters(&m_paramsDistortion);
			}
			break;				
		case eSFX_echo:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXEcho8,(LPVOID*) &fxEcho)))
				return E_FAIL;
			else
			{
				hr = fxEcho->SetAllParameters(&m_paramsEcho);
			}
			break;				
		case eSFX_flanger:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXFlanger8,(LPVOID*) &fxFlanger)))
				return E_FAIL;
			else
			{
				hr = fxFlanger->SetAllParameters(&m_paramsFlanger);
				SAFE_RELEASE(fxFlanger);
			}
			break;				
		case eSFX_gargle:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXGargle8,(LPVOID*) &fxGargle)))
				return E_FAIL;
			else
			{
				hr = fxGargle->SetAllParameters(&m_paramsGargle);
			}
			break;				
		case eSFX_parameq:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXParamEq8,(LPVOID*) &fxParameq)))
				return E_FAIL;
			else
			{
				hr = fxParameq->SetAllParameters(&m_paramsParamEq);
			}
			break;
		case eSFX_reverb:
			if (FAILED(hr = g_pSoundBuffer->GetObjectInPath(GUID_All_Objects,
					       order,
						   IID_IDirectSoundFXWavesReverb8,(LPVOID*) &fxReverb)))
				return E_FAIL;
			else
			{
				hr = fxReverb->SetAllParameters(&m_paramsReverb);
			}
			break;
		}
	};
	SAFE_RELEASE(fxChorus);
	SAFE_RELEASE(fxCompressor);
	SAFE_RELEASE(fxDistortion);
	SAFE_RELEASE(fxEcho);
	SAFE_RELEASE(fxGargle);
	SAFE_RELEASE(fxParameq);
	SAFE_RELEASE(fxReverb);
	return hr;
}

HRESULT CAAudio:: setChorus()
{
    DSFXChorus                  temp_paramsChorus;
	HRESULT hr;
	temp_paramsChorus = m_paramsChorus;
	loadDefaultFX(eSFX_chorus);
	if (FAILED(hr = setParamFX(eSFX_chorus))) m_paramsChorus = temp_paramsChorus;
	return hr;
}

HRESULT CAAudio::enableChorus()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_chorus];
	g_pLoaded[eSFX_chorus] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_chorus] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setCompressor()
{
    DSFXCompressor                temp_paramsCompressor;
	HRESULT hr;
	temp_paramsCompressor = m_paramsCompressor;
	loadDefaultFX(eSFX_compressor);
	if (FAILED(hr = setParamFX(eSFX_compressor))) m_paramsCompressor = temp_paramsCompressor;
	return hr;
}

HRESULT CAAudio::enableCompressor()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_compressor];
	g_pLoaded[eSFX_compressor] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_compressor] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setDistortion()
{
    DSFXDistortion                  temp_paramsDistortion;
	HRESULT hr;
	temp_paramsDistortion = m_paramsDistortion;
	loadDefaultFX(eSFX_distortion);
	if (FAILED(hr = setParamFX(eSFX_distortion))) m_paramsDistortion = temp_paramsDistortion;
	return hr;
}

HRESULT CAAudio::enableDistortion()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_distortion];
	g_pLoaded[eSFX_distortion] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_distortion] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setEcho()
{
    DSFXEcho                  temp_paramsEcho;
	HRESULT hr;
	temp_paramsEcho = m_paramsEcho;
	loadDefaultFX(eSFX_echo);
	if (FAILED(hr = setParamFX(eSFX_echo))) m_paramsEcho = temp_paramsEcho;
	return hr;
}

HRESULT CAAudio::enableEcho()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_echo];
	g_pLoaded[eSFX_echo] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_echo] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setFlanger()
{
    DSFXFlanger                  temp_paramsFlanger;
	HRESULT hr;
	temp_paramsFlanger = m_paramsFlanger;
	loadDefaultFX(eSFX_flanger);
	if (FAILED(hr = setParamFX(eSFX_flanger))) m_paramsFlanger = temp_paramsFlanger;
	return hr;
}

HRESULT CAAudio::enableFlanger()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_flanger];
	g_pLoaded[eSFX_flanger] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_flanger] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setGargle()
{
    DSFXGargle                  temp_paramsGargle;
	HRESULT hr;
	temp_paramsGargle = m_paramsGargle;
	loadDefaultFX(eSFX_gargle);
	if (FAILED(hr = setParamFX(eSFX_gargle))) m_paramsGargle = temp_paramsGargle;
	return hr;
}

HRESULT CAAudio::enableGargle()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_gargle];
	g_pLoaded[eSFX_gargle] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_gargle] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setParameq()
{
    DSFXParamEq                  temp_paramsParamEq;
	HRESULT hr;
	temp_paramsParamEq = m_paramsParamEq;
	loadDefaultFX(eSFX_parameq);
	if (FAILED(hr = setParamFX(eSFX_parameq))) m_paramsParamEq = temp_paramsParamEq;
	return hr;
}

HRESULT CAAudio::enableParameq()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_parameq];
	g_pLoaded[eSFX_parameq] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_parameq] = tempLoaded;
	return hr;
}

HRESULT CAAudio:: setReverb()
{
    DSFXWavesReverb             temp_paramsReverb;
	HRESULT hr;
	temp_paramsReverb = m_paramsReverb;
	loadDefaultFX(eSFX_reverb);
	if (FAILED(hr = setParamFX(eSFX_reverb))) m_paramsReverb = temp_paramsReverb;
	return hr;
}

HRESULT CAAudio::enableReverb()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_reverb];
	g_pLoaded[eSFX_reverb] = TRUE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_reverb] = tempLoaded;
	return hr;
}

BOOL CAAudio::isEffect ()
{
	for (DWORD i=0;i <= eNUM_SFX-1;i++)
	{
		if (g_pLoaded[i] = TRUE)
		{
			return TRUE;
		}
	}
	return FALSE;
}

HRESULT CAAudio::setChorus(DSFXChorus const paramsChorus)
{
	HRESULT hr;
    DSFXChorus                  temp_paramsChorus;
	temp_paramsChorus = m_paramsChorus;
	m_paramsChorus = paramsChorus;
	if (FAILED(hr = setParamFX(eSFX_chorus))) m_paramsChorus = temp_paramsChorus;
	return hr;
}

HRESULT CAAudio::setCompressor(DSFXCompressor const paramsCompressor)
{
	HRESULT hr;
    DSFXCompressor                  temp_paramsCompressor;
	temp_paramsCompressor = m_paramsCompressor;
	m_paramsCompressor = paramsCompressor;
	if (FAILED(hr = setParamFX(eSFX_compressor))) m_paramsCompressor = temp_paramsCompressor;
	return hr;
}

HRESULT CAAudio::setDistortion(DSFXDistortion const paramsDistortion)
{
	HRESULT hr;
    DSFXDistortion                  temp_paramsDistortion;
	temp_paramsDistortion = m_paramsDistortion;
	m_paramsDistortion = paramsDistortion;
	if (FAILED(hr = setParamFX(eSFX_distortion))) m_paramsDistortion = temp_paramsDistortion;
	return hr;
}

HRESULT CAAudio::setEcho(DSFXEcho const paramsEcho)
{
	HRESULT hr;
    DSFXEcho                  temp_paramsEcho;
	temp_paramsEcho = m_paramsEcho;
	m_paramsEcho = paramsEcho;
	if (FAILED(hr = setParamFX(eSFX_echo))) m_paramsEcho = temp_paramsEcho;
	return hr;
}

HRESULT CAAudio::setFlanger(DSFXFlanger const paramsFlanger)
{
	HRESULT hr;
    DSFXFlanger                  temp_paramsFlanger;
	temp_paramsFlanger = m_paramsFlanger;
	m_paramsFlanger = paramsFlanger;
	if (FAILED(hr = setParamFX(eSFX_flanger))) m_paramsFlanger = temp_paramsFlanger;
	return hr;
}

HRESULT CAAudio::setGargle(DSFXGargle const paramsGargle)
{
	HRESULT hr;
    DSFXGargle                  temp_paramsGargle;
	temp_paramsGargle = m_paramsGargle;
	m_paramsGargle = paramsGargle;
	if (FAILED(hr = setParamFX(eSFX_gargle))) m_paramsGargle = temp_paramsGargle;
	return hr;
}

HRESULT CAAudio::setParameq(DSFXParamEq const paramsParamEq)
{
	HRESULT hr;
    DSFXParamEq                  temp_paramsParamEq;
	temp_paramsParamEq = m_paramsParamEq;
	m_paramsParamEq = paramsParamEq;
	if (FAILED(hr = setParamFX(eSFX_parameq))) m_paramsParamEq = temp_paramsParamEq;
	return hr;
}

HRESULT CAAudio::setReverb(DSFXWavesReverb const paramsReverb)
{
	HRESULT hr;
    DSFXWavesReverb             temp_paramsReverb;
	temp_paramsReverb = m_paramsReverb;
	m_paramsReverb = paramsReverb;
	if (FAILED(hr = setParamFX(eSFX_reverb))) m_paramsReverb = temp_paramsReverb;
	return hr;
}

HRESULT CAAudio::disableChorus()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_chorus];
	g_pLoaded[eSFX_chorus] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_chorus] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableCompressor()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_compressor];
	g_pLoaded[eSFX_compressor] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_compressor] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableDistortion()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_distortion];
	g_pLoaded[eSFX_distortion] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_distortion] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableEcho()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_echo];
	g_pLoaded[eSFX_echo] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_echo] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableFlanger()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_flanger];
	g_pLoaded[eSFX_flanger] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_flanger] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableGargle()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_gargle];
	g_pLoaded[eSFX_gargle] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_gargle] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableParameq()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_parameq];
	g_pLoaded[eSFX_parameq] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_parameq] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableReverb()
{
	HRESULT hr;
	BOOL tempLoaded;
	tempLoaded = g_pLoaded[eSFX_reverb];
	g_pLoaded[eSFX_reverb] = FALSE;
	if (FAILED(hr = setFX())) g_pLoaded[eSFX_reverb] = tempLoaded;
	return hr;
}

HRESULT CAAudio::disableAllEffect()
{
	HRESULT hr;
	if (g_pAudioPath !=NULL)
	{
	g_pAudioPath->Activate(FALSE);
	if (g_pSoundBuffer != NULL)
			{
				if ((FAILED(hr = (g_pSoundBuffer->SetFX(0,NULL,NULL)))))
				{
					g_pAudioPath->Activate(TRUE);
					return E_FAIL;
				}
				else
				{
					g_pLoaded[eSFX_chorus] = FALSE;
					g_pLoaded[eSFX_compressor] = FALSE;
					g_pLoaded[eSFX_distortion] = FALSE;
					g_pLoaded[eSFX_echo] = FALSE;
					g_pLoaded[eSFX_flanger] = FALSE;
					g_pLoaded[eSFX_gargle] = FALSE;
					g_pLoaded[eSFX_parameq] = FALSE;
					g_pLoaded[eSFX_reverb] = FALSE;
					g_pAudioPath->Activate(TRUE);
					return S_OK;
				}
			}
	else return E_FAIL;
	}
	else return E_FAIL;
}

HRESULT CAAudio::getChorus(DSFXChorus& paramsChorus)
{
	if (isChorus() == FALSE) return E_FAIL;
	paramsChorus = m_paramsChorus;
	return S_OK;
}

HRESULT CAAudio::getCompressor(DSFXCompressor& paramsCompressor)
{
	if (isCompressor() == FALSE) return E_FAIL;
	paramsCompressor = m_paramsCompressor;
	return S_OK;
}

HRESULT CAAudio::getDistortion(DSFXDistortion& paramsDistortion)
{
	if (isDistortion() == FALSE) return E_FAIL;
	paramsDistortion = m_paramsDistortion;
	return S_OK;
}

HRESULT CAAudio::getEcho(DSFXEcho& paramsEcho)
{
	if (isEcho() == FALSE) return E_FAIL;
	paramsEcho = m_paramsEcho;
	return S_OK;
}

HRESULT CAAudio::getFlanger(DSFXFlanger& paramsFlanger)
{
	if (isFlanger() == FALSE) return E_FAIL;
	paramsFlanger = m_paramsFlanger;
	return S_OK;
}

HRESULT CAAudio::getGargle(DSFXGargle& paramsGargle)
{
	if (isGargle() == FALSE) return E_FAIL;
	paramsGargle = m_paramsGargle;
	return S_OK;
}

HRESULT CAAudio::getParameq(DSFXParamEq& paramsParamEq)
{
	if (isParameq() == FALSE) return E_FAIL;
	paramsParamEq = m_paramsParamEq;
	return S_OK;
}

HRESULT CAAudio::getReverb(DSFXWavesReverb& paramsReverb)	
{
	if (isReverb() == FALSE) return E_FAIL;
	paramsReverb = m_paramsReverb;
	return S_OK;
}

HRESULT CAAudio::getloop(DWORD& loop)
{
	HRESULT hr;
	DWORD t_loop;
	if( g_pSegment == NULL )
        return E_FAIL;
	hr = g_pSegment->GetRepeats(&t_loop);
	loop = t_loop;
	return hr;
}

CAAudio::CAAudio(const CAAudio& a)
{
	HRESULT hr;
	volume = a.volume;
	m_paramsChorus = a.m_paramsChorus;
    m_paramsCompressor = a.m_paramsCompressor;
    m_paramsDistortion = a.m_paramsDistortion;
    m_paramsEcho = a.m_paramsEcho;
    m_paramsFlanger = a.m_paramsFlanger;
    m_paramsGargle = a.m_paramsGargle;
    m_paramsParamEq = a.m_paramsParamEq;
    m_paramsReverb = a.m_paramsReverb;
	
   	for (DWORD i=0;i<=eNUM_SFX -1;i++)
		g_pLoaded[i] = a.g_pLoaded[i];

	g_pSegment = NULL;
	g_pAudioPath = NULL;
	g_pSoundBuffer = NULL;
	g_pPerformance = NULL;

	if (a.g_pPerformance != NULL)
	{
		CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, 
                      IID_IDirectMusicPerformance8, (LPVOID*) &g_pPerformance );

		if (g_pPerformance != NULL)
			hr = g_pPerformance->InitAudio( NULL, NULL, NULL, 
				                   0, 64,
					               DMUS_AUDIOF_ALL, NULL );
	}
	else g_pPerformance = NULL;

	if ((a.g_pAudioPath != NULL) && (g_pPerformance != NULL))
	{
		hr = g_pPerformance->CreateStandardAudioPath( 
		DMUS_APATH_SHARED_STEREOPLUSREVERB ,64,TRUE,&g_pAudioPath);            
	}
	else g_pAudioPath = NULL;

	if ((a.g_pSoundBuffer != NULL) && (g_pAudioPath != NULL))
	{
		hr = g_pAudioPath->GetObjectInPath(DMUS_PCHANNEL_ALL,DMUS_PATH_BUFFER 
										,0,GUID_NULL,0,IID_IDirectSoundBuffer8
										,(LPVOID*) &g_pSoundBuffer );
	}
	else g_pSoundBuffer = NULL;

	if (a.g_pSegment != NULL) 
	/*{
		if (MainAudio->getLoader() != NULL)
		{
			//MainAudio->getLoader()->ClearCache(CLSID_DirectMusicSegment);
			//MainAudio->getLoader()->ClearCache(CLSID_DirectSoundWave);
		}
		IDirectMusicSegment* t_segment = NULL;
		if (FAILED(hr = a.g_pSegment->QueryInterface(IID_IDirectMusicSegment, 
        (LPVOID *)&t_segment))) 
			SAFE_RELEASE(t_segment);
		
		if (t_segment != NULL)
		{
			if (FAILED(hr = a.g_pSegment->Clone(0,0,&t_segment))) SAFE_RELEASE(t_segment);
				if (t_segment != NULL)
				{
					hr = t_segment->QueryInterface(IID_IDirectMusicSegment8,(LPVOID *)&g_pSegment);
					hr = g_pSegment->Download(g_pAudioPath);
					SAFE_RELEASE(t_segment);
				}
		}
	}*/
	{
		//if (MainAudio->getLoader() != NULL)
		//{
			//MainAudio->getLoader()->ClearCache(CLSID_DirectMusicSegment);
			//MainAudio->getLoader()->ClearCache(CLSID_DirectSoundWave);
		//}
		TCHAR* t_filename = "";
		strcpy(t_filename,a.m_filename);
		hr = load(t_filename);
	}
	else 
	{
		g_pSegment = NULL;		
	};
}

CAAudio* CAAudio::clone()
{
	CAAudio* t_audio = new CAAudio(*this);

	if (t_audio->isInit() == FALSE)
	{
		t_audio->cleanup();
		SAFE_DELETE(t_audio);
		return NULL;
	}

	DWORD t_loop = 0;
	getloop(t_loop);
	t_audio->setloop(t_loop);
	
	LONG t_vol = 100;
	t_vol = getVolume();
	t_audio->setVolume(t_vol);
	
	if (isChorus()) t_audio->enableChorus();
	if (isCompressor()) t_audio->enableCompressor();
	if (isDistortion()) t_audio->enableDistortion();
	if (isEcho()) t_audio->enableEcho();
	if (isFlanger()) t_audio->enableFlanger();
	if (isGargle()) t_audio->enableGargle();
	if (isParameq()) t_audio->enableParameq();
	if (isReverb()) t_audio->enableReverb();
	
    DSFXChorus                  pChorus;
    DSFXCompressor              pCompressor;
    DSFXDistortion              pDistortion;
    DSFXEcho                    pEcho;
    DSFXFlanger                 pFlanger;
    DSFXGargle                  pGargle;
    DSFXParamEq                 pParamEq;
    DSFXWavesReverb             pReverb;

	getChorus(pChorus);
	getCompressor(pCompressor);
	getDistortion(pDistortion);
	getEcho(pEcho);
	getFlanger(pFlanger);
	getGargle(pGargle);
	getParameq(pParamEq);
	getReverb(pReverb);	

	t_audio->setChorus(pChorus);
	t_audio->setCompressor(pCompressor);
	t_audio->setDistortion(pDistortion);
	t_audio->setEcho(pEcho);
	t_audio->setFlanger(pFlanger);
	t_audio->setGargle(pGargle);
	t_audio->setParameq(pParamEq);
	t_audio->setReverb(pReverb);	
	return t_audio;
}

BOOL CA3daudio::isNormalMode()
{
	DWORD mode;
	if (g_p3DBuffer == NULL) return FALSE;
	g_p3DBuffer->GetMode(&mode);
	if (mode == DS3DMODE_NORMAL ) return TRUE;
	else return FALSE;
}

BOOL CA3daudio::isRelativeMode()
{
	DWORD mode;
	if (g_p3DBuffer == NULL) return FALSE;
	g_p3DBuffer->GetMode(&mode);
	if (mode == DS3DMODE_HEADRELATIVE ) return TRUE;
	else return FALSE;
}

CA3daudio::CA3daudio(const CA3daudio& a)
{
	HRESULT hr;
	volume = a.volume;
	m_paramsChorus = a.m_paramsChorus;
    m_paramsCompressor = a.m_paramsCompressor;
    m_paramsDistortion = a.m_paramsDistortion;
    m_paramsEcho = a.m_paramsEcho;
    m_paramsFlanger = a.m_paramsFlanger;
    m_paramsGargle = a.m_paramsGargle;
    m_paramsParamEq = a.m_paramsParamEq;
    m_paramsReverb = a.m_paramsReverb;

	g_pSegment = NULL;
	g_pAudioPath = NULL;
	g_pSoundBuffer = NULL;
	g_pPerformance = NULL;
	g_p3DBuffer = NULL;

   	for (DWORD i=0;i<=eNUM_SFX -1;i++)
		g_pLoaded[i] = a.g_pLoaded[i];

	if (a.g_pPerformance != NULL)
	{
		CoCreateInstance( CLSID_DirectMusicPerformance, NULL, CLSCTX_INPROC, 
                      IID_IDirectMusicPerformance8, (LPVOID*) &g_pPerformance );

		if (g_pPerformance != NULL)
			g_pPerformance->InitAudio( NULL, NULL, NULL, 
				                   0, 64,
					               DMUS_AUDIOF_ALL, NULL );
	}
	else g_pPerformance = NULL;

	if ((a.g_pAudioPath != NULL) && (g_pPerformance != NULL))
	{
		g_pPerformance->CreateStandardAudioPath(DMUS_APATH_DYNAMIC_3D,64,                         
		TRUE,&g_pAudioPath);            
	}
	else g_pAudioPath = NULL;

	if ((a.g_pSoundBuffer != NULL) && (g_pAudioPath != NULL))
	{
		g_pAudioPath->GetObjectInPath(DMUS_PCHANNEL_ALL,DMUS_PATH_BUFFER 
										,0,GUID_NULL,0,IID_IDirectSoundBuffer8
										,(LPVOID*) &g_pSoundBuffer );
	}
	else g_pSoundBuffer = NULL;

	if ((a.g_p3DBuffer != NULL) && (g_pAudioPath != NULL))
	{
		g_pAudioPath->GetObjectInPath( 0, DMUS_PATH_BUFFER, 0,
                                            GUID_NULL, 0, IID_IDirectSound3DBuffer, 
                                           (LPVOID*) &g_p3DBuffer );

	}
	else g_p3DBuffer = NULL;

	if (a.g_pSegment != NULL) 
	/*{
		IDirectMusicSegment* t_segment = NULL;
		if (FAILED(hr = a.g_pSegment->QueryInterface(IID_IDirectMusicSegment, 
        (LPVOID *)&t_segment))) 
			SAFE_RELEASE(t_segment);
		
		if (t_segment != NULL)
		{
			if (FAILED(hr = a.g_pSegment->Clone(0,0,&t_segment))) SAFE_RELEASE(t_segment);
				if (t_segment != NULL)
				{
					t_segment->QueryInterface(IID_IDirectMusicSegment8,(LPVOID *)&g_pSegment);
					hr = g_pSegment->Download(g_pAudioPath);
					SAFE_RELEASE(t_segment);
				}
		}
	}*/
	{
		//if (MainAudio->getLoader() != NULL)
		//{
			//MainAudio->getLoader()->ClearCache(CLSID_DirectMusicSegment);
			//MainAudio->getLoader()->ClearCache(CLSID_DirectSoundWave);
		//}
		strcpy(m_filename,a.m_filename);
		hr = load(m_filename);
	}
	else 
	{
		g_pSegment = NULL;		
	};
}

CA3daudio* CA3daudio::clone()
{
	CA3daudio* t_audio = new CA3daudio(*this);

	if (t_audio->isInit() == FALSE)
	{
		t_audio->cleanup();
		SAFE_DELETE(t_audio);
		return NULL;
	}

	DWORD t_loop = 0;
	getloop(t_loop);
	t_audio->setloop(t_loop);
	
	LONG t_vol = 100;
	t_vol = getVolume();
	t_audio->setVolume(t_vol);
	
	if (isChorus()) t_audio->enableChorus();
	if (isCompressor()) t_audio->enableCompressor();
	if (isDistortion()) t_audio->enableDistortion();
	if (isEcho()) t_audio->enableEcho();
	if (isFlanger()) t_audio->enableFlanger();
	if (isGargle()) t_audio->enableGargle();
	if (isParameq()) t_audio->enableParameq();
	if (isReverb()) t_audio->enableReverb();
	
    DSFXChorus                  pChorus;
    DSFXCompressor              pCompressor;
    DSFXDistortion              pDistortion;
    DSFXEcho                    pEcho;
    DSFXFlanger                 pFlanger;
    DSFXGargle                  pGargle;
    DSFXParamEq                 pParamEq;
    DSFXWavesReverb             pReverb;

	getChorus(pChorus);
	getCompressor(pCompressor);
	getDistortion(pDistortion);
	getEcho(pEcho);
	getFlanger(pFlanger);
	getGargle(pGargle);
	getParameq(pParamEq);
	getReverb(pReverb);	

	t_audio->setChorus(pChorus);
	t_audio->setCompressor(pCompressor);
	t_audio->setDistortion(pDistortion);
	t_audio->setEcho(pEcho);
	t_audio->setFlanger(pFlanger);
	t_audio->setGargle(pGargle);
	t_audio->setParameq(pParamEq);
	t_audio->setReverb(pReverb);	

	D3DVALUE dist;
	getMaxDistance(dist);
	t_audio->setMaxDistance(dist);
	getMinDistance(dist);
	t_audio->setMinDistance(dist);

	D3DVECTOR pos;
	getPosition(pos);
	t_audio->setPosition(pos);

	if (isRelativeMode()) t_audio->setRelativeMode();
	else t_audio->setNormalMode();

	D3DVECTOR vel;
	getVelocity(vel);
	t_audio->setVelocity(vel);
	
	DWORD in,out;
	getConeAngles(in,out);
	t_audio->setConeAngles(in,out);

	D3DVECTOR ort;
	getConeOrientation(ort);
	t_audio->setConeOrientation(ort);

	LONG vol;
	getConeOutsideVolume(vol);
	t_audio->setConeOutsideVolume(vol);

	return t_audio;
}

HRESULT CAAudio::getFilename(TCHAR* filename)
{
	if (strcmp(m_filename,"") == 0) return E_FAIL;
	strcpy(filename,m_filename);
	return S_OK;
}
