#ifndef GENHANDLE_H
#define GENHANDLE_H

#include <stack>

using namespace std;

class HandleGen
{
private:
	typedef stack<int> t_handle;
	t_handle HandleBin;
	double count ;
public:
	HandleGen();
	~HandleGen();
	int getHandle();
	void deleteHandle(double const hd);
	void cleanup();
};

#endif