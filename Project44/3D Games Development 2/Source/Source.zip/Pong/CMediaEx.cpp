#include <afxwin.h>
#include "CMediaEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMFramework* CMFramework::CMF=NULL;
CMFramework::CMFramework()
{
	CMF=this;
}

CMFramework* CMFramework::getCMF()
{
	if(NULL==CMF){
		CMF=new CMFramework();
	}
	return CMF;
}

void CMFramework::cleanup()
{
	CMManager::cleanup();
	SAFE_DELETE(CMF);
}
