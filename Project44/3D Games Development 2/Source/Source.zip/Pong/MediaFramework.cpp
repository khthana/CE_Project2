#include <afxwin.h>
#include "MediaFramework.h"
#include "FrameworEss.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int DM::init(HWND const hwnd)
{
	return FWUtils::HRESULT2INT(MainMedia->init(hwnd));
}

void DM::cleanup()
{
	MainMedia->cleanup();
}

int DM::Table::add(MEDIA_ROW const row)
{
	return FWUtils::HRESULT2INT(MainMediaTable->add(row));
}

int DM::Table::add(TCHAR* filename)
{
	return FWUtils::HRESULT2INT(MainMediaTable->add(filename));
}

int DM::Table::set(int const handle,MEDIA_ROW const row)
{
	return FWUtils::HRESULT2INT(MainMediaTable->set(handle,row));
}

int DM::Table::get(int const handle,MEDIA_ROW& row)
{
	MEDIA_ROW t_row;
	HRESULT hr;
	hr = MainMediaTable->get(handle,t_row);
	row = t_row;
	return FWUtils::HRESULT2INT(hr);
}

int DM::Table::erase(int const handle)
{
	return FWUtils::HRESULT2INT(MainMediaTable->erase(handle));
}


int DM::load(int const loadhd,int& playhd)
{
	return FWUtils::HRESULT2INT(MainMedia->load(loadhd,playhd));
}

int DM::unload(int const playhd)
{
	return FWUtils::HRESULT2INT(MainMedia->unload(playhd));
}

int DM::setCurrent(int const playhd)
{
	return FWUtils::HRESULT2INT(MainMedia->setCurrent(playhd));
}

int DM::getCurrent(int& playhd)
{
	return FWUtils::HRESULT2INT(MainMedia->getCurrent(playhd));
}

int DM::play()
{
	return FWUtils::HRESULT2INT(MainMedia->play());
}

int DM::pause()
{
	return FWUtils::HRESULT2INT(MainMedia->pause());
}

int DM::stop()
{
	return FWUtils::HRESULT2INT(MainMedia->stop());
}

int DM::isPlay()
{
	return FWUtils::HRESULT2INT(MainMedia->isPlay());
}

int DM::isPause()
{
	return FWUtils::HRESULT2INT(MainMedia->isPause());
}

int DM::isStop()
{
	return FWUtils::HRESULT2INT(MainMedia->isStop());
}

int DM::getCurrentPosition(LONGLONG& pos)
{
	return FWUtils::HRESULT2INT(MainMedia->getCurrentPosition(pos));
}

int DM::getStopPosition(LONGLONG& pos)
{
	return FWUtils::HRESULT2INT(MainMedia->getStopPosition(pos));
}

int DM::setPlayRate(double const rate)
{
	return FWUtils::HRESULT2INT(MainMedia->setPlayRate(rate));
}

int DM::getPlayRate(double& rate)
{
	return FWUtils::HRESULT2INT(MainMedia->getPlayRate(rate));
}

int DM::setEnd(LONGLONG const end) //not for playing
{
	return FWUtils::HRESULT2INT(MainMedia->setEnd(end));
}

int DM::getEnd(LONGLONG& end)
{
	return FWUtils::HRESULT2INT(MainMedia->getEnd(end));
}

int DM::setStart(LONGLONG const start)  //not for playing
{
	return FWUtils::HRESULT2INT(MainMedia->setStart(start));
}

int DM::getStart(LONGLONG& start)
{
	return FWUtils::HRESULT2INT(MainMedia->getStart(start));
}

int DM::setVolume(LONG const volume)
{
	return FWUtils::HRESULT2INT(MainMedia->setVolume(volume));
}

int DM::getVolume(LONG& volume)
{
	return FWUtils::HRESULT2INT(MainMedia->getVolume(volume));
}

int DM::setWindowPosition(WINDOW_POS const pos)
{
	return FWUtils::HRESULT2INT(MainMedia->setWindowPosition(pos));
}

int DM::getWindowPosition(WINDOW_POS& pos)
{
	return FWUtils::HRESULT2INT(MainMedia->getWindowPosition(pos));
}

int DM::setForeground()
{
	return FWUtils::HRESULT2INT(MainMedia->setForeground());
}
