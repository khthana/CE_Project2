class FWUtils
{
public:
	static inline int HRESULT2INT(HRESULT hr)
	{
		if (hr == S_OK) return 0;
		else if (hr == S_FALSE) return 1;
		else return -1;
	}

};