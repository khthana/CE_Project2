#ifndef CMEDIA_H
#define CMEDIA_H

//#ifndef INITGUID
//#define INITGUID
//#endif

#pragma warning(disable:4786)

#include <Dshow.h>
#include <map>
#include "GenHandle.h"

using namespace std;
//#include "CDynamicArray.h"

#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

struct WINDOW_POS
{
	long left;
	long top;
	long width;
	long height;
};

struct MEDIA_ROW
{
	TCHAR filename[MAX_PATH];
	LONG volume;
	double rate;
	LONGLONG start;
	LONGLONG end;
	WINDOW_POS pos;
};

class CMMedia
{
protected:
	LONGLONG StartTime;
	IGraphBuilder* m_pGraphBuilder;
	IMediaControl* m_pController;
	IMediaSeeking* m_pSeeker;
	IBasicAudio* m_pAudio;
	IVideoWindow* m_pWindow;
public:
	CMMedia();
	HRESULT open(TCHAR* filename,HWND const hwnd);
	void close();

	HRESULT setCurrentPosition(LONGLONG const pos);
	HRESULT getCurrentPosition(LONGLONG& pos);
	HRESULT setStopPosition(LONGLONG const pos);
	HRESULT getStopPosition(LONGLONG& pos);
	HRESULT setStartPosition(LONGLONG const start);
	HRESULT getStartPosition(LONGLONG& start);
	HRESULT getDuration(LONGLONG& dur);
};

class CMMediaPlayer:public CMMedia
{
public:
	HRESULT play();
	HRESULT stop();
	HRESULT pause();

	BOOL isPlay();
	BOOL isPause();
	BOOL isStop();

	HRESULT setPlayRate(double const rate);
	HRESULT getPlayRate(double& rate);
	HRESULT getVolume(LONG& volume);
	HRESULT setVolume(LONG const volume);
	HRESULT setWindowPosition(WINDOW_POS const pos);
	HRESULT getWindowPosition(WINDOW_POS& pos);

	HRESULT setForeground();
};

typedef map<int,MEDIA_ROW> MediaMap;
typedef map<int,CMMediaPlayer*> PlayerMap;

class CMMediaTable
{
private:
	MediaMap table;
	HandleGen hdGen;
public:
	~CMMediaTable();
	int add(MEDIA_ROW const row);
	int add(TCHAR* filename);
	HRESULT set(int const handle,MEDIA_ROW const row);
	HRESULT get(int const handle,MEDIA_ROW& row);
	HRESULT erase(int const handle);
	void cleanup();
};

class CMManager
{
private:
	CMMediaTable MediaTable;
	PlayerMap PlayerTable;
	HandleGen hdGen;

	CMMediaPlayer* getMediaPlayer(int const playhd);
	int curPlayerHandle;
	HWND m_hwnd;
public:
	CMManager();
	HRESULT init(HWND const hwnd);
	void cleanup();

	HRESULT load(int const loadhd,int& playhd);
	HRESULT unload(int const playhd);

	HRESULT setCurrent(int const playhd);
	HRESULT getCurrent(int& playhd);

	HRESULT play();
	HRESULT pause();
	HRESULT stop();

	HRESULT isPlay();
	HRESULT isPause();
	HRESULT isStop();
	
	HRESULT getCurrentPosition(LONGLONG& pos);
	HRESULT getStopPosition(LONGLONG& pos);

	HRESULT setPlayRate(double const rate);
	HRESULT getPlayRate(double& rate);
	HRESULT setEnd(LONGLONG const end); //not for playing
	HRESULT getEnd(LONGLONG& end);
	HRESULT setStart(LONGLONG const start);  //not for playing
	HRESULT getStart(LONGLONG& start);
	HRESULT setVolume(LONG const volume);
	HRESULT getVolume(LONG& volume);

	HRESULT setWindowPosition(WINDOW_POS const pos);
	HRESULT getWindowPosition(WINDOW_POS& pos);
	HRESULT setForeground();

	CMMediaTable* getMediaTable() {return &MediaTable;};
};

#endif