#include <afxwin.h>
#include "GenHandle.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HandleGen::HandleGen()
{
	//while (!HandleBin.empty()) HandleBin.pop();
	count = 0;
}

HandleGen::~HandleGen()
{
}

void HandleGen::cleanup()
{
	//while (!HandleBin.empty()) HandleBin.pop();
	count = 0;
}

int HandleGen::getHandle()
{
	if (HandleBin.empty())
	{
		count++;
		return count -1;
	}
	else
	{
		double t_top;
		t_top = HandleBin.top();
		HandleBin.pop();
		return t_top;
	}
}
void HandleGen::deleteHandle(double const hd)
{
	HandleBin.push(hd);
}
