#ifndef CAUDIO_H
#define CAUDIO_H

//#ifndef INITGUID
//#define INITGUID
//#endif

#define MainAudio CAManager::getCAM ()

#include <dmusicc.h>
#include <dmusici.h>
#include <dsound.h>
#include <cguid.h>
#include <unknwn.h >

#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

enum ESFXType
{
    eSFX_chorus = 0,
    eSFX_compressor = 1,
    eSFX_distortion = 2,
    eSFX_echo = 3,
    eSFX_flanger = 4,
    eSFX_gargle = 5,
    eSFX_parameq = 6,
    eSFX_reverb = 7,
    // number of enumerated effects
    eNUM_SFX = 8
};

class CAManager
{
private:
	static CAManager* CAM;
protected:
	IDirectMusicLoader8* g_pLoader;
	IDirectSound8* g_pDS;
	IDirectSound3DListener8* g_pListener;
	LPDIRECTSOUNDBUFFER pDSBPrimary;
public:
	CAManager();
	HRESULT		init(HWND const hWnd);
	void		cleanup();
	
	HRESULT		setOrientation(D3DVECTOR const front,D3DVECTOR const top);
	HRESULT		setOrientation(D3DVALUE const fx,D3DVALUE const fy,D3DVALUE const fz,D3DVALUE tx,D3DVALUE ty,D3DVALUE tz);
	HRESULT		getOrientation(D3DVECTOR& fort,D3DVECTOR& tort);
	HRESULT		setPosition(D3DVECTOR const pos);
	HRESULT		setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT		getPosition(D3DVECTOR& pos);
	HRESULT		setVelocity(D3DVECTOR const vel);
	HRESULT		setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT		getVelocity(D3DVECTOR& vel);
	HRESULT		setDoppler(D3DVALUE const dop);
	HRESULT		getDoppler(D3DVALUE& dop);
	HRESULT		setRolloff(D3DVALUE const rol);
	HRESULT		getRolloff(D3DVALUE& rol);
	
	IDirectMusicLoader8* getLoader(){return g_pLoader;};
	static  CAManager* getCAM();
};

class CAAudio
{
public:
	CAAudio();
	HRESULT init();
	void cleanup();
	void play();
	void stop();
	HRESULT load(TCHAR* const filename);
	HRESULT setloop();
	HRESULT setloop(DWORD const loop);
	HRESULT resetloop();
	HRESULT getloop(DWORD& loop);

	HRESULT isPlay();
	LONG getVolume();
	HRESULT setVolume(LONG const vol);
	
	HRESULT setChorus(DSFXChorus const paramsChorus);
	HRESULT setCompressor(DSFXCompressor const paramsCompressor);
	HRESULT setDistortion(DSFXDistortion const paramsDistortion);
	HRESULT setEcho(DSFXEcho const paramsEcho);
	HRESULT setFlanger(DSFXFlanger const paramsFlanger);
	HRESULT setGargle(DSFXGargle const paramsGargle);
	HRESULT setParameq(DSFXParamEq const paramsParamEq);
	HRESULT setReverb(DSFXWavesReverb const paramsReverb);	

	HRESULT setChorus();
	HRESULT setCompressor();
	HRESULT setDistortion();
	HRESULT setEcho();
	HRESULT setFlanger();
	HRESULT setGargle();
	HRESULT setParameq();
	HRESULT setReverb();

	BOOL isChorus() {return g_pLoaded[eSFX_chorus];};
	BOOL isCompressor() {return g_pLoaded[eSFX_compressor];};
	BOOL isDistortion() {return g_pLoaded[eSFX_distortion];};
	BOOL isEcho() {return g_pLoaded[eSFX_echo];};
	BOOL isFlanger() {return g_pLoaded[eSFX_flanger];};
	BOOL isGargle() {return g_pLoaded[eSFX_gargle];};
	BOOL isParameq() {return g_pLoaded[eSFX_parameq];};
	BOOL isReverb() {return g_pLoaded[eSFX_reverb];};
	BOOL isEffect();
	
	HRESULT getChorus(DSFXChorus& paramsChorus);
	HRESULT getCompressor(DSFXCompressor& paramsCompressor);
	HRESULT getDistortion(DSFXDistortion& paramsDistortion);
	HRESULT getEcho(DSFXEcho& paramsEcho);
	HRESULT getFlanger(DSFXFlanger& paramsFlanger);
	HRESULT getGargle(DSFXGargle& paramsGargle);
	HRESULT getParameq(DSFXParamEq& paramsParamEq);
	HRESULT getReverb(DSFXWavesReverb& paramsReverb);	

	HRESULT enableChorus();
	HRESULT enableCompressor();
	HRESULT enableDistortion();
	HRESULT enableEcho();
	HRESULT enableFlanger();
	HRESULT enableGargle();
	HRESULT enableParameq();
	HRESULT enableReverb();
	
	HRESULT disableChorus();
	HRESULT disableCompressor();
	HRESULT disableDistortion();
	HRESULT disableEcho();
	HRESULT disableFlanger();
	HRESULT disableGargle();
	HRESULT disableParameq();
	HRESULT disableReverb();
	HRESULT disableAllEffect();

	BOOL isInit()
	{
		if ((g_pPerformance != NULL) && (g_pAudioPath != NULL) &&
			(g_pSoundBuffer != NULL)) return TRUE;
		else return FALSE;
	};
	HRESULT active()
	{
		if (g_pAudioPath != NULL) return g_pAudioPath->Activate(TRUE);
		else return E_FAIL;
	};

	CAAudio* clone();
	HRESULT getFilename(TCHAR* filename);
private:
	CAAudio(const CAAudio& a);
protected:
	TCHAR m_filename[MAX_PATH];
	long volume;

    DSFXChorus                  m_paramsChorus;
    DSFXCompressor              m_paramsCompressor;
    DSFXDistortion              m_paramsDistortion;
    DSFXEcho                    m_paramsEcho;
    DSFXFlanger                 m_paramsFlanger;
    DSFXGargle                  m_paramsGargle;
    DSFXParamEq                 m_paramsParamEq;
    DSFXWavesReverb             m_paramsReverb;
	
    IDirectMusicSegment8*		g_pSegment;
	IDirectMusicAudioPath8*		g_pAudioPath;
	IDirectMusicPerformance8*   g_pPerformance;
	IDirectSoundBuffer8*        g_pSoundBuffer;

    BOOL                        g_pLoaded[eNUM_SFX];
	void						genDescFX(DSEFFECTDESC* dsEffect);//[eNUM_SFX]);
	void						clearFXData();
	DWORD						checkFXNum();
	HRESULT						setFX();
	void						loadDefaultFX(ESFXType const FXType);
	HRESULT						setParamFX(ESFXType const FXType);
	DWORD						checkFXOrder(ESFXType const FXType);
};

class CA3daudio:public CAAudio
{
public:
	CA3daudio();
	HRESULT init();
	void cleanup();

	HRESULT setMaxDistance(D3DVALUE const maxDist);
	HRESULT getMaxDistance(D3DVALUE& maxDist);
	HRESULT setMinDistance(D3DVALUE const minDist);
	HRESULT getMinDistance(D3DVALUE& minDist);

	HRESULT setPosition(D3DVECTOR const pos);
	HRESULT setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT movePosition(D3DVECTOR const pos);
	HRESULT movePosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT getPosition(D3DVECTOR& Vt);

	HRESULT setNormalMode();
	HRESULT setRelativeMode();
	BOOL isNormalMode();
	BOOL isRelativeMode();
	
	HRESULT setVelocity(D3DVECTOR const vel);
	HRESULT setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT getVelocity(D3DVECTOR& vel);

	HRESULT setConeAngles(DWORD const in,DWORD const out);
	HRESULT setConeOrientation(D3DVECTOR const ort);
	HRESULT setConeOutsideVolume(LONG const vol);
	HRESULT getConeAngles(DWORD& in,DWORD& out);
	HRESULT getConeOrientation(D3DVECTOR& ort);
	HRESULT getConeOutsideVolume(LONG& vol);

	BOOL isInit()
	{
		if ((g_pPerformance != NULL) && (g_pAudioPath != NULL) &&
			(g_pSoundBuffer != NULL) && (g_p3DBuffer != NULL)) return TRUE;
		else return FALSE;
	};

	CA3daudio* clone();
protected:
	IDirectSound3DBuffer*   g_p3DBuffer;
private:
	CA3daudio(const CA3daudio& a);
};

/*
class CANMSoundAgent
{
public:
	CANMSoundAgent();
	void cleanup();
	void play();
	void stop();
	HRESULT setloop();
	HRESULT setloop(DWORD const loop);
	HRESULT resetloop();
	HRESULT isPlay();
	LONG getVolume();
	HRESULT setVolume(LONG const vol);

	HRESULT setChorus(FLOAT const fWetDryMix,FLOAT const fDepth,FLOAT const fFeedback,FLOAT const fFrequency,
						LONG const lWaveform,FLOAT const fDelay,LONG const lPhase);
	HRESULT setCompressor(FLOAT const fGain,FLOAT const fAttack,FLOAT const fRelease,FLOAT const fThreshold,
    						FLOAT const fRatio,FLOAT const fPredelay);
	HRESULT setDistortion(FLOAT const fGain,FLOAT const fEdge,FLOAT const fPostEQCenterFrequency,
							FLOAT const fPostEQBandwidth,FLOAT const fPreLowpassCutoff);
	HRESULT setEcho(FLOAT const fWetDryMix,FLOAT const fFeedback,FLOAT const fLeftDelay,FLOAT const fRightDelay,
    				  LONG  const lPanDelay);
	HRESULT setFlanger(FLOAT const fWetDryMix,FLOAT const fDepth,FLOAT const fFeedback,FLOAT const fFrequency,
    					 LONG const lWaveform,FLOAT const fDelay,LONG const lPhase);
	HRESULT setGargle(DWORD const dwRateHz,DWORD const dwWaveShape);
	HRESULT setParameq(FLOAT const fCenter,FLOAT const fBandwidth,FLOAT const fGain);
	HRESULT setReverb(FLOAT const fInGain,FLOAT const fReverbMix,FLOAT const fReverbTime,
						FLOAT const fHighFreqRTRatio);
	
	HRESULT setChorus();
	HRESULT setCompressor();
	HRESULT setDistortion();
	HRESULT setEcho();
	HRESULT setFlanger();
	HRESULT setGargle();
	HRESULT setParameq();
	HRESULT setReverb();

	BOOL isChorus(); 
	BOOL isCompressor();
	BOOL isDistortion(); 
	BOOL isEcho(); 
	BOOL isFlanger();
	BOOL isGargle(); 
	BOOL isParameq(); 
	BOOL isReverb();
	BOOL isEffect();
	
	HRESULT enableChorus();
	HRESULT enableCompressor();
	HRESULT enableDistortion();
	HRESULT enableEcho();
	HRESULT enableFlanger();
	HRESULT enableGargle();
	HRESULT enableParameq();
	HRESULT enableReverb();
	
	HRESULT disableChorus();
	HRESULT disableCompressor();
	HRESULT disableDistortion();
	HRESULT disableEcho();
	HRESULT disableFlanger();
	HRESULT disableGargle();
	HRESULT disableParameq();
	HRESULT disableReverb();
	HRESULT disableAllEffect();

	HRESULT dupCANMSoundAgent(CANMSoundAgent& agent);
	HRESULT getName(TCHAR* name);
	HRESULT settoCAAudio(TCHAR* name);
protected:
	CAAudio* pCAAudio;
};

class CA3DSoundAgent
{
public:
	CA3DSoundAgent();
	void cleanup();
	void play();
	void stop();
	HRESULT setloop();
	HRESULT setloop(DWORD const loop);
	HRESULT resetloop();
	HRESULT isPlay();
	LONG getVolume();
	HRESULT setVolume(LONG const vol);

	HRESULT setChorus(FLOAT const fWetDryMix,FLOAT const fDepth,FLOAT const fFeedback,FLOAT const fFrequency,
						LONG const lWaveform,FLOAT const fDelay,LONG const lPhase);
	HRESULT setCompressor(FLOAT const fGain,FLOAT const fAttack,FLOAT const fRelease,FLOAT const fThreshold,
    						FLOAT const fRatio,FLOAT const fPredelay);
	HRESULT setDistortion(FLOAT const fGain,FLOAT const fEdge,FLOAT const fPostEQCenterFrequency,
							FLOAT const fPostEQBandwidth,FLOAT const fPreLowpassCutoff);
	HRESULT setEcho(FLOAT const fWetDryMix,FLOAT const fFeedback,FLOAT const fLeftDelay,FLOAT const fRightDelay,
    				  LONG  const lPanDelay);
	HRESULT setFlanger(FLOAT const fWetDryMix,FLOAT const fDepth,FLOAT const fFeedback,FLOAT const fFrequency,
    					 LONG const lWaveform,FLOAT const fDelay,LONG const lPhase);
	HRESULT setGargle(DWORD const dwRateHz,DWORD const dwWaveShape);
	HRESULT setParameq(FLOAT const fCenter,FLOAT const fBandwidth,FLOAT const fGain);
	HRESULT setReverb(FLOAT const fInGain,FLOAT const fReverbMix,FLOAT const fReverbTime,
						FLOAT const fHighFreqRTRatio);
	
	HRESULT setChorus();
	HRESULT setCompressor();
	HRESULT setDistortion();
	HRESULT setEcho();
	HRESULT setFlanger();
	HRESULT setGargle();
	HRESULT setParameq();
	HRESULT setReverb();

	BOOL isChorus(); 
	BOOL isCompressor();
	BOOL isDistortion(); 
	BOOL isEcho(); 
	BOOL isFlanger();
	BOOL isGargle(); 
	BOOL isParameq(); 
	BOOL isReverb();
	BOOL isEffect();
	
	HRESULT enableChorus();
	HRESULT enableCompressor();
	HRESULT enableDistortion();
	HRESULT enableEcho();
	HRESULT enableFlanger();
	HRESULT enableGargle();
	HRESULT enableParameq();
	HRESULT enableReverb();
	
	HRESULT disableChorus();
	HRESULT disableCompressor();
	HRESULT disableDistortion();
	HRESULT disableEcho();
	HRESULT disableFlanger();
	HRESULT disableGargle();
	HRESULT disableParameq();
	HRESULT disableReverb();
	HRESULT disableAllEffect();

	HRESULT setMaxDistance(D3DVALUE const maxDist);
	HRESULT getMaxDistance(D3DVALUE& maxDist);
	HRESULT setMinDistance(D3DVALUE const minDist);
	HRESULT getMinDistance(D3DVALUE& minDist);

	HRESULT setPosition(D3DVECTOR const pos);
	HRESULT setPosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT movePosition(D3DVECTOR const pos);
	HRESULT movePosition(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT getPosition(D3DVECTOR& Vt);

	HRESULT setNormalMode();
	HRESULT setRelativeMode();
	
	HRESULT setVelocity(D3DVECTOR const vel);
	HRESULT setVelocity(D3DVALUE const x,D3DVALUE const y,D3DVALUE const z);
	HRESULT getVelocity(D3DVECTOR& vel);

	HRESULT setConeAngles(DWORD const in,DWORD const out);
	HRESULT setConeOrientation(D3DVECTOR const ort);
	HRESULT setConeOutsideVolume(LONG const vol);
	HRESULT getConeAngles(DWORD& in,DWORD& out);
	HRESULT getConeOrientation(D3DVECTOR& ort);
	HRESULT getConeOutsideVolume(LONG& vol);

	HRESULT dupCA3DSoundAgent(CANMSoundAgent& agent);
	HRESULT getName(TCHAR* name);
	HRESULT settoCA3DAudio(TCHAR* name);
protected:
	CA3daudio* pCA3DAudio;
};
*/

#endif