#include <afxwin.h>
#include "InputFramework.h"
#include "FrameworEss.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int DI::init(HWND const hwnd)
{
	HRESULT hr;
	DWORD t1,t2,t3;
	if (FAILED(hr = MainInput->init(hwnd))) return -1;
	return (DI::createDevice(t1,t2,t3));
}

void DI::cleanup()
{
	DI::destroyDevice();
	MainInput->cleanup();
}

int DI::getDeviceNum(DWORD& num)
{
	num = GetJoystickCount() + GetMouseCount() + GetKeyboardCount() ;
	return 0;
}

int DI::getDeviceNum(DEVICETYPE const type,DWORD& num)
{
	switch(type)
	{
	case KEY_TYPE :
		num = GetKeyboardCount();
		break;
	case MOUSE_TYPE :
		num = GetMouseCount();
		break;
	case JOY_TYPE :
		num = GetJoystickCount();
		break;
	default :
		num = GetJoystickCount() + GetMouseCount() + GetKeyboardCount() ;
		break;
	}
	return 0;
}

int DI::createDevice(DWORD& keyNum,DWORD& mouseNum,DWORD& joystickNum)
{
	HRESULT hr;
	destroyDevice();

	do
	{
		CIKeyboard* t_keyboard = new CIKeyboard;
		hr = t_keyboard->init();
		if (hr == 0)
		{
			MainInput->addArrKeyboard(t_keyboard);
		}
		else SAFE_DELETE(t_keyboard);
	}while (hr == 0);
	do
	{
		CIMouse* t_mouse = new CIMouse;
		hr = t_mouse->init();
		if (hr == 0)
		{
			MainInput->addArrMouse(t_mouse);
		}
		else SAFE_DELETE(t_mouse);
	}while (hr == 0);
	do
	{
		CIJoystick* t_joystick = new CIJoystick;
		hr = t_joystick->init();
		if (hr == 0)
		{
			MainInput->addArrJoystick(t_joystick);
		}
		else SAFE_DELETE(t_joystick);
	} while (hr == 0);
    	
	keyNum = GetKeyboardCount();
	mouseNum = GetMouseCount();
	joystickNum = GetJoystickCount();
	return 0;
}

void DI::destroyDevice()
{
	for (UINT i=0;i < MainInput->getArrKeyboardSize();i++)
	{
		if (MainInput->toKeyboard(i) != NULL)
		{
			CIKeyboard* t_key;
			t_key = MainInput->toKeyboard(i);
			t_key->cleanup(); 
			SAFE_DELETE(t_key);
		};
	};
	MainInput->clearArrKeyboard();
	for (UINT j=0;j < MainInput->getArrMouseSize();j++)
	{
		if (MainInput->toMouse(j) != NULL)
		{
			CIMouse* t_mouse;
			t_mouse = MainInput->toMouse(j);
			t_mouse->cleanup();
			SAFE_DELETE(t_mouse);
		};
	};
	MainInput->clearArrMouse();
	for (UINT k=0;k < MainInput->getArrJoystickSize();k++)
	{
		if (MainInput->toJoystick(k) != NULL)
		{
			CIJoystick* t_joy;
			t_joy = MainInput->toJoystick(k);
			t_joy->cleanup();
			SAFE_DELETE(t_joy);
		};
	};
	MainInput->clearArrJoystick();
}

int DI::Param::getInfoGuidProduct(DEVICETYPE const type,DWORD const handle,GUID& guidProduct)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoGuidProduct(guidProduct)))
				return -1;
			else return 0;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoGuidProduct(guidProduct)))
				return -1;
			else return 0;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoGuidProduct(guidProduct)))
				return -1;
			else return 0;
	default :return -1;
	}
}

int DI::Param::getInfoGuidFFDriver(DEVICETYPE const type,DWORD const handle,GUID& guidFFDriver)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoGuidFFDriver(guidFFDriver)))
				return -1;
			else return 0;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoGuidFFDriver(guidFFDriver)))
				return -1;
			else return 0;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoGuidFFDriver(guidFFDriver)))
				return -1;
			else return 0;
	default :return -1;
	}
}

int DI::Param::getInfoInstanceName(DEVICETYPE const type,DWORD const handle,TCHAR* tszInstanceName)
{
	HRESULT hr;
	TCHAR* t_str;
	t_str = "";
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoInstanceName(t_str)))
				return -1;
			else break;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoInstanceName(t_str)))
				return -1;
			else break;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoInstanceName(t_str)))
				return -1;
			else break;
	default :return -1;
	}
	strcpy(tszInstanceName,t_str);
	return 0;
}

int DI::Param::getInfoProductName(DEVICETYPE const type,DWORD const handle,TCHAR* tszProductName)
{
	HRESULT hr;
	TCHAR* t_str;
	t_str = "";
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoProductName(t_str)))
				return -1;
			else break;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoProductName(t_str)))
				return -1;
			else break;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoProductName(t_str)))
				return -1;
			else break;
	default :return -1;
	}
	strcpy(tszProductName,t_str);
	return 0;
}

int DI::Param::getInfoDeviceMainType(DEVICETYPE const type,DWORD const handle,DWORD& manintype)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoDeviceMainType(manintype)))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoDeviceMainType(manintype)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoDeviceMainType(manintype)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getInfoDeviceSubType(DEVICETYPE const type,DWORD const handle,DWORD& subtype)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoDeviceSubType(subtype)))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoDeviceSubType(subtype)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoDeviceSubType(subtype)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getInfoDeviceType(DEVICETYPE const type,DWORD const handle,DWORD& alltype)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getInfoDeviceType(alltype)))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoDeviceType(alltype)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoDeviceType(alltype)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::isAttatch(DEVICETYPE const type,DWORD const handle)
{
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FALSE == MainInput->toKeyboard(handle)->isAttatch())
				return 1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FALSE == MainInput->toMouse(handle)->isAttatch())
				return 1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FALSE == MainInput->toJoystick(handle)->isAttatch())
				return 1;
			else return 0;
		else return -1;
	default :return -1;
	}
}


int DI::enableDevice(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->start()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->start()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->start()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::disableDevice(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->stop()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->stop()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->stop()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getFFSupport(DEVICETYPE const type,DWORD const handle)
{
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FALSE == MainInput->toKeyboard(handle)->isFFSupport())
				return 1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FALSE == MainInput->toMouse(handle)->isFFSupport())
				return 1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FALSE == MainInput->toJoystick(handle)->isFFSupport())
				return 1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setFFPause(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->setFFPause()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setFFPause()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setFFPause()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setFFContinue(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->setFFContinue()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setFFContinue()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setFFContinue()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setFFStop(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->setFFStop()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setFFStop()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setFFStop()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setFFReset(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->setFFReset()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setFFReset()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setFFReset()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setFFActuatorsON(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->setFFActuatorsON()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setFFActuatorsON()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setFFActuatorsON()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setFFActuatorsOFF(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->setFFActuatorsOFF()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setFFActuatorsOFF()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setFFActuatorsOFF()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getFFPause(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getFFPause()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getFFPause()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getFFPause()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getFFActuatorsON(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getFFActuatorsON()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getFFActuatorsON()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getFFActuatorsON()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getFFActuatorsOFF(DEVICETYPE const type,DWORD const handle)
{
	HRESULT hr;
	switch(type)
	{
	case KEY_TYPE:
		if ((handle >= 0) || (handle < GetKeyboardCount()))
			if (FAILED(hr = MainInput->toKeyboard(handle)->getFFActuatorsOFF()))
				return -1;
			else return 0;
		else return -1;
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getFFActuatorsOFF()))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getFFActuatorsOFF()))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getInfoAxes(DEVICETYPE const type,DWORD const handle,DWORD& numAxes)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoAxes(numAxes)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoAxes(numAxes)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getInfoPOVs(DEVICETYPE const type,DWORD const handle,DWORD& numPOVs)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoPOVs(numPOVs)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoPOVs(numPOVs)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getInfoButtons(DEVICETYPE const type,DWORD const handle,DWORD& numButtons)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getInfoButtons(numButtons)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getInfoButtons(numButtons)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRange(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setRange(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRange(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRange(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getRange(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRange(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setDeadZone(DEVICETYPE const type,DWORD const handle,LONG const deadzone)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setDeadZone(deadzone)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setDeadZone(deadzone)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getDeadZone(DEVICETYPE const type,DWORD const handle,LONG& deadzone)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getDeadZone(deadzone)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getDeadZone(deadzone)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setSaturation(DEVICETYPE const type,DWORD const handle,LONG const saturation)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setSaturation(saturation)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setSaturation(saturation)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getSaturation(DEVICETYPE const type,DWORD const handle,LONG& saturation)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getSaturation(saturation)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getSaturation(saturation)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRangeX(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setRangeX(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRangeX(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRangeX(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getRangeX(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRangeX(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRangeY(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setRangeY(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRangeY(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRangeY(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getRangeY(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRangeY(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRangeZ(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->setRangeZ(range)))
				return -1;
			else return 0;
		else return -1;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRangeZ(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRangeZ(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case MOUSE_TYPE:
		if ((handle >= 0) || (handle < GetMouseCount()))
			if (FAILED(hr = MainInput->toMouse(handle)->getRangeZ(range)))
				return -1;
			else return 0;
		else return -1;
		break;
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRangeZ(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRangeRX(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRangeRX(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRangeRX(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRangeRX(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRangeRY(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRangeRY(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRangeRY(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRangeRY(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::setRangeRZ(DEVICETYPE const type,DWORD const handle,LONG const range)
{
	HRESULT hr;
	switch(type)
	{
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->setRangeRZ(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::Param::getRangeRZ(DEVICETYPE const type,DWORD const handle,LONG& range)
{
	HRESULT hr;
	switch(type)
	{
	case JOY_TYPE:
		if ((handle >= 0) || (handle < GetJoystickCount()))
			if (FAILED(hr = MainInput->toJoystick(handle)->getRangeRZ(range)))
				return -1;
			else return 0;
		else return -1;
	default :return -1;
	}
}

int DI::getState(DWORD const handle,BYTE* pBuffer)
{
	HRESULT hr;
	if ((handle >= 0) || (handle < GetKeyboardCount()))
		if (FAILED(hr = MainInput->toKeyboard(handle)->getState(pBuffer)))
			//return -1;
			return -1;
		else return 0;
	else return -1;
}

int DI::getState(DWORD const handle,DIMOUSESTATE2& buffer)
{
	HRESULT hr;
	if ((handle >= 0) || (handle < GetMouseCount()))
		if (FAILED(hr = MainInput->toMouse(handle)->getState(buffer)))
			return -1;
		else return 0;
	else return -1;
}

int DI::getState(DWORD const handle,DIJOYSTATE2& buffer)
{
	HRESULT hr;
	if ((handle >= 0) || (handle < GetJoystickCount()))
		if (FAILED(hr = MainInput->toJoystick(handle)->getState(buffer)))
			return -1;
		else return 0;
	else return -1;
}

int DI::FF::createFFEffect(DEVICETYPE const type,DWORD const handle,TCHAR* name,const TCHAR* filename)
{
	HRESULT hr;
	hr = -1;
	CIEffect* t_Effect = new CIEffect;
	switch(type)
	{
	case KEY_TYPE:
		hr = t_Effect->init(MainInput->toKeyboard(handle),filename);
		break;
	case MOUSE_TYPE:
		hr = t_Effect->init(MainInput->toMouse(handle),filename);
		break;
	case JOY_TYPE:
		hr = t_Effect->init(MainInput->toJoystick(handle),filename);
		break;
	}
	if (hr == 0) MainEffect->addCIEffectTable(name,t_Effect);
	else
	{
		t_Effect->cleanup();
		SAFE_DELETE(t_Effect);
		return -1;
	};
	return 0;
	//if (FAILED(hr = t_Agent->settoCIEffect(name))) 
	//{
	//	SAFE_DELETE(t_Agent);
	//	return 1;
	//}
	//else 
	//{
	//	agent = t_Agent;
	//	t_Agent = NULL;
	//	return 0;
	//};
}

int DI::FF::destroyFFEffect(TCHAR* name)
{
	CIEffect* t_Effect;
	UINT t_index;

	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect == NULL) return -1;
	//t_Effect->cleanupAgent();
	//t_Effect->cleanup();
	//SAFE_DELETE(t_Effect);
	MainEffect->removeCIEffectTable(t_index);
	return 0;
}

int DI::FF::clearFFEffect()
{
	while (MainEffect->getCIEffectTableSize() != 0)
	{
		MainEffect->removeCIEffectTable(0);
	}
	//for (UINT i=0;i<=MainEffect->getCI;i++)
	//	MainEffect->removeCIEffectTable(i);
	return 0;
}

CIEffAgent* DI::FF::cloneFFEffectAgent(TCHAR* name)
{
	HRESULT hr;
	CIEffect* t_Effect;
	UINT t_index;
	CIEffAgent* t_Agent = new CIEffAgent;

	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect == NULL) 
	{
		SAFE_DELETE(t_Agent);
		return NULL;
	};
	if (FAILED(hr = t_Agent->settoCIEffect(name))) 
	{
		SAFE_DELETE(t_Agent);
		return NULL;
	}
	else 
	{
		//agent = t_Agent;
		return t_Agent;
	}
}

int DI::FF::playFFEffect(TCHAR* name)
{
	UINT t_index;
	CIEffect* t_Effect;
	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect != NULL)
	{
		t_Effect->play();
		return 0;
	}
	else return -1;
}

int DI::FF::setloopFFEffect(TCHAR* name)
{
	UINT t_index;
	CIEffect* t_Effect;
	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect != NULL)
	{
		t_Effect->setloop();
		return 0;
	}
	else return -1;
}

int DI::FF::setloopFFEffect(TCHAR* name,DWORD const dloop)
{
	UINT t_index;
	CIEffect* t_Effect;
	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect != NULL)
	{
		t_Effect->setloop(dloop);
		return 0;
	}
	else return -1;
}

int DI::FF::resetloopFFEffect(TCHAR* name)
{
	UINT t_index;
	CIEffect* t_Effect;
	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect != NULL)
	{
		t_Effect->resetloop();
		return 0;
	}
	else return -1;
}

int DI::FF::isPlayFFEffect(TCHAR* name)
{
	UINT t_index;
	CIEffect* t_Effect;
	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect != NULL)
		return t_Effect->isPlay();
	else return -1;
}

int DI::FF::checkFFEffect(TCHAR* name)
{
	CIEffect* t_Effect;
	UINT t_index;
	t_Effect = MainEffect->findCIEffect(name,t_index);
	if (t_Effect != NULL) return 0;
	else return -1;
}

int DI::FF::setCurrentFFEffect(TCHAR* name)
{
	return FWUtils::HRESULT2INT(MainEffect->setCurEffect(name));
}

int DI::FF::getCurrentFFEffect(TCHAR* name)
{
	CIEffect* t_Eff;
	TCHAR t_str[MAX_PATH];
	HRESULT hr;
	t_Eff = MainEffect->getCurEffect();
	if (t_Eff != NULL)
	{
		if (FAILED(hr = MainEffect->getCIEffectName(t_Eff,t_str))) return -1;
		else
		{
			strcpy(name,t_str);
			return 0;
		};
	}
	else return 1;
}

int DI::FF::playFFEffect()
{
	if (MainEffect->getCurEffect() == NULL) return 1;
	MainEffect->getCurEffect()->play();
	return 0;
}

int DI::FF::setloopFFEffect()
{
	if (MainEffect->getCurEffect() == NULL) return 1;
	MainEffect->getCurEffect()->setloop();
	return 0;
}

int DI::FF::setloopFFEffect(DWORD const dloop)
{
	if (MainEffect->getCurEffect() == NULL) return 1;
	MainEffect->getCurEffect()->setloop(dloop);
	return 0;
}

int DI::FF::resetloopFFEffect()
{
	if (MainEffect->getCurEffect() == NULL) return 1;
	MainEffect->getCurEffect()->resetloop();
	return 0;
}

int DI::FF::isPlayFFEffect()
{
	if (MainEffect->getCurEffect() == NULL) return 1;
	return FWUtils::HRESULT2INT(MainEffect->getCurEffect()->isPlay());
}
