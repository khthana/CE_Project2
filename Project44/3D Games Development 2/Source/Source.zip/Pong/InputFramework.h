#ifndef INPUTFRAMEWORK_H
#define INPUTFRAMEWORK_H

#include "CInput.h"

enum DEVICETYPE
{
    ALL_TYPE = 0,
    KEY_TYPE = 1,
    MOUSE_TYPE = 2,
    JOY_TYPE = 3,
};

namespace DI
{
int init(HWND const hwnd);
void cleanup();

int getDeviceNum(DWORD& num);
int getDeviceNum(DEVICETYPE const type,DWORD& num);

int createDevice(DWORD& keyNum,DWORD& mouseNum,DWORD& joystickNum);
void destroyDevice();

int isAttatch(DEVICETYPE const type,DWORD const handle);
int enableDevice(DEVICETYPE const type,DWORD const handle);
int disableDevice(DEVICETYPE const type,DWORD const handle);

int getState(DWORD const handle,BYTE* pBuffer);
int getState(DWORD const handle,DIMOUSESTATE2& buffer);
int getState(DWORD const handle,DIJOYSTATE2& buffer);

namespace Param
{
int getInfoGuidProduct(DEVICETYPE const type,DWORD const handle,GUID& guidProduct);
int getInfoGuidFFDriver(DEVICETYPE const type,DWORD const handle,GUID& guidFFDriver);
int getInfoInstanceName(DEVICETYPE const type,DWORD const handle,TCHAR* tszInstanceName);
int getInfoProductName(DEVICETYPE const type,DWORD const handle,TCHAR* tszProductName);
int getInfoDeviceMainType(DEVICETYPE const type,DWORD const handle,DWORD& manintype);
int getInfoDeviceSubType(DEVICETYPE const type,DWORD const handle,DWORD& subtype);
int getInfoDeviceType(DEVICETYPE const type,DWORD const handle,DWORD& alltype);

int getFFSupport(DEVICETYPE const type,DWORD const handle);
int setFFPause(DEVICETYPE const type,DWORD const handle);
int setFFContinue(DEVICETYPE const type,DWORD const handle);
int setFFStop(DEVICETYPE const type,DWORD const handle);
int setFFReset(DEVICETYPE const type,DWORD const handle);
int setFFActuatorsON(DEVICETYPE const type,DWORD const handle);
int setFFActuatorsOFF(DEVICETYPE const type,DWORD const handle);
int getFFPause(DEVICETYPE const type,DWORD const handle);
int getFFActuatorsON(DEVICETYPE const type,DWORD const handle);
int getFFActuatorsOFF(DEVICETYPE const type,DWORD const handle);

int getInfoAxes(DEVICETYPE const type,DWORD const handle,DWORD& numAxes);
int getInfoPOVs(DEVICETYPE const type,DWORD const handle,DWORD& numPOVs);
int getInfoButtons(DEVICETYPE const type,DWORD const handle,DWORD& numButtons);
int setRange(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRange(DEVICETYPE const type,DWORD const handle,LONG& range);
int setDeadZone(DEVICETYPE const type,DWORD const handle,LONG const deadzone);
int getDeadZone(DEVICETYPE const type,DWORD const handle,LONG& deadzone);
int setSaturation(DEVICETYPE const type,DWORD const handle,LONG const saturation);
int getSaturation(DEVICETYPE const type,DWORD const handle,LONG& saturation);

int setRangeX(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRangeX(DEVICETYPE const type,DWORD const handle,LONG& range);
int setRangeY(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRangeY(DEVICETYPE const type,DWORD const handle,LONG& range);
int setRangeZ(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRangeZ(DEVICETYPE const type,DWORD const handle,LONG& range);
int setRangeRX(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRangeRX(DEVICETYPE const type,DWORD const handle,LONG& range);
int setRangeRY(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRangeRY(DEVICETYPE const type,DWORD const handle,LONG& range);
int setRangeRZ(DEVICETYPE const type,DWORD const handle,LONG const range);
int getRangeRZ(DEVICETYPE const type,DWORD const handle,LONG& range);
}

namespace FF
{
int createFFEffect(DEVICETYPE const type,DWORD const handle,TCHAR* name,const TCHAR* filename);
int clearFFEffect();
int destroyFFEffect(TCHAR* name);
CIEffAgent* cloneFFEffectAgent(TCHAR* name);
int playFFEffect(TCHAR* name);
int setloopFFEffect(TCHAR* name);
int setloopFFEffect(TCHAR* name,DWORD const dloop);
int resetloopFFEffect(TCHAR* name);
int isPlayFFEffect(TCHAR* name);
int checkFFEffect(TCHAR* name);

int setCurrentFFEffect(TCHAR* name);
int getCurrentFFEffect(TCHAR* name);
int playFFEffect();
int setloopFFEffect();
int setloopFFEffect(DWORD const dloop);
int resetloopFFEffect();
int isPlayFFEffect();
}
}

#ifndef CINPUT_H
class CIEffAgent
{
public:
	CIEffAgent();
	void cleanup();

	HRESULT play();
	HRESULT setloop();
	HRESULT setloop(DWORD const dloop);
	HRESULT resetloop();
	HRESULT isPlay();

	CIEffAgent* dupEffAgent();
	HRESULT getName(TCHAR* name);
	HRESULT settoCIEffect(TCHAR* name);
private:
	CIEffect* pCIEffect;
};
#endif

#endif
