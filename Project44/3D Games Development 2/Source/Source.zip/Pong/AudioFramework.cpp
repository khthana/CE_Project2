#include <afxwin.h>
#include "AudioFramework.h"
#include "FrameworEss.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int	DA::init(HWND hWnd)
{
	return FWUtils::HRESULT2INT(MainAudioFM->init(hWnd));
}

void DA::cleanup()
{
	MainAudioFM->cleanup();
}

int DA::Normal::create(TCHAR* filename,int& handle)
{
	return FWUtils::HRESULT2INT(MainAudioFM->addNM(filename,handle));
}

int DA::Normal::duplicate(int const s_handle,int& t_handle)
{
	return FWUtils::HRESULT2INT(MainAudioFM->cloneNM(s_handle,t_handle));
}
//int DAudio_duplicateNMSound(TCHAR* name,TCHAR* newsound,CANMSoundAgent& agent)
int DA::Normal::destroy(int const handle)
{
	return FWUtils::HRESULT2INT(MainAudioFM->eraseNM(handle));
}

int DA::Normal::check(int const handle)
{
	if (MainAudioFM->getNMSound(handle) != NULL) return 0;
	else return -1;
}

int DA::Normal::isPlay(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->isPlay());
}

int DA::Normal::getVolume(int const handle,LONG& vol)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	CAAudio* t_sound = MainAudioFM->getNMSound(handle);
	vol = t_sound->getVolume();
	return 0;
}

int DA::Normal::setVolume(int const handle,LONG const vol)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setVolume(vol));
}

void DA::Normal::play(int const handle)
{
	if (MainAudioFM->getNMSound(handle) != NULL)
	MainAudioFM->getNMSound(handle)->play();
}

void DA::Normal::stop(int const handle)
{
	if (MainAudioFM->getNMSound(handle) != NULL)
	MainAudioFM->getNMSound(handle)->stop();
}

int DA::Normal::load(int const handle,TCHAR* filename)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->load(filename));
}

int DA::Normal::setloop(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setloop());
}

int DA::Normal::setloop(int const handle,DWORD const loop)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setloop(loop));
}

int DA::Normal::resetloop(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->resetloop());
}

int DA::Normal::getloop(int const handle,DWORD& loop)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getloop(loop));
}

int DA::Normal::Effect::setChorus(int const handle,DSFXChorus const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setChorus(p));
}

int DA::Normal::Effect::setCompressor(int const handle,DSFXCompressor const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setCompressor(p));
}

int DA::Normal::Effect::setDistortion(int const handle,DSFXDistortion const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setDistortion(p));
}

int DA::Normal::Effect::setEcho(int const handle,DSFXEcho const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setEcho(p));
}

int DA::Normal::Effect::setFlanger(int const handle,DSFXFlanger const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setFlanger(p));
}

int DA::Normal::Effect::setGargle(int const handle,DSFXGargle const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setGargle(p));
}

int DA::Normal::Effect::setParameq(int const handle,DSFXParamEq const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setParameq(p));
}

int DA::Normal::Effect::setReverb(int const handle,DSFXWavesReverb const p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setReverb(p));
}

int DA::Normal::Effect::setChorus(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setChorus());
}

int DA::Normal::Effect::setCompressor(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setCompressor());
}

int DA::Normal::Effect::setDistortion(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setDistortion());
}

int DA::Normal::Effect::setEcho(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setEcho());
}

int DA::Normal::Effect::setFlanger(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setFlanger());
}

int DA::Normal::Effect::setGargle(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setGargle());
}

int DA::Normal::Effect::setParameq(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setParameq());
}

int DA::Normal::Effect::setReverb(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->setReverb());
}

int DA::Normal::Effect::getChorus(int const handle,DSFXChorus& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getChorus(p));
}

int DA::Normal::Effect::getCompressor(int const handle,DSFXCompressor& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getCompressor(p));
}

int DA::Normal::Effect::getDistortion(int const handle,DSFXDistortion& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getDistortion(p));
}

int DA::Normal::Effect::getEcho(int const handle,DSFXEcho& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getEcho(p));
}

int DA::Normal::Effect::getFlanger(int const handle,DSFXFlanger& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getFlanger(p));
}

int DA::Normal::Effect::getGargle(int const handle,DSFXGargle& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getGargle(p));
}

int DA::Normal::Effect::getParameq(int const handle,DSFXParamEq& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getParameq(p));
}

int DA::Normal::Effect::getReverb(int const handle,DSFXWavesReverb& p)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->getReverb(p));
}

int DA::Normal::Effect::isChorus(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isChorus() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isCompressor(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isCompressor() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isDistortion(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isDistortion() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isEcho(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isEcho() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isFlanger(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isFlanger() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isGargle(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isGargle() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isParameq(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isParameq() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isReverb(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isReverb() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::isEffect(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	if (MainAudioFM->getNMSound(handle)->isEffect() == TRUE) return 0;
	else return 1;
}

int DA::Normal::Effect::enableChorus(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableChorus());
}

int DA::Normal::Effect::enableCompressor(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableCompressor());
}

int DA::Normal::Effect::enableDistortion(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableDistortion());
}

int DA::Normal::Effect::enableEcho(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableEcho());
}

int DA::Normal::Effect::enableFlanger(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableFlanger());
}

int DA::Normal::Effect::enableGargle(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableGargle());
}

int DA::Normal::Effect::enableParameq(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableParameq());
}

int DA::Normal::Effect::enableReverb(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->enableReverb());
}

int DA::Normal::Effect::disableChorus(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableChorus());
}

int DA::Normal::Effect::disableCompressor(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableCompressor());
}

int DA::Normal::Effect::disableDistortion(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableDistortion());
}

int DA::Normal::Effect::disableEcho(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableEcho());
}

int DA::Normal::Effect::disableFlanger(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableFlanger());
}

int DA::Normal::Effect::disableGargle(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableGargle());
}

int DA::Normal::Effect::disableParameq(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableParameq());
}

int DA::Normal::Effect::disableReverb(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableReverb());
}

int DA::Normal::Effect::disableAllEffect(int const handle)
{
	if (MainAudioFM->getNMSound(handle) == NULL) return -1;
	return FWUtils::HRESULT2INT(MainAudioFM->getNMSound(handle)->disableAllEffect());
}

