#ifndef CAUDIOEX_H
#define CAUDIOEX_H

#define MainAudioFM CAFramework::getCAM ()

#pragma warning(disable:4786)

#include "CAudio.h"
#include "GenHandle.h"
#include <map>

using namespace std;

typedef map<int,CAAudio*> NmSoundMap;
typedef map<int,CA3daudio*> TdSoundMap;

class CAFramework:public CAManager
{
private:
	static CAFramework* CAM;

	NmSoundMap NMTable;
	TdSoundMap TDTable;
	HandleGen NMhdGen;
	HandleGen TDhdGen;

	int curNMHandle;
	int cur3DHandle;
public:
	CAFramework();

	void cleanup();

	HRESULT addNM(TCHAR* filename,int& handle);
	HRESULT cloneNM(int const handle,int& chandle); 
	HRESULT eraseNM(int const handle);

	HRESULT add3D(TCHAR* filename,int& handle);
	HRESULT clone3D(int const handle,int& chandle); 
	HRESULT erase3D(int const handle);

	HRESULT setNMCurrent(int const handle);
	HRESULT getNMCurrent(int& handle);

	HRESULT set3DCurrent(int const handle);
	HRESULT get3DCurrent(int& handle);

	CAAudio* getNMSound(int const handle);
	CA3daudio* get3DSound(int const handle);
	static CAFramework* getCAM();

};
#endif