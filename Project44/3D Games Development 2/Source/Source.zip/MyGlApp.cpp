/////////////////////////////////////////////////////////////////////////////
//
//	Copyright (c) 2001, Maetee Supreanruey and Anusorn Krasantisuk
//	All Rights Reserved.
//
//	This is UNPUBLISHED PROPRIETARY SOURCE CODE of Maetee Supreanruey 
//	and Anusorn Krasantisuk, the contents of this file may not be 
//	disclosed to third parties, copied or duplicated in any form, 
//	in whole or in part, without the prior written permission of 
//	Maetee Supreanruey and Anusorn Krasantisuk.
//
/////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "myglapp.h"
#include "d3dx8.h"
#include <Dxerr8.h>

//Engine
#include "Engine\GLGfx.h"
#include "Engine\Matrix.h"
#include "Engine\StaticModel.h"
#include "Engine\Texture.h"
#include "Engine\Triangle.h"
#include "Engine\EngineInterface.h"
#include "Engine\Text2D.h"
#include "Engine\DynamicModel.h"
#include "Engine\ModelData.h"
#include "Engine\staticmodeldata.h"
#include "Engine\Animation.h"
#include "Engine\EffectBillboardList.h"
#include "Engine\Sound.h"
//#include "ProjectileObject.h"

// Custom
#include "CChar.h"
//#include "Soldier.h"
//#include "Tree.h"
//#include "TreeList.h"
//#include "Camera2.h"	

#include "Pong\InputFramework.h"
#include "Pong\MediaFramework.h"
#include "Pong\AudioFramework.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CSLandModel SkyBox[6];
CSLandModel Plane;
CSLandModel Tower;

CSLandModel LCursor;
CSLandModel PCursor;

const MAX_COP = 3;
int Cop_Select = 0;

CChar Cop[MAX_COP];
CChar Wolf;

const MAXBUFF = 5;
int CopBufferSound[MAX_COP][MAXBUFF];

CEffectBillboardList EList;

CUseTexture YouWin,YouLose ;
CUseTexture CopBar,WolfBar ;

CIEffAgent* EffGun = NULL;
CIEffAgent* EffAttack = NULL;
HRESULT erH;
BOOL joyLeft = FALSE;
BOOL joyRight = FALSE;

BOOL isEnd = FALSE;
BOOL isWin = FALSE;

int joy;

GLfloat LightAmbient[]=		{ 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat LightDiffuse[]=		{ 1.0f, 0.80f, 0.520f, 1.0f };
GLfloat LightPosition[]=	{ 0.0f, 0.0f, 0.0f, 1.0f };

int g_nAmbRed	= 255;
int g_nAmbGreen = 248;
int g_nAmbBlue	= 220;

int g_nFogRed	= 171;
int g_nFogGreen = 183;
int g_nFogBlue	= 156;

float g_fFogStart = 271.0f;
float g_fFogEnd = 1750.340f;

float g_fV0 = 35.0f;


CMyGlApp::CMyGlApp(void):
CGLApplication()
{

	//joyLeft = FALSE;
	//joyRight = FALSE;

	m_MBLeft   = FALSE; // Left   Button
	m_MBMiddle = FALSE; // Middle Button	
	m_MBRight  = FALSE; // Right  Button

	ResetMBUp();

	m_MouseX = 10;
	m_MouseY = 10;

	//m_bFullscreen = TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default
	//m_nMode = 2;			// 800*600*32 Fullscreen

	 m_strTitle = "Game Engine Demo from Korkai Studio.";
	 m_bShoot = FALSE;


	m_calibase[0] = CPoint( 50, 200 );
	m_calibase[1] = CPoint( 338, 200 );
	m_calibase[2] = CPoint( 628, 200 );

	m_calibase[3] = CPoint( 50, 288 );
	m_calibase[4] = CPoint( 338, 288 ); 
	m_calibase[5] = CPoint( 628, 288 );

	m_calibase[6] = CPoint( 50, 377 );
	m_calibase[7] = CPoint( 338, 377 );
	m_calibase[8] = CPoint( 628, 377 );
}

CMyGlApp::~CMyGlApp(void)
{

}

HRESULT CMyGlApp::OneTimeSceneInit(void)
{
	//don't move out from Onetimescene (use texture for loading screen)
	CoInitialize(NULL);

	m_Mouse.UseTexture("Texture\\Mouse001.tga"); 
	
	// InitPort
	Port::InitPort();

	return S_OK;										// Everything Went OK
}

HRESULT CMyGlApp::FinalCleanup(void)
{
	// Close Port
	Port::ClosePort();

	DA::Normal::stop(0);
	DA::cleanup();
	DI::cleanup();
	DM::cleanup();

	CoUninitialize();
	return S_OK;										// Everything Went OK
}

HRESULT CMyGlApp::InitDeviceObjects(GLvoid)
{

	static BOOL  bFirstTime = TRUE;

	m_Camera.SetProjParams( D3DX_PI / 4.0f, 1.33f * m_fMonitor, 1.0f, 1000000000.0f );
	//m_Camera.SetProjParams( D3DX_PI * 14.0f / 180.0f, 1.66f * m_fMonitor, 1.0f, 1000000000.0f );

	if (bFirstTime)
	{
		bFirstTime = FALSE;
		
		DA::init(m_hWnd);
		//DI::init(m_hWnd);
		DM::init(m_hWnd);

		SetMode(2);

		/*
		RECT ScrRect;
		::GetClientRect( m_hWnd, &ScrRect );
		int ScrWidth  = ScrRect.right - ScrRect.left;
		int ScrHeight = ScrRect.bottom - ScrRect.top;
		
		int title1,title2,playt;
		LONGLONG max_pos,tv_pos;

		title1 = DM::Table::add("TITLE.MPG");
		title2 = DM::Table::add("TITLE2.MPG");
		DM::load(title1,playt);
		WINDOW_POS wi_pos;
		wi_pos.left = 0;
		wi_pos.top = 0;
		wi_pos.height = ScrHeight;
		wi_pos.width = ScrWidth;
		DM::setWindowPosition(wi_pos);
		DM::getStopPosition(max_pos);
		tv_pos = 0;
		DM::play();
		while (tv_pos < max_pos)
		{
			DM::getCurrentPosition(tv_pos);
		}
		DM::stop();
		DM::unload(playt);

		DM::load(title2,playt);
		DM::setWindowPosition(wi_pos);
		DM::getStopPosition(max_pos);
		tv_pos = 0;
		DM::play();
		while (tv_pos < max_pos)
		{
			DM::getCurrentPosition(tv_pos);
		}
		DM::stop();
		DM::unload(playt);
		*/

		int t_sound;
		DA::Normal::create("BGM.wav",t_sound);
		DA::Normal::setloop(t_sound);
		DA::Normal::setVolume(t_sound,95);
		DA::Normal::play(t_sound);
		
		ShowLoading(0.0f,"Wait for loading");

		// Set Up Camera
		m_Camera.SetParamsSystem1(  3.390f,31.542f, -71.169f,
								    -38.603783f,39.413685f, -101.286095f,
								    0.0f,1.0f,0.0f );
		D3DXVECTOR3 v,l,u;
		v.x = 0; v.y = 10.0f; v.z = 13;
		l.x = 0; l.y = -0.0f; l.z = 0;
		u.x = 0, u.y = 20; u.z = -40;
		m_Camera.SetViewParams(v,l,u);

		ShowLoading(30.0f,"Load Model");

		SkyBox[0].LoadModel("Frame\\SkyBox\\PNegX.maf");
		SkyBox[0].SetRotation(-90,90,0);

		SkyBox[1].LoadModel("Frame\\SkyBox\\PNegY.maf");

		SkyBox[2].LoadModel("Frame\\SkyBox\\PNegZ.maf");
		SkyBox[2].SetRotation(-90,90,90);

		SkyBox[3].LoadModel("Frame\\SkyBox\\PPosX.maf");
		SkyBox[3].SetRotation(-90,90,180);

		SkyBox[4].LoadModel("Frame\\SkyBox\\PPosY.maf");
		SkyBox[4].SetRotation(-180,0,180); 

		SkyBox[5].LoadModel("Frame\\SkyBox\\PPosZ.maf");
		SkyBox[5].SetRotation(-90,90,270);

		for(int i=0;i<=5;i++)
		{
			//SkyBox[i].SetPosition(-40,40,-100);
			SkyBox[i].SetScale(20,20,20);
		}

		Tower.LoadModel("Frame\\Tower.maf");
		Tower.SetPosition(0,0,0);

		LCursor.LoadModel("Frame\\LCursor.maf");
		LCursor.SetPosition(0.0f ,3.5f,0.0f);
		LCursor.SetScale(0.5f,0.5f,0.5f);
		
		for (int j=0;j<MAX_COP;j++)
		{
			Cop[j].LoadModel("AnimationSet\\Cop.mas");
			Cop[j].ChangeStatus(STOP);
			Cop[j].SetRange(4.0f);
			Cop[j].SetVelocity(1.2f);
			Cop[j].SetPower(4);
			Cop[j].SetHP(100);
		}
		Cop[0].SetPosition(5.0f,3.3f,6.0f);
		Cop[1].SetPosition(-4.5f,3.3f,6.5f); 
		Cop[2].SetPosition(-5.5f,3.3f,-4.0f); 

		PCursor.LoadModel("Frame\\PCursor.maf");
		PCursor.SetPosition(Cop[Cop_Select].Px(),Cop[Cop_Select].Py()+2.0f,Cop[Cop_Select].Pz());
		PCursor.SetScale(0.5f,0.5f,0.5f);

		Wolf.LoadModel("AnimationSet\\Wolf.mas");
		Wolf.SetScale(0.06f,0.06f,0.06f);
		Wolf.SetRotation(0,0,-90);
		Wolf.ChangeStatus(STOP);
		Wolf.SetRange(1.0f);
		Wolf.SetVelocity(1.8f);
		Wolf.SetPower(6);
		Wolf.SetHP(150);
		//Wolf.SetPosition(-2,4.2f,0); //Walk
		Wolf.SetPosition(-2,4.7f,0); //Stand & Dead

		//-----------2d Texture------------
		ShowLoading(50.0f,"Load Texture");

		YouLose.Use("Texture\\Lose.tga");
		YouWin.Use("Texture\\Win.tga");
		CopBar.Use("Texture\\manHP.tga");
		WolfBar.Use("Texture\\wolfHP.tga");

		//------------- Sound ------------
		ShowLoading(80.0f,"Load Sound and Music");

		D3DVECTOR t_pos;
		for (int a=0;a<MAX_COP;a++)
		{
			DA::ThreeD::create("Sound\\m16.wav",Cop[a].AttackID);
			DA::ThreeD::create("Sound\\die.wav",Cop[a].DieID);
			t_pos.x = Cop[a].Px();
			t_pos.y = Cop[a].Py();
			t_pos.z = Cop[a].Pz();
			DA::ThreeD::Param3D::setPosition(Cop[a].AttackID,t_pos);
			DA::ThreeD::Param3D::setPosition(Cop[a].DieID,t_pos);
			//DA::ThreeD::Param3D::setNormalMode(Cop[a].AttackID);
			//DA::ThreeD::Param3D::setNormalMode(Cop[a].DieID);

			DA::ThreeD::Param3D::setMaxDistance(Cop[a].AttackID,0.1f);
			DA::ThreeD::Param3D::setMinDistance(Cop[a].AttackID,4.0f);

			//DSFXWavesReverb r_param;
			//r_param.fInGain = 0;
			//r_param.fReverbMix = 0;
			//r_param.fReverbTime = 3000.0f;
			//r_param.fHighFreqRTRatio = 0.5f;
			//DA::ThreeD::Effect::enableReverb(Cop[a].AttackID);
			//DA::ThreeD::Effect::setReverb(Cop[a].AttackID,r_param);
			DSFXEcho e_param;
			e_param.fWetDryMix = 50.0f;
			e_param.fFeedback = 50.0f;
			e_param.fLeftDelay = 500.0f;
			e_param.fRightDelay = 500.0f;
			e_param.lPanDelay = 0;
			DA::ThreeD::Effect::enableEcho(Cop[a].DieID);
			DA::ThreeD::Effect::setEcho(Cop[a].DieID,e_param);	

			DA::ThreeD::Param3D::setMaxDistance(Cop[a].DieID,0.1f);
			DA::ThreeD::Param3D::setMinDistance(Cop[a].DieID,4.0f);
			for (int c=0;c<MAXBUFF;c++)
				DA::ThreeD::duplicate(Cop[a].AttackID,CopBufferSound[a][c]);
		}

		DA::ThreeD::create("Sound\\fight.wav",Wolf.AttackID);
		DA::ThreeD::create("Sound\\wolfdie.wav",Wolf.DieID);
		t_pos.x = Wolf.Px();
		t_pos.y = Wolf.Py();
		t_pos.z = Wolf.Pz();
		DA::ThreeD::Param3D::setPosition(Wolf.AttackID,t_pos);
		DA::ThreeD::Param3D::setPosition(Wolf.DieID,t_pos);
		//DA::ThreeD::Param3D::setNormalMode(Wolf.AttackID);
		//DA::ThreeD::Param3D::setNormalMode(Wolf.DieID);

		DA::ThreeD::Param3D::setMaxDistance(Wolf.AttackID,0.1f);
		DA::ThreeD::Param3D::setMinDistance(Wolf.AttackID,4.0f);
		DA::ThreeD::Param3D::setMaxDistance(Wolf.DieID,0.1f);
		DA::ThreeD::Param3D::setMinDistance(Wolf.DieID,4.0f);

		D3DXVECTOR3 t_eye = m_Camera.GetEyePt();
		D3DVECTOR t_reye;
		t_reye.x = t_eye.x;
		t_reye.y = t_eye.y;
		t_reye.z = t_eye.z;
		DA::ThreeD::Listener::setPosition(t_reye);

		DA::ThreeD::Listener::setDoppler(1.0f);
		DA::ThreeD::Listener::setRolloff(1.0f);

		ShowLoading(100.0f,"Finished");
	}

	//------------- Enable Input------------
	//DI::enableDevice(KEY_TYPE,0);
	//DI::enableDevice(MOUSE_TYPE,0);
	
	//DWORD a,b,c;
	//DI::createDevice(a,b,c);
	DI::cleanup();
	if (EffGun != NULL)
	{
		EffGun->cleanup();
		SAFE_DELETE(EffGun);
	}
	if (EffAttack != NULL)
	{
		EffAttack->cleanup();
		SAFE_DELETE(EffAttack);
	}
	DI::FF::clearFFEffect();

	DI::init(m_hWnd);
	DWORD joyNum;
	DI::getDeviceNum(JOY_TYPE,joyNum);
	if (joyNum >= 1)
	{
		if (DI::Param::getFFSupport(JOY_TYPE,0) == 0)
		{
			DI::FF::createFFEffect(JOY_TYPE,0,"Gun","Gun.ffe");
			DI::FF::createFFEffect(JOY_TYPE,0,"Attack","Attack.ffe");
			if (EffGun == NULL) EffGun = DI::FF::cloneFFEffectAgent("Gun");
			if (EffAttack == NULL) EffAttack = DI::FF::cloneFFEffectAgent("Attack");
		}
		DI::enableDevice(JOY_TYPE,0);
		DI::Param::setRange(JOY_TYPE,0,1000);
	}
	if (EffGun != NULL) joy = EffGun->play();
	if (EffAttack != NULL) joy = EffAttack->play();
	
	glShadeModel( GL_SMOOTH );							// Enable Smooth Shading
	/*
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do*/
	
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	

	//ModelSky.SetScale( 1000,1000,1000 );
	//ModelBox.SetScale( 0.07f, 0.07f, 0.07f );


	glEnable( GL_CULL_FACE );
	glCullFace( GL_FRONT );

	//glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	//glDepthFunc(GL_LESS);								// The Type Of Depth Testing To Do
	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping ( NEW )

//	Blend01.LoadFrame("Frame\\man_001.maf","Frame\\man_002.maf");

	
	glLightfv(GL_LIGHT0, GL_AMBIENT, LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT0, GL_DIFFUSE, LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT0, GL_POSITION,LightPosition);	// Position The Light
//aa	glEnable(GL_LIGHTING);
//aa	glEnable(GL_LIGHT0);								// Enable Light One
	//glNormal3f(0.0f,0.0f,0.0f);*/
	glDisable(GL_LIGHTING);

	return S_OK;										// Everything Went OK
}

HRESULT CMyGlApp::DeleteDeviceObjects(GLvoid)
{
	//DI::disableDevice(KEY_TYPE,0);
	//DI::disableDevice(MOUSE_TYPE,0);
	//DI::disableDevice(JOY_TYPE,0);
	//DI::destroyDevice();
	return S_OK;										// Everything Went OK
}

HRESULT CMyGlApp::FrameMove(GLvoid)
{
	CEngineInterface::AddLogicalTime( m_fElapsedTime );

	ProcessKey( m_fElapsedTime );
	static double Angle = 0;
	Angle += m_fElapsedTime * 20;
	static float x = 5.0f;
	static float z = 5.0f;
	static float High;

	BYTE Data[10];
	if( Port::ReadData( 10, Data ) )
	{
		ProcessComData( Data );
	}

	Cop[0].ProcessMove(m_fElapsedTime);
	Cop[1].ProcessMove(m_fElapsedTime);
	Cop[2].ProcessMove(m_fElapsedTime);
	
	if ((Wolf.CanAttack(&Cop[Cop_Select]) == TRUE) && (Cop[Cop_Select].GetStatus() != DEAD))
	{
		if (Wolf.GetCurrentAnimationTime() >= Wolf.GetCurrentMaxTime())
		{
			if (EffAttack != NULL) joy = EffAttack->play();
			//DI::FF::playFFEffect("Attack");
			D3DVECTOR t_pos;
			t_pos.x = Wolf.Px();
			t_pos.y = Wolf.Py();
			t_pos.z = Wolf.Pz();
			DA::ThreeD::Param3D::setPosition(Wolf.AttackID,t_pos);
			//DA::ThreeD::Param3D::setPosition(Wolf.DieID,t_pos);

			Wolf.ChangeStatus(FIRE);
			Wolf.Attack(&Cop[Cop_Select]);
			//DA::ThreeD::play(Wolf.AttackID);

			if (Cop[Cop_Select].IsAlive() == FALSE)
			{
				D3DVECTOR t_pos;
				t_pos.x = Cop[Cop_Select].Px();
				t_pos.y = Cop[Cop_Select].Py();
				t_pos.z = Cop[Cop_Select].Pz();
				//DA::ThreeD::Param3D::setPosition(Cop[Cop_Select].AttackID,t_pos);
				DA::ThreeD::Param3D::setPosition(Cop[Cop_Select].DieID,t_pos);

				if (DA::ThreeD::isPlay(Cop[Cop_Select].DieID) != 0)
					DA::ThreeD::play(Cop[Cop_Select].DieID);

				EList.Add("Texture\\blood.tga",
						Cop[Cop_Select].Px(), Cop[Cop_Select].Py()+1.0f, Cop[Cop_Select].Pz(),
						Cop[Cop_Select].Px(), Cop[Cop_Select].Py()+1.25f, Cop[Cop_Select].Pz(),
						1.0f, 0.0f,
						1.0f, 4.5f,
						float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f,01.0f,
						float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f,0.0f,
						0.25f);
			}
		};
	}
	else if (Cop[Cop_Select].GetStatus() == DEAD)
	{
		Wolf.ChangeStatus(STOP);
	}
	else 
	{	
		//Wolf.SetRotation(0,0,180);
		if (Wolf.IsAlive() == TRUE)
		{
			Wolf.FaceTo(Cop[Cop_Select].Px(),Cop[Cop_Select].Pz());
			Wolf.SetRotation(Wolf.Row(),Wolf.Phi(),Wolf.Zetha() + 270);
			Wolf.SetDestination(Cop[Cop_Select].Px()-0.5f,Cop[Cop_Select].Pz()-0.5f);
		}
		if (Wolf.GetStatus() != WALK) 
		{
			Wolf.ChangeStatus(WALK);
		}
	}

	BOOL isCopsDead = FALSE;
	for (int e=0;e<=MAX_COP;e++)
	{
		if (Cop[e].IsAlive() == TRUE)
		{
			isCopsDead = TRUE;
			break;
		}
	}
	if (isCopsDead == FALSE) 
		{	
			isEnd = TRUE;
			isWin = FALSE;
		}

	Wolf.ProcessMove(m_fElapsedTime);

	//------------------Sound-------------
	//D3DVECTOR t_pos;
	//for (int a=0;a<MAX_COP;a++)
	//{
	//	t_pos.x = Cop[a].Px();
	//	t_pos.y = Cop[a].Py();
	//	t_pos.z = Cop[a].Pz();
	//	DA::ThreeD::Param3D::setPosition(Cop[a].AttackID,t_pos);
	//	DA::ThreeD::Param3D::setPosition(Cop[a].DieID,t_pos);
	//	for (int c=0;c<MAXBUFF;c++)
	//		DA::ThreeD::Param3D::setPosition(CopBufferSound[a][c],t_pos);
	//}
		//t_pos.x = Cop[Cop_Select].Px();
		//t_pos.y = Cop[Cop_Select].Py();
		//t_pos.z = Cop[Cop_Select].Pz();
		//DA::ThreeD::Param3D::setPosition(Cop[Cop_Select].AttackID,t_pos);
		//DA::ThreeD::Param3D::setPosition(Cop[Cop_Select].DieID,t_pos);
		//for (int c=0;c<MAXBUFF;c++)
		//	DA::ThreeD::Param3D::setPosition(CopBufferSound[Cop_Select][c],t_pos);

	//t_pos.x = Wolf.Px();
	//t_pos.y = Wolf.Py();
	//t_pos.z = Wolf.Pz();
	//DA::ThreeD::Param3D::setPosition(Wolf.AttackID,t_pos);
	//DA::ThreeD::Param3D::setPosition(Wolf.DieID,t_pos);

	D3DXVECTOR3 t_eye = m_Camera.GetEyePt();
	D3DVECTOR t_reye;
	t_reye.x = t_eye.x;
	t_reye.y = t_eye.y;
	t_reye.z = t_eye.z;
	DA::ThreeD::Listener::setPosition(t_reye);

	D3DXVECTOR3 fort_c,tort_c;
	D3DVECTOR fort,tort;
	fort_c = m_Camera.GetLookatPt();
	fort.x = fort_c.x;
	fort.y = fort_c.y;
	fort.z = fort_c.z;
	tort_c = m_Camera.GetUpVec();
	tort.x = tort_c.x;
	tort.y = tort_c.y;
	tort.z = tort_c.z;
	DA::ThreeD::Listener::setOrientation(fort,tort);


	//LCursor.SetPosition(LCursor_pos.x,LCursor_pos.y,LCursor_pos.z);
	return S_OK;										// Everything Went OK
}

//CEffectBillboardList CloudList;

HRESULT CMyGlApp::Render(GLvoid)
{


	//===================R==============G=============B
	float fogColor[4] = {g_nFogRed/255.0f,g_nFogGreen/255.0f,g_nFogBlue/255.0f,1.0f};
	glFogi(GL_FOG_MODE, GL_LINEAR);			// Fog Mode
	glFogfv(GL_FOG_COLOR, fogColor);					// Set Fog Color
	//glFogf(GL_FOG_DENSITY, g_fFogDen);						// How Dense Will The Fog Be
	glHint(GL_FOG_HINT, GL_DONT_CARE);					// Fog Hint Value
	glFogf(GL_FOG_START, g_fFogStart);							// Fog Start Depth
	glFogf(GL_FOG_END, g_fFogEnd);							// Fog End Depth
	glEnable(GL_FOG);									// Enables GL_FOG



	// UseFul Data
	RECT ScrRect;
	::GetClientRect( m_hWnd, &ScrRect );
	int ScrWidth  = ScrRect.right - ScrRect.left;
	int ScrHeight = ScrRect.bottom - ScrRect.top;

	// Camera View
	m_Camera.View();

	// Clear Scene
//	ModelBox.Render();

	GLGfx::Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

 		//glDrawArrays(GL_QUADS, 0, 40);
		//glDrawElements( GL_TRIANGLES, 6, GL_UNSIGNED_INT, arIndices ); 
	glDisable(GL_FOG);									// Disables GL_FOG
//	glColor3f(0.6f,0.45f,0.45f);
	glColor3f(float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f);

	//ModelSky.Render();
	glEnable(GL_FOG);									// Enables GL_FOG

//	mdlShadowCylinder.Render();

	// Setup light
	//LightModel.Render();


//	glColor3f(0.5f,0.4f,0.4f);
	glColor3f(float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f);


	//ModelLand.Render();

	glDepthMask(1);
	//glColorMask(FALSE,FALSE,FALSE,FALSE);

	//========================Render Land=============================
/*	glEnable(GL_STENCIL_TEST);
	glStencilFunc(GL_ALWAYS, 1, 0xffffffff);
	glStencilOp( GL_KEEP, GL_KEEP, GL_REPLACE );*/

	//ModelLand.Render();
	//================================================================
	//ModelLand.Render();
	//glColorMask(TRUE,TRUE,TRUE,TRUE);


	//Soldier01.SetPosition( -2, 0, 0 );
	//Soldier01.Render();

	//========================Render Soldier==========================
	//SoldierList.Render(&m_Camera);	
	//glDisable(GL_STENCIL_TEST);
	//================================================================

	//arProjectileObject.Render();

	glEnable(GL_BLEND);
	//glEnable(GL_ALPHA_TEST);
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );	// Select The Type Of Blending
	//glAlphaFunc(GL_GREATER,0.0f);
	//glColor4f(1.0f,1.0f,1.0f, ( Math::Sinf(m_fTime*3.0f)+1.0f )/2.0f);


	glDisable(GL_BLEND);


	glColor3f(float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f);
	D3DXVECTOR3 vCamera = m_Camera.GetEyePt();
	//ModelTreeList.RenderAll( vCamera , &m_Camera.GetBillboardMatrix() );


	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	glEnable( GL_CULL_FACE );
	glCullFace( GL_FRONT );
	
	D3DXVECTOR3 cPos  = m_Camera.CCamera::GetEyePt();	
	for(int i=0;i<=5;i++)
	{	
		SkyBox[i].SetPosition(cPos.x,cPos.y,cPos.z);
		SkyBox[i].Render();
	}

	//Cop.FaceTo(LCursor.Px(),LCursor.Pz());
	//Cop.CalculateMoving(LCursor.Px(),LCursor.Pz(),1.0f,m_fElapsedTime);
	//for(int j=0;j<MAX_COP;j++)
	//{
	Cop[0].Render();
	Cop[1].Render();
	Cop[2].Render();

	//}

	Wolf.Render();
	Tower.Render();
	LCursor.Render();

	PCursor.SetPosition(Cop[Cop_Select].Px(),Cop[Cop_Select].Py()+2.0f,Cop[Cop_Select].Pz());
	PCursor.Render();

	glDisable(GL_LIGHTING);				 
	glEnable(GL_BLEND);
	glDepthMask(0);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	EList.Render(m_Camera.GetBillboardMatrix());
	glDepthMask(1);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);

	//ModelCop.SetPosition(-40,50,-100);
	//ModelCop.SetPosition( -6.0f + float((nCount/10)/1.0f), 0, 2.0f - (nCount%10) );
	//GLGfx::SetMatWorld(&ModelCop.GetMat());		
	//Cop_w.Render(m_fElapsedTime);

//	ModelBox.Render();

	//CString strSoldierPart;
	//D3DXVECTOR3 RayOrigin, RayDirection;
	//Ray::ScrToRay( m_MouseX, m_MouseY, ScrWidth, ScrHeight, &m_Camera, &RayOrigin, &RayDirection );

	/*if( m_MBLeft )
	{
		CTriangle TriHit;
		float U, V;
		if( ModelLand.RayTest( RayOrigin, RayDirection, NULL, &TriHit, NULL, &U, &V ) )
		{

		}

	}*/

	// -------- Mouse Zone --------------
	static float fPrevTime = m_fTime;

	//int ShootX, ShootY;
	if( (m_MBLeft) || (joyLeft) )
	{
	//	//ShootX = m_MouseX;
		//ShootY = m_MouseY;
		Cop[Cop_Select].ChangeStatus(WALK);
		Cop[Cop_Select].FaceTo(LCursor.Px(),LCursor.Pz());
		Cop[Cop_Select].SetDestination(LCursor.Px(),LCursor.Pz());

	}
	//else if ( m_bShoot )
	//{
		//ShootX = int(m_shootx);
		//ShootY = int(m_shooty);		
	//}
	if ((( m_MBRight ) || (joyRight))&& (isEnd == FALSE))
	{
		if (Cop[Cop_Select].GetStatus() != DEAD)
		{
		//erH = DI::enableDevice(JOY_TYPE,0);
		if (EffGun != NULL) joy = EffGun->play();
		//DI::FF::playFFEffect("Gun");
		
		D3DVECTOR t_pos;
		t_pos.x = Cop[Cop_Select].Px();
		t_pos.y = Cop[Cop_Select].Py();
		t_pos.z = Cop[Cop_Select].Pz();
		DA::ThreeD::Param3D::setPosition(Cop[Cop_Select].AttackID,t_pos);
		//DA::ThreeD::Param3D::setPosition(Cop[Cop_Select].DieID,t_pos);
		for (int c=0;c<MAXBUFF;c++)
			DA::ThreeD::Param3D::setPosition(CopBufferSound[Cop_Select][c],t_pos);

		if (DA::ThreeD::isPlay(Cop[Cop_Select].AttackID) != 0)
		{
			DA::ThreeD::play(Cop[Cop_Select].AttackID);
		}
		else
			for (int b=0;b<MAXBUFF;b++)
			{
				if (DA::ThreeD::isPlay(CopBufferSound[Cop_Select][b]) != 0)
				{
					DA::ThreeD::play(CopBufferSound[Cop_Select][b]);
					break;
				}
			};
			if (Cop[Cop_Select].CanAttack(&Wolf) == FALSE)
			{
				EList.Add("Texture\\Cloud.tga",
						LCursor.Px(), LCursor.Py(), LCursor.Pz(),
						LCursor.Px(), LCursor.Py(), LCursor.Pz(),
						0.0f, 0.0f,
						1.0f, 2.5f,
						float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f,01.0f,
						float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f,0.0f,
						0.5f);
			}
			else
			{
				EList.Add("Texture\\blood.tga",
						Wolf.Px(), Wolf.Py()+1.0f, Wolf.Pz(),
						Wolf.Px()+1.0f, Wolf.Py()+1.5f, Wolf.Pz(),
						1.0f, 1.0f,
						3.0f, 6.5f,
						float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f,01.0f,
						float(g_nAmbRed)/255.0f,float(g_nAmbGreen)/255.0f,float(g_nAmbBlue)/255.0f,0.0f,
						0.4f);
			};

		if (Cop[Cop_Select].GetCurrentAnimationTime() >= Cop[Cop_Select].GetCurrentMaxTime())
		{
			if (Cop[Cop_Select].IsAlive() == TRUE)
			{
			Cop[Cop_Select].FaceTo(LCursor.Px(),LCursor.Pz());
			Cop[Cop_Select].ChangeStatus(FIRE);
			Cop[Cop_Select].Attack(&Wolf);

			D3DVECTOR t_pos;
			t_pos.x = Wolf.Px();
			t_pos.y = Wolf.Py();
			t_pos.z = Wolf.Pz();
			DA::ThreeD::Param3D::setPosition(Wolf.AttackID,t_pos);
			//DA::ThreeD::Param3D::setPosition(Wolf.DieID,t_pos);
			if (Wolf.IsAlive() == FALSE)
					DA::ThreeD::play(Wolf.DieID);
			}
		}}

		if (Wolf.IsAlive() == FALSE) 
		{	
			isEnd = TRUE;
			isWin = TRUE;
		}
	}
	
	D3DXVECTOR3 cam_vec = m_Camera.GetEyePt() - m_Camera.GetLookatPt();
	Vec3::Normalize(&cam_vec,&cam_vec);
	cam_vec.x = -((((float(m_MouseX)/float(ScrWidth))*25.0f)-10) + cam_vec.x);
	cam_vec.z = (((float(m_MouseY)/float(ScrHeight))*25.0f)-10) + cam_vec.z;
	cam_vec.y = 3.5f;
	if (cam_vec.x >= 6.0f) cam_vec.x = 6.0f;
	if (cam_vec.x <= -6.0f) cam_vec.x = -6.0f;
	if (cam_vec.z >= 9.0f) cam_vec.z = 9.0f;
	if (cam_vec.z <= -9.0f) cam_vec.z = -9.0f;
	LCursor.SetPosition(cam_vec.x,cam_vec.y,cam_vec.z);
	
	//TwoD begin
	/////////////////////////////////////////////////////////////////////////////////
	// TwoD Zone
	/////////////////////////////////////////////////////////////////////////////////
	CCamera Camera2D;
	Camera2D.SetParamsSystem1(	0.0f, 0.0f, 0.0f,
								0.0f, 0.0f, 1.0f,
								0.0f, 1.0f, 0.0f	);

	GLGfx::SetMatWorld(&cs::IMat);
	Camera2D.View();

	BOOL bIsEnable_DepthTest = glIsEnabled(GL_DEPTH_TEST);
	glDisable(GL_DEPTH_TEST);							// Disables Depth Testing

	glDisable(GL_LIGHTING);

		//Tex1.Use("Texture\\SignalandNumber.bmp");
		//Engine::TwoDZone::PutPictureIn2D( &Tex1,0,0,0.5f,0.5f,0.0f,0.0f,0.0f,01.0f,01.0f);
		char sz[255];
		//char* sz;
		//sprintf(sz,"%.2f ?????????????",m_fFPS);
		//CText2D::Putstring(sz,0.01f,0.012f,0,0xffffffff);

		//Engine::TwoDZone::CText2D::Putstring("Font thai Engine ??????????",0.07f,0.9f,0,0xffffffff);

		m_Mouse.SetMousePos( m_MouseX, m_MouseY, ScrWidth, ScrHeight );
		//float fMouseDepth = 0.0f;
		//glReadPixels( 0, 0, ScrWidth, ScrHeight, GL_DEPTH_COMPONENT, GL_FLOAT, &fMouseDepth );
 		//sprintf( sz, "Depth = %f", fMouseDepth );
		//CText2D::Putstring(sz,0.01f,0.112f,0,0xffffffff);

		int x =  int(((Math::Sinf(m_fTime*2.0f)+1.0f)/2.0f)*255.0f);
		x = x & (0x000000ff);
		
		/*
		if ( m_arKey['W'] ) g_nAmbRed++;
		if ( m_arKey['S'] ) g_nAmbRed--;
		if ( g_nAmbRed > 255 ) g_nAmbRed = 255;
		if ( g_nAmbRed < 0 )   g_nAmbRed = 0;

		if ( m_arKey['E'] ) g_nAmbGreen++;
		if ( m_arKey['D'] ) g_nAmbGreen--;
		if ( g_nAmbGreen > 255 ) g_nAmbGreen = 255;
		if ( g_nAmbGreen < 0 )   g_nAmbGreen = 0;

		if ( m_arKey['R'] ) g_nAmbBlue++;
		if ( m_arKey['F'] ) g_nAmbBlue--;
		if ( g_nAmbBlue > 255 ) g_nAmbBlue = 255;
		if ( g_nAmbBlue < 0 )   g_nAmbBlue = 0;


		if ( m_arKey['T'] ) g_nFogRed++;
		if ( m_arKey['V'] ) g_nFogRed--;
		if ( g_nFogRed > 255 ) g_nFogRed = 255;
		if ( g_nFogRed < 0 )   g_nFogRed = 0;

		if ( m_arKey['Y'] ) g_nFogGreen++;
		if ( m_arKey['H'] ) g_nFogGreen--;
		if ( g_nFogGreen > 255 ) g_nFogGreen = 255;
		if ( g_nFogGreen < 0 )   g_nFogGreen = 0;

		if ( m_arKey['U'] ) g_nFogBlue++;
		if ( m_arKey['J'] ) g_nFogBlue--;
		if ( g_nFogBlue > 255 ) g_nFogBlue = 255;
		if ( g_nFogBlue < 0 )   g_nFogBlue = 0;

		if ( m_arKey['I'] ) g_fFogStart+= m_fElapsedTime * 150.0f;
		if ( m_arKey['K'] ) g_fFogStart-= m_fElapsedTime * 150.0f;
		if ( g_fFogStart > g_fFogEnd ) g_fFogStart = g_fFogEnd;
		if ( g_fFogStart < 0.0f ) g_fFogStart = 0.0f;

		if ( m_arKey['O'] ) g_fFogEnd+= m_fElapsedTime * 150.0f;
		if ( m_arKey['L'] ) g_fFogEnd-= m_fElapsedTime * 150.0f;
		if ( g_fFogEnd > 15000.0f ) g_fFogEnd = 15000.0f;
		if ( g_fFogEnd < g_fFogStart ) g_fFogEnd = g_fFogStart;

		
		if ( m_arKey['N'] ) g_fV0+= m_fElapsedTime * 10;
		if ( m_arKey['M'] ) g_fV0-= m_fElapsedTime * 10;
		if ( g_fV0 > 500.0f ) g_fV0 = 500.0f;
		if ( g_fV0 < 1.0f )   g_fV0 = 1.0f;
		*/

		static BOOL bShowData = TRUE;
		static BOOL bPressedF12 = FALSE;

		if ( m_arKey[VK_F12] && (! bPressedF12) )
		{
			bPressedF12 = TRUE;
			bShowData = ! bShowData;
		}

		if ( (! m_arKey[VK_F12]) && ( bPressedF12) )
		{
			bPressedF12 = FALSE;
		}
		
		if (isEnd == TRUE)
		{
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA,GL_ONE);
			glColor3f(1.0f,1.0f,1.0f);

			if (isWin == TRUE)
			{
				CText2D::PutPictureIn2D(&YouWin,0.25f,0.4f,0.75f,0.6f,0.0f,0.0f,0.0f,1.0f,1.0f); 
			}
			else
			{
				CText2D::PutPictureIn2D(&YouLose,0.25f,0.4f,0.75f,0.6f,0.0f,0.0f,0.0f,1.0f,1.0f); 
			}
			glDisable(GL_BLEND);
		}

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glColor3f(1.0f,1.0f,1.0f);
		CText2D::PutPictureIn2D(&CopBar,0,0,0.3f,0.07f,0.0f,0.0f,0.0f,1.0f,1.0f); 
		CText2D::PutPictureIn2D(&WolfBar,0.7f,0,1.0f,0.07f,0.0f,0.0f,0.0f,1.0f,1.0f); 
		glDisable(GL_BLEND);
	
		sprintf(sz,"����: %i ",Cop[Cop_Select].getHP());
		CText2D::Putstring(sz,0.04f,0.02f,0,0xffffffff);

		sprintf(sz,"��һ��: %i ",Wolf.getHP());
		CText2D::Putstring(sz,0.74f,0.02f,0,0xffffffff);

		if ( bShowData )
		{
			//D3DVECTOR t_v;
			//DA::ThreeD::Listener::getPosition(t_v);
			//sprintf(sz,"Listener = %f , %f , %f ",t_v.x,t_v.y,t_v.z);
			//CText2D::Putstring(sz,0.01f,0.852f,0,0xffffffff);

			//sprintf(sz,"%d",key);
			//sz = DXGetErrorDescription8(key);

			//D3DVECTOR fort,tort;
			//DA::ThreeD::Listener::getOrientation(fort,tort);
			//sprintf(sz,"%d",er);

			//CText2D::Putstring(DXGetErrorDescription8(DIERR_INCOMPLETEEFFECT),0.01f,0.952f,0,0xffffffff);

			//sprintf(sz,"%d" ,erH);
			//mCText2D::Putstring(DXGetErrorDescription8(joy),0.01f,0.852f,0,0xffffffff);

			//sprintf(sz,"Fog R = %d ,G = %d , B = %d",g_nFogRed,g_nFogGreen,g_nFogBlue);
			//CText2D::Putstring(sz,0.01f,0.902f,0,0xffffffff);

			//sprintf(sz,"Ambient R = %d ,G = %d , B = %d",g_nAmbRed,g_nAmbGreen,g_nAmbBlue);
			//CText2D::Putstring(sz,0.01f,0.952f,0,0xffffffff);

			//D3DXVECTOR3 vEyeAt  = m_Camera.CCamera::GetEyePt();
			//D3DXVECTOR3 vLookAt = m_Camera.CCamera::GetLookatPt();

			//sprintf(sz,"Camera At %f, %f, %f", vEyeAt.x, vEyeAt.y, vEyeAt.z );
			//CText2D::Putstring(sz,0.01f,0.1f,0,0xffffffff);
			
			//sprintf(sz,"Camera Look %f, %f, %f ,%i", vLookAt.x, vLookAt.y, vLookAt.z , Cop[Cop_Select].getHP());
			//CText2D::Putstring(sz,0.01f,0.2f,0,0xffffffff);	

			//sprintf(sz,"V0 = %f ", g_fV0 );
			//CText2D::Putstring(sz,0.01f,0.80f,0,(0xffffffff));
			//sprintf(sz,"V0 = %f ,%f ,%f", LCur_pos.x, LCur_pos.y, LCur_pos.z );
			//CText2D::Putstring(sz,0.01f,0.80f,0,(0xffffffff));
		}
/*
		sprintf(sz,"Program Military Simulator Beta 0.2");
		CText2D::Putstring(sz,0.01f,0.95f,0,(0xffff00)|(x));

		sprintf(sz,"x= %f , y = %f , z = %f", vCamera.x,vCamera.y,vCamera.z);
		CText2D::Putstring(sz,0.01f,0.2f,0,(0xffff00)|(0xff));	
		

		sprintf(sz,"Current Animation Time is %f", Soldier01.GetCurrentAnimationTime() );
		CText2D::Putstring(sz,0.01f,0.4f,0,(0xffff00)|(0xff));

		sprintf(sz,"Velocity is %f", Soldier01.GetWalkVelocity() );
		CText2D::Putstring(sz,0.01f,0.5f,0,(0xffff00)|(0xff));

		sprintf(sz,"State is %s", Soldier01.GetStrState() );
		CText2D::Putstring(sz,0.01f,0.6f,0,(0xffff00)|(0xff));

		sprintf(sz,"Desire Action is %s", Soldier01.GetStrDesireAction() );
		CText2D::Putstring(sz,0.01f,0.7f,0,(0xffff00)|(0xff));

		sprintf(sz,"Current Action is %s", Soldier01.GetStrCurrentAction() );
		CText2D::Putstring(sz,0.01f,0.8f,0,(0xffff00)|(0xff));

*/
		//sprintf(sz,"HP is %d", Soldier01.GetHP() );
		//CText2D::Putstring(sz,0.01f,0.3f,0,(0xffff00)|(0xff));

		//sprintf(sz,"P is %f ,%f", Soldier01.Px(), Soldier01.Pz() );
		//CText2D::Putstring(sz,0.01f,0.4f,0,(0xffff00)|(0xff));

		/*
		float fDesX, fDesZ;
		//Soldier01.GetDestination( &fDesX, &fDesZ );
		sprintf(sz,"D is %f ,%f", fDesX, fDesZ );
		CText2D::Putstring(sz,0.01f,0.5f,0,(0xffff00)|(0xff));
*/

		//m_Mouse.Render();

	if ( bIsEnable_DepthTest ) glEnable(GL_DEPTH_TEST);

	//TwoD end

	ResetMBUp(); // For Mouse
	m_bShoot = FALSE;
	return S_OK;										// Everything Went OK
}

LRESULT CALLBACK CMyGlApp::MsgProc(	HWND    hWnd,			// Handle For This Window
									UINT	uMsg,			// Message For This Window
									WPARAM	wParam,			// Additional Message Information
									LPARAM	lParam )		// Additional Message Information
{
	switch (uMsg)
    {
		case WM_MOUSEMOVE :
		{
			m_MouseX = LOWORD (lParam) ;
			m_MouseY = HIWORD (lParam) ;
			return 0;
		}

		case WM_LBUTTONDOWN :
		case WM_MBUTTONDOWN :
		case WM_RBUTTONDOWN :
		{
			if( wParam & MK_LBUTTON ) m_MBLeft   = TRUE;
			if( wParam & MK_MBUTTON ) m_MBMiddle = TRUE;
			if( wParam & MK_RBUTTON ) m_MBRight  = TRUE;
			return 0;
		}
								  
		case WM_LBUTTONUP :
		{
			m_MBLeftUp = TRUE;  
			m_MBLeft   = FALSE;
			//TRACE("MouseX = %d, MouseY = %d \n", m_MouseX, m_MouseY );
			return 0;
		}
		case WM_MBUTTONUP :
		{
			m_MBMiddleUp = TRUE;
			m_MBMiddle   = FALSE;
			return 0;
		}
		case WM_RBUTTONUP :
		{
			//Soldier01.SetDesireAction( CSoldier::ACTION_GUNUP );
			//Soldier01.DecreaseHP( 20 );
			/*
			static BOOL test = TRUE;
			if ( test )
			{
				test = ! test;
				Soldier01.SetAnimation("left");
			}
			else
			{
				test = ! test;
				Soldier01.SetAnimation("walk");
			}

			float Ts = Soldier01.GetTimeScale();
			//Soldier01.SetTimeScale( Ts * 1.1f );
			*/

			m_MBRightUp = TRUE;
			m_MBRight  = FALSE;
			return 0;
		}
		
	}
	return CGLApplication::MsgProc( hWnd, uMsg, wParam, lParam ); 
}

HRESULT CMyGlApp::ProcessKey( float fElapsedTime )
{
	if (isEnd == TRUE) return S_OK;
	
	// MoveForward
	static float MoveForward = 0.0f;
	static float fLimit = 20.5f;
	if( m_arKey[VK_NUMPAD8]) 
	{
		MoveForward+=(fElapsedTime/6.0f); 
		if( MoveForward > fLimit ) MoveForward = fLimit;
	}
	else 
	{
		MoveForward-=(fElapsedTime/3.0f);
	}

	if (MoveForward<=0.0f) 
	{
		MoveForward = 0.0f;
	}
	else
	{
		m_Camera.S2_MoveForward( MoveForward );
	}

	// MoveBackward
	static float MoveBackward = 0.0f;
	if( m_arKey[VK_NUMPAD2]) 
	{
		MoveBackward+=(fElapsedTime/6.0f); 
		if( MoveBackward > fLimit ) MoveBackward = fLimit;
	}	
	else 
	{
		MoveBackward-=(fElapsedTime/3.0f);
	}

	if (MoveBackward<=0.0f) 
	{
		MoveBackward = 0.0f;
	}
	else
	{
		m_Camera.S2_MoveBackward( MoveBackward );
	}

	// MoveLeft
	static float MoveLeft = 0.0f;
	if( m_arKey[VK_NUMPAD4]) 
	{
		MoveLeft+=(fElapsedTime/6.0f); 
		if( MoveLeft > fLimit ) MoveLeft = fLimit;
	}
	else 
	{
		MoveLeft-=(fElapsedTime/3.0f);
	}

	if (MoveLeft<=0.0f) 
	{
		MoveLeft = 0.0f;
	}
	else
	{
		m_Camera.S2_MoveLeft( MoveLeft );
	}

	static float MoveRight = 0.0f;
	if( m_arKey[VK_NUMPAD6]) 
	{
		MoveRight+=(fElapsedTime/6.0f); 
		if( MoveRight > fLimit ) MoveRight = fLimit;
	}
	else 
	{
		MoveRight-=(fElapsedTime/3.0f);
	}

	if (MoveRight<=0.0f) 
	{
		MoveRight = 0.0f;
	}
	else
	{
		m_Camera.S2_MoveRight( MoveRight );
	}

	// MoveUp
	static float MoveUp = 0.0f;
	if( m_arKey['G']) 
	{
		MoveUp+=(fElapsedTime/6.0f); 
		if( MoveUp > fLimit ) MoveUp = fLimit;
	}
	else 
	{
		MoveUp-=(fElapsedTime/3.0f);
	}
	if (MoveUp<=0.0f) 
	{
		MoveUp = 0.0f;
	}
	else
	{
		m_Camera.S2_MoveUp( MoveUp );
	}

	// MoveDown
	static float MoveDown = 0.0f;
	if( m_arKey['B']) 
	{
		MoveDown+=(fElapsedTime/6.0f); 
		if( MoveDown > fLimit ) MoveDown = fLimit;
	}
	else 
	{
		MoveDown-=(fElapsedTime/3.0f);
	}

	if (MoveDown<=0.0f) 
	{
		MoveDown = 0.0f;
	}
	else
	{
		m_Camera.S2_MoveDown( MoveDown );
	}

	// UseFul Data
	RECT ScrRect;
	::GetClientRect( m_hWnd, &ScrRect );
	int ScrWidth  = ScrRect.right - ScrRect.left;
	int ScrHeight = ScrRect.bottom - ScrRect.top;
	//============================Rotate Left=================================
	if( m_arKey[VK_NUMPAD7] || (m_MouseX == 0) ) 
	{
		m_Camera.S2_RotateLeft( fElapsedTime*50.0f );
	}

	//============================Rotate Right================================
	if( m_arKey[VK_NUMPAD9] || (m_MouseX == ScrWidth - 1) ) 
	{
		m_Camera.S2_RotateRight( fElapsedTime*50.0f );
	}

	//============================Rotate Up===================================
	if( m_arKey['A'] || (m_MouseY == 0) ) 
	{
		m_Camera.S2_RotateUp( fElapsedTime*50.0f );
	}
	//==========================================================================

	//============================Rotate Down==================================
	if( m_arKey['Z'] || (m_MouseY == ScrHeight - 1 )  ) 
	{
		m_Camera.S2_RotateDown( fElapsedTime*50.0f );
	}

	//==========================================================================

	//------------Pong Input-----------------
	DWORD joyNum;
	DI::getDeviceNum(JOY_TYPE,joyNum);
	if (joyNum >= 1)
	{
		DIJOYSTATE2 joyState;
	    ZeroMemory(&joyState, sizeof(DIJOYSTATE2));
		DI::getState(0,joyState);
		
		//Move Up
		static float MoveUp = 0.0f;
		if (joyState.rgbButtons[7] & 0x80)
		{
			MoveUp+=(fElapsedTime/6.0f); 
			if( MoveUp > fLimit ) MoveUp = fLimit;
		}
		else 
		{
			MoveUp-=(fElapsedTime/3.0f);
		}
		if (MoveUp<=0.0f) 
		{
			MoveUp = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveUp( MoveUp );
		}

		// MoveDown
		static float MoveDown = 0.0f;
		if(joyState.rgbButtons[6] & 0x80) 
		{
			MoveDown+=(fElapsedTime/6.0f); 
			if( MoveDown > fLimit ) MoveDown = fLimit;
		}
		else 
		{
			MoveDown-=(fElapsedTime/3.0f);
		}

		if (MoveDown<=0.0f) 
		{
			MoveDown = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveDown( MoveDown );
		}
		
		//Rotate
		if(joyState.lRz <= -400) 
		{
			m_Camera.S2_RotateLeft( fElapsedTime*50.0f );
		}

		if(joyState.lRz >= 400) 
		{
			m_Camera.S2_RotateRight( fElapsedTime*50.0f );
		}

		if(joyState.rglSlider[0] <= -400) 
		{
			m_Camera.S2_RotateUp( fElapsedTime*50.0f );
		}
		if(joyState.rglSlider[0] >= 400) 
		{
			m_Camera.S2_RotateDown( fElapsedTime*50.0f );
		}

		//Put Mouse	
		static BOOL isJoyRight = FALSE;
		if (joyState.rgbButtons[1] & 0x80) 
		{
			if (isJoyRight == FALSE)
			{
				joyRight = TRUE;
			}
			isJoyRight = TRUE;
		}
		else 
		{
			joyRight = FALSE;
			isJoyRight = FALSE;
		}

		static BOOL isJoyLeft = FALSE;
		if (joyState.rgbButtons[0] & 0x80) 
		{
			if (isJoyLeft == FALSE)
			{
				joyLeft = TRUE;
			}
			isJoyLeft = TRUE;
		}
		else 
		{
			joyLeft = FALSE;
			isJoyLeft = FALSE;
		}
		
		//Move Mouse
		//static BOOL is = FALSE;

		if (joyState.lX >= 300) m_MouseX = m_MouseX + 10;
		else if (joyState.lX <= -300) m_MouseX = m_MouseX - 10;

		if (joyState.lY >= 300) m_MouseY = m_MouseY + 10;
		else if (joyState.lY <= -300) m_MouseY = m_MouseY - 10;

		// MoveForward
		static float MoveForward = 0.0f;
		if(joyState.rgdwPOV[0] == 0) 
		{
			MoveForward+=(fElapsedTime/6.0f); 
			if( MoveForward > fLimit ) MoveForward = fLimit;
		}
		else 
		{
			MoveForward-=(fElapsedTime/3.0f);
		}

		if (MoveForward<=0.0f) 
		{
			MoveForward = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveForward( MoveForward );
		}

		// MoveBackward
		static float MoveBackward = 0.0f;
		if(joyState.rgdwPOV[0] == 18000) 
		{
			MoveBackward+=(fElapsedTime/6.0f); 
			if( MoveBackward > fLimit ) MoveBackward = fLimit;
		}	
		else 
		{
			MoveBackward-=(fElapsedTime/3.0f);
		}

		if (MoveBackward<=0.0f) 
		{
			MoveBackward = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveBackward( MoveBackward );
		}

		// MoveLeft
		static float MoveLeft = 0.0f;
		if(joyState.rgdwPOV[0] == 27000) 
		{
			MoveLeft+=(fElapsedTime/6.0f); 
			if( MoveLeft > fLimit ) MoveLeft = fLimit;
		}
		else 
		{
			MoveLeft-=(fElapsedTime/3.0f);
		}

		if (MoveLeft<=0.0f) 
		{
			MoveLeft = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveLeft( MoveLeft );
		}

		static float MoveRight = 0.0f;
		if(joyState.rgdwPOV[0] == 9000) 
		{
			MoveRight+=(fElapsedTime/6.0f); 
			if( MoveRight > fLimit ) MoveRight = fLimit;
		}
		else 
		{
			MoveRight-=(fElapsedTime/3.0f);
		}

		if (MoveRight<=0.0f) 
		{
			MoveRight = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveRight( MoveRight );
		}

		// MoveForwardLeft
		static float MoveForwardLeft = 0.0f;
		if(joyState.rgdwPOV[0] == 31500) 
		{
			MoveForwardLeft+=(fElapsedTime/6.0f); 
			if( MoveForwardLeft > fLimit ) MoveForwardLeft = fLimit;
		}
		else 
		{
			MoveForwardLeft-=(fElapsedTime/3.0f);
		}

		if (MoveForwardLeft<=0.0f) 
		{
			MoveForwardLeft = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveForward( MoveForwardLeft );
			m_Camera.S2_MoveLeft(MoveForwardLeft);
		}

		// MoveBackwardLeft
		static float MoveBackwardLeft = 0.0f;
		if(joyState.rgdwPOV[0] == 22500) 
		{
			MoveBackwardLeft+=(fElapsedTime/6.0f); 
			if( MoveBackwardLeft > fLimit ) MoveBackwardLeft = fLimit;
		}
		else 
		{
			MoveBackwardLeft-=(fElapsedTime/3.0f);
		}

		if (MoveBackwardLeft<=0.0f) 
		{
			MoveBackwardLeft = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveBackward( MoveBackwardLeft );
			m_Camera.S2_MoveLeft(MoveBackwardLeft);
		}
		
		// MoveForwardRight
		static float MoveForwardRight = 0.0f;
		if(joyState.rgdwPOV[0] == 4500) 
		{
			MoveForwardRight+=(fElapsedTime/6.0f); 
			if( MoveForwardRight > fLimit ) MoveForwardRight = fLimit;
		}
		else 
		{
			MoveForwardRight-=(fElapsedTime/3.0f);
		}

		if (MoveForwardRight<=0.0f) 
		{
			MoveForwardRight = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveForward( MoveForwardRight );
			m_Camera.S2_MoveRight(MoveForwardRight);
		}

		// MoveBackwardRight
		static float MoveBackwardRight = 0.0f;
		if(joyState.rgdwPOV[0] == 13500) 
		{
			MoveBackwardRight+=(fElapsedTime/6.0f); 
			if( MoveBackwardRight > fLimit ) MoveBackwardRight = fLimit;
		}
		else 
		{
			MoveBackwardRight-=(fElapsedTime/3.0f);
		}

		if (MoveBackwardRight<=0.0f) 
		{
			MoveBackwardRight = 0.0f;
		}
		else
		{
			m_Camera.S2_MoveBackward( MoveBackwardRight );
			m_Camera.S2_MoveRight(MoveBackwardRight);
		}
	
		static BOOL Cop_hSelect = FALSE;
		if (joyState.rgbButtons[3] & 0x80)
		{
			if (Cop_hSelect == FALSE)
			{
				if (Cop_Select >= MAX_COP -1) Cop_Select = 0;
				else Cop_Select++;
			}
			Cop_hSelect = TRUE;
		}
		else Cop_hSelect = FALSE;

		//if (m_arKey['E'])
		//{
			//erH = DI::enableDevice(JOY_TYPE,0);
		//	if (EffGun != NULL) joy = EffGun->play();
		//}
	}

	//--------------------------------------

	static BOOL Cop_hSelect = FALSE;
	if (m_arKey['Q'])
	{
		if (Cop_hSelect == FALSE)
		{
			if (Cop_Select >= MAX_COP -1) Cop_Select = 0;
			else Cop_Select++;
		}
		Cop_hSelect = TRUE;
	}
	else Cop_hSelect = FALSE;

	return S_OK;
}

void CMyGlApp::ShowLoading(float fPercent,const CString& Message)
{
	//CUseTexture TexLoading;
	//TexLoading.Use("texture\\Mouse001.tga");

	CCamera Camera2D;
	Camera2D.SetParamsSystem1(	0.0f, 0.0f, 0.0f,
								0.0f, 0.0f, 1.0f,
								0.0f, 1.0f, 0.0f	);
	Camera2D.View();

	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping ( NEW )

	GLGfx::Clear();
	
	char sz[255];
	
	sprintf(sz,"Now Loading ... ");
	CText2D::Putstring(sz,0.385f,0.49f,0.0f, 0xffffffff);

	sprintf(sz,"... %s",Message);
	CText2D::Putstring(sz,0.05f,0.93f,0.0f, 0xffffffff);	

	glColor4f(0.3f,0.3f,0.3f,1.0f);
	CText2D::PutPictureIn2D(NULL,0.30f,0.55f,0.70f,0.555f,0.0f,0.0f,0.0f,0.0f,0.0f);
	
	glColor4f(1.0f,1.0f,1.0f,1.0f);
	CText2D::PutPictureIn2D(NULL,0.30f,0.55f,
								0.3f +( (0.70f-0.30f) * (fPercent/100.0f) ),0.555f,
								0.0f,0.0f,0.0f,0.0f,0.0f);
	GLGfx::SwapBuffers();

}

void CMyGlApp::ProcessComData(BYTE *pData)
{
	int id = 0;
	char TempX[5], TempY[5];
	CopyMemory(TempX, pData + 1, 4);
	CopyMemory(TempY, pData + 5, 4);
	TempX[4] = TempY[4] = 0;

	float x = float(atoi(TempX));
	float y = float(atoi(TempY));

	CRect rect(m_calibase[0], m_calibase[8]);
	if (!rect.PtInRect(CPoint(int(x), int(y) )))
	{
		return;
	}

	int Q = 0;
	if (x <= m_calibase[4].x)
	{
       if (y <= m_calibase[4].y)
	   {
           Q = 1;
		}
		else
		{
           Q = 3;
		}
	}
	else
	{
        if (y <= m_calibase[4].y)
		{
			Q = 2;
		}
		else
		{
            Q = 4;
		}        
    }

	CRect rcClient;
	GetClientRect(m_hWnd, rcClient);

	switch( Q)
	{
		case 0:
			return;
		case 1:
			x -= m_calibase[0].x + (m_calibase[3].x - m_calibase[0].x) / 2;
			y -= m_calibase[0].y + (m_calibase[1].y - m_calibase[0].y) / 2;
			x = rcClient.Width() / 2 * x / ((float) ((m_calibase[1].x - m_calibase[0].x) + (m_calibase[4].x - m_calibase[3].x)) / 2.0f);
			y = rcClient.Height() / 2 * y / ((float) ((m_calibase[3].y - m_calibase[0].y) + (m_calibase[4].y - m_calibase[1].y)) / 2.0f);
			break;
		case 2:
			x -= m_calibase[1].x + (m_calibase[4].x - m_calibase[1].x) / 2;
			y -= m_calibase[1].y + (m_calibase[2].y - m_calibase[1].y) / 2;
			x = rcClient.Width() / 2 * x / ((float) ((m_calibase[2].x - m_calibase[1].x) + (m_calibase[5].x - m_calibase[4].x)) / 2.0f) + rcClient.Width()/2;
			y = rcClient.Height() / 2 * y / ((float) ((m_calibase[4].y - m_calibase[1].y) + (m_calibase[5].y - m_calibase[2].y)) / 2.0f);
			break;
		case 3:
			x -= m_calibase[3].x + (m_calibase[6].x - m_calibase[3].x) / 2;
			y -= m_calibase[3].y + (m_calibase[4].y - m_calibase[3].y) / 2;
			x = rcClient.Width() / 2  * x / ((float) ((m_calibase[4].x - m_calibase[3].x) + (m_calibase[7].x - m_calibase[6].x)) / 2.0f);
			y = rcClient.Height() / 2 * y / ((float) ((m_calibase[6].y - m_calibase[3].y) + (m_calibase[7].y - m_calibase[4].y)) / 2.0f) + rcClient.Height()/2;
			break;
		case 4:
			x -= m_calibase[4].x + (m_calibase[7].x - m_calibase[4].x) / 2;
			y -= m_calibase[4].y + (m_calibase[5].y - m_calibase[4].y) / 2;
			x = rcClient.Width() / 2  * x / ((float) ((m_calibase[5].x - m_calibase[4].x) + (m_calibase[8].x - m_calibase[7].x)) / 2.0f) + rcClient.Width()/2;
			y = rcClient.Height() / 2 * y / ((float) ((m_calibase[7].y - m_calibase[4].y) + (m_calibase[8].y - m_calibase[5].y)) / 2.0f) + rcClient.Height()/2;
			break;
	}
	
	m_shootx = x;
	m_shooty = y;	
	m_bShoot = TRUE;
}


