#include"GameMain.h"
#include"engine.h"
#include"dxutil.h"
#include"global.h"
#include"assert.h"
#include"cGraphic.h"
#include"cWindows.h"
#include"cView.h"
#include"d3dx8.h"
#include"CAudio.h"
#define IDC_COMBO2 1001
#define IDC_COMBO5 1002
#define IDC_COMBO6 1003
#define IDC_RADIO2 1004
#define IDC_RADIO1 1005
#define MUL 1
#define TIMERID_CONNECT_COMPLETE    1
#define MODE_STANDALONE 0
#define MODE_1VS2 1
#define MODE_12VSCOM 2
int Tempnum=0;
GUID	DP_SPACEPIRATES = { 0x74171a50, 0xe7c0, 0x4257, { 0xa7, 0x8c, 0x14, 0xdb, 0x54, 0xaf, 0x31, 0xa0 } };
int aa=0;
cApplication* CreateApplication()
{
	return new GameMain();
}
cGraphic* GetMainGraphic()
{
	return new GameGraphic();
}
VOID GameMain::ChangeGraphic(HWND hDlg)
{
	HWND hwndAdapter =GetDlgItem(hDlg,IDC_COMBO2);
	HWND hwndDevice  =GetDlgItem(hDlg,IDC_COMBO5);
	HWND hwndFullList = GetDlgItem(hDlg,IDC_COMBO6);
	HWND hwndWindowRadio = GetDlgItem(hDlg,IDC_RADIO2);
	HWND hwndFullRadio = GetDlgItem(hDlg,IDC_RADIO1);
	BOOL bUpdateDialogControl = FALSE;
}
void GameMain::InitInput()
{
	MainInput->init();
	key1.init(g_hWnd);
	key1.start();
	mouse1.init(g_hWnd);
	
	mouse1.start();
	
}
void GameMain::CleanUp()
{
    key1.stop();
	key1.cleanup();
	mouse1.stop();
	mouse1.cleanup();
	MainInput->cleanup();
	cGraphic::GetGraphic()->CleanUp();
	
}
int GameMain::GetInput(DIMOUSESTATE& mbuffer)
{
	BYTE dkey[256];
	
	int a=0;
 	ZeroMemory(&mbuffer,sizeof(DIMOUSESTATE));
	mouse1.getState(mbuffer);
	
	if(key1.getState(dkey)!=-1)
	{
	
	if(dkey[DIK_UP]&0x80)
			a=a|1;
		if(dkey[DIK_DOWN]&0x80)
			a=a|2;
		if(dkey[DIK_LEFT]&0x80)
			a=a|4;
		if(dkey[DIK_RIGHT]&0x80)
		    a=a|8;
		if(dkey[DIK_W]&0x80)
			a=a|16;
		if(dkey[DIK_S]&0x80)
			a=a|32;
		if(dkey[DIK_A]&0x80)
			a=a|64;
		if(dkey[DIK_D]&0x80)
			a=a|128;
		if(dkey[DIK_L]&0x80)
			a=a|256;
		if(dkey[DIK_K]&0x80)
			a=a|512;
		if(dkey[DIK_J]&0x80)
			a=a|1024;
		if(dkey[DIK_I]&0x80)
			a=a|2048;
		if(dkey[DIK_U]&0x80)
			a=a|4096;
		if(dkey[DIK_P]&0x80)
			a=a|8192;		
		if(dkey[DIK_O]&0x80)
			a=a|16384;
	}
		return a;
}
void GameMain::UpdateState(int in1,DIMOUSESTATE& mbuffer)
{
	cGraphic::GetGraphic()->UpdateState(in1, mbuffer);
}
HRESULT GameGraphic::InitD3D( HWND hWnd )
{
		CAManager::getCAM()->init(hWnd);	
		sWalk.init();
		sWalk.load("sound\\step1.wav");
		sWalk.setloop();
		sShot.init();
		sShot.load("sound\\shot5.wav");
		cGet.init();
		cGet.load("sound\\BIGLAFF.wav");
	//	sShot.setloop();

	dwUpdateTime=0;
    FrontLight=false;
	OnFog=false;
	OnNight=false;
	// Create the D3D object.
    if( NULL == ( g_pD3D = Direct3DCreate8( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // Get the current desktop display mode, so we can set up a back
    // buffer of the same format
    D3DDISPLAYMODE d3ddm;
    if( FAILED( g_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
        return E_FAIL;

    // Set up the structure used to create the D3DDevice. Since we are now
    // using more complex geometry, we will create a device with a zbuffer.
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = false;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = d3ddm.Format;
    d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
	d3dpp.BackBufferWidth  = 800;
    d3dpp.BackBufferHeight = 600;
    
    // Create the D3DDevice
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return E_FAIL;
    }

    // Turn on the zbuffer
     //g_pd3dDevice->SetRenderState( D3DRS_ZENABLE,D3DZB_TRUE);
	/* g_pd3dDevice->SetRenderState( D3DRS_CULLMODE,D3DCULL_CCW );
 */
	g_pd3dDevice->SetRenderState(D3DRS_FOGCOLOR,0X00959595);
	g_pd3dDevice->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_LINEAR);

   fogstart=0.0f;
   fogend=3000.0f;
  //  g_pd3dDevice->SetRenderState(D3DRS_FOGSTART,*(DWORD*)&st1);
   // g_pd3dDevice->SetRenderState(D3DRS_FOGEND,*(DWORD*)&end1);

  
	g_pd3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE,TRUE);

	//g_pd3dDevice->SetRenderState( D3DRS_CLIPPING,FALSE);
    // Turn on ambient lighting 
  //g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x00FFFFFF );

    return S_OK;
}

void GameGraphic::UpdateState(int in1,DIMOUSESTATE& mbuffer)
{
	s1.AnimeAll();
	s2.AnimeAll();
	if (state==0)
	{
		if(statein==0)
		{
			for(int i = 0 ;i<200 ;i++)
			{
				CanEnemy[i]=false;
			}
			for(i = 0 ; i < MAX_PLAYERS ; i++ ) 
			{
				i_char[i].bActive = 0;
			}
			AllPage=new c2D(g_pd3dDevice,800,600,0,0,"Picture\\FirstPage.bmp");
			AllPage->InitVB(g_pd3dDevice);
			PlayB=new c2D(g_pd3dDevice,71*MUL,28*MUL,301*MUL,252*MUL,"Picture\\PlayButton2.BMP");
			PlayB->InitVB(g_pd3dDevice);
			ExitB=new c2D(g_pd3dDevice,71*MUL,28*MUL,227*MUL,252*MUL,"Picture\\ExitButton2.BMP");
			ExitB->InitVB(g_pd3dDevice);
			statein=1;
		
		}
		if(statein==1)
		{
			Mou->AddPos(mbuffer.lX,mbuffer.lY);
			Mou->CheckPos();
			if(ExitB->Check(Mou))
				ExitB->Show();
			else
				ExitB->Hide();Mou->AddPos(mbuffer.lX,mbuffer.lY);
			if(PlayB->Check(Mou))
				PlayB->Show();
			else
				PlayB->Hide();
			if(mbuffer.rgbButtons[0]>0)
			{
				if(ExitB->Check(Mou))
				{
				//		hrInitializeDirectPlay();
				//				hrHostGame();
									statechange=1;
					statein=2;
			//		exit(0);
				}
			//	exit(0);
				if(PlayB->Check(Mou))
				{
				//	hrInitializeDirectPlay();
				//	hrJoinGame();
						
					statechange=1;
					statein=2;
				}
			}
		}
		if (statein==2)
		{
			state=statechange;
			g_manager.RemoveAll();
			statein=0;
			delete AllPage;
			delete PlayB;
			delete ExitB;
		}
	
	}
	if(state==1)
	{
		Mou->AddPos(mbuffer.lX,mbuffer.lY);
		Mou->CheckPos();
			
		if(statein==0)
		{
			AllPage=new c2D(g_pd3dDevice,800,600,0,0,"Picture\\SelectMenu.bmp");
			AllPage->InitVB(g_pd3dDevice);
			in1vs21=new c2D(g_pd3dDevice,194*MUL,14*MUL,520,60*MUL,"Picture\\1pvs2p1.bmp");
			in1vs21->InitVB(g_pd3dDevice);
			in1vs22=new c2D(g_pd3dDevice,194*MUL,14*MUL,100,60*MUL,"Picture\\1pvs2p2.bmp");
			in1vs22->InitVB(g_pd3dDevice);
			in1vsCom1=new c2D(g_pd3dDevice,194*MUL,14*MUL,440,20*MUL,"Picture\\1pvscom1.bmp");
			in1vsCom1->InitVB(g_pd3dDevice);
			in1vsCom2=new c2D(g_pd3dDevice,194*MUL,14*MUL,100,20*MUL,"Picture\\1pvscom2.bmp");
			in1vsCom2->InitVB(g_pd3dDevice);
			in12vsCom1=new c2D(g_pd3dDevice,194*MUL,14*MUL,600,100*MUL,"Picture\\12pvscom1.bmp");
			in12vsCom1->InitVB(g_pd3dDevice);
			in12vsCom2=new c2D(g_pd3dDevice,194*MUL,14*MUL,100,100*MUL,"Picture\\12pvscom2.bmp");
			in12vsCom2->InitVB(g_pd3dDevice);
			CheckBox=new c2D(g_pd3dDevice,210*MUL,138*MUL,30,-10+4*MUL,"Picture\\logon.bmp");
			CheckBox->InitVB(g_pd3dDevice);
			HostBut=new c2D(g_pd3dDevice,76*MUL,25*MUL,-9,46,"Picture\\HostButton.bmp");
			HostBut->InitVB(g_pd3dDevice);
			JoinBut=new c2D(g_pd3dDevice,76*MUL,25*MUL,74,46,"Picture\\JoinButton.bmp");
			JoinBut->InitVB(g_pd3dDevice);
			statein=1;
		}
		if(statein==1)
		{
			
		/*	void *packet;
			PacketPosition pacPos;
			pacPos.dwSize = sizeof(PacketPosition);
			pacPos.dwType = PACKET_TYPE_POSITION;
			pacPos.fx = 2;
			pacPos.fz = 3;
			packet = (VOID*)&pacPos;
			hrSendPeerMessage(-1,PACKET_TYPE_POSITION,packet);
*/
			CheckBox->Hide();
			if(in1vs21->getX()>100)
				in1vs21->AddPos(-20,0);
			if(in1vsCom1->getX()>100)
				in1vsCom1->AddPos(-20,0);
			if(in12vsCom1->getX()>100)
				in12vsCom1->AddPos(-20,0);
			else
				statein=2;
				in1vs22->Hide();
				in1vsCom2->Hide();
				in12vsCom2->Hide();
		}
		if(statein==2)
		{
			if(in1vs22->Check(Mou))
				in1vs22->Show();
			else
				in1vs22->Hide();
			if(in1vsCom2->Check(Mou))
				in1vsCom2->Show();
			else
				in1vsCom2->Hide();
			if(in12vsCom2->Check(Mou))
				in12vsCom2->Show();
			else
				in12vsCom2->Hide();
			if(mbuffer.rgbButtons[0]>0)
			{
				if(in1vsCom2->Check(Mou))
				{
				
					main_mode=MODE_STANDALONE;
					statein=3;
					statechange=3;		
				}
				if(in12vsCom2->Check(Mou))
				{
	
					main_mode=MODE_12VSCOM;
					statein=4;
					//atechange=3;
					cWindow::GetMainWindow()->ClearMessage();
					cWindow::GetMainWindow()->setWrite();
					cWindow::GetMainWindow()->setMax(8);
					cWindow::GetMainWindow()->setEnter(false);

				}
				if(in1vs22->Check(Mou))
				{
	
					main_mode=MODE_1VS2;
					statein=4;
					//atechange=3;
					cWindow::GetMainWindow()->ClearMessage();
					cWindow::GetMainWindow()->setWrite();
					cWindow::GetMainWindow()->setMax(8);
					cWindow::GetMainWindow()->setEnter(false);

				}

			}
		}
		if(statein==3)
		{
			
			delete AllPage;
			delete in1vs21;
			delete in1vs22;
			delete in1vsCom1;
			delete in1vsCom2;
			delete in12vsCom1;
			delete in12vsCom2;
			state=statechange;
			g_manager.RemoveAll();
			statein=0;
		}
		if(statein==4)
		{
			CheckBox->Show();
			strcpy(szSystemMessage,cWindow::GetMainWindow()->szSystemMessage.data());
			if(cWindow::GetMainWindow()->getEnter())
			{	
				statein=5;
				Name=szSystemMessage;
				cWindow::GetMainWindow()->ClearMessage();
				cWindow::GetMainWindow()->ClearCommand();
				cWindow::GetMainWindow()->setMax(16);
				cWindow::GetMainWindow()->setEnter(false);
		
			}

			strcat(szSystemMessage,"_");
		}
		if(statein==5)
		{
			strcpy(szSystemMessage,cWindow::GetMainWindow()->szSystemMessage.data());
			
			if(HostBut->Check(Mou))
				HostBut->Show();
			else
				HostBut->Hide();
			if(JoinBut->Check(Mou))
				JoinBut->Show();
			else
				JoinBut->Hide();
		
			if(cWindow::GetMainWindow()->getEnter())
			{	
				statein=3;
				statechange=3;
				IPHost=szSystemMessage;
				cWindow::GetMainWindow()->ClearMessage();
				cWindow::GetMainWindow()->ClearCommand();
			}

			strcat(szSystemMessage,"_");
				if(mbuffer.rgbButtons[0]>0)
			{
				if(HostBut->Check(Mou))
				{
									statechange=3;
									doHost=true;
					statein=3;
			//		exit(0);
				}
			//	exit(0);
				if(JoinBut->Check(Mou))
				{
						doHost=false;
					statechange=3;
					statein=3;
				}
			}
	
		}
	}	
	if(state==3)
	{
		if(statein==0)
		{
			/*if(main_mode==MODE_NETWORK) hrInitializeDirectPlay();
		
			else 
			{
				
				g_iMyPlayerId=0;
				g_char[g_iMyPlayerId]=g_stand;
			}*/
			g_manager.LoadTexture (g_pd3dDevice,"model\\crafy_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\crafy_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\marvin_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\marvin_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\spiff_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\spiff_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\invade_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\invade_weapon.bmp");
			AllPage=new c2D(g_pd3dDevice,800,600,0,0,"Picture\\SelectChar2.tga");
			AllPage->InitVB(g_pd3dDevice);
		
			Ctua=new c2D(g_pd3dDevice,87*MUL,242*MUL,(498-400+44)*MUL,(21-300+122)*MUL,"Picture\\crafy2.bmp");
			Ctua->InitVB(g_pd3dDevice);
			Itua=new c2D(g_pd3dDevice,87*MUL,242*MUL,(404.5-400+44)*MUL,(21-300+122)*MUL,"Picture\\invade2.bmp");
			Itua->InitVB(g_pd3dDevice);
			Mtua=new c2D(g_pd3dDevice,87*MUL,242*MUL,(592-400+44)*MUL,(20.5-300+122)*MUL,"Picture\\marvin2.bmp");
			Mtua->InitVB(g_pd3dDevice);
			Stua=new c2D(g_pd3dDevice,87*MUL,242*MUL,(686-400+44)*MUL,(21-300+122)*MUL,"Picture\\spiff2.bmp");
			Stua->InitVB(g_pd3dDevice);	
			statein=1;
			g_stand->setPos(-10,0,-4.5);
			g_stand->stand();
			g_w1->setPos(-10,0,-4.5);
			g_w1->stand();
	
		}
		if(statein==1)
		{
			Mou->AddPos(mbuffer.lX,mbuffer.lY);
			Mou->CheckPos();
			g_stand->turnLeft();
			g_w1->turnLeft();
			if(Ctua->Check(Mou))
			{
				g_stand->setModel(g_SetModel.getModel(0));
				g_w1->setModel(g_SetModel.getModel(1));
				Ctua->Show();
				TexName="model\\crafy_texture.bmp";
				TexWea="model\\crafy_weapon.bmp";
				g_stand->Show();
				g_w1->Show();
				Stua->Hide();
				Itua->Hide();
				Mtua->Hide();					
			}
			else
			{
				Ctua->Hide();
				if(Itua->Check(Mou))
				{	
					Itua->Show();
					TexName="model\\invade_texture.bmp";
					TexWea="model\\invade_weapon.bmp";
			
					g_stand->setModel(g_SetModel.getModel(6));
					g_w1->setModel(g_SetModel.getModel(7));
					Stua->Hide();
					Ctua->Hide();
					Mtua->Hide();
					g_stand->Show();
					g_w1->Show();
				}
				else
				{
					Itua->Hide();
					if(Mtua->Check(Mou))
					{
						g_stand->setModel(g_SetModel.getModel(2));
						g_w1->setModel(g_SetModel.getModel(3));
						Ctua->Hide();
						Stua->Hide();
						Itua->Hide();
						TexName="model\\marvin_texture.bmp";
						TexWea="model\\marvin_weapon.bmp";
			
						Mtua->Show();
						g_stand->Show();
						g_w1->Show();
					
					}	
					else
					{	
						Mtua->Hide();
						if(Stua->Check(Mou))
						{
							g_stand->setModel(g_SetModel.getModel(4));
							g_w1->setModel(g_SetModel.getModel(5));
							TexName="Picture\\marvin2.bmp";
							TexName="model\\spiff_texture.bmp";
							TexWea="model\\spiff_weapon.bmp";
			
							Ctua->Hide();
							Itua->Hide();
							Mtua->Hide();
							Stua->Show();
							g_stand->Show();
							g_w1->Show();
						}
						else
						{
							Stua->Hide();
							g_stand->Hide();
							g_w1->Hide();
						}
				
					}
				}
			}
			if(mbuffer.rgbButtons[0]>0)
			{
				if(Ctua->Check(Mou))
				{
					statein=2;
					statechange=10;		
					typeChar=0;
				}
				if(Itua->Check(Mou))
				{
					statein=2;
					statechange=10;		
					typeChar=6;
				}
				if(Mtua->Check(Mou))
				{
					statein=2;
					statechange=10;		
					typeChar=2;
				}
				if(Stua->Check(Mou))
				{
					statein=2;
					statechange=10;		
					typeChar=4;
				}
			}
	
		}
		if(statein==2)
		{
				hrInitializeDirectPlay();
				if(doHost)hrHostGame();
				else hrJoinGame();
					
			state=statechange;
			g_manager.RemoveAll();
			statein=0;
			delete AllPage;
			delete Ctua;
			delete Itua;
			delete Mtua;
			delete Stua;
		}	
		
	}
	if(state==10)
	{
		if(statein==0)
		{
			g_manager.LoadTexture (g_pd3dDevice,"model\\crafy_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\crafy_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\marvin_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\marvin_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\spiff_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\spiff_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\invade_texture.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\invade_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\a.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\a_weapon.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"model\\seafloor.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\BlueBullet.tga");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\lifeBoss1.tga");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\lifeboss2.tga");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\lifeboss3.tga");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\lifeboss4.tga");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\CrafyFace.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\MarvinFace.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\InvadeFace.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\SpiffFace.bmp");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\heart.tga");
			g_manager.LoadTexture (g_pd3dDevice,"Picture\\weaponface.bmp");
			cWindow::GetMainWindow()->setEnter(false);

			Face[0]=new c2D(g_pd3dDevice,23,33,-330+(23/2),-250,"Picture\\CrafyFace.bmp");
			Face[0]->InitVB(g_pd3dDevice);
			Face[1]=new c2D(g_pd3dDevice,23,33,-330+(23/2),-250,"Picture\\MarvinFace.bmp");
			Face[1]->InitVB(g_pd3dDevice);
			Face[2]=new c2D(g_pd3dDevice,23,33,-330+(23/2),-250,"Picture\\SpiffFace.bmp");
			Face[2]->InitVB(g_pd3dDevice);
			Face[3]=new c2D(g_pd3dDevice,23,33,-330+(23/2),-250,"Picture\\InvadeFace.bmp");
			Face[3]->InitVB(g_pd3dDevice);
			Life1[0]=new c2D(g_pd3dDevice,323,30,-300+(323/2),-250,"Picture\\life0.tga");
			Life1[1]=new c2D(g_pd3dDevice,271,29,-300+(271/2),-250,"Picture\\life1.tga");
			Life1[2]=new c2D(g_pd3dDevice,214,29,-300+(214/2),-250,"Picture\\life2.tga");
			Life1[3]=new c2D(g_pd3dDevice,151,29,-300+(151/2),-250,"Picture\\life3.tga");
			Life1[4]=new c2D(g_pd3dDevice,94,29,-300+(94/2),-250,"Picture\\life4.tga");
			Map=new c2D(g_pd3dDevice,154,106,320-(23/2),230,"Picture\\map.bmp");
			Map->InitVB(g_pd3dDevice);
			Point=new c2D(g_pd3dDevice,4,4,320-(23/2),230,"Picture\\Point.bmp");
			Point->InitVB(g_pd3dDevice);
			Point2=new c2D(g_pd3dDevice,4,4,320-(23/2),230,"Picture\\Point2.bmp");
			Point2->InitVB(g_pd3dDevice);
			for (int k=0;k<3;k++)
			{
				Heart[k]=new cBillBoard(1,1,1,2,0.5,1);
				Heart[k]->InitVB(g_pd3dDevice);
			}
			Heart[0]->setPos(-150,0,-200);
			Heart[1]->setPos(388,0,-144);
			Heart[2]->setPos(290,0,80);
	b1=new cBillBoard(0.5,0.5,0.5,2,0.5,1);
				b1->InitVB(g_pd3dDevice);
		
			for (k=0;k<3;k++)
			{
				Krasun[k]=new cBillBoard(1,1,1,2,0.5,1);
				Krasun[k]->InitVB(g_pd3dDevice);
			}
			Krasun[0]->setPos(196,0,-170);
			Krasun[1]->setPos(-137,0,153);
			Krasun[2]->setPos(290,0,60);
		
			for(int i=0;i<5;i++)
			{
				Life1[i]->InitVB(g_pd3dDevice);
				Life1[i]->Hide();
			}
			statein=1;
			Life=5;
			Score=0;
			g_char[g_iMyPlayerId]->setPos(0,0,0);
			g_weapon[g_iMyPlayerId]->setPos(0,0,0);
			g_char[g_iMyPlayerId]->settype(typeChar);
			g_weapon[g_iMyPlayerId]->settype(typeChar+1);
			view1.setSlow(*g_char[g_iMyPlayerId]);
			if(bHost)
			{		
				for (int i=0;i<5;i++)
				{	
					CanEnemy[i]=true;
					float xin=rand()%200-100;
					float yin=rand()%200-100;
					float r1=rand()%3*20;
					float r2=rand()%3;
					g_en[i] = new cEnemy();
					g_en[i]->setModel(g_SetModel.getModel(8));
					g_en[i]->settype(8);
					g_en[i]->setPos(xin,0,yin);
					g_en[i]->setBound(1);
					g_wea[i] = new cEnemy();
					g_wea[i]->setModel(g_SetModel.getModel(9));
					g_wea[i]->setPos(xin,0,yin);
					g_wea[i]->settype(9);
					g_wea[i]->setBound(1);
					g_en[i]->setup(r1,r2);
					g_wea[i]->setup(r1,r2);
					setTex(g_en[i]->gettype());
					g_en[i]->setTex(TexName);
					g_wea[i]->setTex(TexWea);
				}
				g_en[0]->setPos(390,0,160);
				g_wea[0]->setPos(390,0,160);
				g_en[1]->setPos(200,0,160);
				g_wea[1]->setPos(200,0,160);
				g_en[2]->setPos(52,0,160);
				g_wea[2]->setPos(52,0,160);
					g_en[3]->setPos(-160,0,-160);
				g_wea[3]->setPos(-160,0,-160);
				g_en[4]->setPos(-150,0,-160);
				g_wea[4]->setPos(-150,0,-160);

			}
			else
			{
				
				void  *packet;
				PacketRequestEnemy pacRE; 
				pacRE.dwSize = sizeof(PacketRequestEnemy);
				pacRE.dwType = PACKET_TYPE_REQUEST_ENEMY;
				pacRE.state = 1;
				packet = (VOID*)&pacRE;
				HRESULT hReturn =hrSendPeerMessage(-1,PACKET_TYPE_REQUEST_ENEMY,packet);		
				if(FAILED(hReturn))exit(0);
			/*	
				for(int i =0;i<MAX_PLAYERS;i++)
				{
					if(i_char[i].bActive)
					{
						void  *packet;
						PacketRequestChar pacRC; 
						pacRC.dwSize = sizeof(PacketRequestChar);
						pacRC.dwType = PACKET_TYPE_REQUEST_CHAR;
						pacRC.idNumber = i_char[i].dpnidPlayer;
						packet = (VOID*)&pacRC;
						
						HRESULT hReturn =hrSendPeerMessage(-1,PACKET_TYPE_REQUEST_CHAR,packet);		
						if(FAILED(hReturn))exit(0);
					}
				}*/
			}
			void			*packet;
			PacketTypeChar     pacTypeChar;
			pacTypeChar.dwSize = sizeof(PacketTypeChar);
			pacTypeChar.dwType = PACKET_TYPE_TYPE_CHAR;
			pacTypeChar.Type = typeChar;
			pacTypeChar.Number = i_char[g_iMyPlayerId].dpnidPlayer;
			packet = (VOID*)&pacTypeChar;
			HRESULT hReturn = hrSendPeerMessage(-1,PACKET_TYPE_TYPE_CHAR,packet);		
			if(FAILED(hReturn))exit(0);
			setTex(typeChar);
			g_char[g_iMyPlayerId]->setModel(g_SetModel.getModel(typeChar));
			g_weapon[g_iMyPlayerId]->setModel(g_SetModel.getModel(typeChar+1));
			g_char[g_iMyPlayerId]->setTex(TexName);
			g_weapon[g_iMyPlayerId]->setTex(TexWea);		
			talk=false;
			cWindow::GetMainWindow()->setEnter(false);
				strcpy(szInMsg,"");
			
		}
		if(statein==1)
		{
			if(cWindow::GetMainWindow()->getEnter())
			{
				if(!talk)
				{
					cWindow::GetMainWindow()->setEnter(false);
					cWindow::GetMainWindow()->ClearCommand();
					cWindow::GetMainWindow()->ClearMessage();
					g_char[g_iMyPlayerId]->stand();
					talk=true;
					cWindow::GetMainWindow()->setWrite();
				}
				else
				{
					PacketChat		ChatMsg;
					void			*packet;
					cWindow::GetMainWindow()->SetNoWrite();
					cWindow::GetMainWindow()->setEnter(false);
					ChatMsg.dwSize = sizeof(PacketChat);
					ChatMsg.dwType = PACKET_TYPE_CHAT;
					strcpy(ChatMsg.szText,Name.data());
					strcat(ChatMsg.szText,":");
					strcat(ChatMsg.szText,cWindow::GetMainWindow()->szSystemMessage.data());
					// Convert the packet to a void stream
					packet = (VOID*)&ChatMsg;
					// Send the chat packet
					hrSendPeerMessage(-1,PACKET_TYPE_CHAT,packet);
					talk=false;
					strcpy(szInMsg,"");
				}
			}
			for(int j=0;j<5;j++)
			{
					Life1[j]->Hide();
			}
			if(5-Life<5)Life1[5-Life]->Show();
			
			g_weapon[g_iMyPlayerId]->Animate(true);
			for(int i = 0 ; i < MAX_PLAYERS ; i++ ) 
			{
				if( (i_char[i].bActive)&&(i!=g_iMyPlayerId )) 
				{
					g_char[i]->Animate(true);
					g_weapon[i]->Animate(true);
				//	g_char[i]->Interpulate(timeGetTime(),dwUpdateTime,dwUpdateTime+100);
				//	g_weapon[i]->Interpulate(timeGetTime(),dwUpdateTime,dwUpdateTime+100);
				}
			}
				if(g_char[g_iMyPlayerId]->Animate(true))
				{
					statein=2; 
					statechange=11;
				}
			NumEnemy=0;
			bool chk;
			for(i=0;i<3;i++)
			{
				if(Heart[i]->isActive())
					if(Heart[i]->CheckCol(*g_char[g_iMyPlayerId]))
					{
						cGet.play();
						if(Life<5)Life++;
						Heart[i]->Hide();
					}
				if(Krasun[i]->isActive())
					if(Krasun[i]->CheckCol(*g_char[g_iMyPlayerId]))
					{
						cGet.play();
						g_char[g_iMyPlayerId]->incMax();
						Krasun[i]->Hide();
					}


			}
			for( i=0;i<5;i++)	
			{
				if(CanEnemy[i])
				{
					if(!g_en[i]->getDie())	NumEnemy++;
					if(bHost)
					{
						chk=g_wea[i]->check(g_SetModel.getXModel(2)->getMesh());
						if(s1.CheckBound(*g_en[i]))
						{
							g_en[i]->die();
							g_wea[i]->die();
							Score+=200;
						}
						for(int j=0;j<8;j++)
						if(i_char[j].bActive)
						{
						g_wea[i]->carry(g_char[j],chk);	
						if(g_en[i]->carry(g_char[j],chk)==1)
							{
								if(g_en[i]->CanShot())
								{ 
									BOOL hit;
									float u,v,dist;
									DWORD index;
									D3DXVECTOR3 a3(g_en[i]->getX(),g_en[i]->getY()+2,g_en[i]->getZ());
									D3DXVECTOR3 b3(cos(g_en[i]->getDirection()),0,sin(g_en[i]->getDirection()));
									D3DXIntersect(	g_SetModel.getXModel(2)->getMesh(),&a3,&b3,&hit,&index,&u,&v,&dist);
				
									cShot *a=new cShot(g_en[i]->getX(),g_en[i]->getY(),g_en[i]->getZ(),g_en[i]->getDirection(),0.3,1,b1,dist);
									s2.add(*a);
									void			*packet;
						PacketShot	pacShot;
					
						pacShot.dwSize = sizeof(PacketShot);
						pacShot.dwType = PACKET_TYPE_SHOT;
						pacShot.Number=i;
						pacShot.x = g_en[i]->getX();
						pacShot.y = g_en[i]->getY();
						pacShot.z = g_en[i]->getZ();
						pacShot.dir1=g_en[i]->getDirection();
						pacShot.sp=0.3;
						pacShot.b=1;
						pacShot.ene=true;
						pacShot.dist=dist;
						packet = (VOID*)&pacShot;
						HRESULT hReturn = hrSendPeerMessage(-1,PACKET_TYPE_SHOT,packet);
						break;
								}
							}
						}							
						
					}
				}
						
			}
			if(s2.CheckBound(*g_char[g_iMyPlayerId]))
			{
				Life--;
			if(Life==0)	g_char[g_iMyPlayerId]->die();
			}
			if(talk)
			{

				strcpy(szInMsg,"INPUT: ");
				strcat(szInMsg,cWindow::GetMainWindow()->szSystemMessage.data());
				strcat(szInMsg,"_");
			}
			else
			{
				if (in1%2==1)
				{
					view1.getOut();
				}
				if ((in1>>1)%2==1)
				{
					Tempnum=(Tempnum++)%10;
					view1.getIn();
				}
				if ((in1>>2)%2==1)
				{
					view1.getLeft();
				}
				if ((in1>>3)%2==1)
				{
					view1.getRight();
				}
				if ((in1>>4)%2==1)
				{
					BOOL hit;
					float u,v,dist;
					DWORD index;
			//	for (int i=1;i<100;i++)
				{
					g_char[g_iMyPlayerId]->walk();
					g_char[g_iMyPlayerId]->goAhead();
					g_weapon[g_iMyPlayerId]->walk();
					g_weapon[g_iMyPlayerId]->goAhead();
			
					D3DXVECTOR3 a1(g_char[g_iMyPlayerId]->getX(),g_char[g_iMyPlayerId]->getY()+2,g_char[g_iMyPlayerId]->getZ());
					D3DXVECTOR3 b1(cosf(g_char[g_iMyPlayerId]->getDirection()),0,-sinf(g_char[g_iMyPlayerId]->getDirection()));
				//	D3DXVECTOR3 b1(0,1,0);
					D3DXIntersect(	g_SetModel.getXModel(2)->getMesh(),&a1,&b1,&hit,&index,&u,&v,&dist);
						if(!(hit)||	(dist>4)){
				//	D3DXVECTOR3 a1(g_char[g_iMyPlayerId]->getX(),g_char[g_iMyPlayerId]->getY()+4,g_char[g_iMyPlayerId]->getZ());
		//			D3DXVECTOR3 b1(0,-1,0);
				//	D3DXVECTOR3 b1(0,1,0);
			//	     D3DXIntersect(	g_SetModel.getXModel(2)->getMesh(),&a1,&b1,&hit,&index,&u,&v,&dist);
			//			if(!(hit)||	(dist>1.5)){
					/*D3DXIntersect(
	  LPD3DXBASEMESH pMesh,
	  CONST D3DXVECTOR3* pRayPos,
	  CONST D3DXVECTOR3* pRayDir,
	  BOOL* pHit,
	  DWORD* pFaceIndex,
	  FLOAT* pU,
	  FLOAT* pV,
	  FLOAT* pDist
	);
*/
	if(sWalk.isPlay())
	sWalk.play();
		}
				else
				{
					g_char[g_iMyPlayerId]->walk();
			g_char[g_iMyPlayerId]->goBack();
			//		g_char[g_iMyPlayerId]->goBack();
					g_weapon[g_iMyPlayerId]->walk();
			g_weapon[g_iMyPlayerId]->goBack();
			//		g_weapon[g_iMyPlayerId]->goBack();
				
				}
			}
				}
				
				else
				{
							sWalk.stop();
			
					g_char[g_iMyPlayerId]->stand();
					g_weapon[g_iMyPlayerId]->stand();
				}
				if ((in1>>5)%2==1)
				{
   					g_char[g_iMyPlayerId]->goBack();
					g_weapon[g_iMyPlayerId]->goBack();
				}
				if ((in1>>6)%2==1)
				{
					g_char[g_iMyPlayerId]->turnLeft();
					g_weapon[g_iMyPlayerId]->turnLeft();
					
				}
				if ((in1>>7)%2==1)
				{
	 				g_char[g_iMyPlayerId]->turnRight();
					g_weapon[g_iMyPlayerId]->turnRight();
				}
				if ((in1>>8)%2==1)
				{
					g_char[g_iMyPlayerId]->jump();
					g_weapon[g_iMyPlayerId]->jump();
		    		if(g_char[g_iMyPlayerId]->CanShot())
					{
						//if(bHost)
						{
							
							    sShot.play();
								BOOL hit;
								float u,v,dist;
								DWORD index;
								D3DXVECTOR3 a3(g_char[g_iMyPlayerId]->getX(),g_char[g_iMyPlayerId]->getY()+2,g_char[g_iMyPlayerId]->getZ());
								D3DXVECTOR3 b3(cos(g_char[g_iMyPlayerId]->getDirection()),0,-sin(g_char[g_iMyPlayerId]->getDirection()));
								D3DXIntersect(	g_SetModel.getXModel(2)->getMesh(),&a3,&b3,&hit,&index,&u,&v,&dist);
			
								cShot *a=new cShot(g_char[g_iMyPlayerId]->getX(),g_char[g_iMyPlayerId]->getY(),g_char[g_iMyPlayerId]->getZ(),g_char[g_iMyPlayerId]->getDirection(),0.3,1,b1,dist);
					    		s1.add(*a);
				//		}
				//		else
				//		{
							void			*packet;
							PacketShot	pacShot;
						
							pacShot.dwSize = sizeof(PacketShot);
							pacShot.dwType = PACKET_TYPE_SHOT;
							pacShot.Number=i_char[g_iMyPlayerId].dpnidPlayer;
							pacShot.x = g_char[g_iMyPlayerId]->getX();
							pacShot.y = g_char[g_iMyPlayerId]->getY();
							pacShot.z = g_char[g_iMyPlayerId]->getZ();
							pacShot.dir1=g_char[g_iMyPlayerId]->getDirection();
							pacShot.sp=0.3;
							pacShot.b=1;
							if(main_mode==MODE_1VS2)
								pacShot.ene=true;
							else
								pacShot.ene=false;
							pacShot.dist=dist;
							packet = (VOID*)&pacShot;
							HRESULT hReturn = hrSendPeerMessage(-1,PACKET_TYPE_SHOT,packet);
						}
					}
				}
				if ((in1>>9)%2==1)
				{
					OnFog=true;
				}
				if ((in1>>10)%2==1)
				{
					view1.setSlow(*g_char[g_iMyPlayerId]);
				}
				if((in1>>11)%2==1)
				{
					if(CanEnemy[1])
					g_en[1]->walkup(100);
				}
				if((in1>>12)%2==1)
				{
					FrontLight=true;
				}
				if((in1>>13)%2==1)
				{	
					if(CanEnemy[1])
					g_en[1]->walkup(100);
				}
				else
				{
				}
				if((in1>>14)%2==1)
				{
					OnNight=false;
				}
			}
			if(OnFog)
			{
			fogstart;	if(fogend>300)fogend-=20;
    g_pd3dDevice->SetRenderState(D3DRS_FOGSTART,*(DWORD*)&fogstart);
    g_pd3dDevice->SetRenderState(D3DRS_FOGEND,*(DWORD*)&fogend);

	g_pd3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE,TRUE);

				g_pd3dDevice->SetRenderState(D3DRS_FOGENABLE,TRUE);
			}
			else
			{
				g_pd3dDevice->SetRenderState(D3DRS_FOGENABLE,FALSE);
			}

			i_char[g_iMyPlayerId].vecCurPos.x =        g_char[g_iMyPlayerId]->getX();
			i_char[g_iMyPlayerId].vecCurPos.y =        g_char[g_iMyPlayerId]->getY();
			i_char[g_iMyPlayerId].vecCurPos.z =        g_char[g_iMyPlayerId]->getZ();
			vUpdateNetwork();
			strcpy(szSystemMessage,cWindow::GetMainWindow()->szSystemMessage.data());
		}
		if (statein==2)
		{
			state=statechange;
			g_manager.RemoveAll();
			statein=0;
		}	

	}
	if(state==11)
	{
		if(statein==0)
		{
			AllPage=new c2D(g_pd3dDevice,800,600,0,0,"Picture\\GameOver.bmp");
			AllPage->InitVB(g_pd3dDevice);
	//		bYes=new c2D(g_pd3dDevice,87*MUL,242*MUL,(498-400+44)*MUL,(21-300+122)*MUL,"Picture\\yes.bmp");
	//		bYes->InitVB(g_pd3dDevice);
	//		bNo=new c2D(g_pd3dDevice,87*MUL,242*MUL,(404.5-400+44)*MUL,(21-300+122)*MUL,"Picture\\No.bmp");
	//		bNo->InitVB(g_pd3dDevice);
			statein=1;
			Score=0;
		}
		if(statein==1)
		{
			delete AllPage;
		//	delete bYes;
		//	delete bNo;
		}
	}

}

//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all prviously initialized objects
//-----------------------------------------------------------------------------
VOID GameGraphic::CleanUp()
{
//    tiger.Destroy(); 
 //   aa.Destroy();
//	floor.Destroy();
	if( g_pd3dDevice != NULL )
        g_pd3dDevice->Release();

    if( g_pD3D != NULL )
        g_pD3D->Release();
}


HRESULT GameGraphic::InitVB()
{
		TexName	=	new char[100];
			TexWea	=	new char[100];
			NameFace= new char[100];
			TexName	=	"model\\crafy_texture.bmp";
			TexWea	=	"model\\crafy_weapon.bmp";
			NameFace	=	"Picture\\CrafyFace.bmp";
	dwUpdateTime1=0;	
	lstrcpy( m_strFont, _T("Arial") );
    m_dwFontSize = 36;
    m_pFont      = new CD3DFont( m_strFont, m_dwFontSize );
    m_pStatsFont = new CD3DFont( _T("Comic"),10, D3DFONT_BOLD );
	m_pFont->InitDeviceObjects( g_pd3dDevice );
    m_pStatsFont->InitDeviceObjects( g_pd3dDevice );
	m_pFont->RestoreDeviceObjects();
    m_pStatsFont->RestoreDeviceObjects();

	g_SetModel.Load("Data\\a.map",g_pd3dDevice);
	
	g_stand = new cCharacter();
	g_stand->setModel(g_SetModel.getModel(0));
	
	g_w1 = new cCharacter();
	g_w1->setModel(g_SetModel.getModel(1));
	Mou=new c2D(g_pd3dDevice,26,24,0,0,"Picture\\mouse.tga");
	Mou->InitVB(g_pd3dDevice);
	
	state=0;
		
	/*
	HRESULT hr;
	
	if(FAILED( hr=tiger.CreateFromXFile("tiger.x","tiger.bmp", g_plld3dDevice)))
	{
		assert(false&&"1");
		return hr;
		
	}
		if(FAILED( hr=floor.CreateFromXFile("seafloor.x","seafloor.bmp", g_pd3dDevice)))
	{	
		assert(false&&"2");
		return hr;
		
	}*/
	LPDIRECT3DVERTEXBUFFER8 p_ver;
  D3DXMATRIX m;
  D3DXMatrixRotationX(&m,-3.1316/2);
	DWORD numVer=g_SetModel.getXModel(2)->getMesh()->GetNumVertices();
	g_SetModel.getXModel(2)->getMesh()->GetVertexBuffer(&p_ver);
	p_ver->Lock(0,0,(BYTE**) &pVertices,0);
	for(DWORD i1=0;i1<numVer;i1++)
	{
		float temp=pVertices[i1].z;
		//pVertices[i1].x=100;
		pVertices[i1].z=-pVertices[i1].y;
		pVertices[i1].y=temp;
//		D3DXVec3TransformCoord(D3DVECTOR3(pVertices[i1],pVertices[i1],m);
	}
	p_ver->Unlock();	

	/*
	if(FAILED( hr=aa.CreateFromXFile("blade.x","blade.bmp",g_pd3dDevice)))
	{	
		assert(false&&"3");
		return hr;
	}

	aa.getMesh()->GetVertexBuffer(&p_ver);
	
	p_ver->Lock(0,0,(BYTE**) &pVertices,0);
    numVer=aa.getMesh()->GetNumVertices();
	for(DWORD j =0;j<numVer;j++)
	{
		  pVertices[j].x/=120.0f;
			pVertices[j].z/=120.0f;
			pVertices[j].y/=120.0f;
	}
	p_ver->Unlock();	

    
	floor.setPos(0,0,0);
	tiger.setPos(5,HeightField(5,5),5);
    aa.setPos(0,HeightField(0,0),0);
	aa.setScale(0.5f);
  //aa2.Load("C:\\WINDOWS\\Desktop\\Tutorial\\GRAPHIC\\MODELS\\Tris.md2");
  	aa2.LoadFromFile("c:\\a.ini");
	aa2.setScale(0.1f);
	aaCom.LoadFromFile("c:\\a.ini");
	aaCom.setScale(0.2f);
	
	//	aa2= new cMD2Model;
//	aa2->loadModel(g_pd3dDevice,"c:\\shotgun.md2",0,1.0f);
*///	g_manager.LoadTexture (g_pd3dDevice,"C:\\blade.bmp");
	
//	g_manager.LoadTexture (g_pd3dDevice,"C:\\a.tga");
	sk1.Init(g_pd3dDevice);
	statein=0;
  	
	return S_OK;
  
}

VOID GameGraphic::SetupLights()
{
    // Set up a material. The material here just has the diffuse and ambient
    // colors set to yellow. Note that only one material can be used at a time.
   
    // Set up a white, directional light, with an oscillating direction.
    // Note that many lights may be active at a time (but each one slows down
    // the rendering of our scene). However, here we are just using one. Also,
    // we need to set the D3DRS_LIGHTING renderstate to enable lighting
	/*
if (state==10)
{
	D3DXVECTOR3 vecDir,vecDir2,vecDir3;
    D3DLIGHT8 light,light2;
    ZeroMemory( &light, sizeof(D3DLIGHT8) );
    light.Type       = D3DLIGHT_SPOT;
    light.Diffuse.r  = 1.0f;
    light.Diffuse.g  = 1.0f;
    light.Diffuse.b  = 1.0f;
    light.Ambient.r  = 1.0f;
    light.Ambient.g  = 1.0f;
    light.Ambient.b  = 1.0f;
    light.Specular.r  = 1.0f;
    light.Specular.g  = 1.0f;
    light.Specular.b  = 1.0f;
    double a=g_char[g_iMyPlayerId]->getDirection();
	float zstart=g_char[g_iMyPlayerId]->getZ()-((sin(a)));
	float xstart=g_char[g_iMyPlayerId]->getX()-((cos(a)));
	float ystart=3;
	float zstart2=g_char[g_iMyPlayerId]->getZ()-((6*sin(a)));
	float xstart2=g_char[g_iMyPlayerId]->getX()-((6*cos(a)));
	float ystart2=HeightField(xstart,zstart);
	float zdest=g_char[g_iMyPlayerId]->getZ()-(100*(sin(a)));
	float xdest=g_char[g_iMyPlayerId]->getX()-(100*(cos(a)));
   ZeroMemory( &light2, sizeof(D3DLIGHT8) );
    light2.Type       = D3DLIGHT_POINT;
    light2.Diffuse.r  = 1.0f;
    light2.Diffuse.g  = 1.0f;
    light2.Diffuse.b  = 1.0f;
    light2.Ambient.r  = 1.0f;
    light2.Ambient.g  = 1.0f;
    light2.Ambient.b  = 1.0f;
    light2.Specular.r  = 1.0f;
    light2.Specular.g  = 1.0f;
    light2.Specular.b  = 1.0f;
    
   vecDir = D3DXVECTOR3(xstart,
                        ystart,
                        zstart );
   vecDir3 = D3DXVECTOR3(xstart2,
                        ystart2,
                        zstart2 );
      
   vecDir2 = D3DXVECTOR3(xdest,
                         0,
                         zdest );
	light.Falloff=1.0f;
	light.Theta=0.0f;
	light.Phi=3.0f;

	//	light.Position=vecDir;
   // 

	D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir2 );
   // D3DXVec3Normalize( (D3DXVECTOR3*)&light.Position, &vecDir2 );
	light.Position=vecDir;
    light2.Position=vecDir3;
  //	light.Direction=vecDir;
  	light.Attenuation1=0.2f;
    light.Range       = 100.0f;
    light2.Attenuation1=0.2f;
    light2.Range       = 100.0f;
    g_pd3dDevice->SetLight( 0, &light );
    g_pd3dDevice->SetLight( 1, &light2 );
    if(FrontLight)
	{
		g_pd3dDevice->LightEnable( 0, TRUE );
	//	g_pd3dDevice->LightEnable( 1, TRUE );
	}
		else
		{
		g_pd3dDevice->LightEnable( 0, FALSE );
	//	g_pd3dDevice->LightEnable( 1, FALSE );
		}
		g_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
    // Finally, turn on some ambient light.
	if(OnNight)
	{
		g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x00555555);
	}
	else
	{
	
		g_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x00AAAAAA);
	
	}
	}*/
}
VOID GameGraphic::SetupMatrices()
{

    // For the projection matrix, we set up a perspective transform (which
    // transforms geometry from 3D view space to 2D viewport space, with
    // a perspective divide making objects smaller in the distance). To build
    // a perpsective transform, we need the field of view (1/4 pi is common),
    // the aspect ratio, and the near and far clipping planes (which define at
    // what distances geometry should be no longer be rendered).
    HRESULT hr;
	D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, 1.0f, 1.0f, 1000.0f );
    hr=g_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID GameGraphic::Render()

{
///	if( timeGetTime() > dwUpdateTime1+16 ) 
	{
   
	// Clear the backbuffer to a blue color
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 
		D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
    SetupLights();


    // Begin the scene
     g_pd3dDevice->BeginScene();
	if(state==10)
	{
		SetupMatrices();
		g_pd3dDevice->SetRenderState (D3DRS_CULLMODE,D3DCULL_NONE);
		g_pd3dDevice->SetRenderState (D3DRS_ZENABLE ,D3DZB_USEW);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_ANISOTROPIC);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_ANISOTROPIC);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_ANISOTROPIC);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MAXANISOTROPY, 4);
	
		view1.setViewforSky(g_pd3dDevice);
		sk1.Render(g_pd3dDevice);
		view1.setView(g_pd3dDevice);
		
		g_pd3dDevice->SetTexture(0,g_manager.GetTexture ("model\\seafloor.bmp"));
		D3DXMATRIX matWorld,m1,m2,m3,matLookAt,mBack;
		D3DXMatrixIdentity(&matWorld);            
	//		D3DXMatrixRotationX(&m2,-3.1416/2);
	
	//3DXMatrixMultiply(&matWorld,&matWorld,&m2);
			D3DXMatrixTranslation(&m2,0,-4,0);
	
		D3DXMatrixMultiply(&matWorld,&matWorld,&m2);
		
	g_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

		//	g_SetModel.getXModel(0)->Render(g_pd3dDevice,true);
		g_SetModel.getXModel(2)->RenderOpt(g_pd3dDevice);
	
		for( int i = 0 ; i < MAX_PLAYERS ; i++ ) {
		if( i_char[i].bActive ) {
				g_pd3dDevice->SetTexture(0,g_manager.GetTexture (g_char[i]->getTex()));	
				g_char[i]->Render(g_pd3dDevice,true);
				g_pd3dDevice->SetTexture(0,g_manager.GetTexture (g_weapon[i]->getTex()));	
				g_weapon[i]->Render(g_pd3dDevice,true);
	
			}
		}

		for( i=0;i<5;i++)	
		{
			if(CanEnemy[i])
			{
				g_pd3dDevice->SetTexture(0,g_manager.GetTexture (g_en[i]->getTex()));
				g_en[i]->Animate(true);	
				g_en[i]->Render(g_pd3dDevice,true);
				g_pd3dDevice->SetTexture(0,g_manager.GetTexture (g_wea[i]->getTex()));
				g_wea[i]->Animate(true);	
				g_wea[i]->Render(g_pd3dDevice,true);
			}
		}

 
		g_pd3dDevice->SetTexture(0,g_manager.GetTexture ("Picture\\BlueBullet.tga"));
	//	b1->Render(g_pd3dDevice,view1);
		int  decimal, sign;
			char a[200];
		int dec1,dec2;
	
		s1.Render(g_pd3dDevice,view1);
    	s2.Render(g_pd3dDevice,view1);
	/*	c2D::PostInitialize(g_pd3dDevice,1024,768);
		Mou->Render(g_pd3dDevice);
	
    	m_pStatsFont->DrawText( 200, 20, 0xFFFFFFFF, fcvt(Score,0, &decimal, &sign ));*/
//	 	m_pStatsFont->DrawText( 6, 20, 0xFFFFFFFF,szSystemMessage);
		char temp[200],temp1[10];
		itoa(NumEnemy,temp,10);
		strcat(temp,"        X=");
		strcat(temp,fcvt( g_char[g_iMyPlayerId]->getX(),8,&dec1,&dec2));
		strcat(temp,"        Y=");
		strcat(temp,fcvt( g_char[g_iMyPlayerId]->getY(),8,&dec1,&dec2));
		strcat(temp,"        Z=");
		strcat(temp,fcvt( g_char[g_iMyPlayerId]->getZ(),8,&dec1,&dec2));
		g_pd3dDevice->SetTexture(0,g_manager.GetTexture ("Picture\\heart.tga"));
		for(int k=0;k<3;k++)
			Heart[k]->Render(g_pd3dDevice,view1);
g_pd3dDevice->SetTexture(0,g_manager.GetTexture ("Picture\\weaponface.bmp"));
		
		for(k=0;k<3;k++)
			Krasun[k]->Render(g_pd3dDevice,view1);

    	c2D::PostInitialize(g_pd3dDevice,800,600);
		//		g_manager.LoadTexture (g_pd3dDevice,"Picture\\life1.tga");
			Map->Render(g_pd3dDevice);
	
		for( i=0;i<5;i++)	
		{
			if(CanEnemy[i])
			{
				Point->SetPos(g_en[i]->getX()/4.2+280,-(g_en[i]->getZ()/4)+225);
				Point->Render(g_pd3dDevice);
			}
		}
		for(  i = 0 ; i < MAX_PLAYERS ; i++ ) 
		{
			if( i_char[i].bActive ) 
			{
				Point2->SetPos(g_char[i]->getX()/4.2+280,-(g_char[i]->getZ()/4)+225);
				Point2->Render(g_pd3dDevice);
			}
		}
		
		strcpy(a,Name.data());
		if(5-Life<5)Life1[5-Life]->Render(g_pd3dDevice);
		Face[g_char[g_iMyPlayerId]->gettype()/2]->Render(g_pd3dDevice);
		m_pStatsFont->DrawText( 6, 40, 0xFFFFFFFF,a );
		m_pStatsFont->DrawText( 6, 60, 0xFFFFFFFF, szChat );
		m_pStatsFont->DrawText( 6, 360, 0xFFFFFFFF, szInMsg ); 
		m_pStatsFont->DrawText( 6, 500, 0xFFFFFFFF, temp ); 
		
    }
	else if(state==0)
	{
	
		c2D::PostInitialize(g_pd3dDevice,800,600);
		AllPage->Render(g_pd3dDevice);
		PlayB->Render(g_pd3dDevice);
		ExitB->Render(g_pd3dDevice);
		Mou->Render(g_pd3dDevice);
   	
	}
	else if(state==1)
	{
		c2D::PostInitialize(g_pd3dDevice,800,600);
		AllPage->Render(g_pd3dDevice);
		in1vs21->Render(g_pd3dDevice);
   		in1vsCom1->Render(g_pd3dDevice);
   		in12vsCom1->Render(g_pd3dDevice);
		in1vs22->Render(g_pd3dDevice);
   		in1vsCom2->Render(g_pd3dDevice);
   		in12vsCom2->Render(g_pd3dDevice);
		CheckBox->Render(g_pd3dDevice);
		if(statein==4)
		{
			m_pStatsFont->DrawText( 422, 265, 0xFFFFFFFF,szSystemMessage);
		}
		if(statein==5)
		{
			HostBut->Render(g_pd3dDevice);
			JoinBut->Render(g_pd3dDevice);
			char temp[200];
			strcpy(temp,Name.data());
			m_pStatsFont->DrawText( 422, 265, 0xFFFFFFFF,temp);
			m_pStatsFont->DrawText( 422, 299, 0xFFFFFFFF,szSystemMessage);
		}
		Mou->Render(g_pd3dDevice);
	
	}
	else if(state==3)
	{
		SetupMatrices();
		g_pd3dDevice->SetRenderState (D3DRS_CULLMODE,D3DCULL_NONE);
		g_pd3dDevice->SetRenderState (D3DRS_ZENABLE ,D3DZB_USEW);
	/*	g_pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_ANISOTROPIC);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_ANISOTROPIC);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_ANISOTROPIC);
		g_pd3dDevice->SetTextureStageState(0, D3DTSS_MAXANISOTROPY, 4);*/
		D3DMATERIAL8 a1;
		a1.Ambient.r=255;
		a1.Ambient.g=255;
		a1.Ambient.b=255;
		a1.Ambient.a=0;
		a1.Diffuse=a1.Ambient=a1.Specular=a1.Emissive ;
		a1.Power=10;
		g_pd3dDevice->SetMaterial(&a1);
    	view1.setView(g_pd3dDevice);
		g_w1->Animate(true);
		g_stand->Animate(true); 
		g_pd3dDevice->SetTexture(0,g_manager.GetTexture (TexWea));
		g_w1->Render(g_pd3dDevice,true);
		g_pd3dDevice->SetTexture(0,g_manager.GetTexture (TexName));
		g_stand->Render(g_pd3dDevice,true);
		c2D::PostInitialize(g_pd3dDevice,800,600);
		AllPage->Render(g_pd3dDevice);
		Ctua->Render(g_pd3dDevice);
		Itua->Render(g_pd3dDevice);
		Mtua->Render(g_pd3dDevice);
		Stua->Render(g_pd3dDevice);
		Mou->Render(g_pd3dDevice);
	}
	if(state==11)
	{
		AllPage->Render(g_pd3dDevice);
	//	g_pd3dDevice->SetTexture(0,g_manager.GetTexture ("Picture\\yes.bmp"));
	//	bYes->Render(g_pd3dDevice);
	//	g_pd3dDevice->SetTexture(0,g_manager.GetTexture ("Picture\\No.bmp"));
	//	bNo->Render(g_pd3dDevice);
		Mou->Render(g_pd3dDevice);
	
	}
	g_pd3dDevice->EndScene();
	dwUpdateTime1 = timeGetTime();

 
    // Present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
	  	}

}
HRESULT GameGraphic::hrInitializeDirectPlay() 
{
	HRESULT	hReturn;
	
	// Initialize COM
	hReturn = CoInitialize( NULL );
	if( FAILED(hReturn) ) {
	//	MessageBox( hWindow, "Error Initializing COM", "DirectPlay Error", MB_ICONERROR );
		assert(false);
		return hReturn;
	}

	// Initialize critical sections for multi-threading
	InitializeCriticalSection( &g_csModifyPlayer );
	
	// Create IDirectPlay8Peer Object
	if( FAILED( hReturn = CoCreateInstance( CLSID_DirectPlay8Peer, 
		NULL, 
		CLSCTX_INPROC_SERVER, 
		IID_IDirectPlay8Peer, 
		(LPVOID*) &g_pDP ) ) )
		assert(false);
     //   MessageBox( hWindow, "Can't Create DPlayPeer", "DirectPlay Error", MB_ICONERROR );

	// Init IDirectPlay8Peer Message Handler
	if( FAILED( hReturn = g_pDP->Initialize( NULL, DirectPlayMessageHandler, 0 ) ) ) {
	//	MessageBox( hWindow, "Failed to Message Handler", "DirectPlay Error", MB_ICONERROR );
		assert(false);
		return -1;
	}

	// Create a device address
	hReturn = CoCreateInstance( CLSID_DirectPlay8Address, NULL,CLSCTX_INPROC_SERVER, IID_IDirectPlay8Address, (LPVOID*) &g_pDeviceAddress );
	if( FAILED(hReturn) ) {
	//	MessageBox( hWindow, "Failed to Create Device", "CoCreateInstance()", MB_ICONERROR );
		assert(false);
		return -1;
	}

	// Set our service provider to TCP/IP
	if( FAILED( hReturn = g_pDeviceAddress->SetSP( &CLSID_DP8SP_TCPIP ) ) ) {
	//	MessageBox( hWindow, "Failed to SetSP() for Device Address", "Invalid Param", MB_ICONERROR );
		assert(false);
		return -1;
	}

	// Create a host address
	hReturn = CoCreateInstance( CLSID_DirectPlay8Address, NULL,CLSCTX_INPROC_SERVER, IID_IDirectPlay8Address, (LPVOID*) &g_pHostAddress );
	if( FAILED(hReturn) ) {
	//	MessageBox( hWindow, "Failed to Create Host Address()", "Invalid Param", MB_ICONERROR );
		assert(false);
		return -1;
	}
	// Set the host address to TCP/IP
	if( FAILED( hReturn = g_pHostAddress->SetSP( &CLSID_DP8SP_TCPIP ) ) ) {
	//	MessageBox( hWindow, "Failed to SetSP() for Host Address", "Invalid Param", MB_ICONERROR );
	
	assert(false);	
		return -1;
	}

	// Create connection complete event for later use
	g_hConnectCompleteEvent = CreateEvent( NULL, FALSE, FALSE, NULL );

	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: DirectPlayMessageHandler()
// Desc: Handles all Direct Play messages
//-----------------------------------------------------------------------------
HRESULT  WINAPI DirectPlayMessageHandler( PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer )
{

	return GameGraphic::GetGraphic()->DirectPlayMessageHandle( pvUserContext, dwMessageId, pMsgBuffer );
}
HRESULT GameGraphic::DirectPlayMessageHandle( PVOID pvUserContext, DWORD dwMessageId, PVOID pMsgBuffer )
{
	HRESULT				hReturn = S_OK;
	PacketChat			*ChatMsg;
	PacketAngle			*pacAngle;
	PacketAction		*pacAction;
	PacketVelocity		*pacVel;
	PacketPosition		*pacPos;
	PacketBullet		*pacBul;
	PacketScore			*pacScore;
	PacketNumberEnemy   *pacNum;
	PacketTypeEnemy     *pacTypeEnemy;
	PacketTypeChar      *pacTypeChar;
	PacketPosEnemy      *pacPosEnemy;
	PacketRequestChar   *pacRequestChar;
	PacketActionEnemy   *pacActEnemy ;
	PacketAngleEnemy	*pacAngEnemy ;
	PacketShot			*pacShot ;
	int					iPlayerID;
	
	switch( dwMessageId ) 
	{
		case DPN_MSGID_CREATE_PLAYER:
		{
			hrCreatePlayer(pvUserContext,pMsgBuffer);
			break;
		}
		
		case DPN_MSGID_DESTROY_PLAYER:
		{
			
			hrDestroyPlayer(pvUserContext,pMsgBuffer);
			break;
		}
		
		case DPN_MSGID_HOST_MIGRATE:
		{
		/*	PDPNMSG_HOST_MIGRATE pHostMigrateMsg;
		   pHostMigrateMsg = (PDPNMSG_HOST_MIGRATE)pMsgBuffer;
			
			// Check to see if we are the new host
			if( pHostMigrateMsg->dpnidNewHost == g_dpnidLocalPlayer ) {
			}*/
			break;
		}
		
		case DPN_MSGID_TERMINATE_SESSION:
		{
		/*	PDPNMSG_TERMINATE_SESSION pTerminateSessionMsg;
			pTerminateSessionMsg = (PDPNMSG_TERMINATE_SESSION)pMsgBuffer;*/
			break;
		}
		
		case DPN_MSGID_RECEIVE:
		{
	
			PDPNMSG_RECEIVE pReceiveMsg;
			PacketGeneric	*PGen;

			pReceiveMsg = (PDPNMSG_RECEIVE)pMsgBuffer;
			
			// Cast it to a generic packet so we can check the type
			PGen = (PacketGeneric*)pReceiveMsg->pReceiveData;

			// If it is a chat packet, display its contents
			if( PGen->dwType == PACKET_TYPE_CHAT ) {
				// Convert the packet to a chat packet
				ChatMsg = (PacketChat*)pReceiveMsg->pReceiveData;
				// Output it on our screen
				sprintf(szChat,ChatMsg->szText);
			
			}
			else if( PGen->dwType == PACKET_TYPE_ANGLE ) {
				// Convert the packet to a chat packet
				iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				pacAngle = (PacketAngle*)pReceiveMsg->pReceiveData;
				EnterCriticalSection( &g_csModifyPlayer );
				g_char[iPlayerID]->setDirection(pacAngle->fAngle);
				g_weapon[iPlayerID]->setDirection(pacAngle->fAngle);
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if( PGen->dwType == PACKET_TYPE_ACTION ) {
				// Convert the packet to a chat packet
				iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				pacAction = (PacketAction*)pReceiveMsg->pReceiveData;
				EnterCriticalSection( &g_csModifyPlayer );
				g_char[iPlayerID]->setstate(pacAction->Action);
				g_weapon[iPlayerID]->setstate(pacAction->Action);
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if( PGen->dwType == PACKET_TYPE_VELOCITY ) {
				// Convert the packet to a chat packet
				iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				pacVel = (PacketVelocity*)pReceiveMsg->pReceiveData;
				EnterCriticalSection( &g_csModifyPlayer );
				//PlayerInfo[iPlayerID].fVelocity = pacVel->fVelocity;
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if( PGen->dwType == PACKET_TYPE_SHOT) {
				// Convert the packet to a chat packet
		//	if(bHost)
				{
					pacShot = (PacketShot*)pReceiveMsg->pReceiveData;
					EnterCriticalSection( &g_csModifyPlayer );
					cShot *a=new cShot(pacShot->x,pacShot->y,pacShot->z,pacShot->dir1,pacShot->sp,pacShot->b,b1,pacShot->dist);
					if(pacShot->ene)s2.add(*a);
					else s1.add(*a);
					//PlayerInfo[iPlayerID].fVelocity = pacVel->fVelocity;
					LeaveCriticalSection( &g_csModifyPlayer );
				}
			}
			else if( PGen->dwType == PACKET_TYPE_POSITION ) {
				// Convert the packet to a chat packet
				pacPos = (PacketPosition*)pReceiveMsg->pReceiveData;
				iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				EnterCriticalSection( &g_csModifyPlayer );
				
				i_char[iPlayerID].vecCurPos.x = pacPos->fx;
				i_char[iPlayerID].vecCurPos.z = pacPos->fz;
				g_char[iPlayerID]->setPos(pacPos->fx,0,pacPos->fz);
				g_weapon[iPlayerID]->setPos(pacPos->fx,0,pacPos->fz);
				LeaveCriticalSection( &g_csModifyPlayer);
			}
			else if( PGen->dwType == PACKET_TYPE_BULLET ) {
				// Convert the packet to a chat packet
				pacBul = (PacketBullet*)pReceiveMsg->pReceiveData;
				//vCreateBullet(pacBul->Bullet.dpOwner,pacBul->Bullet.fx,pacBul->Bullet.fz,pacBul->Bullet.fVelocity,pacBul->Bullet.fRot);
			}
			else if( PGen->dwType == PACKET_TYPE_SCORE ) {
				// Convert the packet to a chat packet
				pacScore = (PacketScore*)pReceiveMsg->pReceiveData;
			//	iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				EnterCriticalSection( &g_csModifyPlayer );
				//PlayerInfo[iPlayerID].lScore = pacScore->lScore;
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if( PGen->dwType == PACKET_TYPE_NUMBER_ENEMY ) {
				// Convert the packet to a chat packet
				pacNum = (PacketNumberEnemy*)pReceiveMsg->pReceiveData;
			//	iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				EnterCriticalSection( &g_csModifyPlayer );
				MaxEnemy=pacNum->Number;
			/*	for (int i=0;i<MaxEnemy;i++)
				{
					CanEnemy[i]=false;
				}*/
				//PlayerInfo[iPlayerID].lScore = pacScore->lScore;
			LeaveCriticalSection( &g_csModifyPlayer);
			}
			else if( PGen->dwType == PACKET_TYPE_TYPE_ENEMY ) {
				// Convert the packet to a chat packet
				
				pacTypeEnemy = (PacketTypeEnemy*)pReceiveMsg->pReceiveData;
			//	iPlayerID = iGetPlayerID(pReceiveMsg->dpnidSender);
				EnterCriticalSection( &g_csModifyPlayer );
					g_en[pacTypeEnemy->Number]= new cEnemy();
				g_en[pacTypeEnemy->Number]->setModel(g_SetModel.getModel(pacTypeEnemy->Type));
				g_wea[pacTypeEnemy->Number]= new cEnemy();
				g_wea[pacTypeEnemy->Number]->setModel(g_SetModel.getModel(pacTypeEnemy->Type+1));
				g_en[pacTypeEnemy->Number]->settype(pacTypeEnemy->Type);
				g_wea[pacTypeEnemy->Number]->settype(pacTypeEnemy->Type+1);
			
				CanEnemy[pacTypeEnemy->Number] = true;
				setTex(g_en[pacTypeEnemy->Number]->gettype());
				g_en[pacTypeEnemy->Number]->setTex(TexName);
				g_wea[pacTypeEnemy->Number]->setTex(TexWea);
	
				//PlayerInfo[iPlayerID].lScore = pacScore->lScore;
				LeaveCriticalSection( &g_csModifyPlayer );
			}
		else if( PGen->dwType == PACKET_TYPE_TYPE_CHAR ) {
				// Convert the packet to a chat packet
					
				pacTypeChar = (PacketTypeChar*)pReceiveMsg->pReceiveData;
				iPlayerID = iGetPlayerID(pacTypeChar->Number);
				if(i_char[iPlayerID].bActive)
				{
					EnterCriticalSection( &g_csModifyPlayer );
					g_char[iPlayerID]->settype(pacTypeChar->Type);
					g_weapon[iPlayerID]->settype(pacTypeChar->Type+1);
					g_char[iPlayerID]->setModel(g_SetModel.getModel(pacTypeChar->Type));
					g_weapon[iPlayerID]->setModel(g_SetModel.getModel(pacTypeChar->Type+1));
					setTex(	g_char[iPlayerID]->gettype()) ;
					g_char[iPlayerID] ->setTex(TexName);
					g_weapon[iPlayerID]->setTex(TexWea); 
					//PlayerInfo[iPlayerID].lScore = pacScore->lScore;
					LeaveCriticalSection( &g_csModifyPlayer );
				}
			}
			else if( PGen->dwType == PACKET_TYPE_POS_ENEMY ) 
			{
				pacPosEnemy = (PacketPosEnemy*)pReceiveMsg->pReceiveData;
				EnterCriticalSection( &g_csModifyPlayer );
				if(CanEnemy[pacPosEnemy->Number]== true)
				{
					g_en[pacPosEnemy->Number]->setPos(pacPosEnemy->x,pacPosEnemy->y,pacPosEnemy->z);
					g_wea[pacPosEnemy->Number]->setPos(pacPosEnemy->x,pacPosEnemy->y,pacPosEnemy->z);
				}
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if( PGen->dwType == PACKET_TYPE_ACTION_ENEMY ) 
			{
				pacActEnemy = (PacketActionEnemy*)pReceiveMsg->pReceiveData;
				EnterCriticalSection( &g_csModifyPlayer );
				if(CanEnemy[pacActEnemy->Number]== true)
				{
					g_en[pacActEnemy->Number]->setstate(pacActEnemy->Action);
					g_wea[pacActEnemy->Number]->setstate(pacActEnemy->Action);
				}
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if( PGen->dwType == PACKET_TYPE_ANGLE_ENEMY ) 
			{
				pacAngEnemy = (PacketAngleEnemy*)pReceiveMsg->pReceiveData;
				EnterCriticalSection( &g_csModifyPlayer );
				if(CanEnemy[pacAngEnemy->Number]== true)
				{
					g_en[pacAngEnemy->Number]->setDirection(pacAngEnemy->fAngle);
					g_wea[pacAngEnemy->Number]->setDirection(pacAngEnemy->fAngle);
				}
				LeaveCriticalSection( &g_csModifyPlayer );
			}
			else if(PGen->dwType == PACKET_TYPE_REQUEST_CHAR)
			{
				pacRequestChar  = (PacketRequestChar *)pReceiveMsg->pReceiveData;
				iPlayerID = iGetPlayerID(pacRequestChar->idNumber);
				if(bHost)
				{
					if(i_char[iPlayerID].bActive)
					{
						void			*packet;
						PacketTypeChar     pacTypeChar;
						pacTypeChar.dwSize = sizeof(PacketTypeChar);
						pacTypeChar.dwType = PACKET_TYPE_TYPE_CHAR;
						pacTypeChar.Number=pacRequestChar->idNumber;
						pacTypeChar.Type = g_char[iPlayerID]->gettype();
						packet = (VOID*)&pacTypeChar;
						HRESULT hReturn = hrSendPeerMessage(-1,PACKET_TYPE_TYPE_CHAR,packet);		
						if(FAILED(hReturn))exit(0);
					}
				}
			}
			else if(PGen->dwType == PACKET_TYPE_REQUEST_ENEMY)
			{
				if(bHost)
				{
					void			*packet;
					PacketNumberEnemy	pacNE;
					PacketTypeEnemy  pacTE;
					PacketPosEnemy  pacPE;
					pacNE.dwSize = sizeof(PacketNumberEnemy);
					pacNE.dwType = PACKET_TYPE_NUMBER_ENEMY;
					pacNE.Number = 5;
					packet = (VOID*)&pacNE;//dpnidSender
					hReturn = hrSendPeerMessage(-1,PACKET_TYPE_NUMBER_ENEMY,packet);
					for(int i=0;i<5;i++)
					{
						if(CanEnemy[i])
						{
							pacTE.dwSize = sizeof(PacketTypeEnemy);
							pacTE.dwType = PACKET_TYPE_TYPE_ENEMY;
							pacTE.Number = i;
							pacTE.Type = g_en[i]->gettype();
							packet = (VOID*)&pacTE;
							hReturn = hrSendPeerMessage(-1,PACKET_TYPE_TYPE_ENEMY,packet);
							pacPE.dwSize = sizeof(PacketPosEnemy);
							pacPE.dwType = PACKET_TYPE_POS_ENEMY;
							pacPE.Number = i;
							pacPE.x = g_en[i]->getX();
							pacPE.y = g_en[i]->getY();
							pacPE.z = g_en[i]->getZ();
							packet = (VOID*)&pacPE;
							hReturn = hrSendPeerMessage(-1,PACKET_TYPE_POS_ENEMY,packet);
						}							
					}
				}
			}
		}

		case DPN_MSGID_CONNECT_COMPLETE:
		{
			PDPNMSG_CONNECT_COMPLETE pConnectCompleteMsg;
			pConnectCompleteMsg = (PDPNMSG_CONNECT_COMPLETE)pMsgBuffer;
			
			g_hrConnectComplete = pConnectCompleteMsg->hResultCode;
			SetEvent( g_hConnectCompleteEvent );
			break;
		}
	}
	
	return hReturn;

}

//-----------------------------------------------------------------------------
// Name: hrCreatePlayer()
// Desc: Function to create a player who joins the session
//-----------------------------------------------------------------------------
HRESULT	GameGraphic::hrCreatePlayer( PVOID pvUserContext, PVOID pMsgBuffer )
{
    HRESULT					hReturn = S_OK;
    PDPNMSG_CREATE_PLAYER	pCreatePlayerMsg;
	char					strName[256];
	DWORD					dwSize = 0;
	DPN_PLAYER_INFO			*pdpPlayerInfo = NULL;
	int						i;
	void					*packet;
		PacketChat				ChatMsg;
		
	// Get a Create Message pointer to the buffer
	pCreatePlayerMsg = (PDPNMSG_CREATE_PLAYER)pMsgBuffer;
    // Get the peer info and extract its name
    hReturn = g_pDP->GetPeerInfo( pCreatePlayerMsg->dpnidPlayer, pdpPlayerInfo, &dwSize, 0 );
    if( FAILED(hReturn) && hReturn != DPNERR_BUFFERTOOSMALL ) {
		exit(0);
        hReturn = -1;
	}
	else {
		// Allocate memory for the player info
		pdpPlayerInfo = (DPN_PLAYER_INFO*) new BYTE[ dwSize ];
		
		ZeroMemory( pdpPlayerInfo, dwSize );
		pdpPlayerInfo->dwSize = sizeof(DPN_PLAYER_INFO);
		// Load the player info into the newly allocated data
		hReturn = g_pDP->GetPeerInfo( pCreatePlayerMsg->dpnidPlayer, pdpPlayerInfo, &dwSize, 0 );
		if( FAILED(hReturn) ) {
			exit(0);
			hReturn = -1;
		}
		else {
			EnterCriticalSection( &g_csModifyPlayer );
			
			// Convert player name to ANSI
			DXUtil_ConvertWideStringToGeneric( strName, pdpPlayerInfo->pwszName );
			// Check if we are adding ourselves
			if( pdpPlayerInfo->dwPlayerFlags & DPNPLAYER_LOCAL ) {
				g_dpnidLocalPlayer = pCreatePlayerMsg->dpnidPlayer;
				g_iMyPlayerId = iAddPlayer(g_dpnidLocalPlayer,D3DXVECTOR3(0.0f,0.0f,0.0f),0.0f,strName);
				g_char[g_iMyPlayerId] = new cCharacter();
				g_char[g_iMyPlayerId]->setPos(0,0,0);
				g_char[g_iMyPlayerId]->setModel(g_SetModel.getModel(0));
				g_char[g_iMyPlayerId]->setBound(1);
				g_char[g_iMyPlayerId]->settype(0);
				
				g_weapon[g_iMyPlayerId] = new cCharacter();
				g_weapon[g_iMyPlayerId]->setPos(0,0,0);
				g_weapon[g_iMyPlayerId]->setModel(g_SetModel.getModel(1));
				g_weapon[g_iMyPlayerId]->setBound(1);
				g_weapon[g_iMyPlayerId]->settype(1);
				setTex(g_char[g_iMyPlayerId]->gettype());
				g_char[g_iMyPlayerId]->setTex(TexName);
				g_weapon[g_iMyPlayerId]->setTex(TexWea);					
			}
			else {
				// Add the player to our game				
				i = iAddPlayer(pCreatePlayerMsg->dpnidPlayer,D3DXVECTOR3(0.0f,0.0f,0.0f),0.0f,strName);
				g_char[i] = new cCharacter();
				g_char[i]->setPos(0,0,0);
				g_char[i]->setModel(g_SetModel.getModel(0));
				g_char[i]->setBound(1);
				g_char[i]->settype(0);

				g_weapon[i] = new cCharacter();
				g_weapon[i]->setPos(0,0,0);
				g_weapon[i]->setModel(g_SetModel.getModel(1));
				g_weapon[i]->setBound(1);
				g_weapon[i]->settype(1);
				setTex(g_char[i]->gettype());
				g_char[i]->setTex(TexName);
				g_weapon[i]->setTex(TexWea);					
			    void  *packet;
				PacketRequestChar pacRC; 
				pacRC.dwSize = sizeof(PacketRequestChar);
				pacRC.dwType = PACKET_TYPE_REQUEST_CHAR;
				pacRC.idNumber = pCreatePlayerMsg->dpnidPlayer;
				packet = (VOID*)&pacRC;
				
				HRESULT hReturn =hrSendPeerMessage(-1,PACKET_TYPE_REQUEST_CHAR,packet);		
				if(FAILED(hReturn))exit(0);
		
				// Send them a welcoming message if we are the host
				if( bHost ) {
					sprintf(szOutput,"Welcome to the game, %s!",strName);
					ChatMsg.dwSize = sizeof(PacketChat);
					ChatMsg.dwType = PACKET_TYPE_CHAT;
					strcpy(ChatMsg.szText,szOutput);
					// Convert the packet to a void stream
					packet = (VOID*)&ChatMsg;

					// Send the chat packet
					hReturn = hrSendPeerMessage(i,PACKET_TYPE_CHAT,packet);
				}
				sprintf(szChat,"%s Has Joined.", strName);
			}

			SAFE_DELETE_ARRAY( pdpPlayerInfo );
			
			// Update the number of active players in a thread safe way
			InterlockedIncrement( &g_lNumberOfActivePlayers );

			LeaveCriticalSection( &g_csModifyPlayer );
		}
	}
		
	return hReturn;
	return S_OK;
}
void GameGraphic::setTex(int ain)
{
	switch(	ain) 
	{
		case 0:	TexName="model\\crafy_texture.bmp";
				NameFace="Picture\\CrafyFace.bmp";
				TexWea="model\\crafy_weapon.bmp";break;
		case 2:	TexName="model\\marvin_texture.bmp";
				NameFace="Picture\\MarvinFace.bmp";		
				TexWea="model\\marvin_weapon.bmp";break;
		case 4:	TexName="model\\spiff_texture.bmp";
				NameFace="Picture\\SpiffFace.bmp";
				TexWea="model\\spiff_weapon.bmp";break;
		case 6:	TexName="model\\invade_texture.bmp";
				NameFace="Picture\\InvadeFace.bmp";
				TexWea="model\\invade_weapon.bmp";break;
		case 8:	TexName="model\\a.bmp";
				NameFace="Picture\\CrafyFace.bmp";
				TexWea="model\\a_weapon.bmp";break;
		default:
		{
			TexName="model\\invade_texture.bmp";
			TexWea="model\\invade_weapon.bmp";
			NameFace="Picture\\CrafyFace.bmp";
		}
	}
}
				
//-----------------------------------------------------------------------------
// Name: hrDestroyPlayer()
// Desc: Function to destroy a player who leaves the session
//-----------------------------------------------------------------------------
HRESULT	GameGraphic::hrDestroyPlayer( PVOID pvUserContext, PVOID pMsgBuffer )
{
	PDPNMSG_DESTROY_PLAYER	pDestroyPlayerMsg;
	HRESULT					hReturn = S_OK;
	int						i;
	char					szOutput[256];
		
	// Get a Destroy Message pointer to the buffer
	pDestroyPlayerMsg = (PDPNMSG_DESTROY_PLAYER)pMsgBuffer;
	
	// Update the number of active players in a thread safe way
	InterlockedDecrement( &g_lNumberOfActivePlayers );

	EnterCriticalSection( &g_csModifyPlayer );

	// Remove Player from list
	for( i = 0 ; i < MAX_PLAYERS ; i++ ) {
		if( i_char[i].bActive ) {
			if( i_char[i].dpnidPlayer == pDestroyPlayerMsg->dpnidPlayer ) {
				i_char[i].bActive = 0;
				sprintf(szOutput,"<%s> Left The Game",i_char[i].szPlayerName);
				sprintf(szChat,szOutput);
				break;
			}
		}
	}
	
	LeaveCriticalSection( &g_csModifyPlayer );
	
	return(hReturn);
	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: hrJoinGame()

// Desc: Function to join the game
//-----------------------------------------------------------------------------
HRESULT GameGraphic::hrJoinGame()
{
	HRESULT					hReturn = S_OK;
	WCHAR					wszHostName[256];
	WCHAR					wszPeerName[256];
	char					szPeerName[256];
	char					szIP[256];
	DWORD					dwPort;
	DWORD					dwLength = 256;
	DPN_APPLICATION_DESC	dpnAppDesc;
	DPN_PLAYER_INFO			dpPlayerInfo;

	// Read some settings from the config file
	FILE *fp = fopen("config.txt","r");
	fgets(szIP,16,fp);
	szIP[strlen(szIP)-1] = '\0';
//	fgets(szPeerName,32,fp);
//	szPeerName[strlen(szPeerName)-1] = '\0';
	fclose(fp);
//	strcpy(szIP,IPHost.data());
	strcpy(szPeerName,Name.data());
	szPeerName[strlen(szPeerName)-1] = '\0';

	bHost=false;
	// Set the peer info
	DXUtil_ConvertGenericStringToWide( wszPeerName, szPeerName );
	
	ZeroMemory( &dpPlayerInfo, sizeof(DPN_PLAYER_INFO) );
	dpPlayerInfo.dwSize = sizeof(DPN_PLAYER_INFO);
	dpPlayerInfo.dwInfoFlags = DPNINFO_NAME;
	dpPlayerInfo.pwszName = wszPeerName;
	
	// Make this a synchronous call
	if( FAILED( hReturn = g_pDP->SetPeerInfo( &dpPlayerInfo, NULL, NULL, DPNSETPEERINFO_SYNC ) ) ) {
		exit(0);
		return -1;
	
	}
		
	// Prepare the application description
	ZeroMemory( &dpnAppDesc, sizeof( DPN_APPLICATION_DESC ) );
	dpnAppDesc.dwSize = sizeof( DPN_APPLICATION_DESC );
	dpnAppDesc.guidApplication = DP_SPACEPIRATES;

	// Set the IP
	DXUtil_ConvertGenericStringToWide( wszHostName, szIP );
	// Set the port number
	dwPort = 6000;

	// Add host name to address
	hReturn = g_pHostAddress->AddComponent(DPNA_KEY_HOSTNAME,wszHostName,(wcslen(wszHostName)+1)*sizeof(WCHAR),DPNA_DATATYPE_STRING);
	if( hReturn != S_OK ) {
		assert(false);
		exit(0);
		//MessageBox( hWnd, "Failed to AddComponent()", "hrJoinGame()", MB_ICONERROR );
		return -1;

	}
	// Add port number to address
	hReturn = g_pHostAddress->AddComponent(DPNA_KEY_PORT,&dwPort,sizeof(DWORD),DPNA_DATATYPE_DWORD);
	if( hReturn != S_OK ) {
exit(0);
		//MessageBox( hWnd, "Failed to AddComponent()", "hrJoinGame()", MB_ICONERROR );
		assert(false);
		return -1;
	}

	// Connect to the session
	hReturn = g_pDP->Connect(	&dpnAppDesc,
								g_pHostAddress,    
								g_pDeviceAddress,
								NULL,
								NULL,
								NULL,	
								0,
								NULL,
								NULL, 
								&g_hConnectAsyncOp,
								NULL); // flags
	
	if( hReturn != E_PENDING && FAILED(hReturn) ) {
		exit(0);
		return -1;
	}
	SetTimer( cWindow::GetMainWindow()->GetHWnd(), TIMERID_CONNECT_COMPLETE, 100, NULL );

	return(hReturn);
	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: hrHostGame()
// Desc: Function to host the game
//-----------------------------------------------------------------------------
HRESULT	GameGraphic::hrHostGame()
{
	HRESULT					hReturn;
	char					szPeerName[256];
	char					szSessionName[256];
	WCHAR					wszPeerName[256];
	WCHAR					wszSessionName[256];
	DPN_APPLICATION_DESC	dnAppDesc;
	char					szIP[256];
	DWORD					dwLength = 256;
	DPN_PLAYER_INFO			dpPlayerInfo;
	DWORD					dwPort = 9000;
	
	// Read some settings from the config file
	FILE *fp = fopen("config.txt","r");
	fgets(szIP,16,fp);
	szIP[strlen(szIP)-1] = '\0';
//	fgets(szPeerName,32,fp);
//	szPeerName[strlen(szPeerName)-1] = '\0';
	fclose(fp);

//	strcpy(szIP,IPHost.data());
	strcpy(szPeerName,Name.data());
		szPeerName[strlen(szPeerName)-1] = '\0';

	//
	// Setup our player information
	//
	DXUtil_ConvertGenericStringToWide( wszPeerName, szPeerName );
	ZeroMemory( &dpPlayerInfo, sizeof(DPN_PLAYER_INFO) );
	dpPlayerInfo.dwSize = sizeof(DPN_PLAYER_INFO);
	dpPlayerInfo.dwInfoFlags = DPNINFO_NAME;
	dpPlayerInfo.pwszName = wszPeerName;
	
	// Set us up to be non-asynchronous
	if( FAILED( hReturn = g_pDP->SetPeerInfo( &dpPlayerInfo, NULL, NULL, DPNSETPEERINFO_SYNC ) ) ) {
		assert(false);//MessageBox( hWindow, "Failed to SetPeerInfo()", "DirectPlay Error", MB_ICONERROR );
		return -1;
	}
	
	// Setup the application description
	sprintf(szSessionName,"%s's Game",szPeerName);
	DXUtil_ConvertGenericStringToWide( wszSessionName, szSessionName );
	
	ZeroMemory( &dnAppDesc, sizeof(DPN_APPLICATION_DESC) );
	dnAppDesc.dwSize			= sizeof(DPN_APPLICATION_DESC);
	dnAppDesc.guidApplication	= DP_SPACEPIRATES;
	dnAppDesc.pwszSessionName	= wszSessionName;
	dnAppDesc.dwMaxPlayers		= MAX_PLAYERS;
	dnAppDesc.dwFlags			= DPNSESSION_MIGRATE_HOST;
	
	// Set the port number
	dwPort = 6000;
	
	// Add port number to address
	hReturn = g_pDeviceAddress->AddComponent(DPNA_KEY_PORT,&dwPort,sizeof(DWORD),DPNA_DATATYPE_DWORD);
	if( hReturn != S_OK ) {
		assert(false);//MessageBox( hWindow, "Failed to AddComponent()", "hrHostGame()", MB_ICONERROR );
		return -1;
	}
	
	// Host the game
	hReturn = g_pDP->Host(	&dnAppDesc,               
		&g_pDeviceAddress,        
		1,                        
		NULL, 
		NULL,               
		NULL,                     
		NULL );
	if( FAILED( hReturn ) ) {
		if( hReturn == DPNERR_INVALIDPARAM ) 
			assert(false);//MessageBox( hWindow, "Failed to Host()", "Invalid Param", MB_ICONERROR );
		else if( hReturn == DPNERR_INVALIDDEVICEADDRESS  ) 
			assert(false);
			//MessageBox( hWindow, "Failed to Host()", "Invalid Device Address", MB_ICONERROR );
		else
		assert (false);
			//MessageBox( hWindow, "Failed to Host()", "DirectPlay Error", MB_ICONERROR );
		return -1;
	}
	
	// Let us know we are the host
	bHost = 1;

	sprintf(szChat,"Hosting");

	return hReturn;
	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: hrSendPeerMessage()
// Desc: Used to send messages to other players via Direct Play
//-----------------------------------------------------------------------------
HRESULT	GameGraphic::hrSendPeerMessage( int player, DWORD dwMessageType, PVOID pMsgBuffer )
{
	DPNHANDLE		hAsync;
    DWORD			dwLength;
	DPN_BUFFER_DESC bufferDesc;
	PacketGeneric	*PGen;
	HRESULT hr;
	// Cast to a generic packet to get the size
	PGen = (PacketGeneric*)pMsgBuffer;
	dwLength = PGen->dwSize;

	// Return if an empty packet
	if( dwLength == 0 ) 
	{
		exit(0);
		return(0);
	}

	bufferDesc.dwBufferSize = dwLength;
	bufferDesc.pBufferData  = (BYTE*)pMsgBuffer;

	// Broadcast message
	if( player == -1 )
		hr=g_pDP->SendTo( DPNID_ALL_PLAYERS_GROUP, &bufferDesc, 1, 0, NULL, &hAsync, DPNSEND_NOLOOPBACK );
	// Send to a particular player
	else
		hr=g_pDP->SendTo( i_char[player].dpnidPlayer, &bufferDesc, 1,0, NULL, &hAsync, 0 );

	return hr;

}
//-----------------------------------------------------------------------------
// Name: iGetPlayerID()
// Desc: Returns the player slot that matches the passed ID
//-----------------------------------------------------------------------------

int GameGraphic::iGetPlayerID(DPNID dpid)
{
	int i;

	// Remove Player from list
	for( i = 0 ; i < MAX_PLAYERS ; i++ ) {
		if(i_char[i].bActive ) {
			if( i_char[i].dpnidPlayer == dpid ) {
				return(i);
			}
		}
	}
	exit(0);
	return(0);
}

//-----------------------------------------------------------------------------
// Name: vNetwork()
// Desc: Synchronizes Networked Players
//-----------------------------------------------------------------------------
void GameGraphic::vUpdateNetwork(void)
{
	void			*packet;
	PacketAngle		pacAngle;
	PacketAction	pacAction;
	PacketVelocity	pacVel;
	PacketPosition	pacPos;
	PacketScore		pacScore;
	PacketActionEnemy pacAE;
	PacketPosEnemy pacPE;
	PacketAngleEnemy pacAnE;
	HRESULT			hReturn;
	if( timeGetTime() > dwUpdateTime+100 ) 
	{
		
		// Only send packets if other players are in the game
	//	if( g_lNumberOfActivePlayers > 1 ) 
		{
			// Send our angle
			pacAngle.dwSize = sizeof(PacketAngle);
			pacAngle.dwType = PACKET_TYPE_ANGLE;
			pacAngle.fAngle = g_char[g_iMyPlayerId]->getDirection();
			packet = (VOID*)&pacAngle;
			hReturn = hrSendPeerMessage(-1,PACKET_TYPE_ANGLE,packet);		
			if(FAILED(hReturn))exit(0);
			pacAction.dwSize = sizeof(PacketAction);
			pacAction.dwType = PACKET_TYPE_ACTION;
			pacAction.Action = g_char[g_iMyPlayerId]->getState();
			packet = (VOID*)&pacAction;
			hReturn = hrSendPeerMessage(-1,PACKET_TYPE_ACTION,packet);		
			if(FAILED(hReturn))exit(0);
		
			// Send our velocity
		/*	pacVel.dwSize = sizeof(PacketVelocity);
			pacVel.dwType = PACKET_TYPE_VELOCITY;
			pacVel.fVelocity = (float)i_char[g_iMyPlayerId].fVelocity;
			packet = (VOID*)&pacVel;
			hReturn = hrSendPeerMessage(-1,PACKET_TYPE_VELOCITY,packet);*/
			// Send our position
			pacPos.dwSize = sizeof(PacketPosition);
			pacPos.dwType = PACKET_TYPE_POSITION;
			pacPos.fx = i_char[g_iMyPlayerId].vecCurPos.x;
			pacPos.fy = i_char[g_iMyPlayerId].vecCurPos.y;
			pacPos.fz = i_char[g_iMyPlayerId].vecCurPos.z;
			packet = (VOID*)&pacPos;
			hReturn = hrSendPeerMessage(-1,PACKET_TYPE_POSITION,packet);
			if(FAILED(hReturn))exit(0);
			// Send our Score
			/*pacScore.dwSize = sizeof(PacketScore);
			pacScore.dwType = PACKET_TYPE_SCORE;
			pacScore.lScore = i_char[g_iMyPlayerId].lScore;
			packet = (VOID*)&pacScore;
			hReturn = hrSendPeerMessage(-1,PACKET_TYPE_SCORE,packet);*/
			if(bHost)
			{
				for(int i=0;i<5;i++)
				{
					if(CanEnemy[i])
					{
						pacPE.dwSize = sizeof(PacketPosEnemy);
						pacPE.dwType = PACKET_TYPE_POS_ENEMY;
						pacPE.Number = i;
						pacPE.x = g_en[i]->getX();
						pacPE.y = g_en[i]->getY();
						pacPE.z = g_en[i]->getZ();
						packet = (VOID*)&pacPE;
						hReturn = hrSendPeerMessage(-1,PACKET_TYPE_POS_ENEMY,packet);
					}
				}
				for( i=0;i<5;i++)
				{
					if(CanEnemy[i])
					{
						pacAnE.dwSize = sizeof(PacketAngleEnemy);
						pacAnE.dwType = PACKET_TYPE_ANGLE_ENEMY;
						pacAnE.Number = i;
						pacAnE.fAngle = g_en[i]->getDirection();
						packet = (VOID*)&pacAnE;
						hReturn = hrSendPeerMessage(-1,PACKET_TYPE_ANGLE_ENEMY,packet);
					}
				}
				for(i=0;i<5;i++)
				{
					if(CanEnemy[i])
					{
						
						pacAE.dwSize = sizeof(PacketActionEnemy);
						pacAE.dwType = PACKET_TYPE_ACTION_ENEMY;
						pacAE.Number = i;
						pacAE.Action = g_en[i]->getstate();
						packet = (VOID*)&pacAE;
						hReturn = hrSendPeerMessage(-1,PACKET_TYPE_ACTION_ENEMY,packet);
					}							
				}
			}
		}
		dwUpdateTime = timeGetTime();
	}
}
int GameGraphic::iAddPlayer(DPNID dpid, D3DXVECTOR3 pos, float fRot, char *szName)
{
	int i;

	for( i = 0 ; i < MAX_PLAYERS ; i++ ) {
		if( !i_char[i].bActive ) {
			break;
		}
	}	
	// No free slots
	if( i == MAX_PLAYERS )
	{
		exit(0);
		return(-1); 
	}
	i_char[i].bActive = true;
	i_char[i].dpnidPlayer = dpid;
	i_char[i].vecCurPos = pos;
	i_char[i].vecLastPos = pos;
	i_char[i].iFrame = 0;
	i_char[i].fRot = fRot;
	i_char[i].fVelocity = 0.0f;
	strcpy(i_char[i].szPlayerName,szName);
	return(i);
}


