/**************************************************************************
 *      Copyright (C) Dipl.-Ing. Erwin Authried 2000                      *
 *                    Softwareentwicklung und Systemdesign                *
 *      All Rights Reserved.                                              *
 **************************************************************************/
/*!  \file armtool.c
  \brief Simple JTAG monitor for ARM7TDMI
  \author Erwin Authried
  \version $Id: armtool.c,v 1.3 2000/11/16 20:43:40 eauth Exp $

  The program uses the JTAG i/o routines written by R.Longo
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>  // for stat() func

void GetInformation(void)
{
  unsigned int IDCode = ReadIDCode();
 
  printf("IDCODE: %08X\n", IDCode);
  
  // AT91M40400 IDCODE = 0x1F0F0F0F
  if (IDCode == 0x1F0F0F0F) {	
	printf("OK: Found ATMEL AT91EB01 Board\n");
  }
  else {
	printf("ERROR: Not Found ATMEL AT91EB01 Board\n");
  }
}

int main(int argc,char **argv)
{
  u_int32_t adr,words,value,total;
  u_int32_t buf[16];
  FILE *f;
  int mode,n,st,percent;
  struct stat status;
  __off_t fsize;   // File Size in Byte
  

  if (argc<2) {
        fprintf(stderr, "Usage: %s r{ead} adr words {filename} ... read from target\n"
                        "       %s w{rite} adr value           ... write a single word to target\n"
                        "       %s w{rite} adr 0 filename      ... write file contents to target \n"
                        "       %s x{ecute} adr                ... execute program at 'adr'\n"
			"       %s i{nformation}               ... get the JTAG information\n",
                argv[0],argv[0],argv[0],argv[0],argv[0]);
        exit(1);
  }

  if (argc>2) {
  	n=sscanf(argv[2],"%lu",&adr);
  	if (n && adr==0 && argv[2][1]=='x') n=0;
  	if (!n) n=sscanf(argv[2],"%lxu",&adr);
  	if (n!=1) {fprintf(stderr,"argument error: adr\n");exit(1);}
  }
  
  words=0;
  
  if (argc>3){
        n=sscanf(argv[3],"%lu",&words);   
	if (words==0)  n=0;
	if (!n) n=sscanf(argv[3],"%lxu",&words);
  	if (n!=1) {fprintf(stderr,"argument error: words\n");exit(1);}
  }

  if (initialize_jtag_hardware() < 0) {
	perror("initialize_jtag_hardware");
  }


  ResetTapC();
  PutBreakPoint(0x20000000);           /* Put 'any address' brekpt.-> stop NOW! */
  ClearAnyBreakPoint();                /* Avoid entering debug state after exiting */
  ReadCpuRegs(0);                      /* Read CPU registers & store away */

  switch(argv[1][0]){
  	case 'w':
        case 'W':
        	if (argc==5 && words==0){
                	f=fopen(argv[4],"r");
                	if (f==NULL) {fprintf(stderr,"can't open file\n");exit(1);}
                	
			st=stat(argv[4],&status); 
			if (st!=0) {fprintf(stderr,"can't read file status\n");exit(1);}
			
			
			fsize = status.st_size;
			
			if (fsize % 4 == 0) {
				total = (int)fsize / 4; 
			}
			else {
				total = 1 + (int)fsize / 4; 
			}
			
			words = total;
			percent = 0;
			
			while(words){				
				n=words; if (n>14) n=14;
                        	n=fread(buf,4,n,f);
                        	if (n==0) {fclose(f); exit(0);}
                        	WriteMemoryBuf(adr,n,buf);
                        	adr+=4*n; words-=n;
				
				percent = ((total-words)*100)/total;	
				printf("     Writing : %lu %\r",percent);		
                	}
			fclose(f);
			printf("     Writing : Complete!\n");
			printf("     Total Writing : %lu word(s) | %lu byte(s)\n",
				total-words,4*total-words);
        	}
		else if(argc==4) {
                	WriteMemoryBuf(adr,1,&words);
        	}
		else {
			fprintf(stderr,"agrument error\n");exit(1);
		}
        	break;

        case 'r':
        case 'R':
                f=NULL;
                if (argc==5){
                        f=fopen(argv[4],"w");
                        if (f==NULL) {fprintf(stderr,"can't create file");exit(1);}
                }

                ReadMemory(adr,words,f);
                if (f!=NULL) fclose(f);
                break;

        case 'x':
        case 'X':
                RunProgram(adr);
                break;
        case 'i':
	case 'I':
		GetInformation();
		break;
  } /* switch */
}

