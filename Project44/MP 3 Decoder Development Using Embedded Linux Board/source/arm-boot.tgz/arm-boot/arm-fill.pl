#!/usr/bin/perl

if ($#ARGV < 2) {
	die "Usage: arm-fill.pl <addr> <words> <value>\n" ;
}

$total_writing = hex($ARGV[1]);
print "Total Writing : $total_writing word(s) | ";
print $total_writing*4, " byte(s)\n";

$addr = hex($ARGV[0]);

$percent = -1;
for ($i=0; $i<$total_writing; $i++) {
	$_percent = int($i/($total_writing-1)*100);
        if ($percent < $_percent) {
        	$percent = $_percent;
                print "$percent %  \r";
        }
	system "./armtool w $addr $ARGV[2]";
        $addr += 4;
}
print "\n";
