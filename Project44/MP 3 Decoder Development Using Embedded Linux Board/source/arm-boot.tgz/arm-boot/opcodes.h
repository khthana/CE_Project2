// ARM THUMB opcodes
#define THUMB_MOV_R0_PC 0x46784678

// ARM opcodes
#define ARM_NOP         0xe1a00000
#define ARM_LD_R0_PC    0xe59f0000
#define ARM_LD_R1_PC    0xe59f1000
// Rd -> [Rn], half-word
#define ARM_STRH(Rn,Rd) (0xe1c000b0|((u_int32_t)Rn<<16)|((u_int32_t)Rd<<12))
#define ARM_LDRH(Rn,Rd) (0xe1d000b0|((u_int32_t)Rn<<16)|((u_int32_t)Rd<<12))

	/* LDM,STM */
#define ARM_STMDA(Rn,Rl) (0xe8000000 | ((u_int32_t)Rn<<16)|Rl)	/* post-decr. store */
#define ARM_STMIA(Rn,Rl) (0xe8800000 | ((u_int32_t)Rn<<16)|Rl)  /* post-incr. store */
#define ARM_LDMIA(Rn,Rl) (0xe8900000 | ((u_int32_t)Rn<<16)|Rl)  /* post-incr. load */

#define ARM_LD_C(R,C) (0xe3a00000 | ((u_int32_t)R<<12)|C)
#define ARM_MOV(Rd,Rs) (0xe1a00000|((u_int32_t)Rd<<12)|(u_int32_t)Rs)

