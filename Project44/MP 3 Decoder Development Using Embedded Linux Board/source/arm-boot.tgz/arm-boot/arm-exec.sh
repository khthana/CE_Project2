#!/bin/sh

echo 'Objcopy linux.'
arm-uclinux-objcopy -Obinary ../linux/linux linux.bin

echo 'Loading linux.bin...'
./armtool write 0x02000000 0x100000 linux.bin

echo 'Setupping parameters, at 0x200...'
echo '-- clear internal RAM.'
./arm-fill.pl 0x200 0x200 0		# clear internal RAM
echo '-- page size = 4kB'
./armtool write 0x200 0x1000		# page size = 4kB
echo '-- number of pages = 6k'
./armtool write 0x204 0x1800		# number of pages = 6k
echo '-- cmdline: root=/dev/rom0 rom=0x02180000 init=/bin/sh0\0\0\0'
echo -e 'root=/dev/rom0 rom=0x02180000 init=/bin/sh\0\0\0\0' >cmdline
./armtool write 0x700 64 cmdline

echo 'Loading romfs...'
genromfs -d ../romfs -f romfs.img
./armtool write 0x2180000 0x80000 romfs.img

echo 'Execute linux...'
./armtool x 0x02000000

echo 'Done.'
