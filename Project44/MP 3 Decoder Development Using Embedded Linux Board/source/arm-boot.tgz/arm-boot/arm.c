/**************************************************************************
 *      Copyright (C) Dipl.-Ing. Erwin Authried 2000                      *
 *                    Softwareentwicklung und Systemdesign                *
 *      All Rights Reserved.                                              *
 **************************************************************************/
/*!  \file armtool.cc
  \brief Simple JTAG monitor for ARM7TDMI
  \author Erwin Authried
  \version $Id: arm.c,v 1.3 2000/10/31 00:02:38 eauth Exp $

  The program uses the JTAG i/o routines written by R.Longo
*/
 
/***----------------------------------------------------------***/
/***  Parallel port <-> ARM7TDMI JTAG direct i/o test program ***/
/***  (c) R.Longo, 2000                                       ***/
/***----------------------------------------------------------***/

/* WARNING: program under heavy development - inconsistencies ahead !!! */

/*                     DESCRIPTION:                                   */
/* This program allows to use the JTAG port on a AT91M40400 CPU       */
/* to read & write registers & RAM, stop the CPU & put breakpoints    */
/* The JTAG port is accessed from the PC's parallel port with a       */
/* simple hardware interface. Works only on Linux, but could be made  */
/* to work under any OS that allows direct hardware access.           */
/* It has been developed & tested on a AT91EB01 eval board.           */

/* ****   WARNING: VERY sub-pre-before ALPHA version !!! ****         */
/* This program CAN damage your board (i.e.,overwrite the FLASH)      */
/* (Check the board documentation about jumpers for FLASH protection) */
/*      ***********    USE AT YOUR OWN RISK    ***********            */

/* Legalese: #include standard disclaimers here. Copyright owners are */
/* the owners of their respective copyrights.                         */
/* This program and related hardware are released under the GNU GPL   */


/*  DONE:
      - Parallel port interface design
      - Low level parallel port access
      - Read IDCODE (= 0x1F0F0F0F on AT91M40400)
      - Read & write ICEBreaker registers
      - Enter debug state thru direct user request
      - Enter debug state thru breakpoint/watchpoint
      - READ CPU REGISTERS after entering debug state
      - Leave debug state & run again
      - Adjust PC & return address depending on how debug was entered
      - System speed access to access memory map. NOTE: does not work
        as documented, uses a workaround.
        Read speed: 2 Kbytes/sec. Could be better, about 3.5 Kbytes/sec
        by using more registers on LDM/STM
      
    TO DO:
      - Simple command line interface
      - Read complete CPU state (ALL registers, ALL modes)
      - Recover original CPU state before leaving debug
      - Modify registers under user control before leaving debug
      - Modify memory (bytes/words)
      - use /dev/parport instead of direct port access
      - (.._LOTS_ more things...)

    Luxury items:
      - Online disassembler (use disarm.c)
      - Memory dump
      - Memory editor
      - Software breakpoints
      - Direct flash memory programming

    Under serious evaluation:
      - GDB interface (CygMon ? GDB stub? GDB remote?)

*/ 


/* Compile with:   gcc -o tp tp.c  */



/** THIS PROGRAM ONLY WORKS FOR ROOT USER !!! ***/
/* To understand how parallel port access works under Linux, check
   the IO-PORT-PROGRAMMING mini-HOWTO
   On newer kernels, /dev/parport can be used. This has the advantage
   that any user can access the port.
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include "opcodes.h"

void EnterSC1Bits(unsigned int *newdata, unsigned int *olddata);

/* INTERNAL CPU REGISTERS & ASSOCIATED VARIABLES */
u_int32_t CPU_regs[16];              /* 16 CPU regs image (R0..R15) */
u_int32_t CPU_CPSR;                  /* CPSR image */
int was_in_thumb=0;                     /* THUMB mode flag             */
int total_ins_exec=0;                   /* total # of instr. executed  */
int is_watchpoint=0;                    /* Breakpoint=0, watchpoint=1  */
int is_debugrequest=0;                  /* User requested debug (not brkp.)*/

/***-------------------------------------***/
/***  Reset the JTAG TAP controller      ***/
/***-------------------------------------***/
/* NOTE: after reset, Run-Test/Idle state will be entered */

void ResetTapC(void)
{
  jtag_io(1,0,0);	// 5 cycles with TMS=1
  jtag_io(1,0,0);
  jtag_io(1,0,0);
  jtag_io(1,0,0);
  jtag_io(1,0,0);
  jtag_io(0,0,0);	// TMS=0 to enter run-test/idle
}

/***-------------------------------------***/
/***  Step to next state in TAP machine  ***/
/***-------------------------------------***/

/* Advances to next TAP state depending on TMS value */

void StepNextTAPState(int newtms)
{
  jtag_io(newtms,0,0);
}

/***  Enter a new instr. in TAP machine  ***/
/***-------------------------------------***/

/* Assumes TAP is on Run-Test/Idle or Update-DR/Update-IR states at entry */
/* On exit, stays at Update-IR  */

int EnterIRInst(int nbits, unsigned int newinst)
{
int tms=0;
  StepNextTAPState(1);             /* goto Select-DR-Scan               */
  StepNextTAPState(1);             /* goto Select-IR-Scan               */
  StepNextTAPState(0);             /* goto Capture-IR                   */
  StepNextTAPState(0);             /* goto Shift-IR                     */

  while(nbits)
   { /* If last bit, put TMS=1 to exit Shift-IR state */
     if (nbits == 1) tms=1;
     jtag_io(tms,newinst&1,0);
     newinst >>= 1;
     nbits--;
   }

  StepNextTAPState(1);             /* goto Update-IR                    */

  return 0;
}

void SC1(int b, u_int32_t instruction, u_int32_t *outdata)
{
u_int32_t indata[2];

 indata[0] = instruction;
 indata[1] = b;                        /* bit 32 = BREAKPT (0) */
 EnterSC1Bits(indata, outdata);        /* Send opcode & read out data */
 StepNextTAPState(0);                  /* Run-Test/idle => exec instr. */
}

void RunTest_Idle()
{
  StepNextTAPState(0);
}

/***-----------------------------------------***/
/***  Enter a bit stream in the selected DR  ***/
/***-----------------------------------------***/

/* Assumes TAP is on Run-Test/Idle or Update-DR/Update-IR states at entry */
/* On exit, stays at Update-DR/Update-IR  */
/* newdata is an array of 32-bit words with the bit stream to send,
   LSB first. The total number of bits to send is nbits. */
/* The readout bit stream is stored in olddata[] */
/* If newdata is NULL, zeros are sent in the data stream */
/* If olddata is NULL, readout bits are thrown away */
/* enter_DR & exit_DR are flags intended to allow chaining several
   calls to this routine without leaving DR. This simplifies building
   the data stream. */

int EnterDRBits(int nbits, unsigned int *newdata, unsigned int *olddata,
                int enter_DR, int exit_DR)
{ int bits_sent=0;
  u_int32_t databits=0;
  u_int32_t readmask=1;
  int oldbit;
  unsigned int readbits=0;
  int tms=0;

  if (enter_DR)
    { StepNextTAPState(1);             /* goto Select-DR-Scan               */
      StepNextTAPState(0);             /* goto Capture-DR                   */
      StepNextTAPState(0);             /* goto Shift-DR                     */
    }

  while(nbits)
   { /* If last bit, put TMS=1 to exit Shift-DR state */
     if ((nbits == 1) && (exit_DR))
        tms=1;

     if ((bits_sent & 0x0000001f)==0)     /* Every 32 bits sent...      */
       { if (newdata != NULL)             /* Only if newdata is <> NULL */
           databits = *newdata++;         /* ...get a new word          */
         readmask = 1;
         readbits = 0;
       }
     oldbit = jtag_io(tms,databits&1,olddata!=NULL);

     if (oldbit)                                   /* Compose readout data */
       readbits |= readmask;
     databits >>= 1;
     readmask <<= 1;
     if (olddata != NULL)
       { *olddata = readbits;          /* Save every new bit */
         if (readmask == 0)            /* After reading 32 bits, move ptr */
           olddata++;
       }
     nbits--;
     bits_sent++;
   }

  if (exit_DR)
    StepNextTAPState(1);             /* goto Update-DR                    */

  return bits_sent;
}

/***----------------------------------------------------***/
/***  Enter an instruction+BREAKPT bit in Scan chain 1  ***/
/***----------------------------------------------------***/

/* Similar to EnterDRBits(), but scans in always 33 bits:
   newdata[0] = 32 bits with instruction
   newdata[1] = 1 bit (0/1) with BREAKPT bit in LSB
   NOTE: Scan chain 1 bit order is (from DIN to DOUT):
         D0..D31, BREAKPT
   So, using EnterDRBits() will not work without reversing the
   instruction bits. Better make a new function like this one...

   RETURNS previous BREAKPT value (useful to know the reason we entered DEBUG)
   Also returns 32 bits read out
*/

void EnterSC1Bits(unsigned int *newdata, unsigned int *olddata)
{
  unsigned int databits=0;
  u_int32_t readmask=0x80000000;
  int oldbit;
  unsigned int readbits=0;

  int nbits = 32;
  int oldBrkptBit;
  int tms=0;
  
  StepNextTAPState(1);             /* goto Select-DR-Scan               */
  StepNextTAPState(0);             /* goto Capture-DR                   */
  StepNextTAPState(0);             /* goto Shift-DR                     */

  /* First insert the BREAKPT bit: */
  oldBrkptBit = jtag_io(tms,newdata[1] & 1,olddata!=NULL);
  if (olddata!=NULL) olddata[1] = oldBrkptBit;

  /* Then insert 32 bits, MSB first: */
  databits = newdata[0];
  while(nbits)
   { /* If last bit, put TMS=1 to exit Shift-DR state */
     if (nbits == 1) tms=1;

     oldbit=jtag_io(tms,databits & 0x80000000,olddata!=NULL);

     if (oldbit)                                   /* Compose readout data */
       readbits |= readmask;
     databits <<= 1;
     readmask >>= 1;
     if (olddata != NULL)
       { *olddata = readbits;          /* Save every new bit */
       }
     nbits--;
   }

  StepNextTAPState(1);             /* goto Update-DR                    */
}

/***-----------------------------------------***/
/***  Read the Device Identification code    ***/
/***-----------------------------------------***/

unsigned int ReadIDCode(void)
{ u_int32_t idcode = 0;

  ResetTapC();                           /* First reset the TAP machine  */
  EnterIRInst(4, 0x0e);                  /* Enter IDCODE instr.          */
  EnterDRBits(32, NULL, &idcode, 1,1);   /* Read out 32 bits into idcode */
  return idcode;
}

/***-----------------------------------------***/
/***  Select a given Scan Chain (0, 1 or 2)  ***/
/***-----------------------------------------***/

int SelectScanChain(int sc)
{
  EnterIRInst(4, 0x02);             /* Enter SCAN_N instr.         */
  EnterDRBits(4, &sc, NULL, 1,1);   /* Send desired scan chain # (4 bits only) */
  return sc;
}

/***--------------------------------------------***/
/***  Read out one IceBreaker register contents ***/
/***--------------------------------------------***/

/* To read one IceBreaker register, follow this procedure:
   - Select Scan chain 2
   - Enter INTEST mode
   - Scan in 5 bits with the reg. addr and 1 bit (set to 0) as R/W 
     (no need to scan in 32 data bits that will not be useful)
   - Enter Update-DR state in TAP machine to read the register.
   - Scan out 32 bits while scanning in 0's. The 32 bits will be the
     desired register contents.
   - Go to Update-DR to exit the procedure.
   NOTE: if several registers must be R/W one after another, you can
   read out one register contents while clocking in the address and R/W
   bit for the next. Not implemented yet.
*/

unsigned int IceBreakerRegRead(int nreg)
{ u_int32_t indata[2];               /* 2 words enough for 38 bits  */
  u_int32_t outdata[2];


  SelectScanChain(2);                   /* Select IceBreaker Scan chain */
  EnterIRInst(4, 0x0c);                 /* Enter INTEST instr.         */
  indata[0] = nreg;                     /* bits 4..0 = nreg, bit 5=r/w  */
  indata[1] = 0;                        /* New reg data (not useful)    */
  /* Enter 32+5+1 bits in two phases: */
  EnterDRBits(32,  &indata[1], &outdata[1],1,0);  /* Read 32 bits out   */
  EnterDRBits(5+1, &indata[0], &outdata[0],0,1);  /* Send read cmd      */
  /* Now repeat the same but this time read out first 32 bits: */
  EnterDRBits(32,  &indata[1], &outdata[1],1,0);  /* Read 32 bits out   */
  EnterDRBits(5+1, &indata[0], &outdata[0],0,1);  /* Send read cmd      */

  return outdata[1];  /* Return 32 bits readout */
}

/***--------------------------------------------***/
/***  Overwrite IceBreaker register contents    ***/
/***--------------------------------------------***/

unsigned int IceBreakerRegWrite(int nreg, unsigned int regdata)
{ u_int32_t indata[2];               /* 2 words enough for 38 bits  */
  u_int32_t outdata[2];

  SelectScanChain(2);                   /* Select IceBreaker Scan chain */
  EnterIRInst(4, 0x0c);                 /* Enter INTEST instr.         */
  indata[0] = regdata;                  /* Bits 0..31 = new data        */
  indata[1] = 0x20+nreg;                /* bits 32..36 = nreg, bit 37= r/w =1 */
  EnterDRBits(32+5+1, indata, outdata,1,1); /* Send write cmd & read out data */
  return outdata[0];                    /* Only use 32 LSB bits out of 38 */
}

/***--------------------------------------------***/
/***  Read & print ALL of IceBreaker registers  ***/
/***--------------------------------------------***/

/* NOTE: IceBreaker reg numbers are NOT in sequence !!! */

int ReadAllIceBreakerRegs(void)
{ int nreg;
  
  printf ("IceB Debug Control        = 0x%08X\n", IceBreakerRegRead(0));
  printf ("IceB Debug Status         = 0x%08X\n", IceBreakerRegRead(1));
  printf ("IceB Debug Comms Control  = 0x%08X\n", IceBreakerRegRead(4));
  printf ("IceB Debug Comms Status   = 0x%08X\n", IceBreakerRegRead(5));

  printf ("IceB WatchP #0 Address    = 0x%08X\n", IceBreakerRegRead(8));
  printf ("IceB WatchP #0 Addr.mask  = 0x%08X\n", IceBreakerRegRead(9));
  printf ("IceB WatchP #0 Data       = 0x%08X\n", IceBreakerRegRead(10));
  printf ("IceB WatchP #0 Data mask  = 0x%08X\n", IceBreakerRegRead(11));
  printf ("IceB WatchP #0 Control    = 0x%08X\n", IceBreakerRegRead(12));
  printf ("IceB WatchP #0 Contr.mask = 0x%08X\n", IceBreakerRegRead(13));

  printf ("IceB WatchP #1 Address    = 0x%08X\n", IceBreakerRegRead(16));
  printf ("IceB WatchP #1 Addr.mask  = 0x%08X\n", IceBreakerRegRead(17));
  printf ("IceB WatchP #1 Data       = 0x%08X\n", IceBreakerRegRead(18));
  printf ("IceB WatchP #1 Data mask  = 0x%08X\n", IceBreakerRegRead(19));
  printf ("IceB WatchP #1 Control    = 0x%08X\n", IceBreakerRegRead(20));
  printf ("IceB WatchP #1 Contr.mask = 0x%08X\n", IceBreakerRegRead(21));
  printf ("\n");
  return 0;
}

/***------------------------------------------------***/
/***  Stop a running program and enter DEBUG state  ***/
/***------------------------------------------------***/

/* Works by putting a '1' in DBGRQ (Debug Control Register, ICE Breaker) */
/* NOTE: the program MUST be running */

int StopRunningProgram(void)
{
  IceBreakerRegWrite(0, 0x07);              /* DBGRQ=1 */

  /* After sending data, RUN-TEST/IDLE state must be entered: */
   StepNextTAPState(0);             /* goto Run-Test/Idle          */

  /* Show the Debug Status Register contents to see if the processor
     is stopped: */
  /*
  printf("StopRunningProgram: Debug Status Reg.=0x%02X\n",
          IceBreakerRegRead(1));
  printf("StopRunningProgram: Debug Status Reg.=0x%02X\n",
          IceBreakerRegRead(1));
  */
  
  /* Put a flag to remember later that the debug state was entered because
     WE requested it directly (not thru a breakpoint/watchpoint): */
  is_debugrequest = 1;
  
  return 0;
}

/* Put a breakpoint at some address using ICEBreaker */
int PutBreakPoint(unsigned int addr)
{

  IceBreakerRegWrite(12, 0x0f0);                   /* WP0 contr value DISABLE */
  IceBreakerRegWrite(20, 0x0f0);                   /* WP1 contr value DISABLE */
  IceBreakerRegWrite(9,  0xffffffff);              /* WP0 Addr mask=ignore */
  IceBreakerRegWrite(11, 0xffffffff);              /* WP0 data mask=ignore */
  IceBreakerRegWrite(13, 0x0f7);                   /* WP0 contr mask=nOPC only*/
  IceBreakerRegWrite(12, 0x1f0);                   /* WP0 contr value nOPC=0 */


  /* Flag to know if the debug state was entered because of a BRKP/WATCHP
     or a direct debug request: */

  is_debugrequest = 0;
  return 0;
}

/* Disable any enabled breakpoint */
int ClearAnyBreakPoint(void)
{
  IceBreakerRegWrite(12, 0x0f0);               /* WP0 contr value ENABLE=0 */
  return 0;
}

/* Clear Debug Request */
int ClearUserDebugRequest(void)
{
  IceBreakerRegWrite(0, 0x00);              /* DBGRQ=0 */

  /* After sending data, RUN-TEST/IDLE state must be entered: */
  /* Not necessary: works without it. Must check docs...      */
  /* StepNextTAPState(0);*/             /* goto Run-Test/Idle          */

  return 0;
}

/***------------------------------------------------***/
/***  Read out internal CPU registers (ARM state)   ***/
/***------------------------------------------------***/

/* Only works in DEBUG state !!! */

/* WARNING: this routine should be called only ONCE, just
   after entering debug state. If called again while in debug
   state, the saved register values will be overwritten.
*/


int ReadCpuRegs(int reset_inst_counter)
{ 
  u_int32_t outdata[2];
  u_int32_t instruction;
  int i;

  if (reset_inst_counter)
    total_ins_exec = 0;

  /* Read ICEBreaker Status reg. to see if we are on THUMB state: */
  i = IceBreakerRegRead(1);
  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  if (0x10 & i)
    { /* The CPU was in THUMB state: take note of the fact & enter ARM mode
         to read the registers. Registers in THUMB state are just a subset
         of those in ARM state, so no need to worry about reading
         THUMB-state registers.*/

      was_in_thumb = 1;

      /* Feed instructions to the pipeline while in thumb state: */
      /* STR R0,[R0] = 0x60006000    */
	SC1(0,0x60006000,outdata);
	is_watchpoint=outdata[1];
      /* NOTE: value returned shows BREAKPT/WATCHPT */

      		/* MOV R0,PC = 0x46784678  */
	SC1(0, THUMB_MOV_R0_PC, NULL);
      total_ins_exec++;

      	/* STR R0,[R0] = 0x60006000    */
      	SC1(0,0x60006000,NULL);

      /* Next cycle is the execution of the 1st STR: */
          /* NOP = MOV R8,R8 */
      	SC1(0,0x46c046c0,outdata);
      	CPU_regs[0] = outdata[0];                /* Copy register contents    */
      /* printf ("%08x  ",outdata[0]); */

      /* BX PC = 0x47784778   (Enter ARM state) */
	SC1(0,0x47784778,NULL); 
      total_ins_exec++;

      /* Next cycle is the execution of the 1st STR: */
      /* NOP = MOV R8,R8 = 0x46C046C0  */
      SC1(0,0x46C046C0,outdata);
      CPU_regs[15] = outdata[0];               /* Copy register contents (PC) */

      /* NOP = MOV R8,R8 = 0x46C046C0  */
      	SC1(0,0x46c046c0,NULL); 
      total_ins_exec++;
    }
  else
    { was_in_thumb = 0;
    }
    
  /* From now on, we are in ARM state */
    
  /* Start feeding instructions to the pipeline. First 3 instructions are
     eaten by the pipeline without doing anything: */

  /* STM R0,{R0..R15} = 1110.1000.1000.0000.1111.1111.1111.1111 = 0xE880ffff */
  if (was_in_thumb)
    instruction = 0xE8007FFE;               /* R1-R14 only in THUMB    */
  else
    instruction = 0xE800FFFF;               /* R0-R15 in ARM           */
  SC1(0,instruction,outdata);
  i = outdata[1];    /* Send opcode & read out data */
  if (was_in_thumb == 0)
    is_watchpoint = i;                  /* Value returned shows BREAKPT/WATCHPT */
  total_ins_exec++;
 
     /*  MRS R0,CPSR   */
  SC1(0,0xe10f0000,NULL);
  total_ins_exec++;

  /* 1st instruction (STM) is executed while fetching the 3rd instr.: */
    /*  STR R0,R0     */
  SC1(0,0xe5800000,NULL); 

  /* Read out registers while STM is being executed: */
  /* In THUMB state only regs. R1-R14 will be recovered now. */
  if (was_in_thumb)
    for (i=1; i<15; i++)
      {
	SC1(0,ARM_NOP,outdata); 
        CPU_regs[i] = outdata[0];                /* Copy register contents    */
        /* printf ("%08x  ",outdata[0]); */
      }
  else
    for (i=0; i<16; i++)
      { 
	SC1(0,ARM_NOP,outdata); 
        CPU_regs[i] = outdata[0];                /* Copy register contents    */
        /* printf ("%08x  ",outdata[0]); */
      }
  /* printf ("\n"); */

  /* PC must be adjusted to allow for pipelining. Adjustment varies depending
     on how debug state was entered (breakpoint, watchpoint, debug request) */
  if (is_debugrequest)
    CPU_regs[15] -= 0x14;
  else
    CPU_regs[15] -= 0x18;

  /* Keep track of how many instructions are being executed while in DEBUG: */
  total_ins_exec++;

  /* next 2 instructions are just NOP's:
  /* Execute MRS R0,CPSR: */   
  SC1(0,ARM_NOP,NULL); 
  total_ins_exec++;

  /* Execute STR R0, R0: */
  SC1(0,ARM_NOP,NULL); 

  SC1(0,ARM_NOP,outdata); 
  total_ins_exec++;

  CPU_CPSR = outdata[0];                /* Copy register contents    */
  /* printf ("CPSR = %08x\n",outdata[0]); */

  /* Still work to do to read USER, FIQ, SPSR regs.... */
    
  return 0;
}

/***------------------------------------------------***/
/***  Restore registers and RUN (exit DEBUG state)  ***/
/***------------------------------------------------***/

/* Only works in DEBUG state, of course !! */
/*
	LDM	-
 	NOP	-
	-	LDM
	-	R0
	-	...
	-	R14
     	NOP
	NOP
  BRK	NOP 	
	BRA

*/
int ExitDebug(void)
{ 
  u_int32_t outdata[2];
  u_int32_t dest;
  int i;

  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  /* Scan in instructions in the data bus */ 

  /* Recover any overwritten registers: R0-R14 (R15 will be recovered last) */
  SC1(0,ARM_LDMIA(0,0x7fff) /* 0xe8907fff*/,NULL);	 /* LDM R0,{R0-R14} = 0xE8907fff   */
  total_ins_exec++;

  SC1(0,ARM_NOP,outdata);	 total_ins_exec++;
  SC1(0,ARM_NOP,outdata);	 total_ins_exec++;

  /* At this point, the LDM R0,{R0-R14} instruction is executed: */
  /* 15 read cycles will be executed */
  for (i=0; i<15; i++)
    { 
	SC1(0,CPU_regs[i],NULL);
    }

  /* 3rd cycle is just a prefetch */
  SC1(0,ARM_NOP,outdata); 
  SC1(0,ARM_NOP,outdata); total_ins_exec++;
  SC1(1,ARM_NOP,outdata); 	/* BREAK=1 */
  total_ins_exec++;

  /* B -6 = 0xEAFFFFFA */
  /* Calculate branch instruction: 3 for debug request plus 1 for each
     instruction executed, including the branch itself. */
  dest = (unsigned int)(-3 -1 -total_ins_exec);

  /* User debug request have one fetch less: */
  if (is_debugrequest == 0)
    dest--;

  /* generate the branch field in the instr.: */
  dest &= 0x00ffffff;
  dest |= 0xEA000000;
  /* printf ("BRANCH = %08x\n",indata[0]); */
  SC1(0,dest,NULL);

  /* Enter a RESTART instr. in the TAP controller: */
  EnterIRInst(4, 0x04);             /* Enter RESTART instr.         */
  StepNextTAPState(0);             /* goto Run-Test/Idle          */

  /* printf ("Program running again...\n"); */
  return 0;
}

/***------------------------------------------------***/
/***         Read memory while in DEBUG state       ***/
/***------------------------------------------------***/

/* Max read speed on a Pentium @90 Mhz: 1.5 Kbytes/sec */
/* Can be made faster by using more registers on LDM & STM instrs. */

/*   The way to access real memory while in DEBUG is as follows:
     (NOT as shown in the official documentation - DOES NOT WORK !!!)
     - Load R0 with the address to read
     - Program ICEBreaker to make a breakpoint on ANY instruction.
       Previous ICEBr. register values should be saved previously.
     - Perform an EXIT DEBUG procedure with the last instruction
       scanned in the data bus being an LDMIA R0,{R0-Rn}
     - The LDM instruction will be executed in real time and will load
       R0-Rn with the desired value. When the CPU trys to execute the next
       instruction, a breakpoint will be generated and DEBUG state will
       be entered again.
     - Disable breakpoints by reprogramming ICEBreaker.
     - Now the R0-Rn values can be recovered with an STM R0,{R0-Rn} instruction
       at debug speed.

LD_R0	-
NOP	-
	LD_R0
	adr
	i
*/

int ReadMemory(u_int32_t address, int howmanywords, FILE *f)
{ 
  u_int32_t outdata[2];
  int i,j;
//  int lines=0;
//  printf ("READ MEMORY AT 0x%08X:\n", address);
  j=0;

  PutBreakPoint(0x20000000);        /* Put 'any address' breakpt.-> stop NOW! */
  
//while ((lines*8) < howmanywords)
while (howmanywords > 0)
{  

  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  /* Scan in instructions in the data bus */ 
  /* Load R0 with the address to read: */
  /* LDR R0,PC+xx = 0xE59F0000 */
  SC1(0, ARM_LD_R0_PC,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  RunTest_Idle();

  /* At this point, the LDR R0,PC+xx instruction is executed: */
  /* 2nd cycle performs the memory read to R0: */
  SC1(0,address,NULL);

  /* 3rd cycle is just a prefetch */
  RunTest_Idle(); total_ins_exec++;

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;

  /* Insert a NOP with bit 33=1 */
  SC1(1,ARM_NOP,NULL); total_ins_exec++;

  /* System speed access: LDMIA R0,{R0-R7} = 0xE89000ff */
  SC1(0,ARM_LDMIA(0,0xff),NULL); total_ins_exec++;

  /* Perform an EXIT DEBUG STATE procedure by entering a RESTART
     instruction + RUN-TEST/IDLE: */

  EnterIRInst(4, 0x04);             /* Enter RESTART instr.         */
  StepNextTAPState(0);            /* goto Run-Test/Idle          */

  /* wait for breakpoint to be triggered */
  for (i=0; i<16; i++) { }     /* Busy wait loop */

  /* After doing this, the CPU will be stopped again in DEBUG state.
     Registers R0-R7 must be read out to know the desired value */

  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  SC1(0,ARM_STMDA(0,0xff), NULL);		 /* Bits 0..31  = STM R0,{R0-R7} */
  total_ins_exec++;

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;

  /* Execute STM R0,{R0-R7}: */
  
  if (f==NULL) printf("%08x: ",address);
  for (i=0; i<8; i++)
    {	
	SC1(0,0,outdata); 
	if (howmanywords-- > 0){
		if (f==NULL) 	printf ("%08x  ", outdata[0]);
		else		fwrite(&outdata[0],4,1,f);
	}
    }
  if (f==NULL) printf ("\n");

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;

  address += (4*8);                         /* Go for next memory address */
  //lines++;
}
  if (f==NULL) printf ("\n");

  /* No need to use the breakpoint again: */
  ClearAnyBreakPoint();         /* Avoid entering debug state after exiting */

  return 0;
}

u_int32_t ReadWord(u_int32_t address)
{ 
  u_int32_t outdata[2];
  int i,j;
  int lines=0;
  j=0;

  PutBreakPoint(0x20000000);        /* Put 'any address' breakpt.-> stop NOW! */
  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  /* Scan in instructions in the data bus */ 
  /* Load R0 with the address to read: */
  /* LDR R0,PC+xx = 0xE59F0000 */
  SC1(0, ARM_LD_R0_PC,NULL);
  total_ins_exec++;

  SC1(0,ARM_NOP,NULL); total_ins_exec++;

  RunTest_Idle();

  /* At this point, the LDR R0,PC+xx instruction is executed: */
  /* 2nd cycle performs the memory read to R0: */
  SC1(0,address,NULL);

  /* 3rd cycle is just a prefetch */
  RunTest_Idle();
  total_ins_exec++;

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  /* Insert a NOP with bit 33=1 */
  SC1(1,ARM_NOP,NULL); total_ins_exec++;

  /* System speed access: LDMIA R0,{R0-R7} = 0xE89000ff */
   SC1(0,ARM_LDRH(0,1),NULL);
  /* Perform an EXIT DEBUG STATE procedure by entering a RESTART
     instruction + RUN-TEST/IDLE: */

  /* Enter a RESTART instr. in the TAP controller: */
  EnterIRInst(4, 0x04);             /* Enter RESTART instr.         */
  StepNextTAPState(0);            /* goto Run-Test/Idle          */

  /* wait for breakpoint to be triggered */
  for (i=0; i<16; i++) { }     /* Busy wait loop */

  /* After doing this, the CPU will be stopped again in DEBUG state.
     Registers R0-R7 must be read out to know the desired value */

  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  SC1(0,ARM_STMDA(0,0x02) /*0xe8000002*/,NULL);		 /* Bits 0..31  = STM R0,{R1} */
  /*indata[0] = 0xE5800000;*/            /* Bits 0..31  = STR R0,R0     */
  total_ins_exec++;

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL);
  total_ins_exec++;

  /* Execute STM R0,{R0-R7}: */
  
//  printf("read WORD %08x: ",address);
      SC1(0,0,outdata); 
//      printf ("%08x  ", outdata[0]);
  printf ("\n");

  SC1(0,ARM_NOP,NULL);
  total_ins_exec++;

  SC1(0,ARM_NOP,NULL);
  total_ins_exec++;

  /* No need to use the breakpoint again: */
  ClearAnyBreakPoint();         /* Avoid entering debug state after exiting */

  return outdata[0];
}

// 8-bit memory write
// TODO: instruction count 

// LD_RO	-
// LD_R1	-
// NOP		LD_R0
//		adr		
//		i 
// NOP		LD_R1
//		val		
//		i 

WriteMemoryLocation(u_int32_t address, u_int32_t value)
{
int i;

//printf("write 0x%0lx -> 0x%08lx\n",value,address);

  PutBreakPoint(0x20000000);        /* Put 'any address' breakpt.-> stop NOW! */
  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  SC1(0, ARM_LD_R0_PC,NULL); total_ins_exec++;		// address -> R0
  SC1(0, ARM_LD_R1_PC,NULL); total_ins_exec++;		// value   -> R1

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,address,NULL);
  SC1(0,ARM_NOP,NULL);
  
  SC1(0,ARM_NOP,NULL);
  SC1(0,value,  NULL);
  SC1(0,ARM_NOP,NULL);

  SC1(0,ARM_NOP,NULL);
  SC1(0,ARM_NOP,NULL);
  SC1(0,ARM_NOP,NULL);
  SC1(1,ARM_NOP,NULL);

//  SC1(0,ARM_STRH(0,1),NULL);		// R1 -> [R0] --> this works too, for halfwords
  SC1(0,ARM_STMDA(0,2),NULL);		// R1 -> [R0]

  EnterIRInst(4, 0x04);             	/* Enter RESTART instr.         */
  StepNextTAPState(0);            	/* goto Run-Test/Idle          */

  /* wait for breakpoint to be triggered */
  for (i=0; i<16; i++) { }     /* Busy wait loop */

  ClearAnyBreakPoint();         /* Avoid entering debug state after exiting */
}

/*
        LDM     R0,Rlist        ... load registers with values R0=adress, R1..Rn = data
        ** execute at system speed **
        STM     R0,Rlist        ... store R1..Rn -> [R0]
 */
WriteMemoryBuf(u_int32_t address, int count, u_int32_t *pMemory)
{
//u_int32_t indata[2];
int i;

//printf("write 0x%0lx -> 0x%08lx\n",value,address);

  PutBreakPoint(0x20000000);        /* Put 'any address' breakpt.-> stop NOW! */
  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  SC1(0,ARM_LDMIA(0,((1<<(count+1))-1)),NULL);          /* load R0,R1,... */
  SC1(0,ARM_NOP,NULL);
  SC1(0,ARM_NOP,NULL);
  SC1(0,address,NULL);          // R0
  for(i=0; i<count; i++) SC1(0,*pMemory++,NULL); 

  SC1(0,ARM_NOP,NULL);
  SC1(0,ARM_NOP,NULL);

  SC1(1,ARM_NOP,NULL);          // execute next instr. at systemspeed

  SC1(0,ARM_STMIA(0,((1<<count)-1)<<1),NULL);             // R1..Rn -> [R0]

  EnterIRInst(4, 0x04);                 /* Enter RESTART instr.         */
  StepNextTAPState(0);                  /* goto Run-Test/Idle          */

  /* wait for breakpoint to be triggered */
  for (i=0; i<16; i++) { }     /* Busy wait loop */

  ClearAnyBreakPoint();         /* Avoid entering debug state after exiting */
}

RunProgram(u_int32_t address)
{
  printf("Run program at 0x%lx\n",address);

  SelectScanChain(1);               /* Select Debug Scan chain */
  EnterIRInst(4, 0x0c);             /* Enter INTEST instr.         */

  SC1(0, ARM_LD_R0_PC,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  RunTest_Idle();
  SC1(0,address,NULL);

  RunTest_Idle(); total_ins_exec++;

  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;
  SC1(0,ARM_NOP,NULL); total_ins_exec++;

  /* Insert a NOP with bit 33=1 */
  SC1(1,ARM_NOP,NULL); total_ins_exec++;

  SC1(0,ARM_MOV(15,0),NULL);	 	/* MOV pc,r0 */

  EnterIRInst(4, 0x04);                 /* Enter RESTART instr.         */
  StepNextTAPState(0);                  /* goto Run-Test/Idle          */

  /* Yippieeh! We are running! */
}

#if 0
/***-----------------------------------***/
/***                                   ***/
/***             MAIN                  ***/
/***                                   ***/
/***-----------------------------------***/

int xmain (int argc, char *argv[])
{ int x,i,j;
u_int32_t v1,v2;
int rand=0;
  initialize_jtag_hardware();

/* First thing to do is to check IDCODE: */
//SetTDI(0);
ResetTapC();
printf ("IDCODE=%08X\n", ReadIDCode());

usleep(500000);

  for (;;)
    { 
#ifdef TESTPINS
      /* Just to check connections...*/
      outb(1, DATA_PORT);
      usleep(300000);
      outb(0, DATA_PORT);
      usleep(300000);
      x = inb(STATUS_PORT);
      printf("DATA= %02x\n", x);
#endif

/* First thing to do is to check IDCODE: */
#ifdef TEST1
ResetTapC();
printf ("IDCODE=%08X\n", ReadIDCode());
#endif

/* Then try more advanced things: */
#ifdef TEST2
ResetTapC();                      /* First reset the TAP machine */
ReadAllIceBreakerRegs();
IceBreakerRegWrite(9, 0xdefabada);  /* Just to see if writing works...*/
printf ("IceB WatchP #0 Addr.mask  = 0x%08X\n\n", IceBreakerRegRead(9));
usleep(1000000);
#endif

/*  Show IceB. registers before & after entering debug state: */
printf ("IceB Debug Control = 0x%08X  Status = 0x%08X\n",
         IceBreakerRegRead(0), IceBreakerRegRead(1));

/*StopRunningProgram();*/           /* Stop by user request */
PutBreakPoint(0x20000000);          /* Put 'any address' brekpt.-> stop NOW! */
usleep(100000);                     /* Wait a bit to allow entering the breakpoint */

printf ("IceB Debug Control = 0x%08X  Status = 0x%08X\n",
         IceBreakerRegRead(0), IceBreakerRegRead(1));

/*ClearUserDebugRequest();*/         /* Clear user debug request */
ClearAnyBreakPoint();              /* Avoid entering debug state after exiting */
total_ins_exec = 0;                /* From now on, count instructions */
ReadCpuRegs(0);                    /* Read CPU registers & store away */

/* EBI read */
ReadMemory(0xffe00000,8);
//ReadMemory(0xffe00020,1);
//ReadMemory(0xfffff000,64);

/* System speed access test */ 
//ReadMemory(0x00000000, 96);         /* Read memory (in words, 4 bytes/each) */

// try read-id. Write at top half of flash.
WriteMemory(0x0101aaaa,0xaaaaaaaa);
WriteMemory(0x01015554,0x55555555);
WriteMemory(0x0101aaaa,0x90909090);

v1=ReadWord(0x01000000);
v2=ReadWord(0x01000002);
printf("******************* 0x%lx 0x%lx\n",v1,v2);
sleep(1);
v1=ReadWord(0x01000000);
v2=ReadWord(0x01000002);
printf("******************FFF 0x%lx 0x%lx\n",v1,v2);
//sleep(1);
ReadMemory(0x1000000,0x20); 

//exit(0);


//ReadMemory(0x01000000,128*1024/4);	// Flash 128KB
//ReadMemory(0x02000000,100*1024/4);	// RAM 512KB
//WriteMemory(0x02000008,0xaaaaaaab);
//WriteMemory(0x0200000a,0x55555556);
rand +=0x22221111;


  SelectScanChain(1);               /* Select Debug Scan chain */

j=5555;
WriteMemory(0x2000004,0x1234+j);
ReadMemory(0x02000000,16);	// RAM 512KB
WriteMemory(0x2000006,0x2345+j);
ReadMemory(0x02000000,16);	// RAM 512KB
WriteMemory(0x2000008,0x6789+j);

ReadMemory(0x02000000,16);	// RAM 512KB
exit(0);

ExitDebug();                       /* Leave debug state & run again   */
//exit(0);

/* Show the reason the program was stopped: */
printf ("Program halted by user debug request: %s\n", is_debugrequest ? 
          "YES" : "NO, is a breakpoint/watchpoint");
if (is_debugrequest == 0)
  printf ("BREAK/WATCH: %s\n", is_watchpoint ? "WATCHPOINT" : "BREAKPOINT");

/* Show register values: */
printf ("Register contents:\n");
for (i=0; i<16; i++)
  printf ("%08X  ", CPU_regs[i]);
printf   ("CPSR    = 0x%08X\n", CPU_CPSR);

usleep(3000000);

    }

  return 0;
}

STAT()
{
  printf ("IceB Debug Status         = 0x%08X\n", IceBreakerRegRead(1));
  SelectScanChain(1);
}

#endif

