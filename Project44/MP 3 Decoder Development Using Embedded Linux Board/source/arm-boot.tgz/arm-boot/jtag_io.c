/**************************************************************************
 *      Copyright (C) Dipl.-Ing. Erwin Authried 2000                      *
 *                    Softwareentwicklung und Systemdesign                *
 *      Released under the GNU GPL                                        *
 **************************************************************************/

/*! \file
  \brief JTAG i/o for parallel port wigglers.
  \author Erwin Authried
  \version $Id: jtag_io.c,v 1.2 2000/10/25 09:01:05 eauth Exp $

  Schematics from R. Longo
*/

/*--------------------------------------------------------------------

       SCHEMATIC FOR THE PARALLEL PORT INTERFACE CIRCUIT

   NOTE: Power comes from the JTAG connector (3.3 V) and feeds
         just the 74HC240 and the pullups. The 74HC240 works OK
         at 3.3 Volts. Instead of a 74HC240, a pair of 74HC14's
         can also be used. Put also some decoupling on VDD
         (10 uF will do).


   JTAG VDD -------------------------------  +3.3V
   (PIN 1+2)          |                        |
                 74HC240 VDD                   |
                                              [5K]
                                               |
   JTAG TMS  ________/|______/|_________[22K]__|___  D0 (LPT1)
    (PIN 7)          \|      \|                       (PIN 2)
                 74HC240    74HC240

                                             +3.3V
                                               |
                                              [5K]
   JTAG TCK  ________/|______/|_________[22K]__|___  D1 (LPT1)
    (PIN 9)          \|      \|                       (PIN 3)
                 74HC240    74HC240

                                             +3.3V
                                               |
                                              [5K]
   JTAG TDI  ________/|______/|_________[22K]__|___  D2 (LPT1)
    (PIN 5)          \|      \|                       (PIN 4)
                 74HC240    74HC240



   JTAG TDO  ________|\______|\__________________  SELECT (LPT1)
    (PIN 13)         |/      |/                       (PIN 13)
                 74HC240    74HC240


   JTAG GND  -------------------------------------- GND  (LPT1)
    (PIN 20)          |     |      |               (PINS 18..25)
                74HC240 E1  |  74HC240 E2
                            |
                        74HC240 GND


---------------------------------------------------------------*/

#include <unistd.h>
#include <sys/types.h>
#include <asm/io.h>

/* Parallel port i/o addr. (LPT1) */
#define DATA_PORT    0x378
#define STATUS_PORT  0x379

/***-------------------------------------***/
/*** Masks for the parallel port pins    ***/
/***-------------------------------------***/

/* Change these masks if you change the connections */

/* TMS, TCK & TDI are connected to one pin each of D0-D7 (data port) */
/* TDO is connected to one pin of the status port (SELECT) */

#define MASK_TMS_BIT   2	//0x01
#define MASK_TCK_BIT   1	//0x02
#define MASK_TDI_BIT   4	//0x04
#define MASK_TDO_BIT   0x20	//0x10

/* Polarity of signals */
#define INVERT_TMS 0		// 0
#define INVERT_TCK 0		// 0
#define INVERT_TDI 0		// 0
#define INVERT_TDO 1		// 1

static unsigned char dataPortImg = 0;   /* Local copy of data port */

/*! \brief Parallel port initialization
 */
int initialize_jtag_hardware()
{
	int ret;

	ret=ioperm(DATA_PORT,8,1);
	if (ret) return ret;
	dataPortImg=0xff;
	jtag_io(0,0,0);
	return 0;
}

/*! \brief JTAG i/o
    \param tms output value for TMS
    \param tdi output value for TDI
    \param read_tdo 1:read  and return TDO, 0:return 0
 */
int jtag_io(int tms, int tdi, int read_tdo)
{
	int data=0;
	int tdo=0;

	if (read_tdo) {
		tdo = (inb(STATUS_PORT)&MASK_TDO_BIT) ? (INVERT_TDO?0:1):(INVERT_TDO?1:0);	// TDO
	}

	data = (tdi ? (INVERT_TDI?0:MASK_TDI_BIT) : (INVERT_TDI?MASK_TDI_BIT:0))
		| (tms ? (INVERT_TMS?0:MASK_TMS_BIT) : (INVERT_TMS?MASK_TMS_BIT:0));

	if (data != dataPortImg){
		 outb(data | ((INVERT_TCK)?MASK_TCK_BIT:0),DATA_PORT);	// TMS,TDI
		 dataPortImg=data;
	}

	// TCK pulse
	outb(data|((INVERT_TCK)?0:MASK_TCK_BIT), DATA_PORT);	// Set TCK
	outb(data|((INVERT_TCK)?MASK_TCK_BIT:0), DATA_PORT);	// Clear TCK

#if 0
	if (verbose){
		printf("tms/tdi %d/%d ", tms, tdi);
		if (read_tdo) printf("tdo=%d", tdo);
		printf("\n");
	}
#endif
	return (tdo);
}

