#!/bin/sh

#
# board initializaton for ARM EB01
#
# FLASH: 0x01000000	64KB	Bootcode,Angel
#	 0x01010000	64KB	Application
#	 0x01020000

# RAM:	0x02000000 	2MB+512k	RAM
#	0x02280000
# 	RAM:	0x020000000	1MB	CS4
# 	RAM:	0x021000000	1MB	CS5
# 	RAM:	0x022000000	512kB	NCS1

echo 'Initializing board...'
# EBI_CSR0
./armtool write 0xffe00000 0x0100223D	# Enable, 16-bit, 6 WSates, 1M PSize, TDF:0

# EBI_CSR1
./armtool write 0xffe00004 0x02202001	# Enable, 16-bit, 0 WSates, 1M PSize, TDF:0

# EBI_CSR2 .. EBI_CSR7
./armtool write 0xffe00008 0x20000000
./armtool write 0xffe0000c 0x30000000
./armtool write 0xffe00010 0x02002001	# Enable, 16-bit, 1 WStates, 1M PSize, TDF:0
./armtool write 0xffe00014 0x02102001	# Enable, 16-bit, 1 WStates, 1M PSize, TDF:0
./armtool write 0xffe00018 0x60000000
./armtool write 0xffe0001c 0x70000000

# EBI Remap Control Register
# REMAP done
./armtool write 0xffe00020 1

# EBI Memory Control Register
# 1MByte per CS
./armtool write 0xffe00024 0x17

# Diable all interrupts
./armtool write 0xfffff124 0xffffffff

# Diable watchdog timer
./armtool write 0xffff8000 0

echo 'Done.'
