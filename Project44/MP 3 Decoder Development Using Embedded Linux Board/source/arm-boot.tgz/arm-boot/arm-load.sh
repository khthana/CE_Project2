#!/bin/sh

echo 'Setup board.'
./arm-setup.sh

echo 'Execute kernel.'
./arm-exec.sh
