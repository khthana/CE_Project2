unsigned long *out_size;
unsigned long out_pos;

str_init(unsigned long adr)
{
out_size =  (unsigned long*) adr;
*out_size = 0;
out_pos=0;
}

str_add(char *s)
{
char *p;

  p = (char*)  out_size+4;
  p += out_pos;
  while (*s){ 
        *p++ = *s++;
        out_pos++;
  } 
  *out_size = (out_pos+3)>>2;   // nr. of words
  *p++='\n';
  *p++='\n';
  *p++='\n';
}

