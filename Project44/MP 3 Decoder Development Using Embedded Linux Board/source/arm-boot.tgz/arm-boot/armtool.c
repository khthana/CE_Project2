/**************************************************************************
 *      Copyright (C) Dipl.-Ing. Erwin Authried 2000                      *
 *                    Softwareentwicklung und Systemdesign                *
 *      All Rights Reserved.                                              *
 **************************************************************************/
/*!  \file armtool.c
  \brief Simple JTAG monitor for ARM7TDMI
  \author Erwin Authried
  \version $Id: armtool.c,v 1.3 2000/11/16 20:43:40 eauth Exp $

  The program uses the JTAG i/o routines written by R.Longo
*/

#include <stdio.h>
#include <sys/types.h>

void GetInformation(void)
{
  printf ("IDCODE=%08X\n", ReadIDCode());
}

int main(int argc,char **argv)
{
u_int32_t adr,words,value;
u_int32_t buf[16];
FILE *f;
int mode,n;

  if (argc<2) {
        fprintf(stderr, "Usage: %s r{ead}  adr words {filename} ... read from target\n"
                        "       %s w{rite} adr value            ... write a single word to target\n"
                        "       %s w{rite} adr words filename   ... write file contents to target \n"
                        "       %s x{ecute} adr                 ... execute program at 'adr'\n"
			"	%s i{nformation}                ... get the information\n",
                argv[0],argv[0],argv[0],argv[0], argv[0]);
        exit(1);
  }

  if (argc>2) {
  	n=sscanf(argv[2],"%lu",&adr);
  	if (n && adr==0 && argv[2][1]=='x') n=0;
  	if (!n) n=sscanf(argv[2],"%lxu",&adr);
  	if (n!=1) {fprintf(stderr,"argument error: adr\n");exit(1);}
  }
  words=0;
  if (argc>3){
        n=sscanf(argv[3],"%lu",&words);
        if (words==0)  n=0;
        if (!n) n=sscanf(argv[3],"%lxu",&words);
        if (n!=1) {fprintf(stderr,"argument error: words\n");exit(1);}
  }

//  printf("adr=0x%lx words=0x%x\n",adr,words);

  if (initialize_jtag_hardware() < 0) {
		perror("initialize_jtag_hardware");
  }


  ResetTapC();
  PutBreakPoint(0x20000000);          /* Put 'any address' brekpt.-> stop NOW! */
  ClearAnyBreakPoint();              /* Avoid entering debug state after exiting */
//  total_ins_exec = 0;                /* From now on, count instructions */
  ReadCpuRegs(0);                    /* Read CPU registers & store away */

        switch(argv[1][0]){
        case 'w':
        case 'W':

        if (argc==5){
                f=fopen(argv[4],"r");
                if (f==NULL) {fprintf(stderr,"can't open file\n");exit(1);}
                while(words){
			n=words; if (n>14) n=14;
                        n=fread(buf,4,n,f);
                        if (n==0)  {fclose(f); fprintf(stderr, "end of file at 0x%lx\n",adr); exit(0);}
                        WriteMemoryBuf(adr,n,buf);
                        adr+=4*n; words-=n;
                }
                fclose(f);

        }
        else{
                WriteMemoryBuf(adr,1,&words);
        }
        break;

        case 'r':
        case 'R':
                f=NULL;
                if (argc==5){
                        f=fopen(argv[4],"w");
                        if (f==NULL) {fprintf(stderr,"can't create file");exit(1);}
                }

                ReadMemory(adr,words,f);
                if (f!=NULL) fclose(f);
                break;

        case 'x':
        case 'X':
                RunProgram(adr);
                break;
        case 'i':
	case 'I':
		GetInformation();
		break;
        } /* switch */
}

