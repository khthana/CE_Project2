# With a modern GNU make(1) (highly recommended, that's what all the
# developers use), all of the following configuration values can be
# overridden at the command line.  For example:
#   make CROSS=arm-uclinux- DOSTATIC=true

# If you want a static binary, turn this on.
DOSTATIC = false

# Set the following to `true' to make a debuggable build.
# Leave this set to `false' for production use.
# eg: `make DODEBUG=true tests'
# Do not enable this for production builds...
DODEBUG = false

# If you are running a cross compiler, you may want to set this
# to something more interesting, like "arm-uclinux-".
CROSS = arm-uclinux-
CC = $(CROSS)gcc
LD = $(CROSS)gcc
AR = $(CROSS)ar
RANLIB = $(CROSS)ranlib
STRIPTOOL = $(CROSS)strip
CONVERT = elf2flt $(PROG)

# To compile vs an alternative libc, you may need to use/adjust
# the following lines to meet your needs.
UCLINUXDIR = /opt/uClinux/linux
LIBCDIR = /opt/uClinux/uClibc
ROMFSDIR = /opt/uClinux/romfs
GCCINCDIR = $(shell $(CC) -print-search-dirs | sed -ne "s/install: \(.*\)/\1include/gp")

CFLAGS = -mdisable-got -mcpu=arm7tdmi -msoft-float -nostdinc -I$(UCLINUXDIR)/include -I$(LIBCDIR)/include -I$(GCCINCDIR)
LDFLAGS = -mdisable-got -mcpu=arm7tdmi -msoft-float -shared -symbolic -nostdlib -nostartfiles /opt/uClinux/uClibc/crt0.o
LDLIBS = $(LIBCDIR)/libc.a -lgcc
LIBRARIES = $(LDLIBS)

# use '-Os' optimization if available, else use -O2
#OPTIMIZATION = $(shell if $(CC) -Os -S -o /dev/null -xc /dev/null >/dev/null 2>&1; \
#    then echo "-Os"; else echo "-O2" ; fi)
OPTIMIZATION = -O2

WARNINGS = -Wall

ifeq ($(DODEBUG),true)
    CFLAGS  += $(WARNINGS) -g -D_GNU_SOURCE
    LDFLAGS += -Wl,-warn-common
    STRIP    =
else
    CFLAGS  += $(WARNINGS) $(OPTIMIZATION) -fomit-frame-pointer -D_GNU_SOURCE
    LDFLAGS += -s -Wl,-warn-common
    STRIP    = $(STRIPTOOL) --remove-section=.note --remove-section=.comment $(PROG)
endif

ifeq ($(DOSTATIC),true)
    LDFLAGS += --static
endif
