/****************************************************************************/

/*
 *	mp3play.c -- Play mp3 data files
 *
 *	(C) Copyright 1999, Greg Ungerer (gerg@lineo.com)
 *
 *	This code is a derivitive of Stephane Tavenard's mpegdev_demo.c,
 *	which is:


    Author  :   St�phane TAVENARD

    $VER:   MPEGDEC_demo.c 0.3  (20/08/1997)

    (C) Copyright 1997-1997 St�phane TAVENARD
        All Rights Reserved

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

    #Rev|   Date   |                      Comment
    ----|----------|--------------------------------------------------------
    0   |07/05/1997| Initial revision                                     ST
    1   |07/05/1997| Released                                             ST
    2   |23/05/1997| Stream buffer is now configurable                    ST
    3   |20/08/1997| Update to V0.9 OF MPEGDEC library                    ST

    ------------------------------------------------------------------------

    Demo of how to use MPEGDEC link library with SAS/C compiler
    Use of private bitstream access functions (access to ram buffer)

------------------------------------------------------------------------------*/

#include "defs.h"
#include "mpegdec.h"

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <asm/io.h>

static int verbose = 0;

static MPEGDEC_STREAM *mps = NULL;

// Ram buffer
//#define MPEGA_BUFFER_SIZE  (256*1024) // in bytes
//#define MPEGA_BUFFER_SIZE  (64*1024) // in bytes
//#define MPEGA_BUFFER_SIZE  (16*1024) // in bytes
#define MPEGA_BUFFER_SIZE  (4*1024) // in bytes

// PCM buffer
#define PCM_BUFFER_SIZE (MPEGDEC_MAX_CHANNELS*MPEGDEC_PCM_SIZE) // 2 * 1152
//#define MPEGDEC_MAX_FRAME     200

// Global Variables
static INT8   *mpega_buffer = NULL;
static UINT32  mpega_buffer_offset = 0;
static UINT32  mpega_buffer_next_block = 0;
static UINT32  mpega_buffer_size = 0;
static UINT32  mpega_stream_size = 0;
static int     mpega_buffer_fd = 0;
static char   *mpega_filename = NULL;


/* Get stream size (just file size) */

static int getstreamsize(void)
{
   struct stat st;
   if (stat(mpega_filename, &st) < 0)
	return(0);
   return(st.st_size);
}

/* Get another chunk of data into RAM */

static UINT32 getnextbuffer()
{
   lseek( mpega_buffer_fd, mpega_buffer_next_block, SEEK_SET );
   mpega_buffer_size = read( mpega_buffer_fd, mpega_buffer, MPEGA_BUFFER_SIZE );
   mpega_buffer_next_block += mpega_buffer_size;
   return(mpega_buffer_size);
}

// Here start our own bitstream access routines

INT32 bs_open( char *stream_name, INT32 buffer_size, INT32 *stream_size )
/*-----------------------------------------------------------------------
*/
{
   // We don't really need stream_name
   // print it anyway...
   // buffer_size indicate the following read access size

#if 0
   printf( "bs_open: '%s'\n", stream_name );
#endif

   // Some open errors...
   if( !mpega_buffer ) return 0;

   // initialize some variables
   mpega_buffer_offset = 0;

   // We know total size, we can set it
   *stream_size = mpega_stream_size;

   // Just return a dummy handle (not NULL)
   return 1;
}

void bs_close( INT32 handle )
/*---------------------------
*/
{
   if( handle ) {
      // Clean up
#if 0
      printf( "bs_close\n" );
#endif
   }
}

INT32 bs_read( INT32 handle, void *buffer, INT32 num_bytes )
/*----------------------------------------------------------
*/
{

   INT32 read_size;

   if( !handle ) return -1; // Check valid handle

tryagain:
   read_size = mpega_buffer_size - mpega_buffer_offset;
   if( read_size > num_bytes ) read_size = num_bytes;

   if( read_size > 0 ) {
      if( !buffer ) return -1;
      // Fill buffer with our MPEG audio data
      memcpy( buffer, &mpega_buffer[ mpega_buffer_offset ], read_size );
      mpega_buffer_offset += read_size;
   }
   else {
      if (getnextbuffer() > 0) {
	  mpega_buffer_offset = 0;
	  goto tryagain;
      }
      read_size = -1; // End of stream
   }

   return read_size;
}

int bs_seek( INT32 handle, INT32 abs_byte_seek_pos )
/*-----------------------------------------------
*/
{
   if( !handle ) return -1;

   if( abs_byte_seek_pos <= 0 ) mpega_buffer_offset = 0;
   else if( abs_byte_seek_pos >= mpega_buffer_size ) return -1;
   else mpega_buffer_offset = abs_byte_seek_pos;
   return 0;
}

/* 16-bits Stereo
int output_pcm( INT16 channels, INT16*pcm[ 2 ], INT32 count, INT16 out_file )
//---------------------------------------------------------------------------
//    Ouput the current decoded PCM to DAC (Stereo 16 bits)
//    Return 0 if Ok
//---------------------------------------------------------------------------
{
  int nw;
  static INT16 *pcm_buffer = NULL;
  if( !out_file ) return -1;

    if( !pcm_buffer ) {
      pcm_buffer = (INT16 *)malloc( PCM_BUFFER_SIZE * sizeof(INT16) );
      if( !pcm_buffer ) return -1;
    }
    if( channels == 2 ) {   // Stereo
      register INT16 *pcm0, *pcm1, *pcmLR;
      register INT32 i;

      pcm0  = pcm[ 0 ];     // Left Channel
      pcm1  = pcm[ 1 ];     // Right Channel
      pcmLR = pcm_buffer;  
      i = count;
      
      while( i-- ) {
        *pcmLR++ = *pcm0++;
        *pcmLR++ = *pcm1++;
      }
      //fwrite( pcm_buffer, 4, count, out_file );    // standard library function
      nw = write(out_file, pcm_buffer, 4*count);     // system call (driver's function)
      printf("write %d bytes to DAC\n",nw);
    }
    else { 		    // Mono
      //fwrite( pcm[ 0 ], 2, count, out_file );
      write(out_file, pcm[ 0 ], 2*count);
    }
  
  return 0;
} //output_pcm 
*/

int output_pcm( INT16 channels, INT16*pcm[ 2 ], INT32 count, int out_file )
//---------------------------------------------------------------------------
//    Ouput the current decoded PCM to DAC (Mono 8 bits)
//    Return 0 if Ok
//---------------------------------------------------------------------------
{
  static unsigned char *raw_buffer = NULL;
  register unsigned short *pcm0;
  int i;
	     
  if( !out_file ) return -1;
	        
  if( !raw_buffer ) {
    raw_buffer = (unsigned char *)malloc( PCM_BUFFER_SIZE * sizeof(char) );
    if( !raw_buffer ) return -1;
  }
  
  pcm0 = pcm[ 0 ];    
  for (i = 0; (i < count); i++)
    raw_buffer[i] = (*pcm0++ ^ 0x8000) >> 8;  // Mono 8 bits
  
  write( out_file, raw_buffer, count );

  return 0;
					  
}

int main( int argc, char **argv )
{
   int frame, argnr;
   char *out_filename = NULL;
   int out_file = 0;
   INT16 i;
   INT32 pcm_count;
   INT16 *pcm[ MPEGDEC_MAX_CHANNELS ];
   
   
   MPEGDEC_ACCESS bs_access = { bs_open, bs_close, bs_read, bs_seek };

   static char *modes[] = { "stereo", "j-stereo", "dual", "mono" };

   MPEGDEC_CTRL mpa_ctrl;
   MPEGDEC_CTRL mpa_defctrl = {
      NULL,    // Bitstream access is default file I/O
      // Layers I & II settings (#3)
      { FALSE, { 1, 2, 48000 }, { 1, 2, 48000 } },
      // Layer III settings (#3)
      { FALSE, { 1, 2, 48000 }, { 1, 2, 48000 } },
      0,           // #2: Don't check mpeg validity at start (needed for mux stream)
      2048         // #2: Stream Buffer size
   };

   if( argc <= 1 ) {
      fprintf( stderr, "Usage %s <input mpeg audio files>...\n", argv[ 0 ] );
      exit( 0 );
   }

   mpega_buffer = (INT8 *)malloc( MPEGA_BUFFER_SIZE );
   if( !mpega_buffer ) {
      fprintf( stderr, "Can't allocate MPEG buffer\n" );
      exit( 0 );
   }

   for( i=0; i<MPEGDEC_MAX_CHANNELS; i++ ) {
      pcm[ i ] = malloc( MPEGDEC_PCM_SIZE * sizeof( INT16 ) );
      if( !pcm[ i ] ) {
         fprintf( stderr, "Can't allocate PCM buffers\n" );
         exit( 0 );
      }
   }
  
   argnr = 1;

nextfile:
   mpa_ctrl = mpa_defctrl;

   mpega_buffer_offset = 0;
   mpega_buffer_next_block = 0;

   mpega_filename = argv[ argnr ];

   /* Open file or stream to data */
   mpega_stream_size = getstreamsize();   // Get the size of the data stream
   mpega_buffer_fd = open( mpega_filename, O_RDONLY );

   if( mpega_buffer_fd < 0 ) {
	fprintf( stderr, "Unable to open '%s', errno=%d\n",
		mpega_filename, errno );
	goto badfile;
   }

   // Get first part of the stream into a ram buffer
   getnextbuffer();

   // Set our bitstream access routines and open the stream
   mpa_ctrl.bs_access = &bs_access;

   mps = MPEGDEC_open( mpega_filename, &mpa_ctrl );
   if( !mps ) {
      printf( "Unable to open MPEG Audio stream '%s'\n", mpega_filename );
      goto badfile;
   }

   if (verbose) {
	printf("%s:\n", mpega_filename);
	printf( "    MPEG%d-%s %s %dkbps %dHz (%ld ms)\n",
           mps->norm, (mps->layer == 1)?"I":(mps->layer == 2)?"II":"III",
           modes[ mps->mode ], mps->bitrate, mps->frequency, mps->ms_duration );
	printf( "    Decoding: Channels=%d Quality=%d Frequency=%dHz\n",
           mps->dec_channels, mps->dec_quality, mps->dec_frequency ); // #3
   } else {
   	printf( "%s: MPEG%d-%s (%ld ms)\n", mpega_filename,
	    mps->norm, (mps->layer == 1)?"I":(mps->layer == 2)?"II":"III",
	    mps->ms_duration);
   }

   // Open the output file
   out_filename = "/dev/dac0800";
   if( out_filename ) {
      out_file = open( out_filename, O_WRONLY );
      if( out_file < 0 ) {
         fprintf( stderr, "Can't open output device '%s'\n", out_filename );
         exit( 0 );
      }
   }

   // main decode loop  
   pcm_count = 0;
   frame = 1;
   

   while( (pcm_count = MPEGDEC_decode_frame( mps, pcm )) >= 0 ) {
     if( pcm_count != 0 ) { // first decode return 0 sample
       if( out_file ) output_pcm( mps->dec_channels, pcm, pcm_count, out_file ); 
       //printf("frame: %d\n",frame);
       frame++;
     }
   }

badfile:
   close(out_file);
   close( mpega_buffer_fd );
   MPEGDEC_close( mps );
   mps = NULL;

   if (++argnr < argc)
	goto nextfile;

   exit(0);
}

