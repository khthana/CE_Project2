#!/usr/bin/perl

# Experimental code to duplicate genromfs.c in Perl, with more advanced
# capabilities, including autogeneration of device nodes, and positioning
# of code during FS generation.
#
# Copyright (C) 1998  Kenneth Albanowski <kjahds@kjahds.com>
#                     The Silver Hammer Group, Ltd.
#


@dirfilter = ();
@filter = ();
@finish = (do_fixups, do_checksums);

$BASE = 0x0;

sub gendev { -2 };
sub genino {
	++$genino;
}

sub afterdir (&) {
	my($code) = @_;
	push @afterdir, $code;
}

sub skipfiles {
	my($re) = @_;
	if (not defined $installed_skipfiles_filter) {
		unshift @dirfilter, sub {
			grep (!/$skipfiles/, @_);
		};
		$installed_skipfiles_filter = 1;
	}
	push @skipfiles, $re;
	$skipfiles = join("|",map("($_)", @skipfiles));
}

sub findnode_byname {
	my($node, $name) = @_;
	
	$name =~ s!/+!/!g;
	
	if ($name =~ s!^/!!) {
		$node = $root;
	}
	
	$name =~ s!/+$!!;
	my($f,$mid,$r) = ($name =~ m!^(.*?)(/(.*))?$!);
	
	if ($f eq "..") {
		return findnode_byname($node->{parentdir}, $r);
	}
	
	foreach (@{$node->{dirlist}}) {
		if (length $f and $_->{name} eq $f) {
			return $_;
		}
		if (length $r and $_->{dirlist}) {
			my($found) = findnode_byname($_, $r);
			return $found if $found;
		}
	}
	undef;
	
}

sub record_checksum {
	my($pos,$len,$writepos) = @_;
	push @checksums, [$pos,$len,$writepos];
}

sub fixup {
	my($fixup) = @_;
	$fixup->{dir} = $::dir;
	push @fixups, $fixup;
}

sub do_checksums {
	foreach (@checksums) {
		#warn sprintf("Checksum of %d bytes at %d (writing to %d)\n", $_->[1], $_->[0], $_->[2]);
		$data = "";
		seek(STDOUT, $_->[0], 0) or die "$!";
		read(STDOUT, $data, $_->[1]);
		#warn "Read ".(length $data)." bytes\n";
		seek(STDOUT, $_->[2], 0) or die "$!";
		print pack("N", -romfs_checksum($data));
	}
}

sub do_fixups {
	foreach (@fixups) {
		next if not ref $_;
		if (not $_->{node}) {
			if ($_->{name}) {
				$_->{node} = findnode_byname($_->{dir}, $_->{name});
				if (not defined $_->{node}) {
					warn "Unable to find file '$_->{name}' during relocations\n";
					next;
				}
			}
			if (not $_->{node}) {
				warn "Nodeless relocation skipped\n";
				next;
			}
		}
		my($data);
		$_->{node}->{filepos} = $_->{node}->{offset} + hdrspaceneeded($_->{node});

		$_->{node}->{filepos} += $BASE;

		if (not defined $_->{data}) {
			$_->{data} = &{$_->{code}}($_);
		}
		
		$_->{node}->{filepos} -= $BASE;
		
		if (defined $_->{pos} and defined $_->{data}) {
			seek(STDOUT, $_->{pos}+$_->{node}->{filepos}, 0);
			print $_->{data};
		}
	}
}

sub shownode {
	my($level,$node) = @_;
	printf STDERR "%-4d %-20s [0x%-8x, 0x%-8x] %07o, sz %5u, at 0x%-6x", 
		$level,
		$node->{name},
		$node->{ondev},
		$node->{onino},
		$node->{modes},
		$node->{size},
		$node->{offset};
	if ($node->{orig_link}) {
		printf STDERR " [link to 0x%-6x]", $node->{orig_link}->{offset};
	}
	printf STDERR "\n";
	foreach (@{$node->{dirlist}}) {
		shownode($level+1, $_);
	}
}

sub romfs_checksum {
	my($data) = @_;
	my($i,$sum);
	for($i=0;$i<(length($data)-3);$i+=4) {
		$sum += unpack("N",substr($data,$i,4));
	}
	$sum;
}

sub findnode {
	my($node, $dev, $ino) = @_;
	
	if ($node->{ondev} == $dev and $node->{onino} == $ino) {
		return $node;
	}
	
	foreach (@{$node->{dirlist}}) {
		my($found) = findnode($_, $dev, $ino);
		return $found if $found;
	}
	undef;
}

sub ALIGNUP16 { ($_[0] + 15) & ~15 };

sub spaceneeded {
	my($node) = @_;
	16 + ALIGNUP16(length($node->{name}) + 1) + ALIGNUP16($node->{size});
}

sub hdrspaceneeded {
	my($node) = @_;
	16 + ALIGNUP16(length($node->{name}) + 1);
}

sub ST_DEV {0};
sub ST_INO {1};
sub ST_MODE {2};
sub ST_NLINK {3};
sub ST_UID {4};
sub ST_GID {5};
sub ST_RDEV {6};
sub ST_SIZE {7};

sub S_IFMT   {00170000}
sub S_IFSOCK {0140000}
sub S_IFLNK  {0120000}
sub S_IFREG  {0100000}
sub S_IFBLK  {0060000}
sub S_IFDIR  {0040000}
sub S_IFCHR  {0020000}
sub S_IFIFO  {0010000}
sub S_ISUID  {0004000}
sub S_ISGID  {0002000}
sub S_ISVTX  {0001000}

sub S_ISLNK { ($_[0] & S_IFMT) == S_IFLNK }
sub S_ISREG { ($_[0] & S_IFMT) == S_IFREG }
sub S_ISDIR { ($_[0] & S_IFMT) == S_IFDIR }
sub S_ISCHR { ($_[0] & S_IFMT) == S_IFCHR }
sub S_ISBLK { ($_[0] & S_IFMT) == S_IFBLK }
sub S_ISFIFO { ($_[0] & S_IFMT) == S_IFFIFO }
sub S_ISSOCK { ($_[0] & S_IFMT) == S_IFSOCK }

$dirsym = "DIR0000";

sub processdir {
	my($level, $base, $dirname, $dir, $root, $curroffset) = @_;
	my($dirfd, $dp, $link, $n, @stat);
	my(@dir);
	local(@afterdir) = ();
	my(%skip) = ();
	
	if ($level <= 1) {
		$link = newnode($base, ".", $curroffset);
		if (@stat = lstat($link->{realname})) {
			setnode($link, $stat[ST_DEV], $stat[ST_INO], $stat[ST_MODE]);
			if ($dir->{dirlist}->[-1]) {
				$dir->{dirlist}->[-1]->{next} = $link;
			}
			push @{$dir->{dirlist}}, $link;
			$list->{parentdir} = $dir;
			$curroffset += spaceneeded($link);
			$n = newnode($base, "..", $curroffset);
			if (@stat = lstat($link->{realname})) {
				setnode($n, $stat[ST_DEV], $stat[ST_INO], $stat[ST_MODE]);
				if ($dir->{dirlist}->[-1]) {
					$dir->{dirlist}->[-1]->{next} = $n;
				}
				push @{$dir->{dirlist}}, $n;
				$n->{parentdir} = $dir;
				$n->{orig_link} = $link;
				$curroffset += spaceneeded($n);
			}
		}
	}
	
	$dirfd = $dirsym++;
	opendir($dirfd, $dir->{realname});
	
	@dir = readdir($dirfd);
	closedir($dirfd);

refilter:
	foreach (@dirfilter) {
		@dir = &{$_}(@dir);
	}
	
	# Process entire dir, looking for command files
	
	foreach (@dir) {
		if (!$skip{$_} and -f "$base/$_") {
			open(FD,"<$base/$_");
			$data = "";
			read(FD, $data, 16);
			if ($data eq "#!/bin/genromfs\n") {
				close(FD);

				$skip{$_} = 1;
				
				$::level = $level;
				$::base = $base;
				$::dirname = $dirname;
				$::dir = $dir;
				$::root = $root;
				$::curroffset = $curroffset;
				
				do "$base/$_";
				if ($@) {
					die $@; 
				}
				
				$curroffset = $::curroffset;
				
				goto refilter;
			}
		}
	}
	

file:
	foreach $dp (@dir) {
		next if $skip{$dp};
		if ($level <= 1 and ($dp eq "." or $dp eq "..")) {
			next;
		}
		$n = newnode($base, $dp, $curroffset);
		if (not (@stat = lstat($n->{realname}))) {
			printf STDERR "ignoring '%s' (lstat failed)\n", $n->{realname};
			freenode($n);
			next;
		}
		setnode($n, $stat[ST_DEV], $stat[ST_INO], $stat[ST_MODE]);
		if (!S_ISLNK($n->{modes}) and !-r $n->{realname}) {
			printf STDERR "ignoring '%s' (access failed)\n", $n->{realname};
			freenode($n);
			next;
		}
		foreach (@filter) {
			if (not &{$_}($n)) {
				next file;
			}
		}
		$link = findnode($root, $n->{ondev}, $n->{onino});
		if ($dir->{dirlist}->[-1]) {
			$dir->{dirlist}->[-1]->{next} = $n;
		}
		push @{$dir->{dirlist}}, $n;
		$n->{parentdir} = $dir;
		if ($link) {
			$n->{orig_link} = $link;
			$curroffset += spaceneeded($n);
			next;
		}
		if (S_ISREG($stat[ST_MODE])) {
			$n->{size} = $stat[ST_SIZE];
		}
		if (S_ISLNK($stat[ST_MODE])) {
			$n->{size} = $stat[ST_SIZE];
		}
		$curroffset += spaceneeded($n);
		if (S_ISCHR($stat[ST_MODE]) or S_ISBLK($stat[ST_MODE])) {
			$n->{devnode} = $stat[ST_RDEV];
		}
		if (S_ISDIR($stat[ST_MODE])) {
			$curroffset = processdir($level+1, $n->{realname}, $dp, $n, $root, $curroffset);
		}
	}
	
	foreach (@afterdir) {
		$::level = $level;
		$::base = $base;
		$::dirname = $dirname;
		$::dir = $dir;
		$::root = $root;
		$::curroffset = $curroffset;
		&{$_}();
		$curroffset = $::curroffset;
	}

	$curroffset;
}

sub fixsum {
	my($data, $size) = @_;
	$size = length $data unless defined $size;
	
	substr($$data, 12, 4) = "\0\0\0\0";
	substr($$data, 12, 4) = pack("N", -romfs_checksum($$data));
	
	$data;
}

sub dumpri {
	my ($ri, $node) = @_;
	my($len) = length($node->{name})+1;
	
	$buf = pack("NNNN", $ri->{nextfh}, $ri->{spec}, $ri->{size}, $ri->{checksum});
	
	$buf .= $node->{name} . "\0";
	
	if ($len & 15) {
		$buf .= "\0" x (16 - ($len % 15));
		$len += (16 - ($len % 15));
	}
	
	$len += 16;
	
	if ($node->{offset}) {
#		warn "Would want checksum of $len bytes at $node->{offset}\n";
#		fixsum(\$buf, $len); 
	}
	#$ri->{checksum} = unpack("N", substr($buf, 12, 4));
	
	dumpdata($buf);



#   printf STDERR "RI: [at %06x] %08lx, %08lx, %08lx, %08lx [%s]\n",
#   					$node->{offset},
#   					$ri->{nextfh},
#   					$ri->{spec},
#   					$ri->{size},
#   					$ri->{checksum},
#   					$node->{name};
	                                                                        
}

sub ROMFH_HRD {0};
sub ROMFH_DIR {1};
sub ROMFH_REG {2};
sub ROMFH_LNK {3};
sub ROMFH_BLK {4};
sub ROMFH_CHR {5};
sub ROMFH_SCK {6};
sub ROMFH_FIF {7};
sub ROMFH_EXEC {8};

$atoffs = 0;
$header = "";

sub dumpdata {
	my($data) = @_;
	my($len) = length $data;
	return if not length $data;
	
#	if ($atoffs < 512) {
#		$header .= $data;
#		$atoffs += $len;
#		
#		if ($atoffs<512) {
#			return;
#		}
#
#		$data = substr($header,512);
#		$len = length $data;
#		
#		$header = substr($header, 0, 512);
#		
#		warn "Wanted checksum of ".($lastoff > 512 ? 512 : $lastoff)." bytes at 0\n";
#		fixsum(\$header, );
#		
#		print $header;
#		
#	}
	
	print $data;
	$atoffs += $len;
	return;
}

sub dumpzero {
	my($len) = @_;
	dumpdata("\0" x $len);
}

sub dumpdataa {
	my($data) = @_;
	my($len) = length $data;
	dumpdata($data);
	if ($len & 15) {
		dumpzero(16-($len & 15));
	}
} 

sub dumpstring {
	my($string) = @_;
	dumpdata($string . "\0");
}

sub major { $_[0] >> 8; }
sub minor { $_[0] & 0xff; }

sub dumpnode {
	my($node) = @_;
	my($ri) = { nextfh => 0, spec => 0, size => $node->{size}, checksum => 0 }; #0x55555555 };
	if ($node->{next}) { # and $node->{next}->{next}) {
		$ri->{nextfh} = $node->{next}->{offset};
	}
	if ($node->{modes} & 0111 and (S_ISDIR($node->{modes}) or S_ISREG($node->{modes}))) {
		$ri->{nextfh} |= ROMFH_EXEC;
	}
	
	if ($node->{orig_link}) {
		$ri->{nextfh} |= ROMFH_HRD;
		$ri->{nextfh} &= ~ROMFH_EXEC;
		$ri->{spec} = $node->{orig_link}->{offset};
		dumpri($ri, $node);
	} elsif (S_ISDIR($node->{modes})) {
		$ri->{nextfh} |= ROMFH_DIR;
		if (!@{$node->{dirlist}}) {
			$ri->{spec} = $node->{offset};
		} else {
			$ri->{spec} = $node->{dirlist}->[0]->{offset};
		}
		dumpri($ri, $node);
	} elsif (S_ISLNK($node->{modes})) {
		$ri->{nextfh} |= ROMFH_LNK;
		dumpri($ri, $node);
		dumpdataa(readlink($node->{realname}));
	} elsif (S_ISREG($node->{modes})) {
		my($offset, $max, $len, $avail);
		$ri->{nextfh} |= ROMFH_REG;
		dumpri($ri, $node);
		$offset = 0;
		$max = $node->{size};
		if ($node->{contents}) {
			$offset += dumpdata(&{$node->{contents}}($node));
		} else {
			open(FD, "<$node->{realname}") or die "Unable to open $node->{realname}: $!";
			while ($offset < $max) {
				$buf = "";
				$avail = $max - $offset < 4096 ? $max-$offset : 4096;
				read(FD, $buf, $avail) or warn "Tryied to read $avail: $!";
				dumpdata($buf);
				$offset += length $buf;
			}
		}
		$max = ($max+15)&~15;
		if ($offset < $max) {
			dumpzero($max-$offset);
		}
	} elsif (S_ISCHR($node->{modes})) {
		$ri->{nextfh} |= ROMFH_CHR;
		$ri->{spec} = (major($node->{devnode}) << 16) | minor($node->{devnode});
		dumpri($ri, $node);
	} elsif (S_ISBLK($node->{modes})) {
		$ri->{nextfh} |= ROMFH_BLK;
		$ri->{spec} = (major($node->{devnode}) << 16) | minor($node->{devnode});
		dumpri($ri, $node);
	} elsif (S_ISFIFO($node->{modes})) {
		$ri->{nextfh} |= ROMFH_FIF;
		dumpri($ri, $node);
	} elsif (S_ISSOCK($node->{modes})) {
		$ri->{nextfh} |= ROMFH_SCK;
		dumpri($ri, $node);
	}
	
	record_checksum($node->{offset}, hdrspaceneeded($node) > 512 ? 512 : hdrspaceneeded($node), $node->{offset}+12);
	
	foreach (@{$node->{dirlist}}) {
		dumpnode($_);
	}
	
}

sub dumpall {
	my ($node, $lastoff) = @_;
	
	my ($ri) = {
		nextfh => 0x2d726f6d,
		spec => 0x3166732d,
		size => $lastoff,
		checksum => 0 #0x55555555
	};
	
	dumpri($ri, $node);
	
	foreach (@{$node->{dirlist}}) {
		dumpnode($_);
	}
	
	if ($lastoff & 1023) {
		dumpzero (1024-($lastoff & 1023));
	}
}

sub freenode {
	my ($node) = @_;
}

sub setnode {
	my ($node, $dev, $ino, $um) = @_;
	$node->{ondev} = $dev;
	$node->{onino} = $ino;
	$node->{modes} = $um;
}

sub newnode {
	my($base, $name, $offset) = @_;
	my($realname);
	if ($offset) {
		$realname = "$base/$name";
	} else {
		$realname = "$base/.";
	}
	
	{
		name => $name,
		realname => $realname,
		next => undef,
		prev => undef,
		ondev => -1,
		onino => -1,
		modes => -1,
		size => 0,
		devnode => 0,
		orig_link => undef,
		offset => $offset,
		dirlist => []
	};
}

sub showhelp {
	print <<"EOT";
Usage: $0 [OPTIONS] -f IMAGE
Create a romfs filesystem image from a directory

  -f IMAGE               Output the image into this file
  -d DIRECTORY           Use this directory as source
  -D VAR=DEFINITION      Define variable
  -s SCRIPTFILE          Execute script before processing directory
  -v                     (Too) verbose operation
  -V VOLUME              Use the specified volume name
  -h                     Show this help

Report bugs to chexum\@shadow.banki.hu
EOT
}

use Getopt::Std;

sub main {
	if ( !getopts('d:f:V:vhs:D:', \%opts) or $opts{h} or not $opts{f} or not $opts{d} or @ARGV) {
		showhelp;
		exit;
	}
	
	if ($opts{D}) {
		if ($opts{D} =~ /=/) {
			my($name,$val) = ($`,$');
			$val = oct($val) if $val =~ /^0/;
			${$name} = $val;
		}
	}
	
	if ($opts{s}) {
		do $opts{s};
		if ($@) {
			die $@;
		}
	}
	
	open(STDOUT,"+>$opts{f}") if $opts{f};
	
	seek(STDOUT, 0, 0) or die "Output must be file, not pipe\n";
	
	$root = newnode($opts{d}, $opts{V}, 0);
	$lastoff = processdir (1, $opts{d}, $opts{d}, $root, $root, spaceneeded($root));

	shownode(0, $root) if $opts{v};
	dumpall($root, $lastoff);

	record_checksum 0, $lastoff > 512 ? 512 : $lastoff, 12;

	close(STDOUT);
	open(STDOUT,"+<$opts{f}") if $opts{f};

	
#	fixsum(\$header, 512 < $root->{size} ? 512 : $root->{size});
	
	seek(STDOUT, 0, 0);
	
	#print $header;

	foreach (@finish) {
		seek(STDOUT, 0, 0);
		&{$_}($root, $lastoff);
	}
	
}
main;
