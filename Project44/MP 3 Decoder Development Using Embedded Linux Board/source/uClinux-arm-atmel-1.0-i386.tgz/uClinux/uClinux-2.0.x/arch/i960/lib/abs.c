/*
 *   FILE: abs.c
 * AUTHOR: kma
 *  DESCR: absolute value; we need this
 */

#ident "abs.c,v 1.1.1.1 1999/05/25 19:41:03 jeff Exp"

int abs(int j)
{
	return (j<0)? -j : j;
}
