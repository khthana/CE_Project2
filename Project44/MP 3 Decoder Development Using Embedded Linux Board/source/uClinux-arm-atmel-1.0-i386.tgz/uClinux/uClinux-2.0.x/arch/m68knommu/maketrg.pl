
# Turn raw binary image into TRG flashloader image (by chopping off first
# 64K, and padding to 64K in length.)

open(T,"<vmlinux.bin");
open(O,">vmlinux.trg");
seek(T,64*1024,0);
while($l=read(T,$block,64*1024))
{
	if ($l<(64*1024)) {
		$block .= "\0" x ((64*1024)-$l);
	}
	print O $block;
}
	
