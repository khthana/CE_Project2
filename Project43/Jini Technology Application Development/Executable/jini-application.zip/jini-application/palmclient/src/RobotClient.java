import com.sun.kjava.*;
import java.io.*;
import javax.microedition.io.*;
import java.lang.Thread;

public class RobotClient extends Spotlet implements Runnable
{
	private Button exitButton;
	private Button connectButton;
	private Button disconnectButton;
	private Button forward;
	private Button backward;
	private Button left;
	private Button right;
	private Button stop;
	private Button status;
	private Button fire;
	private Button f1;
	private Button f2;
	private Button f3;
	private Button f4;
	private Button findServiceButton;
	
	private ScrollTextBox showText;
	private String textBuffer = new String();

	private boolean isConnect = false;
	private String statusMessage = new String();

    DataInputStream in;
    DataOutputStream out;
    StreamConnection socket = null;

	static Graphics g = Graphics.getGraphics();
	private Runtime runtime = Runtime.getRuntime();
	private Thread myThread;

	public static void main(String[] args) {
		RobotClient client = new RobotClient();
		client.register(NO_EVENT_OPTIONS);
	}

	public void run(){
		String request = new String();
		connect();
		while(isConnect){
			try{
				request = in.readUTF();
				if(request.charAt(0) == '#'){
					setStatus(request.substring(1));
				}else 
				if(request.charAt(0) == '@'){
					showText.setText("");
					textBuffer = "";
					append(request.substring(1));
				}else
				append(request);
			}
			catch(IOException ioe){
				setStatus("Error: receive data.");
				System.exit(1);
			}
		}
	}

	public RobotClient(){
		
		myThread = new Thread(this);
		// up arrow bitmap
		byte[] up = {
			(byte)0, (byte)0, (byte)1, (byte)128, 
			(byte)3, (byte)192, (byte)7, (byte)224, (byte)15, 
			(byte)240, (byte)31, (byte)248, (byte)63, (byte)252, 
			(byte)127, (byte)254, (byte)0, (byte)0
		};
		forward = new Button(new Bitmap((short)2, up), 40, 10);
		up = null;
		runtime.gc();
		
		// down arrow bitmap
		byte[] down = {
			(byte)0, (byte)0, (byte)127, (byte)254, 
			(byte)63, (byte)252, (byte)31, (byte)248, (byte)15, 
			(byte)240, (byte)7, (byte)224, (byte)3, (byte)192, 
			(byte)1, (byte)128, (byte)0, (byte)0
		};
		backward = new Button(new Bitmap((short)2, down), 40, 40);
		down = null;
		runtime.gc();
		
		// right arrow bitmap
		byte[] rturn = {
			(byte)0, (byte)0, (byte)96, (byte)0, 
			(byte)126, (byte)0, (byte)127, (byte)224, (byte)127, 
			(byte)254, (byte)127, (byte)224, (byte)126, (byte)0, 
			(byte)96, (byte)0, (byte)0, (byte)0
		};
		right = new Button(new Bitmap((short)2, rturn), 65, 25);
		rturn = null;
		runtime.gc();
		
		// left arrow bitmap
		byte[] lturn = {
			(byte)0, (byte)0, (byte)0, (byte)6, 
			(byte)0, (byte)126, (byte)7, (byte)254, (byte)127, 
			(byte)254, (byte)7, (byte)254, (byte)0, (byte)126, 
			(byte)0, (byte)6, (byte)0, (byte)0
		};
		left = new Button(new Bitmap((short)2, lturn), 15, 25);
		lturn = null;
		runtime.gc();
		
		// stop circle bitmap
		byte[] halt = {
			(byte)0, (byte)0, (byte)3, (byte)192, 
			(byte)31, (byte)248, (byte)63, (byte)252, (byte)63, 
			(byte)252, (byte)63, (byte)252, (byte)31, (byte)248, 
			(byte)3, (byte)192, (byte)0, (byte)0
		};
		stop = new Button(new Bitmap((short)2, halt), 40, 25);
		halt = null;
		runtime.gc();
		
		// status query bitmap
		byte[] why = {
			(byte)0, (byte)0, (byte)3, (byte)192, (byte)6, 
			(byte)96, (byte)0, (byte)192, (byte)1, (byte)128, (byte)1, 
			(byte)128, (byte)0, (byte)0, (byte)1, (byte)128, (byte)0, (byte)0
		};
		status = new Button(new Bitmap((short)2, why), 65, 50);
		why = null;
		runtime.gc();
		
		// fire bang bitmap
		byte[] bang = {
			(byte)  0, (byte)  0, (byte)  1, (byte)128, (byte)  1, 
			(byte)128, (byte)  1, (byte)128, (byte)  1, (byte)128, (byte)  1, 
			(byte)128, (byte)  0, (byte)  0, (byte)  1, (byte)128, (byte)  0, (byte)0
		};
		fire = new Button(new Bitmap((short)2, bang), 15, 50);
		bang = null;
		runtime.gc();
		
		f1 = new Button(" 1 ",15,63);
		f2 = new Button(" 2 ",32,63);
		f3 = new Button(" 3 ",49,63);
		f4 = new Button(" 4 ",66,63);
		
		connectButton = new Button("     Connect     ", 95, 9);
		disconnectButton = new Button("  Disconnect  ", 95, 28);
		exitButton = new Button("         Exit         ", 95, 46);
		disconnectButton.setEnabled(false);
		findServiceButton = new Button(" Find Service ",95,63);
		findServiceButton.setEnabled(false);
		showText = new ScrollTextBox("",10,85,140,50);

		g.clearScreen();
		paint();
	}

	/** redraw the GUI */
	private void paint() {
		g.resetDrawRegion();
		//g.drawBorder(1, 1, 140, 133, Graphics.PLAIN, Graphics.SIMPLE);
		//g.drawRectangle(0, 140, 160, 20, Graphics.ERASE, 0);
		g.drawBorder(5, 5, 150, 150, Graphics.PLAIN, Graphics.RAISED);
		g.drawLine(5,80,155,80,Graphics.PLAIN);
		g.drawLine(5,140,155,140,Graphics.PLAIN);
		exitButton.paint();
		connectButton.paint();
		disconnectButton.paint();
		forward.paint();
		backward.paint();
		left.paint();
		right.paint();
		stop.paint();
		status.paint();
		fire.paint();
		f1.paint();
		f2.paint();
		f3.paint();
		f4.paint();
		findServiceButton.paint();
		showText.paint();
		g.drawBorder(8,84,144,53, Graphics.PLAIN, Graphics.SIMPLE);
		this.displayStatus();
		g.setDrawRegion(1, 1, 159, 133);
	}

	private void displayStatus() {
		int mXpoint = 10;
		int mYpoint = 143;
		g.drawRectangle(10, 142, 145, 10, Graphics.ERASE, 0);
		g.drawString("Status: "+statusMessage, mXpoint, mYpoint);
	}

	public void sendMessage(String message){
		try{
			out.writeUTF(message);
		}
		catch(IOException ioe){
			setStatus("Error Send data to Server");
		}
	}

	public void append(String text){
		if (showText.getNumLines() >= 5){
			textBuffer = "";
		}
		textBuffer = textBuffer+text+"\n";
		showText.setText(textBuffer);
		showText.paint();
	}

	public void setStatus(String s){
		statusMessage = s;
		paint();
	}
	
	public void connect(){
		//Create Socket to Daemon
		try{
			socket = (StreamConnection)Connector.open("socket://localhost:1234",Connector.READ_WRITE,true);
			in = new DataInputStream(socket.openInputStream());
			out = new DataOutputStream(socket.openOutputStream());
			isConnect = true;
			findServiceButton.setEnabled(true);
			setStatus("Connection Establish");
		}
		catch(Exception e){
			isConnect = false;
			setStatus("Can't create connection");
			disconnectButton.setEnabled(false);
			connectButton.setEnabled(true);
			findServiceButton.setEnabled(false);
		}
		
	}

	public void disconnect(){
		try{
			socket.close();
			in.close();
			out.close();
			in = null;
			out = null;
			socket = null;
			setStatus("Disconnect from server");
			showText.setText("");
			isConnect = false;
			runtime.gc();
		} catch(IOException ioe){
			setStatus("Can't Disconnect from server");
		}
		
	}

	public void penDown(int x, int y) {
		String cmd = null;
		byte repSly;
		byte newline;

		runtime.gc();
		if (exitButton.pressed(x, y)) {
			if (isConnect == true){
				disconnect();
			}
			System.exit(1);
		}
		else if (connectButton.pressed(x,y)){
			//Start listen on port 1234
			myThread.start();
			connectButton.setEnabled(false);
			disconnectButton.setEnabled(true);
			paint();
			isConnect = true;
		}
		else if (disconnectButton.pressed(x,y)){
			this.disconnect();
			connectButton.setEnabled(true);
			disconnectButton.setEnabled(false);
			paint();
		}
		// user wants to scroll text
		else if (showText.contains(x,y)) {
			showText.handlePenDown(x,y);
		}
		else if (forward.pressed(x, y)) {
			sendMessage("forward");
		}
		else if (backward.pressed(x, y)){
			sendMessage("backward");
		}
		else if (left.pressed(x, y)){
			sendMessage("left");
		}
		else if (right.pressed(x, y)){
			sendMessage("right");
		}
		else if (stop.pressed(x, y)){
			sendMessage("stop");
		}
		else if (status.pressed(x, y)){
			sendMessage("turn off");
		}
		else if (fire.pressed(x, y)){
			sendMessage("turn on");
		}
		else if (f1.pressed(x, y)){
			sendMessage("1");
		}
		else if (f2.pressed(x, y)){
			sendMessage("2");
		}
		else if (f3.pressed(x, y)){
			sendMessage("3");
		}
		else if (f4.pressed(x, y)){
			sendMessage("4");
		}
		else if (findServiceButton.pressed(x, y)){
			sendMessage("find service");
		}
		if (cmd == null) return ;
	}
}