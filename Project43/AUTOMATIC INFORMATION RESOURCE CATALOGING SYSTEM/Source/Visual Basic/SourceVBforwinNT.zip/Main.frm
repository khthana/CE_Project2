VERSION 5.00
Begin VB.Form Main 
   BackColor       =   &H8000000E&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BookCode Management Program"
   ClientHeight    =   6105
   ClientLeft      =   570
   ClientTop       =   1695
   ClientWidth     =   8820
   Icon            =   "Main.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6105
   ScaleWidth      =   8820
   StartUpPosition =   2  'CenterScreen
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   6
      Left            =   480
      Picture         =   "Main.frx":110A
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "�͡�ҡ��÷ӧҹ�ͧ�����"
      DragIcon        =   "Main.frx":298C
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   4
      Left            =   3120
      TabIndex        =   4
      Top             =   5280
      Width           =   3375
   End
   Begin VB.Image Image2 
      Height          =   1350
      Left            =   120
      Picture         =   "Main.frx":2C96
      Top             =   360
      Width           =   8760
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   5
      Left            =   480
      Picture         =   "Main.frx":75F7
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   4
      Left            =   480
      Picture         =   "Main.frx":A932
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   3
      Left            =   480
      Picture         =   "Main.frx":BB6C
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   2
      Left            =   480
      Picture         =   "Main.frx":D82C
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   1
      Left            =   480
      Picture         =   "Main.frx":E11D
      Stretch         =   -1  'True
      Top             =   2280
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   0
      Left            =   480
      Picture         =   "Main.frx":FA1C
      Stretch         =   -1  'True
      Top             =   2280
      Width           =   2325
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "������Ѵ�������ª���˹ѧ��� �������"
      DragIcon        =   "Main.frx":1129E
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   3
      Left            =   3120
      TabIndex        =   3
      Top             =   4500
      Width           =   4095
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "�������èѴ��â����ŵ���к� Marc format"
      DragIcon        =   "Main.frx":115A8
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   2
      Left            =   3120
      TabIndex        =   2
      Top             =   3720
      Width           =   5175
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "�������èѴ����������ͧ˹ѧ���"
      DragIcon        =   "Main.frx":118B2
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   1
      Left            =   3120
      TabIndex        =   1
      Top             =   2940
      Width           =   3495
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      BackStyle       =   0  'Transparent
      Caption         =   "�������èѴ����Ţ�����˹ѧ���"
      DragIcon        =   "Main.frx":11BBC
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   0
      Left            =   3120
      TabIndex        =   0
      Top             =   2160
      Width           =   3735
   End
End
Attribute VB_Name = "Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Label1_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If Source Is Label1(Index) Then
        With Label1(Index)
            .Font.Underline = False
            .ForeColor = vbBlack
            Screen.MousePointer = vbHourglass
            
            Select Case Index
            Case 0
                Main.Visible = False
                AuthorMenu.Show
            Case 1
                Main.Visible = False
                HeaderMenu.Show
            Case 2
               Main.Visible = False
               MarcMenu.Show
            Case 3
                Main.Visible = False
                PrintMenu.Show
            Case 4
               End
            
            End Select
            Screen.MousePointer = vbNormal
        End With
    End If
End Sub

Private Sub Label1_DragOver(Index As Integer, Source As Control, X As Single, Y As Single, State As Integer)
If State = vbLeave Then
        With Label1(Index)
            .Drag vbEndDrag
            .Font.Underline = False
            .ForeColor = vbBlack
            Image1(0).Picture = Image1(6).Picture
         
        End With
    End If

End Sub

Private Sub Label1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
With Label1(Index)
        .ForeColor = vbBlue
        .Font.Underline = True
        .Drag vbBeginDrag
        Image1(0).Picture = Image1(Index + 1).Picture

    End With
  
End Sub

