VERSION 5.00
Begin VB.Form printing 
   Caption         =   "printing"
   ClientHeight    =   6015
   ClientLeft      =   -1530
   ClientTop       =   1575
   ClientWidth     =   9840
   Icon            =   "print.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6015
   ScaleWidth      =   9840
   WindowState     =   2  'Maximized
   Begin VB.Frame Frame1 
      Caption         =   "���͡�����Ũҡ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1815
      Left            =   1080
      TabIndex        =   6
      Top             =   360
      Width           =   3615
      Begin VB.OptionButton Option2 
         Caption         =   "���͡�ҡ�Ţ����¹"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   14.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   8
         Top             =   1080
         Width           =   3135
      End
      Begin VB.OptionButton Option1 
         Caption         =   "���͡�ҡ�Ţ ISBN"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   14.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   7
         Top             =   480
         Width           =   3135
      End
   End
   Begin VB.CommandButton Command4 
      Caption         =   "clear"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8280
      TabIndex        =   5
      Top             =   1560
      Width           =   1095
   End
   Begin VB.CommandButton Command3 
      Caption         =   "���͡"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6120
      TabIndex        =   4
      Top             =   1560
      Width           =   1095
   End
   Begin VB.ComboBox cmbIDpr 
      Height          =   315
      Left            =   6240
      TabIndex        =   3
      Text            =   "Combo1"
      Top             =   720
      Width           =   2295
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Cancel"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1080
      TabIndex        =   2
      Top             =   5400
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Print"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1080
      TabIndex        =   1
      Top             =   3840
      Width           =   1695
   End
   Begin VB.TextBox Text1 
      Height          =   5655
      Left            =   3240
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Top             =   2520
      Width           =   8055
   End
End
Attribute VB_Name = "printing"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public tmp As String
Public tmp1 As String
Public myprinter As Printer
Public marcdbpr As Database
Public marcwspr As Workspace
Public Rectagdatapr1 As Recordset
Public Rectagdatapr2 As Recordset

Private Sub Command1_Click()
Printer.ScaleMode = 1
Printer.Font.Name = "MS Sans Serif"
Printer.Font.Size = 16
Printer.Print tmp
Printer.EndDoc
End Sub

Private Sub Command2_Click()
tmp = ""
Unload Me
End Sub

Private Sub Command3_Click()
Dim ISBN As String
If cmbIDpr.Text <> "" Then
Set Rectagdatapr1 = marcdbpr.OpenRecordset("Select * from tagdata1", dbOpenDynaset)
Set Rectagdatapr2 = marcdbpr.OpenRecordset("Select * from tagdata2", dbOpenDynaset)
Rectagdatapr1.MoveFirst
Rectagdatapr2.MoveFirst
If Option1.Value Then
Do While Rectagdatapr1.Fields("t020_1") <> cmbIDpr.Text
  Rectagdatapr1.MoveNext
  If Rectagdatapr1.EOF Then
 MsgBox ("��辺�����ź��ҹ������")
 GoTo ex  ' exit
 End If
Loop

Do While Rectagdatapr2.Fields("t020_1") <> cmbIDpr.Text
  Rectagdatapr2.MoveNext
Loop
Else
Do While Rectagdatapr1.Fields("book_no") <> cmbIDpr.Text
  Rectagdatapr1.MoveNext
  If Rectagdatapr1.EOF Then
 MsgBox ("��辺�����ź��ҹ������")
 GoTo ex  ' exit
End If

Loop

ISBN = Rectagdatapr1.Fields("t020_1")
Do While Rectagdatapr2.Fields("t020_1") <> ISBN
  Rectagdatapr2.MoveNext
Loop
End If

'************ show data in text box *************
'********* tag020 **********
If Rectagdatapr1.Fields("t020_1") <> " " Or Rectagdatapr1.Fields("t020_2") <> " " Or Rectagdatapr1.Fields("t020_3") <> " " Then tmp = tmp & "020  "
If Rectagdatapr1.Fields("t020_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t020_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t020_1")
If Rectagdatapr1.Fields("t020_2") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t020_2")
If Rectagdatapr1.Fields("t020_3") <> " " Then tmp = tmp & "| z " & Rectagdatapr1.Fields("t020_3")
'*********tag022**********
If Rectagdatapr1.Fields("t022_1") <> " " Or Rectagdatapr1.Fields("t022_2") <> " " Or Rectagdatapr1.Fields("t022_3") <> " " Then tmp = tmp & vbCrLf & "022  "
If Rectagdatapr1.Fields("i022") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i022") & "  "
If Rectagdatapr1.Fields("t022_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t022_1")
If Rectagdatapr1.Fields("t022_2") <> " " Then tmp = tmp & "| y " & Rectagdatapr1.Fields("t022_2")
If Rectagdatapr1.Fields("t022_3") <> " " Then tmp = tmp & "| z " & Rectagdatapr1.Fields("t022_3")
'********tag090***********
If Rectagdatapr1.Fields("t090_1") <> " " Or Rectagdatapr1.Fields("t090_2") <> " " Or Rectagdatapr1.Fields("t090_3") <> " " Then tmp = tmp & vbCrLf & "090  "
If Rectagdatapr1.Fields("t090_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t090_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t090_1")
If Rectagdatapr1.Fields("t090_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t090_2")
If Rectagdatapr1.Fields("t090_3") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t090_3")
'********tag099***********
If Rectagdatapr1.Fields("t099_1") <> " " Or Rectagdatapr1.Fields("t099_2") <> " " Or Rectagdatapr1.Fields("t099_3") <> " " Then tmp = tmp & vbCrLf & "090  "
If Rectagdatapr1.Fields("t099_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t099_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t099_1")
If Rectagdatapr1.Fields("t099_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t099_2")
If Rectagdatapr1.Fields("t099_3") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t099_3")
'********tag100***********
If Rectagdatapr1.Fields("t100_1") <> " " Or Rectagdatapr1.Fields("t100_2") <> " " Or Rectagdatapr1.Fields("t100_3") <> " " Then tmp = tmp & vbCrLf & "100  "
If Rectagdatapr1.Fields("i100") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i100") & "  "
If Rectagdatapr1.Fields("t100_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t100_1")
If Rectagdatapr1.Fields("t100_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t100_2")
If Rectagdatapr1.Fields("t100_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t100_3")
If Rectagdatapr1.Fields("t100_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t100_4")
If Rectagdatapr1.Fields("t100_5") <> " " Then tmp = tmp & "| q " & Rectagdatapr1.Fields("t100_5")
'********tag110***********
If Rectagdatapr1.Fields("t110_1") <> " " Or Rectagdatapr1.Fields("t110_2") <> " " Or Rectagdatapr1.Fields("t110_3") <> " " Then tmp = tmp & vbCrLf & "110  "
If Rectagdatapr1.Fields("i110") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i110") & "  "
If Rectagdatapr1.Fields("t110_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t110_1")
If Rectagdatapr1.Fields("t110_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t110_2")
If Rectagdatapr1.Fields("t110_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t110_3")
If Rectagdatapr1.Fields("t110_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t110_4")
If Rectagdatapr1.Fields("t110_5") <> " " Then tmp = tmp & "| g " & Rectagdatapr1.Fields("t110_5")
If Rectagdatapr1.Fields("t110_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t110_6")
'********tag111***********
If Rectagdatapr1.Fields("t111_1") <> " " Or Rectagdatapr1.Fields("t111_2") <> " " Or Rectagdatapr1.Fields("t111_3") <> " " Then tmp = tmp & vbCrLf & "111  "
If Rectagdatapr1.Fields("i111") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i111") & "  "
If Rectagdatapr1.Fields("t111_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t111_1")
If Rectagdatapr1.Fields("t111_2") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t111_2")
If Rectagdatapr1.Fields("t111_3") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t111_3")
If Rectagdatapr1.Fields("t111_4") <> " " Then tmp = tmp & "| e " & Rectagdatapr1.Fields("t111_4")
If Rectagdatapr1.Fields("t111_5") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t111_5")
If Rectagdatapr1.Fields("t111_6") <> " " Then tmp = tmp & "| q " & Rectagdatapr1.Fields("t111_6")
'********tag130***********
If Rectagdatapr1.Fields("t130_1") <> " " Or Rectagdatapr1.Fields("t130_2") <> " " Or Rectagdatapr1.Fields("t130_3") <> " " Then tmp = tmp & vbCrLf & "130  "
If Rectagdatapr1.Fields("i130") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i130") & "  "
If Rectagdatapr1.Fields("t130_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t130_1")
If Rectagdatapr1.Fields("t130_2") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t130_2")
If Rectagdatapr1.Fields("t130_3") <> " " Then tmp = tmp & "| f " & Rectagdatapr1.Fields("t130_3")
If Rectagdatapr1.Fields("t130_4") <> " " Then tmp = tmp & "| k " & Rectagdatapr1.Fields("t130_4")
If Rectagdatapr1.Fields("t130_5") <> " " Then tmp = tmp & "| l " & Rectagdatapr1.Fields("t130_5")
If Rectagdatapr1.Fields("t130_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t130_6")
If Rectagdatapr1.Fields("t130_7") <> " " Then tmp = tmp & "| p " & Rectagdatapr1.Fields("t130_7")
If Rectagdatapr1.Fields("t130_8") <> " " Then tmp = tmp & "| s " & Rectagdatapr1.Fields("t130_8")
'********tag210***********
If Rectagdatapr1.Fields("t210_1") <> " " Or Rectagdatapr1.Fields("t210_2") <> " " Then tmp = tmp & vbCrLf & "210  "
If Rectagdatapr1.Fields("i210") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i210") & "  "
If Rectagdatapr1.Fields("t210_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t210_1")
If Rectagdatapr1.Fields("t210_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t210_2")
'********tag240***********
If Rectagdatapr1.Fields("t240_1") <> " " Or Rectagdatapr1.Fields("t240_2") <> " " Then tmp = tmp & vbCrLf & "240  "
If Rectagdatapr1.Fields("i240") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i240") & "  "
If Rectagdatapr1.Fields("t240_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t240_1")
If Rectagdatapr1.Fields("t240_2") <> " " Then tmp = tmp & "| d " & Rectagdatapr1.Fields("t240_2")
If Rectagdatapr1.Fields("t240_3") <> " " Then tmp = tmp & "| f " & Rectagdatapr1.Fields("t240_3")
If Rectagdatapr1.Fields("t240_4") <> " " Then tmp = tmp & "| g " & Rectagdatapr1.Fields("t240_4")
If Rectagdatapr1.Fields("t240_5") <> " " Then tmp = tmp & "| k " & Rectagdatapr1.Fields("t240_5")
If Rectagdatapr1.Fields("t240_6") <> " " Then tmp = tmp & "| l " & Rectagdatapr1.Fields("t240_6")
If Rectagdatapr1.Fields("t240_7") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t240_7")
If Rectagdatapr1.Fields("t240_8") <> " " Then tmp = tmp & "| p " & Rectagdatapr1.Fields("t240_8")
If Rectagdatapr1.Fields("t240_9") <> " " Then tmp = tmp & "| s " & Rectagdatapr1.Fields("t240_9")
'********tag242***********
If Rectagdatapr1.Fields("t242_1") <> " " Or Rectagdatapr1.Fields("t242_2") <> " " Then tmp = tmp & vbCrLf & "242  "
If Rectagdatapr1.Fields("i242") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i242") & "  "
If Rectagdatapr1.Fields("t242_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t242_1")
If Rectagdatapr1.Fields("t242_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t242_2")
If Rectagdatapr1.Fields("t242_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t242_3")
If Rectagdatapr1.Fields("t242_4") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t242_4")
If Rectagdatapr1.Fields("t242_5") <> " " Then tmp = tmp & "| p " & Rectagdatapr1.Fields("t242_5")
If Rectagdatapr1.Fields("t242_6") <> " " Then tmp = tmp & "| y " & Rectagdatapr1.Fields("t242_6")
'********tag245***********
If Rectagdatapr1.Fields("t245_1") <> " " Or Rectagdatapr1.Fields("t245_2") <> " " Then tmp = tmp & vbCrLf & "245  "
If Rectagdatapr1.Fields("i245") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i245") & "  "
If Rectagdatapr1.Fields("t245_1") <> " " Then tmp1 = Rectagdatapr1.Fields("t245_1")
If Len(tmp1) > 35 Then
tmp1 = Left(tmp1, 35)
tmp1 = tmp1 & ". . ."
End If
If Rectagdatapr1.Fields("t245_1") <> " " Then tmp = tmp & "| a " & tmp1
If Rectagdatapr1.Fields("t245_2") <> " " Then tmp1 = Rectagdatapr1.Fields("t245_2")
If Len(tmp1) > 35 Then
tmp1 = Left(tmp1, 35)
tmp1 = tmp1 & ". . ."
End If
If Rectagdatapr1.Fields("t245_2") <> " " Then tmp = tmp & "| b " & tmp1
If Rectagdatapr1.Fields("t245_3") <> " " Then tmp1 = Rectagdatapr1.Fields("t245_3")
If Len(tmp1) > 35 Then
tmp1 = Left(tmp1, 35)
tmp1 = tmp1 & ". . ."
End If
If Rectagdatapr1.Fields("t245_3") <> " " Then tmp = tmp & "| c " & tmp1
If Rectagdatapr1.Fields("t245_4") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t245_4")
If Rectagdatapr1.Fields("t245_5") <> " " Then tmp = tmp & "| p " & Rectagdatapr1.Fields("t245_5")
If Rectagdatapr1.Fields("t245_6") <> " " Then tmp = tmp & "| s " & Rectagdatapr1.Fields("t245_6")
'********tag246***********
If Rectagdatapr1.Fields("t246_1") <> " " Or Rectagdatapr1.Fields("t246_2") <> " " Then tmp = tmp & vbCrLf & "246  "
If Rectagdatapr1.Fields("i246") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i246") & "  "
If Rectagdatapr1.Fields("t246_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t246_1")
If Rectagdatapr1.Fields("t246_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t246_2")
If Rectagdatapr1.Fields("t246_3") <> " " Then tmp = tmp & "| f " & Rectagdatapr1.Fields("t246_3")
If Rectagdatapr1.Fields("t246_4") <> " " Then tmp = tmp & "| g " & Rectagdatapr1.Fields("t246_4")
If Rectagdatapr1.Fields("t246_5") <> " " Then tmp = tmp & "| h " & Rectagdatapr1.Fields("t246_5")
If Rectagdatapr1.Fields("t246_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t246_6")
If Rectagdatapr1.Fields("t246_7") <> " " Then tmp = tmp & "| p " & Rectagdatapr1.Fields("t246_7")
'********tag250***********
If Rectagdatapr1.Fields("t250_1") <> " " Or Rectagdatapr1.Fields("t250_2") <> " " Then tmp = tmp & vbCrLf & "250  "
If Rectagdatapr1.Fields("t250_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t250_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t250_1")
If Rectagdatapr1.Fields("t250_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t250_2")
'********tag260***********
If Rectagdatapr1.Fields("t260_1") <> " " Or Rectagdatapr1.Fields("t260_2") <> " " Then tmp = tmp & vbCrLf & "260  "
If Rectagdatapr1.Fields("t260_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t260_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t260_1")
If Rectagdatapr1.Fields("t260_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t260_2")
If Rectagdatapr1.Fields("t260_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t260_3")
'***tag300***********
If Rectagdatapr1.Fields("t300_1") <> " " Or Rectagdatapr1.Fields("t300_2") <> " " Or Rectagdatapr1.Fields("t300_3") <> " " Then tmp = tmp & vbCrLf & "300  "
If Rectagdatapr1.Fields("t300_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t300_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t300_1")
If Rectagdatapr1.Fields("t300_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t300_2")
If Rectagdatapr1.Fields("t300_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t300_3")
If Rectagdatapr1.Fields("t300_4") <> " " Then tmp = tmp & "| e " & Rectagdatapr1.Fields("t300_4")
If Rectagdatapr1.Fields("t300_5") <> " " Then tmp = tmp & "| f " & Rectagdatapr1.Fields("t300_5")
If Rectagdatapr1.Fields("t300_6") <> " " Then tmp = tmp & "| g " & Rectagdatapr1.Fields("t300_6")
If Rectagdatapr1.Fields("t300_7") <> " " Then tmp = tmp & "| 3 " & Rectagdatapr1.Fields("t300_7")
'*******tag440***********
If Rectagdatapr1.Fields("t440_1") <> " " Or Rectagdatapr1.Fields("t440_2") <> " " Or Rectagdatapr1.Fields("t440_3") <> " " Then tmp = tmp & vbCrLf & "440  "
If Rectagdatapr1.Fields("i440") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i440") & "  "
If Rectagdatapr1.Fields("t440_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t440_1")
If Rectagdatapr1.Fields("t440_2") <> " " Then tmp = tmp & "| n " & Rectagdatapr1.Fields("t440_2")
If Rectagdatapr1.Fields("t440_3") <> " " Then tmp = tmp & "| p " & Rectagdatapr1.Fields("t440_3")
If Rectagdatapr1.Fields("t440_4") <> " " Then tmp = tmp & "| v " & Rectagdatapr1.Fields("t440_4")
If Rectagdatapr1.Fields("t440_5") <> " " Then tmp = tmp & "| x " & Rectagdatapr1.Fields("t440_5")
'*******tag490***********
If Rectagdatapr1.Fields("t490_1") <> " " Or Rectagdatapr1.Fields("t490_2") <> " " Then tmp = tmp & vbCrLf & "490  "
If Rectagdatapr1.Fields("i490") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i490") & "  "
If Rectagdatapr1.Fields("t490_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t490_1")
If Rectagdatapr1.Fields("t490_2") <> " " Then tmp = tmp & "| v " & Rectagdatapr1.Fields("t490_2")
'***tag500***********
If Rectagdatapr1.Fields("t500_1") <> " " Then tmp = tmp & vbCrLf & "500       | a " & Rectagdatapr1.Fields("t500_1")
'***tag501***********
If Rectagdatapr1.Fields("t501_1") <> " " Then tmp = tmp & vbCrLf & "501       | a " & Rectagdatapr1.Fields("t501_1")
'***tag502***********
If Rectagdatapr1.Fields("t502_1") <> " " Then tmp = tmp & vbCrLf & "502       | a " & Rectagdatapr1.Fields("t502_1")
'*******tag505***********
If Rectagdatapr1.Fields("t505_1") <> " " Or Rectagdatapr1.Fields("t505_2") <> " " Or Rectagdatapr1.Fields("t505_3") <> " " Then tmp = tmp & vbCrLf & "505  "
If Rectagdatapr1.Fields("i505") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i505") & "  "
If Rectagdatapr1.Fields("t505_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t505_1")
If Rectagdatapr1.Fields("t505_2") <> " " Then tmp = tmp & "| g " & Rectagdatapr1.Fields("t505_2")
If Rectagdatapr1.Fields("t505_3") <> " " Then tmp = tmp & "| r  " & Rectagdatapr1.Fields("t505_3")
'*******tag510***********
If Rectagdatapr1.Fields("t510_1") <> " " Or Rectagdatapr1.Fields("t510_2") <> " " Or Rectagdatapr1.Fields("t510_3") <> " " Then tmp = tmp & vbCrLf & "510  "
If Rectagdatapr1.Fields("i510") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i510") & "  "
If Rectagdatapr1.Fields("t510_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t510_1")
If Rectagdatapr1.Fields("t510_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t510_2")
If Rectagdatapr1.Fields("t510_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr1.Fields("t510_3")
If Rectagdatapr1.Fields("t510_4") <> " " Then tmp = tmp & "| x " & Rectagdatapr1.Fields("t510_4")
'*******tag520***********
If Rectagdatapr1.Fields("t520_1") <> " " Or Rectagdatapr1.Fields("t520_2") <> " " Or Rectagdatapr1.Fields("t520_3") <> " " Then tmp = tmp & vbCrLf & "520  "
If Rectagdatapr1.Fields("i520") <> " " Then tmp = tmp & Rectagdatapr1.Fields("i520") & "  "
If Rectagdatapr1.Fields("t520_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr1.Fields("t520_1")
If Rectagdatapr1.Fields("t520_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr1.Fields("t520_2")
If Rectagdatapr1.Fields("t520_3") <> " " Then tmp = tmp & "| 3 " & Rectagdatapr1.Fields("t520_3")
'*******tag536***********
If Rectagdatapr1.Fields("t536_1") <> " " Or Rectagdatapr1.Fields("t536_2") <> " " Or Rectagdatapr1.Fields("t536_3") <> " " Then tmp = tmp & vbCrLf & "536  "
If Rectagdatapr1.Fields("t536_1") <> " " Then tmp = tmp & "     "
If Rectagdatapr1.Fields("t536_1") <> " " Then tmp = tmp & "| a" & Rectagdatapr1.Fields("t536_1")
If Rectagdatapr1.Fields("t536_2") <> " " Then tmp = tmp & "| b" & Rectagdatapr1.Fields("t536_2")
If Rectagdatapr1.Fields("t536_3") <> " " Then tmp = tmp & "| c" & Rectagdatapr1.Fields("t536_3")
If Rectagdatapr1.Fields("t536_4") <> " " Then tmp = tmp & "| d" & Rectagdatapr1.Fields("t536_4")
'***tag546***********
If Rectagdatapr1.Fields("t546_1") <> " " Then tmp = tmp & vbCrLf & "546       | a " & Rectagdatapr1.Fields("t546_1")
'***tag586***********
If Rectagdatapr1.Fields("t586_1") <> " " Then tmp = tmp & vbCrLf & "586       | a " & Rectagdatapr1.Fields("t586_1")
'********tag600***********
If Rectagdatapr2.Fields("t600_1") <> " " Or Rectagdatapr2.Fields("t600_2") <> " " Or Rectagdatapr2.Fields("t600_3") <> " " Then tmp = tmp & vbCrLf & "600  "
If Rectagdatapr2.Fields("i600") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i600") & "  "
If Rectagdatapr2.Fields("t600_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t600_1")
If Rectagdatapr2.Fields("t600_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr2.Fields("t600_2")
If Rectagdatapr2.Fields("t600_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t600_3")
If Rectagdatapr2.Fields("t600_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t600_4")
If Rectagdatapr2.Fields("t600_5") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t600_5")
If Rectagdatapr2.Fields("t600_6") <> " " Then tmp = tmp & "| q " & Rectagdatapr2.Fields("t600_6")
If Rectagdatapr2.Fields("t600_7") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t600_7")
If Rectagdatapr2.Fields("t600_8") <> " " Then tmp = tmp & "| x " & Rectagdatapr2.Fields("t600_8")
If Rectagdatapr2.Fields("t600_9") <> " " Then tmp = tmp & "| y " & Rectagdatapr2.Fields("t600_9")
If Rectagdatapr2.Fields("t600_10") <> " " Then tmp = tmp & "| z " & Rectagdatapr2.Fields("t600_10")
If Rectagdatapr2.Fields("t600_11") <> " " Then tmp = tmp & "| 2 " & Rectagdatapr2.Fields("t600_11")
'********tag610***********
If Rectagdatapr2.Fields("t610_1") <> " " Or Rectagdatapr2.Fields("t610_2") <> " " Or Rectagdatapr2.Fields("t610_3") <> " " Then tmp = tmp & vbCrLf & "610  "
If Rectagdatapr2.Fields("i610") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i610") & "  "
If Rectagdatapr2.Fields("t610_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t610_1")
If Rectagdatapr2.Fields("t610_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr2.Fields("t610_2")
If Rectagdatapr2.Fields("t610_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t610_3")
If Rectagdatapr2.Fields("t610_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t610_4")
If Rectagdatapr2.Fields("t610_5") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t610_5")
If Rectagdatapr2.Fields("t610_6") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t610_6")
If Rectagdatapr2.Fields("t610_7") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t610_7")
If Rectagdatapr2.Fields("t610_8") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t610_8")
If Rectagdatapr2.Fields("t610_9") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t610_9")
If Rectagdatapr2.Fields("t610_10") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t610_10")
If Rectagdatapr2.Fields("t610_11") <> " " Then tmp = tmp & "| x " & Rectagdatapr2.Fields("t610_11")
If Rectagdatapr2.Fields("t610_12") <> " " Then tmp = tmp & "| y " & Rectagdatapr2.Fields("t610_12")
If Rectagdatapr2.Fields("t610_13") <> " " Then tmp = tmp & "| z " & Rectagdatapr2.Fields("t610_13")
If Rectagdatapr2.Fields("t610_14") <> " " Then tmp = tmp & "| 2 " & Rectagdatapr2.Fields("t610_14")
'********tag611***********
If Rectagdatapr2.Fields("t611_1") <> " " Or Rectagdatapr2.Fields("t611_2") <> " " Or Rectagdatapr2.Fields("t611_3") <> " " Then tmp = tmp & vbCrLf & "611  "
If Rectagdatapr2.Fields("i611") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i611") & "  "
If Rectagdatapr2.Fields("t611_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t611_1")
If Rectagdatapr2.Fields("t611_2") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t611_2")
If Rectagdatapr2.Fields("t611_3") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t611_3")
If Rectagdatapr2.Fields("t611_4") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t611_4")
If Rectagdatapr2.Fields("t611_5") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t611_5")
If Rectagdatapr2.Fields("t611_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t611_6")
If Rectagdatapr2.Fields("t611_7") <> " " Then tmp = tmp & "| x " & Rectagdatapr2.Fields("t611_7")
If Rectagdatapr2.Fields("t611_8") <> " " Then tmp = tmp & "| y " & Rectagdatapr2.Fields("t611_8")
If Rectagdatapr2.Fields("t611_9") <> " " Then tmp = tmp & "| z " & Rectagdatapr2.Fields("t611_9")
If Rectagdatapr2.Fields("t611_10") <> " " Then tmp = tmp & "| 2 " & Rectagdatapr2.Fields("t611_10")
'********tag630***********
If Rectagdatapr2.Fields("t630_1") <> " " Or Rectagdatapr2.Fields("t630_2") <> " " Or Rectagdatapr2.Fields("t630_3") <> " " Then tmp = tmp & vbCrLf & "630  "
If Rectagdatapr2.Fields("i630") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i630") & "  "
If Rectagdatapr2.Fields("t630_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t630_1")
If Rectagdatapr2.Fields("t630_2") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t630_2")
If Rectagdatapr2.Fields("t630_3") <> " " Then tmp = tmp & "| f " & Rectagdatapr2.Fields("t630_3")
If Rectagdatapr2.Fields("t630_4") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t630_4")
If Rectagdatapr2.Fields("t630_5") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t630_5")
If Rectagdatapr2.Fields("t630_6") <> " " Then tmp = tmp & "| l " & Rectagdatapr2.Fields("t630_6")
If Rectagdatapr2.Fields("t630_7") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t630_7")
If Rectagdatapr2.Fields("t630_8") <> " " Then tmp = tmp & "| o " & Rectagdatapr2.Fields("t630_8")
If Rectagdatapr2.Fields("t630_9") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t630_9")
If Rectagdatapr2.Fields("t630_10") <> " " Then tmp = tmp & "| r " & Rectagdatapr2.Fields("t630_10")
If Rectagdatapr2.Fields("t630_11") <> " " Then tmp = tmp & "| s " & Rectagdatapr2.Fields("t630_11")
If Rectagdatapr2.Fields("t630_12") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t630_12")
If Rectagdatapr2.Fields("t630_13") <> " " Then tmp = tmp & "| x " & Rectagdatapr2.Fields("t630_13")
If Rectagdatapr2.Fields("t630_14") <> " " Then tmp = tmp & "| y " & Rectagdatapr2.Fields("t630_14")
If Rectagdatapr2.Fields("t630_15") <> " " Then tmp = tmp & "| z " & Rectagdatapr2.Fields("t630_15")
If Rectagdatapr2.Fields("t630_16") <> " " Then tmp = tmp & "| 2 " & Rectagdatapr2.Fields("t630_16")
'********tag650***********
If Rectagdatapr2.Fields("t650_1") <> " " Or Rectagdatapr2.Fields("t650_2") <> " " Or Rectagdatapr2.Fields("t650_3") <> " " Then tmp = tmp & vbCrLf & "650  "
If Rectagdatapr2.Fields("i650") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i650") & "  "
If Rectagdatapr2.Fields("t650_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t650_1")
If Rectagdatapr2.Fields("t650_2") <> " " Then tmp = tmp & "| x " & Rectagdatapr2.Fields("t650_2")
If Rectagdatapr2.Fields("t650_3") <> " " Then tmp = tmp & "| y " & Rectagdatapr2.Fields("t650_3")
If Rectagdatapr2.Fields("t650_4") <> " " Then tmp = tmp & "| z " & Rectagdatapr2.Fields("t650_4")
If Rectagdatapr2.Fields("t650_5") <> " " Then tmp = tmp & "| 2 " & Rectagdatapr2.Fields("t650_5")
'********tag651***********
If Rectagdatapr2.Fields("t651_1") <> " " Or Rectagdatapr2.Fields("t651_2") <> " " Or Rectagdatapr2.Fields("t651_3") <> " " Then tmp = tmp & vbCrLf & "651  "
If Rectagdatapr2.Fields("i651") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i651") & "  "
If Rectagdatapr2.Fields("t651_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t651_1")
If Rectagdatapr2.Fields("t651_2") <> " " Then tmp = tmp & "| x " & Rectagdatapr2.Fields("t651_2")
If Rectagdatapr2.Fields("t651_3") <> " " Then tmp = tmp & "| y " & Rectagdatapr2.Fields("t651_3")
If Rectagdatapr2.Fields("t651_4") <> " " Then tmp = tmp & "| z " & Rectagdatapr2.Fields("t651_4")
If Rectagdatapr2.Fields("t651_5") <> " " Then tmp = tmp & "| 2 " & Rectagdatapr2.Fields("t651_5")
'********tag700***********
If Rectagdatapr2.Fields("t700_1") <> " " Or Rectagdatapr2.Fields("t700_2") <> " " Or Rectagdatapr2.Fields("t700_3") <> " " Then tmp = tmp & vbCrLf & "700  "
If Rectagdatapr2.Fields("i700") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i700") & "  "
If Rectagdatapr2.Fields("t700_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t700_1")
If Rectagdatapr2.Fields("t700_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr2.Fields("t700_2")
If Rectagdatapr2.Fields("t700_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t700_3")
If Rectagdatapr2.Fields("t700_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t700_4")
If Rectagdatapr2.Fields("t700_5") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t700_5")
If Rectagdatapr2.Fields("t700_6") <> " " Then tmp = tmp & "| q " & Rectagdatapr2.Fields("t700_6")
'********tag710***********
If Rectagdatapr2.Fields("t710_1") <> " " Or Rectagdatapr2.Fields("t710_2") <> " " Or Rectagdatapr2.Fields("t710_3") <> " " Then tmp = tmp & vbCrLf & "710  "
If Rectagdatapr2.Fields("i710") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i710") & "  "
If Rectagdatapr2.Fields("t710_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t710_1")
If Rectagdatapr2.Fields("t710_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr2.Fields("t710_2")
If Rectagdatapr2.Fields("t710_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t710_3")
If Rectagdatapr2.Fields("t710_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t710_4")
If Rectagdatapr2.Fields("t710_5") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t710_5")
If Rectagdatapr2.Fields("t710_6") <> " " Then tmp = tmp & "| f " & Rectagdatapr2.Fields("t710_6")
If Rectagdatapr2.Fields("t710_7") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t710_7")
If Rectagdatapr2.Fields("t710_8") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t710_8")
If Rectagdatapr2.Fields("t710_9") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t710_9")
If Rectagdatapr2.Fields("t710_10") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t710_10")
If Rectagdatapr2.Fields("t710_11") <> " " Then tmp = tmp & "| s " & Rectagdatapr2.Fields("t710_11")
If Rectagdatapr2.Fields("t710_12") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t710_12")
'********tag711***********
If Rectagdatapr2.Fields("t711_1") <> " " Or Rectagdatapr2.Fields("t711_2") <> " " Or Rectagdatapr2.Fields("t711_3") <> " " Then tmp = tmp & vbCrLf & "711  "
If Rectagdatapr2.Fields("i711") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i711") & "  "
If Rectagdatapr2.Fields("t711_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t711_1")
If Rectagdatapr2.Fields("t711_2") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t711_2")
If Rectagdatapr2.Fields("t711_3") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t711_3")
If Rectagdatapr2.Fields("t711_4") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t711_4")
If Rectagdatapr2.Fields("t711_5") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t711_5")
If Rectagdatapr2.Fields("t711_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t711_6")
If Rectagdatapr2.Fields("t711_7") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t711_7")
If Rectagdatapr2.Fields("t711_8") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t711_8")
'********tag730***********
If Rectagdatapr2.Fields("t730_1") <> " " Or Rectagdatapr2.Fields("t730_2") <> " " Or Rectagdatapr2.Fields("t730_3") <> " " Then tmp = tmp & vbCrLf & "730  "
If Rectagdatapr2.Fields("i730") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i730") & "  "
If Rectagdatapr2.Fields("t730_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t730_1")
If Rectagdatapr2.Fields("t730_2") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t730_2")
If Rectagdatapr2.Fields("t730_3") <> " " Then tmp = tmp & "| f " & Rectagdatapr2.Fields("t730_3")
If Rectagdatapr2.Fields("t730_4") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t730_4")
If Rectagdatapr2.Fields("t730_5") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t730_5")
If Rectagdatapr2.Fields("t730_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t730_6")
If Rectagdatapr2.Fields("t730_7") <> " " Then tmp = tmp & "| l " & Rectagdatapr2.Fields("t730_7")
If Rectagdatapr2.Fields("t730_8") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t730_8")
If Rectagdatapr2.Fields("t730_9") <> " " Then tmp = tmp & "| s " & Rectagdatapr2.Fields("t730_9")
If Rectagdatapr2.Fields("t730_10") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t730_10")
'********tag740***********
If Rectagdatapr2.Fields("t740_1") <> " " Or Rectagdatapr2.Fields("t740_2") <> " " Or Rectagdatapr2.Fields("t740_3") <> " " Then tmp = tmp & vbCrLf & "740  "
If Rectagdatapr2.Fields("i740") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i740") & "  "
If Rectagdatapr2.Fields("t740_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t740_1")
If Rectagdatapr2.Fields("t740_2") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t740_2")
If Rectagdatapr2.Fields("t740_3") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t740_3")
'********tag800***********
If Rectagdatapr2.Fields("t800_1") <> " " Or Rectagdatapr2.Fields("t800_2") <> " " Or Rectagdatapr2.Fields("t800_3") <> " " Then tmp = tmp & vbCrLf & "800  "
If Rectagdatapr2.Fields("i800") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i800") & "  "
If Rectagdatapr2.Fields("t800_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t800_1")
If Rectagdatapr2.Fields("t800_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr2.Fields("t800_2")
If Rectagdatapr2.Fields("t800_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t800_3")
If Rectagdatapr2.Fields("t800_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t800_4")
If Rectagdatapr2.Fields("t800_5") <> " " Then tmp = tmp & "| q " & Rectagdatapr2.Fields("t800_5")
If Rectagdatapr2.Fields("t800_6") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t800_6")
If Rectagdatapr2.Fields("t800_7") <> " " Then tmp = tmp & "| v " & Rectagdatapr2.Fields("t800_7")
'********tag810***********
If Rectagdatapr2.Fields("t810_1") <> " " Or Rectagdatapr2.Fields("t810_2") <> " " Or Rectagdatapr2.Fields("t810_3") <> " " Then tmp = tmp & vbCrLf & "810  "
If Rectagdatapr2.Fields("i810") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i810") & "  "
If Rectagdatapr2.Fields("t810_1") <> " " Then tmp = tmp & "| a" & Rectagdatapr2.Fields("t810_1")
If Rectagdatapr2.Fields("t810_2") <> " " Then tmp = tmp & "| b " & Rectagdatapr2.Fields("t810_2")
If Rectagdatapr2.Fields("t810_3") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t810_3")
If Rectagdatapr2.Fields("t810_4") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t810_4")
If Rectagdatapr2.Fields("t810_5") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t810_5")
If Rectagdatapr2.Fields("t810_6") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t810_6")
If Rectagdatapr2.Fields("t810_7") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t810_7")
If Rectagdatapr2.Fields("t810_8") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t810_8")
If Rectagdatapr2.Fields("t810_9") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t810_9")
If Rectagdatapr2.Fields("t810_10") <> " " Then tmp = tmp & "| v " & Rectagdatapr2.Fields("t810_10")
'********tag811***********
If Rectagdatapr2.Fields("t811_1") <> " " Or Rectagdatapr2.Fields("t811_2") <> " " Or Rectagdatapr2.Fields("t811_3") <> " " Then tmp = tmp & vbCrLf & "811  "
If Rectagdatapr2.Fields("i811") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i811") & "  "
If Rectagdatapr2.Fields("t811_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t811_1")
If Rectagdatapr2.Fields("t811_2") <> " " Then tmp = tmp & "| c " & Rectagdatapr2.Fields("t811_2")
If Rectagdatapr2.Fields("t811_3") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t811_3")
If Rectagdatapr2.Fields("t811_4") <> " " Then tmp = tmp & "| e " & Rectagdatapr2.Fields("t811_4")
If Rectagdatapr2.Fields("t811_5") <> " " Then tmp = tmp & "| g " & Rectagdatapr2.Fields("t811_5")
If Rectagdatapr2.Fields("t811_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t811_6")
If Rectagdatapr2.Fields("t811_7") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t811_7")
If Rectagdatapr2.Fields("t811_8") <> " " Then tmp = tmp & "| q " & Rectagdatapr2.Fields("t811_8")
If Rectagdatapr2.Fields("t811_9") <> " " Then tmp = tmp & "| t " & Rectagdatapr2.Fields("t811_9")
If Rectagdatapr2.Fields("t811_10") <> " " Then tmp = tmp & "| v " & Rectagdatapr2.Fields("t811_10")
'********tag830***********
If Rectagdatapr2.Fields("t830_1") <> " " Or Rectagdatapr2.Fields("t830_2") <> " " Or Rectagdatapr2.Fields("t830_3") <> " " Then tmp = tmp & vbCrLf & "830  "
If Rectagdatapr2.Fields("i830") <> " " Then tmp = tmp & Rectagdatapr2.Fields("i830") & "  "
If Rectagdatapr2.Fields("t830_1") <> " " Then tmp = tmp & "| a " & Rectagdatapr2.Fields("t830_1")
If Rectagdatapr2.Fields("t830_2") <> " " Then tmp = tmp & "| d " & Rectagdatapr2.Fields("t830_2")
If Rectagdatapr2.Fields("t830_3") <> " " Then tmp = tmp & "| f " & Rectagdatapr2.Fields("t830_3")
If Rectagdatapr2.Fields("t830_4") <> " " Then tmp = tmp & "| k " & Rectagdatapr2.Fields("t830_4")
If Rectagdatapr2.Fields("t830_5") <> " " Then tmp = tmp & "| l " & Rectagdatapr2.Fields("t830_5")
If Rectagdatapr2.Fields("t830_6") <> " " Then tmp = tmp & "| n " & Rectagdatapr2.Fields("t830_6")
If Rectagdatapr2.Fields("t830_7") <> " " Then tmp = tmp & "| p " & Rectagdatapr2.Fields("t830_7")
If Rectagdatapr2.Fields("t830_8") <> " " Then tmp = tmp & "| s " & Rectagdatapr2.Fields("t830_8")
If Rectagdatapr2.Fields("t830_9") <> " " Then tmp = tmp & "| v " & Rectagdatapr2.Fields("t830_9")
'***tag850***********
If Rectagdatapr2.Fields("t850_1") <> " " Then tmp = tmp & vbCrLf & "850       |a" & Rectagdatapr2.Fields("t850_1")
'********************
tmp = tmp & vbCrLf & vbCrLf
Text1.Text = tmp
End If
ex:
End Sub

Private Sub Command4_Click()
Text1.Text = ""
tmp = ""

End Sub

Private Sub Form_Load()
Option1.Value = True
Set marcwspr = DBEngine.Workspaces(0)
Set marcdbpr = marcwspr.OpenDatabase("marcsheetdb", False, False)
'Openrecordset for select from combo box
Set idsnappr = marcdbpr.OpenRecordset("Select t020_1 from tagdata1 Order by t020_1", dbOpenSnapshot)
'checking for null database
If idsnappr.EOF Then
   MsgBox ("����բ����ź��ҹ����������")
   cmbIDpr.Clear
Else
'Add item in the combo box
idsnappr.MoveFirst
cmbIDpr.Clear
Do While Not idsnappr.EOF
  cmbIDpr.AddItem (idsnappr.Fields("t020_1"))
   idsnappr.MoveNext
Loop
End If
End Sub

Private Sub Option1_Click()
Set marcwspr = DBEngine.Workspaces(0)
Set marcdbpr = marcwspr.OpenDatabase("marcsheetdb", False, False)
Set idsnappr = marcdbpr.OpenRecordset("Select t020_1 from tagdata1 Order by t020_1", dbOpenSnapshot)
If idsnappr.EOF Then
   MsgBox ("����բ����ź��ҹ����������")
   Command1.Visible = False
   cmbIDpr.Clear
 Else
    idsnappr.MoveFirst
cmbIDpr.Clear
Do While Not idsnappr.EOF
  cmbIDpr.AddItem (idsnappr.Fields("t020_1"))
   idsnappr.MoveNext
Loop
End If
    
End Sub

Private Sub Option2_Click()
Set marcwspr = DBEngine.Workspaces(0)
Set marcdbpr = marcwspr.OpenDatabase("marcsheetdb", False, False)
Set idsnappr = marcdbpr.OpenRecordset("Select book_no from tagdata1 Order by book_no", dbOpenSnapshot)
If idsnappr.EOF Then
   MsgBox ("����բ����ź��ҹ����������")
   Command1.Visible = False
   cmbIDpr.Clear
 Else
    idsnappr.MoveFirst
cmbIDpr.Clear
Do While Not idsnappr.EOF
  cmbIDpr.AddItem (idsnappr.Fields("book_no"))
   idsnappr.MoveNext
Loop
End If
End Sub

