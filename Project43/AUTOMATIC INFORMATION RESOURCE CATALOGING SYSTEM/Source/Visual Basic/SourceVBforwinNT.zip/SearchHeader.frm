VERSION 5.00
Begin VB.Form SearchHeader 
   Caption         =   "�����������ͧ"
   ClientHeight    =   7935
   ClientLeft      =   435
   ClientTop       =   420
   ClientWidth     =   10980
   Icon            =   "SearchHeader.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   7935
   ScaleWidth      =   10980
   Begin VB.CommandButton Command5 
      Height          =   855
      Left            =   9000
      Picture         =   "SearchHeader.frx":110A
      Style           =   1  'Graphical
      TabIndex        =   7
      ToolTipText     =   "�����������ͧŧ Marc"
      Top             =   720
      Width           =   975
   End
   Begin VB.CommandButton Command4 
      Caption         =   "&Redo"
      Height          =   615
      Left            =   6600
      Picture         =   "SearchHeader.frx":1CD4
      Style           =   1  'Graphical
      TabIndex        =   4
      ToolTipText     =   "仢�ҧ˹��"
      Top             =   840
      Width           =   1455
   End
   Begin VB.CommandButton Command3 
      Caption         =   "&Undo"
      Height          =   615
      Left            =   4920
      Picture         =   "SearchHeader.frx":2116
      Style           =   1  'Graphical
      TabIndex        =   3
      ToolTipText     =   "��͹��Ѻ"
      Top             =   840
      Width           =   1455
   End
   Begin VB.CommandButton Command2 
      Height          =   855
      Left            =   2520
      Picture         =   "SearchHeader.frx":2558
      Style           =   1  'Graphical
      TabIndex        =   2
      ToolTipText     =   "�͡�ҡ�����"
      Top             =   720
      Width           =   975
   End
   Begin VB.TextBox TxtSearch 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2640
      TabIndex        =   0
      Top             =   240
      Width           =   5175
   End
   Begin VB.CommandButton Command1 
      Default         =   -1  'True
      Height          =   855
      Left            =   720
      Picture         =   "SearchHeader.frx":2F7A
      Style           =   1  'Graphical
      TabIndex        =   1
      ToolTipText     =   "�ʴ��������ͧ"
      Top             =   720
      Width           =   975
   End
   Begin VB.TextBox Searchhit 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6015
      Left            =   360
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   5
      Top             =   1680
      Width           =   10215
   End
   Begin VB.Label Label1 
      Caption         =   "�������ͧ����ͧ��ä���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   480
      TabIndex        =   6
      Top             =   240
      Width           =   1935
   End
End
Attribute VB_Name = "SearchHeader"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public OrderWs     As Workspace
Public OrderDb     As Database
Public Opendyna  As Recordset
Public Opendyna1 As Recordset
Public Opendyna2 As Recordset
Public Opendyna3 As Recordset
Public sqlcommand  As String
Public Searchtext  As String
Public Searchfind As String
Public CheckHeader As Boolean
Public Numcount As Integer

Dim Redo_Undo(20) As String
Dim Keep_Header As String
Dim Keep_SubHeader1 As String
Dim Keep_SubHeader2 As String
Dim Keep_SubHeader3 As String
Dim tab_string As String ' ��㹡�èѴ˹�������§��㹵͹�ʴ���
Dim tmp As String
Dim i As Integer ' Index for Redo Undo Array

Private Sub Command1_Click()
Where_SearchText
End Sub

Private Sub Command2_Click()
Unload Me
End Sub

Private Sub Command3_Click()
If i > 1 Then
i = i - 1
Searchhit.Text = Redo_Undo(i)
End If
End Sub

Private Sub Command4_Click()
Dim j As Integer
j = i + 1
If j <= 20 Then
If (i < 20) And (Redo_Undo(j) <> "") Then
i = i + 1
Searchhit.Text = Redo_Undo(i)
End If
End If

End Sub

Private Sub Command5_Click()
MarcMenu.check = True
tag090.tag090_1.Text = Searchhit.SelText
tagselect.Show
tag090.Show

End Sub

Private Sub Form_Load()
Set OrderWs = DBEngine.Workspaces(0)
 Set OrderDb = OrderWs.OpenDatabase("HeaderDB.mdb", False, False)
 i = 0
End Sub

Private Sub Searchhit_DblClick()
Where_SearchText
End Sub

Public Sub SearchHead()

sqlcommand = " SELECT * FROM tblMain "
sqlcommand = sqlcommand & "WHERE Header LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*' "
sqlcommand = sqlcommand & "order by 1"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

'--------------------------------------------- End sql command ---------------------------------------------------

Searchfind = ""
Do Until Opendyna.EOF

Keep_Header = Opendyna.Fields("header")
Searchfind = Searchfind & vbTab & Opendyna.Fields("Header") & "  "
If Opendyna.Fields("TranEng") <> "" Then
Searchfind = Searchfind & "(" & Opendyna.Fields("TranEng") & ")  "
End If
If Opendyna.Fields("LC_Dewey") <> "" Then
Searchfind = Searchfind & "[" & Opendyna.Fields("LC_Dewey") & "]"
End If
If Opendyna.Fields("Descript") <> "" Then
'Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna.Fields("Descript") & vbCrLf
tmp = Opendyna.Fields("Descript")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & tmp & vbCrLf
Else
    Searchfind = Searchfind & vbCrLf
End If

'------------------------------- Display USE , UF , BT , RT , SA , NT  -----------------------------------------------------------


If Opendyna.Fields("Use") <> "" Then
tmp = Opendyna.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
'tmp = Replace(tmp, "%", tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna.Fields("UF") <> "" Then
tmp = Opendyna.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)

Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna.Fields("BT") <> "" Then
tmp = Opendyna.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)

Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna.Fields("RT") <> "" Then
tmp = Opendyna.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)

Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna.Fields("SA") <> "" Then
tmp = Opendyna.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)

Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna.Fields("NT") <> "" Then
tmp = Opendyna.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

'--------------------------------------- Search and Display Subheader 1 is it have -------------------------------------------
'---------------------------------------------------------------------------------------------------------------------------------------------------

sqlcommand = " SELECT * FROM tblSub1 "
sqlcommand = sqlcommand & "WHERE Header = "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header
sqlcommand = sqlcommand & "' "
sqlcommand = sqlcommand & "order by 1,2"
Set Opendyna1 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna1.EOF
    Keep_SubHeader1 = Opendyna1.Fields("Subheader_1")
     Searchfind = Searchfind & vbTab & "    -  " & Opendyna1.Fields("Subheader_1") & "  "
     If Opendyna1.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna1.Fields("TranEng") & ")  "
    End If
    If Opendyna1.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna1.Fields("LC_Dewey") & "]"
    End If
    If Opendyna1.Fields("Descript") <> "" Then
           'Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna1.Fields("Descript") & vbCrLf
            tmp = Opendyna1.Fields("Descript")
            tmp = Replace(tmp, vbCrLf, tab_string, 1)
            Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & tmp & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna1.Fields("Use") <> "" Then
tmp = Opendyna1.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna1.Fields("UF") <> "" Then
tmp = Opendyna1.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna1.Fields("BT") <> "" Then
tmp = Opendyna1.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna1.Fields("RT") <> "" Then
tmp = Opendyna1.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna1.Fields("SA") <> "" Then
tmp = Opendyna1.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna1.Fields("NT") <> "" Then
tmp = Opendyna1.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

'---------------------------------------------- Search and Display Subheader 2 -------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------

'--------------------------------------------------------------------------------------------------------------------------------------------------
sqlcommand = " SELECT * FROM tblSub2 "
sqlcommand = sqlcommand & "WHERE Header = "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & " and Subheader_1 = '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "'"
sqlcommand = sqlcommand & " order by 1,2,3 "

Set Opendyna2 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

Do Until Opendyna2.EOF
Keep_SubHeader2 = Opendyna2.Fields("Subheader_2")
Searchfind = Searchfind & vbTab & vbTab & "    - -  " & Opendyna2.Fields("Subheader_2") & "  "
     If Opendyna2.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna2.Fields("TranEng") & ")  "
    End If
    If Opendyna2.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna2.Fields("LC_Dewey") & "]"
    End If
    If Opendyna2.Fields("Descript") <> "" Then
           'Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna2.Fields("Descript") & vbCrLf
            tmp = Opendyna2.Fields("Descript")
            tmp = Replace(tmp, vbCrLf, tab_string, 1)
            Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & tmp & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna2.Fields("Use") <> "" Then
tmp = Opendyna2.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna2.Fields("UF") <> "" Then
tmp = Opendyna2.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna2.Fields("BT") <> "" Then
tmp = Opendyna2.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna2.Fields("RT") <> "" Then
tmp = Opendyna2.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna2.Fields("SA") <> "" Then
tmp = Opendyna2.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna2.Fields("NT") <> "" Then
tmp = Opendyna2.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

'---------------------------------------------- Search and Display Subheader 3 ------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------

'--------------------------------------------------------------------------------------------------------------------------------------------------

sqlcommand = " SELECT * FROM tblSub3 "
sqlcommand = sqlcommand & "WHERE Header = "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & " and Subheader_1 = '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "'"
sqlcommand = sqlcommand & " and Subheader_2 = '"
sqlcommand = sqlcommand & Keep_SubHeader2 & "'"
sqlcommand = sqlcommand & " order by 1,2,3,4 "

Set Opendyna3 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

Do Until Opendyna3.EOF
Searchfind = Searchfind & vbTab & vbTab & vbTab & "    - - -  " & Opendyna3.Fields("Subheader_3") & "  "
     If Opendyna3.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna3.Fields("TranEng") & ")  "
    End If
    If Opendyna3.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna3.Fields("LC_Dewey") & "]"
    End If
    If Opendyna3.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna3.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna3.Fields("Use") <> "" Then
tmp = Opendyna3.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna3.Fields("UF") <> "" Then
tmp = Opendyna3.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna3.Fields("BT") <> "" Then
tmp = Opendyna3.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("RT") <> "" Then
tmp = Opendyna3.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("SA") <> "" Then
tmp = Opendyna3.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna3.Fields("NT") <> "" Then
tmp = Opendyna3.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

Searchfind = Searchfind & vbCrLf
Opendyna3.MoveNext

Loop ' -------------------------------------- Loop 's Subheader 3

Searchfind = Searchfind & vbCrLf
Opendyna2.MoveNext

Loop ' ---------------------------------------- Loop 's Subheader 2


Searchfind = Searchfind & vbCrLf
Opendyna1.MoveNext

Loop ' ----------------------------------------- Loop 's Subheader 1

'----------------------------------------------- end Display sub header --------------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------

Searchfind = Searchfind & vbCrLf
Opendyna.MoveNext

Loop ' ------------------------------------------ Loop 's  Header

End Sub

Public Sub SearchSub1()

sqlcommand = " SELECT * FROM tblSub1 "
sqlcommand = sqlcommand & "WHERE Header like "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header & "*' "
sqlcommand = sqlcommand & "and Subheader_1 like '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "*' "
sqlcommand = sqlcommand & "order by 1,2"
Set Opendyna1 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

If Not (Opendyna1.EOF) Then
Searchfind = vbTab & Opendyna1.Fields("Header") & vbCrLf
Keep_Header = Opendyna1.Fields("Header")
End If

Do Until Opendyna1.EOF
    If Keep_Header <> Opendyna1.Fields("Header") Then
       Searchfind = Searchfind & vbTab & Opendyna1.Fields("Header") & vbCrLf
       Keep_Header = Opendyna1.Fields("Header")
    End If
    Keep_SubHeader1 = Opendyna1.Fields("Subheader_1")
     Searchfind = Searchfind & vbTab & "    -  " & Opendyna1.Fields("Subheader_1") & "  "
     If Opendyna1.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna1.Fields("TranEng") & ")  "
    End If
    If Opendyna1.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna1.Fields("LC_Dewey") & "]"
    End If
    If Opendyna1.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna1.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna1.Fields("Use") <> "" Then
tmp = Opendyna1.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna1.Fields("UF") <> "" Then
tmp = Opendyna1.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna1.Fields("BT") <> "" Then
tmp = Opendyna1.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna1.Fields("RT") <> "" Then
tmp = Opendyna1.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna1.Fields("SA") <> "" Then
tmp = Opendyna1.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna1.Fields("NT") <> "" Then
tmp = Opendyna1.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

'---------------------------------------------- Search and Display Subheader 2 -------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------

'--------------------------------------------------------------------------------------------------------------------------------------------------
sqlcommand = " SELECT * FROM tblSub2 "
sqlcommand = sqlcommand & "WHERE Header = "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header
sqlcommand = sqlcommand & "' "
sqlcommand = sqlcommand & " and Subheader_1 = '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "' "
sqlcommand = sqlcommand & " order by 1,2,3 "




Set Opendyna2 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

Do Until Opendyna2.EOF
Keep_SubHeader2 = Opendyna2.Fields("Subheader_2")
Searchfind = Searchfind & vbTab & vbTab & "    - -  " & Opendyna2.Fields("Subheader_2") & "  "
     If Opendyna2.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna2.Fields("TranEng") & ")  "
    End If
    If Opendyna2.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna2.Fields("LC_Dewey") & "]"
    End If
    If Opendyna2.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna2.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna2.Fields("Use") <> "" Then
tmp = Opendyna2.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna2.Fields("UF") <> "" Then
tmp = Opendyna2.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna2.Fields("BT") <> "" Then
tmp = Opendyna2.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna2.Fields("RT") <> "" Then
tmp = Opendyna2.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna2.Fields("SA") <> "" Then
tmp = Opendyna2.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna2.Fields("NT") <> "" Then
tmp = Opendyna2.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

'---------------------------------------------- Search and Display Subheader 3 ------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------

'--------------------------------------------------------------------------------------------------------------------------------------------------

sqlcommand = " SELECT * FROM tblSub3 "
sqlcommand = sqlcommand & "WHERE Header = "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & " and Subheader_1 = '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "'"
sqlcommand = sqlcommand & " and Subheader_2 = '"
sqlcommand = sqlcommand & Keep_SubHeader2 & "'"
sqlcommand = sqlcommand & " order by 1,2,3,4 "

Set Opendyna3 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

Do Until Opendyna3.EOF
Searchfind = Searchfind & vbTab & vbTab & vbTab & "    - - -  " & Opendyna3.Fields("Subheader_3") & "  "
     If Opendyna3.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna3.Fields("TranEng") & ")  "
    End If
    If Opendyna3.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna3.Fields("LC_Dewey") & "]"
    End If
    If Opendyna3.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna3.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna3.Fields("Use") <> "" Then
tmp = Opendyna3.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna3.Fields("UF") <> "" Then
tmp = Opendyna3.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna3.Fields("BT") <> "" Then
tmp = Opendyna3.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("RT") <> "" Then
tmp = Opendyna3.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("SA") <> "" Then
tmp = Opendyna3.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna3.Fields("NT") <> "" Then
tmp = Opendyna3.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

Searchfind = Searchfind & vbCrLf
Opendyna3.MoveNext

Loop ' -------------------------------------- Loop 's Subheader 3

Searchfind = Searchfind & vbCrLf
Opendyna2.MoveNext

Loop ' ---------------------------------------- Loop 's Subheader 2


Searchfind = Searchfind & vbCrLf
Opendyna1.MoveNext

Loop ' ----------------------------------------- Loop 's Subheader 1



End Sub

Public Sub SearchSub2()

sqlcommand = " SELECT * FROM tblSub2 "
sqlcommand = sqlcommand & "WHERE Header like "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header & "*' "
sqlcommand = sqlcommand & " and Subheader_1 like '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "*' "
sqlcommand = sqlcommand & " and Subheader_2 like '"
sqlcommand = sqlcommand & Keep_SubHeader2 & "*' "
sqlcommand = sqlcommand & " order by 1,2,3 "

Set Opendyna2 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

If Not (Opendyna2.EOF) Then
Searchfind = vbTab & Opendyna2.Fields("Header") & vbCrLf
 Keep_Header = Opendyna2.Fields("Header")
 Searchfind = Searchfind & vbTab & "    -  " & Opendyna2.Fields("Subheader_1") & vbCrLf
 Keep_SubHeader1 = Opendyna2.Fields("Subheader_1")
 End If
 
Do Until Opendyna2.EOF
If Keep_Header <> Opendyna2.Fields("Header") Then
   Searchfind = Searchfind & vbTab & Opendyna2.Fields("Header") & vbCrLf
   Keep_Header = Opendyna2.Fields("Header")
End If

If Keep_SubHeader1 <> Opendyna2.Fields("Subheader_1") Then
   Searchfind = Searchfind & vbTab & "    -  " & Opendyna2.Fields("Subheader_1") & vbCrLf
   Keep_SubHeader1 = Opendyna2.Fields("Subheader_1")
 End If

Keep_SubHeader2 = Opendyna2.Fields("Subheader_2")
Searchfind = Searchfind & vbTab & vbTab & "    - -  " & Opendyna2.Fields("Subheader_2") & "  "
     If Opendyna2.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna2.Fields("TranEng") & ")  "
    End If
    If Opendyna2.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna2.Fields("LC_Dewey") & "]"
    End If
    If Opendyna2.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna2.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna2.Fields("Use") <> "" Then
tmp = Opendyna2.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna2.Fields("UF") <> "" Then
tmp = Opendyna2.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna2.Fields("BT") <> "" Then
tmp = Opendyna2.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna2.Fields("RT") <> "" Then
tmp = Opendyna2.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna2.Fields("SA") <> "" Then
tmp = Opendyna2.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna2.Fields("NT") <> "" Then
tmp = Opendyna2.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

'---------------------------------------------- Search and Display Subheader 3 ------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------
'--------------------------------------------------------------------------------------------------------------------------------------------------

'--------------------------------------------------------------------------------------------------------------------------------------------------

sqlcommand = " SELECT * FROM tblSub3 "
sqlcommand = sqlcommand & "WHERE Header = "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Keep_Header
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & " and Subheader_1 = '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "'"
sqlcommand = sqlcommand & " and Subheader_2 = '"
sqlcommand = sqlcommand & Keep_SubHeader2 & "'"
sqlcommand = sqlcommand & " order by 1,2,3,4 "

Set Opendyna3 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

Do Until Opendyna3.EOF
Searchfind = Searchfind & vbTab & vbTab & vbTab & "    - - -  " & Opendyna3.Fields("Subheader_3") & "  "
     If Opendyna3.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna3.Fields("TranEng") & ")  "
    End If
    If Opendyna3.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna3.Fields("LC_Dewey") & "]"
    End If
    If Opendyna3.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna3.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna3.Fields("Use") <> "" Then
tmp = Opendyna3.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna3.Fields("UF") <> "" Then
tmp = Opendyna3.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna3.Fields("BT") <> "" Then
tmp = Opendyna3.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("RT") <> "" Then
tmp = Opendyna3.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("SA") <> "" Then
tmp = Opendyna3.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna3.Fields("NT") <> "" Then
tmp = Opendyna3.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

Searchfind = Searchfind & vbCrLf
Opendyna3.MoveNext

Loop ' -------------------------------------- Loop 's Subheader 3

Searchfind = Searchfind & vbCrLf
Opendyna2.MoveNext

Loop ' ---------------------------------------- Loop 's Subheader 2
End Sub

Public Sub SearchSub3()

sqlcommand = " SELECT * FROM tblSub3 "
sqlcommand = sqlcommand & "WHERE Header like '"
sqlcommand = sqlcommand & Keep_Header & "*' "
sqlcommand = sqlcommand & " and Subheader_1 like '"
sqlcommand = sqlcommand & Keep_SubHeader1 & "*' "
sqlcommand = sqlcommand & " and Subheader_2 like '"
sqlcommand = sqlcommand & Keep_SubHeader2 & "*' "
sqlcommand = sqlcommand & " and Subheader_3 like '"
sqlcommand = sqlcommand & Keep_SubHeader3 & "*' "
sqlcommand = sqlcommand & " order by 1,2,3,4 "

Set Opendyna3 = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)

If Not (Opendyna3.EOF) Then
Searchfind = vbTab & Opendyna3.Fields("Header") & vbCrLf
Keep_Header = Opendyna3.Fields("Header")
 Searchfind = Searchfind & vbTab & "    -  " & Opendyna3.Fields("Subheader_1") & vbCrLf
 Keep_SubHeader1 = Opendyna3.Fields("Subheader_1")
 Searchfind = Searchfind & vbTab & vbTab & "    - -  " & Opendyna3.Fields("Subheader_2") & vbCrLf
 Keep_SubHeader2 = Opendyna3.Fields("Subheader_2")
End If

Do Until Opendyna3.EOF

If Keep_Header <> Opendyna3.Fields("Header") Then
Searchfind = Searchfind & vbTab & Opendyna3.Fields("Header") & vbCrLf
Keep_Header = Opendyna3.Fields("Header")
End If

If Keep_SubHeader1 <> Opendyna3.Fields("Subheader_1") Then
Searchfind = Searchfind & vbTab & "    -  " & Opendyna3.Fields("Subheader_1") & vbCrLf
 Keep_SubHeader1 = Opendyna3.Fields("Subheader_1")
End If

If Keep_SubHeader2 <> Opendyna3.Fields("Subheader_2") Then
Searchfind = Searchfind & vbTab & vbTab & "    - -  " & Opendyna3.Fields("Subheader_2") & vbCrLf
 Keep_SubHeader2 = Opendyna3.Fields("Subheader_2")
End If

Searchfind = Searchfind & vbTab & vbTab & vbTab & "    - - -  " & Opendyna3.Fields("Subheader_3") & "  "
     If Opendyna3.Fields("TranEng") <> "" Then
           Searchfind = Searchfind & "(" & Opendyna3.Fields("TranEng") & ")  "
    End If
    If Opendyna3.Fields("LC_Dewey") <> "" Then
           Searchfind = Searchfind & "[" & Opendyna3.Fields("LC_Dewey") & "]"
    End If
    If Opendyna3.Fields("Descript") <> "" Then
           Searchfind = Searchfind & vbCrLf & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & Opendyna3.Fields("Descript") & vbCrLf
    Else
           Searchfind = Searchfind & vbCrLf
    End If

If Opendyna3.Fields("Use") <> "" Then
tmp = Opendyna3.Fields("Use")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "USE       " & tmp & vbCrLf
End If

If Opendyna3.Fields("UF") <> "" Then
tmp = Opendyna3.Fields("UF")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "UF          " & tmp & vbCrLf
End If

If Opendyna3.Fields("BT") <> "" Then
tmp = Opendyna3.Fields("BT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "BT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("RT") <> "" Then
tmp = Opendyna3.Fields("RT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "RT          " & tmp & vbCrLf
End If

If Opendyna3.Fields("SA") <> "" Then
tmp = Opendyna3.Fields("SA")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "SA          " & tmp & vbCrLf
End If

If Opendyna3.Fields("NT") <> "" Then
tmp = Opendyna3.Fields("NT")
tmp = Replace(tmp, vbCrLf, tab_string, 1)
Searchfind = Searchfind & vbTab & vbTab & vbTab & vbTab & vbTab & "NT          " & tmp & vbCrLf
End If

Searchfind = Searchfind & vbCrLf
Opendyna3.MoveNext

Loop ' -------------------------------------- Loop 's Subheader 3

End Sub

Public Sub Where_SearchText()
Dim dash As Integer
Dim j As Integer
Dim a As Integer
Dim tmp As String

Searchtext = ""
Searchfind = ""
Keep_Header = ""
Keep_SubHeader1 = ""
Keep_SubHeader2 = ""
Keep_SubHeader3 = ""


If TxtSearch.Text = "" Then
Searchtext = Searchhit.SelText
Else
Searchtext = TxtSearch.Text
End If

'------------------ Delete Blank , Tab String , CarageReturn form Searchtext ----
Searchtext = Trim(Searchtext)
Searchtext = Replace(Searchtext, vbTab, "", 1)
Searchtext = Replace(Searchtext, vbCrLf, "", 1)
'-------------------------------------------------------------------------------------------------------------------

If Searchtext <> "" Then

tab_string = vbCrLf & String(5, vbTab) '��Ѵ������˹����ҡѹ
i = i + 1

If i > 20 Then
For j = 1 To 19
Redo_Undo(j) = Redo_Undo(j + 1)
Next j
Redo_Undo(20) = ""
i = 20
End If

a = 0
tmp = Searchtext


Do
a = InStr(a + 1, tmp, "-")
If a <> 0 Then
dash = dash + 1
      If dash = 1 Then
         Keep_Header = Left(tmp, a - 1)
         Keep_SubHeader1 = Mid(tmp, a + 1)
         Keep_SubHeader1 = Trim(Keep_SubHeader1)
      End If
      If dash = 2 Then
         Keep_SubHeader1 = Left(Keep_SubHeader1, (InStr(Keep_SubHeader1, "-")) - 1)
         Keep_SubHeader2 = Mid(tmp, a + 1)
         Keep_SubHeader2 = Trim(Keep_SubHeader2)
      End If
      If dash = 3 Then
         Keep_SubHeader2 = Left(Keep_SubHeader2, (InStr(Keep_SubHeader2, "-")) - 1)
         Keep_SubHeader3 = Mid(tmp, a + 1)
         Keep_SubHeader3 = Trim(Keep_SubHeader3)
      End If
End If
Loop Until a = 0



Select Case dash
Case Is = 0
         SearchHead
Case Is = 1
         SearchSub1
Case Is = 2
         SearchSub2
Case Is = 3
         SearchSub3
End Select

Searchhit.ForeColor = QBColor(1)

Searchhit.Locked = True
TxtSearch.Text = ""
TxtSearch.SetFocus

 Dim Respond As Variant
 
 If Searchfind = "" Then
   Respond = MsgBox("��辺�������ͧ " & Searchtext & " ����ͧ��� " & vbCrLf & "��ͧ��������������ͧ�������㹰ҹ�������������", vbQuestion + vbYesNo)
   i = i - 1
   If Respond = vbYes Then
       If dash = 0 Then
           Header.Show
           Header.calladd
           Header.Text1(0).Text = Searchtext
           
       End If
       If dash = 1 Then
           Header1.Show
           Header1.calladd
           Header1.Label5.Caption = Keep_Header
           Header1.Text1(0).Text = Keep_SubHeader1
           
       End If
       If dash = 2 Then
          Header2.Show
          Header2.calladd
          Header2.Label5.Caption = Keep_Header
          Header2.Label7.Caption = Keep_SubHeader1
          Header2.Text1(0).Text = Keep_SubHeader2
          
       End If
       If dash = 3 Then
          Header3.Show
           Header3.calladd
          Header3.Label5.Caption = Keep_Header
          Header3.Label7.Caption = Keep_SubHeader1
          Header3.Label9.Caption = Keep_SubHeader2
          Header3.Text1(0).Text = Keep_SubHeader3
         
          
       End If
   End If   ' end if of Respond
 Else
 Searchfind = Replace(Searchfind, "%", tab_string, 1)
 Searchhit.Text = Searchfind
 Redo_Undo(i) = Searchfind
End If
Else
MsgBox ("��س�����������ͧ����ͧ��ä���")
TxtSearch.SetFocus
End If


End Sub
