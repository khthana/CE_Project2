VERSION 5.00
Begin VB.Form Main 
   BackColor       =   &H8000000E&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BookCode Management Program"
   ClientHeight    =   6105
   ClientLeft      =   2160
   ClientTop       =   1920
   ClientWidth     =   8820
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6105
   ScaleWidth      =   8820
   Begin VB.Image Image2 
      Height          =   1350
      Left            =   120
      Picture         =   "Form1.frx":110A
      Top             =   360
      Width           =   8760
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   5
      Left            =   480
      Picture         =   "Form1.frx":5A6B
      Stretch         =   -1  'True
      Top             =   2040
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   4
      Left            =   480
      Picture         =   "Form1.frx":72ED
      Stretch         =   -1  'True
      Top             =   2040
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   3
      Left            =   480
      Picture         =   "Form1.frx":7E6B
      Stretch         =   -1  'True
      Top             =   2040
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   2
      Left            =   480
      Picture         =   "Form1.frx":9B2B
      Stretch         =   -1  'True
      Top             =   2040
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      BorderStyle     =   1  'Fixed Single
      Height          =   3075
      Index           =   1
      Left            =   480
      Picture         =   "Form1.frx":A41C
      Stretch         =   -1  'True
      Top             =   2040
      Visible         =   0   'False
      Width           =   2325
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   0
      Left            =   480
      Picture         =   "Form1.frx":BD1B
      Stretch         =   -1  'True
      Top             =   2040
      Width           =   2325
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "�͡�ҡ��÷ӧҹ�ͧ�����"
      DragIcon        =   "Form1.frx":D59D
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   3
      Left            =   3120
      TabIndex        =   3
      Top             =   4680
      Width           =   3375
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "�������èѴ��â����ŵ���к� Marc format"
      DragIcon        =   "Form1.frx":D8A7
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   2
      Left            =   3120
      TabIndex        =   2
      Top             =   3840
      Width           =   5175
   End
   Begin VB.Label Label1 
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   "�������èѴ����Ţ�������ͧ˹ѧ���"
      DragIcon        =   "Form1.frx":DBB1
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   1
      Left            =   3120
      TabIndex        =   1
      Top             =   3000
      Width           =   3975
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      BackStyle       =   0  'Transparent
      Caption         =   "�������èѴ����Ţ�����˹ѧ���"
      DragIcon        =   "Form1.frx":DEBB
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   0
      Left            =   3120
      TabIndex        =   0
      Top             =   2160
      Width           =   3735
   End
End
Attribute VB_Name = "Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Label1_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If Source Is Label1(Index) Then
        With Label1(Index)
            .Font.Underline = False
            .ForeColor = vbBlack
            Screen.MousePointer = vbHourglass
            
            Select Case Index
            Case 0
                AuthorMenu.Show
            Case 1
                HeaderMenu.Show
            Case 2
               mainmenu.Show
            Case 3
               Unload Me
            
            End Select
            Screen.MousePointer = vbNormal
        End With
    End If
End Sub

Private Sub Label1_DragOver(Index As Integer, Source As Control, X As Single, Y As Single, State As Integer)
If State = vbLeave Then
        With Label1(Index)
            .Drag vbEndDrag
            .Font.Underline = False
            .ForeColor = vbBlack
            Image1(0).Picture = Image1(5).Picture
         
        End With
    End If

End Sub

Private Sub Label1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
With Label1(Index)
        .ForeColor = vbBlue
        .Font.Underline = True
        .Drag vbBeginDrag
        Image1(0).Picture = Image1(Index + 1).Picture

    End With
  
End Sub

