VERSION 5.00
Begin VB.Form tag500 
   Caption         =   "tag500"
   ClientHeight    =   7860
   ClientLeft      =   60
   ClientTop       =   1080
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton Newcmd 
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2880
      TabIndex        =   22
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   2
      Left            =   9000
      MaxLength       =   2
      TabIndex        =   12
      Top             =   360
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   1
      Left            =   3360
      MaxLength       =   2
      TabIndex        =   7
      Top             =   4920
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   0
      Left            =   3360
      MaxLength       =   2
      TabIndex        =   3
      Top             =   3240
      Width           =   375
   End
   Begin VB.CommandButton Command2 
      Caption         =   "BACK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   7560
      TabIndex        =   25
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Caption         =   "NEXT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   8400
      TabIndex        =   26
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton tag500_s 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   6000
      TabIndex        =   24
      Top             =   7080
      Width           =   1455
   End
   Begin VB.CommandButton tag500_q 
      Caption         =   "QUIT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   4440
      TabIndex        =   23
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox tag586_1 
      Height          =   315
      Left            =   8520
      TabIndex        =   21
      Top             =   5400
      Width           =   2775
   End
   Begin VB.TextBox tag546_1 
      Height          =   315
      Left            =   8520
      TabIndex        =   20
      Top             =   4440
      Width           =   2775
   End
   Begin VB.TextBox tag536_4 
      Height          =   315
      Left            =   8520
      TabIndex        =   19
      Top             =   3480
      Width           =   2775
   End
   Begin VB.TextBox tag536_3 
      Height          =   315
      Left            =   8520
      TabIndex        =   18
      Top             =   3120
      Width           =   2775
   End
   Begin VB.TextBox tag536_2 
      Height          =   315
      Left            =   8520
      TabIndex        =   17
      Top             =   2760
      Width           =   2775
   End
   Begin VB.TextBox tag536_1 
      Height          =   315
      Left            =   8520
      TabIndex        =   16
      Top             =   2400
      Width           =   2775
   End
   Begin VB.TextBox tag520_3 
      Height          =   315
      Left            =   8520
      TabIndex        =   15
      Top             =   1560
      Width           =   2775
   End
   Begin VB.TextBox tag520_2 
      Height          =   315
      Left            =   8520
      TabIndex        =   14
      Top             =   1200
      Width           =   2775
   End
   Begin VB.TextBox tag520_1 
      Height          =   315
      Left            =   8520
      TabIndex        =   13
      Top             =   840
      Width           =   2775
   End
   Begin VB.TextBox tag510_4 
      Height          =   315
      Left            =   2760
      TabIndex        =   11
      Top             =   6480
      Width           =   2775
   End
   Begin VB.TextBox tag510_3 
      Height          =   315
      Left            =   2760
      TabIndex        =   10
      Top             =   6120
      Width           =   2775
   End
   Begin VB.TextBox tag510_2 
      Height          =   315
      Left            =   2760
      TabIndex        =   9
      Top             =   5760
      Width           =   2775
   End
   Begin VB.TextBox tag510_1 
      Height          =   315
      Left            =   2760
      TabIndex        =   8
      Top             =   5400
      Width           =   2775
   End
   Begin VB.TextBox tag505_3 
      Height          =   315
      Left            =   2640
      TabIndex        =   6
      Top             =   4440
      Width           =   2775
   End
   Begin VB.TextBox tag505_2 
      Height          =   315
      Left            =   2640
      TabIndex        =   5
      Top             =   4080
      Width           =   2775
   End
   Begin VB.TextBox tag505_1 
      Height          =   315
      Left            =   2640
      TabIndex        =   4
      Top             =   3720
      Width           =   2775
   End
   Begin VB.TextBox tag502_1 
      Height          =   315
      Left            =   2640
      TabIndex        =   2
      Top             =   2640
      Width           =   2775
   End
   Begin VB.TextBox tag501_1 
      Height          =   315
      Left            =   2640
      TabIndex        =   1
      Top             =   1680
      Width           =   2775
   End
   Begin VB.TextBox tag500_1 
      Height          =   315
      Left            =   2640
      TabIndex        =   0
      Top             =   720
      Width           =   2775
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   9600
      TabIndex        =   57
      Top             =   360
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3960
      TabIndex        =   56
      Top             =   4920
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3960
      TabIndex        =   55
      Top             =   3240
      Width           =   855
   End
   Begin VB.Label Label26 
      Caption         =   "�����˵�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   54
      Top             =   4440
      Width           =   2295
   End
   Begin VB.Label Label25 
      Caption         =   "�����˵��ҧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   53
      Top             =   5400
      Width           =   2295
   End
   Begin VB.Label Label24 
      Caption         =   "�����Ţ�ç���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   52
      Top             =   3480
      Width           =   2295
   End
   Begin VB.Label Label23 
      Caption         =   "�����Ţ�͡���˹��§ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   51
      Top             =   3120
      Width           =   2535
   End
   Begin VB.Label Label22 
      Caption         =   "�����Ţ˹ѧ����ѭ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   50
      Top             =   2760
      Width           =   2415
   End
   Begin VB.Label Label21 
      Caption         =   "�����˵طع ,ʹѺʹع"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   49
      Top             =   2400
      Width           =   2535
   End
   Begin VB.Label Label20 
      Caption         =   "�к��ѡɳ���ʴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   48
      Top             =   1560
      Width           =   2295
   End
   Begin VB.Label Label19 
      Caption         =   "��â�������ͧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   47
      Top             =   1200
      Width           =   2415
   End
   Begin VB.Label Label18 
      Caption         =   "����ͧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   46
      Top             =   840
      Width           =   1695
   End
   Begin VB.Label Label17 
      Caption         =   "�Ţ�ҵðҹ ISSN"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   45
      Top             =   6480
      Width           =   2175
   End
   Begin VB.Label Label16 
      Caption         =   "���˹觢ͧ���觢�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   44
      Top             =   6120
      Width           =   2295
   End
   Begin VB.Label Label15 
      Caption         =   "�ѹ���ѹ�֡���駷��ͧ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   43
      Top             =   5760
      Width           =   2415
   End
   Begin VB.Label Label14 
      Caption         =   "�������觢�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   42
      Top             =   5400
      Width           =   1695
   End
   Begin VB.Label Label13 
      Caption         =   "����駤����Ѻ�Դ�ͺ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   41
      Top             =   4440
      Width           =   2295
   End
   Begin VB.Label Label12 
      Caption         =   "����������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   40
      Top             =   4080
      Width           =   1695
   End
   Begin VB.Label Label11 
      Caption         =   "�����˵���úѭ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   39
      Top             =   3720
      Width           =   1695
   End
   Begin VB.Label Label10 
      Caption         =   "�����˵��Է�ҹԾ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   38
      Top             =   2640
      Width           =   2175
   End
   Begin VB.Label Label9 
      Caption         =   "�����˵� ""���������"""
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   37
      Top             =   1680
      Width           =   2295
   End
   Begin VB.Label Label8 
      Caption         =   "586 �����˵��ҧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   36
      Top             =   5040
      Width           =   3615
   End
   Begin VB.Label Label7 
      Caption         =   "546 �����˵�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   35
      Top             =   4080
      Width           =   3615
   End
   Begin VB.Label Label6 
      Caption         =   "536 �����˵ت��ͷع��������ʹѺʹع"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   34
      Top             =   2040
      Width           =   4455
   End
   Begin VB.Label Label5 
      Caption         =   "520 �����˵���ػ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   33
      Top             =   360
      Width           =   2655
   End
   Begin VB.Label Label4 
      Caption         =   "510 �����˵���ҧ�ԧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   32
      Top             =   4920
      Width           =   2655
   End
   Begin VB.Label Label3 
      Caption         =   "505 �����˵���úѭ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   31
      Top             =   3240
      Width           =   2655
   End
   Begin VB.Label Label2 
      Caption         =   "502 �����˵��Է�ҹԾ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   30
      Top             =   2280
      Width           =   3615
   End
   Begin VB.Label Label1 
      Caption         =   "501 �����˵ؾ��������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   29
      Top             =   1320
      Width           =   3615
   End
   Begin VB.Label Label43 
      Caption         =   "500 �����˵�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   28
      Top             =   360
      Width           =   3615
   End
   Begin VB.Label Label71 
      Caption         =   "�����˵ط����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   27
      Top             =   720
      Width           =   1695
   End
End
Attribute VB_Name = "tag500"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
tagselect.Command8.SetFocus
tag600.Show

End Sub

Private Sub Command2_Click()
tagselect.Command6.SetFocus
tag250.Show

End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag500_q_Click()
MarcMenu.quitting
End Sub

Private Sub tag500_s_Click()
MarcMenu.saving
End Sub
