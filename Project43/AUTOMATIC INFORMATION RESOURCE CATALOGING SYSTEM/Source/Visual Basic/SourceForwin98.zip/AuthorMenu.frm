VERSION 5.00
Begin VB.Form AuthorMenu 
   BackColor       =   &H8000000E&
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Author Code Program"
   ClientHeight    =   6090
   ClientLeft      =   1215
   ClientTop       =   1350
   ClientWidth     =   8805
   Icon            =   "AuthorMenu.frx":0000
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6090
   ScaleWidth      =   8805
   StartUpPosition =   2  'CenterScreen
   Begin VB.Image Image2 
      Height          =   945
      Left            =   360
      Picture         =   "AuthorMenu.frx":110A
      Top             =   480
      Width           =   8925
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   5
      Left            =   720
      Picture         =   "AuthorMenu.frx":3E85
      Stretch         =   -1  'True
      Top             =   1920
      Width           =   2325
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��Ѻ��ѧ������ѡ"
      DragIcon        =   "AuthorMenu.frx":5784
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   3600
      TabIndex        =   3
      Top             =   4800
      Width           =   1935
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "�ʴ��ҹ�������Ţ�����˹ѧ���"
      DragIcon        =   "AuthorMenu.frx":5A8E
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3600
      TabIndex        =   2
      Top             =   3960
      Width           =   3375
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   " ������Ѵ����Ţ�����˹ѧ��� (�ѧ���)"
      DragIcon        =   "AuthorMenu.frx":5D98
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3480
      TabIndex        =   1
      Top             =   3120
      Width           =   4455
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "������Ѵ����Ţ�����˹ѧ��� (��)"
      DragIcon        =   "AuthorMenu.frx":60A2
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   3600
      TabIndex        =   0
      Top             =   2280
      Width           =   4095
   End
End
Attribute VB_Name = "AuthorMenu"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Label1_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If Source Is Label1(Index) Then
        With Label1(Index)
            .Font.Underline = False
            .ForeColor = vbBlack
            Screen.MousePointer = vbHourglass
            
            Select Case Index
            Case 0
                AuthorThai.Show
            Case 1
                AuthorEng.Show
            Case 2
               Authorcode_show.Show
            Case 3
               Main.Visible = True
               Unload Me
            End Select
            Screen.MousePointer = vbNormal
        End With
    End If

End Sub

Private Sub Label1_DragOver(Index As Integer, Source As Control, X As Single, Y As Single, State As Integer)
If State = vbLeave Then
        With Label1(Index)
            .Drag vbEndDrag
            .Font.Underline = False
            .ForeColor = vbBlack
          '  Image1(0).Picture = Image1(5).Picture
         
        End With
    End If

End Sub

Private Sub Label1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
With Label1(Index)
        .ForeColor = vbBlue
        .Font.Underline = True
        .Drag vbBeginDrag
        'Image1(0).Picture = Image1(Index + 1).Picture

    End With
End Sub
