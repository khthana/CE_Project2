VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form tag800 
   Caption         =   "tag800"
   ClientHeight    =   7860
   ClientLeft      =   90
   ClientTop       =   1065
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin TabDlg.SSTab SSTab1 
      Height          =   8265
      Left            =   0
      TabIndex        =   49
      Top             =   0
      Width           =   12000
      _ExtentX        =   21167
      _ExtentY        =   14579
      _Version        =   393216
      Tabs            =   2
      TabsPerRow      =   2
      TabHeight       =   520
      TabCaption(0)   =   "Tag800-Tag810"
      TabPicture(0)   =   "tag800.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Label2"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "Label3"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Label4"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).Control(3)=   "Label5"
      Tab(0).Control(3).Enabled=   0   'False
      Tab(0).Control(4)=   "Label6"
      Tab(0).Control(4).Enabled=   0   'False
      Tab(0).Control(5)=   "Label7"
      Tab(0).Control(5).Enabled=   0   'False
      Tab(0).Control(6)=   "Label1(0)"
      Tab(0).Control(6).Enabled=   0   'False
      Tab(0).Control(7)=   "Label8"
      Tab(0).Control(7).Enabled=   0   'False
      Tab(0).Control(8)=   "Label9"
      Tab(0).Control(8).Enabled=   0   'False
      Tab(0).Control(9)=   "Label11"
      Tab(0).Control(9).Enabled=   0   'False
      Tab(0).Control(10)=   "Label12"
      Tab(0).Control(10).Enabled=   0   'False
      Tab(0).Control(11)=   "Label13"
      Tab(0).Control(11).Enabled=   0   'False
      Tab(0).Control(12)=   "Label14"
      Tab(0).Control(12).Enabled=   0   'False
      Tab(0).Control(13)=   "Label15"
      Tab(0).Control(13).Enabled=   0   'False
      Tab(0).Control(14)=   "Label18"
      Tab(0).Control(14).Enabled=   0   'False
      Tab(0).Control(15)=   "Label19"
      Tab(0).Control(15).Enabled=   0   'False
      Tab(0).Control(16)=   "Label20"
      Tab(0).Control(16).Enabled=   0   'False
      Tab(0).Control(17)=   "Label10"
      Tab(0).Control(17).Enabled=   0   'False
      Tab(0).Control(18)=   "Label16"
      Tab(0).Control(18).Enabled=   0   'False
      Tab(0).Control(19)=   "Label1(1)"
      Tab(0).Control(19).Enabled=   0   'False
      Tab(0).Control(20)=   "Label1(2)"
      Tab(0).Control(20).Enabled=   0   'False
      Tab(0).Control(21)=   "tag800_5"
      Tab(0).Control(21).Enabled=   0   'False
      Tab(0).Control(22)=   "tag800_1"
      Tab(0).Control(22).Enabled=   0   'False
      Tab(0).Control(23)=   "tag800_2"
      Tab(0).Control(23).Enabled=   0   'False
      Tab(0).Control(24)=   "tag800_3"
      Tab(0).Control(24).Enabled=   0   'False
      Tab(0).Control(25)=   "tag800_4"
      Tab(0).Control(25).Enabled=   0   'False
      Tab(0).Control(26)=   "tag800_7"
      Tab(0).Control(26).Enabled=   0   'False
      Tab(0).Control(27)=   "tag800_6"
      Tab(0).Control(27).Enabled=   0   'False
      Tab(0).Control(28)=   "tag810_5"
      Tab(0).Control(28).Enabled=   0   'False
      Tab(0).Control(29)=   "tag810_1"
      Tab(0).Control(29).Enabled=   0   'False
      Tab(0).Control(30)=   "tag810_2"
      Tab(0).Control(30).Enabled=   0   'False
      Tab(0).Control(31)=   "tag810_3"
      Tab(0).Control(31).Enabled=   0   'False
      Tab(0).Control(32)=   "tag810_4"
      Tab(0).Control(32).Enabled=   0   'False
      Tab(0).Control(33)=   "tag810_6"
      Tab(0).Control(33).Enabled=   0   'False
      Tab(0).Control(34)=   "tag810_7"
      Tab(0).Control(34).Enabled=   0   'False
      Tab(0).Control(35)=   "tag810_8"
      Tab(0).Control(35).Enabled=   0   'False
      Tab(0).Control(36)=   "tag810_9"
      Tab(0).Control(36).Enabled=   0   'False
      Tab(0).Control(37)=   "tag810_10"
      Tab(0).Control(37).Enabled=   0   'False
      Tab(0).Control(38)=   "tag800_q1"
      Tab(0).Control(38).Enabled=   0   'False
      Tab(0).Control(39)=   "tag800_s1"
      Tab(0).Control(39).Enabled=   0   'False
      Tab(0).Control(40)=   "Command1"
      Tab(0).Control(40).Enabled=   0   'False
      Tab(0).Control(41)=   "indicator(0)"
      Tab(0).Control(41).Enabled=   0   'False
      Tab(0).Control(42)=   "indicator(1)"
      Tab(0).Control(42).Enabled=   0   'False
      Tab(0).Control(43)=   "Newcmd"
      Tab(0).Control(43).Enabled=   0   'False
      Tab(0).ControlCount=   44
      TabCaption(1)   =   "Tag811-Tag850"
      TabPicture(1)   =   "tag800.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Command2"
      Tab(1).Control(1)=   "indicator(3)"
      Tab(1).Control(2)=   "indicator(2)"
      Tab(1).Control(3)=   "Command4"
      Tab(1).Control(4)=   "tag800_s2"
      Tab(1).Control(5)=   "tag800_q2"
      Tab(1).Control(6)=   "tag850_1"
      Tab(1).Control(7)=   "tag830_4"
      Tab(1).Control(8)=   "tag830_3"
      Tab(1).Control(9)=   "tag830_2"
      Tab(1).Control(10)=   "tag830_1"
      Tab(1).Control(11)=   "tag830_6"
      Tab(1).Control(12)=   "tag830_5"
      Tab(1).Control(13)=   "tag830_7"
      Tab(1).Control(14)=   "tag830_9"
      Tab(1).Control(15)=   "tag830_8"
      Tab(1).Control(16)=   "tag811_10"
      Tab(1).Control(17)=   "tag811_8"
      Tab(1).Control(18)=   "tag811_4"
      Tab(1).Control(19)=   "tag811_3"
      Tab(1).Control(20)=   "tag811_2"
      Tab(1).Control(21)=   "tag811_1"
      Tab(1).Control(22)=   "tag811_6"
      Tab(1).Control(23)=   "tag811_7"
      Tab(1).Control(24)=   "tag811_9"
      Tab(1).Control(25)=   "tag811_5"
      Tab(1).Control(26)=   "Label1(4)"
      Tab(1).Control(27)=   "Label1(3)"
      Tab(1).Control(28)=   "Label23"
      Tab(1).Control(29)=   "Label22"
      Tab(1).Control(30)=   "Label39"
      Tab(1).Control(31)=   "Label40"
      Tab(1).Control(32)=   "Label41"
      Tab(1).Control(33)=   "Label42"
      Tab(1).Control(34)=   "Label43"
      Tab(1).Control(35)=   "Label44"
      Tab(1).Control(36)=   "Label46"
      Tab(1).Control(37)=   "Label49"
      Tab(1).Control(38)=   "Label52"
      Tab(1).Control(39)=   "Label53"
      Tab(1).Control(40)=   "Label21"
      Tab(1).Control(41)=   "Label17"
      Tab(1).Control(42)=   "Label28"
      Tab(1).Control(43)=   "Label29"
      Tab(1).Control(44)=   "Label30"
      Tab(1).Control(45)=   "Label31"
      Tab(1).Control(46)=   "Label32"
      Tab(1).Control(47)=   "Label33"
      Tab(1).Control(48)=   "Label34"
      Tab(1).Control(49)=   "Label35"
      Tab(1).Control(50)=   "Label36"
      Tab(1).ControlCount=   51
      Begin VB.CommandButton Command2 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -72000
         TabIndex        =   45
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton Newcmd 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3480
         TabIndex        =   19
         Top             =   7080
         Width           =   1455
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   3
         Left            =   -64800
         MaxLength       =   2
         TabIndex        =   34
         Top             =   720
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   2
         Left            =   -71040
         MaxLength       =   2
         TabIndex        =   23
         Top             =   720
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   1
         Left            =   9720
         MaxLength       =   2
         TabIndex        =   8
         Top             =   600
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   0
         Left            =   3720
         MaxLength       =   2
         TabIndex        =   0
         Top             =   600
         Width           =   375
      End
      Begin VB.CommandButton Command4 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -67320
         TabIndex        =   48
         Top             =   7080
         Width           =   1575
      End
      Begin VB.CommandButton Command1 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   8160
         TabIndex        =   22
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag800_s2 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -68880
         TabIndex        =   47
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag800_q2 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -70440
         TabIndex        =   46
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag800_s1 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   6600
         TabIndex        =   21
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag800_q1 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   5040
         TabIndex        =   20
         Top             =   7080
         Width           =   1455
      End
      Begin VB.TextBox tag850_1 
         Height          =   315
         Left            =   -66000
         TabIndex        =   44
         Top             =   5160
         Width           =   2775
      End
      Begin VB.TextBox tag830_4 
         Height          =   315
         Left            =   -66000
         TabIndex        =   38
         Top             =   2280
         Width           =   2775
      End
      Begin VB.TextBox tag830_3 
         Height          =   315
         Left            =   -66000
         TabIndex        =   37
         Top             =   1920
         Width           =   2775
      End
      Begin VB.TextBox tag830_2 
         Height          =   315
         Left            =   -66000
         TabIndex        =   36
         Top             =   1560
         Width           =   2775
      End
      Begin VB.TextBox tag830_1 
         Height          =   315
         Left            =   -66000
         TabIndex        =   35
         Top             =   1200
         Width           =   2775
      End
      Begin VB.TextBox tag830_6 
         Height          =   315
         Left            =   -66000
         TabIndex        =   40
         Top             =   3000
         Width           =   2775
      End
      Begin VB.TextBox tag830_5 
         Height          =   315
         Left            =   -66000
         TabIndex        =   39
         Top             =   2640
         Width           =   2775
      End
      Begin VB.TextBox tag830_7 
         Height          =   315
         Left            =   -66000
         TabIndex        =   41
         Top             =   3360
         Width           =   2775
      End
      Begin VB.TextBox tag830_9 
         Height          =   315
         Left            =   -66000
         TabIndex        =   43
         Top             =   4080
         Width           =   2775
      End
      Begin VB.TextBox tag830_8 
         Height          =   315
         Left            =   -66000
         TabIndex        =   42
         Top             =   3720
         Width           =   2775
      End
      Begin VB.TextBox tag811_10 
         Height          =   315
         Left            =   -71880
         TabIndex        =   33
         Top             =   4440
         Width           =   2775
      End
      Begin VB.TextBox tag811_8 
         Height          =   315
         Left            =   -71280
         TabIndex        =   31
         Top             =   3720
         Width           =   2175
      End
      Begin VB.TextBox tag811_4 
         Height          =   315
         Left            =   -71880
         TabIndex        =   27
         Top             =   2280
         Width           =   2775
      End
      Begin VB.TextBox tag811_3 
         Height          =   315
         Left            =   -71880
         TabIndex        =   26
         Top             =   1920
         Width           =   2775
      End
      Begin VB.TextBox tag811_2 
         Height          =   315
         Left            =   -71880
         TabIndex        =   25
         Top             =   1560
         Width           =   2775
      End
      Begin VB.TextBox tag811_1 
         Height          =   315
         Left            =   -71880
         TabIndex        =   24
         Top             =   1200
         Width           =   2775
      End
      Begin VB.TextBox tag811_6 
         Height          =   315
         Left            =   -70560
         TabIndex        =   29
         Top             =   3000
         Width           =   1455
      End
      Begin VB.TextBox tag811_7 
         Height          =   315
         Left            =   -71880
         TabIndex        =   30
         Top             =   3360
         Width           =   2775
      End
      Begin VB.TextBox tag811_9 
         Height          =   315
         Left            =   -71880
         TabIndex        =   32
         Top             =   4080
         Width           =   2775
      End
      Begin VB.TextBox tag811_5 
         Height          =   315
         Left            =   -71880
         TabIndex        =   28
         Top             =   2640
         Width           =   2775
      End
      Begin VB.TextBox tag810_10 
         Height          =   315
         Left            =   9000
         TabIndex        =   18
         Top             =   4320
         Width           =   2775
      End
      Begin VB.TextBox tag810_9 
         Height          =   315
         Left            =   9000
         TabIndex        =   17
         Top             =   3960
         Width           =   2775
      End
      Begin VB.TextBox tag810_8 
         Height          =   315
         Left            =   9000
         TabIndex        =   16
         Top             =   3600
         Width           =   2775
      End
      Begin VB.TextBox tag810_7 
         Height          =   315
         Left            =   10320
         TabIndex        =   15
         Top             =   3240
         Width           =   1455
      End
      Begin VB.TextBox tag810_6 
         Height          =   315
         Left            =   9000
         TabIndex        =   14
         Top             =   2880
         Width           =   2775
      End
      Begin VB.TextBox tag810_4 
         Height          =   315
         Left            =   9000
         TabIndex        =   12
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag810_3 
         Height          =   315
         Left            =   9000
         TabIndex        =   11
         Top             =   1800
         Width           =   2775
      End
      Begin VB.TextBox tag810_2 
         Height          =   315
         Left            =   9000
         TabIndex        =   10
         Top             =   1440
         Width           =   2775
      End
      Begin VB.TextBox tag810_1 
         Height          =   315
         Left            =   9000
         TabIndex        =   9
         Top             =   1080
         Width           =   2775
      End
      Begin VB.TextBox tag810_5 
         Height          =   315
         Left            =   9360
         TabIndex        =   13
         Top             =   2520
         Width           =   2415
      End
      Begin VB.TextBox tag800_6 
         Height          =   315
         Left            =   3120
         TabIndex        =   6
         Top             =   2880
         Width           =   2775
      End
      Begin VB.TextBox tag800_7 
         Height          =   315
         Left            =   3120
         TabIndex        =   7
         Top             =   3240
         Width           =   2775
      End
      Begin VB.TextBox tag800_4 
         Height          =   315
         Left            =   3120
         TabIndex        =   4
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag800_3 
         Height          =   315
         Left            =   3120
         TabIndex        =   3
         Top             =   1800
         Width           =   2775
      End
      Begin VB.TextBox tag800_2 
         Height          =   315
         Left            =   3120
         TabIndex        =   2
         Top             =   1440
         Width           =   2775
      End
      Begin VB.TextBox tag800_1 
         Height          =   315
         Left            =   3120
         TabIndex        =   1
         Top             =   1080
         Width           =   2775
      End
      Begin VB.TextBox tag800_5 
         Height          =   315
         Left            =   3120
         TabIndex        =   5
         Top             =   2520
         Width           =   2775
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   4
         Left            =   -64320
         TabIndex        =   95
         Top             =   720
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   3
         Left            =   -70440
         TabIndex        =   94
         Top             =   720
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   2
         Left            =   10320
         TabIndex        =   93
         Top             =   600
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   1
         Left            =   4320
         TabIndex        =   92
         Top             =   600
         Width           =   855
      End
      Begin VB.Label Label23 
         Caption         =   "����ʶҺѹ�������觾����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   91
         Top             =   5160
         Width           =   3135
      End
      Begin VB.Label Label22 
         Caption         =   "850 ����ʶҺѹ�������觾����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   90
         Top             =   4800
         Width           =   5055
      End
      Begin VB.Label Label39 
         Caption         =   "��ǹ��Сͺ���¢ͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   89
         Top             =   2280
         Width           =   2775
      End
      Begin VB.Label Label40 
         Caption         =   "�վ����ͧ��������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   88
         Top             =   1920
         Width           =   3135
      End
      Begin VB.Label Label41 
         Caption         =   "�շ��ŧ���ʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   87
         Top             =   1560
         Width           =   2415
      End
      Begin VB.Label Label42 
         Caption         =   "��������ͧẺ��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   86
         Top             =   1200
         Width           =   3135
      End
      Begin VB.Label Label43 
         Caption         =   "830 ��¡���������ͪش��������ͧẺ��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   85
         Top             =   720
         Width           =   5055
      End
      Begin VB.Label Label44 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   84
         Top             =   3000
         Width           =   4455
      End
      Begin VB.Label Label46 
         Caption         =   "���Ңͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   83
         Top             =   2640
         Width           =   2415
      End
      Begin VB.Label Label49 
         Caption         =   "���͵͹/��ǹ�ͧ��������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   82
         Top             =   3360
         Width           =   2775
      End
      Begin VB.Label Label52 
         Caption         =   "�Ţ�к�����/�ӴѺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   81
         Top             =   4080
         Width           =   2415
      End
      Begin VB.Label Label53 
         Caption         =   "��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   80
         Top             =   3720
         Width           =   1935
      End
      Begin VB.Label Label21 
         Caption         =   "�����Ţ�ش"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   79
         Top             =   4440
         Width           =   3135
      End
      Begin VB.Label Label17 
         Caption         =   "���͡�û�Ъ���������ѧ��¡�ùԵԺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   78
         Top             =   3720
         Width           =   3735
      End
      Begin VB.Label Label28 
         Caption         =   "��¡���ͧ�������͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   77
         Top             =   2280
         Width           =   2895
      End
      Begin VB.Label Label29 
         Caption         =   "�շ��Ѵ��Ъ��/��ʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   76
         Top             =   1920
         Width           =   3135
      End
      Begin VB.Label Label30 
         Caption         =   "����ʶҹ�����Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   75
         Top             =   1560
         Width           =   2415
      End
      Begin VB.Label Label31 
         Caption         =   "���͹ԵԺؤ�����ͪ��͵��������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   74
         Top             =   1200
         Width           =   3135
      End
      Begin VB.Label Label32 
         Caption         =   "811 ��¡���������ͪش���͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   73
         Top             =   720
         Width           =   4455
      End
      Begin VB.Label Label33 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   72
         Top             =   3000
         Width           =   4455
      End
      Begin VB.Label Label34 
         Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   71
         Top             =   3360
         Width           =   2535
      End
      Begin VB.Label Label35 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   70
         Top             =   4080
         Width           =   2775
      End
      Begin VB.Label Label36 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   69
         Top             =   2640
         Width           =   3255
      End
      Begin VB.Label Label16 
         Caption         =   "�Ţ�к�����/�ӴѺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   68
         Top             =   4320
         Width           =   2775
      End
      Begin VB.Label Label10 
         Caption         =   "��������ͧ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   67
         Top             =   3960
         Width           =   2775
      End
      Begin VB.Label Label20 
         Caption         =   "���͵͹�ͧ�ҹ/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   66
         Top             =   3600
         Width           =   2775
      End
      Begin VB.Label Label19 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   65
         Top             =   3240
         Width           =   4335
      End
      Begin VB.Label Label18 
         Caption         =   "��������§ҹ����ٻẺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   64
         Top             =   2880
         Width           =   2655
      End
      Begin VB.Label Label15 
         Caption         =   "�շ���Ъ��/�բͧʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   63
         Top             =   2160
         Width           =   2775
      End
      Begin VB.Label Label14 
         Caption         =   "ʶҹ���Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   62
         Top             =   1800
         Width           =   3135
      End
      Begin VB.Label Label13 
         Caption         =   "����˹��§ҹ�ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   61
         Top             =   1440
         Width           =   2415
      End
      Begin VB.Label Label12 
         Caption         =   "���͹ԵԺؤ�����ͪ��͵��������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   60
         Top             =   1080
         Width           =   3135
      End
      Begin VB.Label Label11 
         Caption         =   "810 ��¡���������ͪش���͹ԵԺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   59
         Top             =   600
         Width           =   5055
      End
      Begin VB.Label Label9 
         Caption         =   "���кؤ�������ѹ��ԵԺؤ�šѺ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   58
         Top             =   2520
         Width           =   3255
      End
      Begin VB.Label Label8 
         Caption         =   "��������ͧ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   57
         Top             =   2880
         Width           =   2775
      End
      Begin VB.Label Label1 
         Caption         =   "�Ţ�к�����/�ӴѺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   56
         Top             =   3240
         Width           =   2415
      End
      Begin VB.Label Label7 
         Caption         =   "���Դ �յ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   55
         Top             =   2160
         Width           =   2775
      End
      Begin VB.Label Label6 
         Caption         =   "���˹� �� ��ô��ѡ��� �������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   54
         Top             =   1800
         Width           =   3015
      End
      Begin VB.Label Label5 
         Caption         =   "�Ţ���ѹ�����ѧ���͵�"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   53
         Top             =   1440
         Width           =   2415
      End
      Begin VB.Label Label4 
         Caption         =   "���ͺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   52
         Top             =   1080
         Width           =   3135
      End
      Begin VB.Label Label3 
         Caption         =   "800  ��¡���������ͪش���ͺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   51
         Top             =   600
         Width           =   3735
      End
      Begin VB.Label Label2 
         Caption         =   "�������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   50
         Top             =   2520
         Width           =   2415
      End
   End
End
Attribute VB_Name = "tag800"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
tagselect.Command9.SetFocus
tag700.Show

End Sub

Private Sub Command2_Click()
MarcMenu.newedit
End Sub

Private Sub Command4_Click()
tagselect.Command9.SetFocus
tag700.Show

End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag800_q1_Click()
MarcMenu.quitting
End Sub

Private Sub tag800_q2_Click()
MarcMenu.quitting
End Sub

Private Sub tag800_s1_Click()
MarcMenu.saving
End Sub

Private Sub tag800_s2_Click()
MarcMenu.saving
End Sub
