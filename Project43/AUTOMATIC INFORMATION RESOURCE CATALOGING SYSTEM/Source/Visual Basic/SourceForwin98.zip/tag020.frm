VERSION 5.00
Begin VB.Form tag020 
   Caption         =   "tag020"
   ClientHeight    =   7845
   ClientLeft      =   45
   ClientTop       =   1065
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7845
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton Newcmd 
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2880
      TabIndex        =   7
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Left            =   7440
      MaxLength       =   2
      TabIndex        =   3
      Top             =   4080
      Width           =   375
   End
   Begin VB.CommandButton Command1 
      Caption         =   "BACK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   7680
      TabIndex        =   10
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton Command3 
      Caption         =   "NEXT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   8520
      TabIndex        =   11
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton tag020_s 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   6120
      TabIndex        =   9
      Top             =   7080
      Width           =   1455
   End
   Begin VB.CommandButton tag020_q 
      Caption         =   "QUIT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   4560
      TabIndex        =   8
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox tag022_1 
      Height          =   375
      Left            =   7440
      TabIndex        =   4
      Top             =   4560
      Width           =   1215
   End
   Begin VB.TextBox tag020_1 
      Height          =   375
      Left            =   7440
      TabIndex        =   0
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox tag020_2 
      Height          =   375
      Left            =   7440
      TabIndex        =   1
      Top             =   2040
      Width           =   1215
   End
   Begin VB.TextBox tag020_3 
      Height          =   375
      Left            =   7440
      TabIndex        =   2
      Top             =   2520
      Width           =   1215
   End
   Begin VB.TextBox tag022_3 
      Height          =   375
      Left            =   7440
      TabIndex        =   6
      Top             =   5520
      Width           =   1215
   End
   Begin VB.TextBox tag022_2 
      Height          =   375
      Left            =   7440
      TabIndex        =   5
      Top             =   5040
      Width           =   1215
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8040
      TabIndex        =   20
      Top             =   4080
      Width           =   855
   End
   Begin VB.Label Label30 
      Caption         =   "�Ţ�ҵðҹ�ҡŻ�Ш�˹ѧ��� (ISBN)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   2280
      TabIndex        =   19
      Top             =   1560
      Width           =   3975
   End
   Begin VB.Label Label29 
      Caption         =   "ISSN"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   18
      Top             =   4560
      Width           =   3615
   End
   Begin VB.Label Label15 
      Caption         =   "�Ҥ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   17
      Top             =   2040
      Width           =   2775
   End
   Begin VB.Label Label61 
      Caption         =   "�Ţ�ҵðҹ�ҡŻ�Ш�˹ѧ��ͷ��¡��ԡ/���١��ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   16
      Top             =   2520
      Width           =   5055
   End
   Begin VB.Label Label62 
      Caption         =   "Canceled  ISSN"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   15
      Top             =   5520
      Width           =   2415
   End
   Begin VB.Label Label63 
      Caption         =   "Incorrect  ISSN"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   14
      Top             =   5040
      Width           =   2175
   End
   Begin VB.Label Label64 
      Caption         =   "Tag 020 �Ţ�ҵðҹ�ҡŻ�Ш�˹ѧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   13
      Top             =   1080
      Width           =   4695
   End
   Begin VB.Label Label65 
      Caption         =   "Tag 022 ISSN"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2280
      TabIndex        =   12
      Top             =   4080
      Width           =   2775
   End
End
Attribute VB_Name = "tag020"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
tagselect.Command1.SetFocus
tag008.Show

End Sub

Private Sub Command3_Click()
tagselect.Command3.SetFocus
tag090.Show

End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag020_q_Click()
MarcMenu.quitting
End Sub



Private Sub tag020_s_Click()
MarcMenu.saving
End Sub
