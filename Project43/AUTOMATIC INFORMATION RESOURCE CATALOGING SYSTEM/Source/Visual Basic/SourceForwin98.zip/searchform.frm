VERSION 5.00
Object = "{00028C01-0000-0000-0000-000000000046}#1.0#0"; "DBGRID32.OCX"
Begin VB.Form searchform 
   Caption         =   "searchform"
   ClientHeight    =   8610
   ClientLeft      =   60
   ClientTop       =   330
   ClientWidth     =   11865
   ControlBox      =   0   'False
   Icon            =   "searchform.frx":0000
   LinkTopic       =   "Form1"
   Moveable        =   0   'False
   ScaleHeight     =   8610
   ScaleWidth      =   11865
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "�ٰҹ�����ŶѴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   9840
      TabIndex        =   8
      Top             =   1680
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.CommandButton quit 
      Caption         =   "Quit"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4920
      TabIndex        =   6
      Top             =   7680
      Width           =   2175
   End
   Begin VB.Data Data1 
      Caption         =   "Data1"
      Connect         =   "Access"
      DatabaseName    =   ""
      DefaultCursorType=   0  'DefaultCursor
      DefaultType     =   2  'UseODBC
      Exclusive       =   0   'False
      Height          =   495
      Left            =   8160
      Options         =   0
      ReadOnly        =   0   'False
      RecordsetType   =   1  'Dynaset
      RecordSource    =   ""
      Top             =   7560
      Visible         =   0   'False
      Width           =   1935
   End
   Begin MSDBGrid.DBGrid DBGrid1 
      Bindings        =   "searchform.frx":110A
      Height          =   4455
      Left            =   1680
      OleObjectBlob   =   "searchform.frx":111E
      TabIndex        =   5
      Top             =   2760
      Width           =   9495
   End
   Begin VB.CommandButton go 
      Caption         =   "�ʴ�������㹰ҹ������"
      Default         =   -1  'True
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   7440
      TabIndex        =   4
      Top             =   1680
      Width           =   2055
   End
   Begin VB.TextBox containtext 
      Height          =   315
      Left            =   4560
      TabIndex        =   3
      Top             =   1800
      Width           =   2655
   End
   Begin VB.ComboBox orderby 
      Height          =   315
      ItemData        =   "searchform.frx":1AF1
      Left            =   2160
      List            =   "searchform.frx":1B01
      TabIndex        =   0
      Text            =   "����˹ѧ���"
      Top             =   1800
      Width           =   1935
   End
   Begin VB.Label Label3 
      Caption         =   "���Ң�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5040
      TabIndex        =   7
      Top             =   600
      Width           =   2295
   End
   Begin VB.Label Label2 
      Caption         =   "����˹ѧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4560
      TabIndex        =   2
      Top             =   1320
      Width           =   1935
   End
   Begin VB.Label Label1 
      Caption         =   "���§�ӴѺ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      TabIndex        =   1
      Top             =   1320
      Width           =   2295
   End
End
Attribute VB_Name = "searchform"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Public marcws1 As Workspace
'Public marcset1 As Recordset
'Public marcdb1 As Database

Public marcws2 As Workspace
Public marcset2 As Recordset
Public marcdb2 As Database

Private Sub Command1_Click()
'If orderby.Text = "����˹ѧ���" Then
 'sqlcommand = "SELECT tagdata1.t20_1 , tagdata1.t245_1 , tagdata2.t600_1 , tagdata2.t600_2 , tagdata2.t600_3 , tagdata2.t600_4 , tagdata2.t600_5 , tagdata2.t600_6 , tagdata2.t600_7 , tagdata2.t600_8 , tagdata2.t600_9 , tagdata2.t600_10 , tagdata2.t600_11"
 'sqlcommand = sqlcommand & ",tagdata2.t610_1 , tagdata2.t610_2 , tagdata2.t610_3 , tagdata2.t610_4 , tagdata2.t610_5 , tagdata2.t610_6 , tagdata2.t610_7 , tagdata2.t610_8 , tagdata2.t610_9 , tagdata2.t610_10 , tagdata2.t610_11 , tagdata2.t610_12 , tagdata2.t610_13 , tagdata2.t610_14"
 'sqlcommand = sqlcommand & ",tagdata2.t611_1 , tagdata2.t611_2 , tagdata2.t611_3 , tagdata2.t611_4 , tagdata2.t611_5 , tagdata2.t611_6 , tagdata2.t611_7 , tagdata2.t611_8 , tagdata2.t611_9 , tagdata2.t611_10"
 'sqlcommand = sqlcommand & ",tagdata2.t630_1 , tagdata2.t630_2 , tagdata2.t630_3 , tagdata2.t630_4 , tagdata2.t630_5 , tagdata2.t630_6 , tagdata2.t630_7 , tagdata2.t630_8 , tagdata2.t630_9 , tagdata2.t630_10 , tagdata2.t630_11 , tagdata2.t630_12 , tagdata2.t630_13 , tagdata2.t630_14 , tagdata2.t630_15 , tagdata2.t630_16 "
 'sqlcommand = sqlcommand & ",tagdata2.t650_1 , tagdata2.t650_2 , tagdata2.t650_3 , tagdata2.t650_4 , tagdata2.t650_5"
 'sqlcommand = sqlcommand & ",tagdata2.t651_1 , tagdata2.t651_2 , tagdata2.t651_3 , tagdata2.t651_4 , tagdata2.t651_5"
 'sqlcommand = sqlcommand & ",tagdata2.t700_1 , tagdata2.t700_2 , tagdata2.t700_3 , tagdata2.t700_4 , tagdata2.t700_5 , tagdata2.t700_6"
 'sqlcommand = sqlcommand & ",tagdata2.t710_1 , tagdata2.t710_2 , tagdata2.t710_3 , tagdata2.t710_4 , tagdata2.t710_5 , tagdata2.t710_6, tagdata2.t710_7, tagdata2.t710_8, tagdata2.t710_9, tagdata2.t710_10, tagdata2.t710_11"
 'sqlcommand = sqlcommand & ",tagdata2.t711_1 , tagdata2.t711_2 , tagdata2.t711_3 , tagdata2.t711_4 , tagdata2.t711_5 , tagdata2.t711_6 , tagdata2.t711_7 , tagdata2.t711_8"
 'sqlcommand = sqlcommand & ",tagdata2.t730_1 , tagdata2.t730_2 , tagdata2.t730_3 , tagdata2.t730_4 , tagdata2.t730_5 , tagdata2.t730_6 , tagdata2.t730_7 , tagdata2.t730_8 , tagdata2.t730_9 , tagdata2.t730_10"
 'sqlcommand = sqlcommand & ",tagdata2.t740_1 , tagdata2.t740_2 , tagdata2.t740_3"
 'sqlcommand = sqlcommand & ",tagdata2.t800_1 , tagdata2.t800_2 , tagdata2.t800_3 , tagdata2.t800_4 , tagdata2.t800_5 , tagdata2.t800_6 , tagdata2.t800_7 "
 'sqlcommand = sqlcommand & ",tagdata2.t810_1 , tagdata2.t810_2 , tagdata2.t810_3 , tagdata2.t810_4 , tagdata2.t810_5 , tagdata2.t810_6 , tagdata2.t810_7 , tagdata2.t810_8 , tagdata2.t810_9 , tagdata2.t810_10 "
 'sqlcommand = sqlcommand & ",tagdata2.t811_1 , tagdata2.t811_2 , tagdata2.t811_3 , tagdata2.t811_4 , tagdata2.t811_5 , tagdata2.t811_6 , tagdata2.t811_7 , tagdata2.t811_8 , tagdata2.t811_9 , tagdata2.t811_10"
 'sqlcommand = sqlcommand & ",tagdata2.t830_1 , tagdata2.t830_2 , tagdata2.t830_3 , tagdata2.t830_4 , tagdata2.t830_5 , tagdata2.t830_6 , tagdata2.t830_7, tagdata2.t830_8 , tagdata2.t830_9"
 'sqlcommand = sqlcommand & ",tagdata2.t850_1"
 'sqlcommand = sqlcommand & " FROM tagdata1 , tagdata2 "
 'sqlcommand = sqlcommand & " WHERE  tagdata1.t245_1  LIKE  "
 'sqlcommand = sqlcommand & " '*" & containtext.Text & "*' "
 'sqlcommand = sqlcommand & " and tagdata1.t020_1 = tagdata2.t020_1"
  'sqlcommand = sqlcommand & " Order by tagdata1.t020_1"
  
 'Set marcset1 = marcdb1.OpenRecordset(sqlcommand, dbOpenSnapshot)
 'Set Data1.Recordset = marcset1
'Else
'If orderby.Text = "���ͼ����" Then
'sqlcommand = "SELECT tagdata1.t20_1 , tagdata1.t245_1 , tagdata2.t600_1 , tagdata2.t600_2 , tagdata2.t600_3 , tagdata2.t600_4 , tagdata2.t600_5 , tagdata2.t600_6 , tagdata2.t600_7 , tagdata2.t600_8 , tagdata2.t600_9 , tagdata2.t600_10 , tagdata2.t600_11"
 'sqlcommand = sqlcommand & ",tagdata2.t610_1 , tagdata2.t610_2 , tagdata2.t610_3 , tagdata2.t610_4 , tagdata2.t610_5 , tagdata2.t610_6 , tagdata2.t610_7 , tagdata2.t610_8 , tagdata2.t610_9 , tagdata2.t610_10 , tagdata2.t610_11 , tagdata2.t610_12 , tagdata2.t610_13 , tagdata2.t610_14"
 'sqlcommand = sqlcommand & ",tagdata2.t611_1 , tagdata2.t611_2 , tagdata2.t611_3 , tagdata2.t611_4 , tagdata2.t611_5 , tagdata2.t611_6 , tagdata2.t611_7 , tagdata2.t611_8 , tagdata2.t611_9 , tagdata2.t611_10"
 'sqlcommand = sqlcommand & ",tagdata2.t630_1 , tagdata2.t630_2 , tagdata2.t630_3 , tagdata2.t630_4 , tagdata2.t630_5 , tagdata2.t630_6 , tagdata2.t630_7 , tagdata2.t630_8 , tagdata2.t630_9 , tagdata2.t630_10 , tagdata2.t630_11 , tagdata2.t630_12 , tagdata2.t630_13 , tagdata2.t630_14 , tagdata2.t630_15 , tagdata2.t630_16 "
 'sqlcommand = sqlcommand & ",tagdata2.t650_1 , tagdata2.t650_2 , tagdata2.t650_3 , tagdata2.t650_4 , tagdata2.t650_5"
 'sqlcommand = sqlcommand & ",tagdata2.t651_1 , tagdata2.t651_2 , tagdata2.t651_3 , tagdata2.t651_4 , tagdata2.t651_5"
 'sqlcommand = sqlcommand & ",tagdata2.t700_1 , tagdata2.t700_2 , tagdata2.t700_3 , tagdata2.t700_4 , tagdata2.t700_5 , tagdata2.t700_6"
 'sqlcommand = sqlcommand & ",tagdata2.t710_1 , tagdata2.t710_2 , tagdata2.t710_3 , tagdata2.t710_4 , tagdata2.t710_5 , tagdata2.t710_6, tagdata2.t710_7, tagdata2.t710_8, tagdata2.t710_9, tagdata2.t710_10, tagdata2.t710_11"
 'sqlcommand = sqlcommand & ",tagdata2.t711_1 , tagdata2.t711_2 , tagdata2.t711_3 , tagdata2.t711_4 , tagdata2.t711_5 , tagdata2.t711_6 , tagdata2.t711_7 , tagdata2.t711_8"
 'sqlcommand = sqlcommand & ",tagdata2.t730_1 , tagdata2.t730_2 , tagdata2.t730_3 , tagdata2.t730_4 , tagdata2.t730_5 , tagdata2.t730_6 , tagdata2.t730_7 , tagdata2.t730_8 , tagdata2.t730_9 , tagdata2.t730_10"
 'sqlcommand = sqlcommand & ",tagdata2.t740_1 , tagdata2.t740_2 , tagdata2.t740_3"
 'sqlcommand = sqlcommand & ",tagdata2.t800_1 , tagdata2.t800_2 , tagdata2.t800_3 , tagdata2.t800_4 , tagdata2.t800_5 , tagdata2.t800_6 , tagdata2.t800_7 "
 'sqlcommand = sqlcommand & ",tagdata2.t810_1 , tagdata2.t810_2 , tagdata2.t810_3 , tagdata2.t810_4 , tagdata2.t810_5 , tagdata2.t810_6 , tagdata2.t810_7 , tagdata2.t810_8 , tagdata2.t810_9 , tagdata2.t810_10 "
 'sqlcommand = sqlcommand & ",tagdata2.t811_1 , tagdata2.t811_2 , tagdata2.t811_3 , tagdata2.t811_4 , tagdata2.t811_5 , tagdata2.t811_6 , tagdata2.t811_7 , tagdata2.t811_8 , tagdata2.t811_9 , tagdata2.t811_10"
 'sqlcommand = sqlcommand & ",tagdata2.t830_1 , tagdata2.t830_2 , tagdata2.t830_3 , tagdata2.t830_4 , tagdata2.t830_5 , tagdata2.t830_6 , tagdata2.t830_7, tagdata2.t830_8 , tagdata2.t830_9"
 'sqlcommand = sqlcommand & ",tagdata2.t850_1"
 'sqlcommand = sqlcommand & " FROM tagdata1 ,tagdata2 "
 'sqlcommand = sqlcommand & "  WHERE  tagdata1.t100_1  LIKE  "
 'sqlcommand = sqlcommand & "'*" & containtext.Text & "*' "
 'sqlcommand = sqlcommand & " and tagdata1.t020_1 = tagdata2.t020_1"
 'sqlcommand = sqlcommand & " Order by tagdata1.t020_1"
 'Set marcset2 = marcdb2.OpenRecordset(sqlcommand, dbOpenSnapshot)
 'Set Data1.Recordset = marcset2
'Else
 'MsgBox "��س����͡��ҨФ��Ҵ�������", vbOKOnly
'End If
'End If
End Sub

Private Sub Form_Load()
On Error GoTo HandleError
'Set marcws1 = DBEngine.Workspaces(0)
'Set marcdb1 = marcws1.OpenDatabase("marcsheetdb.mdb", False, False)

Set marcws2 = DBEngine.Workspaces(0)
Set marcdb2 = marcws2.OpenDatabase("marcsheetdb.mdb", False, False)
Exit Sub
HandleError:
MsgBox Error(Err.Number)
End Sub

Private Sub go_Click()
If orderby.Text = "����˹ѧ���" Then
 sqlcommand = "SELECT  *  FROM tagdata1"
 sqlcommand = sqlcommand & " WHERE  t245_1  LIKE  "
 sqlcommand = sqlcommand & "'*" & containtext.Text & "*' "
 sqlcommand = sqlcommand & " Order by t245_1"
 Set marcset2 = marcdb2.OpenRecordset(sqlcommand, dbOpenSnapshot)
 Set Data1.Recordset = marcset2
Else
If orderby.Text = "���ͼ����" Then
 sqlcommand = "Select * FROM tagdata1"
 sqlcommand = sqlcommand & " WHERE t100_1 LIKE  "
 sqlcommand = sqlcommand & " '*" & containtext.Text & "*' "
  sqlcommand = sqlcommand & " Order by t100_1"
 Set marcset2 = marcdb2.OpenRecordset(sqlcommand, dbOpenSnapshot)
 Set Data1.Recordset = marcset2
 Else
 If orderby.Text = "�Ţ����¹" Then
 sqlcommand = "Select * FROM tagdata1"
 sqlcommand = sqlcommand & " WHERE book_no LIKE  "
 sqlcommand = sqlcommand & " '*" & containtext.Text & "*' "
  sqlcommand = sqlcommand & " Order by book_no"
 Set marcset2 = marcdb2.OpenRecordset(sqlcommand, dbOpenSnapshot)
 Set Data1.Recordset = marcset2
Else
If orderby.Text = "�������ͧ" Then
 sqlcommand = "Select * FROM tagdata1"
 sqlcommand = sqlcommand & " WHERE t090_1 LIKE  "
 sqlcommand = sqlcommand & " '*" & containtext.Text & "*' "
  sqlcommand = sqlcommand & " Order by t090_1"
 Set marcset2 = marcdb2.OpenRecordset(sqlcommand, dbOpenSnapshot)
 Set Data1.Recordset = marcset2
Else
 MsgBox "��س����͡��ҨФ��Ҵ�������", vbOKOnly
End If
End If
End If
End If

End Sub



Private Sub quit_Click()
Unload Me
End Sub
