VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form tag700 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "tag700"
   ClientHeight    =   7860
   ClientLeft      =   90
   ClientTop       =   1110
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin TabDlg.SSTab SSTab1 
      Height          =   8265
      Left            =   0
      TabIndex        =   54
      Top             =   0
      Width           =   12000
      _ExtentX        =   21167
      _ExtentY        =   14579
      _Version        =   393216
      Tabs            =   2
      TabsPerRow      =   2
      TabHeight       =   520
      TabCaption(0)   =   "Tag700-Tag710"
      TabPicture(0)   =   "tag700.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Label1(0)"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "Label2"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Label3"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).Control(3)=   "Label4"
      Tab(0).Control(3).Enabled=   0   'False
      Tab(0).Control(4)=   "Label5"
      Tab(0).Control(4).Enabled=   0   'False
      Tab(0).Control(5)=   "Label6"
      Tab(0).Control(5).Enabled=   0   'False
      Tab(0).Control(6)=   "Label7"
      Tab(0).Control(6).Enabled=   0   'False
      Tab(0).Control(7)=   "Label8"
      Tab(0).Control(7).Enabled=   0   'False
      Tab(0).Control(8)=   "Label9"
      Tab(0).Control(8).Enabled=   0   'False
      Tab(0).Control(9)=   "Label10"
      Tab(0).Control(9).Enabled=   0   'False
      Tab(0).Control(10)=   "Label11"
      Tab(0).Control(10).Enabled=   0   'False
      Tab(0).Control(11)=   "Label12"
      Tab(0).Control(11).Enabled=   0   'False
      Tab(0).Control(12)=   "Label13"
      Tab(0).Control(12).Enabled=   0   'False
      Tab(0).Control(13)=   "Label14"
      Tab(0).Control(13).Enabled=   0   'False
      Tab(0).Control(14)=   "Label15"
      Tab(0).Control(14).Enabled=   0   'False
      Tab(0).Control(15)=   "Label16"
      Tab(0).Control(15).Enabled=   0   'False
      Tab(0).Control(16)=   "Label17"
      Tab(0).Control(16).Enabled=   0   'False
      Tab(0).Control(17)=   "Label18"
      Tab(0).Control(17).Enabled=   0   'False
      Tab(0).Control(18)=   "Label19"
      Tab(0).Control(18).Enabled=   0   'False
      Tab(0).Control(19)=   "Label20"
      Tab(0).Control(19).Enabled=   0   'False
      Tab(0).Control(20)=   "Label1(1)"
      Tab(0).Control(20).Enabled=   0   'False
      Tab(0).Control(21)=   "Label1(2)"
      Tab(0).Control(21).Enabled=   0   'False
      Tab(0).Control(22)=   "tag700_5"
      Tab(0).Control(22).Enabled=   0   'False
      Tab(0).Control(23)=   "tag700_6"
      Tab(0).Control(23).Enabled=   0   'False
      Tab(0).Control(24)=   "tag700_1"
      Tab(0).Control(24).Enabled=   0   'False
      Tab(0).Control(25)=   "tag700_2"
      Tab(0).Control(25).Enabled=   0   'False
      Tab(0).Control(26)=   "tag700_3"
      Tab(0).Control(26).Enabled=   0   'False
      Tab(0).Control(27)=   "tag700_4"
      Tab(0).Control(27).Enabled=   0   'False
      Tab(0).Control(28)=   "tag710_5"
      Tab(0).Control(28).Enabled=   0   'False
      Tab(0).Control(29)=   "tag710_6"
      Tab(0).Control(29).Enabled=   0   'False
      Tab(0).Control(30)=   "tag710_1"
      Tab(0).Control(30).Enabled=   0   'False
      Tab(0).Control(31)=   "tag710_2"
      Tab(0).Control(31).Enabled=   0   'False
      Tab(0).Control(32)=   "tag710_3"
      Tab(0).Control(32).Enabled=   0   'False
      Tab(0).Control(33)=   "tag710_4"
      Tab(0).Control(33).Enabled=   0   'False
      Tab(0).Control(34)=   "tag710_11"
      Tab(0).Control(34).Enabled=   0   'False
      Tab(0).Control(35)=   "tag710_12"
      Tab(0).Control(35).Enabled=   0   'False
      Tab(0).Control(36)=   "tag710_7"
      Tab(0).Control(36).Enabled=   0   'False
      Tab(0).Control(37)=   "tag710_8"
      Tab(0).Control(37).Enabled=   0   'False
      Tab(0).Control(38)=   "tag710_9"
      Tab(0).Control(38).Enabled=   0   'False
      Tab(0).Control(39)=   "tag710_10"
      Tab(0).Control(39).Enabled=   0   'False
      Tab(0).Control(40)=   "tag700_q1"
      Tab(0).Control(40).Enabled=   0   'False
      Tab(0).Control(41)=   "tag700_s1"
      Tab(0).Control(41).Enabled=   0   'False
      Tab(0).Control(42)=   "Command3"
      Tab(0).Control(42).Enabled=   0   'False
      Tab(0).Control(43)=   "Command1"
      Tab(0).Control(43).Enabled=   0   'False
      Tab(0).Control(44)=   "indicator(0)"
      Tab(0).Control(44).Enabled=   0   'False
      Tab(0).Control(45)=   "indicator(1)"
      Tab(0).Control(45).Enabled=   0   'False
      Tab(0).Control(46)=   "Newcmd"
      Tab(0).Control(46).Enabled=   0   'False
      Tab(0).ControlCount=   47
      TabCaption(1)   =   "Tag711-Tag740"
      TabPicture(1)   =   "tag700.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Command5"
      Tab(1).Control(1)=   "indicator(4)"
      Tab(1).Control(2)=   "indicator(3)"
      Tab(1).Control(3)=   "indicator(2)"
      Tab(1).Control(4)=   "Command4"
      Tab(1).Control(5)=   "Command2"
      Tab(1).Control(6)=   "tag700_s2"
      Tab(1).Control(7)=   "tag700_q2"
      Tab(1).Control(8)=   "tag740_3"
      Tab(1).Control(9)=   "tag740_2"
      Tab(1).Control(10)=   "tag740_1"
      Tab(1).Control(11)=   "tag730_4"
      Tab(1).Control(12)=   "tag730_3"
      Tab(1).Control(13)=   "tag730_2"
      Tab(1).Control(14)=   "tag730_1"
      Tab(1).Control(15)=   "tag730_7"
      Tab(1).Control(16)=   "tag730_6"
      Tab(1).Control(17)=   "tag730_5"
      Tab(1).Control(18)=   "tag730_8"
      Tab(1).Control(19)=   "tag730_10"
      Tab(1).Control(20)=   "tag730_9"
      Tab(1).Control(21)=   "tag711_4"
      Tab(1).Control(22)=   "tag711_3"
      Tab(1).Control(23)=   "tag711_2"
      Tab(1).Control(24)=   "tag711_1"
      Tab(1).Control(25)=   "tag711_6"
      Tab(1).Control(26)=   "tag711_7"
      Tab(1).Control(27)=   "tag711_8"
      Tab(1).Control(28)=   "tag711_5"
      Tab(1).Control(29)=   "Label1(5)"
      Tab(1).Control(30)=   "Label1(4)"
      Tab(1).Control(31)=   "Label1(3)"
      Tab(1).Control(32)=   "Label24"
      Tab(1).Control(33)=   "Label23"
      Tab(1).Control(34)=   "Label22"
      Tab(1).Control(35)=   "Label21"
      Tab(1).Control(36)=   "Label39"
      Tab(1).Control(37)=   "Label40"
      Tab(1).Control(38)=   "Label41"
      Tab(1).Control(39)=   "Label42"
      Tab(1).Control(40)=   "Label43"
      Tab(1).Control(41)=   "Label44"
      Tab(1).Control(42)=   "Label46"
      Tab(1).Control(43)=   "Label47"
      Tab(1).Control(44)=   "Label49"
      Tab(1).Control(45)=   "Label52"
      Tab(1).Control(46)=   "Label53"
      Tab(1).Control(47)=   "Label28"
      Tab(1).Control(48)=   "Label29"
      Tab(1).Control(49)=   "Label30"
      Tab(1).Control(50)=   "Label31"
      Tab(1).Control(51)=   "Label32"
      Tab(1).Control(52)=   "Label33"
      Tab(1).Control(53)=   "Label34"
      Tab(1).Control(54)=   "Label35"
      Tab(1).Control(55)=   "Label36"
      Tab(1).ControlCount=   56
      Begin VB.CommandButton Command5 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -72000
         TabIndex        =   49
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton Newcmd 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2880
         TabIndex        =   20
         Top             =   7080
         Width           =   1455
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   4
         Left            =   -65400
         MaxLength       =   2
         TabIndex        =   45
         Top             =   4920
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   3
         Left            =   -65280
         MaxLength       =   2
         TabIndex        =   34
         Top             =   600
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   2
         Left            =   -71400
         MaxLength       =   2
         TabIndex        =   25
         Top             =   600
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   1
         Left            =   9240
         MaxLength       =   2
         TabIndex        =   7
         Top             =   840
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   0
         Left            =   3120
         MaxLength       =   2
         TabIndex        =   0
         Top             =   840
         Width           =   375
      End
      Begin VB.CommandButton Command4 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -67320
         TabIndex        =   52
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command2 
         Caption         =   "NEXT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -66480
         TabIndex        =   53
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command1 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   7560
         TabIndex        =   23
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command3 
         Caption         =   "NEXT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   8400
         TabIndex        =   24
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton tag700_s2 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -68880
         TabIndex        =   51
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag700_q2 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -70440
         TabIndex        =   50
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag700_s1 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   6000
         TabIndex        =   22
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag700_q1 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   4440
         TabIndex        =   21
         Top             =   7080
         Width           =   1455
      End
      Begin VB.TextBox tag740_3 
         Height          =   315
         Left            =   -67560
         TabIndex        =   48
         Top             =   6120
         Width           =   2775
      End
      Begin VB.TextBox tag740_2 
         Height          =   315
         Left            =   -67560
         TabIndex        =   47
         Top             =   5760
         Width           =   2775
      End
      Begin VB.TextBox tag740_1 
         Height          =   315
         Left            =   -67560
         TabIndex        =   46
         Top             =   5400
         Width           =   2775
      End
      Begin VB.TextBox tag730_4 
         Height          =   315
         Left            =   -66000
         TabIndex        =   38
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag730_3 
         Height          =   315
         Left            =   -66000
         TabIndex        =   37
         Top             =   1800
         Width           =   2775
      End
      Begin VB.TextBox tag730_2 
         Height          =   315
         Left            =   -66000
         TabIndex        =   36
         Top             =   1440
         Width           =   2775
      End
      Begin VB.TextBox tag730_1 
         Height          =   315
         Left            =   -66000
         TabIndex        =   35
         Top             =   1080
         Width           =   2775
      End
      Begin VB.TextBox tag730_7 
         Height          =   315
         Left            =   -66000
         TabIndex        =   41
         Top             =   3240
         Width           =   2775
      End
      Begin VB.TextBox tag730_6 
         Height          =   315
         Left            =   -66000
         TabIndex        =   40
         Top             =   2880
         Width           =   2775
      End
      Begin VB.TextBox tag730_5 
         Height          =   315
         Left            =   -66000
         TabIndex        =   39
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox tag730_8 
         Height          =   315
         Left            =   -66000
         TabIndex        =   42
         Top             =   3600
         Width           =   2775
      End
      Begin VB.TextBox tag730_10 
         Height          =   315
         Left            =   -66000
         TabIndex        =   44
         Top             =   4320
         Width           =   2775
      End
      Begin VB.TextBox tag730_9 
         Height          =   315
         Left            =   -66000
         TabIndex        =   43
         Top             =   3960
         Width           =   2775
      End
      Begin VB.TextBox tag711_4 
         Height          =   315
         Left            =   -71880
         TabIndex        =   29
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag711_3 
         Height          =   315
         Left            =   -71880
         TabIndex        =   28
         Top             =   1800
         Width           =   2775
      End
      Begin VB.TextBox tag711_2 
         Height          =   315
         Left            =   -71880
         TabIndex        =   27
         Top             =   1440
         Width           =   2775
      End
      Begin VB.TextBox tag711_1 
         Height          =   315
         Left            =   -71880
         TabIndex        =   26
         Top             =   1080
         Width           =   2775
      End
      Begin VB.TextBox tag711_6 
         Height          =   315
         Left            =   -70560
         TabIndex        =   31
         Top             =   2880
         Width           =   1455
      End
      Begin VB.TextBox tag711_7 
         Height          =   315
         Left            =   -71880
         TabIndex        =   32
         Top             =   3240
         Width           =   2775
      End
      Begin VB.TextBox tag711_8 
         Height          =   315
         Left            =   -71880
         TabIndex        =   33
         Top             =   3600
         Width           =   2775
      End
      Begin VB.TextBox tag711_5 
         Height          =   315
         Left            =   -71880
         TabIndex        =   30
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox tag710_10 
         Height          =   315
         Left            =   9000
         TabIndex        =   17
         Top             =   4560
         Width           =   2775
      End
      Begin VB.TextBox tag710_9 
         Height          =   315
         Left            =   10320
         TabIndex        =   16
         Top             =   4200
         Width           =   1455
      End
      Begin VB.TextBox tag710_8 
         Height          =   315
         Left            =   9000
         TabIndex        =   15
         Top             =   3840
         Width           =   2775
      End
      Begin VB.TextBox tag710_7 
         Height          =   315
         Left            =   9000
         TabIndex        =   14
         Top             =   3480
         Width           =   2775
      End
      Begin VB.TextBox tag710_12 
         Height          =   315
         Left            =   9000
         TabIndex        =   19
         Top             =   5280
         Width           =   2775
      End
      Begin VB.TextBox tag710_11 
         Height          =   315
         Left            =   9000
         TabIndex        =   18
         Top             =   4920
         Width           =   2775
      End
      Begin VB.TextBox tag710_4 
         Height          =   315
         Left            =   9000
         TabIndex        =   11
         Top             =   2400
         Width           =   2775
      End
      Begin VB.TextBox tag710_3 
         Height          =   315
         Left            =   9000
         TabIndex        =   10
         Top             =   2040
         Width           =   2775
      End
      Begin VB.TextBox tag710_2 
         Height          =   315
         Left            =   9000
         TabIndex        =   9
         Top             =   1680
         Width           =   2775
      End
      Begin VB.TextBox tag710_1 
         Height          =   315
         Left            =   9000
         TabIndex        =   8
         Top             =   1320
         Width           =   2775
      End
      Begin VB.TextBox tag710_6 
         Height          =   315
         Left            =   9000
         TabIndex        =   13
         Top             =   3120
         Width           =   2775
      End
      Begin VB.TextBox tag710_5 
         Height          =   315
         Left            =   9360
         TabIndex        =   12
         Top             =   2760
         Width           =   2415
      End
      Begin VB.TextBox tag700_4 
         Height          =   315
         Left            =   3120
         TabIndex        =   4
         Top             =   2400
         Width           =   2775
      End
      Begin VB.TextBox tag700_3 
         Height          =   315
         Left            =   3480
         TabIndex        =   3
         Top             =   2040
         Width           =   2415
      End
      Begin VB.TextBox tag700_2 
         Height          =   315
         Left            =   3120
         TabIndex        =   2
         Top             =   1680
         Width           =   2775
      End
      Begin VB.TextBox tag700_1 
         Height          =   315
         Left            =   3120
         TabIndex        =   1
         Top             =   1320
         Width           =   2775
      End
      Begin VB.TextBox tag700_6 
         Height          =   315
         Left            =   3120
         TabIndex        =   6
         Top             =   3120
         Width           =   2775
      End
      Begin VB.TextBox tag700_5 
         Height          =   315
         Left            =   3120
         TabIndex        =   5
         Top             =   2760
         Width           =   2775
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   5
         Left            =   -64800
         TabIndex        =   103
         Top             =   4920
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   4
         Left            =   -64680
         TabIndex        =   102
         Top             =   600
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   3
         Left            =   -70800
         TabIndex        =   101
         Top             =   600
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   2
         Left            =   9840
         TabIndex        =   100
         Top             =   840
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   1
         Left            =   3720
         TabIndex        =   99
         Top             =   840
         Width           =   855
      End
      Begin VB.Label Label24 
         Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -70560
         TabIndex        =   98
         Top             =   6120
         Width           =   3135
      End
      Begin VB.Label Label23 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -70560
         TabIndex        =   97
         Top             =   5760
         Width           =   2415
      End
      Begin VB.Label Label22 
         Caption         =   "��������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -70560
         TabIndex        =   96
         Top             =   5400
         Width           =   3135
      End
      Begin VB.Label Label21 
         Caption         =   "740 ��¡��������������ͧ���ᵡ��ҧ/��������ͧ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -70560
         TabIndex        =   95
         Top             =   4920
         Width           =   5055
      End
      Begin VB.Label Label39 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   94
         Top             =   2160
         Width           =   2775
      End
      Begin VB.Label Label40 
         Caption         =   "�բͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   93
         Top             =   1800
         Width           =   3135
      End
      Begin VB.Label Label41 
         Caption         =   "�շ��ŧ���ʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   92
         Top             =   1440
         Width           =   2415
      End
      Begin VB.Label Label42 
         Caption         =   "��������ͧẺ��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   91
         Top             =   1080
         Width           =   3135
      End
      Begin VB.Label Label43 
         Caption         =   "730 ��¡��������������ͧẺ��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   90
         Top             =   600
         Width           =   5055
      End
      Begin VB.Label Label44 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   89
         Top             =   3240
         Width           =   4455
      End
      Begin VB.Label Label46 
         Caption         =   "���Ңͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   88
         Top             =   2880
         Width           =   2415
      End
      Begin VB.Label Label47 
         Caption         =   "��������§ҹ����ٻẺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   87
         Top             =   2520
         Width           =   3255
      End
      Begin VB.Label Label49 
         Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   86
         Top             =   3600
         Width           =   2775
      End
      Begin VB.Label Label52 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   85
         Top             =   4320
         Width           =   2415
      End
      Begin VB.Label Label53 
         Caption         =   "��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   84
         Top             =   3960
         Width           =   1935
      End
      Begin VB.Label Label28 
         Caption         =   "��¡���ͧ�������͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   83
         Top             =   2160
         Width           =   2895
      End
      Begin VB.Label Label29 
         Caption         =   "�շ��Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   82
         Top             =   1800
         Width           =   3135
      End
      Begin VB.Label Label30 
         Caption         =   "ʶҹ���Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   81
         Top             =   1440
         Width           =   2415
      End
      Begin VB.Label Label31 
         Caption         =   "���͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   80
         Top             =   1080
         Width           =   3135
      End
      Begin VB.Label Label32 
         Caption         =   "711 ��¡���������͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   79
         Top             =   600
         Width           =   4455
      End
      Begin VB.Label Label33 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   78
         Top             =   2880
         Width           =   4455
      End
      Begin VB.Label Label34 
         Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   77
         Top             =   3240
         Width           =   2535
      End
      Begin VB.Label Label35 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   76
         Top             =   3600
         Width           =   2775
      End
      Begin VB.Label Label36 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   75
         Top             =   2520
         Width           =   3255
      End
      Begin VB.Label Label20 
         Caption         =   "���͵͹/������ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   74
         Top             =   4560
         Width           =   2775
      End
      Begin VB.Label Label19 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   73
         Top             =   4200
         Width           =   4335
      End
      Begin VB.Label Label18 
         Caption         =   "��ǹ��Сͺ���¢ͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   72
         Top             =   3840
         Width           =   2655
      End
      Begin VB.Label Label17 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   71
         Top             =   3480
         Width           =   3135
      End
      Begin VB.Label Label16 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   70
         Top             =   5280
         Width           =   2415
      End
      Begin VB.Label Label15 
         Caption         =   "��������´����ǡѺ��Ѻ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   69
         Top             =   4920
         Width           =   3255
      End
      Begin VB.Label Label14 
         Caption         =   "�շ���Ъ��/�բͧʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   68
         Top             =   2400
         Width           =   2775
      End
      Begin VB.Label Label13 
         Caption         =   "ʶҹ���Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   67
         Top             =   2040
         Width           =   3135
      End
      Begin VB.Label Label12 
         Caption         =   "����˹��§ҹ�ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   66
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label Label11 
         Caption         =   "���͹ԵԺؤ�����ͪ��͵��������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   65
         Top             =   1320
         Width           =   3135
      End
      Begin VB.Label Label10 
         Caption         =   "710 ��¡���������͹ԵԺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   64
         Top             =   840
         Width           =   5055
      End
      Begin VB.Label Label9 
         Caption         =   "�վ����ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   63
         Top             =   3120
         Width           =   2415
      End
      Begin VB.Label Label8 
         Caption         =   "���кؤ�������ѹ��ԵԺؤ�šѺ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   62
         Top             =   2760
         Width           =   3255
      End
      Begin VB.Label Label7 
         Caption         =   "���Դ �յ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   61
         Top             =   2400
         Width           =   2775
      End
      Begin VB.Label Label6 
         Caption         =   "���˹� �� ��к�ô��ѡ��� �������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   60
         Top             =   2040
         Width           =   3615
      End
      Begin VB.Label Label5 
         Caption         =   "�Ţ���ѹ�����ѧ���͵�"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   59
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label Label4 
         Caption         =   "���ͺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   58
         Top             =   1320
         Width           =   3135
      End
      Begin VB.Label Label3 
         Caption         =   "700  ��¡���������ͺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   57
         Top             =   840
         Width           =   5055
      End
      Begin VB.Label Label2 
         Caption         =   "�������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   56
         Top             =   3120
         Width           =   2415
      End
      Begin VB.Label Label1 
         Caption         =   "���кؤ�������ѹ��ؤ�šѺ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   0
         Left            =   120
         TabIndex        =   55
         Top             =   2760
         Width           =   3255
      End
   End
End
Attribute VB_Name = "tag700"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
tagselect.Command8.SetFocus
tag600.Show

End Sub

Private Sub Command2_Click()
tagselect.Command10.SetFocus
tag800.Show

End Sub

Private Sub Command3_Click()
tagselect.Command10.SetFocus
tag800.Show

End Sub

Private Sub Command4_Click()
tagselect.Command8.SetFocus
tag600.Show

End Sub

Private Sub Command5_Click()
MarcMenu.newedit
End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag700_q1_Click()
MarcMenu.quitting
End Sub

Private Sub tag700_q2_Click()
MarcMenu.quitting
End Sub


Private Sub tag700_s1_Click()
MarcMenu.saving
End Sub

Private Sub tag700_s2_Click()
MarcMenu.saving
End Sub
