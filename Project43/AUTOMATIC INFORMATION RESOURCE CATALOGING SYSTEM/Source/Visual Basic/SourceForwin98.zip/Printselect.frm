VERSION 5.00
Begin VB.Form Printselect 
   Caption         =   "�Ծ�������"
   ClientHeight    =   2895
   ClientLeft      =   2175
   ClientTop       =   3150
   ClientWidth     =   6870
   Icon            =   "Printselect.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   2895
   ScaleWidth      =   6870
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command2 
      Cancel          =   -1  'True
      Caption         =   "¡��ԡ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4320
      TabIndex        =   5
      ToolTipText     =   "�͡�ҡ�����"
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��ŧ"
      Default         =   -1  'True
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1680
      TabIndex        =   4
      ToolTipText     =   "����������"
      Top             =   2040
      Width           =   1215
   End
   Begin VB.Frame Frame1 
      Caption         =   "��/��͹/�ѹ ����ͧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1455
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   6135
      Begin VB.TextBox Text2 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         Left            =   3960
         MaxLength       =   8
         TabIndex        =   3
         Top             =   720
         Width           =   1215
      End
      Begin VB.TextBox Text1 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   420
         Left            =   1560
         MaxLength       =   8
         TabIndex        =   1
         Top             =   720
         Width           =   1215
      End
      Begin VB.Label Label2 
         Caption         =   "�֧"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3240
         TabIndex        =   6
         Top             =   720
         Width           =   375
      End
      Begin VB.Label Label1 
         Caption         =   "�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   720
         TabIndex        =   2
         Top             =   720
         Width           =   615
      End
   End
End
Attribute VB_Name = "Printselect"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public marcws As Workspace
Public marcdb As Database
Public Opendyna  As Recordset
Dim check As Boolean
Dim Character As String
Dim Date1 As String, Date2 As String
Public sqlcommand As String
Private Sub Command1_Click()
check = False
CheckInput

If Not (check) Then
SQL
Printed.Show
Unload Me
End If

End Sub

Private Sub Command2_Click()
Unload Me
End Sub

Private Sub Form_Load()
check = False
Character = "0123456789"
On Error GoTo HandleError
Set marcws = DBEngine.Workspaces(0)
Set marcdb = marcws.OpenDatabase("marcsheetdb.mdb", False, False)
Exit Sub
HandleError:
MsgBox Error(Err.Number)

Set marcws = DBEngine.Workspaces(0)
Set marcdb = marcws.OpenDatabase("HeaderDB.mdb", False, False)
End Sub

Sub SQL()
Dim tmp As String
sqlcommand = " SELECT book_no,t090_1,t090_2,t090_3,t099_1,t099_2,t099_3 FROM tagdata1 "
sqlcommand = sqlcommand & "WHERE t008_7 between '"
sqlcommand = sqlcommand & Date1 & "' and '"
sqlcommand = sqlcommand & Date2 & "'"
sqlcommand = sqlcommand & "order by 1"
Set Opendyna = marcdb.OpenRecordset(sqlcommand, dbOpenDynaset)

Do Until Opendyna.EOF
tmp = Opendyna.Fields("book_no")
tmp = Trim(tmp)
Printed.List1.AddItem tmp
Opendyna.MoveNext
Loop

End Sub

Sub CheckInput()
Dim i As Integer, j As Integer, k As Integer, m As Integer, n As Integer
Dim Year As String, Month As String, Day As String
Dim tmp As String, tmp1 As String, tmp2 As String, tmp3 As String
Dim tmp4 As String

i = Len(Text1.Text)
j = Len(Text2.Text)
tmp1 = Text1.Text
tmp2 = Text2.Text


If (i = 0) And (j = 0) Then
     Date1 = ""
     Date2 = ""
    
ElseIf (i = 6) And (j = 6) Then
    
    For k = 1 To 6
          tmp = Mid(tmp1, k, 1)
          tmp3 = Mid(tmp2, k, 1)
          m = InStr(Character, tmp)
          n = InStr(Character, tmp3)
          If (m = 0) Or (n = 0) Then
                 GoTo Err
          End If
    Next k
    
    Year = Mid(tmp1, 1, 2)
    Month = Mid(tmp1, 3, 2)
    Day = Mid(tmp1, 5, 2)
    Date1 = Year & "/" & Month & "/" & Day
    
    Year = Mid(tmp2, 1, 2)
    Month = Mid(tmp2, 3, 2)
    Day = Mid(tmp2, 5, 2)
    Date2 = Year & "/" & Month & "/" & Day
    
    
   
ElseIf (i = 8) And (j = 8) Then
   
   tmp4 = "0123456789/-"

   For k = 1 To 8
        tmp = Mid(tmp1, k, 1)
        m = InStr(tmp4, tmp)
        tmp3 = Mid(tmp2, k, 1)
        n = InStr(tmp4, tmp)
        If (m = 0) Or (n = 0) Then
            GoTo Err
        End If
        
        If (k = 3) Or (k = 6) Then
             If (tmp <> "-") Or (tmp3 <> "-") Then
                  If (tmp <> "/") And (tmp3 <> "/") Then
                        GoTo Err
                 End If
             Else
                  Mid(tmp1, k, 1) = "/"
                  Mid(tmp2, k, 1) = "/"
                 
             End If
        End If
   
   Next k
   
   Date1 = tmp1
   Date2 = tmp2
   
   
 Else
Err:
     MsgBox "����ѹ��͹�վ���� ��س�����������١��ͧ "
     check = True
 End If





End Sub

