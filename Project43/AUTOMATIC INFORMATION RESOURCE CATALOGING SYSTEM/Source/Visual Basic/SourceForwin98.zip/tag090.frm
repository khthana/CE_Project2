VERSION 5.00
Begin VB.Form tag090 
   Caption         =   "tag090"
   ClientHeight    =   7875
   ClientLeft      =   75
   ClientTop       =   1050
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7875
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton Newcmd 
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2640
      TabIndex        =   8
      Top             =   7080
      Width           =   1455
   End
   Begin VB.CommandButton Command4 
      Height          =   495
      Left            =   8280
      Picture         =   "tag090.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   1680
      Width           =   1215
   End
   Begin VB.CommandButton Command2 
      Height          =   495
      Left            =   8280
      Picture         =   "tag090.frx":0B9A
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   2280
      Width           =   1215
   End
   Begin VB.ComboBox ComboAuthorCode 
      Height          =   315
      Left            =   9600
      TabIndex        =   22
      Text            =   "�Ţ�����˹ѧ���"
      Top             =   4680
      Width           =   1455
   End
   Begin VB.ComboBox ComboHeaderCode 
      Height          =   315
      Left            =   7920
      TabIndex        =   21
      Text            =   "�Ţ�������ͧ˹ѧ���"
      Top             =   4680
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "BACK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   7320
      TabIndex        =   11
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton Command3 
      Caption         =   "NEXT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   8160
      TabIndex        =   12
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton tag090_s 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   5760
      TabIndex        =   10
      Top             =   7080
      Width           =   1455
   End
   Begin VB.CommandButton tag090_q 
      Caption         =   "QUIT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   4200
      TabIndex        =   9
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox tag090_1 
      Height          =   375
      Left            =   6600
      TabIndex        =   0
      Top             =   1800
      Width           =   1215
   End
   Begin VB.TextBox tag099_1 
      Height          =   375
      Left            =   6480
      TabIndex        =   5
      Top             =   4680
      Width           =   1215
   End
   Begin VB.TextBox tag090_3 
      Height          =   375
      Left            =   6600
      TabIndex        =   4
      Top             =   2760
      Width           =   1215
   End
   Begin VB.TextBox tag090_2 
      Height          =   375
      Left            =   6600
      TabIndex        =   2
      Top             =   2280
      Width           =   1215
   End
   Begin VB.TextBox tag099_3 
      Height          =   375
      Left            =   6480
      TabIndex        =   7
      Top             =   5640
      Width           =   1215
   End
   Begin VB.TextBox tag099_2 
      Height          =   375
      Left            =   6480
      TabIndex        =   6
      Top             =   5160
      Width           =   1215
   End
   Begin VB.Label Label33 
      Caption         =   "�Ţ����˹ѧ��ͷ����ͧ��ش��˹�������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   20
      Top             =   4680
      Width           =   3615
   End
   Begin VB.Label Label34 
      Caption         =   "�Ţ����˹ѧ���Ẻ����ش�Ѱ�������ԡѹ (LC)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      TabIndex        =   19
      Top             =   1800
      Width           =   4215
   End
   Begin VB.Label Label32 
      Caption         =   "090 �Ţ���¡˹ѧ����к�����ش�Ѱ�������ԡѹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      TabIndex        =   18
      Top             =   1320
      Width           =   5295
   End
   Begin VB.Label Label35 
      Caption         =   "�վ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      TabIndex        =   17
      Top             =   2760
      Width           =   2535
   End
   Begin VB.Label Label36 
      Caption         =   "�Ţ�����˹ѧ��� (�Ţ�ѵ����)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      TabIndex        =   16
      Top             =   2280
      Width           =   4215
   End
   Begin VB.Label Label66 
      Caption         =   "099 �Ţ���¡˹ѧ�����ͧ��ش��˹��ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   15
      Top             =   4200
      Width           =   4335
   End
   Begin VB.Label Label67 
      Caption         =   "�վ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   14
      Top             =   5640
      Width           =   2535
   End
   Begin VB.Label Label68 
      Caption         =   "�Ţ�����˹ѧ��� (�Ţ�ѵ����)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   13
      Top             =   5160
      Width           =   4215
   End
End
Attribute VB_Name = "tag090"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False




Private Sub ComboAuthorCode_Click()
tag099_1.Text = ComboHeaderCode.Text
tag099_2.Text = ComboAuthorCode.Text
End Sub

Private Sub ComboHeaderCode_Click()
tag099_1.Text = ComboHeaderCode.Text
tag099_2.Text = ComboAuthorCode.Text
End Sub

Private Sub Command1_Click()
tagselect.Command2.SetFocus
tag020.Show

End Sub

Private Sub Command2_Click()
Authorcode_show.Show

End Sub

Private Sub Command3_Click()
tagselect.Command4.SetFocus
tag100.Show

End Sub

Private Sub Command4_Click()
SearchHeader.Show
End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag090_q_Click()
MarcMenu.quitting
End Sub

Private Sub tag090_s_Click()
MarcMenu.saving
End Sub


