VERSION 5.00
Begin VB.Form deleteform 
   Caption         =   "deleteform"
   ClientHeight    =   6630
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7395
   Icon            =   "deleteform.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   6630
   ScaleWidth      =   7395
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   Begin VB.Frame Frame1 
      Caption         =   "���͡�����Ũҡ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1815
      Left            =   480
      TabIndex        =   8
      Top             =   960
      Width           =   3615
      Begin VB.OptionButton Option1 
         Caption         =   "���͡�ҡ�Ţ ISBN"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   14.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   10
         Top             =   480
         Width           =   3135
      End
      Begin VB.OptionButton Option2 
         Caption         =   "���͡�ҡ�Ţ����¹"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   14.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   9
         Top             =   1080
         Width           =   3135
      End
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Cancel"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   9240
      TabIndex        =   4
      Top             =   2040
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Delete"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7800
      TabIndex        =   1
      Top             =   2040
      Width           =   1215
   End
   Begin VB.ComboBox cmbIDdel 
      Height          =   315
      Left            =   4920
      TabIndex        =   0
      Top             =   2040
      Width           =   2655
   End
   Begin VB.Label Label5 
      Caption         =   "���ͼ���� :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1920
      TabIndex        =   7
      Top             =   5640
      Width           =   1815
   End
   Begin VB.Label Label4 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3720
      TabIndex        =   6
      Top             =   5640
      Width           =   7575
   End
   Begin VB.Label Label3 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3720
      TabIndex        =   5
      Top             =   4560
      Width           =   7575
   End
   Begin VB.Label Label1 
      Caption         =   "�ô���͡����˹ѧ��ͷ���ҹ��ͧź"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   6000
      TabIndex        =   3
      Top             =   1200
      Width           =   4095
   End
   Begin VB.Label Label2 
      Caption         =   "����˹ѧ��� :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   1920
      TabIndex        =   2
      Top             =   4560
      Width           =   1815
   End
End
Attribute VB_Name = "deleteform"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public marcdbdel As Database
Public marcwsdel As Workspace
Public Rectagdatadel1 As Recordset
Public Rectagdatadel2 As Recordset
Public idsnapdel As Recordset

Private Sub cmbIDdel_click()
Set Rectagdatadel1 = marcdbdel.OpenRecordset("select * from tagdata1", dbOpenDynaset)
Rectagdatadel1.MoveFirst
If cmbIDdel.Text <> "" Then

If Option1.Value Then
Do While Rectagdatadel1.Fields("t020_1") <> cmbIDdel.Text
  Rectagdatadel1.MoveNext
Loop
Else
Do While Rectagdatadel1.Fields("book_no") <> cmbIDdel.Text
  Rectagdatadel1.MoveNext
Loop
End If

If Rectagdatadel1.Fields("t100_1") <> " " Then
Label4.Caption = (Rectagdatadel1.Fields("t100_1"))
ElseIf Rectagdatadel1.Fields("t110_1") <> " " Then
Label4.Caption = (Rectagdatadel1.Fields("t110_1"))
ElseIf Rectagdatadel1.Fields("t111_1") <> " " Then
Label4.Caption = (Rectagdatadel1.Fields("t111_1"))
ElseIf Rectagdatadel1.Fields("t130_1") <> " " Then
Label4.Caption = (Rectagdatadel1.Fields("t130_1"))
End If

If Rectagdatadel1.Fields("t245_1") <> " " Then
Label3.Caption = (Rectagdatadel1.Fields("t245_1"))
ElseIf Rectagdatadel1.Fields("t210_1") <> " " Then
Label3.Caption = (Rectagdatadel1.Fields("t210_1"))
ElseIf Rectagdatadel1.Fields("t240_1") <> " " Then
Label3.Caption = (Rectagdatadel1.Fields("t240_1"))
ElseIf Rectagdatadel1.Fields("t242_1") <> " " Then
Label3.Caption = (Rectagdatadel1.Fields("t242_1"))
ElseIf Rectagdatadel1.Fields("t246_1") <> " " Then
Label3.Caption = (Rectagdatadel1.Fields("t246_1"))
End If

End If
End Sub

Private Sub Command1_Click()
Dim ISBN As String
If cmbIDdel.Text <> "" Then
Set Rectagdatadel1 = marcdbdel.OpenRecordset("Select * from tagdata1", dbOpenDynaset)
Set Rectagdatadel2 = marcdbdel.OpenRecordset("Select * from tagdata2", dbOpenDynaset)
Rectagdatadel1.MoveFirst
Rectagdatadel2.MoveFirst
If Option1.Value Then
Do While Rectagdatadel1.Fields("t020_1") <> cmbIDdel.Text
  Rectagdatadel1.MoveNext
  
  If Rectagdatadel1.EOF Then
 MsgBox ("��辺�����ź��ҹ������")
 GoTo ex   '  exit
End If

Loop
Do While Rectagdatadel2.Fields("t020_1") <> cmbIDdel.Text
  Rectagdatadel2.MoveNext
Loop
Else
Do While Rectagdatadel1.Fields("book_no") <> cmbIDdel.Text
  Rectagdatadel1.MoveNext
  
  If Rectagdatadel1.EOF Then
 MsgBox ("��辺�����ź��ҹ������")
 GoTo ex   '  exit
End If

Loop
ISBN = Rectagdatadel1.Fields("t020_1")
Do While Rectagdatadel2.Fields("t020_1") <> ISBN
  Rectagdatadel2.MoveNext
Loop
End If
If MsgBox("Are you sure ?", vbOKCancel) = vbOK Then
   Rectagdatadel1.Delete
   Rectagdatadel2.Delete
  Form_Load
Else
End If
End If
Label3.Caption = ""
Label4.Caption = ""
ex:
End Sub

Private Sub Command2_Click()
Unload Me
End Sub

Private Sub Form_Load()
Option1.Value = True
Set marcwsdel = DBEngine.Workspaces(0)
Set marcdbdel = marcwsdel.OpenDatabase("marcsheetdb", False, False)
'Openrecordset for select from combo box
Set idsnapdel = marcdbdel.OpenRecordset("Select t020_1 from tagdata1 Order by t020_1", dbOpenSnapshot)
'checking for null database
If idsnapdel.EOF Then
   MsgBox ("����բ����ź��ҹ����������")
   Command1.Visible = False
   cmbIDdel.Clear
Else
Command1.Visible = True
'Add item in the combo box
idsnapdel.MoveFirst
cmbIDdel.Clear
Do While Not idsnapdel.EOF
   cmbIDdel.AddItem (idsnapdel.Fields("t020_1"))
    idsnapdel.MoveNext
Loop
End If
End Sub

Private Sub Option1_Click()
Set marcwsdel = DBEngine.Workspaces(0)
Set marcdbdel = marcwsdel.OpenDatabase("marcsheetdb", False, False)
Set idsnapdel = marcdbdel.OpenRecordset("Select t020_1 from tagdata1 Order by t020_1", dbOpenSnapshot)
Label3.Caption = ""
Label4.Caption = ""
If idsnapdel.EOF Then
   MsgBox ("����բ����ź��ҹ����������")
   Command1.Visible = False
   cmbIDdel.Clear
Else
Command1.Visible = True
'Add item in the combo box
idsnapdel.MoveFirst
cmbIDdel.Clear
Do While Not idsnapdel.EOF
   cmbIDdel.AddItem (idsnapdel.Fields("t020_1"))
    idsnapdel.MoveNext
Loop
End If
End Sub

Private Sub Option2_Click()
Set marcwsdel = DBEngine.Workspaces(0)
Set marcdbdel = marcwsdel.OpenDatabase("marcsheetdb", False, False)
Set idsnapdel = marcdbdel.OpenRecordset("Select book_no from tagdata1 Order by 1", dbOpenSnapshot)
Label3.Caption = ""
Label4.Caption = ""
If idsnapdel.EOF Then
   MsgBox ("����բ����ź��ҹ����������")
   Command1.Visible = False
   cmbIDdel.Clear
Else
Command1.Visible = True
'Add item in the combo box
idsnapdel.MoveFirst
cmbIDdel.Clear
Do While Not idsnapdel.EOF
   cmbIDdel.AddItem (idsnapdel.Fields("book_no"))
    idsnapdel.MoveNext
Loop
End If
End Sub
