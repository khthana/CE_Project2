VERSION 5.00
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Begin VB.Form �Header2 
   Caption         =   "�������ͧ����2"
   ClientHeight    =   8055
   ClientLeft      =   180
   ClientTop       =   420
   ClientWidth     =   10680
   LinkTopic       =   "Form1"
   ScaleHeight     =   8055
   ScaleWidth      =   10680
   Begin VB.Frame Frame5 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1695
      Left            =   8640
      TabIndex        =   32
      Top             =   6240
      Width           =   1695
      Begin MSAdodcLib.Adodc Adodc1 
         Height          =   495
         Left            =   240
         Top             =   360
         Width           =   1200
         _ExtentX        =   2117
         _ExtentY        =   873
         ConnectMode     =   0
         CursorLocation  =   3
         IsolationLevel  =   -1
         ConnectionTimeout=   15
         CommandTimeout  =   30
         CursorType      =   3
         LockType        =   3
         CommandType     =   1
         CursorOptions   =   0
         CacheSize       =   50
         MaxRecords      =   0
         BOFAction       =   0
         EOFAction       =   0
         ConnectStringType=   1
         Appearance      =   1
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Orientation     =   0
         Enabled         =   -1
         Connect         =   "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=D:\book\Source\HeaderDB.mdb"
         OLEDBString     =   "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=D:\book\Source\HeaderDB.mdb"
         OLEDBFile       =   ""
         DataSourceName  =   ""
         OtherAttributes =   ""
         UserName        =   ""
         Password        =   ""
         RecordSource    =   "select Header,Subheader_1,Subheader_2,TranEng,LC_Dewey,Descript,UF,BT,NT,RT,NT,SA from tblSub2 order by 1,2,3"
         Caption         =   "Adodc1"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         _Version        =   393216
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   34
         Top             =   1200
         Width           =   1455
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         Caption         =   "��������礤���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   33
         Top             =   960
         Width           =   1455
      End
   End
   Begin VB.CommandButton cmdSearch 
      Caption         =   "&GoTo Header"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8760
      TabIndex        =   19
      Top             =   4200
      Width           =   1455
   End
   Begin VB.Frame Frame4 
      Height          =   1215
      Left            =   8640
      TabIndex        =   31
      Top             =   2760
      Width           =   1695
      Begin VB.CommandButton cmdOK 
         Caption         =   "&OK"
         Default         =   -1  'True
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   18
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton cmdCancel 
         Caption         =   "&Cancel"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   20
         Top             =   720
         Width           =   1215
      End
   End
   Begin VB.Frame Frame3 
      Height          =   2535
      Left            =   8640
      TabIndex        =   30
      Top             =   120
      Width           =   1695
      Begin VB.CommandButton cmdAdd 
         Caption         =   "&Add"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   14
         Top             =   360
         Width           =   1215
      End
      Begin VB.CommandButton cmdUpdate 
         Caption         =   "&Save"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   15
         Top             =   840
         Width           =   1215
      End
      Begin VB.CommandButton cmdDelete 
         Caption         =   "&Delete"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   16
         Top             =   1320
         Width           =   1215
      End
      Begin VB.CommandButton cmdEnd 
         Caption         =   "&End"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   17
         Top             =   1920
         Width           =   1215
      End
   End
   Begin VB.Frame Frame2 
      Height          =   4695
      Left            =   120
      TabIndex        =   29
      Top             =   3240
      Width           =   8055
      Begin VB.CheckBox Check5 
         Caption         =   "SA ��͸Ժ�¡�����������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   12
         Top             =   3840
         Width           =   2295
      End
      Begin VB.CheckBox Check4 
         Caption         =   "NT �ӷ��᤺����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   10
         Top             =   2880
         Width           =   2175
      End
      Begin VB.CheckBox Check2 
         Caption         =   "BT �ӷ����ҧ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   6
         Top             =   1140
         Width           =   2055
      End
      Begin VB.CheckBox Check1 
         Caption         =   "UF �ӷ����������������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   4
         Top             =   240
         Width           =   2055
      End
      Begin VB.TextBox Text1 
         DataField       =   "UF"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   4
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   5
         Top             =   240
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "BT"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   5
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   7
         Top             =   1140
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "NT"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   7
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   11
         Top             =   3000
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "SA"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   8
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   13
         Top             =   3840
         Width           =   4815
      End
      Begin VB.CheckBox Check3 
         Caption         =   "RT �ӷ������Ǣ�ͧ����ѹ��ѹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   8
         Top             =   2040
         Width           =   2295
      End
      Begin VB.TextBox Text1 
         DataField       =   "RT"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   6
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   9
         Top             =   2040
         Width           =   4815
      End
   End
   Begin VB.Frame Frame1 
      Height          =   3015
      Left            =   120
      TabIndex        =   22
      Top             =   120
      Width           =   8055
      Begin VB.TextBox Text1 
         DataField       =   "Subheader_2"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   345
         Index           =   0
         Left            =   2640
         TabIndex        =   0
         Top             =   720
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "TranEng"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   1
         Left            =   2640
         TabIndex        =   1
         Top             =   1200
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "LC_Dewey"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   2
         Left            =   2640
         TabIndex        =   2
         Top             =   1680
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "Descript"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   3
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   3
         Top             =   2160
         Width           =   4815
      End
      Begin VB.Label Label7 
         Caption         =   "Label7"
         DataField       =   "Subheader_1"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4080
         TabIndex        =   36
         Top             =   240
         Width           =   3615
      End
      Begin VB.Label Label6 
         Caption         =   "- -"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3720
         TabIndex        =   35
         Top             =   240
         Width           =   495
      End
      Begin VB.Label Label1 
         Caption         =   "�������ͧ����1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   0
         Left            =   240
         TabIndex        =   28
         Top             =   840
         Width           =   1215
      End
      Begin VB.Label Label1 
         Caption         =   "���������ѧ����������ͧ����1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   1
         Left            =   240
         TabIndex        =   27
         Top             =   1320
         Width           =   2175
      End
      Begin VB.Label Label1 
         Caption         =   "�Ţ���� [LC ; DEWEY]"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   2
         Left            =   240
         TabIndex        =   26
         Top             =   1800
         Width           =   2055
      End
      Begin VB.Label Label1 
         Caption         =   "��������´�������ͧ����1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   3
         Left            =   240
         TabIndex        =   25
         Top             =   2280
         Width           =   1815
      End
      Begin VB.Label Label4 
         Caption         =   "�������ͧ :"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   24
         Top             =   240
         Width           =   975
      End
      Begin VB.Label Label5 
         Caption         =   "Label5"
         DataField       =   "Header"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   1320
         TabIndex        =   23
         Top             =   240
         Width           =   2175
      End
   End
   Begin VB.CommandButton Command1 
      Caption         =   ">>>"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8760
      TabIndex        =   21
      Top             =   5160
      Width           =   1455
   End
End
Attribute VB_Name = "�Header2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Adodc1_MoveComplete(ByVal adReason As ADODB.EventReasonEnum, ByVal pError As ADODB.Error, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
    cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
    cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
    cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdOK.Enabled = False '��͹���� OK
    cmdCancel.Enabled = False '��͹���� Cancel
    
    Dim currentRecord As Integer
    Dim allRecord As Integer
    With Adodc1.Recordset
        currentRecord = .AbsolutePosition '�纵��˹���礤��촻Ѩ�غѹ
        allRecord = .RecordCount '�纨ӹǹ��礤��촷�����
    End With
    Adodc1.Caption = currentRecord & "/" & allRecord
    Label2.Caption = Adodc1.Caption
End Sub

Private Sub Check1_Click()
If Check1.Value Then
   Text1(4).Enabled = True
   Text1(4).SetFocus
   Else
   Text1(4).Enabled = False
   Check1.SetFocus
  End If
End Sub

Private Sub Check2_Click()
If Check2.Value Then
   Text1(5).Enabled = True
   Text1(5).SetFocus
   Else
   Text1(5).Enabled = False
   Check2.SetFocus
  End If
End Sub

Private Sub Check3_Click()
If Check3.Value Then
   Text1(6).Enabled = True
   Text1(6).SetFocus
   Else
   Text1(6).Enabled = False
   Check3.SetFocus
  End If
End Sub

Private Sub Check4_Click()
If Check4.Value Then
   Text1(7).Enabled = True
   Text1(7).SetFocus
   Else
   Text1(7).Enabled = False
   Check4.SetFocus
  End If
End Sub

Private Sub Check5_Click()
If Check5.Value Then
   Text1(8).Enabled = True
   Text1(8).SetFocus
   Else
   Text1(8).Enabled = False
   Check5.SetFocus
  End If
End Sub

Private Sub cmdAdd_Click()
 Adodc1.Recordset.AddNew  '������礤�����ҧ����㹰ҹ������
    cmdAdd.Enabled = False   '��˹������� Add �����ʶҹ����������Ǥ���
    cmdUpdate.Enabled = False '��˹������� Update �����ʶҹ����������Ǥ���
    cmdDelete.Enabled = False '��˹������� Delete �����ʶҹ����������Ǥ���
    cmdEnd.Enabled = False '��˹������� End �����ʶҹ����������Ǥ���
    Adodc1.Enabled = False '��˹����͹��� ADO Data �����ʶҹ����������Ǥ���
    cmdOK.Enabled = True
    cmdCancel.Enabled = True
    Label5.Caption = Header.Text1(0).Text
End Sub

Private Sub cmdCancel_Click()
Adodc1.Recordset.CancelUpdate '¡��ԡ�������������
    cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
    cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
    cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdOK.Enabled = False '��͹���� OK
    cmdCancel.Enabled = False '��͹���� Cancel
    Adodc1.Enabled = True '��˹����͹��� ADO Data �����ʶҹл��

End Sub

Private Sub cmdDelete_Click()
'��͹ź��礤��� ��ͧ��ä��׹�ѹ��͹
If MsgBox("�س��ͧ���ź��礤��촹�� ���������?", vbYesNo, "�׹�ѹ���ź��礤���") = vbYes Then
   With Adodc1.Recordset
       .Delete   '�������ź��礤���
       .MoveNext   '����͹���礤��촶Ѵ�
            If Adodc1.Recordset.EOF Then  '��Ǩ�ͺ��� �繨ش����ش�������
                 Adodc1.Recordset.MoveLast  '����� �������͹��¹����� ����礤����ش����
            End If
   End With
End If
End Sub

Private Sub cmdEnd_Click()
 Dim response As Variant
    response = MsgBox("�س��ͧ��÷��кѹ�֡�������¹�ŧ������� ", vbExclamation + vbYesNoCancel + vbDefaultButton1, "�͡�ҡ������������ͧ")
    If response = vbYes Then
    Adodc1.Recordset.Update
    Unload Me
    ElseIf response = vbNo Then
    Unload Me
  End If
End Sub

Private Sub cmdOK_Click()
'��Ǩ�ͺ��͹��� �������Ťú�ء��ͧ�������
If (Text1(0).Text = "") Then '������ú
     MsgBox "�س�ѧ�����������ú!", vbOKOnly, "��ͼԴ��Ҵ"
 Else
     Adodc1.Enabled = True '��Ҥú��˹����͹��� ADO Data  �����ʶҹл���
     cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
    cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
    cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdOK.Enabled = False '��͹���� OK
    cmdCancel.Enabled = False '��͹���� Cancel
End If
End Sub

Private Sub cmdSearch_Click()
Header2Search.Show
End Sub

Private Sub cmdUpdate_Click()
 Adodc1.Recordset.Update '�������������㹰ҹ������
End Sub

Private Sub Command1_Click()
Header3.Show
End Sub

Private Sub Form_Load()
Dim userCriteria As String '���͹䢢ͧ�����
     Dim result As String '�š�ä���
     Dim respond As Variant
     '���Ŵ� Heade �����͹�㹡�ä���
      userCriteria = "Header1 like '" & Header1.Label5.Caption & "'"
     With Adodc1.Recordset
           .MoveFirst '����¹��������价���õ����á��͹
           .Find userCriteria, , adSearchForward '��������ҵ�����͹�
     End With
        If Adodc1.Recordset.EOF Then '�����辺�������ͧ����ͧ���
               Call cmdAdd_Click
               Label5.Caption = Header1.Label5.Caption
                Label7.Caption = Header1.Text1(0).Text
         Else
             Label5.Caption = Header1.Label5.Caption
             Label7.Caption = Header1.Text1(0).Text
             
        End If
End Sub

