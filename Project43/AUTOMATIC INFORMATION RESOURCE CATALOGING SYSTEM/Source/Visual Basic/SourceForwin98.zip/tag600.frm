VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form tag600 
   Caption         =   "tag600"
   ClientHeight    =   7860
   ClientLeft      =   45
   ClientTop       =   1080
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin TabDlg.SSTab SSTab1 
      Height          =   8265
      Left            =   0
      TabIndex        =   82
      Top             =   0
      Width           =   12000
      _ExtentX        =   21167
      _ExtentY        =   14579
      _Version        =   393216
      TabHeight       =   520
      TabCaption(0)   =   "Tag600"
      TabPicture(0)   =   "tag600.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Label8"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "Label7"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Label5"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).Control(3)=   "Label4"
      Tab(0).Control(3).Enabled=   0   'False
      Tab(0).Control(4)=   "Label3"
      Tab(0).Control(4).Enabled=   0   'False
      Tab(0).Control(5)=   "Label2"
      Tab(0).Control(5).Enabled=   0   'False
      Tab(0).Control(6)=   "Label1(0)"
      Tab(0).Control(6).Enabled=   0   'False
      Tab(0).Control(7)=   "Label6"
      Tab(0).Control(7).Enabled=   0   'False
      Tab(0).Control(8)=   "Label21"
      Tab(0).Control(8).Enabled=   0   'False
      Tab(0).Control(9)=   "Label22"
      Tab(0).Control(9).Enabled=   0   'False
      Tab(0).Control(10)=   "Label23"
      Tab(0).Control(10).Enabled=   0   'False
      Tab(0).Control(11)=   "Label24"
      Tab(0).Control(11).Enabled=   0   'False
      Tab(0).Control(12)=   "Label1(1)"
      Tab(0).Control(12).Enabled=   0   'False
      Tab(0).Control(13)=   "tag600_s1"
      Tab(0).Control(13).Enabled=   0   'False
      Tab(0).Control(14)=   "tag600_q1"
      Tab(0).Control(14).Enabled=   0   'False
      Tab(0).Control(15)=   "tag600_9"
      Tab(0).Control(15).Enabled=   0   'False
      Tab(0).Control(16)=   "tag600_10"
      Tab(0).Control(16).Enabled=   0   'False
      Tab(0).Control(17)=   "tag600_11"
      Tab(0).Control(17).Enabled=   0   'False
      Tab(0).Control(18)=   "tag600_5"
      Tab(0).Control(18).Enabled=   0   'False
      Tab(0).Control(19)=   "tag600_6"
      Tab(0).Control(19).Enabled=   0   'False
      Tab(0).Control(20)=   "tag600_7"
      Tab(0).Control(20).Enabled=   0   'False
      Tab(0).Control(21)=   "tag600_8"
      Tab(0).Control(21).Enabled=   0   'False
      Tab(0).Control(22)=   "tag600_1"
      Tab(0).Control(22).Enabled=   0   'False
      Tab(0).Control(23)=   "tag600_2"
      Tab(0).Control(23).Enabled=   0   'False
      Tab(0).Control(24)=   "tag600_3"
      Tab(0).Control(24).Enabled=   0   'False
      Tab(0).Control(25)=   "tag600_4"
      Tab(0).Control(25).Enabled=   0   'False
      Tab(0).Control(26)=   "Command4"
      Tab(0).Control(26).Enabled=   0   'False
      Tab(0).Control(27)=   "Command5"
      Tab(0).Control(27).Enabled=   0   'False
      Tab(0).Control(28)=   "indicator(0)"
      Tab(0).Control(28).Enabled=   0   'False
      Tab(0).Control(29)=   "Newcmd"
      Tab(0).Control(29).Enabled=   0   'False
      Tab(0).ControlCount=   30
      TabCaption(1)   =   "Tag610-Tag611"
      TabPicture(1)   =   "tag600.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Command7"
      Tab(1).Control(1)=   "indicator(2)"
      Tab(1).Control(2)=   "indicator(1)"
      Tab(1).Control(3)=   "Command1"
      Tab(1).Control(4)=   "Command3"
      Tab(1).Control(5)=   "tag610_4"
      Tab(1).Control(6)=   "tag610_3"
      Tab(1).Control(7)=   "tag610_2"
      Tab(1).Control(8)=   "tag610_1"
      Tab(1).Control(9)=   "tag610_8"
      Tab(1).Control(10)=   "tag610_7"
      Tab(1).Control(11)=   "tag610_6"
      Tab(1).Control(12)=   "tag610_5"
      Tab(1).Control(13)=   "tag610_11"
      Tab(1).Control(14)=   "tag610_10"
      Tab(1).Control(15)=   "tag610_9"
      Tab(1).Control(16)=   "tag610_14"
      Tab(1).Control(17)=   "tag610_13"
      Tab(1).Control(18)=   "tag610_12"
      Tab(1).Control(19)=   "tag611_4"
      Tab(1).Control(20)=   "tag611_3"
      Tab(1).Control(21)=   "tag611_2"
      Tab(1).Control(22)=   "tag611_1"
      Tab(1).Control(23)=   "tag611_6"
      Tab(1).Control(24)=   "tag611_7"
      Tab(1).Control(25)=   "tag611_8"
      Tab(1).Control(26)=   "tag611_5"
      Tab(1).Control(27)=   "tag611_10"
      Tab(1).Control(28)=   "tag611_9"
      Tab(1).Control(29)=   "tag600_q2"
      Tab(1).Control(30)=   "tag600_s2"
      Tab(1).Control(31)=   "Label1(3)"
      Tab(1).Control(32)=   "Label1(2)"
      Tab(1).Control(33)=   "Label9"
      Tab(1).Control(34)=   "Label10"
      Tab(1).Control(35)=   "Label11"
      Tab(1).Control(36)=   "Label12"
      Tab(1).Control(37)=   "Label13"
      Tab(1).Control(38)=   "Label14"
      Tab(1).Control(39)=   "Label15"
      Tab(1).Control(40)=   "Label16"
      Tab(1).Control(41)=   "Label17"
      Tab(1).Control(42)=   "Label18"
      Tab(1).Control(43)=   "Label19"
      Tab(1).Control(44)=   "Label20"
      Tab(1).Control(45)=   "Label25"
      Tab(1).Control(46)=   "Label26"
      Tab(1).Control(47)=   "Label27"
      Tab(1).Control(48)=   "Label28"
      Tab(1).Control(49)=   "Label29"
      Tab(1).Control(50)=   "Label30"
      Tab(1).Control(51)=   "Label31"
      Tab(1).Control(52)=   "Label32"
      Tab(1).Control(53)=   "Label33"
      Tab(1).Control(54)=   "Label34"
      Tab(1).Control(55)=   "Label35"
      Tab(1).Control(56)=   "Label36"
      Tab(1).Control(57)=   "Label37"
      Tab(1).Control(58)=   "Label38"
      Tab(1).ControlCount=   59
      TabCaption(2)   =   "Tag630-Tag651"
      TabPicture(2)   =   "tag600.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Command8"
      Tab(2).Control(1)=   "indicator(5)"
      Tab(2).Control(2)=   "indicator(4)"
      Tab(2).Control(3)=   "indicator(3)"
      Tab(2).Control(4)=   "Command6"
      Tab(2).Control(5)=   "Command2"
      Tab(2).Control(6)=   "tag630_4"
      Tab(2).Control(7)=   "tag630_3"
      Tab(2).Control(8)=   "tag630_2"
      Tab(2).Control(9)=   "tag630_1"
      Tab(2).Control(10)=   "tag630_7"
      Tab(2).Control(11)=   "tag630_8"
      Tab(2).Control(12)=   "tag630_6"
      Tab(2).Control(13)=   "tag630_5"
      Tab(2).Control(14)=   "tag630_10"
      Tab(2).Control(15)=   "tag630_9"
      Tab(2).Control(16)=   "tag630_14"
      Tab(2).Control(17)=   "tag630_13"
      Tab(2).Control(18)=   "tag630_12"
      Tab(2).Control(19)=   "tag630_11"
      Tab(2).Control(20)=   "tag630_16"
      Tab(2).Control(21)=   "tag630_15"
      Tab(2).Control(22)=   "tag650_4"
      Tab(2).Control(23)=   "tag650_3"
      Tab(2).Control(24)=   "tag650_2"
      Tab(2).Control(25)=   "tag650_1"
      Tab(2).Control(26)=   "tag650_5"
      Tab(2).Control(27)=   "tag651_4"
      Tab(2).Control(28)=   "tag651_3"
      Tab(2).Control(29)=   "tag651_2"
      Tab(2).Control(30)=   "tag651_1"
      Tab(2).Control(31)=   "tag651_5"
      Tab(2).Control(32)=   "tag600_q3"
      Tab(2).Control(33)=   "tag600_s3"
      Tab(2).Control(34)=   "Label1(6)"
      Tab(2).Control(35)=   "Label1(5)"
      Tab(2).Control(36)=   "Label1(4)"
      Tab(2).Control(37)=   "Label39"
      Tab(2).Control(38)=   "Label40"
      Tab(2).Control(39)=   "Label41"
      Tab(2).Control(40)=   "Label42"
      Tab(2).Control(41)=   "Label43"
      Tab(2).Control(42)=   "Label44"
      Tab(2).Control(43)=   "Label45"
      Tab(2).Control(44)=   "Label46"
      Tab(2).Control(45)=   "Label47"
      Tab(2).Control(46)=   "Label48"
      Tab(2).Control(47)=   "Label49"
      Tab(2).Control(48)=   "Label50"
      Tab(2).Control(49)=   "Label51"
      Tab(2).Control(50)=   "Label52"
      Tab(2).Control(51)=   "Label53"
      Tab(2).Control(52)=   "Label54"
      Tab(2).Control(53)=   "Label55"
      Tab(2).Control(54)=   "Label56"
      Tab(2).Control(55)=   "Label57"
      Tab(2).Control(56)=   "Label58"
      Tab(2).Control(57)=   "Label59"
      Tab(2).Control(58)=   "Label60"
      Tab(2).Control(59)=   "Label61"
      Tab(2).Control(60)=   "Label62"
      Tab(2).Control(61)=   "Label63"
      Tab(2).Control(62)=   "Label64"
      Tab(2).Control(63)=   "Label65"
      Tab(2).Control(64)=   "Label66"
      Tab(2).Control(65)=   "Label67"
      Tab(2).ControlCount=   66
      Begin VB.CommandButton Command8 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -71880
         TabIndex        =   77
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton Command7 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -72000
         TabIndex        =   43
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton Newcmd 
         Caption         =   "New"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3120
         TabIndex        =   12
         Top             =   7080
         Width           =   1455
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   5
         Left            =   -64320
         MaxLength       =   2
         TabIndex        =   71
         Top             =   3120
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   4
         Left            =   -64560
         MaxLength       =   2
         TabIndex        =   65
         Top             =   600
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   3
         Left            =   -70200
         MaxLength       =   2
         TabIndex        =   48
         Top             =   600
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   2
         Left            =   -64680
         MaxLength       =   2
         TabIndex        =   32
         Top             =   1080
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   1
         Left            =   -71040
         MaxLength       =   2
         TabIndex        =   17
         Top             =   1080
         Width           =   375
      End
      Begin VB.TextBox indicator 
         Height          =   375
         Index           =   0
         Left            =   6600
         MaxLength       =   2
         TabIndex        =   0
         Top             =   1680
         Width           =   375
      End
      Begin VB.CommandButton Command6 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -67200
         TabIndex        =   80
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command2 
         Caption         =   "NEXT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -66360
         TabIndex        =   81
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command1 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -67320
         TabIndex        =   46
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command3 
         Caption         =   "NEXT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -66480
         TabIndex        =   47
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command5 
         Caption         =   "BACK"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   7800
         TabIndex        =   15
         Top             =   7080
         Width           =   735
      End
      Begin VB.CommandButton Command4 
         Caption         =   "NEXT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   8640
         TabIndex        =   16
         Top             =   7080
         Width           =   735
      End
      Begin VB.TextBox tag600_4 
         Height          =   315
         Left            =   6240
         TabIndex        =   4
         Top             =   3240
         Width           =   2775
      End
      Begin VB.TextBox tag600_3 
         Height          =   315
         Left            =   6240
         TabIndex        =   3
         Top             =   2880
         Width           =   2775
      End
      Begin VB.TextBox tag600_2 
         Height          =   315
         Left            =   6240
         TabIndex        =   2
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox tag600_1 
         Height          =   315
         Left            =   6240
         TabIndex        =   1
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag600_8 
         Height          =   315
         Left            =   6240
         TabIndex        =   8
         Top             =   4680
         Width           =   2775
      End
      Begin VB.TextBox tag600_7 
         Height          =   315
         Left            =   6240
         TabIndex        =   7
         Top             =   4320
         Width           =   2775
      End
      Begin VB.TextBox tag600_6 
         Height          =   315
         Left            =   6240
         TabIndex        =   6
         Top             =   3960
         Width           =   2775
      End
      Begin VB.TextBox tag600_5 
         Height          =   315
         Left            =   6240
         TabIndex        =   5
         Top             =   3600
         Width           =   2775
      End
      Begin VB.TextBox tag600_11 
         Height          =   315
         Left            =   6240
         TabIndex        =   11
         Top             =   5760
         Width           =   2775
      End
      Begin VB.TextBox tag600_10 
         Height          =   315
         Left            =   6240
         TabIndex        =   10
         Top             =   5400
         Width           =   2775
      End
      Begin VB.TextBox tag600_9 
         Height          =   315
         Left            =   6240
         TabIndex        =   9
         Top             =   5040
         Width           =   2775
      End
      Begin VB.TextBox tag610_4 
         Height          =   315
         Left            =   -71880
         TabIndex        =   21
         Top             =   2640
         Width           =   2775
      End
      Begin VB.TextBox tag610_3 
         Height          =   315
         Left            =   -71880
         TabIndex        =   20
         Top             =   2280
         Width           =   2775
      End
      Begin VB.TextBox tag610_2 
         Height          =   315
         Left            =   -71880
         TabIndex        =   19
         Top             =   1920
         Width           =   2775
      End
      Begin VB.TextBox tag610_1 
         Height          =   315
         Left            =   -71880
         TabIndex        =   18
         Top             =   1560
         Width           =   2775
      End
      Begin VB.TextBox tag610_8 
         Height          =   315
         Left            =   -70560
         TabIndex        =   25
         Top             =   4080
         Width           =   1455
      End
      Begin VB.TextBox tag610_7 
         Height          =   315
         Left            =   -71880
         TabIndex        =   24
         Top             =   3720
         Width           =   2775
      End
      Begin VB.TextBox tag610_6 
         Height          =   315
         Left            =   -71880
         TabIndex        =   23
         Top             =   3360
         Width           =   2775
      End
      Begin VB.TextBox tag610_5 
         Height          =   315
         Left            =   -71520
         TabIndex        =   22
         Top             =   3000
         Width           =   2415
      End
      Begin VB.TextBox tag610_11 
         Height          =   315
         Left            =   -71880
         TabIndex        =   28
         Top             =   5160
         Width           =   2775
      End
      Begin VB.TextBox tag610_10 
         Height          =   315
         Left            =   -71880
         TabIndex        =   27
         Top             =   4800
         Width           =   2775
      End
      Begin VB.TextBox tag610_9 
         Height          =   315
         Left            =   -71880
         TabIndex        =   26
         Top             =   4440
         Width           =   2775
      End
      Begin VB.TextBox tag610_14 
         Height          =   315
         Left            =   -71880
         TabIndex        =   31
         Top             =   6240
         Width           =   2775
      End
      Begin VB.TextBox tag610_13 
         Height          =   315
         Left            =   -71880
         TabIndex        =   30
         Top             =   5880
         Width           =   2775
      End
      Begin VB.TextBox tag610_12 
         Height          =   315
         Left            =   -71880
         TabIndex        =   29
         Top             =   5520
         Width           =   2775
      End
      Begin VB.TextBox tag611_4 
         Height          =   315
         Left            =   -66000
         TabIndex        =   36
         Top             =   2640
         Width           =   2775
      End
      Begin VB.TextBox tag611_3 
         Height          =   315
         Left            =   -66000
         TabIndex        =   35
         Top             =   2280
         Width           =   2775
      End
      Begin VB.TextBox tag611_2 
         Height          =   315
         Left            =   -66000
         TabIndex        =   34
         Top             =   1920
         Width           =   2775
      End
      Begin VB.TextBox tag611_1 
         Height          =   315
         Left            =   -66000
         TabIndex        =   33
         Top             =   1560
         Width           =   2775
      End
      Begin VB.TextBox tag611_6 
         Height          =   315
         Left            =   -64680
         TabIndex        =   38
         Top             =   3360
         Width           =   1455
      End
      Begin VB.TextBox tag611_7 
         Height          =   315
         Left            =   -66000
         TabIndex        =   39
         Top             =   3720
         Width           =   2775
      End
      Begin VB.TextBox tag611_8 
         Height          =   315
         Left            =   -66000
         TabIndex        =   40
         Top             =   4080
         Width           =   2775
      End
      Begin VB.TextBox tag611_5 
         Height          =   315
         Left            =   -66000
         TabIndex        =   37
         Top             =   3000
         Width           =   2775
      End
      Begin VB.TextBox tag611_10 
         Height          =   315
         Left            =   -66000
         TabIndex        =   42
         Top             =   4800
         Width           =   2775
      End
      Begin VB.TextBox tag611_9 
         Height          =   315
         Left            =   -66000
         TabIndex        =   41
         Top             =   4440
         Width           =   2775
      End
      Begin VB.TextBox tag630_4 
         Height          =   315
         Left            =   -71760
         TabIndex        =   52
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag630_3 
         Height          =   315
         Left            =   -71760
         TabIndex        =   51
         Top             =   1800
         Width           =   2775
      End
      Begin VB.TextBox tag630_2 
         Height          =   315
         Left            =   -71760
         TabIndex        =   50
         Top             =   1440
         Width           =   2775
      End
      Begin VB.TextBox tag630_1 
         Height          =   315
         Left            =   -71760
         TabIndex        =   49
         Top             =   1080
         Width           =   2775
      End
      Begin VB.TextBox tag630_7 
         Height          =   315
         Left            =   -70440
         TabIndex        =   55
         Top             =   3240
         Width           =   1455
      End
      Begin VB.TextBox tag630_8 
         Height          =   315
         Left            =   -71760
         TabIndex        =   56
         Top             =   3600
         Width           =   2775
      End
      Begin VB.TextBox tag630_6 
         Height          =   315
         Left            =   -71760
         TabIndex        =   54
         Top             =   2880
         Width           =   2775
      End
      Begin VB.TextBox tag630_5 
         Height          =   315
         Left            =   -71760
         TabIndex        =   53
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox tag630_10 
         Height          =   315
         Left            =   -71760
         TabIndex        =   58
         Top             =   4320
         Width           =   2775
      End
      Begin VB.TextBox tag630_9 
         Height          =   315
         Left            =   -71760
         TabIndex        =   57
         Top             =   3960
         Width           =   2775
      End
      Begin VB.TextBox tag630_14 
         Height          =   315
         Left            =   -71760
         TabIndex        =   62
         Top             =   5760
         Width           =   2775
      End
      Begin VB.TextBox tag630_13 
         Height          =   315
         Left            =   -71760
         TabIndex        =   61
         Top             =   5400
         Width           =   2775
      End
      Begin VB.TextBox tag630_12 
         Height          =   315
         Left            =   -71760
         TabIndex        =   60
         Top             =   5040
         Width           =   2775
      End
      Begin VB.TextBox tag630_11 
         Height          =   315
         Left            =   -71760
         TabIndex        =   59
         Top             =   4680
         Width           =   2775
      End
      Begin VB.TextBox tag630_16 
         Height          =   315
         Left            =   -71760
         TabIndex        =   64
         Top             =   6480
         Width           =   2775
      End
      Begin VB.TextBox tag630_15 
         Height          =   315
         Left            =   -71760
         TabIndex        =   63
         Top             =   6120
         Width           =   2775
      End
      Begin VB.TextBox tag650_4 
         Height          =   315
         Left            =   -65880
         TabIndex        =   69
         Top             =   2160
         Width           =   2775
      End
      Begin VB.TextBox tag650_3 
         Height          =   315
         Left            =   -65880
         TabIndex        =   68
         Top             =   1800
         Width           =   2775
      End
      Begin VB.TextBox tag650_2 
         Height          =   315
         Left            =   -65880
         TabIndex        =   67
         Top             =   1440
         Width           =   2775
      End
      Begin VB.TextBox tag650_1 
         Height          =   315
         Left            =   -65880
         TabIndex        =   66
         Top             =   1080
         Width           =   2775
      End
      Begin VB.TextBox tag650_5 
         Height          =   315
         Left            =   -65880
         TabIndex        =   70
         Top             =   2520
         Width           =   2775
      End
      Begin VB.TextBox tag651_4 
         Height          =   315
         Left            =   -65880
         TabIndex        =   75
         Top             =   4680
         Width           =   2775
      End
      Begin VB.TextBox tag651_3 
         Height          =   315
         Left            =   -65880
         TabIndex        =   74
         Top             =   4320
         Width           =   2775
      End
      Begin VB.TextBox tag651_2 
         Height          =   315
         Left            =   -65880
         TabIndex        =   73
         Top             =   3960
         Width           =   2775
      End
      Begin VB.TextBox tag651_1 
         Height          =   315
         Left            =   -65880
         TabIndex        =   72
         Top             =   3600
         Width           =   2775
      End
      Begin VB.TextBox tag651_5 
         Height          =   315
         Left            =   -65880
         TabIndex        =   76
         Top             =   5040
         Width           =   2775
      End
      Begin VB.CommandButton tag600_q1 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   4680
         TabIndex        =   13
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag600_s1 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   6240
         TabIndex        =   14
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag600_q2 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -70440
         TabIndex        =   44
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag600_s2 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -68880
         TabIndex        =   45
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag600_q3 
         Caption         =   "QUIT"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -70320
         TabIndex        =   78
         Top             =   7080
         Width           =   1455
      End
      Begin VB.CommandButton tag600_s3 
         Caption         =   "SAVE"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   -68760
         TabIndex        =   79
         Top             =   7080
         Width           =   1455
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   6
         Left            =   -63840
         TabIndex        =   155
         Top             =   3120
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   5
         Left            =   -64080
         TabIndex        =   154
         Top             =   600
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   4
         Left            =   -69720
         TabIndex        =   153
         Top             =   600
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   3
         Left            =   -64080
         TabIndex        =   152
         Top             =   1080
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   2
         Left            =   -70440
         TabIndex        =   151
         Top             =   1080
         Width           =   855
      End
      Begin VB.Label Label1 
         Caption         =   "��Ǻ觪��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   1
         Left            =   7200
         TabIndex        =   150
         Top             =   1680
         Width           =   855
      End
      Begin VB.Label Label24 
         Caption         =   "���Դ-�յ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   149
         Top             =   3240
         Width           =   2295
      End
      Begin VB.Label Label23 
         Caption         =   "���˹�  ��  ��ô��ѡ���  �������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   148
         Top             =   2880
         Width           =   3135
      End
      Begin VB.Label Label22 
         Caption         =   "�Ţ���ѹ�������ѧ���͵�"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   147
         Top             =   2520
         Width           =   2415
      End
      Begin VB.Label Label21 
         Caption         =   "���ͺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   146
         Top             =   2160
         Width           =   1695
      End
      Begin VB.Label Label6 
         Caption         =   "600 ��¡�������������ͧ : ���ͺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   145
         Top             =   1680
         Width           =   4455
      End
      Begin VB.Label Label1 
         Caption         =   "�������ͧ���·����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Index           =   0
         Left            =   2640
         TabIndex        =   144
         Top             =   4680
         Width           =   2295
      End
      Begin VB.Label Label2 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   143
         Top             =   4320
         Width           =   2535
      End
      Begin VB.Label Label3 
         Caption         =   "�������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   142
         Top             =   3960
         Width           =   2415
      End
      Begin VB.Label Label4 
         Caption         =   "��ǹ��Сͺ���¢ͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   141
         Top             =   3600
         Width           =   2535
      End
      Begin VB.Label Label5 
         Caption         =   "���觷���Ңͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   140
         Top             =   5760
         Width           =   2295
      End
      Begin VB.Label Label7 
         Caption         =   "�������ͧ���ª��ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   139
         Top             =   5400
         Width           =   2655
      End
      Begin VB.Label Label8 
         Caption         =   "�������ͧ��������ǡѺ�ӴѺ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2640
         TabIndex        =   138
         Top             =   5040
         Width           =   2775
      End
      Begin VB.Label Label9 
         Caption         =   "�շ��Ѵ��Ъ�����ͷ�ʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   137
         Top             =   2640
         Width           =   2775
      End
      Begin VB.Label Label10 
         Caption         =   "ʶҹ���Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   136
         Top             =   2280
         Width           =   3135
      End
      Begin VB.Label Label11 
         Caption         =   "����˹��§ҹ�ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   135
         Top             =   1920
         Width           =   2415
      End
      Begin VB.Label Label12 
         Caption         =   "���͹ԵԺؤ��  ���ͪ��͵��������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   134
         Top             =   1560
         Width           =   3135
      End
      Begin VB.Label Label13 
         Caption         =   "610 ��¡�������������ͧ : �ԵԺؤ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   133
         Top             =   1080
         Width           =   4455
      End
      Begin VB.Label Label14 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   132
         Top             =   4080
         Width           =   4455
      End
      Begin VB.Label Label15 
         Caption         =   "��ǹ��Сͺ���¢ͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   131
         Top             =   3720
         Width           =   2535
      End
      Begin VB.Label Label16 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   130
         Top             =   3360
         Width           =   2415
      End
      Begin VB.Label Label17 
         Caption         =   "���кؤ�������ѹ��ԵԺؤ�šѺ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   129
         Top             =   3000
         Width           =   3255
      End
      Begin VB.Label Label18 
         Caption         =   "�������ͧ���·����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   128
         Top             =   5160
         Width           =   2295
      End
      Begin VB.Label Label19 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   127
         Top             =   4800
         Width           =   2655
      End
      Begin VB.Label Label20 
         Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   126
         Top             =   4440
         Width           =   2775
      End
      Begin VB.Label Label25 
         Caption         =   "�����ͷ�����˹��������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   125
         Top             =   6240
         Width           =   2295
      End
      Begin VB.Label Label26 
         Caption         =   "�������ͧ���ª��ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   124
         Top             =   5880
         Width           =   2655
      End
      Begin VB.Label Label27 
         Caption         =   "�������ͧ��������ǡѺ�ӴѺ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   123
         Top             =   5520
         Width           =   2775
      End
      Begin VB.Label Label28 
         Caption         =   "��¡���ͧ�������͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   122
         Top             =   2640
         Width           =   2895
      End
      Begin VB.Label Label29 
         Caption         =   "�շ��Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   121
         Top             =   2280
         Width           =   3135
      End
      Begin VB.Label Label30 
         Caption         =   "ʶҹ���Ѵ��Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   120
         Top             =   1920
         Width           =   2415
      End
      Begin VB.Label Label31 
         Caption         =   "���͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   119
         Top             =   1560
         Width           =   3135
      End
      Begin VB.Label Label32 
         Caption         =   "611 ��¡�������������ͧ : ���͡�û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   118
         Top             =   1080
         Width           =   4455
      End
      Begin VB.Label Label33 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   117
         Top             =   3360
         Width           =   4455
      End
      Begin VB.Label Label34 
         Caption         =   "�������ͧ���·����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   116
         Top             =   3720
         Width           =   2535
      End
      Begin VB.Label Label35 
         Caption         =   "�������ͧ��������ǡѺ�ӴѺ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   115
         Top             =   4080
         Width           =   2775
      End
      Begin VB.Label Label36 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   114
         Top             =   3000
         Width           =   3255
      End
      Begin VB.Label Label37 
         Caption         =   "���觷���Ңͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   113
         Top             =   4800
         Width           =   2655
      End
      Begin VB.Label Label38 
         Caption         =   "�������ͧ���ª��ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -69000
         TabIndex        =   112
         Top             =   4440
         Width           =   2775
      End
      Begin VB.Label Label39 
         Caption         =   "��������´����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   111
         Top             =   2160
         Width           =   2775
      End
      Begin VB.Label Label40 
         Caption         =   "�բͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   110
         Top             =   1800
         Width           =   3135
      End
      Begin VB.Label Label41 
         Caption         =   "�շ��ŧ���ʹ���ѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   109
         Top             =   1440
         Width           =   2415
      End
      Begin VB.Label Label42 
         Caption         =   "��������ͧẺ��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   108
         Top             =   1080
         Width           =   3135
      End
      Begin VB.Label Label43 
         Caption         =   "630 ��¡�������������ͧ : ��������ͧẺ��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74880
         TabIndex        =   107
         Top             =   600
         Width           =   4575
      End
      Begin VB.Label Label44 
         Caption         =   "�����Ţ�͹/��ǹ�ͧ�ҹ/���駷��ͧ��û�Ъ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   106
         Top             =   3240
         Width           =   4455
      End
      Begin VB.Label Label45 
         Caption         =   "������º���§�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   105
         Top             =   3600
         Width           =   2535
      End
      Begin VB.Label Label46 
         Caption         =   "���Ңͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   104
         Top             =   2880
         Width           =   2415
      End
      Begin VB.Label Label47 
         Caption         =   "��������§ҹ����ٻẺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   103
         Top             =   2520
         Width           =   3255
      End
      Begin VB.Label Label48 
         Caption         =   "�ح����§"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   102
         Top             =   4320
         Width           =   2655
      End
      Begin VB.Label Label49 
         Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   101
         Top             =   3960
         Width           =   2775
      End
      Begin VB.Label Label50 
         Caption         =   "�������ͧ��������ǡѺ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   100
         Top             =   5760
         Width           =   4455
      End
      Begin VB.Label Label51 
         Caption         =   "�������ͧ���·����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   99
         Top             =   5400
         Width           =   2535
      End
      Begin VB.Label Label52 
         Caption         =   "���ͧ͢�ҹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   98
         Top             =   5040
         Width           =   2415
      End
      Begin VB.Label Label53 
         Caption         =   "��Ѻ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   97
         Top             =   4680
         Width           =   3255
      End
      Begin VB.Label Label54 
         Caption         =   "���觷���Ңͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   96
         Top             =   6480
         Width           =   2655
      End
      Begin VB.Label Label55 
         Caption         =   "�������ͧ���ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -74760
         TabIndex        =   95
         Top             =   6120
         Width           =   2775
      End
      Begin VB.Label Label56 
         Caption         =   "�������ͧ���ª��ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   94
         Top             =   2160
         Width           =   2775
      End
      Begin VB.Label Label57 
         Caption         =   "�������ͧ��������ǡѺ�ӴѺ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   93
         Top             =   1800
         Width           =   3135
      End
      Begin VB.Label Label58 
         Caption         =   "�������ͧ���·����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   92
         Top             =   1440
         Width           =   2415
      End
      Begin VB.Label Label59 
         Caption         =   "�������ͧ�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   91
         Top             =   1080
         Width           =   3135
      End
      Begin VB.Label Label60 
         Caption         =   "650 ��¡�������������ͧ : �������ͧ�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   90
         Top             =   600
         Width           =   4575
      End
      Begin VB.Label Label61 
         Caption         =   "���觷���Ңͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   89
         Top             =   2520
         Width           =   3255
      End
      Begin VB.Label Label62 
         Caption         =   "�������ͧ���ª��ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   88
         Top             =   4680
         Width           =   2775
      End
      Begin VB.Label Label63 
         Caption         =   "�������ͧ���������ӴѺ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   87
         Top             =   4320
         Width           =   3135
      End
      Begin VB.Label Label64 
         Caption         =   "�������ͧ���·����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   86
         Top             =   3960
         Width           =   2415
      End
      Begin VB.Label Label65 
         Caption         =   "���ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   85
         Top             =   3600
         Width           =   3135
      End
      Begin VB.Label Label66 
         Caption         =   "651 ��¡�������������ͧ : ���ͷҧ������ʵ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   84
         Top             =   3120
         Width           =   5055
      End
      Begin VB.Label Label67 
         Caption         =   "���觷���Ңͧ�������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   -68880
         TabIndex        =   83
         Top             =   5040
         Width           =   3255
      End
   End
End
Attribute VB_Name = "tag600"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
tagselect.Command7.SetFocus
tag500.Show

End Sub

Private Sub Command2_Click()
tagselect.Command9.SetFocus
tag700.Show

End Sub

Private Sub Command3_Click()
tagselect.Command9.SetFocus
tag700.Show

End Sub

Private Sub Command4_Click()
tagselect.Command9.SetFocus
tag700.Show

End Sub

Private Sub Command5_Click()
tagselect.Command7.SetFocus
tag500.Show

End Sub

Private Sub Command6_Click()
tagselect.Command7.SetFocus
tag500.Show

End Sub

Private Sub Command7_Click()
MarcMenu.newedit
End Sub

Private Sub Command8_Click()
MarcMenu.newedit
End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag600_q1_Click()
MarcMenu.quitting
End Sub

Private Sub tag600_q2_Click()
MarcMenu.quitting
End Sub
Private Sub tag600_q3_Click()
MarcMenu.quitting
End Sub

Private Sub tag600_s1_Click()
MarcMenu.saving
End Sub

Private Sub tag600_s2_Click()
MarcMenu.saving
End Sub

Private Sub tag600_s3_Click()
MarcMenu.saving
End Sub
