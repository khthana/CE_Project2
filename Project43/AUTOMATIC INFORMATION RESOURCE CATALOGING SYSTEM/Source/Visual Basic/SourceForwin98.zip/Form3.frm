VERSION 5.00
Begin VB.Form HeaderMenu 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "MENU HEADER CODE PROGRAM"
   ClientHeight    =   6105
   ClientLeft      =   1080
   ClientTop       =   2025
   ClientWidth     =   8805
   FillColor       =   &H00FFFFFF&
   ForeColor       =   &H8000000E&
   Icon            =   "Form3.frx":0000
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6105
   ScaleWidth      =   8805
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��Ѻ��ѧ Menu ��ѡ"
      DragIcon        =   "Form3.frx":110A
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   3120
      TabIndex        =   3
      Top             =   4320
      Width           =   2775
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��������¤��Ң������Ţ�������ͧ�ҡ WEB "
      DragIcon        =   "Form3.frx":1414
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3120
      TabIndex        =   2
      Top             =   3360
      Width           =   4815
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��������¤��Ң������Ţ�������ͧ�ҡ�ҹ������"
      DragIcon        =   "Form3.frx":171E
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3120
      TabIndex        =   1
      Top             =   2400
      Width           =   5175
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "�������á�͡�������Ţ�������ͧ"
      DragIcon        =   "Form3.frx":1A28
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   3120
      TabIndex        =   0
      Top             =   1440
      Width           =   3735
   End
End
Attribute VB_Name = "HeaderMenu"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Label1_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If Source Is Label1(Index) Then
        With Label1(Index)
            .Font.Underline = False
            .ForeColor = vbBlack
            Screen.MousePointer = vbHourglass
            
            Select Case Index
            Case 0
                Header.Show
            Case 1
                SearchHeader.Show
            Case 2
              SearchList.Show
            Case 3
               Unload Me
            
            End Select
            Screen.MousePointer = vbNormal
        End With
    End If
End Sub

Private Sub Label1_DragOver(Index As Integer, Source As Control, X As Single, Y As Single, State As Integer)
If State = vbLeave Then
        With Label1(Index)
            .Drag vbEndDrag
            .Font.Underline = False
            .ForeColor = vbBlack
           'image1(0).Picture = Image1(5).Picture
         
        End With
    End If

End Sub

Private Sub Label1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
With Label1(Index)
        .ForeColor = vbBlue
        .Font.Underline = True
        .Drag vbBeginDrag
        'Image1(0).Picture = Image1(Index + 1).Picture

    End With
  
End Sub
