VERSION 5.00
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Begin VB.Form AuthorThai 
   BackColor       =   &H80000009&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "ThaiAuthor"
   ClientHeight    =   4005
   ClientLeft      =   870
   ClientTop       =   2055
   ClientWidth     =   8100
   Icon            =   "AuthorThai.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4005
   ScaleWidth      =   8100
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdSearch 
      Caption         =   "&Search"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6120
      TabIndex        =   11
      ToolTipText     =   "���Ң�����"
      Top             =   2040
      Width           =   1575
   End
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   495
      Left            =   720
      Top             =   3360
      Width           =   6960
      _ExtentX        =   12277
      _ExtentY        =   873
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   1
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   1
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=ThaiAuthor.mdb"
      OLEDBString     =   "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=ThaiAuthor.mdb"
      OLEDBFile       =   ""
      DataSourceName  =   ""
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   "select * from ThaiAuthor order by 1"
      Caption         =   ""
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin VB.TextBox Text2 
      DataField       =   "Tauthorcode"
      DataSource      =   "Adodc1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   2040
      TabIndex        =   10
      Top             =   1920
      Width           =   3735
   End
   Begin VB.TextBox Text1 
      DataField       =   "Tauthorname"
      DataSource      =   "Adodc1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   2040
      TabIndex        =   9
      Top             =   1200
      Width           =   3735
   End
   Begin VB.CommandButton cmdEnd 
      Caption         =   "&End"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6120
      TabIndex        =   5
      ToolTipText     =   "�͡�ҡ�����"
      Top             =   2640
      Width           =   1575
   End
   Begin VB.CommandButton cmdDelete 
      Caption         =   "&Delete"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6120
      TabIndex        =   4
      ToolTipText     =   "ź������"
      Top             =   1440
      Width           =   1575
   End
   Begin VB.CommandButton cmdUpdate 
      Caption         =   "&Update"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6120
      TabIndex        =   3
      ToolTipText     =   "�Ѿവ������"
      Top             =   840
      Width           =   1575
   End
   Begin VB.CommandButton cmdAdd 
      Caption         =   "&Add"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6120
      TabIndex        =   2
      ToolTipText     =   "����������"
      Top             =   240
      Width           =   1575
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "&Cancel"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4080
      TabIndex        =   1
      ToolTipText     =   "¡��ԡ��úѹ�֡������"
      Top             =   2640
      Width           =   1575
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   2160
      TabIndex        =   0
      ToolTipText     =   "�ѹ�֡������"
      Top             =   2640
      Width           =   1575
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "������Ѵ����Ţ�����(��)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   222
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H8000000D&
      Height          =   495
      Left            =   1080
      TabIndex        =   8
      Top             =   360
      Width           =   4455
   End
   Begin VB.Label lblLabels 
      BackColor       =   &H00FFFFFF&
      Caption         =   "���ʼ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   375
      Index           =   1
      Left            =   720
      TabIndex        =   7
      Top             =   1920
      Width           =   1335
   End
   Begin VB.Label lblLabels 
      BackColor       =   &H00FFFFFF&
      Caption         =   "���ͼ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   14.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   375
      Index           =   0
      Left            =   720
      TabIndex        =   6
      Top             =   1200
      Width           =   1095
   End
End
Attribute VB_Name = "AuthorThai"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Adodc1_MoveComplete(ByVal adReason As ADODB.EventReasonEnum, ByVal pError As ADODB.Error, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
    cmdAdd.Enabled = True
    cmdDelete.Enabled = True
    cmdEnd.Enabled = True
    cmdUpdate.Enabled = True
    cmdOK.Enabled = False
    cmdCancel.Enabled = False
    
Dim currentRecord As Integer
Dim allRecord As Integer
    With Adodc1.Recordset
        currentRecord = .AbsolutePosition
        allRecord = .RecordCount
    End With
Adodc1.Caption = "��������礤��� " & currentRecord & "/" & allRecord
End Sub

Private Sub cmdAdd_Click()
    Adodc1.Recordset.AddNew
    cmdAdd.Enabled = False
    cmdUpdate.Enabled = False
    cmdDelete.Enabled = False
    cmdEnd.Enabled = False
    cmdSearch.Enabled = False
    Adodc1.Enabled = False
    cmdOK.Enabled = True
    cmdCancel.Enabled = True
    End Sub

Private Sub cmdCancel_Click()
    Adodc1.Recordset.CancelUpdate
    cmdAdd.Enabled = True
    cmdUpdate.Enabled = True
    cmdDelete.Enabled = True
    cmdEnd.Enabled = True
    cmdSearch.Enabled = True
    cmdOK.Enabled = False
    cmdCancel.Enabled = False
    Adodc1.Enabled = True
End Sub

Private Sub cmdDelete_Click()
    If MsgBox("�س��ͧ���ź��礤��촹�����������?", vbYesNo, "�׹�ѹ���ź��礤���") = vbYes Then
        With Adodc1.Recordset
            .Delete
            .MoveNext
                If Adodc1.Recordset.EOF Then
                    Adodc1.Recordset.MoveLast
                End If
        End With
    End If
End Sub

Private Sub cmdEnd_Click()
    If MsgBox("�س��ͧ����͡�ҡ����� ���������?", vbYesNo, "���׹�ѹ") = vbYes Then
        Unload Me
    End If
End Sub

Private Sub cmdOK_Click()
    If (Text1.Text = "") Or (Text2.Text = "") Then
        MsgBox "�س�ѧ�����������ú!", vbOKOnly, "��ͼԴ��Ҵ"
    Else
        Adodc1.Enabled = True
        cmdAdd.Enabled = True
        cmdUpdate.Enabled = True
        cmdDelete.Enabled = True
        cmdEnd.Enabled = True
        cmdSearch.Enabled = True
        cmdOK.Enabled = False
        cmdCancel.Enabled = False
        Adodc1.Recordset.MoveFirst
    End If
End Sub

Private Sub cmdSearch_Click()
Dim userCriteria As String
Dim Searchtext As String
Searchtext = InputBox("��س������ͼ���觷���ͧ��ä���")
userCriteria = "Tauthorname like '" & Searchtext & "*'"
If Searchtext = "" Then
    MsgBox "�س�ѧ����������ͼ����! ��س������ͼ���觷���ͧ��ä��Ҵ���", vbYes, "���Ң����żԴ��Ҵ"
Else
    With Adodc1.Recordset
        .MoveFirst
        .Find userCriteria, , adSearchForward
    End With
End If
    If Adodc1.Recordset.EOF Then
        MsgBox "��辺������", vbYes, "�š�ä���"
        Adodc1.Recordset.MoveFirst
    End If
End Sub

Private Sub cmdUpdate_Click()
    Adodc1.Recordset.Update
End Sub

Private Sub Form_Load()
    cmdOK.Enabled = False
    cmdCancel.Enabled = False
 End Sub

