VERSION 5.00
Begin VB.Form tag100 
   Caption         =   "tag100"
   ClientHeight    =   7860
   ClientLeft      =   60
   ClientTop       =   1080
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton Newcmd 
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2880
      TabIndex        =   29
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   3
      Left            =   9720
      MaxLength       =   2
      TabIndex        =   20
      Top             =   3480
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   2
      Left            =   9480
      MaxLength       =   2
      TabIndex        =   13
      Top             =   600
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   1
      Left            =   3360
      MaxLength       =   2
      TabIndex        =   6
      Top             =   3960
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   0
      Left            =   3360
      MaxLength       =   2
      TabIndex        =   0
      Top             =   600
      Width           =   375
   End
   Begin VB.CommandButton Command1 
      Caption         =   "BACK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   7560
      TabIndex        =   32
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton Command3 
      Caption         =   "NEXT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   8400
      TabIndex        =   33
      Top             =   7080
      Width           =   735
   End
   Begin VB.TextBox tag130_7 
      Height          =   315
      Left            =   9720
      TabIndex        =   27
      Top             =   6120
      Width           =   2055
   End
   Begin VB.TextBox tag130_8 
      Height          =   315
      Left            =   9720
      TabIndex        =   28
      Top             =   6480
      Width           =   2055
   End
   Begin VB.TextBox tag130_6 
      Height          =   315
      Left            =   9720
      TabIndex        =   26
      Top             =   5760
      Width           =   2055
   End
   Begin VB.CommandButton tag100_s 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   6000
      TabIndex        =   31
      Top             =   7080
      Width           =   1455
   End
   Begin VB.CommandButton tag100_q 
      Caption         =   "QUIT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   4440
      TabIndex        =   30
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox tag100_2 
      Height          =   315
      Left            =   3240
      TabIndex        =   2
      Top             =   1440
      Width           =   2055
   End
   Begin VB.TextBox tag100_3 
      Height          =   315
      Left            =   3240
      TabIndex        =   3
      Top             =   1800
      Width           =   2055
   End
   Begin VB.TextBox tag100_1 
      Height          =   315
      Left            =   3240
      TabIndex        =   1
      Top             =   1080
      Width           =   2055
   End
   Begin VB.TextBox tag100_5 
      Height          =   315
      Left            =   3240
      TabIndex        =   5
      Top             =   2520
      Width           =   2055
   End
   Begin VB.TextBox tag100_4 
      Height          =   315
      Left            =   3240
      TabIndex        =   4
      Top             =   2160
      Width           =   2055
   End
   Begin VB.TextBox tag130_2 
      Height          =   315
      Left            =   9720
      TabIndex        =   22
      Top             =   4320
      Width           =   2055
   End
   Begin VB.TextBox tag130_3 
      Height          =   315
      Left            =   9720
      TabIndex        =   23
      Top             =   4680
      Width           =   2055
   End
   Begin VB.TextBox tag130_1 
      Height          =   315
      Left            =   9720
      TabIndex        =   21
      Top             =   3960
      Width           =   2055
   End
   Begin VB.TextBox tag130_5 
      Height          =   315
      Left            =   9720
      TabIndex        =   25
      Top             =   5400
      Width           =   2055
   End
   Begin VB.TextBox tag130_4 
      Height          =   315
      Left            =   9720
      TabIndex        =   24
      Top             =   5040
      Width           =   2055
   End
   Begin VB.TextBox tag110_2 
      Height          =   315
      Left            =   3240
      TabIndex        =   8
      Top             =   4800
      Width           =   2055
   End
   Begin VB.TextBox tag110_3 
      Height          =   315
      Left            =   3240
      TabIndex        =   9
      Top             =   5160
      Width           =   2055
   End
   Begin VB.TextBox tag110_1 
      Height          =   315
      Left            =   3240
      TabIndex        =   7
      Top             =   4440
      Width           =   2055
   End
   Begin VB.TextBox tag110_5 
      Height          =   315
      Left            =   3240
      TabIndex        =   11
      Top             =   5880
      Width           =   2055
   End
   Begin VB.TextBox tag110_4 
      Height          =   315
      Left            =   3240
      TabIndex        =   10
      Top             =   5520
      Width           =   2055
   End
   Begin VB.TextBox tag110_6 
      Height          =   315
      Left            =   3240
      TabIndex        =   12
      Top             =   6240
      Width           =   2055
   End
   Begin VB.TextBox tag111_2 
      Height          =   315
      Left            =   9720
      TabIndex        =   15
      Top             =   1440
      Width           =   2055
   End
   Begin VB.TextBox tag111_3 
      Height          =   315
      Left            =   9720
      TabIndex        =   16
      Top             =   1800
      Width           =   2055
   End
   Begin VB.TextBox tag111_1 
      Height          =   315
      Left            =   9720
      TabIndex        =   14
      Top             =   1080
      Width           =   2055
   End
   Begin VB.TextBox tag111_5 
      Height          =   315
      Left            =   9720
      TabIndex        =   18
      Top             =   2520
      Width           =   2055
   End
   Begin VB.TextBox tag111_4 
      Height          =   315
      Left            =   9720
      TabIndex        =   17
      Top             =   2160
      Width           =   2055
   End
   Begin VB.TextBox tag111_6 
      Height          =   315
      Left            =   9720
      TabIndex        =   19
      Top             =   2880
      Width           =   2055
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   4
      Left            =   10320
      TabIndex        =   66
      Top             =   3480
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   10080
      TabIndex        =   65
      Top             =   600
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3960
      TabIndex        =   64
      Top             =   3960
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3960
      TabIndex        =   63
      Top             =   600
      Width           =   855
   End
   Begin VB.Label Label3 
      Caption         =   "�����Ţ�͹/��ǹ�ͧ��������ͧẺ��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   62
      Top             =   5760
      Width           =   4215
   End
   Begin VB.Label Label2 
      Caption         =   "���͵͹/��ǹ�ͧ��������ͧẺ��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   61
      Top             =   6120
      Width           =   4215
   End
   Begin VB.Label Label1 
      Caption         =   "��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   5640
      TabIndex        =   60
      Top             =   6480
      Width           =   4215
   End
   Begin VB.Label Label50 
      Caption         =   "100 ��¡����ѡ���ͺؤ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   59
      Top             =   600
      Width           =   2895
   End
   Begin VB.Label Label51 
      Caption         =   "111 ��¡����ѡ���͡�û�Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   58
      Top             =   600
      Width           =   3495
   End
   Begin VB.Label Label54 
      Caption         =   "130 ��¡����ѡ��������ͧẺ��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   57
      Top             =   3600
      Width           =   3735
   End
   Begin VB.Label Label56 
      Caption         =   "110 ��¡����ѡ�ԵԺؤ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   56
      Top             =   3960
      Width           =   2895
   End
   Begin VB.Label Label57 
      Caption         =   "���ͺؤ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   55
      Top             =   1080
      Width           =   4215
   End
   Begin VB.Label Label37 
      Caption         =   "����Ţ���ѹ�������ѧ���͵�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   54
      Top             =   1440
      Width           =   4215
   End
   Begin VB.Label Label40 
      Caption         =   "���˹�  ��  ��ô��ѡ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   53
      Top             =   1800
      Width           =   4215
   End
   Begin VB.Label Label59 
      Caption         =   "���Դ-�յ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   52
      Top             =   2160
      Width           =   4215
   End
   Begin VB.Label Label60 
      Caption         =   "�������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   51
      Top             =   2520
      Width           =   4215
   End
   Begin VB.Label Label81 
      Caption         =   "���͹ԵԺؤ�����ͪ��͵��������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   50
      Top             =   4440
      Width           =   4215
   End
   Begin VB.Label Label82 
      Caption         =   "����˹��§ҹ�ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   49
      Top             =   4800
      Width           =   4215
   End
   Begin VB.Label Label83 
      Caption         =   "���駷��ͧ��û�Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   48
      Top             =   6240
      Width           =   4215
   End
   Begin VB.Label Label84 
      Caption         =   "��������´����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   47
      Top             =   5880
      Width           =   4215
   End
   Begin VB.Label Label85 
      Caption         =   "�շ��Ѵ��Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   46
      Top             =   5520
      Width           =   4215
   End
   Begin VB.Label Label86 
      Caption         =   "ʶҹ���Ѵ��Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   45
      Top             =   5160
      Width           =   4215
   End
   Begin VB.Label Label87 
      Caption         =   "��¡���ͧ���ŧ��¡���������͡�û�Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   44
      Top             =   2160
      Width           =   4215
   End
   Begin VB.Label Label88 
      Caption         =   "�շ��Ѵ��Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   43
      Top             =   1800
      Width           =   4215
   End
   Begin VB.Label Label89 
      Caption         =   "���͡�û�Ъ�������ѧ���͵��������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   42
      Top             =   2880
      Width           =   4215
   End
   Begin VB.Label Label90 
      Caption         =   "���駷��ͧ��û�Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   41
      Top             =   2520
      Width           =   4215
   End
   Begin VB.Label Label91 
      Caption         =   "ʶҹ���Ѵ��Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   40
      Top             =   1440
      Width           =   4215
   End
   Begin VB.Label Label92 
      Caption         =   "���͡�û�Ъ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   39
      Top             =   1080
      Width           =   4215
   End
   Begin VB.Label Label93 
      Caption         =   "���Ңͧ�ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   38
      Top             =   5400
      Width           =   4215
   End
   Begin VB.Label Label94 
      Caption         =   "��������µ���ٻẺ�ͧ��ʴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   37
      Top             =   5040
      Width           =   4215
   End
   Begin VB.Label Label95 
      Caption         =   "�բͧ�ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   36
      Top             =   4680
      Width           =   4215
   End
   Begin VB.Label Label96 
      Caption         =   "�շ��ŧ����ʹ���ѭ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   35
      Top             =   4320
      Width           =   4215
   End
   Begin VB.Label Label97 
      Caption         =   "��������ͧẺ��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5640
      TabIndex        =   34
      Top             =   3960
      Width           =   4215
   End
End
Attribute VB_Name = "tag100"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public OrderWs     As Workspace
Public OrderDb     As Database
Public Opendyna  As Recordset
Public sqlcommand  As String
Public Searchtext  As String
Public ComboHeaderCode As ComboBox
Public ComboAuthorCode As ComboBox
Private Sub Command1_Click()
tagselect.Command3.SetFocus
tag090.Show

End Sub

Private Sub Command3_Click()
tagselect.Command5.SetFocus
tag210.Show

End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag100_1_Change()
tag090.ComboAuthorCode.Clear
tag090.ComboAuthorCode.Text = "�Ţ�����˹ѧ���"
Set OrderWs = DBEngine.Workspaces(0)
 Set OrderDb = OrderWs.OpenDatabase("ThaiAuthor.mdb", False, False)
Searchtext = tag100_1.Text
'*****************ThaiAuthor************
If Searchtext <> "" Then
sqlcommand = " SELECT * FROM ThaiAuthor "
sqlcommand = sqlcommand & "WHERE TAuthorname LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*'"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna.EOF
If Opendyna.Fields("Tauthorcode") <> "" Then
tag090.ComboAuthorCode.AddItem Opendyna.Fields("Tauthorcode")
End If
Opendyna.MoveNext
Loop
End If
'*****************EngAuthor************
Set OrderWs = DBEngine.Workspaces(0)
 Set OrderDb = OrderWs.OpenDatabase("EngAuthor.mdb", False, False)
If Searchtext <> "" Then
sqlcommand = " SELECT * FROM EngAuthor "
sqlcommand = sqlcommand & "WHERE EAuthorname LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*'"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna.EOF
If Opendyna.Fields("Eauthorcode") <> "" Then
tag090.ComboAuthorCode.AddItem Opendyna.Fields("Eauthorcode")
End If
Opendyna.MoveNext
Loop
End If
End Sub


Private Sub tag100_q_Click()
MarcMenu.quitting
End Sub

Private Sub tag100_s_Click()
MarcMenu.saving
End Sub

Private Sub tag130_1_Change()
Dim tmp As String
Dim tmp1 As String
Dim i  As Integer

tag090.ComboHeaderCode.Clear
tag090.ComboHeaderCode.Text = "�Ţ�������ͧ˹ѧ���"
Set OrderWs = DBEngine.Workspaces(0)
 Set OrderDb = OrderWs.OpenDatabase("HeaderDB.mdb", False, False)
Searchtext = tag130_1.Text
 '*******************search tblMain******
 If Searchtext <> "" Then
sqlcommand = " SELECT * FROM tblMain "
sqlcommand = sqlcommand & "WHERE Header LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*'"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna.EOF
If Opendyna.Fields("LC_Dewey") <> "" Then
tmp = Opendyna.Fields("LC_Dewey")
tmp = Replace(tmp, ";", ",", 1)
a = 0
     Do
     i = InStr(a + 1, tmp, ",")
     
     If i <> 0 Then
          tmp1 = Left(tmp, i - 1)
     Else
          tmp1 = tmp
     End If
     
     tmp1 = Trim(tmp1)
     tmp = Mid(tmp, i + 1)
     tag090.ComboHeaderCode.AddItem tmp1
     Loop Until i = 0
End If
Opendyna.MoveNext
Loop
End If

'---------------------------------------------------------------- search tblsub1 -------------------------------------------------------------

If Searchtext <> "" Then
sqlcommand = " SELECT * FROM tblSub1 "
sqlcommand = sqlcommand & "WHERE Subheader_1 LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*'"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna.EOF
If Opendyna.Fields("LC_Dewey") <> "" Then
tmp = Opendyna.Fields("LC_Dewey")
tmp = Replace(tmp, ";", ",", 1)
a = 0
     Do
     i = InStr(a + 1, tmp, ",")
     
     If i <> 0 Then
          tmp1 = Left(tmp, i - 1)
     Else
          tmp1 = tmp
     End If
     
     tmp1 = Trim(tmp1)
     tmp = Mid(tmp, i + 1)
     tag090.ComboHeaderCode.AddItem tmp1
     Loop Until i = 0
End If

Opendyna.MoveNext
Loop
End If
'-----------------------------------------------------------------------search tblsub2 ------------------------------------------------------------

If Searchtext <> "" Then
sqlcommand = " SELECT * FROM tblSub2 "
sqlcommand = sqlcommand & "WHERE Subheader_2 LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*'"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna.EOF
If Opendyna.Fields("LC_Dewey") <> "" Then
tmp = Opendyna.Fields("LC_Dewey")
tmp = Replace(tmp, ";", ",", 1)
a = 0
     Do
     i = InStr(a + 1, tmp, ",")
     
     If i <> 0 Then
          tmp1 = Left(tmp, i - 1)
     Else
          tmp1 = tmp
     End If
     
     tmp1 = Trim(tmp1)
     tmp = Mid(tmp, i + 1)
     tag090.ComboHeaderCode.AddItem tmp1
     Loop Until i = 0
End If
Opendyna.MoveNext
Loop
End If

'----------------------------------------------------------search tblsub3 -------------------------------------------------------------------

If Searchtext <> "" Then
sqlcommand = " SELECT * FROM tblSub3 "
sqlcommand = sqlcommand & "WHERE Subheader_3 LIKE "
sqlcommand = sqlcommand & "'"
sqlcommand = sqlcommand & Searchtext
sqlcommand = sqlcommand & "*'"
Set Opendyna = OrderDb.OpenRecordset(sqlcommand, dbOpenDynaset)
Do Until Opendyna.EOF
If Opendyna.Fields("LC_Dewey") <> "" Then
tmp = Opendyna.Fields("LC_Dewey")
tmp = Replace(tmp, ";", ",", 1)
a = 0
     Do
     i = InStr(a + 1, tmp, ",")
     
     If i <> 0 Then
          tmp1 = Left(tmp, i - 1)
     Else
          tmp1 = tmp
     End If
     
     tmp1 = Trim(tmp1)
     tmp = Mid(tmp, i + 1)
     tag090.ComboHeaderCode.AddItem tmp1
     Loop Until i = 0
End If
Opendyna.MoveNext
Loop
End If
End Sub
