VERSION 5.00
Begin VB.Form Menu_Program 
   BackColor       =   &H00FF8080&
   Caption         =   "Manu_Program"
   ClientHeight    =   6945
   ClientLeft      =   525
   ClientTop       =   1905
   ClientWidth     =   9570
   LinkTopic       =   "Form1"
   ScaleHeight     =   6945
   ScaleWidth      =   9570
   WindowState     =   2  'Maximized
   Begin VB.CommandButton Command3 
      Caption         =   "Command3"
      Height          =   495
      Left            =   1680
      TabIndex        =   7
      Top             =   2640
      Width           =   1215
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Command2"
      Height          =   495
      Left            =   1680
      TabIndex        =   6
      Top             =   1800
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   495
      Left            =   1680
      TabIndex        =   5
      Top             =   1080
      Width           =   1215
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00FF8080&
      Caption         =   "MENU  PROGRAM"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   8535
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   11775
      Begin VB.CommandButton cmdCloseMain 
         Caption         =   "�͡�ҡ��÷ӧҹ�ͧ�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   975
         Left            =   3000
         TabIndex        =   4
         Top             =   5400
         Width           =   5895
      End
      Begin VB.CommandButton cmdMARCsheet 
         Caption         =   "�������èѴ��â����ŵ���к�MARC format"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   975
         Left            =   3000
         TabIndex        =   3
         Top             =   4200
         Width           =   5895
      End
      Begin VB.CommandButton cmdHeader 
         Caption         =   "�������èѴ����Ţ�������ͧ˹ѧ���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   975
         Left            =   3000
         TabIndex        =   2
         Top             =   3000
         Width           =   5895
      End
      Begin VB.CommandButton cmdAuthor 
         Caption         =   "�������èѴ����Ţ�����˹ѧ���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   975
         Left            =   3000
         MaskColor       =   &H8000000F&
         TabIndex        =   1
         Top             =   1800
         Width           =   5895
      End
   End
End
Attribute VB_Name = "Menu_Program"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdAuthor_Click()
Author_code.Show
End Sub

Private Sub cmdCloseMain_Click()
Unload Me
End Sub

Private Sub cmdHeader_Click()
MenuHeader.Show
End Sub

Private Sub cmdMARCsheet_Click()
mainmenu.Show
End Sub

Private Sub Command1_Click()
Header.Show
End Sub

Private Sub Command2_Click()
SearchHeader.Show
End Sub

Private Sub Command3_Click()
Form1.Show
End Sub
