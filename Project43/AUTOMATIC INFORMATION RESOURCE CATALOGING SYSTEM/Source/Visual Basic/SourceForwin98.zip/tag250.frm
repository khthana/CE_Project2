VERSION 5.00
Begin VB.Form tag250 
   Caption         =   "tag250"
   ClientHeight    =   7860
   ClientLeft      =   60
   ClientTop       =   1080
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton Newcmd 
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2640
      TabIndex        =   21
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   1
      Left            =   9720
      MaxLength       =   2
      TabIndex        =   18
      Top             =   3240
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   0
      Left            =   9720
      MaxLength       =   2
      TabIndex        =   12
      Top             =   120
      Width           =   375
   End
   Begin VB.CommandButton Command2 
      Caption         =   "BACK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   7320
      TabIndex        =   24
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Caption         =   "NEXT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   8160
      TabIndex        =   25
      Top             =   7080
      Width           =   735
   End
   Begin VB.CommandButton tag250_s 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   5760
      TabIndex        =   23
      Top             =   7080
      Width           =   1455
   End
   Begin VB.CommandButton tag250_q 
      Caption         =   "QUIT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   4200
      TabIndex        =   22
      Top             =   7080
      Width           =   1455
   End
   Begin VB.TextBox tag490_1 
      Height          =   315
      Left            =   9000
      TabIndex        =   19
      Top             =   3720
      Width           =   2775
   End
   Begin VB.TextBox tag490_2 
      Height          =   315
      Left            =   9000
      TabIndex        =   20
      Top             =   4080
      Width           =   2775
   End
   Begin VB.TextBox tag300_6 
      Height          =   315
      Left            =   2880
      TabIndex        =   10
      Top             =   5280
      Width           =   2775
   End
   Begin VB.TextBox tag300_7 
      Height          =   315
      Left            =   2880
      TabIndex        =   11
      Top             =   5640
      Width           =   2775
   End
   Begin VB.TextBox tag300_4 
      Height          =   315
      Left            =   2880
      TabIndex        =   8
      Top             =   4560
      Width           =   2775
   End
   Begin VB.TextBox tag300_5 
      Height          =   315
      Left            =   2880
      TabIndex        =   9
      Top             =   4920
      Width           =   2775
   End
   Begin VB.TextBox tag300_2 
      Height          =   315
      Left            =   2880
      TabIndex        =   6
      Top             =   3840
      Width           =   2775
   End
   Begin VB.TextBox tag300_3 
      Height          =   315
      Left            =   2880
      TabIndex        =   7
      Top             =   4200
      Width           =   2775
   End
   Begin VB.TextBox tag260_3 
      Height          =   315
      Left            =   2880
      TabIndex        =   4
      Top             =   2520
      Width           =   2775
   End
   Begin VB.TextBox tag300_1 
      Height          =   315
      Left            =   2880
      TabIndex        =   5
      Top             =   3480
      Width           =   2775
   End
   Begin VB.TextBox tag260_1 
      Height          =   315
      Left            =   2880
      TabIndex        =   2
      Top             =   1800
      Width           =   2775
   End
   Begin VB.TextBox tag260_2 
      Height          =   315
      Left            =   2880
      TabIndex        =   3
      Top             =   2160
      Width           =   2775
   End
   Begin VB.TextBox tag440_5 
      Height          =   315
      Left            =   9000
      TabIndex        =   17
      Top             =   2160
      Width           =   2775
   End
   Begin VB.TextBox tag440_3 
      Height          =   315
      Left            =   9000
      TabIndex        =   15
      Top             =   1440
      Width           =   2775
   End
   Begin VB.TextBox tag440_4 
      Height          =   315
      Left            =   9000
      TabIndex        =   16
      Top             =   1800
      Width           =   2775
   End
   Begin VB.TextBox tag440_1 
      Height          =   315
      Left            =   9000
      TabIndex        =   13
      Top             =   720
      Width           =   2775
   End
   Begin VB.TextBox tag440_2 
      Height          =   315
      Left            =   9000
      TabIndex        =   14
      Top             =   1080
      Width           =   2775
   End
   Begin VB.TextBox tag250_1 
      Height          =   315
      Left            =   2880
      TabIndex        =   0
      Top             =   480
      Width           =   2775
   End
   Begin VB.TextBox tag250_2 
      Height          =   315
      Left            =   2880
      TabIndex        =   1
      Top             =   840
      Width           =   2775
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   10320
      TabIndex        =   51
      Top             =   3240
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   10320
      TabIndex        =   50
      Top             =   120
      Width           =   855
   End
   Begin VB.Label Label18 
      Caption         =   "�����Ţ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   49
      Top             =   4080
      Width           =   3735
   End
   Begin VB.Label Label17 
      Caption         =   "���ͪش���������¡������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   48
      Top             =   3720
      Width           =   3015
   End
   Begin VB.Label Label16 
      Caption         =   "�Ţ�ҵðҹ�ҡŻ�Ш�������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   47
      Top             =   2160
      Width           =   3015
   End
   Begin VB.Label Label15 
      Caption         =   "�����Ţ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   46
      Top             =   1800
      Width           =   3735
   End
   Begin VB.Label Label14 
      Caption         =   "���͵͹/��ǹ�ͧ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   45
      Top             =   1440
      Width           =   3015
   End
   Begin VB.Label Label13 
      Caption         =   "�����Ţ�͹/��ǹ�ͧ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   44
      Top             =   1080
      Width           =   3735
   End
   Begin VB.Label Label12 
      Caption         =   "���ͪش�������¡������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   43
      Top             =   720
      Width           =   3015
   End
   Begin VB.Label Label11 
      Caption         =   "Material specified"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   42
      Top             =   5640
      Width           =   2055
   End
   Begin VB.Label Label10 
      Caption         =   "��Ҵ�������ͧ��ʴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   41
      Top             =   5280
      Width           =   3015
   End
   Begin VB.Label Label9 
      Caption         =   "�������ͧ��ʴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   40
      Top             =   4920
      Width           =   1695
   End
   Begin VB.Label Label8 
      Caption         =   "��ʴػ�Сͺ��觾����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   39
      Top             =   4560
      Width           =   2655
   End
   Begin VB.Label Label7 
      Caption         =   "��Ҵ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   38
      Top             =   4200
      Width           =   2055
   End
   Begin VB.Label Label6 
      Caption         =   "�Ҿ��Сͺ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   37
      Top             =   3840
      Width           =   2535
   End
   Begin VB.Label Label2 
      Caption         =   "�ӹǹ˹��/��/����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   36
      Top             =   3480
      Width           =   2055
   End
   Begin VB.Label Label5 
      Caption         =   "�շ������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   35
      Top             =   2520
      Width           =   1695
   End
   Begin VB.Label Label4 
      Caption         =   "�����ӹѡ�����,���Ѵ��˹���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   34
      Top             =   2160
      Width           =   3735
   End
   Begin VB.Label Label3 
      Caption         =   " ʶҹ�������,���Ө�˹���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   33
      Top             =   1800
      Width           =   3015
   End
   Begin VB.Label Label1 
      Caption         =   "�����ż���Ѻ�Դ�ͺ��þ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   240
      TabIndex        =   32
      Top             =   840
      Width           =   3735
   End
   Begin VB.Label Label71 
      Caption         =   "����駤��駷������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   31
      Top             =   480
      Width           =   1695
   End
   Begin VB.Label Label49 
      Caption         =   "490 ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   30
      Top             =   3240
      Width           =   2175
   End
   Begin VB.Label Label47 
      Caption         =   "300 �ѡɳ��ٻ��ҧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   240
      TabIndex        =   29
      Top             =   3120
      Width           =   2535
   End
   Begin VB.Label Label46 
      Caption         =   "440 �������¡������ ���ͪش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   28
      Top             =   120
      Width           =   3375
   End
   Begin VB.Label Label43 
      Caption         =   "250 ����駩�Ѻ������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   27
      Top             =   120
      Width           =   3615
   End
   Begin VB.Label Label42 
      Caption         =   "260 ��þ���� ��è�˹���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   26
      Top             =   1440
      Width           =   3615
   End
End
Attribute VB_Name = "tag250"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
tagselect.Command7.SetFocus
tag500.Show

End Sub

Private Sub Command2_Click()
tagselect.Command5.SetFocus
tag210.Show

End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag250_q_Click()
MarcMenu.quitting
End Sub

Private Sub tag250_s_Click()
MarcMenu.saving
End Sub

