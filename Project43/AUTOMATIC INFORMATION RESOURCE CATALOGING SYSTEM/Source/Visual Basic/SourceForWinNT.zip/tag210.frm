VERSION 5.00
Begin VB.Form tag210 
   Caption         =   "tag210"
   ClientHeight    =   7860
   ClientLeft      =   60
   ClientTop       =   1080
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   Moveable        =   0   'False
   ScaleHeight     =   7860
   ScaleWidth      =   11880
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton Newcmd 
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2760
      TabIndex        =   35
      Top             =   7200
      Width           =   1455
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   4
      Left            =   6240
      MaxLength       =   2
      TabIndex        =   27
      Top             =   5400
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   3
      Left            =   10200
      MaxLength       =   2
      TabIndex        =   20
      Top             =   2640
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   2
      Left            =   10200
      MaxLength       =   2
      TabIndex        =   13
      Top             =   0
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   1
      Left            =   3120
      MaxLength       =   2
      TabIndex        =   3
      Top             =   1440
      Width           =   375
   End
   Begin VB.TextBox indicator 
      Height          =   375
      Index           =   0
      Left            =   3120
      MaxLength       =   2
      TabIndex        =   0
      Top             =   0
      Width           =   375
   End
   Begin VB.CommandButton Command2 
      Caption         =   "BACK"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   7440
      TabIndex        =   38
      Top             =   7200
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Caption         =   "NEXT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   8280
      TabIndex        =   39
      Top             =   7200
      Width           =   735
   End
   Begin VB.CommandButton tag210_s 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   5880
      TabIndex        =   37
      Top             =   7200
      Width           =   1455
   End
   Begin VB.CommandButton tag210_q 
      Caption         =   "QUIT"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   350
      Left            =   4320
      TabIndex        =   36
      Top             =   7200
      Width           =   1455
   End
   Begin VB.TextBox tag246_6 
      Height          =   315
      Left            =   9000
      TabIndex        =   33
      Top             =   6360
      Width           =   2775
   End
   Begin VB.TextBox tag246_7 
      Height          =   315
      Left            =   9000
      TabIndex        =   34
      Top             =   6720
      Width           =   2775
   End
   Begin VB.TextBox tag246_5 
      Height          =   315
      Left            =   9000
      TabIndex        =   32
      Top             =   6000
      Width           =   2775
   End
   Begin VB.TextBox tag245_5 
      Height          =   315
      Left            =   9000
      TabIndex        =   25
      Top             =   4560
      Width           =   2775
   End
   Begin VB.TextBox tag245_6 
      Height          =   315
      Left            =   9000
      TabIndex        =   26
      Top             =   4920
      Width           =   2775
   End
   Begin VB.TextBox tag245_3 
      Height          =   315
      Left            =   9000
      TabIndex        =   23
      Top             =   3840
      Width           =   2775
   End
   Begin VB.TextBox tag245_4 
      Height          =   315
      Left            =   9000
      TabIndex        =   24
      Top             =   4200
      Width           =   2775
   End
   Begin VB.TextBox tag245_1 
      Height          =   315
      Left            =   9000
      TabIndex        =   21
      Top             =   3120
      Width           =   2775
   End
   Begin VB.TextBox tag245_2 
      Height          =   315
      Left            =   9000
      TabIndex        =   22
      Top             =   3480
      Width           =   2775
   End
   Begin VB.TextBox tag242_5 
      Height          =   315
      Left            =   9000
      TabIndex        =   18
      Top             =   1920
      Width           =   2775
   End
   Begin VB.TextBox tag242_6 
      Height          =   315
      Left            =   9000
      TabIndex        =   19
      Top             =   2280
      Width           =   2775
   End
   Begin VB.TextBox tag242_3 
      Height          =   315
      Left            =   9000
      TabIndex        =   16
      Top             =   1200
      Width           =   2775
   End
   Begin VB.TextBox tag242_4 
      Height          =   315
      Left            =   9000
      TabIndex        =   17
      Top             =   1560
      Width           =   2775
   End
   Begin VB.TextBox tag242_1 
      Height          =   315
      Left            =   9000
      TabIndex        =   14
      Top             =   480
      Width           =   2775
   End
   Begin VB.TextBox tag242_2 
      Height          =   315
      Left            =   9000
      TabIndex        =   15
      Top             =   840
      Width           =   2775
   End
   Begin VB.TextBox tag246_3 
      Height          =   315
      Left            =   3000
      TabIndex        =   30
      Top             =   6360
      Width           =   2775
   End
   Begin VB.TextBox tag246_4 
      Height          =   315
      Left            =   3000
      TabIndex        =   31
      Top             =   6720
      Width           =   2775
   End
   Begin VB.TextBox tag246_1 
      Height          =   315
      Left            =   3000
      TabIndex        =   28
      Top             =   5640
      Width           =   2775
   End
   Begin VB.TextBox tag246_2 
      Height          =   315
      Left            =   3000
      TabIndex        =   29
      Top             =   6000
      Width           =   2775
   End
   Begin VB.TextBox tag210_1 
      Height          =   315
      Left            =   3000
      TabIndex        =   1
      Top             =   480
      Width           =   2775
   End
   Begin VB.TextBox tag210_2 
      Height          =   315
      Left            =   3000
      TabIndex        =   2
      Top             =   840
      Width           =   2775
   End
   Begin VB.TextBox tag240_2 
      Height          =   315
      Left            =   3000
      TabIndex        =   5
      Top             =   2280
      Width           =   2775
   End
   Begin VB.TextBox tag240_1 
      Height          =   315
      Left            =   3000
      TabIndex        =   4
      Top             =   1920
      Width           =   2775
   End
   Begin VB.TextBox tag240_4 
      Height          =   315
      Left            =   3000
      TabIndex        =   7
      Top             =   3000
      Width           =   2775
   End
   Begin VB.TextBox tag240_3 
      Height          =   315
      Left            =   3000
      TabIndex        =   6
      Top             =   2640
      Width           =   2775
   End
   Begin VB.TextBox tag240_6 
      Height          =   315
      Left            =   3000
      TabIndex        =   9
      Top             =   3720
      Width           =   2775
   End
   Begin VB.TextBox tag240_5 
      Height          =   315
      Left            =   3000
      TabIndex        =   8
      Top             =   3360
      Width           =   2775
   End
   Begin VB.TextBox tag240_8 
      Height          =   315
      Left            =   3000
      TabIndex        =   11
      Top             =   4440
      Width           =   2775
   End
   Begin VB.TextBox tag240_7 
      Height          =   315
      Left            =   3000
      TabIndex        =   10
      Top             =   4080
      Width           =   2775
   End
   Begin VB.TextBox tag240_9 
      Height          =   315
      Left            =   3000
      TabIndex        =   12
      Top             =   4800
      Width           =   2775
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   5
      Left            =   6840
      TabIndex        =   79
      Top             =   5400
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   10800
      TabIndex        =   78
      Top             =   2640
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   10800
      TabIndex        =   77
      Top             =   0
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3720
      TabIndex        =   76
      Top             =   1440
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "��Ǻ觪��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3720
      TabIndex        =   75
      Top             =   0
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "���͵͹�ͧ�ҹ/��ǹ�ͧ��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   6000
      TabIndex        =   74
      Top             =   6720
      Width           =   3255
   End
   Begin VB.Label Label45 
      Caption         =   "245 ��������ͧ��С���駤����Ѻ�Դ�ͺ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   73
      Top             =   2640
      Width           =   4215
   End
   Begin VB.Label Label44 
      Caption         =   "246 ��������ͧ���ᵡ��ҧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3600
      TabIndex        =   72
      Top             =   5280
      Width           =   2535
   End
   Begin VB.Label Label41 
      Caption         =   "242 ��������ͧ�������˹���ŧ��¡��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   71
      Top             =   0
      Width           =   3975
   End
   Begin VB.Label Label39 
      Caption         =   "210 ��������ͧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   70
      Top             =   0
      Width           =   2655
   End
   Begin VB.Label Label38 
      Caption         =   "240 ��������ͧẺ��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   69
      Top             =   1440
      Width           =   2895
   End
   Begin VB.Label Label28 
      Caption         =   "��������ͧ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   68
      Top             =   480
      Width           =   1695
   End
   Begin VB.Label Label69 
      Caption         =   "��������ǹ���¤�����������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   67
      Top             =   840
      Width           =   2655
   End
   Begin VB.Label Label70 
      Caption         =   "�շ��ŧ����ʹ���ѭ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   66
      Top             =   2280
      Width           =   2535
   End
   Begin VB.Label Label71 
      Caption         =   "��������ͧẺ��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   65
      Top             =   1920
      Width           =   1695
   End
   Begin VB.Label Label72 
      Caption         =   "��������´����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   64
      Top             =   3000
      Width           =   2055
   End
   Begin VB.Label Label73 
      Caption         =   "�բͧ�ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   63
      Top             =   2640
      Width           =   1695
   End
   Begin VB.Label Label74 
      Caption         =   "���Ңͧ�ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   62
      Top             =   3720
      Width           =   2055
   End
   Begin VB.Label Label75 
      Caption         =   "��������µ���ٻẺ�ͧ��ʴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   61
      Top             =   3360
      Width           =   2895
   End
   Begin VB.Label Label76 
      Caption         =   "���͵͹"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   60
      Top             =   4440
      Width           =   2535
   End
   Begin VB.Label Label77 
      Caption         =   "�����Ţ�͹"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   59
      Top             =   4080
      Width           =   2895
   End
   Begin VB.Label Label79 
      Caption         =   "��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   58
      Top             =   4800
      Width           =   1695
   End
   Begin VB.Label Label48 
      Caption         =   "��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   57
      Top             =   480
      Width           =   1695
   End
   Begin VB.Label Label98 
      Caption         =   "���͵͹/��ǹ�ͧ�ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   56
      Top             =   1920
      Width           =   2175
   End
   Begin VB.Label Label99 
      Caption         =   "�Ţ�ӴѺ�͹/��ǹ�ͧ�ҹ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   55
      Top             =   1560
      Width           =   2415
   End
   Begin VB.Label Label100 
      Caption         =   "����駤����Ѻ�Դ�ͺ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   54
      Top             =   1200
      Width           =   2295
   End
   Begin VB.Label Label101 
      Caption         =   "��������������ǡѺ��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   53
      Top             =   840
      Width           =   2655
   End
   Begin VB.Label Label102 
      Caption         =   "�������Ңͧ��������ͧ�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   52
      Top             =   2280
      Width           =   2775
   End
   Begin VB.Label Label103 
      Caption         =   "��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   51
      Top             =   3120
      Width           =   2775
   End
   Begin VB.Label Label104 
      Caption         =   "���͵͹/��ǹ�ͧ��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   50
      Top             =   4560
      Width           =   2175
   End
   Begin VB.Label Label105 
      Caption         =   "�����Ţ�͹/��ǹ�ͧ��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   49
      Top             =   4200
      Width           =   2775
   End
   Begin VB.Label Label106 
      Caption         =   "����Ѻ�Դ�ͺ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   48
      Top             =   3840
      Width           =   4695
   End
   Begin VB.Label Label107 
      Caption         =   "��������ͧ��º��§, ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   47
      Top             =   3480
      Width           =   2415
   End
   Begin VB.Label Label108 
      Caption         =   "��Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   6000
      TabIndex        =   46
      Top             =   4920
      Width           =   1695
   End
   Begin VB.Line Line1 
      X1              =   480
      X2              =   3480
      Y1              =   5400
      Y2              =   5400
   End
   Begin VB.Line Line2 
      X1              =   8160
      X2              =   11280
      Y1              =   5400
      Y2              =   5400
   End
   Begin VB.Label Label110 
      Caption         =   "��������ͧ���ᵡ��ҧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   45
      Top             =   5640
      Width           =   2055
   End
   Begin VB.Label Label111 
      Caption         =   "��������������ǡѺ��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   44
      Top             =   6000
      Width           =   2655
   End
   Begin VB.Label Label112 
      Caption         =   "����к��Ţ��Шө�Ѻ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   43
      Top             =   6360
      Width           =   3495
   End
   Begin VB.Label Label113 
      Caption         =   "�����Ţ�͹/��ǹ�ͧ��������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   42
      Top             =   6360
      Width           =   2895
   End
   Begin VB.Label Label114 
      Caption         =   "��������´����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   41
      Top             =   6720
      Width           =   1695
   End
   Begin VB.Label Label115 
      Caption         =   "�ѡɳТͧ��ʴ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6000
      TabIndex        =   40
      Top             =   6000
      Width           =   1695
   End
End
Attribute VB_Name = "tag210"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
tagselect.Command6.SetFocus
tag250.Show

End Sub

Private Sub Command2_Click()
tagselect.Command4.SetFocus
tag100.Show

End Sub

Private Sub Newcmd_Click()
MarcMenu.newedit
End Sub

Private Sub tag210_q_Click()
MarcMenu.quitting
End Sub

Private Sub tag210_s_Click()
MarcMenu.saving
End Sub

