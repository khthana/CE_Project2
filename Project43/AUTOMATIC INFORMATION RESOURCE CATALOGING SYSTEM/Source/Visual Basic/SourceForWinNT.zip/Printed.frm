VERSION 5.00
Object = "{2200CD23-1176-101D-85F5-0020AF1EF604}#1.7#0"; "barcod32.ocx"
Begin VB.Form Printed 
   Caption         =   "����������"
   ClientHeight    =   8145
   ClientLeft      =   1605
   ClientTop       =   225
   ClientWidth     =   9165
   Icon            =   "Printed.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   8145
   ScaleWidth      =   9165
   StartUpPosition =   2  'CenterScreen
   Begin VB.ListBox List1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3660
      ItemData        =   "Printed.frx":110A
      Left            =   960
      List            =   "Printed.frx":110C
      TabIndex        =   16
      Top             =   600
      Width           =   1575
   End
   Begin VB.ListBox List2 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3660
      ItemData        =   "Printed.frx":110E
      Left            =   6360
      List            =   "Printed.frx":1110
      TabIndex        =   15
      Top             =   600
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Select&All"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3600
      TabIndex        =   14
      ToolTipText     =   "���͡�Ţ����¹������"
      Top             =   600
      Width           =   1575
   End
   Begin VB.CommandButton Command2 
      Caption         =   "&Select  -->"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3600
      TabIndex        =   13
      ToolTipText     =   "���͡�Ţ����¹"
      Top             =   1320
      Width           =   1575
   End
   Begin VB.CommandButton Command3 
      Caption         =   "<--  &Remove"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3600
      TabIndex        =   12
      Top             =   3120
      Width           =   1575
   End
   Begin VB.Frame Frame1 
      Caption         =   "�ѡɳС�þ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1215
      Left            =   480
      TabIndex        =   7
      Top             =   5640
      Width           =   7815
      Begin VB.OptionButton Option1 
         Caption         =   "ں�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   360
         TabIndex        =   11
         Top             =   480
         Width           =   1215
      End
      Begin VB.OptionButton Option2 
         Caption         =   "�ѹ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   2160
         TabIndex        =   10
         Top             =   480
         Width           =   1215
      End
      Begin VB.OptionButton Option3 
         Caption         =   "�ѵû�Ш�˹ѧ���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   3840
         TabIndex        =   9
         Top             =   480
         Width           =   1935
      End
      Begin VB.OptionButton Option4 
         Caption         =   "�ͧ�ѵ�"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   6240
         TabIndex        =   8
         Top             =   480
         Width           =   1215
      End
   End
   Begin VB.CommandButton Command4 
      Cancel          =   -1  'True
      Caption         =   "¡��ԡ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5040
      TabIndex        =   6
      ToolTipText     =   "�͡�ҡ�����"
      Top             =   7320
      Width           =   1215
   End
   Begin VB.CommandButton Command5 
      Caption         =   "�����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   2640
      TabIndex        =   5
      ToolTipText     =   "�����"
      Top             =   7320
      Width           =   1215
   End
   Begin VB.CommandButton Command6 
      Caption         =   "&Clear"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   3600
      TabIndex        =   3
      Top             =   3840
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   420
      Left            =   2040
      TabIndex        =   2
      ToolTipText     =   "����Ţ����¹����ͧ�������"
      Top             =   4920
      Width           =   2415
   End
   Begin VB.CommandButton Command7 
      Caption         =   "&Add"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4800
      TabIndex        =   1
      ToolTipText     =   "�����Ţ����¹"
      Top             =   4920
      Width           =   1575
   End
   Begin VB.CommandButton Command8 
      Caption         =   "����������´�������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   6600
      TabIndex        =   0
      Top             =   4920
      Width           =   2175
   End
   Begin BarcodLib.Barcod Barcode1 
      Height          =   735
      Left            =   3360
      TabIndex        =   4
      Top             =   8640
      Width           =   1455
      _Version        =   65543
      _ExtentX        =   2566
      _ExtentY        =   1296
      _StockProps     =   75
      BackColor       =   16777215
      BarWidth        =   0
      Direction       =   0
      Style           =   5
      UPCNotches      =   3
      Alignment       =   0
      Extension       =   ""
   End
   Begin VB.Label Label1 
      Caption         =   "���͡�Ţ����¹"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   3600
      TabIndex        =   21
      Top             =   2160
      Width           =   1815
      WordWrap        =   -1  'True
   End
   Begin VB.Label Label2 
      Caption         =   "����ͧ��èоԾ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3600
      TabIndex        =   20
      Top             =   2640
      Width           =   1815
   End
   Begin VB.Label Label3 
      Caption         =   "�Ţ����¹���о����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   6240
      TabIndex        =   19
      Top             =   240
      Width           =   2055
   End
   Begin VB.Label Label4 
      Caption         =   "���͡�Ţ����¹"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   960
      TabIndex        =   18
      Top             =   240
      Width           =   1695
   End
   Begin VB.Label Label5 
      Caption         =   "�����Ţ����¹"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   17
      Top             =   4920
      Width           =   1575
   End
End
Attribute VB_Name = "Printed"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim Select1 As Integer
Dim Select2 As Integer
Public marcws1 As Workspace
Public marcdb1 As Database
Public Opendyna1  As Recordset


Private Sub Command1_Click()  ' select All Bottun
Dim i As Integer, j As Integer
i = List1.ListCount
j = List2.ListCount


For j = 0 To i - 1
List2.AddItem List1.List(0)
List1.RemoveItem (0)
Next j


End Sub

Private Sub Command2_Click()  ' Select button
Dim i As Integer
i = List1.ListCount

If (i <> 0) And (Select1 <> -1) Then
List2.AddItem List1.List(Select1)
List1.RemoveItem (Select1)
End If
Select2 = -1
Select1 = -1
End Sub

Private Sub Command3_Click() ' Remove Button
Dim i As Integer
i = List2.ListCount
If (i <> 0) And (Select2 <> -1) Then
List1.AddItem List2.List(Select2)
List2.RemoveItem (Select2)
End If
Select1 = -1
Select2 = -1
End Sub

Private Sub Command4_Click()  'Cancel button

Unload Me
End Sub

Private Sub Command5_Click()  ' Print button

If Option1.Value Then
   BarCode
ElseIf Option2.Value Then
   Backbone
ElseIf Option3.Value Then
   Card
ElseIf Option4.Value Then
   CaseCard
End If


End Sub

Private Sub Command6_Click() ' Clear Button
Dim i As Integer, j As Integer

If Select2 <> -1 Then
List2.RemoveItem (Select2)
Else

List2.Clear
  
End If
Select2 = -1
End Sub

Private Sub Command7_Click() ' Add button
Dim tmp As String
tmp = Text1.Text
tmp = Trim(Text1.Text)

If (Text1.Text <> "") Then
   List2.AddItem tmp
   Text1.Text = ""
End If

End Sub

Private Sub Command8_Click()   ' Detail button
Dim BookNo As String
Dim sqlcommand As String
Dim BookCode As String
Dim Author As String
Dim Title As String
Dim ISBN As String

If Select1 <> -1 Then
 BookNo = List1.Text


Set marcws1 = DBEngine.Workspaces(0)
Set marcdb1 = marcws1.OpenDatabase("marcsheetdb.mdb", False, False)
sqlcommand = " SELECT book_no,t020_1,t090_1,t090_2,t090_3,t099_1,t099_2,t099_3,t100_1,t110_1,t111_1,t130_1,t245_1"
sqlcommand = sqlcommand & ",t210_1,t240_1,t242_1,t246_1 FROM tagdata1 "
sqlcommand = sqlcommand & " where book_no = '" & BookNo & "' order by 1"
Set Opendyna1 = marcdb1.OpenRecordset(sqlcommand, dbOpenDynaset)

If Not (Opendyna1.EOF) Then
ISBN = Opendyna1.Fields("t020_1")
If Opendyna1.Fields("t090_1") <> " " Then
    BookCode = Opendyna1.Fields("t090_1") & Opendyna1.Fields("t090_2") & Opendyna1.Fields("t090_3")
Else
    BookCode = Opendyna1.Fields("t099_1") & Opendyna1.Fields("t099_2") & Opendyna1.Fields("t099_3")
End If

If Opendyna1.Fields("t100_1") <> " " Then
    Author = Opendyna1.Fields("t100_1")
ElseIf Opendyna1.Fields("t110_1") <> " " Then
   Author = Opendyna1.Fields("t110_1")
ElseIf Opendyna1.Fields("t130_1") <> " " Then
   Author = Opendyna1.Fields("t130_1")
ElseIf Opendyna1.Fields("t111_1") <> " " Then
  Author = Opendyna1.Fields("t111_1")
End If

If Opendyna1.Fields("t245_1") <> " " Then
    Title = Opendyna1.Fields("t245_1")
ElseIf Opendyna1.Fields("t210_1") <> " " Then
   Title = Opendyna1.Fields("t210_1")
ElseIf Opendyna1.Fields("t240_1") <> " " Then
   Title = Opendyna1.Fields("t240_1")
 ElseIf Opendyna1.Fields("t242_1") <> " " Then
   Title = Opendyna1.Fields("t242_1")
End If

ShowDetail.Show
ShowDetail.Label2(4).Caption = BookNo
ShowDetail.Label2(0).Caption = BookCode
ShowDetail.Label2(1).Caption = ISBN
ShowDetail.Label2(2).Caption = Author
ShowDetail.Label2(3).Caption = Title
Else
MsgBox (" ��辺�����Ź��㹰ҹ������")
 End If
 End If
End Sub

Private Sub Form_Load()
Dim sqlcommand As String
Set marcws1 = DBEngine.Workspaces(0)
Set marcdb1 = marcws1.OpenDatabase("marcsheetdb.mdb", False, False)
sqlcommand = " SELECT book_no,t090_1,t090_2,t090_3,t099_1,t099_2,t099_3,t100_1,t110_1,t111_1,t130_1,t245_1"
sqlcommand = sqlcommand & ",t210_1,t240_1,t242_1,t246_1 FROM tagdata1 "
sqlcommand = sqlcommand & "order by 1"
Set Opendyna1 = marcdb1.OpenRecordset(sqlcommand, dbOpenDynaset)
Option1.Value = True
Select1 = -1
Select2 = -1
End Sub

Private Sub List1_Click()
Select1 = List1.ListIndex
End Sub

Private Sub List2_Click()
Select2 = List2.ListIndex
End Sub

Sub BarCode()
Dim i As Integer, j As Integer, k As Integer, m As Integer, n As Integer
Dim tmp As String

    i = List2.ListCount
    
    If i <> 0 Then
    
    Screen.MousePointer = 11

    Printer.Print
    Printer.ScaleMode = 1
    Printer.Font.Name = "MS Sans Serif"
    Printer.Font.Size = 16
    
    Barcode1.PrinterScaleMode = Printer.ScaleMode
    
    n = Int(i / 33)  ' check total page to printing
    m = 0
    
    Do
        
    k = m * 33
    
    For j = 0 To 32
        tmp = List2.List(k)
        tmp = Trim(tmp)
        Barcode1.Caption = tmp
        Barcode1.PrinterLeft = 960 + (2.5 * 1440) * (j Mod 3) 'Int(I / 10)
        Barcode1.PrinterTop = 960 + 1440 * Int(j / 3) '(I Mod 10)
        Barcode1.PrinterWidth = 2 * 1440
        Barcode1.PrinterHeight = 720
        Barcode1.PrinterHDC = Printer.hDC

        Printer.CurrentX = Barcode1.PrinterLeft
        Printer.CurrentY = Barcode1.PrinterTop + Barcode1.PrinterHeight - 90
        Printer.Print Spc(10); Barcode1.Displayed
        k = k + 1
        If k > i - 1 Then
           Exit Do
        End If
    Next j
    
    Printer.NewPage
    m = m + 1
     
    Loop Until m > n
    Printer.EndDoc

    Screen.MousePointer = 0
    
   End If
End Sub

Sub Backbone()
Dim t1 As String
Dim t2 As String
Dim t3 As String
Dim t4 As String
Dim tmp As String
Dim tmp1 As String
Dim tmp2 As String
Dim tmp3 As String
Dim Character As String
Dim LC As String
Dim Cutter As String
Dim Year As String
Dim i  As Integer, j As Integer, k As Integer, m As Integer, n As Integer, o As Integer
Dim Xposition As Integer, Yposition As Integer

Character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ./-abcdefghijklmnopqrstuvwxyz�����������������������������������������"

i = List2.ListCount
n = Int(i / 66) ' check total page to printing
m = 0


If i <> 0 Then


Do

k = m * 66

For o = 0 To 65
   
   Opendyna1.MoveFirst
   
   Do Until Opendyna1.EOF  ' ---------------------------- find the bookcode in list 2 that exist in database
   
   tmp2 = List2.List(k)
   tmp2 = Trim(tmp2)
   
   tmp3 = Opendyna1.Fields("book_no")
   tmp3 = Trim(tmp3)
   
   If tmp2 = tmp3 Then
      Exit Do
   End If
   
   Opendyna1.MoveNext
   
   Loop                                  ' -----------------------------------------   end do until --------------------------------------------
     
   If Opendyna1.EOF Then  ' ---------------------------------- if it not exist in database kill it ------------------------
     Printer.KillDoc
     MsgBox "��辺�Ţ����¹ " + tmp2 + " 㹰ҹ������", vbYes, "���Ң����żԴ��Ҵ"
     Exit Do
   Else           ' ---------------------------------------------- else process job -----------------------------------------------
   

    
    If Opendyna1.Fields("t090_1") <> " " Then
    LC = Opendyna1.Fields("t090_1")
    Cutter = Opendyna1.Fields("t090_2")
    Year = Opendyna1.Fields("t090_3")
    Else
    LC = Opendyna1.Fields("t099_1")
    Cutter = Opendyna1.Fields("t099_2")
    Year = Opendyna1.Fields("t099_3")
    End If
    LC = Trim(LC)
    i = InStr(LC, " ")
    If i <> 0 Then  ' ----------- check Reference in LC ( R )
       t1 = Left(LC, i - 1)    '------------------------------  if it is Reference book keep it in t1  ----------------
       tmp = Mid(LC, i + 1, Len(LC))
    Else
       t1 = ""
       tmp = LC
    End If
    
    For j = 1 To Len(tmp)
       tmp1 = Mid(tmp, j, 1)
       i = InStr(Character, tmp1)
       If i = 0 Then
          Exit For
       End If
    Next j
    
    t2 = Mid(tmp, 1, j - 1)     ' ------------- cut frist character in LC
    t3 = Mid(tmp, j, Len(tmp)) '-------------   other character from t2
    
    
    tmp = t3   ' ------------- check t3 have "." or not in the word
    
    i = InStr(tmp, ".")
    
    Do    '  --------------------------------------- loop to check all charecter in t 3 that exist "." in the word-----------
    
    If i <> 0 Then
      
      tmp1 = Mid(tmp, i + 1, 1)
      j = InStr(Character, tmp1)
      
      
      If j <> 0 Then
      t4 = Mid(tmp, i, Len(tmp)) ' ---------------- if t3 have "." then keep the word below "."  in t4
      
      
      j = InStr(t3, t4)
      
      t3 = Mid(t3, 1, j - 1)   ' --------------------- and keep then word above "." in t3
      End If
      
    Else
      t4 = ""
    End If
    tmp = Mid(tmp, i + 1, Len(tmp))
    i = InStr(tmp, ".")
    Loop Until i = 0
    
    '-----------------------------------------------------  Print Zone -------------------------------------------------------------------
    i = 1
    Printer.Print
    Printer.ScaleMode = 1
    Printer.Font.Name = "MS Sans Serif"
    Printer.Font.Size = 14
    
    Xposition = 960 + (1440 * 1.25) * (o Mod 6)
    Yposition = 960 + 1530 * Int(o / 6)
    
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition
    Printer.Print t1     ' ------------------------------  Print the Reference word
    
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition + (180 * i)
    Printer.Print t2  ' --------------------------------- Print the First character in LC
    i = i + 1
    
    t3 = Trim(t3)
    If t3 <> "" Then
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition + (180 * i)
    Printer.Print t3  ' ------------------------------------ Print orther word in LC that continue with t2
    i = i + 1
    End If
    
    If t4 <> "" Then
    
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition + (180 * i)
    Printer.Print t4 ' ----------------------------------- Print t4 if t3 have exist "." in the word -------
    i = i + 1
    End If
    
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition + (180 * i)
    Printer.Print Cutter   '--------------------------- Print the Cutter number -----------------
    i = i + 1
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition + (180 * i)
    Printer.Print Year   ' ---------------------------- Print Year
    
    k = k + 1
    
    If k > List2.ListCount - 1 Then
           GoTo finish
        End If
    End If
    
    Next o
    
    Printer.NewPage
    m = m + 1
    
Loop Until m > n

finish:
    Printer.EndDoc

End If

End Sub

Sub Card()
Dim tmp As String, tmp1 As String, tmp2 As String, tmp3 As String
Dim LC As String, Cutter As String, Year As String, Author As String, Title As String, Code As String
Dim t1 As String, t2 As String, t3 As String, t4 As String
Dim i As Integer, j As Integer, k As Integer, m As Integer, n As Integer
Dim Xposition As Integer, Yposition As Integer
Dim check As Boolean
Dim Character As String


n = List2.ListCount
Character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ./-abcdefghijklmnopqrstuvwxyz�����������������������������������������"

For k = 0 To n - 1
check = False
Xposition = 0
Yposition = 0

Opendyna1.MoveFirst
   
   Do Until Opendyna1.EOF  ' ---------------------------- find the bookcode in list 2 that exist in database
   
   tmp2 = List2.List(k)
   tmp2 = Trim(tmp2)
   
   tmp3 = Opendyna1.Fields("book_no")
   tmp3 = Trim(tmp3)
   
   If tmp2 = tmp3 Then
      Exit Do
   End If
   
   Opendyna1.MoveNext
   
   Loop                                  ' -----------------------------------------   end do until --------------------------------------------
     
   If Opendyna1.EOF Then  ' ---------------------------------- if it not exist in database kill it ------------------------
     Printer.KillDoc
     MsgBox "��辺�Ţ����¹ " + tmp2 + " 㹰ҹ������", vbYes, "���Ң����żԴ��Ҵ"
     Exit For
   Else           ' ---------------------------------------------- else process job -----------------------------------------------
   

    
    If Opendyna1.Fields("t090_1") <> " " Then
    LC = Opendyna1.Fields("t090_1")
    Cutter = Opendyna1.Fields("t090_2")
    Year = Opendyna1.Fields("t090_3")
    Else
    LC = Opendyna1.Fields("t099_1")
    Cutter = Opendyna1.Fields("t099_2")
    Year = Opendyna1.Fields("t099_3")
    End If
    LC = Trim(LC)
    i = InStr(LC, " ")
    If i <> 0 Then  ' ----------- check Reference in LC ( R )
       t1 = Left(LC, i - 1)    '------------------------------  if it is Reference book keep it in t1  ----------------
       tmp = Mid(LC, i + 1, Len(LC))
    Else
       t1 = ""
       tmp = LC
    End If
    
    For j = 1 To Len(tmp)
       tmp1 = Mid(tmp, j, 1)
       i = InStr(Character, tmp1)
       If i = 0 Then
          Exit For
       End If
    Next j
    
    t2 = Mid(tmp, 1, j - 1)     ' ------------- cut frist character in LC
    t3 = Mid(tmp, j, Len(tmp)) '-------------   other character from t2
    
    
    tmp = t3   ' ------------- check t3 have "." or not in the word
    
    i = InStr(tmp, ".")
    
    Do    '  --------------------------------------- loop to check all charecter in t 3 that exist "." in the word-----------
    
    If i <> 0 Then
      
      tmp1 = Mid(tmp, i + 1, 1)
      j = InStr(Character, tmp1)
      
      
      If j <> 0 Then
      t4 = Mid(tmp, i, Len(tmp)) ' ---------------- if t3 have "." then keep the word below "."  in t4
      
      
      j = InStr(t3, t4)
      
      t3 = Mid(t3, 1, j - 1)   ' --------------------- and keep then word above "." in t3
      End If
      
    Else
      t4 = ""
    End If
    tmp = Mid(tmp, i + 1, Len(tmp))
    i = InStr(tmp, ".")
    Loop Until i = 0    ' -------------------- End check t4 --------------------------------

Code = Opendyna1.Fields("book_no")
Mid(Code, 2, 1) = "."   '---------------- replace the secord character to "."

If Opendyna1.Fields("t100_1") <> " " Then
    Author = Opendyna1.Fields("t100_1")
ElseIf Opendyna1.Fields("t110_1") <> " " Then
   Author = Opendyna1.Fields("t110_1")
ElseIf Opendyna1.Fields("t130_1") <> " " Then
   Author = Opendyna1.Fields("t130_1")
ElseIf Opendyna1.Fields("t111_1") <> " " Then
  Author = Opendyna1.Fields("t111_1")
End If

Author = Trim(Author)
If Len(Author) > 40 Then
Author = Left(Author, 40)
Author = Author & " . . ."
End If

If Opendyna1.Fields("t245_1") <> " " Then
    Title = Opendyna1.Fields("t245_1")
ElseIf Opendyna1.Fields("t210_1") <> " " Then
   Title = Opendyna1.Fields("t210_1")
ElseIf Opendyna1.Fields("t240_1") <> " " Then
   Title = Opendyna1.Fields("t240_1")
 ElseIf Opendyna1.Fields("t242_1") <> " " Then
   Title = Opendyna1.Fields("t242_1")
End If

Title = Trim(Title)
If Len(Title) > 40 Then
Title = Left(Title, 40)
Title = Title & ". . ."
End If


'------------------------------------------------------------ Printing Zone -----------------------------------------------------------------
'---------------------------------------------------------------------------------------------------------------------------------------------------
    Printer.Print
    Printer.ScaleMode = 1
    Printer.Font.Name = "MS Sans Serif"
    Printer.Font.Size = 14
    
   Yposition = Yposition + 180
   Printer.CurrentY = Yposition
    Printer.Print t2
    
    If t3 <> "" Then
    Yposition = Yposition + 180
    i = Yposition
    check = True
    Printer.CurrentY = Yposition
    Printer.Print t3
    End If
    
    If check Then
    Xposition = Xposition + 2500
    Printer.CurrentX = Xposition
    Printer.CurrentY = i
    Printer.Print Code
    Xposition = Xposition - 2500
    Printer.CurrentX = Xposition
    End If
    
    If t4 <> "" Then
    Yposition = Yposition + 180
    Printer.CurrentY = Yposition
    i = Yposition
    Printer.Print t4
    
    If Not (check) Then
    Xposition = Xposition + 2500
    Printer.CurrentX = Xposition
    Printer.CurrentY = i
    Printer.Print Code
    Xposition = Xposition - 2500
    Printer.CurrentX = Xposition
    End If
    
    End If
    
    Yposition = Yposition + 180
    Printer.CurrentY = Yposition
    Printer.Print Cutter
    
    
    Yposition = Yposition + 540
    Xposition = Xposition + 1000
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition
    Printer.Print Author
    
    Yposition = Yposition + 360
    Xposition = Xposition - 450
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition
    Printer.Print Title
    
    Printer.NewPage
    End If

Next k

Printer.EndDoc

End Sub


Sub CaseCard()
Dim tmp As String, tmp1 As String, tmp2 As String, tmp3 As String
Dim LC As String, Cutter As String, Year As String, Author As String, Title As String, Code As String
Dim t1 As String, t2 As String, t3 As String, t4 As String
Dim i As Integer, j As Integer, k As Integer, m As Integer, n As Integer
Dim Xposition As Integer, Yposition As Integer
Dim check As Boolean
Dim Character As String


n = List2.ListCount
Character = "ABCDEFGHIJKLMNOPQRSTUVWXYZ./-abcdefghijklmnopqrstuvwxyz�����������������������������������������"

For k = 0 To n - 1
check = False
Xposition = 0
Yposition = 2350

Opendyna1.MoveFirst
   
   Do Until Opendyna1.EOF  ' ---------------------------- find the bookcode in list 2 that exist in database
   
   tmp2 = List2.List(k)
   tmp2 = Trim(tmp2)
   
   tmp3 = Opendyna1.Fields("book_no")
   tmp3 = Trim(tmp3)
   
   If tmp2 = tmp3 Then
      Exit Do
   End If
   
   Opendyna1.MoveNext
   
   Loop                                  ' -----------------------------------------   end do until --------------------------------------------
     
   If Opendyna1.EOF Then  ' ---------------------------------- if it not exist in database kill it ------------------------
     Printer.KillDoc
     MsgBox "��辺�Ţ����¹ " + tmp2 + " 㹰ҹ������", vbYes, "���Ң����żԴ��Ҵ"
     Exit For
   Else           ' ---------------------------------------------- else process job -----------------------------------------------
   

    
    If Opendyna1.Fields("t090_1") <> " " Then
    LC = Opendyna1.Fields("t090_1")
    Cutter = Opendyna1.Fields("t090_2")
    Year = Opendyna1.Fields("t090_3")
    Else
    LC = Opendyna1.Fields("t099_1")
    Cutter = Opendyna1.Fields("t099_2")
    Year = Opendyna1.Fields("t099_3")
    End If
    LC = Trim(LC)
    i = InStr(LC, " ")
    If i <> 0 Then  ' ----------- check Reference in LC ( R )
       t1 = Left(LC, i - 1)    '------------------------------  if it is Reference book keep it in t1  ----------------
       tmp = Mid(LC, i + 1, Len(LC))
    Else
       t1 = ""
       tmp = LC
    End If
    
    For j = 1 To Len(tmp)
       tmp1 = Mid(tmp, j, 1)
       i = InStr(Character, tmp1)
       If i = 0 Then
          Exit For
       End If
    Next j
    
    t2 = Mid(tmp, 1, j - 1)     ' ------------- cut frist character in LC
    t3 = Mid(tmp, j, Len(tmp)) '-------------   other character from t2
    
    
    tmp = t3   ' ------------- check t3 have "." or not in the word
    
    i = InStr(tmp, ".")
    
    Do    '  --------------------------------------- loop to check all charecter in t 3 that exist "." in the word-----------
    
    If i <> 0 Then
      
      tmp1 = Mid(tmp, i + 1, 1)
      j = InStr(Character, tmp1)
      
      
      If j <> 0 Then
      t4 = Mid(tmp, i, Len(tmp)) ' ---------------- if t3 have "." then keep the word below "."  in t4
      
      
      j = InStr(t3, t4)
      
      t3 = Mid(t3, 1, j - 1)   ' --------------------- and keep then word above "." in t3
      End If
      
    Else
      t4 = ""
    End If
    tmp = Mid(tmp, i + 1, Len(tmp))
    i = InStr(tmp, ".")
    Loop Until i = 0    ' -------------------- End check t4 --------------------------------

Code = Opendyna1.Fields("book_no")
Mid(Code, 2, 1) = "."   '---------------- replace the secord character to "."

If Opendyna1.Fields("t100_1") <> " " Then
    Author = Opendyna1.Fields("t100_1")
ElseIf Opendyna1.Fields("t110_1") <> " " Then
   Author = Opendyna1.Fields("t110_1")
ElseIf Opendyna1.Fields("t130_1") <> " " Then
   Author = Opendyna1.Fields("t130_1")
ElseIf Opendyna1.Fields("t111_1") <> " " Then
  Author = Opendyna1.Fields("t111_1")
End If

Author = Trim(Author)
If Len(Author) > 32 Then
Author = Left(Author, 32)
Author = Author & " . . . "
End If

If Opendyna1.Fields("t245_1") <> " " Then
    Title = Opendyna1.Fields("t245_1")
ElseIf Opendyna1.Fields("t210_1") <> " " Then
   Title = Opendyna1.Fields("t210_1")
ElseIf Opendyna1.Fields("t240_1") <> " " Then
   Title = Opendyna1.Fields("t240_1")
 ElseIf Opendyna1.Fields("t242_1") <> " " Then
   Title = Opendyna1.Fields("t242_1")
End If

Title = Trim(Title)
If Len(Title) > 32 Then
Title = Left(Title, 32)
Title = Title & ". . ."
End If


'------------------------------------------------------------ Printing Zone -----------------------------------------------------------------
'---------------------------------------------------------------------------------------------------------------------------------------------------
    'Printer.Print
    Printer.ScaleMode = 1
    Printer.Font.Name = "MS Sans Serif"
    Printer.Font.Size = 14
    
   Yposition = Yposition + 180
   Printer.CurrentY = Yposition
   i = Yposition
    Printer.Print t2
    
    
    If t3 <> "" Then
    Yposition = Yposition + 180
    i = Yposition
    check = True
    Printer.CurrentY = Yposition
    Printer.Print t3
    End If
    
    If check Then
    Xposition = Xposition + 3680
    Printer.CurrentX = Xposition
    Printer.CurrentY = i
    Printer.Print Code
    Xposition = Xposition - 3680
    Printer.CurrentX = Xposition
    End If
    
    If t4 <> "" Then
    Yposition = Yposition + 180
    Printer.CurrentY = Yposition
    i = Yposition
    Printer.Print t4
    End If
    
    If Not (check) Then
    Xposition = Xposition + 3680
    Printer.CurrentX = Xposition
    Printer.CurrentY = i
    Printer.Print Code
    Xposition = Xposition - 3680
    Printer.CurrentX = Xposition
    End If
    
    Yposition = Yposition + 180
    Printer.CurrentY = Yposition
    Printer.Print Cutter
    
    
    Yposition = Yposition + 900
    Xposition = Xposition + 700
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition
    Printer.Print Author
    
    Yposition = Yposition + 270
    Xposition = Xposition + 360
    Printer.CurrentX = Xposition
    Printer.CurrentY = Yposition
    Printer.Print Title
    
    Printer.NewPage
    End If

Next k

Printer.EndDoc
End Sub

