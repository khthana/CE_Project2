VERSION 5.00
Begin VB.Form PrintMenu 
   BackColor       =   &H8000000E&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "PrintMenu"
   ClientHeight    =   6090
   ClientLeft      =   720
   ClientTop       =   2295
   ClientWidth     =   8820
   Icon            =   "PrintMenu.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "PrintMenu.frx":110A
   ScaleHeight     =   6090
   ScaleWidth      =   8820
   StartUpPosition =   2  'CenterScreen
   Begin VB.Image Image1 
      Height          =   3450
      Left            =   120
      Picture         =   "PrintMenu.frx":4FE3
      Stretch         =   -1  'True
      Top             =   2040
      Width           =   3135
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��Ѻ��ѧ������ѡ"
      DragIcon        =   "PrintMenu.frx":621D
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3720
      MouseIcon       =   "PrintMenu.frx":6527
      TabIndex        =   2
      Top             =   4920
      Width           =   1935
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "���������� �ѹ�� �ѵû�Ш�˹ѧ��� �ͧ�ѵ�"
      DragIcon        =   "PrintMenu.frx":6969
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3720
      MouseIcon       =   "PrintMenu.frx":6C73
      TabIndex        =   1
      Top             =   3780
      Width           =   4815
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "�������ª���˹ѧ���"
      DragIcon        =   "PrintMenu.frx":70B5
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   3720
      MouseIcon       =   "PrintMenu.frx":73BF
      TabIndex        =   0
      Top             =   2640
      Width           =   1935
   End
End
Attribute VB_Name = "PrintMenu"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Label1_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If Source Is Label1(Index) Then
        With Label1(Index)
            .Font.Underline = False
            .ForeColor = vbBlack
            Screen.MousePointer = vbHourglass
            
            Select Case Index
            Case 0
                Main.Visible = False
                'OLE1.DoVerb
                Dim ReportPath As String
                'Screen.MousePointer = vbHourglass
                ReportPath = App.Path & "\report.exe"
                lngInst = Shell(ReportPath, 1)  ' 1=Normal Window
                'Screen.MousePointer = vbNormal
            Case 1
                Main.Visible = False
                Printselect.Show
            Case 2
               Main.Visible = True
               Unload Me
               
            End Select
            
            Screen.MousePointer = vbNormal
        End With
    End If
End Sub

Private Sub Label1_DragOver(Index As Integer, Source As Control, X As Single, Y As Single, State As Integer)
If State = vbLeave Then
        With Label1(Index)
            .Drag vbEndDrag
            .Font.Underline = False
            .ForeColor = vbBlack
            'Image1(0).Picture = Image1(5).Picture
         
        End With
    End If
End Sub

Private Sub Label1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
With Label1(Index)
        .ForeColor = vbBlue
        .Font.Underline = True
        .Drag vbBeginDrag
        'Image1(0).Picture = Image1(Index + 1).Picture

    End With
End Sub
