VERSION 5.00
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Begin VB.Form Header2 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "�������ͧ���� 2"
   ClientHeight    =   7995
   ClientLeft      =   690
   ClientTop       =   435
   ClientWidth     =   10680
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   8.25
      Charset         =   222
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "Header2.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7995
   ScaleWidth      =   10680
   Begin VB.Frame Frame5 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1695
      Left            =   8640
      TabIndex        =   34
      Top             =   6120
      Width           =   1695
      Begin MSAdodcLib.Adodc Adodc1 
         Height          =   495
         Left            =   240
         ToolTipText     =   "����͹ Record"
         Top             =   360
         Width           =   1200
         _ExtentX        =   2117
         _ExtentY        =   873
         ConnectMode     =   0
         CursorLocation  =   3
         IsolationLevel  =   -1
         ConnectionTimeout=   15
         CommandTimeout  =   30
         CursorType      =   3
         LockType        =   3
         CommandType     =   1
         CursorOptions   =   0
         CacheSize       =   50
         MaxRecords      =   0
         BOFAction       =   0
         EOFAction       =   0
         ConnectStringType=   1
         Appearance      =   1
         BackColor       =   -2147483643
         ForeColor       =   -2147483640
         Orientation     =   0
         Enabled         =   -1
         Connect         =   "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=HeaderDB.mdb"
         OLEDBString     =   "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=HeaderDB.mdb"
         OLEDBFile       =   ""
         DataSourceName  =   ""
         OtherAttributes =   ""
         UserName        =   ""
         Password        =   ""
         RecordSource    =   "select Header,Subheader_1,Subheader_2,TranEng,LC_Dewey,Descript,UF,BT,RT,NT,SA,Use from tblSub2 order by 1,2,3"
         Caption         =   "Adodc1"
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         _Version        =   393216
      End
      Begin VB.Label Label2 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   36
         Top             =   1200
         Width           =   1455
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         Caption         =   "��������礤���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   35
         Top             =   960
         Width           =   1455
      End
   End
   Begin VB.CommandButton cmdSearch 
      Caption         =   "&GoTo Header"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8760
      TabIndex        =   22
      ToolTipText     =   "��ѧ�������ͧ (F6)"
      Top             =   4200
      Width           =   1455
   End
   Begin VB.Frame Frame4 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1215
      Left            =   8640
      TabIndex        =   33
      Top             =   2760
      Width           =   1695
      Begin VB.CommandButton cmdOK 
         Caption         =   "&OK"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   20
         ToolTipText     =   "�ѹ�֡������ (F5)"
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton cmdCancel 
         Cancel          =   -1  'True
         Caption         =   "&Cancel"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   21
         ToolTipText     =   "¡��ԡ��úѹ�֡������ (ESC)"
         Top             =   720
         Width           =   1215
      End
   End
   Begin VB.Frame Frame3 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2535
      Left            =   8640
      TabIndex        =   32
      Top             =   120
      Width           =   1695
      Begin VB.CommandButton cmdAdd 
         Caption         =   "&Add"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   16
         ToolTipText     =   "���������� (F1)"
         Top             =   360
         Width           =   1215
      End
      Begin VB.CommandButton cmdUpdate 
         Caption         =   "&Save"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   17
         ToolTipText     =   "�ѹ�֡������ (F2)"
         Top             =   840
         Width           =   1215
      End
      Begin VB.CommandButton cmdDelete 
         Caption         =   "&Delete"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   18
         ToolTipText     =   "ź������ (F3)"
         Top             =   1320
         Width           =   1215
      End
      Begin VB.CommandButton cmdEnd 
         Caption         =   "&End"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   19
         ToolTipText     =   "�͡�ҡ�����"
         Top             =   1920
         Width           =   1215
      End
   End
   Begin VB.Frame Frame2 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4575
      Left            =   120
      TabIndex        =   31
      Top             =   3240
      Width           =   8055
      Begin VB.CheckBox Check6 
         Caption         =   "USE  �ӷ�������������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   14
         Top             =   3840
         Width           =   2295
      End
      Begin VB.TextBox Text1 
         DataField       =   "Use"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   9
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   15
         Top             =   3840
         Width           =   4815
      End
      Begin VB.CheckBox Check5 
         Caption         =   "SA ��͸Ժ�¡�����������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   10
         Top             =   2520
         Width           =   2295
      End
      Begin VB.CheckBox Check4 
         Caption         =   "NT �ӷ��᤺����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   12
         Top             =   3240
         Width           =   2175
      End
      Begin VB.CheckBox Check2 
         Caption         =   "BT �ӷ����ҧ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   240
         TabIndex        =   6
         Top             =   1020
         Width           =   2055
      End
      Begin VB.CheckBox Check1 
         Caption         =   "UF �ӷ����������������ͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   4
         Top             =   240
         Width           =   2055
      End
      Begin VB.TextBox Text1 
         DataField       =   "UF"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   4
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   5
         Top             =   240
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "BT"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   600
         Index           =   5
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   7
         Top             =   963
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "SA"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   7
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   11
         Top             =   2394
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "NT"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   8
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   13
         Top             =   3117
         Width           =   4815
      End
      Begin VB.CheckBox Check3 
         Caption         =   "RT �ӷ������Ǣ�ͧ����ѹ��ѹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   240
         TabIndex        =   8
         Top             =   1680
         Width           =   2295
      End
      Begin VB.TextBox Text1 
         DataField       =   "RT"
         DataSource      =   "Adodc1"
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   6
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   9
         Top             =   1671
         Width           =   4815
      End
   End
   Begin VB.Frame Frame1 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3015
      Left            =   120
      TabIndex        =   24
      Top             =   120
      Width           =   8055
      Begin VB.TextBox Text1 
         DataField       =   "Subheader_2"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   345
         Index           =   0
         Left            =   2640
         TabIndex        =   0
         Top             =   840
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "TranEng"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   1
         Left            =   2640
         TabIndex        =   1
         Top             =   1320
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "LC_Dewey"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Index           =   2
         Left            =   2640
         TabIndex        =   2
         Top             =   1800
         Width           =   4815
      End
      Begin VB.TextBox Text1 
         DataField       =   "Descript"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   615
         Index           =   3
         Left            =   2640
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   3
         Top             =   2280
         Width           =   4815
      End
      Begin VB.Label Label7 
         Caption         =   "Label7"
         DataField       =   "Subheader_1"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   615
         Left            =   5040
         TabIndex        =   38
         Top             =   240
         Width           =   2895
      End
      Begin VB.Label Label6 
         Alignment       =   2  'Center
         Caption         =   "- "
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   12
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   4800
         TabIndex        =   37
         Top             =   240
         Width           =   255
      End
      Begin VB.Label Label1 
         Caption         =   "�������ͧ���� 2"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   0
         Left            =   240
         TabIndex        =   30
         Top             =   960
         Width           =   1215
      End
      Begin VB.Label Label1 
         Caption         =   "���������ѧ����������ͧ����3"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   1
         Left            =   240
         TabIndex        =   29
         Top             =   1440
         Width           =   2175
      End
      Begin VB.Label Label1 
         Caption         =   "�Ţ���� [LC ; DEWEY]"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   2
         Left            =   240
         TabIndex        =   28
         Top             =   1920
         Width           =   2055
      End
      Begin VB.Label Label1 
         Caption         =   "��������´�������ͧ����3"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Index           =   3
         Left            =   240
         TabIndex        =   27
         Top             =   2400
         Width           =   1815
      End
      Begin VB.Label Label4 
         Caption         =   "�������ͧ :"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   375
         Left            =   240
         TabIndex        =   26
         Top             =   240
         Width           =   975
      End
      Begin VB.Label Label5 
         Caption         =   "Label5"
         DataField       =   "Header"
         DataSource      =   "Adodc1"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FF0000&
         Height          =   615
         Left            =   1320
         TabIndex        =   25
         Top             =   240
         Width           =   3375
      End
   End
   Begin VB.CommandButton Command1 
      Caption         =   ">>>"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8760
      TabIndex        =   23
      ToolTipText     =   "�����������ͧ���·� 3 (F7)"
      Top             =   5400
      Width           =   1455
   End
   Begin VB.Label Label9 
      Caption         =   "�����������ͧ����"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   255
      Left            =   8640
      TabIndex        =   40
      Top             =   5880
      Width           =   1695
   End
   Begin VB.Label Label8 
      Caption         =   "��ѧ�������ͧ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   255
      Left            =   8760
      TabIndex        =   39
      Top             =   4680
      Width           =   1335
   End
End
Attribute VB_Name = "Header2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public keytest As Boolean
Public currentRecord As Integer
Public Check_Header2Open As Boolean ' �� check ��� Form Header3 �١�Դ�ҡ Header2 �������

Private Sub Adodc1_MoveComplete(ByVal adReason As ADODB.EventReasonEnum, ByVal pError As ADODB.Error, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
    cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
    cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
    cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdOK.Enabled = False '��͹���� OK
    cmdCancel.Enabled = False '��͹���� Cancel
    
    
    Dim allRecord As Integer
    With Adodc1.Recordset
        currentRecord = .AbsolutePosition '�纵��˹���礤��촻Ѩ�غѹ
        allRecord = .RecordCount '�纨ӹǹ��礤��촷�����
    End With
    Adodc1.Caption = currentRecord & "/" & allRecord
    Label2.Caption = Adodc1.Caption
    
   If (Adodc1.Recordset.BOF) Or (Adodc1.Recordset.EOF) Then
    Check1.Value = 0
    Check2.Value = 0
    Check3.Value = 0
    Check4.Value = 0
    Check5.Value = 0
    Check6.Value = 0
    Else
    If Adodc1.Recordset.Fields("UF") <> "" Then
    Check1.Value = 1
    Else
    Check1.Value = 0
    End If
    
    If Adodc1.Recordset.Fields("BT") <> "" Then
    Check2.Value = 1
    Else
    Check2.Value = 0
    End If
    
    If Adodc1.Recordset.Fields("RT") <> "" Then
    Check3.Value = 1
    Else
    Check3.Value = 0
    End If
    
    If Adodc1.Recordset.Fields("SA") <> "" Then
    Check5.Value = 1
    Else
    Check5.Value = 0
    End If
    
    If Adodc1.Recordset.Fields("NT") <> "" Then
    Check4.Value = 1
    Else
    Check4.Value = 0
    End If
    
    If Adodc1.Recordset.Fields("Use") <> "" Then
    Check6.Value = 1
    Else
    Check6.Value = 0
    End If
    
    End If
End Sub

Private Sub Check1_Click()
If Check1.Value Then
   Text1(4).Enabled = True
   If keytest Then
        Text1(4).SetFocus
      End If
   Else
   Text1(4).Enabled = False
'   Check1.SetFocus
  End If
End Sub

Private Sub Check2_Click()
If Check2.Value Then
   Text1(5).Enabled = True
    If keytest Then
             Text1(5).SetFocus
           End If
   Else
   Text1(5).Enabled = False
 '  Check2.SetFocus
  End If
End Sub

Private Sub Check3_Click()
If Check3.Value Then
   Text1(6).Enabled = True
   If keytest Then
             Text1(6).SetFocus
     End If
   Else
   Text1(6).Enabled = False
  ' Check3.SetFocus
  End If
End Sub

Private Sub Check4_Click()
If Check4.Value Then
   Text1(8).Enabled = True
 If keytest Then
            Text1(8).SetFocus
    End If
   Else
   Text1(8).Enabled = False
   'Check4.SetFocus
  End If
End Sub

Private Sub Check5_Click()

  If Check5.Value Then
   Text1(7).Enabled = True
   If keytest Then
             Text1(7).SetFocus
    End If
   Else
   Text1(7).Enabled = False
   'Check5.SetFocus
  End If
End Sub

Private Sub Check6_Click()
If Check6.Value Then
    Text1(9).Enabled = True
     If keytest Then
                 Text1(9).SetFocus
    End If
    Else
    Text1(9).Enabled = False
    'Check6.SetFocus
    End If
End Sub

Private Sub cmdAdd_Click()
 Adodc1.Recordset.AddNew  '������礤�����ҧ����㹰ҹ������
    cmdAdd.Enabled = False   '��˹������� Add �����ʶҹ����������Ǥ���
    cmdUpdate.Enabled = False '��˹������� Update �����ʶҹ����������Ǥ���
    cmdDelete.Enabled = False '��˹������� Delete �����ʶҹ����������Ǥ���
    cmdEnd.Enabled = False '��˹������� End �����ʶҹ����������Ǥ���
    Adodc1.Enabled = False '��˹����͹��� ADO Data �����ʶҹ����������Ǥ���
    Command1.Enabled = False
    cmdOK.Enabled = True
    cmdCancel.Enabled = True
    Label7.Caption = Header1.Text1(0).Text
    Label5.Caption = Header1.Label5.Caption
    Check1.Value = 0
    Check2.Value = 0
    Check3.Value = 0
    Check4.Value = 0
    Check5.Value = 0
    Check6.Value = 0
    If keytest Then
    Text1(0).SetFocus
    End If
End Sub

Private Sub cmdCancel_Click()
Adodc1.Recordset.CancelUpdate '¡��ԡ�������������
    cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
    cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
    cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
    Command1.Enabled = True
    cmdOK.Enabled = False '��͹���� OK
    cmdCancel.Enabled = False '��͹���� Cancel
    Adodc1.Enabled = True '��˹����͹��� ADO Data �����ʶҹл��
    
    If currentRecord = -1 Then
    Adodc1.Recordset.MoveLast
    End If
End Sub

Private Sub cmdDelete_Click()
'��͹ź��礤��� ��ͧ��ä��׹�ѹ��͹
If MsgBox("�س��ͧ���ź��礤��촹�� ���������?", vbYesNo, "�׹�ѹ���ź��礤���") = vbYes Then
   With Adodc1.Recordset
       .Delete   '�������ź��礤���
       .MoveNext   '����͹���礤��촶Ѵ�
            If Adodc1.Recordset.EOF Then  '��Ǩ�ͺ��� �繨ش����ش�������
                 Adodc1.Recordset.MoveLast  '����� �������͹��¹����� ����礤����ش����
            End If
   End With
End If
End Sub

Private Sub cmdEnd_Click()
 Dim response As Variant
 Check_Header2Open = False
 If keytest Then
    response = MsgBox("�س��ͧ��÷��кѹ�֡�������¹�ŧ������� ", vbExclamation + vbYesNoCancel + vbDefaultButton1, "�͡�ҡ������������ͧ")
                  If response = vbYes Then
                 Call cmdUpdate_Click
                 keytest = False
                 Unload Me
                 ElseIf response = vbNo Then
                 keytest = False
                 Unload Me
                 End If
   Else
   Unload Me
   End If
   
End Sub

Private Sub cmdOK_Click()
'��Ǩ�ͺ��͹��� �������Ťú�ء��ͧ�������
If (Text1(0).Text = "") Then '������ú
     MsgBox "�س�ѧ�����������ú!", vbOKOnly, "��ͼԴ��Ҵ"
 Else
 Text1(0).Text = Replace(Text1(0).Text, "--", "-", 1)
     If Text1(1).Text <> "" Then
      Text1(1).Text = Replace(Text1(1).Text, "--", "-", 1)
     End If
     If Text1(1).Text <> "" Then
      Text1(1).Text = Replace(Text1(1).Text, "--", "-", 1)
     End If
     If Text1(3).Text <> "" Then
      Text1(3).Text = Replace(Text1(3).Text, "--", "-", 1)
     End If
     If Text1(4).Enabled Then
      Text1(4).Text = Replace(Text1(4).Text, "--", "-", 1)
     End If
     If Text1(5).Enabled Then
      Text1(5).Text = Replace(Text1(5).Text, "--", "-", 1)
     End If
     If Text1(6).Enabled Then
      Text1(6).Text = Replace(Text1(6).Text, "--", "-", 1)
     End If
     If Text1(7).Enabled Then
      Text1(7).Text = Replace(Text1(7).Text, "--", "-", 1)
     End If
     If Text1(8).Enabled Then
      Text1(8).Text = Replace(Text1(8).Text, "--", "-", 1)
     End If
     If Text1(9).Enabled Then
      Text1(9).Text = Replace(Text1(9).Text, "--", "-", 1)
     End If
     Adodc1.Enabled = True '��Ҥú��˹����͹��� ADO Data  �����ʶҹл���
     cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
    cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
    cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
    cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
    Command1.Enabled = True
    cmdOK.Enabled = False '��͹���� OK
    cmdCancel.Enabled = False '��͹���� Cancel
End If
End Sub

Private Sub cmdSearch_Click()
If Text1(0).Text = "" Then
MsgBox "�س�ѧ������������������ͧ����2! ��س��������������ͧ����2����", vbYes, "���Ң����żԴ��Ҵ"
Else
Header2Search.Show
End If
End Sub

Private Sub cmdUpdate_Click()
 Adodc1.Recordset.Update '�������������㹰ҹ������
 keytest = False
End Sub

Private Sub Command1_Click()
Check_Header2Open = True
If keytest Then
     Adodc1.Recordset.Update
     Adodc1.Enabled = True '��Ҥú��˹����͹��� ADO Data  �����ʶҹл���
     cmdAdd.Enabled = True '��˹������� Add �����ʶҹл���
     cmdDelete.Enabled = True '��˹������� Add �����ʶҹл���
     cmdUpdate.Enabled = True '��˹������� Add �����ʶҹл���
     cmdEnd.Enabled = True '��˹������� Add �����ʶҹл���
     cmdOK.Enabled = False '��͹���� OK
     cmdCancel.Enabled = False '��͹���� Cancel
     Header3.Show
Else
Header3.Show
End If
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyF1 Then
     Call cmdAdd_Click
End If
If KeyCode = vbKeyF5 Then
  Call cmdOK_Click
End If
If KeyCode = vbKeyF2 Then
   Call cmdUpdate_Click
 End If
 If KeyCode = vbKeyF3 Then
    Call cmdDelete_Click
 End If
 If KeyCode = vbKeyF6 Then
    Call cmdSearch_Click
 End If
 If KeyCode = vbKeyF7 Then
   Call Command1_Click
 End If
keytest = True
End Sub

Private Sub Form_Load()
Dim userCriteria As String '���͹䢢ͧ�����
Dim userCriteria1 As String
     Dim result As String '�š�ä���
     Dim Respond As Variant
     Check_Header2Open = False
     keytest = False
     
     '---------------------------------- check sub header1 --------------------------------
     '���Ŵ� Heade �����͹�㹡�ä���
     
     If Header1.Check_Header1Open Then
     
      userCriteria = "Subheader_1 like '" & Header1.Text1(0).Text & "'"
     With Adodc1.Recordset
           .MoveFirst '����¹��������价���õ����á��͹
           .Find userCriteria, , adSearchForward '��������ҵ�����͹�
     End With
        If Adodc1.Recordset.EOF Then '�����辺�������ͧ����ͧ���
               Call cmdAdd_Click
               Label5.Caption = Header1.Label5.Caption
                Label7.Caption = Header1.Text1(0).Text
         Else
'-----------------------------------------------------------  check header -----------------------------------
         If Adodc1.Recordset.Fields("Header") = Header1.Label5.Caption Then
              Label5.Caption = Header1.Label5.Caption
              Label7.Caption = Header1.Text1(0).Text
          Else
             Call cmdAdd_Click
              Label5.Caption = Header1.Label5.Caption
              Label7.Caption = Header1.Text1(0).Text
          End If          '--------------- end check header --------------------------
        End If            '--------------- end check sub header1 ------------------
        End If            '---------------- Check_HeaderOpen -----------------------
End Sub

Public Sub search()
    Dim userCriteria As String '���͹䢢ͧ�����
    Dim result As String '�š�ä���

'���Ŵ� Heade �����͹�㹡�ä���

'userCriteria = "Subheader_2 like '" & Header2Search.Text1.Text & "*'"
userCriteria = "Header = '" & Header1.Label5.Caption & "'"

If Header2Search.Text1.Text = "" Then  '��Ǩ�ͺ��͹��� ���������ͤ����������
     MsgBox "�س�ѧ������������������ͧ! ��س��������������ͧ����", vbYes, "���Ң����żԴ��Ҵ"
Else
    With Adodc1.Recordset
          .MoveFirst '����¹��������价���õ����á��͹
           .Find userCriteria, , adSearchForward '��������ҵ�����͹�
     End With
    
End If

        If Adodc1.Recordset.EOF Then '�����辺�������ͧ����ͧ���
             MsgBox "��辺������", vbYes, "�š�ä���"
             Adodc1.Recordset.MoveFirst
         Else
            userCriteria = "Subheader_1 = '" & Header1.Text1(0).Text & "'"
            Adodc1.Recordset.Find userCriteria, , adSearchForward
                  If Adodc1.Recordset.EOF Then
                        MsgBox "��辺������", vbYes, "�š�ä���"
                        Adodc1.Recordset.MoveFirst
                 Else
                     userCriteria = "Subheader_2 like '" & Header2Search.Text1.Text & "*'"
                     Adodc1.Recordset.Find userCriteria, , adSearchForward
                          If Adodc1.Recordset.EOF Then
                                  MsgBox "��辺������", vbYes, "�š�ä���"
                                  Adodc1.Recordset.MoveFirst
                          Else
                               If (Adodc1.Recordset.Fields("Header") <> Header1.Label5.Caption) Or (Adodc1.Recordset.Fields("Subheader_1") <> Header1.Text1(0).Text) Then
                                   MsgBox "��辺������", vbYes, "�š�ä���"
                                  Adodc1.Recordset.MoveFirst
                              End If
                         End If
                 End If
        End If
        
   Unload Header2Search
End Sub

Public Sub calladd()
     Adodc1.Recordset.AddNew  '������礤�����ҧ����㹰ҹ������
    cmdAdd.Enabled = False   '��˹������� Add �����ʶҹ����������Ǥ���
    cmdUpdate.Enabled = False '��˹������� Update �����ʶҹ����������Ǥ���
    cmdDelete.Enabled = False '��˹������� Delete �����ʶҹ����������Ǥ���
    cmdEnd.Enabled = False '��˹������� End �����ʶҹ����������Ǥ���
    Adodc1.Enabled = False '��˹����͹��� ADO Data �����ʶҹ����������Ǥ���
    Command1.Enabled = False
    cmdOK.Enabled = True
    cmdCancel.Enabled = True
    Check1.Value = 0
    Check2.Value = 0
    Check3.Value = 0
    Check4.Value = 0
    Check5.Value = 0
    Check6.Value = 0
    If keytest Then
    Text1(0).SetFocus
    End If
End Sub
