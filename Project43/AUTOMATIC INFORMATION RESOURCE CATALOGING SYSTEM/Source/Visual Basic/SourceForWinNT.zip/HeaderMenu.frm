VERSION 5.00
Begin VB.Form HeaderMenu 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Header Code Program"
   ClientHeight    =   6105
   ClientLeft      =   1530
   ClientTop       =   1875
   ClientWidth     =   8805
   FillColor       =   &H00FFFFFF&
   ForeColor       =   &H8000000E&
   Icon            =   "HeaderMenu.frx":0000
   LinkTopic       =   "Form3"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6105
   ScaleWidth      =   8805
   StartUpPosition =   2  'CenterScreen
   Begin VB.Image Image2 
      Height          =   1005
      Left            =   120
      Picture         =   "HeaderMenu.frx":110A
      Top             =   360
      Width           =   8925
   End
   Begin VB.Image Image1 
      Height          =   3075
      Index           =   5
      Left            =   600
      Picture         =   "HeaderMenu.frx":42BF
      Stretch         =   -1  'True
      Top             =   2160
      Width           =   2325
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��Ѻ��ѧ������ѡ"
      DragIcon        =   "HeaderMenu.frx":4BB0
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   3240
      TabIndex        =   3
      Top             =   4920
      Width           =   1935
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��������¤��Ң������������ͧ�ҡ WEB "
      DragIcon        =   "HeaderMenu.frx":4EBA
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   3240
      TabIndex        =   2
      Top             =   3960
      Width           =   4455
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "��������¤��Ң������������ͧ�ҡ�ҹ������"
      DragIcon        =   "HeaderMenu.frx":51C4
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   3240
      TabIndex        =   1
      Top             =   3000
      Width           =   4815
   End
   Begin VB.Label Label1 
      BackStyle       =   0  'Transparent
      Caption         =   "�������á�͡�����䢢������������ͧ"
      DragIcon        =   "HeaderMenu.frx":54CE
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   0
      Left            =   3240
      TabIndex        =   0
      Top             =   2040
      Width           =   4335
   End
End
Attribute VB_Name = "HeaderMenu"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Label1_DragDrop(Index As Integer, Source As Control, X As Single, Y As Single)
If Source Is Label1(Index) Then
        With Label1(Index)
            .Font.Underline = False
            .ForeColor = vbBlack
            Screen.MousePointer = vbHourglass
            
            Select Case Index
            Case 0
                Header.Show
            Case 1
                SearchHeader.Show
            Case 2
              SearchList.Show
            Case 3
               Main.Visible = True
               Unload Me
            
            End Select
            Screen.MousePointer = vbNormal
        End With
    End If
End Sub

Private Sub Label1_DragOver(Index As Integer, Source As Control, X As Single, Y As Single, State As Integer)
If State = vbLeave Then
        With Label1(Index)
            .Drag vbEndDrag
            .Font.Underline = False
            .ForeColor = vbBlack
           'image1(0).Picture = Image1(5).Picture
         
        End With
    End If

End Sub

Private Sub Label1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
With Label1(Index)
        .ForeColor = vbBlue
        .Font.Underline = True
        .Drag vbBeginDrag
        'Image1(0).Picture = Image1(Index + 1).Picture

    End With
  
End Sub
