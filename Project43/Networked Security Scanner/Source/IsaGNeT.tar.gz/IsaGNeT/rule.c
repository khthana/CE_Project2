#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *fp;
int item;

int opentag(int);
void parser(char *,char *,char *);
char *find_exp(char *,char *,char *);
char temp[2000];
int exp3_result;
FILE *result;

rules(int port_d,char *os_d,char *ver_d,FILE *result)
{
int pp;
int i,openstr=0;
fpos_t filepos;

if((fp = fopen("/usr/local/bin/isagnet-conf/rules","r"))==NULL)
{
	printf("Can't find RULE file");
	exit(0);
}

while ((item = fgetc(fp)) != EOF)
{
	if(item == '[')
	{
		pp=opentag(item);
		if(pp==port_d) {
			  i=0;
			  do
			  {
			  fgetpos(fp,&filepos);
			  item=fgetc(fp);
			  if(item=='"')
				if(openstr==0) openstr=1;
				else openstr=0;

			  if((item!='[')&&(item!='\n'))
			  if((item!=' ')||(openstr==1))
			  temp[i++]=item;
			  }while((item!='[')&&(item!=EOF));
			  temp[i]='\0';
			  //printf("\n%s\n",temp);
			  parser(temp,os_d,ver_d);

			  fsetpos(fp,&filepos);
	}
}
}
printf("\n");
fclose(fp);
return 0;
}

int opentag(int test)
{
	int port=0;
	
	//printf("tag");
	if(test == '['){
	fscanf(fp,"%d",&port);
	//printf("\n%d",port);
	}
	fscanf(fp,"%s",temp);
	return port;
}

void parser(char *str,char *os_d,char *ver_d)
{
	char *p,*q;
	char exp[20];
	char exp1[3];
	int i=0;
	char ver[10];
	char bug[1000];
	char sol[1000];

	//printf("\n!!!!!!%s",str);

	p = strstr(str,"if");

	if(p){
	//printf("\nfound 'if' next shoud be '('\n");

	if( *(p+2) == '('); //printf("'(' OK!!\n");
	} //found 'if' and next is '('
	p = strstr(p,"(");
	
	if(*(p+1)!='(')
	{
   	p=find_exp(p,os_d,ver_d);
	}
	else {
	p=strstr(p,"(");
	p=find_exp(p,os_d,ver_d);
	//printf("\n%s\n",p);
	}
	
	p=strstr(str,"{bug(");
	//printf("%s",p);
	if(p);
	{
	i=0;
	while(*(p+i+6)!='"')
	{
	bug[i++]=*(p+i+6);
	}
	bug[i]='\0';
	if(exp3_result){
	printf("\n=== Description ===\n\t%s\n",bug);
	fprintf(result,"\n=== Description ===\n\t%s\n",bug);
	}
	}

	p=strstr(str,")sol(");
	//printf("%s",p);
	if(p);
	{
	i=0;
	while(*(p+i+6)!='"')
	{
	sol[i++]=*(p+i+6);
	}
	sol[i]='\0';
	if(exp3_result){
	printf("=== How To Fix ===\n\t%s\n",sol);
	fprintf(result,"=== How To Fix ===\n\t%s\n",sol);
	}
	}
}

char *find_exp(char *p,char *os_d,char *ver_d)
{
char exp[30];
char exp1[3];
char exp2[3];
char exp3[3];
char ver1[50];
char ver2[20];
char ver2_t[20];
int i=0,j,a=0,b=0;
char *temp;
char temp_exp[1000];

int exp1_result=0;
int exp2_result=0;
//int exp3_result=0;

/*temp variable*/
//int port_d=25;
//char os_d[30]="Linux 2.2.10";
//char ver_d[20]="8";
/*End of Temp Variable*/

strcpy(exp1,"\0");
strcpy(exp2,"\0");
strcpy(exp3,"\0");

if(*(p+1)=='(')
	j=2; else j=1;
temp=p;
for(j;j--;j<1){
p=temp;
//printf("%s\n",p);
i=0;
while(*(p+i)!=')')
	{
	exp[i++]=*(p+i);
	}
	//exp[i++]=*(p+i);
	exp[i]='\0';
    //printf("%s\n",exp);  
    temp=temp+(i+1);
	//++temp;
	strcpy(temp_exp,temp);
	temp=temp_exp;
	//printf("%s\n",temp);
	
	if(j>0){
	exp3[0]=*(temp);
	exp3[1]=*(temp+1);
	exp3[2]='\0';
//	printf("\nCondition Expression is %s\n",exp3);
	}
	
	if(strstr(exp,"ver"))
	{
		if(strstr(exp,"<=")) strcpy(exp1,"<=");else
		if(strstr(exp,">=")) strcpy(exp1,">=");else
		if(strstr(exp,"==")) strcpy(exp1,"==");else
		if(strstr(exp,"<"))  strcpy(exp1,"<"); else
		if(strstr(exp,">"))  strcpy(exp1,">"); else
		if(strstr(exp,"!=")) strcpy(exp1,"!=");

		p=strtok(exp,exp1);
		p=strtok(NULL,exp1);
		//printf("%s",p);
		strcpy(ver1,p);
		/*printf("Expresstion  1 is : %s\n",exp1);
		printf("Version that have bug is %s\n",ver1);*/
        
	}  

	if(strstr(exp,"os"))
	{
		if(strstr(exp,"<=")) strcpy(exp2,"<=");else
		if(strstr(exp,">=")) strcpy(exp2,">=");else
		if(strstr(exp,"==")) strcpy(exp2,"==");else
		if(strstr(exp,"<"))  strcpy(exp2,"<"); else
		if(strstr(exp,">"))  strcpy(exp2,">"); else
		if(strstr(exp,"!=")) strcpy(exp2,"!=");

		p=strtok(exp,exp2);
		p=strtok(NULL,exp2);
		//printf("%s",p);
		strcpy(ver2,p);
		strcpy(ver2_t,ver2);
		a=0; b=0;
		while(ver2_t[a]!='\0')
		{if(ver2_t[a]!='"')
		{ ver2[b]=ver2_t[a]; b++; }
		a++;
		}
		ver2[b]='\0';
		/*printf("Expresstion 2 is : %s\n",exp2);
		printf("Version that have bug is %s\n",ver2);*/
        }}
	
	 if((strcmp(exp1,"\0"))) 
		{
			exp1_result=0;
			i=0;
			while((ver_d[i]!='\0')&&(ver1[i]!='\0'))
			{
			if(ver_d[i]!=ver1[i]){i++; break;}
			i++;
			};
			--i;
			if(ver_d[i]=='.')ver_d[i]='0';
			if(ver1[i]=='.')ver1[i]='0';
			if(ver_d[i]==ver1[i]) {if(strstr(exp1,"=")) exp1_result=1;} else
			if(i==0){if(strstr(exp1,"!="))exp1_result=1;} else
			if((ver_d[i] < ver1[i])&&!((ver_d[i+1]>='0')&&(ver_d[i+1]<='9')))
			{if(strstr(exp1,"<")||strstr(exp1,"!=")) exp1_result=1;} else
			if((ver_d[i] > ver1[i])&&!((ver1[i+1]>='0')&&(ver1[i+1]<='9')))
			{if(strstr(exp1,">")||strstr(exp1,"!=")) exp1_result=1;} 

		 }

	if((strcmp(exp2,"\0"))) 
		{
			//printf("!!!!!!%s\n",ver2);
			os_d=os_d+2;
			//printf("!!!!!!%s\n",os_d);
			//ver2=ver2+1;
			i=0;
			while((os_d[i]!='\0')&&(ver2[i]!='\0'))
			{
			if(os_d[i]!=ver2[i]){i++; break;}
			i++;
			};
			--i;
			if(os_d[i]=='.')os_d[i]='0';
			if(ver2[i]=='.')ver2[i]='0';
			if(os_d[i]==ver2[i]) {if(strstr(exp2,"=")) exp2_result=1;} else
			if(i==0){if(strstr(exp2,"!="))exp2_result=1;} else
			if((os_d[i] < ver2[i])&&!((os_d[i+1]>='0')&&(os_d[i+1]<='9')))
			{if(strstr(exp2,"<")||strstr(exp2,"!=")) exp2_result=1;} else
			if((os_d[i] > ver2[i])&&!((ver2[i+1]>='0')&&(ver2[i+1]<='9')))
			{if(strstr(exp2,">")||strstr(exp2,"!=")) exp2_result=1;} 
			//if(exp2_result)printf("!!!Yes That Right\n");
		}
	
     if(strcmp(exp3,"\0"))
		{
			if(exp2=="&&")exp3_result=exp2_result&&exp1_result; else
			exp3_result=exp2_result||exp1_result;
		}else exp3_result=exp2_result||exp1_result;
	


	return(p);
}
