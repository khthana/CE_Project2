#include	<stdio.h>
#include	<errno.h>
#include 	<err.h>
#include	<sys/time.h>
#include	<sys/param.h>
#include	<sys/socket.h>
#include   	<sys/file.h>
#include   	<signal.h>
#include   	<unistd.h>
#include   	<netdb.h>
#include   	<stdlib.h>
#include   	<string.h>
#include   	<netinet/in.h>
#include   	<arpa/inet.h>
#include   	<netinet/ip.h>
#include   	<netinet/tcp.h>

//#include	<bsd/signal.h>

#include	<netinet/in_systm.h>
#include	<netinet/ip_icmp.h>

#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif

#define MAXWAIT		10

#define MAXPACKET	4096

#ifndef MAXHOSTNAMELEN
#define	MAXHOSTNAMELEN
#endif

#define SIZE_ICMP_HDR	8
#define SIZE_TIME_DATA	8
#define DEF_DATALEN	56

/*Decaration of Scan Port Section*/
void scanport(char *);
/*End of Scan Port Decaration*/

int 	packsize;

int 	datalen;

int 	verbose;
u_char	sendpack[MAXPACKET];
u_char	recvpack[MAXPACKET];

struct sockaddr_in	dest;
int	sockfd;

char	*hostname;
int 	npackets;
int 	ident;
int 	ntransmitted;
int	nreceived;
int    finish=0;
char    recvfrom_h[20];

int	timing;

int 	tmin;
int	tmax;
long	tsum;

void	sig_finish(int);

void 	sig_alarm(int);

char	hnamebuf[MAXHOSTNAMELEN];
char	*pname;
char    *destdotaddr;
FILE *result;

void ping_host(char *p_host,FILE *result)
{		
	int	sockoptions, on, i;
	//char	*destdotaddr;
	char	*host_err_str();
	struct hostent	*host;
	struct protoent	*proto;
	int port,retval;
	struct tcphdr packet;;
//	Sigfunc  *sigfunc;

	on=1;
	//pname = argv[0];
	pname=p_host;
	/*argc--;
	argv++;*/
	
	sockoptions = 0;
	
	bzero((char *) &dest, sizeof(dest));
	dest.sin_family = AF_INET;
	
	if( (dest.sin_addr.s_addr = inet_addr(pname)) != INADDR_NONE) {
		strcpy(hnamebuf, pname);
		hostname = hnamebuf;
		destdotaddr = NULL;
	} else {
		if ( (host = gethostbyname(pname)) == NULL) {
			printf("host name error:%s\n",
					pname );
					exit(-1);
		}
		//dest.sin_family = host->h_addrtype;
		bcopy(host->h_addr, &dest.sin_addr, host->h_length);
		hostname = host->h_name;
		//destdotaddr = inet_ntoa(dest.sin_addr.s_addr);
		//printf("%s",inet_ntoa(dest.sin_addr.s_addr));
		}
	datalen = DEF_DATALEN;
	packsize = datalen + SIZE_ICMP_HDR;
	if (datalen >= SIZE_TIME_DATA)
		timing = 1;
	npackets = 5;
	ident = getpid() & 0xffff;
	
	if ( (proto = getprotobyname("icmp")) == NULL)
		printf("unknown protocol: icmp");
	if ( (sockfd = socket(AF_INET, SOCK_RAW, proto->p_proto)) < 0)
		printf("can't create raw socket");
	if (sockoptions & SO_DEBUG)
		if (setsockopt(sockfd, SOL_SOCKET, SO_DEBUG, &on,sizeof(on))<0)
			printf("setsockopt SO_DONTROUTE error");
	printf("PING %s", hostname);
	fprintf(result,"PING %s",hostname);
	if(destdotaddr){
		printf(" (%s)",destdotaddr);
		fprintf(result," (%s)",destdotaddr);
		}
        else destdotaddr=hostname;

	printf(": %d data bytes\n", datalen);
	fprintf(result,": %d databytes\n",datalen);
	tmin = 99999999;
	setlinebuf(stdout);
	
	signal(SIGALRM, sig_alarm);
	sig_alarm(0);
	recv_ping();
	
	alarm(0);

}

void sig_alarm(int temp_i)
{
	int	waittime;

	send_ping();

	if(npackets == 0 || ntransmitted < npackets)
		alarm(1);
	else {
	if (nreceived) {
		waittime = 2* tmax/1000;
		if (waittime == 0)
			waittime = 1;
		} else
			waittime = MAXWAIT;
		signal(SIGALRM, sig_finish);
		alarm(waittime);
	}
	return;
}

send_ping()

{
	register int		i;
	register struct icmp	*icp;
	register u_char		*uptr;
//	printf(" Send packet ");
	icp = (struct icmp *) sendpack;
	icp->icmp_type = ICMP_ECHO;
	icp->icmp_code = 0;
	icp->icmp_cksum = 0;
	icp->icmp_id   = ident;
	icp->icmp_seq  = ntransmitted++;

	if(timing)
		gettimeofday((struct timeval *) &sendpack[SIZE_ICMP_HDR],
			     (struct timezone *) 0);
	uptr = &sendpack[SIZE_ICMP_HDR + SIZE_TIME_DATA];
	for (i = SIZE_TIME_DATA; i < datalen; i++)
		*uptr++ = i;

	icp->icmp_cksum = in_cksum_ping(icp, packsize);

	i = sendto(sockfd, sendpack, packsize, 0, (struct sockaddr *) &dest,
				sizeof(dest));
	if (i < 0 || i!= packsize) {
		if (i < 0)
		//	err_ret("sendto error");
			printf("sendto error");
		else
			printf("wrote %s %d bytes, return=%d",hostname,packsize,i);
                        printf("send to");
} 
}

int in_cksum_ping(ptr, nbytes)
register u_short 	*ptr;
register int		nbytes;
{
	register long	sum;
	u_short		oddbyte;
	register u_short	answer;

	sum = 0;
	while (nbytes > 1) {
		sum += *ptr++;
		nbytes -= 2;
	}

	if (nbytes == 1) {
		oddbyte = 0;
		*((u_char *) &oddbyte) = *(u_char *)ptr;
		sum += oddbyte;
	}

	sum = (sum >> 16)+(sum & 0xffff);
	sum += (sum >> 16);
	answer = ~sum;
	return(answer);
}

void sig_finish(int temp_i2)
{
	printf("\n----%s PING Statistics----\n",hostname);
	printf("%d packets transmitted, ",ntransmitted );
	printf("%d packets received, ",nreceived );
	fprintf(result,"\n----%s PING Statistics----\n",hostname);
	fprintf(result,"%d packets transmitted, ",ntransmitted );
	fprintf(result,"%d packets received, ",nreceived );

	if (ntransmitted){
		printf("%d%% packet loss",
			(int) (((ntransmitted-nreceived)*100)/ntransmitted) );
		fprintf(result,"%d%% packet loss",
			(int) (((ntransmitted-nreceived)*100)/ntransmitted) );
			}
	printf("\n");
	fprintf(result,"\n");
	if (nreceived && timing){
		printf("round-trip (ms) min/avg/max = %d/%d/%d\n",
			tmin,tsum / nreceived,tmax );
		fprintf(result,"round-trip (ms) min/avg/max = %d/%d/%d\n",
			tmin,tsum / nreceived,tmax );
			}
	fflush(stdout);
        //alarm(0);
//	exit(0);
	if(nreceived==0){ 
		puts("");
		puts("!Ping to host loss the server maybe down can't scan this server");
		fprintf(result,"\n!Ping to host loss the server maybe down can't scan this server");
		exit(0);
	}
    return;
}

recv_ping()
{
	register int		n;
	int			fromlen;
	struct sockaddr_in	from;
    //int             finish=0;

	while(finish!=1) {
		fromlen = sizeof(from);
	n = recvfrom(sockfd, recvpack, sizeof(recvpack),0,
			(struct sockaddr *) &from, &fromlen);
			//printf("\n N=%d \n",n);
			/*if(n<0){
			//printf("\nRecived ERROR!!!!\n");
			if (errno == EINTR)
			continue;
			printf("recvfrom error");
			continue;
		}//printf("Recived NO error\n");*/

		//recvfrom_h = inet_ntoa(from->sin_addr.s_addr);
                //printf("%s",inet_ntoa((from->sin_addr.s_addr)));

		pr_pack(recvpack,n ,&from);
		
		if (npackets && (nreceived >= npackets))
			{alarm(0); sig_finish(0);
                        finish=1; }
}
return;
}

pr_pack(buf, cc ,from)
char		*buf;
int 		cc;
struct sockaddr_in	*from;
{
	int 			i, iphdrlen, triptime;
	struct ip		*ip;
	register struct icmp	*icp;
	long			*lp;
	struct timeval		tv;
	char			*pr_type();

	//from->sin_addr.s_addr = ntohl(from->sin_addr.s_addr);
	if(timing)
		gettimeofday(&tv, (struct timezone *) 0);
	ip = (struct ip *) buf;
	iphdrlen = ip->ip_hl << 2;
	if(cc < iphdrlen + ICMP_MINLEN) {
		if(verbose)
			/*printf("packet to short (%d bytes) from %s\n", cc,
				inet_ntoa((from->sin_addr.s_addr)));*/
		return;
	}
	cc -= iphdrlen;
	icp = (struct icmp *)(buf + iphdrlen);
	if (icp->icmp_type != ICMP_ECHOREPLY) {
		if(verbose) {
			lp = (long *) buf;
			printf("%d bytes from %s: ",cc,
				destdotaddr);
			fprintf(result,"%d bytes from %s: ",cc,
				destdotaddr);

			printf("icmp_type=%d (%s)\n",
				icp->icmp_type,pr_type(icp->icmp_type));
			fprintf(result,"icmp_type=%d (%s)\n",
				icp->icmp_type,pr_type(icp->icmp_type));

			for (i=0;i<12; i++){
				printf("x%2.2x: x%8.8x\n", i*sizeof(long), *lp++);
				fprintf(result,"x%2.2x: x%8.8x\n", i*sizeof(long), *lp++);
				}
			printf("icmp_code=%d\n", icp->icmp_code);
			fprintf(result,"icmp_code=%d\n", icp->icmp_code);
	}
	return;
}

	if (icp->icmp_id != ident)
		return;
	printf("%d bytes from %s: ",cc, 
			destdotaddr);
	fprintf(result,"%d bytes from %s: ",cc, 
			destdotaddr);

	printf("icmp_seq=%d. ",icp->icmp_seq);
	fprintf(result,"icmp_seq=%d. ",icp->icmp_seq);

	if(timing) {
		tvsub(&tv, (struct timeval *) &icp->icmp_data[0]);
		triptime = tv.tv_sec * 1000 + (tv.tv_usec /1000);
		printf("time=%d. ms",triptime);
		fprintf(result,"time=%d. ms",triptime);
		tsum += triptime;
		if (triptime < tmin)
			tmin = triptime;
		if (triptime > tmax)
			tmax = triptime;
	}
	putchar('\n');
	fputs("\n",result);
	nreceived++;
}

char * pr_type(t)
register int t;
{
	static char	*ttab[] = {
		"Echo Reply",
		"ICMP 1",
		"ICMP 2",
		"Dest Unreachable",
		"Source Quence",
		"Redirect",
		"ICMP 6",
		"ICMP 7",
		"Echo",
		"ICMP 9",
		"ICMP 10",
		"Time Exceeded",
		"Parameter Problem",
		"Timestamp",
		"Timestamp Reply",
		"Info Request",
		"Info Reply"
	};
	if(t < 0 || t > 16)
		return("OUT-OF-RANGE");
	return(ttab[t]);
}

tvsub(out,in)
register struct timeval *out;
register struct timeval *in;
{
	if ( (out->tv_usec -= in->tv_usec) < 0) {
		out->tv_sec--;
		out->tv_usec += 1000000;
	}
	out->tv_sec -= in->tv_sec;
}

/*Begin of scanport*/

void scanport(char *scanhost)
{
    int sock, port = 0,telnet=0;
	struct sockaddr_in serverto;
	struct servent *sv;
	struct 	hostent *hp;
	puts("");
	puts("[Port Scanning....]");
 	puts("");
	fprintf(result,"\n[Port Scanning....]\n");

 	for(port=1; port < 7000; port++)
 	{
   		strncpy( (char *) &serverto, "", sizeof(serverto) );
		serverto.sin_family = AF_INET;

		sock = socket(AF_INET, SOCK_STREAM, 0); 
		if (sock < 0) {
			perror("Stream socket failure!");
			exit(1);
		}
		/* I must take out the gethost routine out of this loop */		
  		serverto.sin_port = htons(port);
  		hp = gethostbyname(scanhost);
  		if (hp == NULL) {
  			herror("Can't resolve hostname - try again with IP address!");
  			exit(1);
  		}
  		bcopy(hp->h_addr, &serverto.sin_addr, hp->h_length); 
     
     		if ( (connect (sock, (struct sockaddr *) &serverto, sizeof (serverto) ) < 0) ) {
 		
 				printf("%s    %d %s\r", scanhost, port, strerror(errno)); 
				
			close(sock); /* Important to close here! */
			continue; /* Try next port instead */
 		}

		sv = getservbyport( htons(port), 0); 
/* placing the above here makes it faster it's very CPU intensive !               */
 		if (sv != 0) /* provided we have a good /etc/services file */ 
 		{
 			printf("%s    %d %s   ..Active!                   \n", scanhost, port, sv->s_name);
			fprintf(result,"%s    %d %s   ..Active!                   \n", scanhost, port, sv->s_name);

		}
		if (sv == NULL)
		{
/* OK the port is open but we have a bad /etc/services file */
 			printf("%s    %d   ..Active!                   \n", scanhost, port);
			fprintf(result,"%s    %d   ..Active!                   \n", scanhost, port);
		}
	if(port==23) telnet=1;
 	close(sock); /* close stream */
	} /* for */

	if(telnet){
	printf("\n\n=== Description ===\n");
	printf("\tTelnet is a service that allows a remote user to connect to a machine.\nTelnet sends all usernames, passwords, and data unencrypted.");
	printf("\n=== How to Fix ===\n");
	printf("\tDisable the telnet service in the /etc/inetd.conf file. Restart inetd so \nchanges take effect. Please use Secure SHELL");

	fprintf(result,"\n\n=== Description ===\n");
	fprintf(result,"\tTelnet is a service that allows a remote user to connect to a machine.\nTelnet sends all usernames, passwords, and data unencrypted.");
	fprintf(result,"\n=== How to Fix ===\n");
	fprintf(result,"\tDisable the telnet service in the /etc/inetd.conf file. Restart inetd so \nchanges take effect. Please use Secure SHELL\n");

	}
	puts("");
} /* probe_ports */
  










