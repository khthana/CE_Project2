/* config.h.  Generated automatically by configure.  */
/* $Id: config.h.in,v 1.5 1998/09/22 17:19:09 savage Exp $ */

#define LINUX 1
#define __BSD_SOURCE 1
#define _BSD_SOURCE 1
#define NEEDS_HTONS_IP_LEN 1
/* #undef HAVE_STRUCT_IP_CSUM */
/* #undef SOLARIS_CKSUM_BUG */
/* #undef PCAP */

