package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import java.util.Collection;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface PackageTourRemote extends EJBObject {
    String getPackageId() throws RemoteException;
    String getPackageName() throws RemoteException;
    void setPackageName(String packageName) throws RemoteException;
    String getDescription() throws RemoteException;
    void setDescription(String description) throws RemoteException;
    Double getTotalPrice() throws RemoteException;
    void setTotalPrice(Double totalPrice) throws RemoteException;
    String getImage() throws RemoteException;
    void setImage(String image) throws RemoteException;
    Integer getDuration() throws RemoteException;
    void setDuration(Integer duration) throws RemoteException;
    String getBusGroupBookingId() throws RemoteException;
    void setBusGroupBookingId(String busGroupBookingId) throws RemoteException;
    String getHotelGroupBookingId() throws RemoteException;
    void setHotelGroupBookingId(String hotelGroupBookingId) throws RemoteException;
    String getAircraftGroupBookingId() throws RemoteException;
    void setAircraftGroupBookingId(String aircraftGroupBookingId) throws RemoteException;
    String getRestaurantGroupBookingId() throws RemoteException;
    void setRestaurantGroupBookingId(String restaurantGroupBookingId) throws RemoteException;
    Timestamp getCreateTime() throws RemoteException;
    void setCreateTime(Timestamp createTime) throws RemoteException;
    String getAdminId() throws RemoteException;
    void setAdminId(String adminId) throws RemoteException;
    Integer getConfirm() throws RemoteException;
    void setConfirm(Integer confirm) throws RemoteException;
    Collection getPackageTourDepartTimeInformations(java.sql.Date departTime) throws RemoteException;
    PackageDepartTimeInformation getPackageTourDepartTimeInformation(java.sql.Timestamp departTime) throws RemoteException;
    Collection getPackagePlaces() throws RemoteException;
}