package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface PlaceHome extends EJBHome {
    public PlaceRemote create(String placeId, String placeName, String country, String state, String province, String description, String imagefilePath) throws RemoteException, CreateException;
    public PlaceRemote create(String placeId) throws RemoteException, CreateException;
    public PlaceRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
    public Collection findByPlaceNameCountryStateProvinceDescription(String placeName, String country, String state, String province, String description) throws RemoteException, FinderException;
}