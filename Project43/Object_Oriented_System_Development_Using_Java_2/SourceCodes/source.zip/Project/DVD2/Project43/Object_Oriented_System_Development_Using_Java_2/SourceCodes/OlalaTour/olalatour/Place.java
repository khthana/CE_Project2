package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Place implements EntityBean {
    EntityContext entityContext;
    public String placeId;
    public String placeName;
    public String country;
    public String state;
    public String province;
    public String description;
    public String imagefilePath;
    public String ejbCreate(String placeId, String placeName, String country, String state, String province, String description, String imagefilePath) throws CreateException {
	this.placeId = placeId;
	this.placeName = placeName;
	this.country = country;
	this.state = state;
	this.province = province;
	this.description = description;
	this.imagefilePath = imagefilePath;
	return null;
    }
    public String ejbCreate(String placeId) throws CreateException {
	return ejbCreate(placeId, null, null, null, null, null, null);
    }
    public void ejbPostCreate(String placeId, String placeName, String country, String state, String province, String description, String imagefilePath) throws CreateException {
    }
    public void ejbPostCreate(String placeId) throws CreateException {
	ejbPostCreate(placeId, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getPlaceId() {
	return placeId;
    }
    public String getPlaceName() {
	return placeName;
    }
    public void setPlaceName(String placeName) {
	this.placeName = placeName;
    }
    public String getCountry() {
	return country;
    }
    public void setCountry(String country) {
	this.country = country;
    }
    public String getState() {
	return state;
    }
    public void setState(String state) {
	this.state = state;
    }
    public String getProvince() {
	return province;
    }
    public void setProvince(String province) {
	this.province = province;
    }
    public String getDescription() {
	return description;
    }
    public void setDescription(String description) {
	this.description = description;
    }
    public String getImagefilePath() {
	return imagefilePath;
    }
    public void setImagefilePath(String imagefilePath) {
	this.imagefilePath = imagefilePath;
    }
}