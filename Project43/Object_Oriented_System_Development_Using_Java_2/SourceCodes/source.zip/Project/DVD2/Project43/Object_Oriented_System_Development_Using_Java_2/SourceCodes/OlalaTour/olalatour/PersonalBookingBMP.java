package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public class PersonalBookingBMP extends PersonalBooking {
  DataSource dataSource;
  public PersonalBookingPK ejbCreate(String bookingId, String travellerId, Boolean hasBookBusSeat, Boolean hasBookAirSeat) throws CreateException {
    super.ejbCreate(bookingId, travellerId, hasBookBusSeat, hasBookAirSeat);
    try {
      //First see if the object already exists
      ejbFindByPrimaryKey(new olalatour.PersonalBookingPK(bookingId, travellerId));
      //If so, then we have to throw an exception
      throw new DuplicateKeyException("Primary key already exists");
    }
    catch(ObjectNotFoundException e) {
      //Otherwise we can go ahead and create it...
    }
    Connection connection = null;
    PreparedStatement statement = null;
    try {
      connection = dataSource.getConnection();
      statement = connection.prepareStatement("INSERT INTO PERSONAL_BOOKING (BOOKING_ID, TRAVELLER_ID, HAS_BOOK_BUS_SEAT, HAS_BOOK_AIR_SEAT) VALUES (?, ?, ?, ?)");
      statement.setString(1, bookingId);
      statement.setString(2, travellerId);
      statement.setBoolean(3, hasBookBusSeat.booleanValue());
      statement.setBoolean(4, hasBookAirSeat.booleanValue());
      if (statement.executeUpdate() != 1) {
        throw new CreateException("Error adding row");
      }
      statement.close();
      statement = null;
      connection.close();
      connection = null;
      return new PersonalBookingPK(bookingId, travellerId);
    }
    catch(SQLException e) {
      throw new EJBException("Error executing SQL INSERT INTO PERSONAL_BOOKING (BOOKING_ID, TRAVELLER_ID, HAS_BOOK_BUS_SEAT, HAS_BOOK_AIR_SEAT) VALUES (?, ?, ?, ?): " + e.toString());
    }
    finally {
      try {
        if (statement != null) {
          statement.close();
        }
      }
      catch(SQLException e) {
      }
      try {
        if (connection != null) {
          connection.close();
        }
      }
      catch(SQLException e) {
      }
    }
  }
  public PersonalBookingPK ejbCreate(String bookingId, String travellerId) throws CreateException {
    return ejbCreate(bookingId, travellerId, null, null);
  }
  public void ejbRemove() throws RemoveException {
    super.ejbRemove();
    Connection connection = null;
    PreparedStatement statement = null;
    try {
      connection = dataSource.getConnection();
      statement = connection.prepareStatement("DELETE FROM PERSONAL_BOOKING WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?");
      statement.setString(1, bookingId);
      statement.setString(2, travellerId);
      if (statement.executeUpdate() < 1) {
        throw new RemoveException("Error deleting row");
      }
      statement.close();
      statement = null;
      connection.close();
      connection = null;
    }
    catch(SQLException e) {
      throw new EJBException("Error executing SQL DELETE FROM PERSONAL_BOOKING WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?: " + e.toString());
    }
    finally {
      try {
        if (statement != null) {
          statement.close();
        }
      }
      catch(SQLException e) {
      }
      try {
        if (connection != null) {
          connection.close();
        }
      }
      catch(SQLException e) {
      }
    }
  }
  public void ejbLoad() {
    PersonalBookingPK key = (PersonalBookingPK) entityContext.getPrimaryKey();
    bookingId = key.bookingId;
    travellerId = key.travellerId;
    Connection connection = null;
    PreparedStatement statement = null;
    try {
      connection = dataSource.getConnection();
      statement = connection.prepareStatement("SELECT HAS_BOOK_BUS_SEAT, HAS_BOOK_AIR_SEAT FROM PERSONAL_BOOKING WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?");
      statement.setString(1, bookingId);
      statement.setString(2, travellerId);
      ResultSet resultSet = statement.executeQuery();
      if (!resultSet.next()) {
        throw new NoSuchEntityException("Row does not exist");
      }
      hasBookBusSeat = new Boolean(resultSet.getBoolean(1));
      hasBookAirSeat = new Boolean(resultSet.getBoolean(2));
      statement.close();
      statement = null;
      connection.close();
      connection = null;
    }
    catch(SQLException e) {
      throw new EJBException("Error executing SQL SELECT HAS_BOOK_BUS_SEAT, HAS_BOOK_AIR_SEAT FROM PERSONAL_BOOKING WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?: " + e.toString());
    }
    finally {
      try {
        if (statement != null) {
          statement.close();
        }
      }
      catch(SQLException e) {
      }
      try {
        if (connection != null) {
          connection.close();
        }
      }
      catch(SQLException e) {
      }
    }
    super.ejbLoad();
  }
  public void ejbStore() {
    super.ejbStore();
    Connection connection = null;
    PreparedStatement statement = null;
    try {
      connection = dataSource.getConnection();
      statement = connection.prepareStatement("UPDATE PERSONAL_BOOKING SET HAS_BOOK_BUS_SEAT = ?, HAS_BOOK_AIR_SEAT = ? WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?");
      statement.setBoolean(1, hasBookBusSeat.booleanValue());
      statement.setBoolean(2, hasBookAirSeat.booleanValue());
      statement.setString(3, bookingId);
      statement.setString(4, travellerId);
      if (statement.executeUpdate() < 1) {
        throw new NoSuchEntityException("Row does not exist");
      }
      statement.close();
      statement = null;
      connection.close();
      connection = null;
    }
    catch(SQLException e) {
      throw new EJBException("Error executing SQL UPDATE PERSONAL_BOOKING SET HAS_BOOK_BUS_SEAT = ?, HAS_BOOK_AIR_SEAT = ? WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?: " + e.toString());
    }
    finally {
      try {
        if (statement != null) {
          statement.close();
        }
      }
      catch(SQLException e) {
      }
      try {
        if (connection != null) {
          connection.close();
        }
      }
      catch(SQLException e) {
      }
    }
  }
  public PersonalBookingPK ejbFindByPrimaryKey(PersonalBookingPK key) throws ObjectNotFoundException {
    Connection connection = null;
    PreparedStatement statement = null;
    try {
      connection = dataSource.getConnection();
      statement = connection.prepareStatement("SELECT BOOKING_ID FROM PERSONAL_BOOKING WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?");
      statement.setString(1, key.bookingId);
      statement.setString(2, key.travellerId);
      ResultSet resultSet = statement.executeQuery();
      if (!resultSet.next()) {
        throw new ObjectNotFoundException("Primary key does not exist");
      }
      statement.close();
      statement = null;
      connection.close();
      connection = null;
      return key;
    }
    catch(SQLException e) {
      throw new EJBException("Error executing SQL SELECT BOOKING_ID FROM PERSONAL_BOOKING WHERE BOOKING_ID = ? AND TRAVELLER_ID = ?: " + e.toString());
    }
    finally {
      try {
        if (statement != null) {
          statement.close();
        }
      }
      catch(SQLException e) {
      }
      try {
        if (connection != null) {
          connection.close();
        }
      }
      catch(SQLException e) {
      }
    }
  }
  public Collection ejbFindAll() {
    Connection connection = null;
    PreparedStatement statement = null;
    try {
      connection = dataSource.getConnection();
      statement = connection.prepareStatement("SELECT BOOKING_ID, TRAVELLER_ID FROM PERSONAL_BOOKING");
      ResultSet resultSet = statement.executeQuery();
      Vector keys = new Vector();
      while (resultSet.next()) {
        String bookingId = resultSet.getString(1);
        String travellerId = resultSet.getString(2);
        keys.addElement(new PersonalBookingPK(bookingId, travellerId));
      }
      statement.close();
      statement = null;
      connection.close();
      connection = null;
      return keys;
    }
    catch(SQLException e) {
      throw new EJBException("Error executing SQL SELECT BOOKING_ID, TRAVELLER_ID FROM PERSONAL_BOOKING: " + e.toString());
    }
    finally {
      try {
        if (statement != null) {
          statement.close();
        }
      }
      catch(SQLException e) {
      }
      try {
        if (connection != null) {
          connection.close();
        }
      }
      catch(SQLException e) {
      }
    }
  }
  public void setEntityContext(EntityContext entityContext) {
    super.setEntityContext(entityContext);
    try {
      javax.naming.Context context = new javax.naming.InitialContext();
      dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
    }
    catch(Exception e) {
      throw new EJBException("Error looking up dataSource:" + e.toString());
    }
  }
}