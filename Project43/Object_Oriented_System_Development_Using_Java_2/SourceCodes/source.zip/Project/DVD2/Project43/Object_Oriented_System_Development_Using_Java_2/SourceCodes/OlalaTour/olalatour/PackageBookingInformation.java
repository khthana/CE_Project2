package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class PackageBookingInformation implements Serializable {

    public PackageBookingInformation(String packageID, java.sql.Timestamp departTIme, String travellerID) {
	this.packageID = packageID;
	this.departTIme = departTIme;
	this.travellerID = travellerID;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPackageID() {
	return packageID;
    }
    public java.sql.Timestamp getDepartTIme() {
	return departTIme;
    }
    public String getTravellerID() {
	return travellerID;
    }
    private String packageID;
    private java.sql.Timestamp departTIme;
    private String travellerID;
}