package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PersonalBookingPK implements Serializable {

  public PersonalBookingPK(String travellerId, String bookingId) {
	this.travellerId = travellerId;
	this.bookingId = bookingId;
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
  }
  public String getBookingId() {
	return bookingId;
  }
  public String getTravellerId() {
	return travellerId;
  }
  public String bookingId;
  public String travellerId;
}