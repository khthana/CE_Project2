package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public interface PackageBookingHome extends EJBHome {
  public PackageBookingRemote create(String travellerId, String packageId, Timestamp departTime, String bookingId) throws RemoteException, CreateException;
  public PackageBookingRemote findByPrimaryKey(PackageBookingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}