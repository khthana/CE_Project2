package restaurantsystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.sql.Date;

public class BookingTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private BookingHome bookingHome = null;
  private BookingRemote bookingRemote = null;

  /**Construct the EJB test client*/
  public BookingTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("Booking");

      //cast to Home interface
      bookingHome = (BookingHome) PortableRemoteObject.narrow(ref, BookingHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public BookingRemote create(String bookingID, String restaurantID, int meal, Date dateTime, int noOfReserveSeat, String agencyID) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      bookingRemote = bookingHome.create(bookingID, restaurantID, meal, dateTime, noOfReserveSeat, agencyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + "): " + bookingRemote + ".");
    }
    return bookingRemote;
  }

  public BookingRemote findByPrimaryKey(String primKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      bookingRemote = bookingHome.findByPrimaryKey(primKey);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: findByPrimaryKey(" + primKey + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: findByPrimaryKey(" + primKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primKey + "): " + bookingRemote + ".");
    }
    return bookingRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getAgencyID() {
    String returnValue = "";
    if (bookingRemote == null) {
      System.out.println("Error in getAgencyID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAgencyID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getAgencyID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getAgencyID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getAgencyID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAgencyID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public int getNoOfReserveSeat() {
    int returnValue = 0;
    if (bookingRemote == null) {
      System.out.println("Error in getNoOfReserveSeat(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getNoOfReserveSeat()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getNoOfReserveSeat();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getNoOfReserveSeat()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getNoOfReserveSeat()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getNoOfReserveSeat(): " + returnValue + ".");
    }
    return returnValue;
  }

  public int getConfirmation() {
    int returnValue = 0;
    if (bookingRemote == null) {
      System.out.println("Error in getConfirmation(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getConfirmation()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getConfirmation();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getConfirmation()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getConfirmation()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getConfirmation(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getBookingID() {
    String returnValue = "";
    if (bookingRemote == null) {
      System.out.println("Error in getBookingID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getBookingID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getBookingID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getBookingID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getBookingID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getBookingID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public int getMeal() {
    int returnValue = 0;
    if (bookingRemote == null) {
      System.out.println("Error in getMeal(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getMeal()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getMeal();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getMeal()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getMeal()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getMeal(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getRestaurantID() {
    String returnValue = "";
    if (bookingRemote == null) {
      System.out.println("Error in getRestaurantID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getRestaurantID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getRestaurantID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getRestaurantID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getRestaurantID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getRestaurantID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void confirm() {
    if (bookingRemote == null) {
      System.out.println("Error in confirm(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling confirm()");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingRemote.confirm();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: confirm()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: confirm()");
      }
      e.printStackTrace();
    }
  }

  public void cancel() {
    if (bookingRemote == null) {
      System.out.println("Error in cancel(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling cancel()");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingRemote.cancel();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: cancel()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: cancel()");
      }
      e.printStackTrace();
    }
  }

  public void modify(String restaurantID, int meal, Date dateTime, int noOfReserveSeat, String agencyID) {
    if (bookingRemote == null) {
      System.out.println("Error in modify(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling modify(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bookingRemote.modify(restaurantID, meal, dateTime, noOfReserveSeat, agencyID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: modify(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: modify(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
      }
      e.printStackTrace();
    }
  }

  public Date getDateTime() {
    Date returnValue = null;
    if (bookingRemote == null) {
      System.out.println("Error in getDateTime(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getDateTime()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingRemote.getDateTime();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: getDateTime()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: getDateTime()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getDateTime(): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    BookingTestClient1 client = new BookingTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    java.sql.Date date = java.sql.Date.valueOf("2001-04-17");
    client.create("123","456",7,date,8,"910");
    client.getMeal();
  }
}