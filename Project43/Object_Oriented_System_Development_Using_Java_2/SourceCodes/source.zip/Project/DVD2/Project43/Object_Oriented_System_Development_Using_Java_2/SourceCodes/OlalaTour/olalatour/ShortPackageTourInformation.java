package olalatour;

import java.io.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortPackageTourInformation implements Serializable {

    public ShortPackageTourInformation(String packageName, String packageID, String description, double totalPrice) {
	this.packageID = packageID;
	this.packageName = packageName;
	this.description = description;
	this.totalPrice = totalPrice;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPackageID() {
	return packageID;
    }
    public String getPackageName() {
	return packageName;
    }
    public String getDescription() {
	return description;
    }
    public double getTotalPrice() {
	return totalPrice;
    }
    private String packageName;
    private String packageID;
    private String description;
    private double totalPrice;
}