package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PackageBookingBMP extends PackageBooking {
  DataSource dataSource;
  public PackageBookingPK ejbCreate(String travellerId, String packageId, Timestamp departTime, String bookingId) throws CreateException {
	super.ejbCreate(travellerId, packageId, departTime, bookingId);
	try {
	  //First see if the object already exists
	  ejbFindByPrimaryKey(new olalatour.PackageBookingPK(travellerId, packageId, departTime, bookingId));
	  //If so, then we have to throw an exception
	  throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	  //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("INSERT INTO PACKAGE_BOOKING (TRAVELLER_ID, PACKAGE_ID, DEPART_TIME, BOOKING_ID) VALUES (?, ?, ?, ?)");
	  statement.setString(1, travellerId);
	  statement.setString(2, packageId);
	  statement.setTimestamp(3, departTime);
	  statement.setString(4, bookingId);
	  if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	  return new PackageBookingPK(travellerId, packageId, departTime, bookingId);
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL INSERT INTO PACKAGE_BOOKING (TRAVELLER_ID, PACKAGE_ID, DEPART_TIME, BOOKING_ID) VALUES (?, ?, ?, ?): " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("DELETE FROM PACKAGE_BOOKING WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?");
	  statement.setString(1, travellerId);
	  statement.setString(2, packageId);
	  statement.setTimestamp(3, departTime);
	  statement.setString(4, bookingId);
	  if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL DELETE FROM PACKAGE_BOOKING WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public void ejbLoad() {
	PackageBookingPK key = (PackageBookingPK) entityContext.getPrimaryKey();
	travellerId = key.travellerId;
	packageId = key.packageId;
	departTime = key.departTime;
	bookingId = key.bookingId;
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("SELECT  FROM PACKAGE_BOOKING WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?");
	  statement.setString(1, travellerId);
	  statement.setString(2, packageId);
	  statement.setTimestamp(3, departTime);
	  statement.setString(4, bookingId);
	  ResultSet resultSet = statement.executeQuery();
	  if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL SELECT  FROM PACKAGE_BOOKING WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
	super.ejbLoad();
  }
  public void ejbStore() {
	super.ejbStore();
//    Connection connection = null;
//    PreparedStatement statement = null;
//    try {
//      connection = dataSource.getConnection();
//      statement = connection.prepareStatement("UPDATE PACKAGE_BOOKING SET  WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?");
//      statement.setString(1, travellerId);
//      statement.setString(2, packageId);
//      statement.setTimestamp(3, departTime);
//      statement.setString(4, bookingId);
//      if (statement.executeUpdate() < 1) {
//        throw new NoSuchEntityException("Row does not exist");
//      }
//      statement.close();
//      statement = null;
//      connection.close();
//      connection = null;
//    }
//    catch(SQLException e) {
//      throw new EJBException("Error executing SQL UPDATE PACKAGE_BOOKING SET  WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?: " + e.toString());
//    }
//    finally {
//      try {
//        if (statement != null) {
//          statement.close();
//        }
//      }
//      catch(SQLException e) {
//      }
//      try {
//        if (connection != null) {
//          connection.close();
//        }
//      }
//      catch(SQLException e) {
//      }
//    }
  }
  public PackageBookingPK ejbFindByPrimaryKey(PackageBookingPK key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("SELECT TRAVELLER_ID FROM PACKAGE_BOOKING WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?");
	  statement.setString(1, key.travellerId);
	  statement.setString(2, key.packageId);
	  statement.setTimestamp(3, key.departTime);
	  statement.setString(4, key.bookingId);
	  ResultSet resultSet = statement.executeQuery();
	  if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	  return key;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL SELECT TRAVELLER_ID FROM PACKAGE_BOOKING WHERE TRAVELLER_ID = ? AND PACKAGE_ID = ? AND DEPART_TIME = ? AND BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("SELECT TRAVELLER_ID, PACKAGE_ID, DEPART_TIME, BOOKING_ID FROM PACKAGE_BOOKING");
	  ResultSet resultSet = statement.executeQuery();
	  Vector keys = new Vector();
	  while (resultSet.next()) {
		String travellerId = resultSet.getString(1);
		String packageId = resultSet.getString(2);
		Timestamp departTime = resultSet.getTimestamp(3);
		String bookingId = resultSet.getString(4);
		keys.addElement(new PackageBookingPK(travellerId, packageId, departTime, bookingId));
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	  return keys;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL SELECT TRAVELLER_ID, PACKAGE_ID, DEPART_TIME, BOOKING_ID FROM PACKAGE_BOOKING: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	  javax.naming.Context context = new javax.naming.InitialContext();
	  dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	  throw new EJBException("Error looking up dataSource:" + e.toString());
	}
  }
}