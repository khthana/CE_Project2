package banksystem;


import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

public class Bank_Transaction implements EntityBean {
  EntityContext entityContext;
  public String transactionID;
  public String accountID;
  public String relateAccountID;
  public int transactionType; // 0 = TRANSFER,1 = PAYBYDEBITCARD, 2 = PAYBYCREDITCARD
  public double money;
  public java.sql.Timestamp txDate;

  private Connection con;
  private String dbName = "java:comp/env/jdbc/BankDB";

  // @@@@@@@@@@@@@@@@@@@ Business methood  @@@@@@@@@@@@@@@@@@@@@@@

  public String getTransactionID() {
	return transactionID;
  }
  public void setAccountID(String newAccountID) {
	accountID = newAccountID;
  }
  public String getAccountID() {
	return accountID;
  }
  public void setRelateAccountID(String newRelateAccountID) {
	relateAccountID = newRelateAccountID;
  }
  public void setTransactionType(int newTransactionType) {
	transactionType = newTransactionType;
  }
  public int getTransactionType() {
	return transactionType;
  }
  public void setMoney(double newMoney) {
	money = newMoney;
  }
  public double getMoney() {
	return money;
  }
  public void setTxDate(java.sql.Timestamp newTxDate) {
	txDate = newTxDate;
  }
  public java.sql.Timestamp getTxDate() {
	return txDate;
  }

  public void setTransactionID(String newTransactionID) {
	transactionID = newTransactionID;
  }

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Require Method @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  public String ejbCreate(String transactionID, String accountID, String relateAccountID, int transactionType, double money, java.sql.Timestamp txDate) throws CreateException {

	 System.out.println("ejbCreate");
	  try {
		insertRow(transactionID,accountID,relateAccountID,transactionType,money,txDate);
	  } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
		  ex.getMessage());
	  }

	this.transactionID = transactionID;
	this.accountID = accountID;
	this.relateAccountID = relateAccountID;
	this.transactionType = transactionType;
	this.money = money;
	this.txDate = txDate;

	  System.out.println("end ejbCreate");

	  return transactionID;
  }

 public void ejbPostCreate(String transactionID, String accountID, String relateAccountID, int transactionType, double money, java.sql.Timestamp txDate) throws CreateException {
  }

 public void ejbRemove() throws RemoveException {
	System.out.println("ejbRomove");
	  try {
	 deleteRow(transactionID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbRomove");
  }

public String ejbFindByPrimaryKey(String primKey) throws FinderException {
	  System.out.println("ejbFindByPrimaryKey");

	  boolean result;

	  try {
	 result = selectByPrimaryKey(primKey);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
		  ex.getMessage());
	   }
	  if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
	  }
	  else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
		("Row for id " + primKey + " not found.");
	  }

  }

 public Collection ejbFindByAccountID(String accountID) throws RemoteException, FinderException {
	  Collection result;

	  try {
	 result = selectByAccountID(accountID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByAccountID " +
		  ex.getMessage());
	   }

	  if (result.isEmpty()) {
	 throw new ObjectNotFoundException("No rows found.");
	  }
	  else {
	 return result;
	  }
  }

  public void ejbActivate() {
	System.out.println("ejbActivate");
	transactionID = (String)entityContext.getPrimaryKey();
	System.out.println("end ejbActivate");
  }

  public void ejbPassivate() {
	System.out.println("ejbPassivate Transaction");
	transactionID = null;
	System.out.println("end ejbPassivate Transaction");
  }

  public void ejbLoad() {
	System.out.println("ejbLoad");
	  try {
	 loadRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
		  ex.getMessage());
	   }
	  System.out.println("end ejbLoad");
  }

  public void ejbStore() {
	System.out.println("ejbStore");
	  try {
	 storeRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbStore: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbStore");
  }

  public void setEntityContext(EntityContext entityContext) {
	System.out.println("setEntityContext 1");
	this.entityContext = entityContext;

	try {
	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup(dbName);
	  con =  ds.getConnection();
	}
	catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
		 ex.getMessage());
	}
	System.out.println("end setEntityContext");
  }

  public void unsetEntityContext() {
	System.out.println("unsetEntityContext");
	entityContext = null;
	  try {
	 con.close();
	  } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
	  }
	System.out.println("end unsetEntityContext");
  }

//****************************************** Database Routines ******************************************

   private void insertRow (String transactionID, String accountID,String relateAccountID,int transactionType, double money, java.sql.Timestamp txDate) throws SQLException {

   System.out.println("****insert table***** ");
	  String insertStatement =
		"insert into BANK_TRANSACTION values ( ? , ? , ? , ?, ?, ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, transactionID);
	  prepStmt.setString(2, accountID);
	  prepStmt.setString(3, relateAccountID);
	  prepStmt.setInt(4, transactionType);
	  prepStmt.setDouble(5, money);
	  prepStmt.setTimestamp(6, txDate);

	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String id) throws SQLException {

	  String deleteStatement =
		"delete from BANK_TRANSACTION where TRANSACTIONID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(deleteStatement);

	  prepStmt.setString(1, id);
	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
	  throws SQLException {
	  String selectStatement =
		"select TRANSACTIONID " +
		"from BANK_TRANSACTION where TRANSACTIONID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);
	  prepStmt.setString(1, primaryKey);

	  ResultSet rs = prepStmt.executeQuery();
	  boolean result = rs.next();
	  prepStmt.close();
	  return result;
   }


   private Collection selectByAccountID(String accountID)
	  throws SQLException {

	  String selectStatement =
		"select TRANSACTIONID " +
		"from BANK_TRANSACTION where ACCOUNTID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, accountID);


	  ResultSet rs = prepStmt.executeQuery();
	  ArrayList a = new ArrayList();

	  while (rs.next()) {
	 String id = rs.getString(1);
	 a.add(id);
	  }

	  prepStmt.close();
	  return a;
   }

   private void loadRow() throws SQLException {

	  String selectStatement =
		"select  ACCOUNTID, RELATEACCOUNTID, TRANSACTIONTYPE, MONEY, TXDATE " +
		"from BANK_TRANSACTION where TRANSACTIONID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, this.transactionID);

	  ResultSet rs = prepStmt.executeQuery();

	  if (rs.next()) {

	 this.accountID = rs.getString(1);
	 this.relateAccountID = rs.getString(2);
	 this.transactionType = rs.getInt(3);
	 this.money = rs.getDouble(4);
	 this.txDate = rs.getTimestamp(5);

	 prepStmt.close();
	  }
	  else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + accountID +
		" not found in database.");
	  }
   }


   private void storeRow() throws SQLException {

	  String updateStatement =
		"update BANK_TRANSACTION set " +
		"ACCOUNTID =  ? , " +
		"RELATEACCOUNTID = ? , " +
		"TRANSACTIONTYPE = ? , " +
		"MONEY = ? , "+
		"TXDATE = ? " +
		"where TRANSACTIONID = ?";
	  PreparedStatement prepStmt =
		con.prepareStatement(updateStatement);

	  prepStmt.setString(1, accountID);
	  prepStmt.setString(2, relateAccountID);
	  prepStmt.setInt(3, transactionType);
	  prepStmt.setDouble(4, money);
	  prepStmt.setTimestamp(5, txDate);

	  prepStmt.setString(6, transactionID);

	  int rowCount = prepStmt.executeUpdate();
	  prepStmt.close();

	  if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + accountID + " failed.");
	  }
   }
  public String getRelateAccountID() {
	return relateAccountID;
  }

}