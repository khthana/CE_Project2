package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class PackageTour implements EntityBean {
    EntityContext entityContext;
    public String packageId;
    public String packageName;
    public String description;
    public Double totalPrice;
    public String image;
    public Integer duration;
    public String busGroupBookingId;
    public String hotelGroupBookingId;
    public String aircraftGroupBookingId;
    public String restaurantGroupBookingId;
    public Timestamp createTime;
    public String adminId;
    public Integer confirm;
    public String ejbCreate(String packageId, String packageName, String description, Double totalPrice, String image, Integer duration, String busGroupBookingId, String hotelGroupBookingId, String aircraftGroupBookingId, String restaurantGroupBookingId, Timestamp createTime, String adminId, Integer confirm) throws CreateException {
	this.packageId = packageId;
	this.packageName = packageName;
	this.description = description;
	this.totalPrice = totalPrice;
	this.image = image;
	this.duration = duration;
	this.busGroupBookingId = busGroupBookingId;
	this.hotelGroupBookingId = hotelGroupBookingId;
	this.aircraftGroupBookingId = aircraftGroupBookingId;
	this.restaurantGroupBookingId = restaurantGroupBookingId;
	this.createTime = createTime;
	this.adminId = adminId;
	this.confirm = confirm;
	return null;
    }
    public String ejbCreate(String packageId) throws CreateException {
	return ejbCreate(packageId, null, null, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbPostCreate(String packageId, String packageName, String description, Double totalPrice, String image, Integer duration, String busGroupBookingId, String hotelGroupBookingId, String aircraftGroupBookingId, String restaurantGroupBookingId, Timestamp createTime, String adminId, Integer confirm) throws CreateException {
    }
    public void ejbPostCreate(String packageId) throws CreateException {
	ejbPostCreate(packageId, null, null, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getPackageId() {
	return packageId;
    }
    public String getPackageName() {
	return packageName;
    }
    public void setPackageName(String packageName) {
	this.packageName = packageName;
    }
    public String getDescription() {
	return description;
    }
    public void setDescription(String description) {
	this.description = description;
    }
    public Double getTotalPrice() {
	return totalPrice;
    }
    public void setTotalPrice(Double totalPrice) {
	this.totalPrice = totalPrice;
    }
    public String getImage() {
	return image;
    }
    public void setImage(String image) {
	this.image = image;
    }
    public Integer getDuration() {
	return duration;
    }
    public void setDuration(Integer duration) {
	this.duration = duration;
    }
    public String getBusGroupBookingId() {
	return busGroupBookingId;
    }
    public void setBusGroupBookingId(String busGroupBookingId) {
	this.busGroupBookingId = busGroupBookingId;
    }
    public String getHotelGroupBookingId() {
	return hotelGroupBookingId;
    }
    public void setHotelGroupBookingId(String hotelGroupBookingId) {
	this.hotelGroupBookingId = hotelGroupBookingId;
    }
    public String getAircraftGroupBookingId() {
	return aircraftGroupBookingId;
    }
    public void setAircraftGroupBookingId(String aircraftGroupBookingId) {
	this.aircraftGroupBookingId = aircraftGroupBookingId;
    }
    public String getRestaurantGroupBookingId() {
	return restaurantGroupBookingId;
    }
    public void setRestaurantGroupBookingId(String restaurantGroupBookingId) {
	this.restaurantGroupBookingId = restaurantGroupBookingId;
    }
    public Timestamp getCreateTime() {
	return createTime;
    }
    public void setCreateTime(Timestamp createTime) {
	this.createTime = createTime;
    }
    public String getAdminId() {
	return adminId;
    }
    public void setAdminId(String adminId) {
	this.adminId = adminId;
    }
    public Integer getConfirm() {
	return confirm;
    }
    public void setConfirm(Integer confirm) {
	this.confirm = confirm;
    }
}