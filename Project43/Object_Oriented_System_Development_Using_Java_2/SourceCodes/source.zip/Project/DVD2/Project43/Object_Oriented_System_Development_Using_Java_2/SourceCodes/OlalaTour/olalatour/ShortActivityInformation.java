package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortActivityInformation implements Serializable {

    public ShortActivityInformation(String activityID, String activityName) {
	this.activityID = activityID;
	this.activityName = activityName;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getActivityID() {
	return activityID;
    }
    public String getActivityName() {
	return activityName;
    }
    private String activityID;
    private String activityName;
}