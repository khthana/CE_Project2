package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class PlaceBMP extends Place {
    DataSource dataSource;
    public String ejbCreate(String placeId, String placeName, String country, String state, String province, String description, String imagefilePath) throws CreateException {
	super.ejbCreate(placeId, placeName, country, state, province, description, imagefilePath);
	try {
	    //First see if the object already exists
	    ejbFindByPrimaryKey(placeId);
	    //If so, then we have to throw an exception
	    throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	    //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("INSERT INTO PLACE (PLACE_ID, PLACE_NAME, COUNTRY, STATE, PROVINCE, DESCRIPTION, IMAGEFILE_PATH) VALUES (?, ?, ?, ?, ?, ?, ?)");
	    statement.setString(1, placeId);
	    statement.setString(2, placeName);
	    statement.setString(3, country);
	    statement.setString(4, state);
	    statement.setString(5, province);
	    statement.setString(6, description);
	    statement.setString(7, imagefilePath);
	    if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return placeId;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL INSERT INTO PLACE (PLACE_ID, PLACE_NAME, COUNTRY, STATE, PROVINCE, DESCRIPTION, IMAGEFILE_PATH) VALUES (?, ?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbCreate(String placeId) throws CreateException {
	return ejbCreate(placeId, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("DELETE FROM PLACE WHERE PLACE_ID = ?");
	    statement.setString(1, placeId);
	    if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL DELETE FROM PLACE WHERE PLACE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void ejbLoad() {
	placeId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT PLACE_NAME, COUNTRY, STATE, PROVINCE, DESCRIPTION, IMAGEFILE_PATH FROM PLACE WHERE PLACE_ID = ?");
	    statement.setString(1, placeId);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    placeName = resultSet.getString(1);
	    country = resultSet.getString(2);
	    state = resultSet.getString(3);
	    province = resultSet.getString(4);
	    description = resultSet.getString(5);
	    imagefilePath = resultSet.getString(6);
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_NAME, COUNTRY, STATE, PROVINCE, DESCRIPTION, IMAGEFILE_PATH FROM PLACE WHERE PLACE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
	super.ejbLoad();
    }
    public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("UPDATE PLACE SET PLACE_NAME = ?, COUNTRY = ?, STATE = ?, PROVINCE = ?, DESCRIPTION = ?, IMAGEFILE_PATH = ? WHERE PLACE_ID = ?");
	    statement.setString(1, placeName);
	    statement.setString(2, country);
	    statement.setString(3, state);
	    statement.setString(4, province);
	    statement.setString(5, description);
	    statement.setString(6, imagefilePath);
	    statement.setString(7, placeId);
	    if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL UPDATE PLACE SET PLACE_NAME = ?, COUNTRY = ?, STATE = ?, PROVINCE = ?, DESCRIPTION = ?, IMAGEFILE_PATH = ? WHERE PLACE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT PLACE_ID FROM PLACE WHERE PLACE_ID = ?");
	    statement.setString(1, key);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return key;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE WHERE PLACE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT PLACE_ID FROM PLACE");
	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindByPlaceNameCountryStateProvinceDescription(String placeName, String country, String state, String province, String description) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT PLACE_ID FROM PLACE WHERE PLACE_NAME LIKE ? AND COUNTRY LIKE ? AND STATE LIKE ? AND PROVINCE LIKE ? AND DESCRIPTION LIKE ? ");
	    statement.setString(1, "%" + placeName + "%");
	    statement.setString(2, "%" + country + "%");
	    statement.setString(3, "%" + state + "%");
	    statement.setString(4, "%" + province + "%");
	    statement.setString(5, "%" + description + "%");

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }

    public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	    javax.naming.Context context = new javax.naming.InitialContext();
	    dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	    throw new EJBException("Error looking up dataSource:" + e.toString());
	}
    }
    public Collection getCategories() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT DISTINCT CATEGORY_ID FROM PLACE_CATEGORY WHERE PLACE_ID = ? ");
	    statement.setString(1, placeId);

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection getActivities() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT DISTINCT ACTIVITY_ID FROM PLACE_ACTIVITY WHERE PLACE_ID = ? ");
	    statement.setString(1, placeId);

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection getFestivals() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT DISTINCT FESTIVAL_ID FROM PLACE_FESTIVAL WHERE PLACE_ID = ? ");
	    statement.setString(1, placeId);

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection getPackageTours() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT DISTINCT PACKAGE_ID FROM PACKAGE_PLACE WHERE PLACE_ID = ? ");
	    statement.setString(1, placeId);

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
}