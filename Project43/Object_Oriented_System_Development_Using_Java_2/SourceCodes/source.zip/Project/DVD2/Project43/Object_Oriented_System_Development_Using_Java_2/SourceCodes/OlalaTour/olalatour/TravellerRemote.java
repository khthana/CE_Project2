package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface TravellerRemote extends EJBObject {
    String getTravellerId() throws RemoteException;
    String getFirstName() throws RemoteException;
    void setFirstName(String firstName) throws RemoteException;
    String getLastName() throws RemoteException;
    void setLastName(String lastName) throws RemoteException;
    String getAddress() throws RemoteException;
    void setAddress(String address) throws RemoteException;
    String getTelephoneNo() throws RemoteException;
    void setTelephoneNo(String telephoneNo) throws RemoteException;
    String getEmailAddress() throws RemoteException;
    void setEmailAddress(String emailAddress) throws RemoteException;
    Integer getGender() throws RemoteException;
    void setGender(Integer gender) throws RemoteException;
    Date getBirthDate() throws RemoteException;
    void setBirthDate(Date birthDate) throws RemoteException;
    String getReligion() throws RemoteException;
    void setReligion(String religion) throws RemoteException;
    String getBusCompanyCustomerId() throws RemoteException;
    void setBusCompanyCustomerId(String busCompanyCustomerId) throws RemoteException;
    String getAirlineCustomerId() throws RemoteException;
    void setAirlineCustomerId(String airlineCustomerId) throws RemoteException;
    String getFoodTypeId() throws RemoteException;
    void setFoodTypeId(String foodTypeId) throws RemoteException;
}