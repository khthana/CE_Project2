package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface TravellerHome extends EJBHome {
    public TravellerRemote create(String travellerId, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String busCompanyCustomerId, String airlineCustomerId, String foodTypeId) throws RemoteException, CreateException;
    public TravellerRemote create(String travellerId) throws RemoteException, CreateException;
    public TravellerRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
}