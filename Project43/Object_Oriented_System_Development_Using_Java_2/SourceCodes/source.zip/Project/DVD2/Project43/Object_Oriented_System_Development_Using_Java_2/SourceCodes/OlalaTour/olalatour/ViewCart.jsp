<HTML>
<HEAD>
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" /><TITLE>
ViewCart
</TITLE>
</HEAD>
<BODY>
<%@ include file="header.jsp" %>
<%
  String remove = request.getParameter("remove");
  if (remove != null) {
    controllerBean.removeItem(remove, Integer.parseInt(request.getParameter("item")));
  }
%>
<H1>
<a href="Jsp1.jsp">jsp1</a>
</H1>
airline item
<table border=1 width=750>
<%int i =0;%>
<%    while(controllerBean.nextAirlineItem()) {%>
    <tr>
	<td>
	    CustomerID : <%=controllerBean.getCustomerID()%>
	</td>
	<td>
	    FlightID : <%=controllerBean.getFlightID()%>
	</td>
	<td>
	    SeatType : <%=controllerBean.getSeatType()%>
	</td>
	<td>
	    DepartTime : <%=controllerBean.getDepartTIme()%>
	</td>
	<td>
	    CanSmoking : <%=controllerBean.getCanSmoking()%>
	</td>
	<td>
	    Price : <%=controllerBean.getPrice()%>
	</td>
	<td>
	    <a href="ViewCart.jsp?remove=airline&item=<%=i++%>">remove</a>
	</td>
    </tr>
<%    }%>
</table>
<hr>
bus item
<table border=1 width=750>
<%
i =0;
    while(controllerBean.nextBusItem()) {%>
    <tr>
	<td>
	    CustomerID : <%=controllerBean.getCustomerID()%>
	</td>
	<td>
	    RouteID : <%=controllerBean.getRouteID()%>
	</td>
	<td>
	    SeatType : <%=controllerBean.getSeatType()%>
	</td>
	<td>
	    DepartTime : <%=controllerBean.getDepartTIme()%>
	</td>
	<td>
	    Price : <%=controllerBean.getPrice()%>
	</td>
	<td>
	    <a href="ViewCart.jsp?remove=bus&item=<%=i++%>">remove</a>
	</td>
    </tr>
<%    }%>
</table>
<hr>
Hotel item
<table border=1 width=750>
<%
i =0;    while(controllerBean.nextHotelItem()) {%>
    <tr>
	<td>
	    HotelID : <%=controllerBean.getHotelID()%>
	</td>
	<td>
	    Description : <%=controllerBean.getDescription()%>
	</td>
	<td>
	    RoomClass : <%=controllerBean.getRoomClass()%>
	</td>
	<td>
	    NumberOfRoom : <%=controllerBean.getNumberOfRoom()%>
	</td>
	<td>
	    PricePerDay : <%=controllerBean.getPricePerDay()%>
	</td>
	<td>
	    <a href="ViewCart.jsp?remove=hotel&item=<%=i++%>">remove</a>
	</td>
    </tr>
<%    }%>
</table>
<hr>
Package item
<table border=1 width=750>
<%
i =0;
    while(controllerBean.nextPackageItem()) {%>
    <tr>
	<td>
	    PackageID : <%=controllerBean.getPackageID()%>
	</td>
	<td>
	    DepartTime : <%=controllerBean.getDepartTIme()%>
	</td>
	<td>
	    TravellerID : <%=controllerBean.getTravellerID()%>
	</td>
	<td>
	    <a href="ViewCart.jsp?remove=package&item=<%=i++%>">remove</a>
	</td>
    </tr>
<%    }%>
</table>

<br>
<form name="form1" action="Reserve.jsp" >
  <input type="submit" name="submit" value="reserve">
</form>
</BODY>
</HTML>
