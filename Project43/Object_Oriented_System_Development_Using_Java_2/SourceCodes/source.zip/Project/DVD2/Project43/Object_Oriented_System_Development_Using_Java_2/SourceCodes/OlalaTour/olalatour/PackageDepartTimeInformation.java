package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class PackageDepartTimeInformation implements Serializable {

    public PackageDepartTimeInformation(String packageID, java.sql.Timestamp departTime, java.sql.Timestamp arriveTime, String guideID) {
	this.packageID = packageID;
	this.departTime = departTime;
	this.arriveTime = arriveTime;
	this.guideID = guideID;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPackageID() {
	return packageID;
    }
    public java.sql.Timestamp getDepartTime() {
	return departTime;
    }
    public java.sql.Timestamp getArriveTime() {
	return arriveTime;
    }
    public String getGuideID() {
	return guideID;
    }
    private String packageID;
    private java.sql.Timestamp departTime;
    private java.sql.Timestamp arriveTime;
    private String guideID;
}