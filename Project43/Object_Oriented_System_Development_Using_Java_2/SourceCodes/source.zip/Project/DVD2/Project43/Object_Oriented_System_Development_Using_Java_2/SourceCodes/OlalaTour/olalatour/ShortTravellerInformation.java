package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortTravellerInformation implements Serializable {

    public ShortTravellerInformation(String travellerID, String firstName, String lastName) {
	this.travellerID = travellerID;
	this.firstName = firstName;
	this.lastName = lastName;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getTravellerID() {
	return travellerID;
    }
    public String getFirstName() {
	return firstName;
    }
    public String getLastName() {
	return lastName;
    }
    private String travellerID;
    private String firstName;
    private String lastName;
}