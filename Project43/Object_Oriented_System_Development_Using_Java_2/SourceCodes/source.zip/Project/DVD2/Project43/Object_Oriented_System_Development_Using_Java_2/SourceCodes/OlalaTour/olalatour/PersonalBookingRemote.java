package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public interface PersonalBookingRemote extends EJBObject {
  String getBookingId() throws RemoteException;
  String getTravellerId() throws RemoteException;
  Boolean getHasBookBusSeat() throws RemoteException;
  void setHasBookBusSeat(Boolean hasBookBusSeat) throws RemoteException;
  Boolean getHasBookAirSeat() throws RemoteException;
  void setHasBookAirSeat(Boolean hasBookAirSeat) throws RemoteException;
}