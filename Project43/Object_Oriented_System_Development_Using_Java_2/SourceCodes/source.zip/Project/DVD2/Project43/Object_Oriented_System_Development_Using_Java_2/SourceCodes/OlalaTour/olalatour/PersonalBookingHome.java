package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public interface PersonalBookingHome extends EJBHome {
  public PersonalBookingRemote create(String bookingId, String travellerId, Boolean hasBookBusSeat, Boolean hasBookAirSeat) throws RemoteException, CreateException;
  public PersonalBookingRemote create(String bookingId, String travellerId) throws RemoteException, CreateException;
  public PersonalBookingRemote findByPrimaryKey(PersonalBookingPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}