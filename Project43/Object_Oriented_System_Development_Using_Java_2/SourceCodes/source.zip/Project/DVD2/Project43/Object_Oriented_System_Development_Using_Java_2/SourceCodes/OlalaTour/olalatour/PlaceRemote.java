package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface PlaceRemote extends EJBObject {
    String getPlaceId() throws RemoteException;
    String getPlaceName() throws RemoteException;
    void setPlaceName(String placeName) throws RemoteException;
    String getCountry() throws RemoteException;
    void setCountry(String country) throws RemoteException;
    String getState() throws RemoteException;
    void setState(String state) throws RemoteException;
    String getProvince() throws RemoteException;
    void setProvince(String province) throws RemoteException;
    String getDescription() throws RemoteException;
    void setDescription(String description) throws RemoteException;
    String getImagefilePath() throws RemoteException;
    void setImagefilePath(String imagefilePath) throws RemoteException;
    Collection getCategories() throws RemoteException;
    Collection getActivities() throws RemoteException;
    Collection getFestivals() throws RemoteException;
    Collection getPackageTours() throws RemoteException;
}