package banksystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

//import oracle.jdbc.driver.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

 public class Account implements EntityBean {
  EntityContext entityContext;

  public String accountID;  //PK
  public String accountName;
  public String password;
  public double balance;
  public String creditCardID;
  public String debitCardID;
  public double credit;

  public Connection con;
  private String dbName = "java:comp/env/jdbc/BankDB";

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ BUSINESS METHOD @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  public void setAccountName(String newAccountName) throws RemoteException {
	accountName = newAccountName;
  }
  public void setPassword (String oldPassword, String newPassword) throws RemoteException {
	password = newPassword;
  }
  public String getAccountName() throws RemoteException {
	return accountName;
  }
  public double getBalance () throws RemoteException{
	return balance;
  }
  public String getAccountID() throws RemoteException{
	return accountID;
  }

  public double getCredit() throws RemoteException{
	return credit;
	}
  public String getCreditCardID() throws RemoteException{
	return creditCardID;
  }
  public String getDebitCardID() throws RemoteException{
	return debitCardID;
  }

  public String getPassword() throws RemoteException {
	return password;
  }


  public void deposit (double amount) throws  RemoteException {

	balance += amount;

  }

  public void withdraw (double amount) throws  RemoteException{

	if (balance - amount < 0) {
	   throw new RemoteException("Your balance is " + balance+ " You cannot withdraw "+amount+"!");
	   }
	   balance -= amount;
  }

  public void withdrawBycredit (double amount) throws  RemoteException{

  if (credit - amount < 0) { // if credit < amount
	   throw new RemoteException("Your credit is " + credit+ " You cannot withdraw "+amount+"!");
	   }
	 credit -= amount;
 }

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Require Method @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  public String ejbCreate( String accountID, String accountName,double credit,double balance, String password, String creditCardID, String debitCardID) throws CreateException , RemoteException {


	  System.out.println("ejbCreate");

	  if (balance < 0.00) {
	  throw new CreateException ("A negative initial balance is not allowed.");
	   }

	  try {
	 insertRow(accountID,accountName,credit,balance,password,creditCardID,debitCardID);
	  } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
		  ex.getMessage());
	  }
	this.accountID = accountID;
	this.balance = balance;
	this.accountName = accountName;
	this.credit = credit;
	this.password = password;
	this.creditCardID = creditCardID;
	this.debitCardID = debitCardID;

	  System.out.println("end ejbCreate");
	 System.out.println(accountID);

	  return this.accountID;


  }

  public void ejbPostCreate(String accoutID, String accountName,double credit,double balance, String password, String creditCardID, String debitCardID)  throws RemoteException {
  }

  public void ejbRemove() throws RemoveException {
	System.out.println("ejbRomove");
	  try {
	 deleteRow(accountID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbRomove");
  }

  public String ejbFindByPrimaryKey(String primKey) throws FinderException {
	  System.out.println("ejbFindByPrimaryKey");

	  boolean result;

	  try {
	 result = selectByPrimaryKey(primKey);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
		  ex.getMessage());
	   }
	  if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
	  }
	  else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
		("Row for id " + primKey + " not found.");
	  }

  }

	public Collection ejbFindByCreditCardID(String creditCardID) throws RemoteException, FinderException {
	  Collection result;

	  try {
	 result = selectByCreditCardID(creditCardID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByCreditCardID " +
		  ex.getMessage());
	   }

	  if (result.isEmpty()) {
	 throw new ObjectNotFoundException("No rows found.");
	  }
	  else {
	 return result;
	  }
  }

   public Collection ejbFindByDebitCardID(String debitCardID) throws RemoteException, FinderException {
	  Collection result;

	  try {
	 result = selectByDebitCardID(debitCardID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByDebitCardID" +
		  ex.getMessage());
	   }

	  if (result.isEmpty()) {
	 throw new ObjectNotFoundException("No rows found.");
	  }
	  else {
	 return result;
	  }
  }



 public void ejbActivate() {
	System.out.println("ejbActivate");
	accountID = (String)entityContext.getPrimaryKey();
	System.out.println("end ejbActivate");
  }

  public void ejbPassivate() {
	System.out.println("ejbPassivate");
	accountID = null;
	System.out.println("end ejbPassivate");
  }

  public void ejbLoad() {
	System.out.println("ejbLoad");
	  try {
	 loadRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
		  ex.getMessage());
	   }
	  System.out.println("end ejbLoad");
  }
  public void ejbStore() {
	System.out.println("ejbStore");
	  try {
	 storeRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbStore: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbStore");
  }
  public void setEntityContext(EntityContext entityContext) {
	System.out.println("setEntityContext 8");
	this.entityContext = entityContext;

	try {
	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup(dbName);
	  con =  ds.getConnection();
	}
	catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
		 ex.getMessage());
	}

	System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
	System.out.println("unsetEntityContext");
	entityContext = null;
	  try {
	 con.close();
	  } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
	  }
	System.out.println("end unsetEntityContext");
  }



//*********************** Database Routines ***************************************************************

   private void insertRow (String accoutID, String accountName,double credit,double balance, String password, String creditCardID, String debitCardID) throws SQLException {

	  String insertStatement =
		"insert into ACCOUNT values ( ? , ? , ? , ?, ?, ?, ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, accoutID);
	  prepStmt.setString(2, accountName);
	  prepStmt.setDouble(3, credit);
	  prepStmt.setDouble(4, balance);
	  prepStmt.setString(5, password);
	  prepStmt.setString(6, creditCardID);
	  prepStmt.setString(7, debitCardID);


	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String id) throws SQLException {

	  String deleteStatement =
		"delete from ACCOUNT where ACCOUNTID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(deleteStatement);

	  prepStmt.setString(1, id);
	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
	  throws SQLException {
	  String selectStatement =
		"select ACCOUNTID " +
		"from ACCOUNT where ACCOUNTID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);
	  prepStmt.setString(1, primaryKey);

	  ResultSet rs = prepStmt.executeQuery();
	  boolean result = rs.next();
	  prepStmt.close();
	  return result;
   }


   private Collection selectByDebitCardID(String debitCardID)
	  throws SQLException {

	  String selectStatement =
		"select ACCOUNTID " +
		"from ACCOUNT where DEBITCARDID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, debitCardID);


	  ResultSet rs = prepStmt.executeQuery();
	  ArrayList a = new ArrayList();

	  while (rs.next()) {
	 String id = rs.getString(1);
	 a.add(id);
	  }

	  prepStmt.close();
	  return a;
   }

	private Collection selectByCreditCardID(String creditCardID)
	  throws SQLException {

	  String selectStatement =
		"select ACCOUNTID " +
		"from ACCOUNT where creditCardID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, creditCardID);


	  ResultSet rs = prepStmt.executeQuery();
	  ArrayList a = new ArrayList();

	  while (rs.next()) {
	 String id = rs.getString(1);
	 a.add(id);
	  }

	  prepStmt.close();
	  return a;
   }

   private void loadRow() throws SQLException {

	  String selectStatement =
		"select ACCOUNTNAME, CREDIT, BALANCE, PASSWORD, CREDITCARDID, DEBITCARDID " +
		"from ACCOUNT where ACCOUNTID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, this.accountID);

	  ResultSet rs = prepStmt.executeQuery();

	  if (rs.next()) {
	 this.accountName = rs.getString(1);
	 this.credit = rs.getDouble(2);
	 this.balance = rs.getDouble(3);
	 this.password = rs.getString(4);
	 this.creditCardID = rs.getString(5);
	 this.debitCardID = rs.getString(6);
	 prepStmt.close();
	  }
	  else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + accountID +
		" not found in database.");
	  }
   }


   private void storeRow() throws SQLException {

	  String updateStatement =
		"update ACCOUNT set " +
		"ACCOUNTNAME =  ? , " +
		"CREDIT = ? , " +
		"BALANCE = ? , " +
		"PASSWORD = ? , "+
		"CREDITCARDID = ?, " +
		"DEBITCARDID = ? " +
		"where ACCOUNTID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(updateStatement);

	  prepStmt.setString(1, accountName);
	  prepStmt.setDouble(2, credit);
	  prepStmt.setDouble(3, balance);
	  prepStmt.setString(4, password);
	  prepStmt.setString(5, creditCardID);
	  prepStmt.setString(6, debitCardID);

	  prepStmt.setString(7, accountID);

	  int rowCount = prepStmt.executeUpdate();
	  prepStmt.close();

	  if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + accountID + " failed.");
	  }
   }

}