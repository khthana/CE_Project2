package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PersonalBooking implements EntityBean {
  EntityContext entityContext;
  public String bookingId;
  public String travellerId;
  public Boolean hasBookBusSeat;
  public Boolean hasBookAirSeat;
  public PersonalBookingPK ejbCreate(String bookingId, String travellerId, Boolean hasBookBusSeat, Boolean hasBookAirSeat) throws CreateException {
	this.bookingId = bookingId;
	this.travellerId = travellerId;
	this.hasBookBusSeat = hasBookBusSeat;
	this.hasBookAirSeat = hasBookAirSeat;
	return null;
  }
  public PersonalBookingPK ejbCreate(String bookingId, String travellerId) throws CreateException {
	return ejbCreate(bookingId, travellerId, null, null);
  }
  public void ejbPostCreate(String bookingId, String travellerId, Boolean hasBookBusSeat, Boolean hasBookAirSeat) throws CreateException {
  }
  public void ejbPostCreate(String bookingId, String travellerId) throws CreateException {
	ejbPostCreate(bookingId, travellerId, null, null);
  }
  public void ejbRemove() throws RemoveException {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
  }
  public void unsetEntityContext() {
	entityContext = null;
  }
  public String getBookingId() {
	return bookingId;
  }
  public String getTravellerId() {
	return travellerId;
  }
  public Boolean getHasBookBusSeat() {
	return hasBookBusSeat;
  }
  public void setHasBookBusSeat(Boolean hasBookBusSeat) {
	this.hasBookBusSeat = hasBookBusSeat;
  }
  public Boolean getHasBookAirSeat() {
	return hasBookAirSeat;
  }
  public void setHasBookAirSeat(Boolean hasBookAirSeat) {
	this.hasBookAirSeat = hasBookAirSeat;
  }
}