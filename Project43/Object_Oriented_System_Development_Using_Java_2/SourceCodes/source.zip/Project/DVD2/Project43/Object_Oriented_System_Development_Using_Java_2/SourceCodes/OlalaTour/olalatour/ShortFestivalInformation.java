package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortFestivalInformation implements Serializable {

    public ShortFestivalInformation(String festivalID, String festivalName) {
	this.festivalID = festivalID;
	this.festivalName = festivalName;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getFestivalID() {
	return festivalID;
    }
    public String getFestivalName() {
	return festivalName;
    }
    private String festivalID;
    private String festivalName;
}