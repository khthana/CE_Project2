package olalatour;

import java.io.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortPlaceInformation implements Serializable {

    public ShortPlaceInformation(String placeID, String placeName, Collection packages, String imageFilePath) {
	this.placeID = placeID;
	this.placeName = placeName;
	this.packages = packages;
	this.imageFilePath = imageFilePath;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPlaceID() {
	return placeID;
    }
    public String getPlaceName() {
	return placeName;
    }
    public java.util.Collection getPackages() {
	return packages;
    }
    public String getImageFilePath() {
	return imageFilePath;
    }
    private String placeID;
    private String placeName;
    private java.util.Collection packages;
    // Collection of packageID
    private String imageFilePath;
}