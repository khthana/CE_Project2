<HTML>
<HEAD>
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<TITLE>
Reserve
</TITLE>
</HEAD>
<BODY>
<%
  String submit = request.getParameter("submit");
  if (submit != null) {
    if (submit.equals("reserve")) {
      out.print("Status:<br>&nbsp;&nbsp;" + controllerBean.reserve());
    }
    else if (submit.equals("confirm")) {

    }
    else if (submit.equals("cancel")) {

    }
  }
%>



<br>
<br>
<hr>
<form name="form1" action="Reserve.jsp" >
  BookingID
  <input type="text" name="BookingID">
  TransactionID : 
  <input type="text" name="TransactionID">
  <br>
  <br>
  <input type="submit" name="submit" value="Confirm">
  <br>
  <br>
  <hr>
  BookingID 
  <input type="text" name="BookingID">
  <br>
  <input type="submit" name="submit" value="Cancel">
</form>
<p>&nbsp; </p>
</BODY>
</HTML>
