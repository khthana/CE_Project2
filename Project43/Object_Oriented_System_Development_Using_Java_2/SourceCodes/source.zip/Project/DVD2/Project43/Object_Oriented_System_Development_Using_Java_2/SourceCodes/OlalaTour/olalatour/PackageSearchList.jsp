<%@ page import="java.sql.Date" %>

<html>
<head>
<jsp:useBean id="viewerBean" scope="page" class="olalatour.ViewerBean" />
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<%
	String submit = request.getParameter("submit");
	out.print(submit);
	if (submit != null) {
	  if (submit.equals("package")) {
		out.print("package");
		String strPackageID = request.getParameter("PackageID");
		String strDepartTimeDay = request.getParameter("DepartTimeDay");
		String strDepartTimeMonth = request.getParameter("DepartTimeMonth");
		String strDepartTimeYear = request.getParameter("DepartTimeYear");
		String strDepartTimeHour = request.getParameter("DepartTimeHour");
		String strDepartTimeMinute = request.getParameter("DepartTimeMinute");
		String strTravellerID = request.getParameter("TravellerID");

		out.print("call addPackageItem");
		java.sql.Timestamp DepartTime = new java.sql.Timestamp(Integer.parseInt(strDepartTimeYear), Integer.parseInt(strDepartTimeMinute), Integer.parseInt(strDepartTimeDay), Integer.parseInt(strDepartTimeHour), Integer.parseInt(strDepartTimeMinute), 0, 0);
		controllerBean.addPackageItem(strPackageID, DepartTime, strTravellerID);
	  }
	}

%>



<table width="750" border="1">
  <tr>
	<td> <b><font size="4"> result of search Package </font></b> </td>
  </tr>
  <tr>
	<td>
	<%
	String strPlaceName = request.getParameter("PlaceName");
	String strCountry = request.getParameter("Country");
	String strState = request.getParameter("State");
	String strProvince = request.getParameter("Province");
	String strDuration = request.getParameter("Duration");
	String strDay = request.getParameter("selectDay");
	String strMonth = request.getParameter("selectMonth");
	String strYear = request.getParameter("selectYear");
	String strPrice = request.getParameter("Price");
	if (strPlaceName == null) {
	  strPlaceName = "";
	}
	if (strCountry == null) {
	  strCountry = "";
	}
	if (strState == null) {
	  strState = "";
	}
	if (strProvince == null) {
	  strProvince = "";
	}
	if (strPrice == null) {
	  strPrice = "500000";
	}
	%>
	<%viewerBean.findPackageTour(strPlaceName, strCountry, strState, strPlaceName, "", Double.parseDouble(strPrice), new Date(Integer.parseInt(strYear), Integer.parseInt(strMonth), Integer.parseInt(strDay)), Integer.parseInt(strDuration));%>
	<%while (viewerBean.nextPackageTour()) {%>
	  <table width="100%" border="1">
	<tr>
	  <td colspan="2" rowspan="3">
		<div align="center"></div>
		<div align="center"><img src="images/LogoPackage.gif" width="150" height="97"><br>
		  <a href="PackageSearchList.jsp?<%=request.getQueryString()%>&PackageID=<%=viewerBean.getPackageID()%>&DepartTimeDay=<%=strDay%>4&DepartTimeMonth=<%=strMonth%>&DepartTimeYear=<%=strYear%>&DepartTimeHour=10&DepartTimeMinute=0&TravellerID=&submit=package">add to cart</a></div>
	  </td>
	  <td width="81%"> <b><font size="4">packagename : <%=viewerBean.getPackageName()%></font></b> </td>
	</tr>
	<tr>
	  <td width="81%">description : <%=viewerBean.getDescription()%></td>
	</tr>
	<tr>
	  <td width="81%">price : <%=viewerBean.getTotalPrice()%></td>
	</tr>
	  </table>
	  <%}%>
	</td>
  </tr>
</table>
</body>
</html>
