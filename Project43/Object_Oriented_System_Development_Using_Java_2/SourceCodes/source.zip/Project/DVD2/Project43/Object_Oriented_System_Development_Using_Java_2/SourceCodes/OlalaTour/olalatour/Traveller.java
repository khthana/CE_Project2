package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Traveller implements EntityBean {
    EntityContext entityContext;
    public String travellerId;
    public String firstName;
    public String lastName;
    public String address;
    public String telephoneNo;
    public String emailAddress;
    public Integer gender;
    public Date birthDate;
    public String religion;
    public String busCompanyCustomerId;
    public String airlineCustomerId;
    public String foodTypeId;
    public String ejbCreate(String travellerId, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String busCompanyCustomerId, String airlineCustomerId, String foodTypeId) throws CreateException {
	this.travellerId = travellerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.telephoneNo = telephoneNo;
	this.emailAddress = emailAddress;
	this.gender = gender;
	this.birthDate = birthDate;
	this.religion = religion;
	this.busCompanyCustomerId = busCompanyCustomerId;
	this.airlineCustomerId = airlineCustomerId;
	this.foodTypeId = foodTypeId;
	return null;
    }
    public String ejbCreate(String travellerId) throws CreateException {
	return ejbCreate(travellerId, null, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbPostCreate(String travellerId, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String busCompanyCustomerId, String airlineCustomerId, String foodTypeId) throws CreateException {
    }
    public void ejbPostCreate(String travellerId) throws CreateException {
	ejbPostCreate(travellerId, null, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getTravellerId() {
	return travellerId;
    }
    public String getFirstName() {
	return firstName;
    }
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }
    public String getAddress() {
	return address;
    }
    public void setAddress(String address) {
	this.address = address;
    }
    public String getTelephoneNo() {
	return telephoneNo;
    }
    public void setTelephoneNo(String telephoneNo) {
	this.telephoneNo = telephoneNo;
    }
    public String getEmailAddress() {
	return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
    }
    public Integer getGender() {
	return gender;
    }
    public void setGender(Integer gender) {
	this.gender = gender;
    }
    public Date getBirthDate() {
	return birthDate;
    }
    public void setBirthDate(Date birthDate) {
	this.birthDate = birthDate;
    }
    public String getReligion() {
	return religion;
    }
    public void setReligion(String religion) {
	this.religion = religion;
    }
    public String getBusCompanyCustomerId() {
	return busCompanyCustomerId;
    }
    public void setBusCompanyCustomerId(String busCompanyCustomerId) {
	this.busCompanyCustomerId = busCompanyCustomerId;
    }
    public String getAirlineCustomerId() {
	return airlineCustomerId;
    }
    public void setAirlineCustomerId(String airlineCustomerId) {
	this.airlineCustomerId = airlineCustomerId;
    }
    public String getFoodTypeId() {
	return foodTypeId;
    }
    public void setFoodTypeId(String foodTypeId) {
	this.foodTypeId = foodTypeId;
    }
}