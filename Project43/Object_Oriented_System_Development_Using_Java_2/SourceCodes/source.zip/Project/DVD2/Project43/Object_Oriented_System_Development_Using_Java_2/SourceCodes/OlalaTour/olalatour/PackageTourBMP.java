package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class PackageTourBMP extends PackageTour {
	DataSource dataSource;
	public String ejbCreate(String packageId, String packageName, String description, Double totalPrice, String image, Integer duration, String busGroupBookingId, String hotelGroupBookingId, String aircraftGroupBookingId, String restaurantGroupBookingId, Timestamp createTime, String adminId, Integer confirm) throws CreateException {
	super.ejbCreate(packageId, packageName, description, totalPrice, image, duration, busGroupBookingId, hotelGroupBookingId, aircraftGroupBookingId, restaurantGroupBookingId, createTime, adminId, confirm);
	try {
		//First see if the object already exists
		ejbFindByPrimaryKey(packageId);
		//If so, then we have to throw an exception
		throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
		//Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("INSERT INTO PACKAGE_TOUR (PACKAGE_ID, PACKAGE_NAME, DESCRIPTION, TOTAL_PRICE, IMAGE, DURATION, BUS_GROUP_BOOKING_ID, HOTEL_GROUP_BOOKING_ID, AIRCRAFT_GROUP_BOOKING_ID, RESTAURANT_GROUP_BOOKING_ID, CREATE_TIME, ADMIN_ID, CONFIRM) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		statement.setString(1, packageId);
		statement.setString(2, packageName);
		statement.setString(3, description);
		statement.setDouble(4, totalPrice.doubleValue());
		statement.setString(5, image);
		statement.setInt(6, duration.intValue());
		statement.setString(7, busGroupBookingId);
		statement.setString(8, hotelGroupBookingId);
		statement.setString(9, aircraftGroupBookingId);
		statement.setString(10, restaurantGroupBookingId);
		statement.setTimestamp(11, createTime);
		statement.setString(12, adminId);
		statement.setInt(13, confirm.intValue());
		if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return packageId;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL INSERT INTO PACKAGE_TOUR (PACKAGE_ID, PACKAGE_NAME, DESCRIPTION, TOTAL_PRICE, IMAGE, DURATION, BUS_GROUP_BOOKING_ID, HOTEL_GROUP_BOOKING_ID, AIRCRAFT_GROUP_BOOKING_ID, RESTAURANT_GROUP_BOOKING_ID, CREATE_TIME, ADMIN_ID, CONFIRM) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public String ejbCreate(String packageId) throws CreateException {
	return ejbCreate(packageId, null, null, null, null, null, null, null, null, null, null, null, null);
	}
	public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("DELETE FROM PACKAGE_TOUR WHERE PACKAGE_ID = ?");
		statement.setString(1, packageId);
		if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL DELETE FROM PACKAGE_TOUR WHERE PACKAGE_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void ejbLoad() {
	packageId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT PACKAGE_NAME, DESCRIPTION, TOTAL_PRICE, IMAGE, DURATION, BUS_GROUP_BOOKING_ID, HOTEL_GROUP_BOOKING_ID, AIRCRAFT_GROUP_BOOKING_ID, RESTAURANT_GROUP_BOOKING_ID, CREATE_TIME, ADMIN_ID, CONFIRM FROM PACKAGE_TOUR WHERE PACKAGE_ID = ?");
		statement.setString(1, packageId);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
		}
		packageName = resultSet.getString(1);
		description = resultSet.getString(2);
		totalPrice = new Double(resultSet.getDouble(3));
		image = resultSet.getString(4);
		duration = new Integer(resultSet.getInt(5));
		busGroupBookingId = resultSet.getString(6);
		hotelGroupBookingId = resultSet.getString(7);
		aircraftGroupBookingId = resultSet.getString(8);
		restaurantGroupBookingId = resultSet.getString(9);
		createTime = resultSet.getTimestamp(10);
		adminId = resultSet.getString(11);
		confirm = new Integer(resultSet.getInt(12));
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT PACKAGE_NAME, DESCRIPTION, TOTAL_PRICE, IMAGE, DURATION, BUS_GROUP_BOOKING_ID, HOTEL_GROUP_BOOKING_ID, AIRCRAFT_GROUP_BOOKING_ID, RESTAURANT_GROUP_BOOKING_ID, CREATE_TIME, ADMIN_ID, CONFIRM FROM PACKAGE_TOUR WHERE PACKAGE_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	super.ejbLoad();
	}
	public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("UPDATE PACKAGE_TOUR SET PACKAGE_NAME = ?, DESCRIPTION = ?, TOTAL_PRICE = ?, IMAGE = ?, DURATION = ?, BUS_GROUP_BOOKING_ID = ?, HOTEL_GROUP_BOOKING_ID = ?, AIRCRAFT_GROUP_BOOKING_ID = ?, RESTAURANT_GROUP_BOOKING_ID = ?, CREATE_TIME = ?, ADMIN_ID = ?, CONFIRM = ? WHERE PACKAGE_ID = ?");
		statement.setString(1, packageName);
		statement.setString(2, description);
		statement.setDouble(3, totalPrice.doubleValue());
		statement.setString(4, image);
		statement.setInt(5, duration.intValue());
		statement.setString(6, busGroupBookingId);
		statement.setString(7, hotelGroupBookingId);
		statement.setString(8, aircraftGroupBookingId);
		statement.setString(9, restaurantGroupBookingId);
		statement.setTimestamp(10, createTime);
		statement.setString(11, adminId);
		statement.setInt(12, confirm.intValue());
		statement.setString(13, packageId);
		if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL UPDATE PACKAGE_TOUR SET PACKAGE_NAME = ?, DESCRIPTION = ?, TOTAL_PRICE = ?, IMAGE = ?, DURATION = ?, BUS_GROUP_BOOKING_ID = ?, HOTEL_GROUP_BOOKING_ID = ?, AIRCRAFT_GROUP_BOOKING_ID = ?, RESTAURANT_GROUP_BOOKING_ID = ?, CREATE_TIME = ?, ADMIN_ID = ?, CONFIRM = ? WHERE PACKAGE_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT PACKAGE_ID FROM PACKAGE_TOUR WHERE PACKAGE_ID = ?");
		statement.setString(1, key);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return key;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT PACKAGE_ID FROM PACKAGE_TOUR WHERE PACKAGE_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindByPlaceIDsPriceDepartTimeDuration(Collection placeIDs, double price, java.sql.Date departTime, int duration) throws FinderException {
	System.out.println("ejbFindByPlaceIDsPriceDepartTimeDuration...");
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		String queryString =
		"SELECT PACKAGE_ID " +
		"FROM PACKAGE_TOUR P1 " +
		"WHERE TOTAL_PRICE <= ? "
			+ "AND DURATION <= ? "
			+ "AND P1.PACKAGE_ID IN ( "
			+ "SELECT P2.PACKAGE_ID "
			+ "FROM PACKAGE_PLACE P2 "
			+ "WHERE PLACE_ID = '' ";
			for (int i = 0; i < placeIDs.size(); i++) {
				queryString += "OR PLACE_ID = ? ";
			}
			queryString = queryString
			+ ") "
			+ "AND PACKAGE_ID IN ( "
			+ "SELECT PACKAGE_ID "
			+ "FROM PACKAGE_DEPARTTIME P3 "
			+ "WHERE P3.DEPART_TIME >= ? "
			+ ") ";

		statement = connection.prepareStatement(queryString);
		System.out.println("prepare");
		Iterator iterator = placeIDs.iterator();
		statement.setDouble(1, price);
		statement.setInt(2, duration);
		for (int i = 0; i < placeIDs.size(); i++) {
		statement.setString(3 + i, (String)iterator.next());
		}
		statement.setTimestamp(3 + placeIDs.size(), new Timestamp(departTime.getTime()));

		ResultSet resultSet = statement.executeQuery();
		System.out.println("execute");
		Vector keys = new Vector();
		while (resultSet.next()) {
		  String placeId = resultSet.getString(1);
		  System.out.println("PackageID : " + placeId);
		  keys.addElement(placeId);
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		System.out.println("end ejbFindByPlaceIDsPriceDepartTimeDuration");
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT PACKAGE_ID FROM PACKAGE_TOUR");
		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		String packageId = resultSet.getString(1);
		keys.addElement(packageId);
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT PACKAGE_ID FROM PACKAGE_TOUR: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
		javax.naming.Context context = new javax.naming.InitialContext();
		dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
		throw new EJBException("Error looking up dataSource:" + e.toString());
	}
	}
	public Collection getPackageTourDepartTimeInformations(java.sql.Date departTime) {
	try {
		  System.out.println("getPackageTourDepartTimeInformations : " + departTime.toString());
		  Connection con = dataSource.getConnection();
		  String selectStatement =
			"select DEPART_TIME, ARRIVE_TIME, GUIDE_ID " +
			"from PACKAGE_DEPARTTIME where  PACKAGE_ID = ? AND DEPART_TIME >= ? ";
		  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
		  prepStmt.setString(1, packageId);
		  prepStmt.setTimestamp(2, new Timestamp(departTime.getTime()));

		  ResultSet rs = prepStmt.executeQuery();
		  System.out.println("executeQuery");

		  ArrayList a = new ArrayList();

		  while (rs.next()) {
		 PackageDepartTimeInformation info = new PackageDepartTimeInformation(packageId, rs.getTimestamp(1), rs.getTimestamp(2), rs.getString(3));
		 a.add(info);
		  }

		  prepStmt.close();
		  prepStmt = null;
		  con.close();
		  con = null;
		  System.out.println("getPackageTourDepartTimeInformations : " + departTime.toString());
		  return a;

	}
	catch (SQLException ex) {
		System.out.println("SQL error in getPackageTourDepartTimeInformations() ");
		return null;
	}
	}
	public Collection getPackagePlaces() {
	try {
		  System.out.println("getPackagePlaces : ");
		  Connection con = dataSource.getConnection();
		  String selectStatement =
			"select PLACE_ID, ARRIVE_TIME, DEPART_TIME, DESCRIPTION " +
			"from PACKAGE_PLACE where  PACKAGE_ID = ? ";
		  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
		  prepStmt.setString(1, packageId);

		  ResultSet rs = prepStmt.executeQuery();
		  System.out.println("executeQuery");

		  ArrayList a = new ArrayList();

		  while (rs.next()) {
		 PackagePlace info = new PackagePlace(rs.getString(1), packageId, rs.getTimestamp(3), rs.getTimestamp(2), rs.getString(4));
		 a.add(info);
		  }

		  prepStmt.close();
		  prepStmt = null;
		  con.close();
		  con = null;
		  System.out.println("getPackagePlaces : ");
		  return a;

	}
	catch (SQLException ex) {
		System.out.println("SQL error in getPackagePlaces() ");
		return null;
	}
	}
	public PackageDepartTimeInformation getPackageTourDepartTimeInformation(java.sql.Timestamp departTime) {
	try {
		  System.out.println("getPackageTourDepartTimeInformation : " + departTime.toString());
		  Connection con = dataSource.getConnection();
		  String selectStatement =
			"select DEPART_TIME, ARRIVE_TIME, GUIDE_ID " +
			"from PACKAGE_DEPARTTIME where  PACKAGE_ID = ? AND DEPART_TIME = ? ";
		  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
		  prepStmt.setString(1, packageId);
		  prepStmt.setTimestamp(2, departTime);

		  ResultSet rs = prepStmt.executeQuery();
		  System.out.println("executeQuery");

		  rs.next();

		  PackageDepartTimeInformation info = new PackageDepartTimeInformation(packageId, rs.getTimestamp(1), rs.getTimestamp(2), rs.getString(3));

		  prepStmt.close();
		  prepStmt = null;
		  con.close();
		  con = null;
		  System.out.println("getPackageTourDepartTimeInformation : " + departTime.toString());
		  return info;

	}
	catch (SQLException ex) {
		System.out.println("SQL error in getPackageTourDepartTimeInformation() ");
		return null;
	}
	}
}