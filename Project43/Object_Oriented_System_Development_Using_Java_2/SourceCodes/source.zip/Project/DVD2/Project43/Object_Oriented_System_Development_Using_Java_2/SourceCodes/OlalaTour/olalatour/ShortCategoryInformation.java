package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortCategoryInformation implements Serializable {

    public ShortCategoryInformation(String categoryID, String categoryName) {
	this.categoryID = categoryID;
	this.categoryName = categoryName;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getCategoryID() {
	return categoryID;
    }
    public String getCategoryName() {
	return categoryName;
    }
    private String categoryID;
    private String categoryName;
}