package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public interface PackageBookingRemote extends EJBObject {
  String getTravellerId() throws RemoteException;
  String getPackageId() throws RemoteException;
  Timestamp getDepartTime() throws RemoteException;
  String getBookingId() throws RemoteException;
}