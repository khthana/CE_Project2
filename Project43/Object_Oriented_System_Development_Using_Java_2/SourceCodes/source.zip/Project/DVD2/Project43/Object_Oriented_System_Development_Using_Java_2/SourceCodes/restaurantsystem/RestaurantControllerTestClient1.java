package restaurantsystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.sql.Date;
import java.util.Iterator;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class RestaurantControllerTestClient1 {
    private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
    private static final int MAX_OUTPUT_LINE_LENGTH = 250;
    private boolean logging = true;
    private RestaurantControllerHome restaurantControllerHome = null;
    private RestaurantControllerRemote restaurantControllerRemote = null;

    /**Construct the EJB test client*/
    public RestaurantControllerTestClient1() {
	long startTime = 0;
	if (logging) {
	    log("Initializing bean access.");
	    startTime = System.currentTimeMillis();
	}

	try {
	    //get naming context
	    Context ctx = new InitialContext();

	    //look up jndi name
	    Object ref = ctx.lookup("RestaurantController");

	    //cast to Home interface
	    restaurantControllerHome = (RestaurantControllerHome) PortableRemoteObject.narrow(ref, RestaurantControllerHome.class);

	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed initializing bean access.");
	    }
	    e.printStackTrace();
	}
    }

    //----------------------------------------------------------------------------
    // Methods that use Home interface methods to generate a Remote interface reference
    //----------------------------------------------------------------------------

    public RestaurantControllerRemote create() {
	long startTime = 0;
	if (logging) {
	    log("Calling create()");
	    startTime = System.currentTimeMillis();
	}
	try {
	    restaurantControllerRemote = restaurantControllerHome.create();
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: create()");
	    }
	    e.printStackTrace();
	}

	if (logging) {
	    log("Return value from create(): " + restaurantControllerRemote + ".");
	}
	return restaurantControllerRemote;
    }

    //----------------------------------------------------------------------------
    // Methods that use Remote interface methods to access data through the bean
    //----------------------------------------------------------------------------

    public Collection findRestaurant(String name, String description, String address, int star) {
	Collection returnValue = null;
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in findRestaurant(): " + ERROR_NULL_REMOTE);
	    return returnValue;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling findRestaurant(" + name + ", " + description + ", " + address + ", " + star + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    returnValue = restaurantControllerRemote.findRestaurant(name, description, address, star);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findRestaurant(" + name + ", " + description + ", " + address + ", " + star + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: findRestaurant(" + name + ", " + description + ", " + address + ", " + star + ")");
	    }
	    e.printStackTrace();
	}

	if (logging) {
	    log("Return value from findRestaurant(" + name + ", " + description + ", " + address + ", " + star + "): " + returnValue + ".");
	}
	return returnValue;
    }

    public FullRestaurantInformation viewRestaurant(String restaurantID) {
	FullRestaurantInformation returnValue = null;
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in viewRestaurant(): " + ERROR_NULL_REMOTE);
	    return returnValue;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling viewRestaurant(" + restaurantID + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    returnValue = restaurantControllerRemote.viewRestaurant(restaurantID);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewRestaurant(" + restaurantID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: viewRestaurant(" + restaurantID + ")");
	    }
	    e.printStackTrace();
	}

	if (logging) {
	    log("Return value from viewRestaurant(" + restaurantID + "): " + returnValue + ".");
	}
	return returnValue;
    }

    public FullBookingInformation viewBooking(String bookingID) {
	FullBookingInformation returnValue = null;
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in viewBooking(): " + ERROR_NULL_REMOTE);
	    return returnValue;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling viewBooking(" + bookingID + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    returnValue = restaurantControllerRemote.viewBooking(bookingID);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewBooking(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: viewBooking(" + bookingID + ")");
	    }
	    e.printStackTrace();
	}

	if (logging) {
	    log("Return value from viewBooking(" + bookingID + "): " + returnValue + ".");
	}
	return returnValue;
    }

    public String reserve(String restaurantID, int meal, Date dateTime, int noOfReserveSeat, String agencyID) {
	String returnValue = "";
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in reserve(): " + ERROR_NULL_REMOTE);
	    return returnValue;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling reserve(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    returnValue = restaurantControllerRemote.reserve(restaurantID, meal, dateTime, noOfReserveSeat, agencyID);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: reserve(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: reserve(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
	    }
	    e.printStackTrace();
	}

	if (logging) {
	    log("Return value from reserve(" + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + "): " + returnValue + ".");
	}
	return returnValue;
    }

    public void confirm(String bookingID) {
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in confirm(): " + ERROR_NULL_REMOTE);
	    return ;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling confirm(" + bookingID + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    restaurantControllerRemote.confirm(bookingID);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: confirm(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: confirm(" + bookingID + ")");
	    }
	    e.printStackTrace();
	}
    }

    public void cancel(String bookingID) {
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in cancel(): " + ERROR_NULL_REMOTE);
	    return ;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling cancel(" + bookingID + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    restaurantControllerRemote.cancel(bookingID);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: cancel(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: cancel(" + bookingID + ")");
	    }
	    e.printStackTrace();
	}
    }

    public void modify(String bookingID, String restaurantID, int meal, Date dateTime, int noOfReserveSeat, String agencyID) {
	if (restaurantControllerRemote == null) {
	    System.out.println("Error in modify(): " + ERROR_NULL_REMOTE);
	    return ;
	}
	long startTime = 0;
	if (logging) {
	    log("Calling modify(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
	    startTime = System.currentTimeMillis();
	}

	try {
	    restaurantControllerRemote.modify(bookingID, restaurantID, meal, dateTime, noOfReserveSeat, agencyID);
	    if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: modify(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	    }
	}
	catch(Exception e) {
	    if (logging) {
		log("Failed: modify(" + bookingID + ", " + restaurantID + ", " + meal + ", " + dateTime + ", " + noOfReserveSeat + ", " + agencyID + ")");
	    }
	    e.printStackTrace();
	}
    }

    //----------------------------------------------------------------------------
    // Utility Methods
    //----------------------------------------------------------------------------

    private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	    System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	    System.out.println("-- " + message);
	}
    }
    /**Main method*/

    public static void main(String[] args) {
	RestaurantControllerTestClient1 client = new RestaurantControllerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.
	client.create();

	// ---Test findRestaurant
//	Collection restaurants = client.findRestaurant("YY", "", "", 100);
//	Iterator iterator = restaurants.iterator();
//
//	while (iterator.hasNext()) {
//	    ShortRestaurantInformation info =  (ShortRestaurantInformation)iterator.next();
//	    System.out.println("ID :" + info.getRestaurantID() + " name :" + info.getName());
//	}


	// ---Test viewRestaurant
	FullRestaurantInformation info = client.viewRestaurant("R0001");
	System.out.println("ID : " + info.getRestaurantID() + " name : " + info.getName() + " description : " + info.getDescription() + " address : " + info.getAddress() + " star : " + info.getStar() + " totalseat : " + info.getTotalSeat());

	// ---Test reserve
//	client.reserve("R0001", 2, new Date(System.currentTimeMillis()), 191, "A0002");

	// ---Test modify
//	client.modify("ceedcdee-0007-f001-0014-74ea796dd505", "R0001", 1, new Date(System.currentTimeMillis()), 919, "A0001");

	// ---Test viewBooking
//	FullBookingInformation info = client.viewBooking("ceedcdee-0007-f001-0014-74ea796dd505");
//	System.out.println("bookingID : " + info.getBookingID() + " agencyID : " + info.getAgencyID() + " restaurantID : " + info.getRestaurantID() + " confirm : " + info.getConfirmation() + " date : " + info.getDateTime().toString() + " meal : " + info.getMeal() + " noOfReserveSeat : " + info.getNoOfReserveSeat());

	// ---Test confirm
//	client.confirm("CF02224E-0007-F001-007B-9FB3E6B8F2D1");

	// ---Test cancel
//	client.cancel("ceedcdee-0007-f001-0014-74ea796dd505");

    }
}