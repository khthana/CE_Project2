package olalatour;

import airlinesystem.*;
import busservice.*;
import hotelsystem.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.sql.Timestamp;
import java.rmi.RemoteException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class ViewerBean {
  OlalaAgencyViewerRemote olalaAgencyViewerRemote = null;
  public void connectServer() {
	try {
		//get naming context
		if (olalaAgencyViewerRemote == null) {
		  Context ctx = new InitialContext();
		  System.out.println("initial");

		  //look up jndi name
		  Object ref = ctx.lookup("olalatour/OlalaAgencyViewer");
		  System.out.println("lookup");

		  //cast to Home interface
		  OlalaAgencyViewerHome olalaAgencyViewerHome = (OlalaAgencyViewerHome)PortableRemoteObject.narrow(ref, OlalaAgencyViewerHome.class);
		  System.out.println("narrow");
		  olalaAgencyViewerRemote = olalaAgencyViewerHome.create();
		  System.out.println("create");
		}
	}
	catch(Exception e) {
		e.printStackTrace();
	}

  }
  //-------------------------------- HOTEL -----------------------------------------
  public void findHotel(String name, String description, String address, int star) {
	connectServer();
	try {
	  /** @todo call OlalaAgencyRemote.findHotel *///ok
	  Collection c = olalaAgencyViewerRemote.findHotel(name, description, address, star);
	  Iterator i = c.iterator();
	  hotelsystem.ShortHotelInformation info = (hotelsystem.ShortHotelInformation)i.next();
	  this.hotelID = info.getHotelID();
	  this.hotelName = info.getHotelName();
	  this.hotelLogo = info.getHotelLogo();
	  this.noOfRooms = info.getNoOfRooms();
	  this.star = info.getStar();
	  /** @todo call OlalaAgencyRemote.findRoom with firsthotelID *///ok
	  System.out.println("hotelID : " + this.hotelID);
	  Collection roomCollection = olalaAgencyViewerRemote.findRoom(this.hotelID);
  //	roomCollection.add(new FullRoomInformation(500, "des1", 11, 12, 13, 14));
  //	roomCollection.add(new FullRoomInformation(550, "des2", 21, 22, 23, 24));
  //	roomCollection.add(new FullRoomInformation(600, "des3", 31, 32, 33, 34));
  //	roomCollection.add(new FullRoomInformation(700, "des4", 41, 42, 43, 44));
	  // ---------------------------------------------------------------
	  roomIterator = roomCollection.iterator();
	}
	catch (Exception ex) {
		ex.printStackTrace();
	}
  }
  public boolean nextRoom() {
	System.out.println("begin nextRoom");
	if (roomIterator.hasNext()) {
		hotelsystem.FullRoomInformation info = (hotelsystem.FullRoomInformation)roomIterator.next();
		this.description = info.getDescription();
		this.numberOfCoupleBed = info.getNumberOfCoupleBed();
		this.numberOfMaximumGuest = info.getNumberOfMaximumGuest();
		this.numberOfSingleBed = info.getNumberOfSingleBed();
		this.pricePerDay = info.getPricePerDay();
		this.roomClass = info.getRoomClass();
		System.out.println("end nextRoom");
		return true;
	}
	else {
		roomIterator = null;
		System.out.println("end nextRoom");
		return false;
	}
  }
  private double pricePerDay;
  private String description;
  private int numberOfSingleBed;
  private int numberOfCoupleBed;
  private int numberOfMaximumGuest;
  private int roomClass;
  public double getPricePerDay() {
	return pricePerDay;
  }
  public String getDescription() {
	return description;
  }
  public int getNumberOfSingleBed() {
	return numberOfSingleBed;
  }
  public int getNumberOfCoupleBed() {
	return numberOfCoupleBed;
  }
  public int getNumberOfMaximumGuest() {
	return numberOfMaximumGuest;
  }
  public int getRoomClass() {
	return roomClass;
  }

  private String hotelID;
  private String hotelName;
  private String hotelLogo;
  private int noOfRooms;
  private int star;
  private Iterator roomIterator;
  public String getHotelID() {
	return hotelID;
  }
  public String getHotelName() {
	return hotelName;
  }
  public String getHotelLogo() {
	return hotelLogo;
  }
  public int getNoOfRooms() {
	return noOfRooms;
  }
  public int getStar() {
	return star;
  }
  //-------------------------------- HOTEL -----------------------------------------

  //-------------------------------- AIRLINE ---------------------------------------
  String PlaceID;
  String PlaceName;
  Iterator airportIterator;
  public String getPlaceID() {
	  return PlaceID;
  }

  public String getPlaceName() {
	 return PlaceName;
  }
  public void searchAirport(String Keyword) {
	System.out.println("begin searchAirport");
	try {
	  connectServer();
	  /** @todo call OlalaAgencyRemote.searchAirport *///ok

	  Collection airportCollection = olalaAgencyViewerRemote.searchAirport(Keyword);
  //	airportCollection.add(new AirportRec("id1", "name1"));
  //	airportCollection.add(new AirportRec("id2", "name2"));
  //	airportCollection.add(new AirportRec("id3", "name3"));
  //	airportCollection.add(new AirportRec("id4", "name4"));
  //	airportCollection.add(new AirportRec("id5", "name5"));
  //	airportCollection.add(new AirportRec("id6", "name6"));

	  airportIterator = airportCollection.iterator();
	}
	catch (Exception ex) {
	  ex.printStackTrace();
	}

	System.out.println("end searchAirport");
  }
  public boolean nextAirport() {
	System.out.println("begin nextAirport");
	if (airportIterator.hasNext()) {
		airlinesystem.AirportRec info = (airlinesystem.AirportRec)airportIterator.next();
		this.PlaceID = info.getPlaceID();
		this.PlaceName = info.getPlaceName();
		System.out.println("end nextAirport");
		return true;
	}
	else {
		airportIterator = null;
		System.out.println("end nextAirport");
		return false;
	}
  }
  String AirlineName;
  String FlightID;
  String AircraftName;
  String ClassName;
  java.sql.Timestamp DepartTime ;
  java.sql.Timestamp ArriveTime;
  int SrcIdx;
  int DstIdx ;
  int TotalDistance;
  double Price;
  String Description;
  Iterator airplaneSeatIterator;
   public String getAirlineName() {
	  return AirlineName;
   }

   public String getFlightID() {
	  return FlightID;
   }
  public String getAircraftName() {
	  return AircraftName;
   }
  public String getClassName() {
	  return ClassName;
   }

   public java.sql.Timestamp getDepartTime() {
	  return DepartTime;
   }

   public java.sql.Timestamp getArriveTime() {
	  return ArriveTime;
   }

   public int getTotalDistance() {
	  return TotalDistance;
   }

  public int getSrcIdx() {
	  return SrcIdx;
   }
  public int getDstIdx() {
	  return DstIdx;
   }
  public double getPrice() {
	  return Price;
   }
//  duplicate
//  public String getDescription() {
//      return Description;
//   }

  public void searchAirplaneSeat(String strSrcAirportID ,String strDstStationID, int totalSeat
	, int departDateDay, int departDateMonth, int departDateYear, int airlineID, int classType, int seatType, boolean canSmoking
	, boolean nonStop, int order) {
	System.out.println("begin searchAirplaneSeat");
	try {
	  connectServer();
	  /** @todo call OlalaAgencyRemote.searchAirplaneSeat *///ok

	  java.sql.Date departDate = new java.sql.Date(departDateYear, departDateMonth, departDateDay);
	  Collection airplaneSeatCollection = olalaAgencyViewerRemote.searchAirplaneSeat(strSrcAirportID, strDstStationID, totalSeat, departDate, airlineID, classType, seatType, canSmoking, nonStop, order);
  //	Collection airplaneSeatCollection = new ArrayList();
  //	airplaneSeatCollection.add(new airlinesystem.SeatRec("airlinename1", "flightid1", "aircraftname1", "1", new Timestamp(2000, 5, 5, 0, 0, 0, 0), new Timestamp(2000, 5, 5, 0, 0, 0, 0), 0, 5, 500, 5000, "des1"));
  //	airplaneSeatCollection.add(new airlinesystem.SeatRec("airlinename2", "flightid2", "aircraftname2", "2", new Timestamp(2000, 5, 5, 0, 0, 0, 0), new Timestamp(2000, 5, 5, 0, 0, 0, 0), 0, 5, 500, 5000, "des1"));
  //	airplaneSeatCollection.add(new airlinesystem.SeatRec("airlinename3", "flightid3", "aircraftname3", "3", new Timestamp(2000, 5, 5, 0, 0, 0, 0), new Timestamp(2000, 5, 5, 0, 0, 0, 0), 0, 5, 500, 5000, "des1"));
  //	airplaneSeatCollection.add(new airlinesystem.SeatRec("airlinename4", "flightid4", "aircraftname4", "4", new Timestamp(2000, 5, 5, 0, 0, 0, 0), new Timestamp(2000, 5, 5, 0, 0, 0, 0), 0, 5, 500, 5000, "des1"));

	  airplaneSeatIterator = airplaneSeatCollection.iterator();
	  System.out.println("end searchAirplaneSeat");
	}
	catch (Exception ex) {
	  ex.printStackTrace();
	}
  }
  public boolean nextAirplaneSeat() {
	System.out.println("begin nextAirplaneSeat");
	if (airplaneSeatIterator.hasNext()) {
		airlinesystem.SeatRec info = (airlinesystem.SeatRec)airplaneSeatIterator.next();
		  this.AirlineName = info.getAircraftName();
		  this.FlightID = info.getFlightID();
		  this.AircraftName = info.getAircraftName();
		  this.ClassName = info.getClassName();
		  this.DepartTime = info.getDepartTime();
		  this.ArriveTime =  info.getArriveTime();
		  this.SrcIdx  = info.getSrcIdx() ;
		  this.DstIdx  = info.getDstIdx() ;
		  this.TotalDistance = info.getTotalDistance();
		  this.Price = info.getPrice();
		  this.Description = info.getDescription();

		System.out.println("end nextAirplaneSeat");
		return true;
	}
	else {
		airplaneSeatIterator = null;
		System.out.println("end nextAirplaneSeat");
		return false;
	}
  }
  //-------------------------------- AIRLINE ---------------------------------------

  // -------------------------------- BUS ------------------------------------------
  Iterator busStationIterator;
  Iterator busSeatIterator;
  String CompanyName ;
//  String ClassName ;
//  java.sql.Timestamp DepartTime ;
//  java.sql.Timestamp ArriveTime ;
  int RouteID ;
  int SrcIndex ;
  int DstIndex ;
//  double Price ;

  public void searchBusStation(String keyword) {
	System.out.println("begin searchBusStation");
	try {
	  connectServer();
	  /** @todo call OlalaAgencyRemote.searchBusStation *///ok


	  Collection busStationCollection = olalaAgencyViewerRemote.searchBusStation(keyword);

  //	Collection busStationCollection = new ArrayList();
  //	busStationCollection.add(new busservice.StationRec("id1", "name1"));
  //	busStationCollection.add(new busservice.StationRec("id2", "name2"));
  //	busStationCollection.add(new busservice.StationRec("id3", "name3"));
  //	busStationCollection.add(new busservice.StationRec("id4", "name4"));

	  busStationIterator = busStationCollection.iterator();
	}
	catch (Exception ex) {
	  ex.printStackTrace();
	}

	System.out.println("end searchBusStation");
  }
  public boolean nextBusStation() {
	System.out.println("begin nextBusStation");
	if (busStationIterator.hasNext()) {
		busservice.StationRec info = (busservice.StationRec)busStationIterator.next();
		this.PlaceID = info.getPlaceID();
		this.PlaceName = info.getPlaceName();
		System.out.println("end nextBusStation");
		return true;
	}
	else {
		airportIterator = null;
		System.out.println("end nextBusStation");
		return false;
	}
  }
  public void searchBusSeat( String SrcStationID, String DstStationID, int TotalSeat, int departDateDay, int departDateMonth, int departDateYear, int CompanyID, int ClassType, int SeatType) {
	System.out.println("begin searchBusSeat");
	try {
	  connectServer();
	  /** @todo call OlalaAgencyRemote.searchBusSeat *///ok

	  java.sql.Date departDate = new java.sql.Date(departDateYear, departDateMonth, departDateDay);
	  Collection busSeatCollection = olalaAgencyViewerRemote.searchBusSeat(SrcStationID, DstStationID, TotalSeat, departDate, CompanyID, ClassType, SeatType);

  //	Collection busSeatCollection = new ArrayList();
  //	busSeatCollection.add(new busservice.SearchRec("company1", "class1", new Timestamp(2001, 5, 10, 0, 0, 0, 0), new Timestamp(2001, 5, 10, 5, 0, 0, 0), 1, 2, 5, 300));
  //	busSeatCollection.add(new busservice.SearchRec("company2", "class2", new Timestamp(2001, 5, 10, 0, 0, 0, 0), new Timestamp(2001, 5, 10, 5, 0, 0, 0), 2, 4, 7, 330));
  //	busSeatCollection.add(new busservice.SearchRec("company3", "class3", new Timestamp(2001, 5, 10, 0, 0, 0, 0), new Timestamp(2001, 5, 10, 5, 0, 0, 0), 3, 5, 8, 340));
  //	busSeatCollection.add(new busservice.SearchRec("company4", "class4", new Timestamp(2001, 5, 10, 0, 0, 0, 0), new Timestamp(2001, 5, 10, 5, 0, 0, 0), 4, 6, 9, 356));

	  busSeatIterator = busSeatCollection.iterator();
	}
	catch (Exception ex) {
	  ex.printStackTrace();
	}

	System.out.println("end searchBusSeat");
  }
  public boolean nextBusSeat() {
	System.out.println("begin nextBusSeat");
	if (busSeatIterator.hasNext()) {
		busservice.SearchRec info = (busservice.SearchRec)busSeatIterator.next();
		this.CompanyName = info.getCompanyName();
		this.ClassName = info.getClassName();
		this.DepartTime = info.getDepartTime();
		this.ArriveTime =  info.getArriveTime();
		this.RouteID = info.getRouteID();
		this.SrcIndex  = info.getSrcIndex() ;
		this.DstIndex  = info.getDstIndex() ;
		this.Price = info.getPrice();

		System.out.println("end nextBusSeat");
		return true;
	}
	else {
		busSeatIterator = null;
		System.out.println("end nextBusSeat");
		return false;
	}
  }
   public String getCompanyName() {
	  return CompanyName;
   }

//   public String getClassName() {
//      return ClassName;
//   }

//   public java.sql.Timestamp getDepartTime() {
//      return DepartTime;
//   }

//   public java.sql.Timestamp getArriveTime() {
//      return ArriveTime;
//   }

   public int getRouteID() {
	  return RouteID;
   }

  public int getSrcIndex() {
	  return SrcIndex;
   }
  public int getDstIndex() {
	  return DstIndex;
   }
//  public double getPrice() {
//      return Price;
//   }



  // -------------------------------- BUS ------------------------------------------

  // -------------------------------- PACKAGETOUR ---------------------------------
  Iterator packageTourIterator;
  private String packageName;
  private String packageID;
//  private String description;
  private double totalPrice;


  public void findPackageTour(String placeName, String country, String state, String province, String description, double price, java.sql.Date departTime, int duration) {
	try {
	  connectServer();
	  /** @todo call olalatour.OlalaAgencyViewer.findPlace and findPackageTour */
	  Collection c = olalaAgencyViewerRemote.findPlace(placeName, country, state, province, description);
	  Iterator i = c.iterator();
	  Collection c2 = new ArrayList();
	  while (i.hasNext()) {
		String x = ((ShortPlaceInformation)i.next()).getPlaceID();
		System.out.println("PlaceID : " + x);
		c2.add(x);
	  }
	  Collection packageTourCollection = olalaAgencyViewerRemote.findPackageTour(c2, price, departTime, duration);

  //	Collection packageTourCollection = new ArrayList();
  //	packageTourCollection.add(new olalatour.ShortPackageTourInformation("packagename1", "id1", "description1", 501));
  //	packageTourCollection.add(new olalatour.ShortPackageTourInformation("packagename2", "id2", "description2", 502));
  //	packageTourCollection.add(new olalatour.ShortPackageTourInformation("packagename3", "id3", "description3", 503));
  //	packageTourCollection.add(new olalatour.ShortPackageTourInformation("packagename4", "id4", "description4", 504));
	  //--------------------------------------------------------------------------------

	  packageTourIterator = packageTourCollection.iterator();
	}
	catch (Exception ex) {
	  ex.printStackTrace();
	}

  }
  public boolean nextPackageTour() {
	System.out.println("begin nextPackageTour");
	if (packageTourIterator.hasNext()) {
		olalatour.ShortPackageTourInformation info = (olalatour.ShortPackageTourInformation)packageTourIterator.next();
		this.packageID = info.getPackageID();
		this.packageName = info.getPackageName();
		this.description = info.getDescription();
		this.totalPrice = info.getTotalPrice();

		System.out.println("end nextPackageTour");
		return true;
	}
	else {
		packageTourIterator = null;
		System.out.println("end nextPackageTour");
		return false;
	}
  }
	public String getPackageID() {
	return packageID;
	}
	public String getPackageName() {
	return packageName;
	}
//    public String getDescription() {
//	return description;
//    }
	public double getTotalPrice() {
	return totalPrice;
	}
  // -------------------------------- PACKAGETOUR ---------------------------------

}