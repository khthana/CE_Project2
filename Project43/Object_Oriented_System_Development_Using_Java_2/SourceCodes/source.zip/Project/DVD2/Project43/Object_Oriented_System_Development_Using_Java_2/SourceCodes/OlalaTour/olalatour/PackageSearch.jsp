<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<table width="750" border="1">
  <tr>
    <td width="100%" rowspan="4"> <font size="5"><b>Fill Data For Package Search</b></font>

      <form method="get" action="PackageSearchList.jsp">
	<table width="100%" border="1">
	  <tr>
	    <td height="15"><b>Where would you like to go?</b></td>
	    <td height="15">&nbsp;</td>
	  </tr>
	  <tr>
	    <td height="33">
	      <div align="right">Place Name : </div>
	    </td>
	    <td height="33"><b>
	          <input type="text" name="PlaceName">
	      </b></td>
	  </tr>
	  <tr>
	    <td height="15">
	      <div align="right">Country : </div>
	    </td>
	    <td height="15"><b>
	          <input type="text" name="Country">
	      </b></td>
	  </tr>
	  <tr>
	    <td height="15">
	      <div align="right">State : </div>
	    </td>
	    <td height="15">
	          <input type="text" name="State">
	    </td>
	  </tr>
	  <tr>
	    <td height="15">
	      <div align="right">Province : </div>
	    </td>
	    <td height="15">
	          <input type="text" name="Province">
	    </td>
	  </tr>
	  <tr>
	    <td height="15"><b>When would you like to travel?</b></td>
	    <td height="15">&nbsp;</td>
	  </tr>
	  <tr>
	    <td height="15">
	      <div align="right">Duration </div>
	    </td>
	    <td height="15">
	          <select name="Duration">
                <option value="1" selected>1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9">9</option>
	      </select>
	      Days </td>
	  </tr>
	  <tr>
	    <td height="15">
	      <div align="right">Departing :</div>
	    </td>
	    <td height="15">
	      <select name="selectDay">
		  <option value="1">1</option>
		  <option value="2">2</option>
		  <option value="3">3</option>
		  <option value="4">4</option>
		  <option value="5">5</option>
		  <option value="6">6</option>
		  <option value="7">7</option>
		  <option value="8">8</option>
		  <option value="9" selected>9</option>
		  <option value="10">10</option>
		  <option value="11">11</option>
		  <option value="12">12</option>
		  <option value="13">13</option>
		  <option value="14">14</option>
		  <option value="15">15</option>
		  <option value="16">16</option>
		  <option value="17">17</option>
		  <option value="18">18</option>
		  <option value="19">19</option>
		  <option value="20">20</option>
		  <option value="21">21</option>
		  <option value="22">22</option>
		  <option value="23">23</option>
		  <option value="24">24</option>
		  <option value="25">25</option>
		  <option value="26">26</option>
		  <option value="27">27</option>
		  <option value="28">28</option>
		  <option value="29">29</option>
		  <option value="30">30</option>
		  <option value="31">31</option>
	      </select>
	      <select name="selectMonth">
                <option value="1">January</option>
                <option value="2">Febuary</option>
                <option value="3" >March</option>
                <option value="4" >April</option>
                <option value="5" selected >May</option>
                <option value="6" >June</option>
                <option value="7" >July</option>
                <option value="8" >August</option>
                <option value="9" >September</option>
                <option value="10" >October</option>
                <option value="11" >November</option>
                <option value="12" >December</option>
              </select>
	      <select name="selectYear">
		<option value="2001" selected>2001</option>
		<option value="2002"> 2002</option>
		<option value="2003"> 2003</option>
		<option value="2004"> 2004</option>
	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td height="15"><b>Passenger and Pricing Information</b></td>
	    <td height="15">&nbsp;</td>
	  </tr>
	  <tr>
	    <td height="15">
	      <div align="right">Price Range : </div>
	    </td>
	    <td height="15">
	          <input type="text" name="Price">
	    </td>
	  </tr>
	  <tr>
	    <td height="15" colspan="2">
	      <div align="center">
		        <input type="submit" name="buttonShowPackage" value="ShowMePackages">
	      </div>
	    </td>
	  </tr>
	</table>
      </form>
    </td>
  </tr>

</table>
</body>
</html>
