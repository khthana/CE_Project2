package olalatour;

import java.io.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public class PackageBookingPK implements Serializable {

  public String travellerId;
  public String packageId;
  public Timestamp departTime;
  public String bookingId;

  public PackageBookingPK() {
  }

  public PackageBookingPK(String travellerId, String packageId, Timestamp departTime, String bookingId) {
    this.travellerId = travellerId;
    this.packageId = packageId;
    this.departTime = departTime;
    this.bookingId = bookingId;
  }
  public boolean equals(Object obj) {
    if (this.getClass().equals(obj.getClass())) {
      PackageBookingPK that = (PackageBookingPK) obj;
      return this.travellerId.equals(that.travellerId) && this.packageId.equals(that.packageId) && this.departTime.equals(that.departTime) && this.bookingId.equals(that.bookingId);
    }
    return false;
  }
  public int hashCode() {
    return (travellerId + packageId + departTime + bookingId).hashCode();
  }
}