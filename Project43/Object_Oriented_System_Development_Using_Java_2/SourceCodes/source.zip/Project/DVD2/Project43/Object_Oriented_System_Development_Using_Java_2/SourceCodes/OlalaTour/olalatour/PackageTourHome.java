package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface PackageTourHome extends EJBHome {
    public PackageTourRemote create(String packageId, String packageName, String description, Double totalPrice, String image, Integer duration, String busGroupBookingId, String hotelGroupBookingId, String aircraftGroupBookingId, String restaurantGroupBookingId, Timestamp createTime, String adminId, Integer confirm) throws RemoteException, CreateException;
    public PackageTourRemote create(String packageId) throws RemoteException, CreateException;
    public PackageTourRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
    public Collection findByPlaceIDsPriceDepartTimeDuration(Collection placeIDs, double price, java.sql.Date departTime, int duration) throws RemoteException, FinderException;
}