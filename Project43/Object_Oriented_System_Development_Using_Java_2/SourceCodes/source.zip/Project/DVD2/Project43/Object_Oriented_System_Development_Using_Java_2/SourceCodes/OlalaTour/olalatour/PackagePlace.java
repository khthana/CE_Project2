package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class PackagePlace implements Serializable {

    public PackagePlace(String placeID, String packageID, java.sql.Timestamp departTime, java.sql.Timestamp arriveTime, String description) {
	this.placeID = placeID;
	this.packageID = packageID;
	this.departTime = departTime;
	this.arriveTime = arriveTime;
	this.description = description;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPlaceID() {
	return placeID;
    }
    public String getPackageID() {
	return packageID;
    }
    public java.sql.Timestamp getDepartTime() {
	return departTime;
    }
    public java.sql.Timestamp getArriveTime() {
	return arriveTime;
    }
    public String getDescription() {
	return description;
    }
    private String placeID;
    private String packageID;
    private java.sql.Timestamp departTime;
    private java.sql.Timestamp arriveTime;
    private String description;
}