<HTML>
<HEAD>
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<TITLE>
Reserve
</TITLE>
</HEAD>
<BODY>
<%
  String submit = request.getParameter("submit");
  if (submit != null) {
    if (submit.equals("reserve")) {
      out.print("Status:<br>&nbsp;&nbsp; Booking complete BookingID = " + controllerBean.reserve());
    }
    else if (submit.equals("confirm")) {

    }
    else if (submit.equals("cancel")) {

    }
  }
%>

</BODY>
</HTML>
