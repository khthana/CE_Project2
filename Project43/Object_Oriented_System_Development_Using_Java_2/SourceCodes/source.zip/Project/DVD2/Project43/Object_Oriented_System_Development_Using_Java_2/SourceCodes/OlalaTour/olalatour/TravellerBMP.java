package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class TravellerBMP extends Traveller {
    DataSource dataSource;
    public String ejbCreate(String travellerId, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String busCompanyCustomerId, String airlineCustomerId, String foodTypeId) throws CreateException {
	super.ejbCreate(travellerId, firstName, lastName, address, telephoneNo, emailAddress, gender, birthDate, religion, busCompanyCustomerId, airlineCustomerId, foodTypeId);
	try {
	    //First see if the object already exists
	    ejbFindByPrimaryKey(travellerId);
	    //If so, then we have to throw an exception
	    throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	    //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("INSERT INTO TRAVELLER (TRAVELLER_ID, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, BUS_COMPANY_CUSTOMER_ID, AIRLINE_CUSTOMER_ID, FOOD_TYPE_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	    statement.setString(1, travellerId);
	    statement.setString(2, firstName);
	    statement.setString(3, lastName);
	    statement.setString(4, address);
	    statement.setString(5, telephoneNo);
	    statement.setString(6, emailAddress);
	    statement.setInt(7, gender.intValue());
	    statement.setDate(8, birthDate);
	    statement.setString(9, religion);
	    statement.setString(10, busCompanyCustomerId);
	    statement.setString(11, airlineCustomerId);
	    statement.setString(12, foodTypeId);
	    if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return travellerId;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL INSERT INTO TRAVELLER (TRAVELLER_ID, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, BUS_COMPANY_CUSTOMER_ID, AIRLINE_CUSTOMER_ID, FOOD_TYPE_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbCreate(String travellerId) throws CreateException {
	return ejbCreate(travellerId, null, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("DELETE FROM TRAVELLER WHERE TRAVELLER_ID = ?");
	    statement.setString(1, travellerId);
	    if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL DELETE FROM TRAVELLER WHERE TRAVELLER_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void ejbLoad() {
	travellerId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, BUS_COMPANY_CUSTOMER_ID, AIRLINE_CUSTOMER_ID, FOOD_TYPE_ID FROM TRAVELLER WHERE TRAVELLER_ID = ?");
	    statement.setString(1, travellerId);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    firstName = resultSet.getString(1);
	    lastName = resultSet.getString(2);
	    address = resultSet.getString(3);
	    telephoneNo = resultSet.getString(4);
	    emailAddress = resultSet.getString(5);
	    gender = new Integer(resultSet.getInt(6));
	    birthDate = resultSet.getDate(7);
	    religion = resultSet.getString(8);
	    busCompanyCustomerId = resultSet.getString(9);
	    airlineCustomerId = resultSet.getString(10);
	    foodTypeId = resultSet.getString(11);
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, BUS_COMPANY_CUSTOMER_ID, AIRLINE_CUSTOMER_ID, FOOD_TYPE_ID FROM TRAVELLER WHERE TRAVELLER_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
	super.ejbLoad();
    }
    public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("UPDATE TRAVELLER SET FIRST_NAME = ?, LAST_NAME = ?, ADDRESS = ?, TELEPHONE_NO = ?, EMAIL_ADDRESS = ?, GENDER = ?, BIRTH_DATE = ?, RELIGION = ?, BUS_COMPANY_CUSTOMER_ID = ?, AIRLINE_CUSTOMER_ID = ?, FOOD_TYPE_ID = ? WHERE TRAVELLER_ID = ?");
	    statement.setString(1, firstName);
	    statement.setString(2, lastName);
	    statement.setString(3, address);
	    statement.setString(4, telephoneNo);
	    statement.setString(5, emailAddress);
	    statement.setInt(6, gender.intValue());
	    statement.setDate(7, birthDate);
	    statement.setString(8, religion);
	    statement.setString(9, busCompanyCustomerId);
	    statement.setString(10, airlineCustomerId);
	    statement.setString(11, foodTypeId);
	    statement.setString(12, travellerId);
	    if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL UPDATE TRAVELLER SET FIRST_NAME = ?, LAST_NAME = ?, ADDRESS = ?, TELEPHONE_NO = ?, EMAIL_ADDRESS = ?, GENDER = ?, BIRTH_DATE = ?, RELIGION = ?, BUS_COMPANY_CUSTOMER_ID = ?, AIRLINE_CUSTOMER_ID = ?, FOOD_TYPE_ID = ? WHERE TRAVELLER_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT TRAVELLER_ID FROM TRAVELLER WHERE TRAVELLER_ID = ?");
	    statement.setString(1, key);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return key;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT TRAVELLER_ID FROM TRAVELLER WHERE TRAVELLER_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT TRAVELLER_ID FROM TRAVELLER");
	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String travellerId = resultSet.getString(1);
		keys.addElement(travellerId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT TRAVELLER_ID FROM TRAVELLER: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	    javax.naming.Context context = new javax.naming.InitialContext();
	    dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	    throw new EJBException("Error looking up dataSource:" + e.toString());
	}
    }
}