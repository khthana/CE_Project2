
wbmpconv: Converts almost anything to/from WBMP.

Copyright (c) 2000 RCP Consultants Ltd All Rights Reserved.

Description

wbmpconv converts a graphics file into WBMP format, or converts WBMP
format to a supported graphics format. It will also display the
converted file before saving it if you wish to confirm the output.

Required environment

This program is distributed in Python source format. A version is also
available asa self contained Windows executable. To use the source
version you will need to have the following (free) software installed on
your computer:

Python (preferably 1.5.2), available from http://www.python.org[1]. You
must be using a build of Python that includes Tk 8.0.
Python Imaging Library (PIL), available from http://www.pythonware.com[2].
Download it from their downloads[3] page.

The required files from each of the above are included in the binary
distributed (which is how a trivial program manages to become so large).

Installation

At present no installation program is supplied. To install, simply unzip
the supplied file into a directory of your choice.

This is a command line program. You may also create associations or
icons to run it from the desktop, from other programs, or from within a
makefile.

To uninstall, simply delete the files and the directory.

Support

If you have any problems with wbmpconv then please take the following
steps:

Check our website[4] to see whether there is a more recent version
available.
Read the FAQ[5].
Post questions to the discussion groups on the website. We, or other
users, may be able to answer your problems.
If you wish to report a bug, then please include a full description of
the problem, including any appropriate image files.

Change History

None recorded, as yet.

Copyright

This program (wbmpconv) may be freely redistributed provided that all
copyright messages are maintained. wbmpconv is copyright (c) 2000 RCP
Consultants Ltd. All rights reserved.
[1]: http://www.python.org
[2]: http://www.pythonware.com
[3]: http://www.pythonware.com/downloads.htm#pil
[4]: http://www.rcp.co.uk/distributed
[5]: http://www.rcp.co.uk/distributed/FAQ
