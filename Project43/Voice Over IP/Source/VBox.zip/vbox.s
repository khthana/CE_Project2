	.module vbox.c
	.area text(rom, con, rel)
	.dbfile C:\icc\work\VBox\vbox.c
	.dbfunc s main _main fI
;      tempData2 -> <dead>
;       testCMD2 -> R10
;       tempData -> R12
;    temp_tel_no -> y+3
;        testCMD -> y+13
;        timeOut -> R10
;      data_dtmf -> y+12
;         tel_no -> y+2
;              i -> y+11
	.even
_main::
	sbiw R28,16
	.dbline 61{
; //ICC-AVR application builder : 3/3/2001 20:23:27
; 
; // Target: AT90S8535
; 
; //ICC needs these helper files...
; #include <io8535.h>
; #include <macros.h>
; #include <string.h>
; #include <eeprom.h>
; #include "defbit.h"
; 
; /* Constant Definitions */
; #define SET_RS  PORTD |= 0x20    
; #define CLR_RS  PORTD &= 0xDF
; #define DIAL    	0
; #define RINGBACK    1
; #define BUSY		2
; #define PCM		3
; #define MAXTIMECALL 5
; #define MAXNO		7
; 
; 
; /* Variable definitions */
; static unsigned char status;          
; static unsigned char dataStatus;
; static unsigned char cmdFlag;
; static unsigned char intFlag;
; static unsigned char hookFlag;
; 
; /* Prototype Definitions */
; /* Procedures */
; void port_init(void);
; //void timer0_init(void);
; void uart0_init(void);
; void init_devices(void);
; void transmitUART(unsigned char data);
; void init_lcd(void);
; void clearLCD(void);
; void gotoxyLCD(unsigned char x_pos);
; void writeLCD(const char *string);
; void writeDataLCD(unsigned char datalcd);   
; void writeCmdLCD(unsigned char datacmdlcd);     
; void latchLCD(void);
; void delayx(unsigned char datax);
; void delayl(unsigned char datal);
; void delay_loop(unsigned char loop);
; void sendSTR(const char *string);
; void changeTone(unsigned char tone);
; void writePCM(unsigned char data);
; /*--------------END-PROCEDURE-DEFINITIONS---------------------*/
; 
; /* Functions */
; unsigned char receiveUART(void);
; unsigned char checkCMD(const char *cmd);
; unsigned char checkCMD2(const char *cmd);
; unsigned char readDTMF(void);
; unsigned char readPCM(void);
; /*--------------END-FUNCTION-DEFINITIONS----------------------*/
; 
; /* Main Program */
; void main(void){
	.dbline 65
; 	unsigned char tempData,tempData2,testCMD,testCMD2,timeOut,i,data_dtmf,tel_no;
; 	unsigned char temp_tel_no[8];
; 
; 	delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 66
; 	init_devices();
	rcall _init_devices
	.dbline 67
; 	PORTD &= 0x7F;   //Clear Pin BlackLight
	in R24,0x12
	andi R24,127
	out 0x12,R24
	.dbline 68
; 	delay_loop(5);
	ldi R16,5
	rcall _delay_loop
	.dbline 69
; 	writeLCD("  VBox   V 1.0  "); //writeLCD("                ");
	ldi R16,<L2
	ldi R17,>L2
	rcall _writeLCD
	.dbline 71
; 
; 	testCMD=0;
	clr R0
	std y+13,R0
	.dbline 72
; 	cmdFlag=0;
	clr R2
	sts _cmdFlag,R2
	.dbline 73
; 	intFlag=0;
	sts _intFlag,R2
	.dbline 74
; 	hookFlag = 0;
	sts _hookFlag,R2
	rjmp L4
L3:
	.dbline 76
; 	
; 	while(testCMD==0){
	.dbline 77
;        delay_loop(40);
	ldi R16,40
	rcall _delay_loop
	.dbline 78
;   	   writeLCD("Check Connection");
	ldi R16,<L6
	ldi R17,>L6
	rcall _writeLCD
	.dbline 79
; 	   delay_loop(40);
	ldi R16,40
	rcall _delay_loop
	.dbline 80
; 	   writeLCD("      Waiting...");
	ldi R16,<L7
	ldi R17,>L7
	rcall _writeLCD
	.dbline 81
; 	   testCMD=checkCMD("@K");
	ldi R16,<L8
	ldi R17,>L8
	rcall _checkCMD
	mov R2,R16
	mov R3,R17
	std y+13,R2
	.dbline 82
; 	   if (testCMD==0) writeLCD("Error Connection"); //False connection 
	ldd R0,y+13
	tst R0
	brne L9
	.dbline 82
	ldi R16,<L11
	ldi R17,>L11
	rcall _writeLCD
L9:
	.dbline 83
L4:
	.dbline 76
	ldd R0,y+13
	tst R0
	breq L3
	.dbline 86
; 	}
; 	// read eeprom,it is No Tel of VBox
; 	
; 	sendSTR("@D");  //send ID to PC for register
	ldi R16,<L12
	ldi R17,>L12
	rcall _sendSTR
	.dbline 87
	clr R0
	inc R0
	std y+11,R0
	rjmp L16
L13:
	.dbline 87
; 	for (i=1;i<=MAXNO;i++){
	.dbline 88
; 		EEPROM_READ(i,tel_no);
	ldi R24,1
	ldi R25,0
	std y+0,R24
	std y+1,R25
	mov R24,R28
	mov R25,R29
	adiw R24,2
	mov R18,R24
	mov R19,R25
	ldd R16,y+11
	clr R17
	rcall _EEPROMReadBytes
	.dbline 89
; 		if (!((tel_no>=0x30)&(tel_no<=0x39))) tel_no=0x30;
	ldd R24,y+2
	cpi R24,48
	brlo L19
	ldi R22,1
	ldi R23,0
	rjmp L20
L19:
	clr R22
	clr R23
L20:
	ldi R24,57
	ldd R2,y+2
	cp R24,R2
	brlo L21
	ldi R20,1
	ldi R21,0
	rjmp L22
L21:
	clr R20
	clr R21
L22:
	mov R2,R22
	mov R3,R23
	and R2,R20
	and R3,R21
	tst R2
	brne L17
	tst R3
	brne L17
	.dbline 89
	ldi R24,48
	std y+2,R24
L17:
	.dbline 90
	ldd R16,y+2
	rcall _transmitUART
	.dbline 91
L14:
	.dbline 87
	ldd R0,y+11
	inc R0
	std y+11,R0
L16:
	.dbline 87
	ldi R24,7
	ldd R0,y+11
	cp R24,R0
	brsh L13
	.dbline 92
; 		transmitUART(tel_no); 	
; 	}
; 	transmitUART('\n');
	ldi R16,10
	rcall _transmitUART
	.dbline 94
; 	
;     writeLCD("        Ready...");
	ldi R16,<L23
	ldi R17,>L23
	rcall _writeLCD
	.dbline 95
; 	delay_loop(40);  
	ldi R16,40
	rcall _delay_loop
	.dbline 96
; 	PORTD |= 0x80;    //Set Pin BlackLight
	sbi 0x12,7
	.dbline 97
; 	SEI();   /* Enable Interrupt */
	sei
	rjmp L25
L24:
	.dbline 98
; 	while(1){
	.dbline 99
	lds R20,_status
	clr R21
	cpi R20,1
	ldi R30,0
	cpc R21,R30
	breq L30
	cpi R20,2
	ldi R30,0
	cpc R21,R30
	brne X3
	rjmp L69
X3:
	rjmp L28
X0:
	.dbline 99
; 		switch(status){
L30:
	.dbline 101
; 			case 1 :
; 				CLI();  /* Disable Interrrupt */
	cli
	.dbline 102
; 				if (dataStatus=='@'){     //Caller
	lds R24,_dataStatus
	cpi R24,64
	breq X4
	rjmp L31
X4:
	.dbline 102
	.dbline 103
; 					tempData = receiveUART();   /* Check Command Charecter */ 
	rcall _receiveUART
	mov R2,R16
	mov R3,R17
	mov R12,R2
	.dbline 104
; 				   	if (tempData=='R'){
	mov R24,R12
	cpi R24,82
	breq X5
	rjmp L32
X5:
	.dbline 104
	.dbline 105
; 					   PORTD &= 0x7F;   //Clear Pin BlackLight
	in R24,0x12
	andi R24,127
	out 0x12,R24
	.dbline 106
; 					   delayx(0xFF);					   
	ldi R16,255
	rcall _delayx
	.dbline 107
; 				       writeLCD("      Receive...");
	ldi R16,<L35
	ldi R17,>L35
	rcall _writeLCD
	.dbline 108
; 					   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 110
; 					   
; 					   timeOut=1;
	clr R10
	inc R10
	rjmp L37
L36:
	.dbline 111
; 					   while(timeOut<=MAXTIMECALL){
	.dbline 112
; 					   		PORTD |= 0x10;   //Set Pin RC
	sbi 0x12,4
	.dbline 113
; 							delay_loop(25);
	ldi R16,25
	rcall _delay_loop
	.dbline 114
; 							PORTD &= 0xEF;   //Clear Pin RC
	in R24,0x12
	andi R24,239
	out 0x12,R24
	.dbline 115
; 							delay_loop(10);
	ldi R16,10
	rcall _delay_loop
	.dbline 116
; 							if ((PIND & 0x04)==0 ) goto end_ring;
	sbic 0x10,2
	rjmp L39
	.dbline 116
	rjmp L41
L39:
	.dbline 117
; 							delay_loop(10);
	ldi R16,10
	rcall _delay_loop
	.dbline 118
; 					   		PORTD |= 0x10;   //Set Pin RC
	sbi 0x12,4
	.dbline 119
; 							delay_loop(25);
	ldi R16,25
	rcall _delay_loop
	.dbline 120
; 							PORTD &= 0xEF;   //Clear Pin RC
	in R24,0x12
	andi R24,239
	out 0x12,R24
	.dbline 121
	clr R0
	std y+11,R0
	rjmp L45
L42:
	.dbline 121
; 							for (i=0;i<6;i++){
	.dbline 122
; 								delay_loop(10);
	ldi R16,10
	rcall _delay_loop
	.dbline 123
; 								if ((PIND & 0x04)==0 ) goto end_ring;
	sbic 0x10,2
	rjmp L46
	.dbline 123
	rjmp L41
L46:
	.dbline 124
L43:
	.dbline 121
	ldd R0,y+11
	inc R0
	std y+11,R0
L45:
	.dbline 121
	ldd R24,y+11
	cpi R24,6
	brlo L42
	.dbline 125
	inc R10
	.dbline 126
L37:
	.dbline 111
	ldi R24,5
	cp R24,R10
	brsh L36
L41:
	.dbline 128
; 							}
; 							timeOut++;
; 					   }
; 					   end_ring:
; 					   if (timeOut>MAXTIMECALL){
	ldi R24,5
	cp R24,R10
	brsh L48
	.dbline 128
	.dbline 129
; 					   	  sendSTR("@I"); //send TimeOut Status
	ldi R16,<L50
	ldi R17,>L50
	rcall _sendSTR
	.dbline 130
; 						  transmitUART('\n');
	ldi R16,10
	rcall _transmitUART
	.dbline 131
; 						  writeLCD("      Time Out!!");
	ldi R16,<L51
	ldi R17,>L51
	rcall _writeLCD
	.dbline 132
	rjmp L32
L48:
	.dbline 132
; 					   }else{
	.dbline 133
; 					   	  sendSTR("@A"); //send Receive Status
	ldi R16,<L52
	ldi R17,>L52
	rcall _sendSTR
	.dbline 134
; 						  transmitUART('\n');
	ldi R16,10
	rcall _transmitUART
	.dbline 135
; 						  writeLCD("      Connect...");
	ldi R16,<L53
	ldi R17,>L53
	rcall _writeLCD
	.dbline 136
; 						  delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 137
; 						  changeTone(PCM);
	ldi R16,3
	rcall _changeTone
	.dbline 138
; 						  delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 140
; 						  
; 						  intFlag=1;
	ldi R24,1
	sts _intFlag,R24
	.dbline 143
; 						    
; 						  // clear ext int 
; 						  GIMSK = 0;
	clr R2
	out 0x3b,R2
	.dbline 144
; 						  SEI();
	sei
	rjmp L55
L54:
	.dbline 146
	.dbline 147
	rcall _readPCM
	mov R2,R16
	mov R3,R17
	mov R12,R2
	.dbline 148
	mov R16,R12
	rcall _transmitUART
	.dbline 149
	ldi R16,255
	rcall _delayx
	.dbline 150
L55:
	.dbline 146
; 						  
; 						  while(((PIND & 0x04)==0)&(hookFlag==0)){
	sbic 0x10,2
	rjmp L57
	ldi R24,1
	ldi R25,0
	mov R14,R24
	mov R15,R25
	rjmp L58
L57:
	clr R14
	clr R15
L58:
	lds R2,_hookFlag
	tst R2
	brne L59
	ldi R22,1
	ldi R23,0
	rjmp L60
L59:
	clr R22
	clr R23
L60:
	mov R2,R14
	mov R3,R15
	and R2,R22
	and R3,R23
	tst R2
	brne L54
	tst R3
	brne L54
	.dbline 152
; 								tempData=readPCM();
; 								transmitUART(tempData);
; 								delayx(0xFF);						  
; 						  }
; 						  
; 						  CLI();
	cli
	.dbline 153
; 						  GIMSK = (1<<INT0);
	ldi R24,64
	out 0x3b,R24
	.dbline 154
; 						  if (hookFlag==1){
	lds R24,_hookFlag
	cpi R24,1
	brne L61
	.dbline 154
	.dbline 155
; 						  	 changeTone(BUSY);
	ldi R16,2
	rcall _changeTone
	.dbline 156
; 							 writeLCD("Please Hang Up!!");
	ldi R16,<L63
	ldi R17,>L63
	rcall _writeLCD
L64:
	.dbline 157
	.dbline 157
L65:
	.dbline 157
; 							 while (((PIND & 0x04)==0)){}
	sbis 0x10,2
	rjmp L64
	.dbline 158
; 						  	 hookFlag=0;
	clr R2
	sts _hookFlag,R2
	.dbline 159
; 						  }
L61:
	.dbline 160
; 						  writeLCD("      Disconnect");
	ldi R16,<L67
	ldi R17,>L67
	rcall _writeLCD
	.dbline 161
; 						  delay_loop(20);
	ldi R16,20
	rcall _delay_loop
	.dbline 162
; 					   }    
	.dbline 163
; 					}
	.dbline 164
	rjmp L32
L31:
	.dbline 164
; 				}else{                           
	.dbline 165
; 					delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 166
; 				}              
L32:
	.dbline 167
; 				status=0;	/* clear status */
	clr R2
	sts _status,R2
	.dbline 168
; 				intFlag=0;
	sts _intFlag,R2
	.dbline 169
; 				writeLCD("        Ready...");
	ldi R16,<L23
	ldi R17,>L23
	rcall _writeLCD
	.dbline 170
; 				delay_loop(20);  
	ldi R16,20
	rcall _delay_loop
	.dbline 171
; 				PORTD |= 0x80;    //Set Pin BlackLight
	sbi 0x12,7
	.dbline 172
; 				sendSTR("@H"); 
	ldi R16,<L68
	ldi R17,>L68
	rcall _sendSTR
	.dbline 173
; 				transmitUART('\n');
	ldi R16,10
	rcall _transmitUART
	.dbline 174
; 				SEI();   /* Enable Interrupt */
	sei
	.dbline 175
; 				break;
	rjmp L28
L69:
	.dbline 177
; 			case 2 :   
; 				CLI();    /* offHook from Phone */
	cli
	.dbline 178
; 				if((PIND & 0x04)==0){
	sbic 0x10,2
	rjmp L70
	.dbline 178
	.dbline 179
; 						 PORTD &= 0x7F;   //Clear Pin BlackLight
	in R24,0x12
	andi R24,127
	out 0x12,R24
	.dbline 180
; 						 delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 181
; 						 writeLCD("Call :");
	ldi R16,<L72
	ldi R17,>L72
	rcall _writeLCD
	.dbline 182
; 						 delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 183
; 						 changeTone(DIAL);
	clr R16
	rcall _changeTone
	.dbline 184
; 						 data_dtmf = 0;
	clr R0
	std y+12,R0
	.dbline 185
; 						 timeOut = 0;
	clr R10
	.dbline 186
; 						 gotoxyLCD(0x41);
	ldi R16,65
	rcall _gotoxyLCD
	rjmp L74
L73:
	.dbline 188
; 						 
; 						 while (1){
	.dbline 189
; 						 	   if (timeOut==MAXNO){
	mov R24,R10
	cpi R24,7
	brne L76
	.dbline 189
	.dbline 190
; 							      writeDataLCD(data_dtmf);
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 191
; 								  temp_tel_no[timeOut]=data_dtmf;
	mov R24,R28
	mov R25,R29
	adiw R24,3
	mov R30,R10
	clr R31
	add R30,R24
	adc R31,R25
	ldd R0,y+12
	std z+0,R0
	.dbline 192
; 								  delay_loop(20); 
	ldi R16,20
	rcall _delay_loop
	.dbline 193
; 							   	  goto end_check_dtmf;
	rjmp L78
L76:
	.dbline 196
; 							   }
; 							   
; 							   data_dtmf = readDTMF();
	rcall _readDTMF
	mov R2,R16
	mov R3,R17
	std y+12,R2
	.dbline 197
; 							   changeTone(PCM);
	ldi R16,3
	rcall _changeTone
	.dbline 198
; 							   if (data_dtmf==0xF0) goto end_call;
	ldd R24,y+12
	cpi R24,240
	brne L79
	.dbline 198
	rjmp L81
L79:
	.dbline 199
; 							   else if ((data_dtmf=='*')&(timeOut==0)){
	ldd R24,y+12
	cpi R24,42
	brne L84
	ldi R22,1
	ldi R23,0
	rjmp L85
L84:
	clr R22
	clr R23
L85:
	tst R10
	brne L86
	ldi R24,1
	ldi R25,0
	std y+14,R24
	std y+15,R25
	rjmp L87
L86:
	clr R0
	clr R1
	std y+14,R0
	std y+15,R1
L87:
	mov R2,R22
	mov R3,R23
	ldd R0,y+14
	ldd R1,y+15
	and R2,R0
	and R3,R1
	tst R2
	brne X6
	tst R3
	breq L82
X6:
	.dbline 199
	.dbline 200
; 							      writeDataLCD(data_dtmf);
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 201
; 								  delayx(100); 
	ldi R16,100
	rcall _delayx
	.dbline 202
; 							      goto setting_Tel_No;
	rjmp L88
L82:
	.dbline 204
; 							   }
; 							   if ((data_dtmf>=0x30)&(data_dtmf<=0x39)){				   
	ldd R24,y+12
	cpi R24,48
	brlo L91
	ldi R24,1
	ldi R25,0
	mov R14,R24
	mov R15,R25
	rjmp L92
L91:
	clr R14
	clr R15
L92:
	ldi R24,57
	ldd R0,y+12
	cp R24,R0
	brlo L93
	ldi R22,1
	ldi R23,0
	rjmp L94
L93:
	clr R22
	clr R23
L94:
	mov R2,R14
	mov R3,R15
	and R2,R22
	and R3,R23
	tst R2
	brne X7
	tst R3
	breq L89
X7:
	.dbline 204
	.dbline 205
; 							   	  writeDataLCD(data_dtmf);
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 206
; 								  temp_tel_no[timeOut]=data_dtmf;
	mov R24,R28
	mov R25,R29
	adiw R24,3
	mov R30,R10
	clr R31
	add R30,R24
	adc R31,R25
	ldd R0,y+12
	std z+0,R0
	.dbline 207
; 					  		   	  delayx(100);
	ldi R16,100
	rcall _delayx
	.dbline 208
; 							   	  timeOut++;
	inc R10
	.dbline 209
; 							   }
L89:
	.dbline 210
L74:
	.dbline 188
	rjmp L73
L88:
	.dbline 212
; 						 }
; 		 				 setting_Tel_No:
; 						       data_dtmf = readDTMF();
	rcall _readDTMF
	mov R2,R16
	mov R3,R17
	std y+12,R2
	.dbline 213
; 							   if ((data_dtmf==0xF0)|(!(data_dtmf=='1'))){
	ldd R24,y+12
	cpi R24,240
	brne L97
	ldi R24,1
	ldi R25,0
	mov R14,R24
	mov R15,R25
	rjmp L98
L97:
	clr R14
	clr R15
L98:
	ldd R24,y+12
	cpi R24,49
	breq L99
	ldi R22,1
	ldi R23,0
	rjmp L100
L99:
	clr R22
	clr R23
L100:
	mov R2,R14
	mov R3,R15
	or R2,R22
	or R3,R23
	tst R2
	brne X8
	tst R3
	breq L95
X8:
	.dbline 213
	.dbline 214
; 							       writeLCD(" Error Setting!!");
	ldi R16,<L101
	ldi R17,>L101
	rcall _writeLCD
	.dbline 215
; 								   delay_loop(30);
	ldi R16,30
	rcall _delay_loop
	.dbline 216
; 								   writeLCD("Please Hang Up!!");
	ldi R16,<L63
	ldi R17,>L63
	rcall _writeLCD
	.dbline 217
; 							   	   goto check_hangup;
	rjmp L169
L95:
	.dbline 219
; 							   }
;      						   writeDataLCD(data_dtmf);delayx(100); 
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 219
	ldi R16,100
	rcall _delayx
	.dbline 220
; 						       data_dtmf = readDTMF();
	rcall _readDTMF
	mov R2,R16
	mov R3,R17
	std y+12,R2
	.dbline 221
; 							   if ((data_dtmf==0xF0)|(!(data_dtmf=='0'))){
	ldd R24,y+12
	cpi R24,240
	brne L105
	ldi R24,1
	ldi R25,0
	mov R14,R24
	mov R15,R25
	rjmp L106
L105:
	clr R14
	clr R15
L106:
	ldd R24,y+12
	cpi R24,48
	breq L107
	ldi R22,1
	ldi R23,0
	rjmp L108
L107:
	clr R22
	clr R23
L108:
	mov R2,R14
	mov R3,R15
	or R2,R22
	or R3,R23
	tst R2
	brne X9
	tst R3
	breq L103
X9:
	.dbline 221
	.dbline 222
; 							   	   writeLCD(" Error Setting!!");
	ldi R16,<L101
	ldi R17,>L101
	rcall _writeLCD
	.dbline 223
; 								   delay_loop(30);
	ldi R16,30
	rcall _delay_loop
	.dbline 224
; 								   writeLCD("Please Hang Up!!");
	ldi R16,<L63
	ldi R17,>L63
	rcall _writeLCD
	.dbline 225
; 							   	   goto check_hangup;
	rjmp L169
L103:
	.dbline 227
; 							   }
; 							   writeDataLCD(data_dtmf);delayx(100);
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 227
	ldi R16,100
	rcall _delayx
	.dbline 228
; 							   data_dtmf = readDTMF();
	rcall _readDTMF
	mov R2,R16
	mov R3,R17
	std y+12,R2
	.dbline 229
; 							   if ((data_dtmf==0xF0)|(!(data_dtmf=='#'))){
	ldd R24,y+12
	cpi R24,240
	brne L111
	ldi R24,1
	ldi R25,0
	mov R14,R24
	mov R15,R25
	rjmp L112
L111:
	clr R14
	clr R15
L112:
	ldd R24,y+12
	cpi R24,35
	breq L113
	ldi R22,1
	ldi R23,0
	rjmp L114
L113:
	clr R22
	clr R23
L114:
	mov R2,R14
	mov R3,R15
	or R2,R22
	or R3,R23
	tst R2
	brne X10
	tst R3
	breq L109
X10:
	.dbline 229
	.dbline 230
; 							   	   writeLCD(" Error Setting!!");
	ldi R16,<L101
	ldi R17,>L101
	rcall _writeLCD
	.dbline 231
; 								   delay_loop(30);
	ldi R16,30
	rcall _delay_loop
	.dbline 232
; 								   writeLCD("Please Hang Up!!");
	ldi R16,<L63
	ldi R17,>L63
	rcall _writeLCD
	.dbline 233
; 							   	   goto check_hangup;
	rjmp L169
L109:
	.dbline 235
; 							   }
; 							   writeDataLCD(data_dtmf);delay_loop(20);
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 235
	ldi R16,20
	rcall _delay_loop
	.dbline 238
; 							   
; 						 	   // write eeprom,it is No Tel of VBox
; 							   writeLCD("      Setting...");
	ldi R16,<L115
	ldi R17,>L115
	rcall _writeLCD
	.dbline 239
; 							   delay_loop(20);
	ldi R16,20
	rcall _delay_loop
	.dbline 240
; 							   writeLCD("No. Set:");
	ldi R16,<L116
	ldi R17,>L116
	rcall _writeLCD
	.dbline 241
; 							   delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 242
; 							   gotoxyLCD(0x41);
	ldi R16,65
	rcall _gotoxyLCD
	.dbline 243
; 							   delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 244
; 							   timeOut=1;
	clr R10
	inc R10
	rjmp L118
L117:
	.dbline 246
; 							   
; 							   while (1){
	.dbline 247
; 							   		 data_dtmf=readDTMF();
	rcall _readDTMF
	mov R2,R16
	mov R3,R17
	std y+12,R2
	.dbline 248
; 							   		 writeDataLCD(data_dtmf);delayx(100);
	ldd R16,y+12
	rcall _writeDataLCD
	.dbline 248
	ldi R16,100
	rcall _delayx
	.dbline 249
; 							   		 if (timeOut==MAXNO){
	mov R24,R10
	cpi R24,7
	brne L120
	.dbline 249
	.dbline 250
; 									    temp_tel_no[timeOut++]=data_dtmf;
	mov R2,R10
	clr R3
	subi R24,255	; addi 1
	mov R10,R24
	mov R24,R28
	mov R25,R29
	adiw R24,3
	mov R30,R2
	mov R31,R3
	add R30,R24
	adc R31,R25
	ldd R0,y+12
	std z+0,R0
	.dbline 251
; 									 	delay_loop(20);
	ldi R16,20
	rcall _delay_loop
	.dbline 252
; 									  	goto set_eeprom;
	rjmp L122
L120:
	.dbline 254
; 									 }
; 									 if (data_dtmf==0xF0) goto exit_setting;
	ldd R24,y+12
	cpi R24,240
	brne L123
	.dbline 254
	rjmp L125
L123:
	.dbline 255
	mov R2,R10
	clr R3
	mov R24,R10
	subi R24,255	; addi 1
	mov R10,R24
	mov R24,R28
	mov R25,R29
	adiw R24,3
	mov R30,R2
	mov R31,R3
	add R30,R24
	adc R31,R25
	ldd R0,y+12
	std z+0,R0
	.dbline 257
L118:
	.dbline 246
	rjmp L117
L122:
	.dbline 259
; 									 temp_tel_no[timeOut++]=data_dtmf;
; 									 
; 							   } 
; 							   set_eeprom:
; 							   		delay_loop(10);
	ldi R16,10
	rcall _delay_loop
	.dbline 260
	clr R0
	inc R0
	std y+11,R0
	rjmp L129
L126:
	.dbline 260
	.dbline 261
	mov R24,R28
	mov R25,R29
	adiw R24,3
	ldd R30,y+11
	clr R31
	add R30,R24
	adc R31,R25
	ldd R2,z+0
	std y+2,R2
	.dbline 262
	ldi R24,1
	ldi R25,0
	std y+0,R24
	std y+1,R25
	mov R24,R28
	mov R25,R29
	adiw R24,2
	mov R18,R24
	mov R19,R25
	ldd R16,y+11
	clr R17
	rcall _EEPROMWriteBytes
	.dbline 263
L127:
	.dbline 260
	ldd R0,y+11
	inc R0
	std y+11,R0
L129:
	.dbline 260
; 							   		for (i=1;i<=(MAXNO+1);i++){
	ldi R24,8
	ldd R0,y+11
	cp R24,R0
	brsh L126
	.dbline 264
; 										tel_no = temp_tel_no[i];
; 										EEPROM_WRITE(i,tel_no);	
; 									}
; 							   writeLCD("Setting Complete");
	ldi R16,<L130
	ldi R17,>L130
	rcall _writeLCD
	.dbline 265
; 							   delay_loop(30);
	ldi R16,30
	rcall _delay_loop
	rjmp L132
L131:
	.dbline 267
	.dbline 268
	ldi R16,<L134
	ldi R17,>L134
	rcall _writeLCD
	.dbline 269
L132:
	.dbline 267
; 
; 							   while(1){
	rjmp L131
L125:
	.dbline 272
; 							   			writeLCD("Please  Reset!!!");
; 							   }
; 							   
; 							   exit_setting:
; 	    					   writeLCD("   Exit  Setting");
	ldi R16,<L135
	ldi R17,>L135
	rcall _writeLCD
	.dbline 273
; 		        			   delay_loop(30);
	ldi R16,30
	rcall _delay_loop
	.dbline 274
; 							   goto end_call;
	rjmp L81
L78:
	.dbline 277
; 							   
; 						 end_check_dtmf:
; 						 	   sendSTR("@C"); //sendnumber
	ldi R16,<L136
	ldi R17,>L136
	rcall _sendSTR
	.dbline 279
	clr R0
	std y+11,R0
	rjmp L140
L137:
	.dbline 279
	.dbline 280
	mov R24,R28
	mov R25,R29
	adiw R24,3
	ldd R30,y+11
	clr R31
	add R30,R24
	adc R31,R25
	ldd R2,z+0
	std y+2,R2
	.dbline 281
	ldd R16,y+2
	rcall _transmitUART
	.dbline 282
L138:
	.dbline 279
	ldd R0,y+11
	inc R0
	std y+11,R0
L140:
	.dbline 279
; 							   				  //No
; 							   for (i=0;i<MAXNO;i++){
	ldd R24,y+11
	cpi R24,7
	brlo L137
	.dbline 283
; 							       tel_no=temp_tel_no[i];
; 							   	   transmitUART(tel_no); 	
; 							   }
; 							   transmitUART('\n');
	ldi R16,10
	rcall _transmitUART
	.dbline 284
; 							   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 285
; 							   writeLCD("    Wait Call...");
	ldi R16,<L141
	ldi R17,>L141
	rcall _writeLCD
	.dbline 286
; 							   delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 287
; 							   testCMD=checkCMD2("@L"); //bug here
	ldi R16,<L142
	ldi R17,>L142
	rcall _checkCMD2
	mov R2,R16
	mov R3,R17
	std y+13,R2
	.dbline 291
; 							   							   
; 							   /* Check Command Charecter */
; 							   // wait status @O connect complete @N Busy
; 							   if (testCMD==1){
	ldd R24,y+13
	cpi R24,1
	breq X11
	rjmp L143
X11:
	.dbline 291
	.dbline 292
; 							      writeLCD("      Calling...");
	ldi R16,<L145
	ldi R17,>L145
	rcall _writeLCD
	.dbline 293
; 							      delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 294
; 								  changeTone(RINGBACK);
	ldi R16,1
	rcall _changeTone
	.dbline 295
; 								  delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 296
; 							      testCMD2=checkCMD2("@O");
	ldi R16,<L146
	ldi R17,>L146
	rcall _checkCMD2
	mov R2,R16
	mov R3,R17
	mov R10,R2
	.dbline 298
; 								  
; 								  if (testCMD2==1){
	mov R24,R10
	cpi R24,1
	breq X12
	rjmp L147
X12:
	.dbline 298
	.dbline 299
; 							   	  	 writeLCD("      Connect...");
	ldi R16,<L53
	ldi R17,>L53
	rcall _writeLCD
	.dbline 300
; 								  	 delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 301
; 								  	 changeTone(PCM);
	ldi R16,3
	rcall _changeTone
	.dbline 303
; 						  		  	 // Loop Read/Write Data From PCM Filter
; 									 intFlag=1;  
	ldi R24,1
	sts _intFlag,R24
	.dbline 305
; 									 // clear ext int
; 									 GIMSK = 0;
	clr R2
	out 0x3b,R2
	.dbline 306
; 									 SEI();
	sei
	rjmp L150
L149:
	.dbline 307
	.dbline 308
	rcall _readPCM
	mov R2,R16
	mov R3,R17
	mov R12,R2
	.dbline 309
	mov R16,R12
	rcall _transmitUART
	.dbline 310
	ldi R16,255
	rcall _delayx
	.dbline 311
L150:
	.dbline 307
; 									 while(((PIND & 0x04)==0)&(hookFlag==0)){
	sbic 0x10,2
	rjmp L152
	ldi R22,1
	ldi R23,0
	rjmp L153
L152:
	clr R22
	clr R23
L153:
	lds R2,_hookFlag
	tst R2
	brne L154
	ldi R24,1
	ldi R25,0
	mov R14,R24
	mov R15,R25
	rjmp L155
L154:
	clr R14
	clr R15
L155:
	mov R2,R22
	mov R3,R23
	and R2,R14
	and R3,R15
	tst R2
	brne L149
	tst R3
	brne L149
	.dbline 312
; 									 	tempData=readPCM();
; 										transmitUART(tempData);
; 										delayx(0xFF);						  
; 									}
; 									CLI();
	cli
	.dbline 313
; 									GIMSK = (1<<INT0);
	ldi R24,64
	out 0x3b,R24
	.dbline 314
; 									if ((PIND & 0x04)==0) goto end_call2;
	sbic 0x10,2
	rjmp L156
	.dbline 314
	rjmp L158
L156:
	.dbline 315
; 									writeLCD("Please Hang Up!!");
	ldi R16,<L63
	ldi R17,>L63
	rcall _writeLCD
	.dbline 317
	rjmp L144
L147:
	.dbline 317
; 									
; 								 }else if (testCMD2==0){
	tst R10
	brne L159
	.dbline 317
	.dbline 318
; 								 	   writeLCD("         BUSY!!!");
	ldi R16,<L161
	ldi R17,>L161
	rcall _writeLCD
	.dbline 319
; 								  	   delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 320
; 									   changeTone(BUSY);
	ldi R16,2
	rcall _changeTone
	.dbline 322
	rjmp L144
L159:
	.dbline 322
; 								 	    
; 								 }else if (testCMD2==3){
	mov R24,R10
	cpi R24,3
	brne L144
	.dbline 322
	.dbline 323
; 								 	   goto end_call;
	rjmp L81
X1:
	.dbline 326
L143:
	.dbline 326
; 								 }
; 								 
; 							  }else if (testCMD==0){
	ldd R0,y+13
	tst R0
	brne L164
	.dbline 326
	.dbline 327
; 							       writeLCD("         BUSY!!!");
	ldi R16,<L161
	ldi R17,>L161
	rcall _writeLCD
	.dbline 328
; 								   delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 329
; 								   changeTone(BUSY);
	ldi R16,2
	rcall _changeTone
	.dbline 331
	rjmp L165
L164:
	.dbline 331
; 								   
; 							  }else if (testCMD==3) goto end_call;
	ldd R24,y+13
	cpi R24,3
	brne L166
	.dbline 331
	rjmp L81
L166:
L165:
L144:
	.dbline 333
; 							  
; 							  delay_loop(20);
	ldi R16,20
	rcall _delay_loop
L168:
	.dbline 335
	.dbline 335
L169:
	.dbline 335
; 						 check_hangup:	  
;     					      while (((PIND & 0x04)==0)){}
	sbis 0x10,2
	rjmp L168
L158:
	.dbline 337
; 						 end_call2:	  
; 	    					  writeLCD("      Disconnect");
	ldi R16,<L67
	ldi R17,>L67
	rcall _writeLCD
	.dbline 338
; 		        			  delay_loop(20);							  
	ldi R16,20
	rcall _delay_loop
L81:
	.dbline 342
; 							   						 
; 				  		 end_call:
; 						 
; 						 changeTone(PCM);
	ldi R16,3
	rcall _changeTone
	.dbline 343
; 						 intFlag=0;  
	clr R2
	sts _intFlag,R2
	.dbline 344
; 						 hookFlag=0;
	sts _hookFlag,R2
	.dbline 345
; 						 status=0;	/* clear status */
	sts _status,R2
	.dbline 346
; 						 writeLCD("        Ready...");
	ldi R16,<L23
	ldi R17,>L23
	rcall _writeLCD
	.dbline 347
; 						 delay_loop(40);  
	ldi R16,40
	rcall _delay_loop
	.dbline 348
; 						 PORTD |= 0x80;    //Set Pin BlackLight
	sbi 0x12,7
	.dbline 349
; 						 sendSTR("@H");
	ldi R16,<L68
	ldi R17,>L68
	rcall _sendSTR
	.dbline 350
; 						 transmitUART('\n');
	ldi R16,10
	rcall _transmitUART
	.dbline 351
; 				}
L70:
	.dbline 352
; 				SEI();   /* Enable Interrupt */
	sei
	.dbline 353
; 				break;
	.dbline 355
; 			default:  
; 				break;
L28:
	.dbline 357
L25:
	.dbline 98
	rjmp L24
X2:
	.dbline 359}
; 		}
; 	}                                                                                       
; 
; }
L1:
	adiw R28,16
	ret
	.dbsym r tempData2 20 c
	.dbsym r testCMD2 10 c
	.dbsym r tempData 12 c
	.dbsym l temp_tel_no 3 Ac[8:8]
	.dbsym l testCMD 13 c
	.dbsym r timeOut 10 c
	.dbsym l data_dtmf 12 c
	.dbsym l tel_no 2 c
	.dbsym l i 11 c
	.area vector(rom, abs)
	.org 22
	rjmp _uart0_rx_isr
	.area text(rom, con, rel)
	.dbfile C:\icc\work\VBox\vbox.c
	.dbfunc s uart0_rx_isr _uart0_rx_isr fI
;       dataRead -> R20
	.even
_uart0_rx_isr::
	rcall push_lset
	rcall push_gset1
	.dbline 364{
; /*------------------------------------------------------------*/
; 
; /* Interrupts handler Definitions */
; #pragma interrupt_handler uart0_rx_isr:12
; void uart0_rx_isr(void){
	.dbline 367
;  unsigned char dataRead;
;  //uart has received a character in UDR
;  if (intFlag==0){
	lds R2,_intFlag
	tst R2
	brne L172
	.dbline 367
	.dbline 368
;  	status = 1;        
	ldi R24,1
	sts _status,R24
	.dbline 369
;  	dataStatus = UDR;
	in R2,0xc
	sts _dataStatus,R2
	.dbline 370
	rjmp L173
L172:
	.dbline 370
;  }else{
	.dbline 371
;     dataRead = UDR;
	in R20,0xc
	.dbline 372
; 	if (dataRead=='@'){
	cpi R20,64
	brne L174
	.dbline 372
	.dbline 373
; 	   cmdFlag=1;
	ldi R24,1
	sts _cmdFlag,R24
	.dbline 374
; 	}
L174:
	.dbline 376
; 	
;  	if (cmdFlag==0){
	lds R2,_cmdFlag
	tst R2
	brne L176
	.dbline 376
	.dbline 377
; 		writePCM(dataRead);
	mov R16,R20
	rcall _writePCM
	.dbline 378
	rjmp L177
L176:
	.dbline 378
; 	}else{
	.dbline 379
; 		if (dataRead=='N'){
	cpi R20,78
	brne L178
	.dbline 379
	.dbline 380
; 		   hookFlag = 1;
	ldi R24,1
	sts _hookFlag,R24
	.dbline 381
	rjmp L179
L178:
	.dbline 381
; 		}else{
	.dbline 382
; 			  writePCM('@');
	ldi R16,64
	rcall _writePCM
	.dbline 383
; 			  writePCM(dataRead);
	mov R16,R20
	rcall _writePCM
	.dbline 384
; 		}
L179:
	.dbline 385
; 	} 
L177:
	.dbline 386
;  }
L173:
	.dbline 387}
; }
L171:
	rcall pop_gset1
	rcall pop_lset
	reti
	.dbsym r dataRead 20 c
	.area vector(rom, abs)
	.org 24
	rjmp _uart0_udre_isr
	.area text(rom, con, rel)
	.dbfile C:\icc\work\VBox\vbox.c
	.dbfunc s uart0_udre_isr _uart0_udre_isr fI
	.even
_uart0_udre_isr::
	st -y,R2
	in R2,0x3f
	st -y,R2
	.dbline 390{
; 
; #pragma interrupt_handler uart0_udre_isr:13
; void uart0_udre_isr(void){
	.dbline 392
;  //character transferred to shift register so UDR is now empty
;  status = 0;
	clr R2
	sts _status,R2
	.dbline 393}
; }
L180:
	ld R2,y+
	out 0x3f,R2
	ld R2,y+
	reti
	.area vector(rom, abs)
	.org 2
	rjmp _int0_isr
	.area text(rom, con, rel)
	.dbfile C:\icc\work\VBox\vbox.c
	.dbfunc s int0_isr _int0_isr fI
	.even
_int0_isr::
	st -y,R24
	in R24,0x3f
	st -y,R24
	.dbline 396{
; 
; #pragma interrupt_handler int0_isr:2
; void int0_isr(void){
	.dbline 398
;  //external interupt on INT0
;  status = 2;
	ldi R24,2
	sts _status,R24
	.dbline 399}
; }
L181:
	ld R24,y+
	out 0x3f,R24
	ld R24,y+
	reti
	.dbfunc s port_init _port_init fI
	.even
_port_init::
	.dbline 403{
; /*------------------------------------------------------------*/
; 
; /*  Prcedure Initial Definitions  */
; void port_init(void){
	.dbline 404
;  PORTA = 0x40;
	ldi R24,64
	out 0x1b,R24
	.dbline 405
;  DDRA = 0xBF;
	ldi R24,191
	out 0x1a,R24
	.dbline 406
;  PORTB = 0xDB;
	ldi R24,219
	out 0x18,R24
	.dbline 407
;  DDRB = 0xFB;
	ldi R24,251
	out 0x17,R24
	.dbline 408
;  PORTC = 0x00;
	clr R2
	out 0x15,R2
	.dbline 409
;  DDRC = 0x00;
	out 0x14,R2
	.dbline 410
;  PORTD = 0xCF;
	ldi R24,207
	out 0x12,R24
	.dbline 411
;  DDRD = 0xFB;
	ldi R24,251
	out 0x11,R24
	.dbline 412}
; }
L182:
	ret
	.dbfunc s uart0_init _uart0_init fI
	.even
_uart0_init::
	.dbline 420{
; 
; //void timer0_init(void){
; // TCCR0 = 0x00; //stop
; // TCNT0 = 0x00 /*INVALID SETTING*/; //set count
;  //TCCR0 = 0x00; //start timer, frequency = 0Hz
; //}
; 
; void uart0_init(void){
	.dbline 421
;  UCR  = 0x00; //disable while setting baud rate
	clr R2
	out 0xa,R2
	.dbline 422
;  UBRR = 0x33;		// Set baudrate 51 = 9600 bps
	ldi R24,51
	out 0x9,R24
	.dbline 423
;  UCR = ((1<<RXCIE)|(1<<RXEN)|(1<<TXEN));	// Set Control Register
	ldi R24,152
	out 0xa,R24
	.dbline 424}
; }
L183:
	ret
	.dbfunc s ext0_init _ext0_init fI
	.even
_ext0_init::
	.dbline 426{
; 
; void ext0_init(void){
	.dbline 427
;  GIMSK = (1<<INT0);
	ldi R24,64
	out 0x3b,R24
	.dbline 428
;  GIFR = (1<<INTF0);
	out 0x3a,R24
	.dbline 429
;  MCUCR = (1<<ISC01);
	ldi R24,2
	out 0x35,R24
	.dbline 430}
; }
L184:
	ret
	.dbfunc s init_devices _init_devices fI
	.even
_init_devices::
	.dbline 433{
; 
; //call this routine to initialise all peripherals
; void init_devices(void){
	.dbline 435
;  //stop errant interrupts until set up
;  CLI(); //disable all interrupts
	cli
	.dbline 436
;  port_init();
	rcall _port_init
	.dbline 438
; // timer0_init();
;  init_lcd();
	rcall _init_lcd
	.dbline 439
;  uart0_init();
	rcall _uart0_init
	.dbline 440
;  ext0_init();  
	rcall _ext0_init
	.dbline 444}
; // TIMSK = 0x00;
; 
;  //all peripherals are now initialised
; }
L185:
	ret
	.dbfunc s transmitUART _transmitUART fI
;           data -> R16
	.even
_transmitUART::
	.dbline 448{
; /*-------------------END---Procedure-Initial------------------*/
; 
; /* send data to PC */
; void transmitUART(unsigned char data){
L187:
	.dbline 449
L188:
	.dbline 449
; 	while(!(USR & (1<<UDRE)));                   
	sbis 0xb,5
	rjmp L187
	.dbline 450
; 	UDR = data;
	out 0xc,R16
	.dbline 451}
; }                                           
L186:
	ret
	.dbsym r data 16 c
	.dbfunc s receiveUART _receiveUART fI
	.even
_receiveUART::
	.dbline 452{
; unsigned char receiveUART(void){
L191:
	.dbline 453
L192:
	.dbline 453
; 	while(!(USR & (1<<RXC)));
	sbis 0xb,7
	rjmp L191
	.dbline 454
;    	return UDR;
	in R16,0xc
	clr R17
L190:
	ret
	.dbline 455}
	.dbfunc s init_lcd _init_lcd fI
	.even
_init_lcd::
	.dbline 459{
; }
; 
; /* LCD Function */
; 
; void init_lcd(void){
	.dbline 460
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 461
;   writeCmdLCD(0x33);
	ldi R16,51
	rcall _writeCmdLCD
	.dbline 462
;   delayx(0xFF);                       
	ldi R16,255
	rcall _delayx
	.dbline 463
;   writeCmdLCD(0x32);
	ldi R16,50
	rcall _writeCmdLCD
	.dbline 464
;   delayx(0xFF);                       
	ldi R16,255
	rcall _delayx
	.dbline 465
;   writeCmdLCD(0x38);
	ldi R16,56
	rcall _writeCmdLCD
	.dbline 466
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 467
;   writeCmdLCD(0x0F);
	ldi R16,15
	rcall _writeCmdLCD
	.dbline 468
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 469
;   writeCmdLCD(0x06);
	ldi R16,6
	rcall _writeCmdLCD
	.dbline 470
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 471
;   writeCmdLCD(0x01);
	ldi R16,1
	rcall _writeCmdLCD
	.dbline 472}
; }     
L194:
	ret
	.dbfunc s writeDataLCD _writeDataLCD fI
;        datalcd -> R20
	.even
_writeDataLCD::
	rcall push_gset1
	mov R20,R16
	.dbline 474{
; 
; void writeDataLCD(unsigned char datalcd){
	.dbline 475
;   PORTD |= 0x20;    //Set Pin RS
	sbi 0x12,5
	.dbline 476
;   PORTC = datalcd;
	out 0x15,R20
	.dbline 477
;   DDRC = 0xFF;
	ldi R24,255
	out 0x14,R24
	.dbline 478
;   latchLCD();
	rcall _latchLCD
	.dbline 479
;   PORTD &= 0xDF;   //Clear Pin RS
	in R24,0x12
	andi R24,223
	out 0x12,R24
	.dbline 480
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 481
;   PORTC = 0x00;
	clr R2
	out 0x15,R2
	.dbline 482
;   DDRC = 0x00;
	out 0x14,R2
	.dbline 483}
; }
L195:
	rcall pop_gset1
	ret
	.dbsym r datalcd 20 c
	.dbfunc s writeLCD _writeLCD fI
;              i -> R20
;         string -> R22,R23
	.even
_writeLCD::
	rcall push_gset2
	mov R22,R16
	mov R23,R17
	.dbline 485{
; 
; void writeLCD(const char *string){
	.dbline 487
;   unsigned char i;
;   i=0;
	clr R20
	.dbline 488
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 489
;   clearLCD();
	rcall _clearLCD
	.dbline 490
;   delayl(0xFF);
	ldi R16,255
	rcall _delayl
	rjmp L198
L197:
	.dbline 491
;   while (*string != '\0') {
	.dbline 492
;     i++;
	inc R20
	.dbline 493
; 	if (i==9) gotoxyLCD(0x40);
	cpi R20,9
	brne L200
	.dbline 493
	ldi R16,64
	rcall _gotoxyLCD
L200:
	.dbline 494
	mov R2,R22
	mov R3,R23
	subi R22,255  ; offset = 1
	sbci R23,255
	mov R30,R2
	mov R31,R3
	lpm
	mov R16,R0
	rcall _writeDataLCD
	.dbline 495
	ldi R16,255
	rcall _delayx
	.dbline 496
L198:
	.dbline 491
	mov R30,R22
	mov R31,R23
	lpm
	tst R0
	brne L197
	.dbline 497}
; 	writeDataLCD(*string++);
; 	delayx(0xFF);
;   }
; }
L196:
	rcall pop_gset2
	ret
	.dbsym r i 20 c
	.dbsym r string 22 pc
	.dbfunc s gotoxyLCD _gotoxyLCD fI
;          x_pos -> R20
	.even
_gotoxyLCD::
	rcall push_gset1
	mov R20,R16
	.dbline 499{
; 
; void gotoxyLCD(unsigned char x_pos){
	.dbline 500
;   x_pos = x_pos | 0x80;
	ori R20,128
	.dbline 501
;   PORTD &= 0xDF;      //Clear Pin RS
	in R24,0x12
	andi R24,223
	out 0x12,R24
	.dbline 502
;   PORTC = x_pos;
	out 0x15,R20
	.dbline 503
;   DDRC = 0xFF;
	ldi R24,255
	out 0x14,R24
	.dbline 504
;   latchLCD();
	rcall _latchLCD
	.dbline 505
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 506
;   PORTC = 0x00;
	clr R2
	out 0x15,R2
	.dbline 507
;   DDRC = 0x00;
	out 0x14,R2
	.dbline 508}
; }
L202:
	rcall pop_gset1
	ret
	.dbsym r x_pos 20 c
	.dbfunc s clearLCD _clearLCD fI
	.even
_clearLCD::
	.dbline 509{
; void clearLCD(void){
	.dbline 510
;   PORTD &= 0xDF;      //Clear Pin RS
	in R24,0x12
	andi R24,223
	out 0x12,R24
	.dbline 511
;   PORTC = 0x01;
	ldi R24,1
	out 0x15,R24
	.dbline 512
;   DDRC = 0xFF;
	ldi R24,255
	out 0x14,R24
	.dbline 513
;   latchLCD();
	rcall _latchLCD
	.dbline 514
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 515
;   PORTC = 0x02;
	ldi R24,2
	out 0x15,R24
	.dbline 516
;   latchLCD();
	rcall _latchLCD
	.dbline 517
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 518
;   PORTC = 0x00;
	clr R2
	out 0x15,R2
	.dbline 519
;   DDRC = 0x00;
	out 0x14,R2
	.dbline 520}
; }
L203:
	ret
	.dbfunc s writeCmdLCD _writeCmdLCD fI
;     datacmdlcd -> R20
	.even
_writeCmdLCD::
	rcall push_gset1
	mov R20,R16
	.dbline 522{
; 
; void writeCmdLCD(unsigned char datacmdlcd){     
	.dbline 523
;   PORTD &= 0xDF;      //Clear Pin RS
	in R24,0x12
	andi R24,223
	out 0x12,R24
	.dbline 524
;   PORTC = datacmdlcd;
	out 0x15,R20
	.dbline 525
;   DDRC = 0xFF;
	ldi R24,255
	out 0x14,R24
	.dbline 526
;   latchLCD();
	rcall _latchLCD
	.dbline 527
;   delayx(0xFF);
	ldi R16,255
	rcall _delayx
	.dbline 528
;   PORTC = 0x00;
	clr R2
	out 0x15,R2
	.dbline 529
;   DDRC = 0x00;
	out 0x14,R2
	.dbline 530}
; }
L204:
	rcall pop_gset1
	ret
	.dbsym r datacmdlcd 20 c
	.dbfunc s latchLCD _latchLCD fI
	.even
_latchLCD::
	.dbline 532{
; 
; void latchLCD(void){
	.dbline 533
;   PORTD &= 0xBF;   //Clear Pin E
	in R24,0x12
	andi R24,191
	out 0x12,R24
	.dbline 534
;   delayx(0xff);
	ldi R16,255
	rcall _delayx
	.dbline 535
;   PORTD |= 0x40;    //Set Pin E
	sbi 0x12,6
	.dbline 536}
; }
L205:
	ret
	.dbfunc s delayx _delayx fI
;              i -> R20
;          datax -> R16
	.even
_delayx::
	rcall push_gset1
	.dbline 538{
; 
; void delayx(unsigned char datax){
	.dbline 540
	clr R20
	rjmp L210
L207:
	.dbline 540
	.dbline 540
L208:
	.dbline 540
	inc R20
L210:
	.dbline 540
;   unsigned char i;
;   for (i=0;i<datax;i++) {}
	cp R20,R16
	brlo L207
	.dbline 541}
; }
L206:
	rcall pop_gset1
	ret
	.dbsym r i 20 c
	.dbsym r datax 16 c
	.dbfunc s delayl _delayl fI
;              i -> R20
;              j -> R22
;          datal -> R16
	.even
_delayl::
	rcall push_gset2
	.dbline 543{
; 
; void delayl(unsigned char datal){
	.dbline 545
	clr R20
	rjmp L215
L212:
	.dbline 545
;   unsigned char i,j;
;   for (i=0;i<datal;i++){
	.dbline 546
	clr R22
	rjmp L219
L216:
	.dbline 546
	.dbline 547
	nop
	.dbline 548
L217:
	.dbline 546
	inc R22
L219:
	.dbline 546
	cpi R22,250
	brlo L216
	.dbline 549
L213:
	.dbline 545
	inc R20
L215:
	.dbline 545
	cp R20,R16
	brlo L212
	.dbline 550}
;   	  for(j=0;j<250;j++){
; 	  	NOP();	
; 	  }
;   }
; }
L211:
	rcall pop_gset2
	ret
	.dbsym r i 20 c
	.dbsym r j 22 c
	.dbsym r datal 16 c
	.dbfunc s delay_loop _delay_loop fI
;              i -> R20
;           loop -> R22
	.even
_delay_loop::
	rcall push_gset2
	mov R22,R16
	.dbline 552{
; 
; void delay_loop(unsigned char loop){
	.dbline 554
	clr R20
	rjmp L224
L221:
	.dbline 554
	ldi R16,255
	rcall _delayl
L222:
	.dbline 554
	inc R20
L224:
	.dbline 554
; unsigned char i;
; 	for (i=0;i<loop;i++) delayl(0xFF);
	cp R20,R22
	brlo L221
	.dbline 555}
; }
L220:
	rcall pop_gset2
	ret
	.dbsym r i 20 c
	.dbsym r loop 22 c
	.dbfunc s checkCMD _checkCMD fI
;          value -> R20
;      tempCheck -> R22
;            cmd -> R10,R11
	.even
_checkCMD::
	rcall push_gset3
	mov R10,R16
	mov R11,R17
	.dbline 557{
; 
; unsigned char checkCMD(const char *cmd){
	.dbline 559
;     unsigned char tempCheck,value;
;     value = 1;
	ldi R20,1
	.dbline 560
; 	tempCheck=receiveUART();
	rcall _receiveUART
	mov R2,R16
	mov R3,R17
	mov R22,R2
	.dbline 561
; 	if (tempCheck != *cmd++){
	mov R2,R10
	mov R3,R11
	mov R24,R2
	mov R25,R3
	adiw R24,1
	mov R10,R24
	mov R11,R25
	mov R30,R2
	mov R31,R3
	lpm
	cp R22,R0
	breq L226
	.dbline 561
	.dbline 562
; 	   value = 0;
	clr R20
	.dbline 563
	rjmp L227
L226:
	.dbline 563
; 	}else{  
	.dbline 564
; 	   tempCheck=receiveUART();
	rcall _receiveUART
	mov R2,R16
	mov R3,R17
	mov R22,R2
	.dbline 565
; 	   if (tempCheck != *cmd){
	mov R30,R10
	mov R31,R11
	lpm
	cp R22,R0
	breq L228
	.dbline 565
	.dbline 566
; 	      value = 0;
	clr R20
	.dbline 567
; 	   }
L228:
	.dbline 568
; 	}
L227:
	.dbline 569
; 	return value;  
	mov R16,R20
	clr R17
L225:
	rcall pop_gset3
	ret
	.dbline 570}
	.dbsym r value 20 c
	.dbsym r tempCheck 22 c
	.dbsym r cmd 10 pc
	.dbfunc s checkCMD2 _checkCMD2 fI
;      tempCheck -> R22
;          value -> R20
;            cmd -> R16,R17
	.even
_checkCMD2::
	rcall push_gset3
	.dbline 572{
; }
; 
; unsigned char checkCMD2(const char *cmd){
	.dbline 574
;     unsigned char tempCheck,value;
;     value = 1;
	ldi R20,1
	rjmp L232
L231:
	.dbline 575
; 	while(!(USR & (1<<RXC))){
	.dbline 576
; 		if (!(PIND & 0x04)==0 ) goto not_check;
	sbic 0x10,2
	rjmp L236
	ldi R24,1
	ldi R25,0
	mov R10,R24
	mov R11,R25
	rjmp L237
L236:
	clr R10
	clr R11
L237:
	tst R10
	brne L234
	tst R11
	brne L234
	.dbline 576
	rjmp L238
L234:
	.dbline 577
L232:
	.dbline 575
	sbis 0xb,7
	rjmp L231
	.dbline 578
;     }
;    	tempCheck = UDR;
	in R22,0xc
	.dbline 580
; 
; 	if (tempCheck != *cmd++){
	mov R2,R16
	mov R3,R17
	subi R16,255  ; offset = 1
	sbci R17,255
	mov R30,R2
	mov R31,R3
	lpm
	cp R22,R0
	breq L242
	.dbline 580
	.dbline 581
; 	   value = 0;
	clr R20
	.dbline 582
	rjmp L250
X13:
	.dbline 582
; 	}else{  
L241:
	.dbline 583
; 		while(!(USR & (1<<RXC))){
	.dbline 584
; 			if (!(PIND & 0x04)==0 ) goto not_check;
	sbic 0x10,2
	rjmp L246
	ldi R24,1
	ldi R25,0
	mov R10,R24
	mov R11,R25
	rjmp L247
L246:
	clr R10
	clr R11
L247:
	tst R10
	brne L244
	tst R11
	brne L244
	.dbline 584
	rjmp L238
L244:
	.dbline 585
L242:
	.dbline 583
	sbis 0xb,7
	rjmp L241
	.dbline 586
;     	}
; 		tempCheck = UDR;
	in R22,0xc
	.dbline 587
; 	    if (tempCheck != *cmd){
	mov R30,R16
	mov R31,R17
	lpm
	cp R22,R0
	breq L250
	.dbline 587
	.dbline 588
; 	        value = 0;
	clr R20
	.dbline 589
; 	    }
	.dbline 590
; 	}
	.dbline 591
; 	goto end_checkCMD2;
	rjmp L250
L238:
	.dbline 593
; 	not_check:
; 		value = 3;
	ldi R20,3
L250:
	.dbline 596
; 	end_checkCMD2:
; 	
; 	return value;  
	mov R16,R20
	clr R17
L230:
	rcall pop_gset3
	ret
	.dbline 597}
	.dbsym r tempCheck 22 c
	.dbsym r value 20 c
	.dbsym r cmd 16 pc
	.dbfunc s sendSTR _sendSTR fI
;         string -> R20,R21
	.even
_sendSTR::
	rcall push_gset1
	mov R20,R16
	mov R21,R17
	.dbline 599{
; }
; 
; void sendSTR(const char *string){
	rjmp L253
L252:
	.dbline 600
	.dbline 601
	mov R2,R20
	mov R3,R21
	subi R20,255  ; offset = 1
	sbci R21,255
	mov R30,R2
	mov R31,R3
	lpm
	mov R16,R0
	rcall _transmitUART
	.dbline 602
L253:
	.dbline 600
;   while (*string != '\0') {
	mov R30,R20
	mov R31,R21
	lpm
	tst R0
	brne L252
	.dbline 603}
; 	transmitUART(*string++);
;   }
; }
L251:
	rcall pop_gset1
	ret
	.dbsym r string 20 pc
	.dbfunc s changeTone _changeTone fI
;           tone -> R20
	.even
_changeTone::
	rcall push_gset1
	mov R20,R16
	.dbline 606{
; 
; /* Control Busy Dial and RingBack Tone */
; void changeTone(unsigned char tone){
	.dbline 607
; 	if (tone==0) {
	tst R20
	brne L256
	.dbline 607
	.dbline 608
; 	    PORTB &= 0x3F;   //AX0 = 0;AX1 = 0;
	in R24,0x18
	andi R24,63
	out 0x18,R24
	.dbline 609
	rjmp L257
L256:
	.dbline 609
;  	}else if(tone==1){
	cpi R20,1
	brne L258
	.dbline 609
	.dbline 610
;  		PORTB |= 0x40;   //AX0 = 1;
	sbi 0x18,6
	.dbline 611
;  		PORTB &= 0x7F;   //AX1 = 0;
	in R24,0x18
	andi R24,127
	out 0x18,R24
	.dbline 612
	rjmp L259
L258:
	.dbline 612
;  	}else if(tone==2){
	cpi R20,2
	brne L260
	.dbline 612
	.dbline 613
; 		PORTB &= 0xBF;   //AX0 = 0;
	in R24,0x18
	andi R24,191
	out 0x18,R24
	.dbline 614
;  		PORTB |= 0x80;   //AX1 = 1; 	
	sbi 0x18,7
	.dbline 615
	rjmp L261
L260:
	.dbline 615
;  	}else{
	.dbline 616
; 		PORTB |= 0xC0;   //AX0 = 1;AX1 = 1;
	in R24,0x18
	ori R24,192
	out 0x18,R24
	.dbline 617
;  	}
L261:
L259:
L257:
	.dbline 619
;  	
; 	PORTB |= 0x20;   //CHTONE= 1; 
	sbi 0x18,5
	.dbline 620
;  	delayl(0xFF);
	ldi R16,255
	rcall _delayl
	.dbline 621
; 	PORTB &= 0xDF;	 //CHTONE= 0;change chanel MT8906BE(Analog Switch)
	in R24,0x18
	andi R24,223
	out 0x18,R24
	.dbline 622
;  	if (tone<3) 	 PORTB &= 0xEF; //CSTONE=0;Chip Select AT89C2051 to Generate Tone 
	cpi R20,3
	brsh L262
	.dbline 622
	in R24,0x18
	andi R24,239
	out 0x18,R24
	rjmp L263
L262:
	.dbline 623
; 	else	PORTB |= 0x10;//CSTONE=1;
	sbi 0x18,4
L263:
	.dbline 624}
; }
L255:
	rcall pop_gset1
	ret
	.dbsym r tone 20 c
	.dbfunc s readDTMF _readDTMF fI
;          value -> R20
	.even
_readDTMF::
	rcall push_gset1
	.dbline 626{
; 
; unsigned char readDTMF(void){
	.dbline 628
; 	unsigned char value;
; 	PORTA |= 0x80;   	//TOE= 1;
	sbi 0x1b,7
	.dbline 629
; 	PORTC = 0xFF;		//INPUT
	ldi R24,255
	out 0x15,R24
	.dbline 630
; 	DDRC = 0x00;
	clr R2
	out 0x14,R2
	.dbline 632
; 	
; 	delayx(0xFF);
	ldi R16,255
	rcall _delayx
	rjmp L266
L265:
	.dbline 633
; 	while(1){
	.dbline 634
; 		if (!((PINA & 0x40)==0)){
	sbis 0x19,6
	rjmp L268
	.dbline 634
	.dbline 635
; 		   value = PINC;
	in R20,0x13
	.dbline 636
; 		   value &= 0x0F;
	andi R20,15
	rjmp L271
L270:
	.dbline 637
	.dbline 638
	nop
	.dbline 639
L271:
	.dbline 637
; 		   while (!((PINA & 0x40)==0)){
	sbic 0x19,6
	rjmp L270
	.dbline 640
; 		   		 NOP();
; 		   }
; 		   if(value<=0x09){
	ldi R24,9
	cp R24,R20
	brlo L273
	.dbline 640
	.dbline 641
; 			  value += 0x30;
	subi R20,208	; addi 48
	.dbline 642
	rjmp L281
L273:
	.dbline 642
; 		   }else if(value==0x0A){
	cpi R20,10
	brne L275
	.dbline 642
	.dbline 643
; 		   	  value = 0x30;
	ldi R20,48
	.dbline 644
	rjmp L281
L275:
	.dbline 644
; 		   }else if(value==0x0B){
	cpi R20,11
	brne L277
	.dbline 644
	.dbline 645
; 			  value = 0x2A;
	ldi R20,42
	.dbline 646
	rjmp L281
L277:
	.dbline 646
; 		   }else if(value==0x0C){
	cpi R20,12
	brne L281
	.dbline 646
	.dbline 647
; 			  value = 0x23;
	ldi R20,35
	.dbline 648
; 		   }
	.dbline 649
; 		   goto end_readDTMF;
	rjmp L281
L268:
	.dbline 650
; 		}else if (!((PIND & 0x04)==0)){
	sbis 0x10,2
	rjmp L282
	.dbline 650
	.dbline 651
; 		   value = 0xF0;
	ldi R20,240
	.dbline 652
; 		   goto end_readDTMF;
	rjmp L281
L282:
	.dbline 654
L266:
	.dbline 633
	rjmp L265
L281:
	.dbline 657
; 		}
; 	}
; 	end_readDTMF:
; 	
; 	PORTA &= 0x7F;	 //TOE= 0;
	in R24,0x1b
	andi R24,127
	out 0x1b,R24
	.dbline 658
; 	PORTC = 0x00;
	clr R2
	out 0x15,R2
	.dbline 659
; 	DDRC = 0x00;
	out 0x14,R2
	.dbline 660
; 	delayx(0xFF);	
	ldi R16,255
	rcall _delayx
	.dbline 661
; 	return value;
	mov R16,R20
	clr R17
L264:
	rcall pop_gset1
	ret
	.dbline 662}
	.dbsym r value 20 c
	.dbfunc s writePCM _writePCM fI
;           data -> R20
	.even
_writePCM::
	rcall push_gset1
	mov R20,R16
	.dbline 664{
; }
; 
; void writePCM(unsigned char data){
	.dbline 665
; 	PORTA &= 0xC0;   //A0 to A5 = 0;
	in R24,0x1b
	andi R24,192
	out 0x1b,R24
	.dbline 666
; 	PORTA |= 0x01;   //A0 = 1;
	sbi 0x1b,0
	.dbline 667
; 	delayx(0x10);
	ldi R16,16
	rcall _delayx
	.dbline 669
; 	
; 	PORTB |= 0x02;   //OE = 1;
	sbi 0x18,1
	.dbline 670
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 671
; 	PORTB &= 0xFE;   //CS = 0
	in R24,0x18
	andi R24,254
	out 0x18,R24
	.dbline 672
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 673
; 	PORTB &= 0xF7;   //R/W = 0
	in R24,0x18
	andi R24,247
	out 0x18,R24
	.dbline 675
; 
; 	DDRC = 0xFF;     //Set PINC = OUTPUT
	ldi R24,255
	out 0x14,R24
L285:
	.dbline 676
	.dbline 676
L286:
	.dbline 676
; 	while ((PINB & 0x04)==0){} 
	sbis 0x16,2
	rjmp L285
	.dbline 677
; 	PORTC = data;
	out 0x15,R20
	.dbline 678
; 	delayx(0x10);
	ldi R16,16
	rcall _delayx
	.dbline 680
; 	
; 	PORTB |= 0x04;   //R/W = 1;
	sbi 0x18,2
	.dbline 681
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 682
; 	PORTB |= 0x01;   //CS = 1
	sbi 0x18,0
	.dbline 683
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 685
; 	
;     PORTA &= 0xC0;   //A0 to A5 = 0;
	in R24,0x1b
	andi R24,192
	out 0x1b,R24
	.dbline 686
; 	PORTC = 0x00;	//Set PINC = Hiz
	clr R2
	out 0x15,R2
	.dbline 687
; 	DDRC = 0x00;
	out 0x14,R2
	.dbline 688}
; }
L284:
	rcall pop_gset1
	ret
	.dbsym r data 20 c
	.dbfunc s readPCM _readPCM fI
;           data -> R20
	.even
_readPCM::
	rcall push_gset1
	.dbline 690{
; 
; unsigned char readPCM(void){
	.dbline 692
; 	unsigned char data;
; 	PORTA &= 0xC0;   //A0 to A5 = 0;
	in R24,0x1b
	andi R24,192
	out 0x1b,R24
	.dbline 693
; 	delayx(0x10);
	ldi R16,16
	rcall _delayx
	.dbline 694
; 	PORTB |= 0x08;   //R/W = 1
	sbi 0x18,3
	.dbline 695
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 696
; 	PORTB &= 0xFE;   //CS = 0
	in R24,0x18
	andi R24,254
	out 0x18,R24
	.dbline 697
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 698
; 	PORTB &= 0xFD;   //OE = 0;
	in R24,0x18
	andi R24,253
	out 0x18,R24
	.dbline 700
; 
; 	PORTC = 0xFF;	 //Set PINC = INPUT
	ldi R24,255
	out 0x15,R24
	.dbline 701
; 	DDRC = 0x00;
	clr R2
	out 0x14,R2
L289:
	.dbline 702
	.dbline 702
L290:
	.dbline 702
; 	while ((PINB & 0x04)==0){} 
	sbis 0x16,2
	rjmp L289
	.dbline 703
; 	data = PINC;
	in R20,0x13
	.dbline 704
; 	delayx(0x10);
	ldi R16,16
	rcall _delayx
	.dbline 706
; 	
; 	PORTB |= 0x02;   //OE = 1;
	sbi 0x18,1
	.dbline 707
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 708
; 	PORTB |= 0x01;   //CS = 1
	sbi 0x18,0
	.dbline 709
; 	delayx(0x20);
	ldi R16,32
	rcall _delayx
	.dbline 711
; 
; 	PORTC = 0x00;	//Set PINC = Hiz
	clr R2
	out 0x15,R2
	.dbline 712
; 	DDRC = 0x00;
	out 0x14,R2
	.dbline 713
; 	return data;
	mov R16,R20
	clr R17
L288:
	rcall pop_gset1
	ret
	.dbline 714}
	.dbsym r data 20 c
	.area bss(ram, con, rel)
	.dbfile C:\icc\work\VBox\vbox.c
_hookFlag:
	.blkb 1
	.dbsym s hookFlag _hookFlag c
_intFlag:
	.blkb 1
	.dbsym s intFlag _intFlag c
_cmdFlag:
	.blkb 1
	.dbsym s cmdFlag _cmdFlag c
_dataStatus:
	.blkb 1
	.dbsym s dataStatus _dataStatus c
_status:
	.blkb 1
	.dbsym s status _status c
	.area lit(rom, con, rel)
L161:
	.byte 32,32,32,32,32,32,32,32,32,'B,'U,'S,'Y,33,33,33
	.byte 0
L146:
	.byte 64,'O,0
L145:
	.byte 32,32,32,32,32,32,'C,'a,'l,'l,'i,'n,'g,46,46,46
	.byte 0
L142:
	.byte 64,'L,0
L141:
	.byte 32,32,32,32,'W,'a,'i,'t,32,'C,'a,'l,'l,46,46,46
	.byte 0
L136:
	.byte 64,'C,0
L135:
	.byte 32,32,32,'E,'x,'i,'t,32,32,'S,'e,'t,'t,'i,'n,'g
	.byte 0
L134:
	.byte 'P,'l,'e,'a,'s,'e,32,32,'R,'e,'s,'e,'t,33,33,33
	.byte 0
L130:
	.byte 'S,'e,'t,'t,'i,'n,'g,32,'C,'o,'m,'p,'l,'e,'t,'e
	.byte 0
L116:
	.byte 'N,'o,46,32,'S,'e,'t,58,0
L115:
	.byte 32,32,32,32,32,32,'S,'e,'t,'t,'i,'n,'g,46,46,46
	.byte 0
L101:
	.byte 32,'E,'r,'r,'o,'r,32,'S,'e,'t,'t,'i,'n,'g,33,33
	.byte 0
L72:
	.byte 'C,'a,'l,'l,32,58,0
L68:
	.byte 64,'H,0
L67:
	.byte 32,32,32,32,32,32,'D,'i,'s,'c,'o,'n,'n,'e,'c,'t
	.byte 0
L63:
	.byte 'P,'l,'e,'a,'s,'e,32,'H,'a,'n,'g,32,'U,'p,33,33
	.byte 0
L53:
	.byte 32,32,32,32,32,32,'C,'o,'n,'n,'e,'c,'t,46,46,46
	.byte 0
L52:
	.byte 64,'A,0
L51:
	.byte 32,32,32,32,32,32,'T,'i,'m,'e,32,'O,'u,'t,33,33
	.byte 0
L50:
	.byte 64,'I,0
L35:
	.byte 32,32,32,32,32,32,'R,'e,'c,'e,'i,'v,'e,46,46,46
	.byte 0
L23:
	.byte 32,32,32,32,32,32,32,32,'R,'e,'a,'d,'y,46,46,46
	.byte 0
L12:
	.byte 64,'D,0
L11:
	.byte 'E,'r,'r,'o,'r,32,'C,'o,'n,'n,'e,'c,'t,'i,'o,'n
	.byte 0
L8:
	.byte 64,'K,0
L7:
	.byte 32,32,32,32,32,32,'W,'a,'i,'t,'i,'n,'g,46,46,46
	.byte 0
L6:
	.byte 'C,'h,'e,'c,'k,32,'C,'o,'n,'n,'e,'c,'t,'i,'o,'n
	.byte 0
L2:
	.byte 32,32,'V,'B,'o,'x,32,32,32,'V,32,49,46,48,32,32
	.byte 0
