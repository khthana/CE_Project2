CC = iccavr
CFLAGS =  -IC:\ICC\include\ -e  -l -g -Wa-W -Wf-str_in_flash 
LFLAGS =  -LC:\ICC\lib\ -m -g -dram_end:0x25f -bdata:0x60.0x25f -Wl-W -bfunc_lit:0x22.0x2000 -dhwstk_size:16 -beeprom:1.512 -fihx_coff
FILES = vbox.o 

VBox:	$(FILES)
	$(CC) -o VBox $(LFLAGS) @VBox.lk 
vbox.o: C:\icc\work\VBox/defbit.h
vbox.o:	C:\icc\work\VBox\vbox.c
	$(CC) -c $(CFLAGS) C:\icc\work\VBox\vbox.c
