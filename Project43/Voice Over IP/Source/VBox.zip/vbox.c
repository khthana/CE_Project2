//ICC-AVR application builder : 3/3/2001 20:23:27

// Target: AT90S8535

//ICC needs these helper files...
#include <io8535.h>
#include <macros.h>
#include <string.h>
#include <eeprom.h>
#include "defbit.h"

/* Constant Definitions */
#define SET_RS  PORTD |= 0x20    
#define CLR_RS  PORTD &= 0xDF
#define DIAL    	0
#define RINGBACK    1
#define BUSY		2
#define PCM		3
#define MAXTIMECALL 5
#define MAXNO		7


/* Variable definitions */
static unsigned char status;          
static unsigned char dataStatus;
static unsigned char cmdFlag;
static unsigned char intFlag;
static unsigned char hookFlag;

/* Prototype Definitions */
/* Procedures */
void port_init(void);
//void timer0_init(void);
void uart0_init(void);
void init_devices(void);
void transmitUART(unsigned char data);
void init_lcd(void);
void clearLCD(void);
void gotoxyLCD(unsigned char x_pos);
void writeLCD(const char *string);
void writeDataLCD(unsigned char datalcd);   
void writeCmdLCD(unsigned char datacmdlcd);     
void latchLCD(void);
void delayx(unsigned char datax);
void delayl(unsigned char datal);
void delay_loop(unsigned char loop);
void sendSTR(const char *string);
void changeTone(unsigned char tone);
void writePCM(unsigned char data);
/*--------------END-PROCEDURE-DEFINITIONS---------------------*/

/* Functions */
unsigned char receiveUART(void);
unsigned char checkCMD(const char *cmd);
unsigned char checkCMD2(const char *cmd);
unsigned char readDTMF(void);
unsigned char readPCM(void);
/*--------------END-FUNCTION-DEFINITIONS----------------------*/

/* Main Program */
void main(void){
	unsigned char tempData,tempData2,testCMD,testCMD2,timeOut,i,data_dtmf,tel_no;
	unsigned char temp_tel_no[8];

	delayl(0xFF);
	init_devices();
	PORTD &= 0x7F;   //Clear Pin BlackLight
	delay_loop(5);
	writeLCD("  VBox   V 1.0  "); //writeLCD("                ");

	testCMD=0;
	cmdFlag=0;
	intFlag=0;
	hookFlag = 0;
	
	while(testCMD==0){
       delay_loop(40);
  	   writeLCD("Check Connection");
	   delay_loop(40);
	   writeLCD("      Waiting...");
	   testCMD=checkCMD("@K");
	   if (testCMD==0) writeLCD("Error Connection"); //False connection 
	}
	// read eeprom,it is No Tel of VBox
	
	sendSTR("@D");  //send ID to PC for register
	for (i=1;i<=MAXNO;i++){
		EEPROM_READ(i,tel_no);
		if (!((tel_no>=0x30)&(tel_no<=0x39))) tel_no=0x30;
		transmitUART(tel_no); 	
	}
	transmitUART('\n');
	
    writeLCD("        Ready...");
	delay_loop(40);  
	PORTD |= 0x80;    //Set Pin BlackLight
	SEI();   /* Enable Interrupt */
	while(1){
		switch(status){
			case 1 :
				CLI();  /* Disable Interrrupt */
				if (dataStatus=='@'){     //Caller
					tempData = receiveUART();   /* Check Command Charecter */ 
				   	if (tempData=='R'){
					   PORTD &= 0x7F;   //Clear Pin BlackLight
					   delayx(0xFF);					   
				       writeLCD("      Receive...");
					   delayx(0xFF);
					   
					   timeOut=1;
					   while(timeOut<=MAXTIMECALL){
					   		PORTD |= 0x10;   //Set Pin RC
							delay_loop(25);
							PORTD &= 0xEF;   //Clear Pin RC
							delay_loop(10);
							if ((PIND & 0x04)==0 ) goto end_ring;
							delay_loop(10);
					   		PORTD |= 0x10;   //Set Pin RC
							delay_loop(25);
							PORTD &= 0xEF;   //Clear Pin RC
							for (i=0;i<6;i++){
								delay_loop(10);
								if ((PIND & 0x04)==0 ) goto end_ring;
							}
							timeOut++;
					   }
					   end_ring:
					   if (timeOut>MAXTIMECALL){
					   	  sendSTR("@I"); //send TimeOut Status
						  transmitUART('\n');
						  writeLCD("      Time Out!!");
					   }else{
					   	  sendSTR("@A"); //send Receive Status
						  transmitUART('\n');
						  writeLCD("      Connect...");
						  delayl(0xFF);
						  changeTone(PCM);
						  delayl(0xFF);
						  
						  intFlag=1;
						    
						  // clear ext int 
						  GIMSK = 0;
						  SEI();
						  
						  while(((PIND & 0x04)==0)&(hookFlag==0)){
								tempData=readPCM();
								transmitUART(tempData);
								delayx(0xFF);						  
						  }
						  
						  CLI();
						  GIMSK = (1<<INT0);
						  if (hookFlag==1){
						  	 changeTone(BUSY);
							 writeLCD("Please Hang Up!!");
							 while (((PIND & 0x04)==0)){}
						  	 hookFlag=0;
						  }
						  writeLCD("      Disconnect");
						  delay_loop(20);
					   }    
					}
				}else{                           
					delayx(0xFF);
				}              
				status=0;	/* clear status */
				intFlag=0;
				writeLCD("        Ready...");
				delay_loop(20);  
				PORTD |= 0x80;    //Set Pin BlackLight
				sendSTR("@H"); 
				transmitUART('\n');
				SEI();   /* Enable Interrupt */
				break;
			case 2 :   
				CLI();    /* offHook from Phone */
				if((PIND & 0x04)==0){
						 PORTD &= 0x7F;   //Clear Pin BlackLight
						 delayl(0xFF);
						 writeLCD("Call :");
						 delayl(0xFF);
						 changeTone(DIAL);
						 data_dtmf = 0;
						 timeOut = 0;
						 gotoxyLCD(0x41);
						 
						 while (1){
						 	   if (timeOut==MAXNO){
							      writeDataLCD(data_dtmf);
								  temp_tel_no[timeOut]=data_dtmf;
								  delay_loop(20); 
							   	  goto end_check_dtmf;
							   }
							   
							   data_dtmf = readDTMF();
							   changeTone(PCM);
							   if (data_dtmf==0xF0) goto end_call;
							   else if ((data_dtmf=='*')&(timeOut==0)){
							      writeDataLCD(data_dtmf);
								  delayx(100); 
							      goto setting_Tel_No;
							   }
							   if ((data_dtmf>=0x30)&(data_dtmf<=0x39)){				   
							   	  writeDataLCD(data_dtmf);
								  temp_tel_no[timeOut]=data_dtmf;
					  		   	  delayx(100);
							   	  timeOut++;
							   }
						 }
		 				 setting_Tel_No:
						       data_dtmf = readDTMF();
							   if ((data_dtmf==0xF0)|(!(data_dtmf=='1'))){
							       writeLCD(" Error Setting!!");
								   delay_loop(30);
								   writeLCD("Please Hang Up!!");
							   	   goto check_hangup;
							   }
     						   writeDataLCD(data_dtmf);delayx(100); 
						       data_dtmf = readDTMF();
							   if ((data_dtmf==0xF0)|(!(data_dtmf=='0'))){
							   	   writeLCD(" Error Setting!!");
								   delay_loop(30);
								   writeLCD("Please Hang Up!!");
							   	   goto check_hangup;
							   }
							   writeDataLCD(data_dtmf);delayx(100);
							   data_dtmf = readDTMF();
							   if ((data_dtmf==0xF0)|(!(data_dtmf=='#'))){
							   	   writeLCD(" Error Setting!!");
								   delay_loop(30);
								   writeLCD("Please Hang Up!!");
							   	   goto check_hangup;
							   }
							   writeDataLCD(data_dtmf);delay_loop(20);
							   
						 	   // write eeprom,it is No Tel of VBox
							   writeLCD("      Setting...");
							   delay_loop(20);
							   writeLCD("No. Set:");
							   delayl(0xFF);
							   gotoxyLCD(0x41);
							   delayl(0xFF);
							   timeOut=1;
							   
							   while (1){
							   		 data_dtmf=readDTMF();
							   		 writeDataLCD(data_dtmf);delayx(100);
							   		 if (timeOut==MAXNO){
									    temp_tel_no[timeOut++]=data_dtmf;
									 	delay_loop(20);
									  	goto set_eeprom;
									 }
									 if (data_dtmf==0xF0) goto exit_setting;
									 temp_tel_no[timeOut++]=data_dtmf;
									 
							   } 
							   set_eeprom:
							   		delay_loop(10);
							   		for (i=1;i<=(MAXNO+1);i++){
										tel_no = temp_tel_no[i];
										EEPROM_WRITE(i,tel_no);	
									}
							   writeLCD("Setting Complete");
							   delay_loop(30);

							   while(1){
							   			writeLCD("Please  Reset!!!");
							   }
							   
							   exit_setting:
	    					   writeLCD("   Exit  Setting");
		        			   delay_loop(30);
							   goto end_call;
							   
						 end_check_dtmf:
						 	   sendSTR("@C"); //sendnumber
							   				  //No
							   for (i=0;i<MAXNO;i++){
							       tel_no=temp_tel_no[i];
							   	   transmitUART(tel_no); 	
							   }
							   transmitUART('\n');
							   delayx(0xFF);
							   writeLCD("    Wait Call...");
							   delayl(0xFF);
							   testCMD=checkCMD2("@L"); //bug here
							   							   
							   /* Check Command Charecter */
							   // wait status @O connect complete @N Busy
							   if (testCMD==1){
							      writeLCD("      Calling...");
							      delayl(0xFF);
								  changeTone(RINGBACK);
								  delayx(0xFF);
							      testCMD2=checkCMD2("@O");
								  
								  if (testCMD2==1){
							   	  	 writeLCD("      Connect...");
								  	 delayl(0xFF);
								  	 changeTone(PCM);
						  		  	 // Loop Read/Write Data From PCM Filter
									 intFlag=1;  
									 // clear ext int
									 GIMSK = 0;
									 SEI();
									 while(((PIND & 0x04)==0)&(hookFlag==0)){
									 	tempData=readPCM();
										transmitUART(tempData);
										delayx(0xFF);						  
									}
									CLI();
									GIMSK = (1<<INT0);
									if ((PIND & 0x04)==0) goto end_call2;
									writeLCD("Please Hang Up!!");
									
								 }else if (testCMD2==0){
								 	   writeLCD("         BUSY!!!");
								  	   delayl(0xFF);
									   changeTone(BUSY);
								 	    
								 }else if (testCMD2==3){
								 	   goto end_call;
								 }
								 
							  }else if (testCMD==0){
							       writeLCD("         BUSY!!!");
								   delayl(0xFF);
								   changeTone(BUSY);
								   
							  }else if (testCMD==3) goto end_call;
							  
							  delay_loop(20);
						 check_hangup:	  
    					      while (((PIND & 0x04)==0)){}
						 end_call2:	  
	    					  writeLCD("      Disconnect");
		        			  delay_loop(20);							  
							   						 
				  		 end_call:
						 
						 changeTone(PCM);
						 intFlag=0;  
						 hookFlag=0;
						 status=0;	/* clear status */
						 writeLCD("        Ready...");
						 delay_loop(40);  
						 PORTD |= 0x80;    //Set Pin BlackLight
						 sendSTR("@H");
						 transmitUART('\n');
				}
				SEI();   /* Enable Interrupt */
				break;
			default:  
				break;
		}
	}                                                                                       

}
/*------------------------------------------------------------*/

/* Interrupts handler Definitions */
#pragma interrupt_handler uart0_rx_isr:12
void uart0_rx_isr(void){
 unsigned char dataRead;
 //uart has received a character in UDR
 if (intFlag==0){
 	status = 1;        
 	dataStatus = UDR;
 }else{
    dataRead = UDR;
	if (dataRead=='@'){
	   cmdFlag=1;
	}
	
 	if (cmdFlag==0){
		writePCM(dataRead);
	}else{
		if (dataRead=='N'){
		   hookFlag = 1;
		}else{
			  writePCM('@');
			  writePCM(dataRead);
		}
	} 
 }
}

#pragma interrupt_handler uart0_udre_isr:13
void uart0_udre_isr(void){
 //character transferred to shift register so UDR is now empty
 status = 0;
}

#pragma interrupt_handler int0_isr:2
void int0_isr(void){
 //external interupt on INT0
 status = 2;
}
/*------------------------------------------------------------*/

/*  Prcedure Initial Definitions  */
void port_init(void){
 PORTA = 0x40;
 DDRA = 0xBF;
 PORTB = 0xDB;
 DDRB = 0xFB;
 PORTC = 0x00;
 DDRC = 0x00;
 PORTD = 0xCF;
 DDRD = 0xFB;
}

//void timer0_init(void){
// TCCR0 = 0x00; //stop
// TCNT0 = 0x00 /*INVALID SETTING*/; //set count
 //TCCR0 = 0x00; //start timer, frequency = 0Hz
//}

void uart0_init(void){
 UCR  = 0x00; //disable while setting baud rate
 UBRR = 0x33;		// Set baudrate 51 = 9600 bps
 UCR = ((1<<RXCIE)|(1<<RXEN)|(1<<TXEN));	// Set Control Register
}

void ext0_init(void){
 GIMSK = (1<<INT0);
 GIFR = (1<<INTF0);
 MCUCR = (1<<ISC01);
}

//call this routine to initialise all peripherals
void init_devices(void){
 //stop errant interrupts until set up
 CLI(); //disable all interrupts
 port_init();
// timer0_init();
 init_lcd();
 uart0_init();
 ext0_init();  
// TIMSK = 0x00;

 //all peripherals are now initialised
}
/*-------------------END---Procedure-Initial------------------*/

/* send data to PC */
void transmitUART(unsigned char data){
	while(!(USR & (1<<UDRE)));                   
	UDR = data;
}                                           
unsigned char receiveUART(void){
	while(!(USR & (1<<RXC)));
   	return UDR;
}

/* LCD Function */

void init_lcd(void){
  delayx(0xFF);
  writeCmdLCD(0x33);
  delayx(0xFF);                       
  writeCmdLCD(0x32);
  delayx(0xFF);                       
  writeCmdLCD(0x38);
  delayx(0xFF);
  writeCmdLCD(0x0F);
  delayx(0xFF);
  writeCmdLCD(0x06);
  delayx(0xFF);
  writeCmdLCD(0x01);
}     

void writeDataLCD(unsigned char datalcd){
  PORTD |= 0x20;    //Set Pin RS
  PORTC = datalcd;
  DDRC = 0xFF;
  latchLCD();
  PORTD &= 0xDF;   //Clear Pin RS
  delayx(0xFF);
  PORTC = 0x00;
  DDRC = 0x00;
}

void writeLCD(const char *string){
  unsigned char i;
  i=0;
  delayx(0xFF);
  clearLCD();
  delayl(0xFF);
  while (*string != '\0') {
    i++;
	if (i==9) gotoxyLCD(0x40);
	writeDataLCD(*string++);
	delayx(0xFF);
  }
}

void gotoxyLCD(unsigned char x_pos){
  x_pos = x_pos | 0x80;
  PORTD &= 0xDF;      //Clear Pin RS
  PORTC = x_pos;
  DDRC = 0xFF;
  latchLCD();
  delayx(0xFF);
  PORTC = 0x00;
  DDRC = 0x00;
}
void clearLCD(void){
  PORTD &= 0xDF;      //Clear Pin RS
  PORTC = 0x01;
  DDRC = 0xFF;
  latchLCD();
  delayx(0xFF);
  PORTC = 0x02;
  latchLCD();
  delayx(0xFF);
  PORTC = 0x00;
  DDRC = 0x00;
}

void writeCmdLCD(unsigned char datacmdlcd){     
  PORTD &= 0xDF;      //Clear Pin RS
  PORTC = datacmdlcd;
  DDRC = 0xFF;
  latchLCD();
  delayx(0xFF);
  PORTC = 0x00;
  DDRC = 0x00;
}

void latchLCD(void){
  PORTD &= 0xBF;   //Clear Pin E
  delayx(0xff);
  PORTD |= 0x40;    //Set Pin E
}

void delayx(unsigned char datax){
  unsigned char i;
  for (i=0;i<datax;i++) {}
}

void delayl(unsigned char datal){
  unsigned char i,j;
  for (i=0;i<datal;i++){
  	  for(j=0;j<250;j++){
	  	NOP();	
	  }
  }
}

void delay_loop(unsigned char loop){
unsigned char i;
	for (i=0;i<loop;i++) delayl(0xFF);
}

unsigned char checkCMD(const char *cmd){
    unsigned char tempCheck,value;
    value = 1;
	tempCheck=receiveUART();
	if (tempCheck != *cmd++){
	   value = 0;
	}else{  
	   tempCheck=receiveUART();
	   if (tempCheck != *cmd){
	      value = 0;
	   }
	}
	return value;  
}

unsigned char checkCMD2(const char *cmd){
    unsigned char tempCheck,value;
    value = 1;
	while(!(USR & (1<<RXC))){
		if (!(PIND & 0x04)==0 ) goto not_check;
    }
   	tempCheck = UDR;

	if (tempCheck != *cmd++){
	   value = 0;
	}else{  
		while(!(USR & (1<<RXC))){
			if (!(PIND & 0x04)==0 ) goto not_check;
    	}
		tempCheck = UDR;
	    if (tempCheck != *cmd){
	        value = 0;
	    }
	}
	goto end_checkCMD2;
	not_check:
		value = 3;
	end_checkCMD2:
	
	return value;  
}

void sendSTR(const char *string){
  while (*string != '\0') {
	transmitUART(*string++);
  }
}

/* Control Busy Dial and RingBack Tone */
void changeTone(unsigned char tone){
	if (tone==0) {
	    PORTB &= 0x3F;   //AX0 = 0;AX1 = 0;
 	}else if(tone==1){
 		PORTB |= 0x40;   //AX0 = 1;
 		PORTB &= 0x7F;   //AX1 = 0;
 	}else if(tone==2){
		PORTB &= 0xBF;   //AX0 = 0;
 		PORTB |= 0x80;   //AX1 = 1; 	
 	}else{
		PORTB |= 0xC0;   //AX0 = 1;AX1 = 1;
 	}
 	
	PORTB |= 0x20;   //CHTONE= 1; 
 	delayl(0xFF);
	PORTB &= 0xDF;	 //CHTONE= 0;change chanel MT8906BE(Analog Switch)
 	if (tone<3) 	 PORTB &= 0xEF; //CSTONE=0;Chip Select AT89C2051 to Generate Tone 
	else	PORTB |= 0x10;//CSTONE=1;
}

unsigned char readDTMF(void){
	unsigned char value;
	PORTA |= 0x80;   	//TOE= 1;
	PORTC = 0xFF;		//INPUT
	DDRC = 0x00;
	
	delayx(0xFF);
	while(1){
		if (!((PINA & 0x40)==0)){
		   value = PINC;
		   value &= 0x0F;
		   while (!((PINA & 0x40)==0)){
		   		 NOP();
		   }
		   if(value<=0x09){
			  value += 0x30;
		   }else if(value==0x0A){
		   	  value = 0x30;
		   }else if(value==0x0B){
			  value = 0x2A;
		   }else if(value==0x0C){
			  value = 0x23;
		   }
		   goto end_readDTMF;
		}else if (!((PIND & 0x04)==0)){
		   value = 0xF0;
		   goto end_readDTMF;
		}
	}
	end_readDTMF:
	
	PORTA &= 0x7F;	 //TOE= 0;
	PORTC = 0x00;
	DDRC = 0x00;
	delayx(0xFF);	
	return value;
}

void writePCM(unsigned char data){
	PORTA &= 0xC0;   //A0 to A5 = 0;
	PORTA |= 0x01;   //A0 = 1;
	delayx(0x10);
	
	PORTB |= 0x02;   //OE = 1;
	delayx(0x20);
	PORTB &= 0xFE;   //CS = 0
	delayx(0x20);
	PORTB &= 0xF7;   //R/W = 0

	DDRC = 0xFF;     //Set PINC = OUTPUT
	while ((PINB & 0x04)==0){} 
	PORTC = data;
	delayx(0x10);
	
	PORTB |= 0x04;   //R/W = 1;
	delayx(0x20);
	PORTB |= 0x01;   //CS = 1
	delayx(0x20);
	
    PORTA &= 0xC0;   //A0 to A5 = 0;
	PORTC = 0x00;	//Set PINC = Hiz
	DDRC = 0x00;
}

unsigned char readPCM(void){
	unsigned char data;
	PORTA &= 0xC0;   //A0 to A5 = 0;
	delayx(0x10);
	PORTB |= 0x08;   //R/W = 1
	delayx(0x20);
	PORTB &= 0xFE;   //CS = 0
	delayx(0x20);
	PORTB &= 0xFD;   //OE = 0;

	PORTC = 0xFF;	 //Set PINC = INPUT
	DDRC = 0x00;
	while ((PINB & 0x04)==0){} 
	data = PINC;
	delayx(0x10);
	
	PORTB |= 0x02;   //OE = 1;
	delayx(0x20);
	PORTB |= 0x01;   //CS = 1
	delayx(0x20);

	PORTC = 0x00;	//Set PINC = Hiz
	DDRC = 0x00;
	return data;
}
