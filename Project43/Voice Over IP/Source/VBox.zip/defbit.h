/* All Bit Definitions for Register of  AVR(AT90S8353)
 * By  Noppadon  Wattanawongsiri
 * Date 21/01/2001
*/

/* General Interrupt Mask Register Bit Definitiones */
#define	INT1	7
#define INT0	6

/* General Interrupt Flag Register Bit Definitions */
#define INTF	7
#define INTF0 	6  

/* Timer/Counter Interrupt Mask Register Bit Definitions */
#define OCIE2	7
#define TOIE2	6
#define TICIE1  5
#define OCE1A	4
#define OCE1B	3
#define TOIE1   2
#define TIMSK_RES	1
#define TOIE0   0 

/* Timer/Counter Interrupt Flag Register Bit Definition */
#define OCF2	7
#define	TOV2	6
#define	ICF1	5
#define	OCF1A	4
#define	OCF1B	3
#define	TOV1	2
#define	TIFR_RES	1
#define	TOV0	0

/* MCU Control Register Bit Definition */
#define	MCUCR_RES	7
#define SE	6
#define	SM1	5
#define	SM0	4
#define	ISC11	3
#define	ISC10	2
#define	ISC01	1
#define	ISC00	0	

/* UART Control Register Bit Definetions */
#define	RXCIE	7
#define TXCIE	6
#define	UDRIE	5
#define	RXEN	4
#define	TXEN	3
#define	CHR9	2
#define	RXB8	1
#define TXB8	0

/* UART Status Register Bit Definitions */
#define RXC	7
#define TXC	6
#define	UDRE	5
#define FE	4
#define OVR	3                      

/* PIN AVR Definition */
/* PORT A */ 
#define TOE 7
#define STD 6
#define A5 5
#define A4 4
#define A3 3
#define A2 2
#define A1 1
#define A0 0

/* PORT B */ 
#define AX1 7
#define AX0 6
#define CHTONE 5
#define CSTONE 4
#define R_W 3
#define DT 2
#define DS 1
#define CS 0

/* PORT C */ 
#define D7 7
#define D6 6
#define D5 5
#define D4 4
#define D3 3
#define D2 2
#define D1 1
#define D0 0

/* PORT D */ 
#define B_LIGHT 7
#define E_LCD 6
#define RS_LCD 5
#define RC 4
#define MUTE 3
#define CH_HOOK A2 2
#define TXMCU 1
#define RXMCU 0

