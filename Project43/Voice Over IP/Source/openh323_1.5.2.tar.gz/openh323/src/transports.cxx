/*
 * transports.cxx
 *
 * H.323 transports handler
 *
 * Open H323 Library
 *
 * Copyright (c) 1998-2000 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Portions of this code were written with the assisance of funding from
 * Vovida Networks, Inc. http://www.vovida.com.
 *
 * Contributor(s): ______________________________________.
 *
 * $Log: transports.cxx,v $
 * Revision 1.69  2001/05/17 06:37:04  robertj
 * Added multicast gatekeeper discovery support.
 *
 * Revision 1.68  2001/04/13 07:44:51  robertj
 * Moved starting connection trace message to be on both Connect() and Accept()
 *
 * Revision 1.67  2001/04/10 01:21:02  robertj
 * Added some more error messages into trace log.
 *
 * Revision 1.66  2001/04/09 08:44:19  robertj
 * Added ability to get transport address for a listener.
 * Added '*' to indicate INADDR_ANY ip address.
 *
 * Revision 1.65  2001/03/06 05:03:00  robertj
 * Changed H.245 channel start failure so does not abort call if there were
 *   some fast started media streams opened. Just lose user indications.
 *
 * Revision 1.64  2001/03/05 04:28:50  robertj
 * Added net mask to interface info returned by GetInterfaceTable()
 *
 * Revision 1.63  2001/02/09 05:13:56  craigs
 * Added pragma implementation to (hopefully) reduce the executable image size
 * under Linux
 *
 * Revision 1.62  2001/02/08 22:29:39  robertj
 * Fixed failure to reset fill character in trace log when output interface list.
 *
 * Revision 1.61  2001/01/29 06:43:32  robertj
 * Added printing of entry of interface table.
 *
 * Revision 1.60  2001/01/23 05:06:52  robertj
 * Fixed bug when trying to clear call while waiting on H.245 channel connect, thanks Yura Aksyonov.
 * Fixed missing increment in H.245 listener when specified local port number range.
 *
 * Revision 1.59  2001/01/11 06:41:01  craigs
 * Fixed problem with outgoing sockets failing because of port in use
 *
 * Revision 1.58  2000/12/18 08:59:20  craigs
 * Added ability to set ports
 *
 * Revision 1.57  2000/11/06 06:19:19  robertj
 * Removed reverse DNS lookup for host name as this can cause HUGE delays in
 *    call setup making it look like a call failure.
 *
 * Revision 1.56  2000/10/20 06:18:49  robertj
 * Fixed very small race condition on creating new connectionon incoming call.
 * Fixed memory/socket leak if do TCP connect and don't send valid setup PDU.
 *
 * Revision 1.55  2000/10/04 12:21:07  robertj
 * Changed setting of callToken in H323Connection to be as early as possible.
 *
 * Revision 1.54  2000/10/04 05:59:26  robertj
 * Minor reorganisation of the H.245 secondary channel start up to make it simpler
 *    to override its behaviour.
 *
 * Revision 1.53  2000/09/25 12:59:34  robertj
 * Added StartListener() function that takes a H323TransportAddress to start
 *     listeners bound to specific interfaces.
 *
 * Revision 1.52  2000/08/31 13:14:10  robertj
 * Increased timeout on assert for stuck transport thread.
 *
 * Revision 1.51  2000/08/25 01:10:28  robertj
 * Added assert if various thrads ever fail to terminate.
 *
 * Revision 1.50  2000/08/22 09:01:06  robertj
 * Fixed small window in which control channel could do write through NULL pointer.
 *
 * Revision 1.49  2000/07/10 16:11:49  robertj
 * Fixed inclusion of interfaces with no IP address in GK registration.
 * Fixed possible crash when closing connection during H.245 TCP connect wait.
 *
 * Revision 1.48  2000/06/20 02:38:28  robertj
 * Changed H323TransportAddress to default to IP.
 *
 * Revision 1.47  2000/06/07 05:48:06  robertj
 * Added call forwarding.
 *
 * Revision 1.46  2000/05/23 02:38:15  robertj
 * Shortened the linger onTCP close to 3 seconds, should be adequate for lst end session transmit.
 *
 * Revision 1.45  2000/05/22 05:21:36  robertj
 * Fixed race condition where controlChannel variable could be used before set.
 *
 * Revision 1.44  2000/05/10 05:14:53  robertj
 * Fixed memory leak when doing GK discovery.
 *
 * Revision 1.43  2000/05/08 14:07:35  robertj
 * Improved the provision and detection of calling and caller numbers, aliases and hostnames.
 *
 * Revision 1.42  2000/05/05 04:37:50  robertj
 * Changed TCP transmit of PDU to not use Nagle algorithm delay, this gives
 *     a significant performance benefit for packet based stuff on stream based TCP.
 *
 * Revision 1.41  2000/05/02 04:32:28  robertj
 * Fixed copyright notice comment.
 *
 * Revision 1.40  2000/04/19 01:59:21  robertj
 * Improved some debugging messages.
 * Added code to restore transport state if gatekeeper discovery fails.
 *
 * Revision 1.39  2000/04/14 17:32:39  robertj
 * Changed transport to return some error number when getting malformed TPKT.
 *
 * Revision 1.38  2000/04/11 03:57:25  robertj
 * Fixed uninitialised variabel giving random port numbers for some PDU's (rare).
 *
 * Revision 1.37  2000/04/10 17:41:46  robertj
 * Changed transport address so does not do reverse DNS lookup, can really slow things down on some systems.
 *
 * Revision 1.36  2000/03/29 02:14:46  robertj
 * Changed TerminationReason to CallEndReason to use correct telephony nomenclature.
 * Added CallEndReason for capability exchange failure.
 *
 * Revision 1.35  2000/03/25 02:02:25  robertj
 * Added adjustable caller name on connection by connection basis.
 *
 * Revision 1.34  2000/02/09 00:00:53  robertj
 * Fixed TCP listener socket error message going to stderr, should go through PTRACE.
 *
 * Revision 1.33  2000/01/29 07:13:33  robertj
 * Fixed possible incorect port being used when GK RAS send address set to the
 *    IP address of the responding GK, thanks Stefan Ditscheid.
 *
 * Revision 1.32  2000/01/07 08:24:01  robertj
 * Added transport independent MakeCall requiring change to transport string format
 *
 * Revision 1.31  1999/12/09 21:46:42  robertj
 * Fixed detection of bound interface in gatekeeper discovery (can't use getsockname!)
 *
 * Revision 1.30  1999/12/09 20:25:41  robertj
 * Changed UDP transport to only do gatekeeper discovery on bound interface (if present)
 *
 * Revision 1.29  1999/11/22 00:56:35  robertj
 * Improved reason display for connection failure.
 *
 * Revision 1.28  1999/11/18 12:51:20  robertj
 * Fixed bug that termination connections incorrectly while awaiting answer.
 *
 * Revision 1.27  1999/11/06 05:37:45  robertj
 * Complete rewrite of termination of connection to avoid numerous race conditions.
 *
 * Revision 1.26  1999/10/28 11:17:38  robertj
 * Fixed bug causing delete of deleted object, thanks Benny Prijono
 *
 * Revision 1.25  1999/10/16 03:47:49  robertj
 * Fixed termination of gatekeeper RAS thread problem
 *
 * Revision 1.24  1999/10/14 12:04:11  robertj
 * Fixed ability to hang up call when still doing TCP connect.
 *
 * Revision 1.23  1999/10/13 04:32:41  robertj
 * Fixed missing port number from gatekeeper discovery.
 * Added removal of redundent transport listeners in H225 PDU.
 *
 * Revision 1.22  1999/10/10 14:12:06  robertj
 * Fixed failure to clean up connection if call is refused by user.
 *
 * Revision 1.21  1999/10/10 08:59:47  robertj
 * no message
 *
 * Revision 1.20  1999/09/27 01:37:23  robertj
 * BeOS port issues
 *
 * Revision 1.19  1999/09/17 07:26:17  robertj
 * Fixed attempt to broadcast to down interfaces or ones not bound to IP protocol.
 *
 * Revision 1.18  1999/09/14 08:19:37  robertj
 * Fixed timeout on retry of gatekeeper discover and added more tracing.
 *
 * Revision 1.17  1999/09/14 06:52:54  robertj
 * Added better support for multi-homed client hosts.
 *
 * Revision 1.16  1999/09/10 09:43:59  robertj
 * Removed attempt at determining local interface for gatekeeper, so still has problem on multi-homed hosts.
 *
 * Revision 1.15  1999/09/02 15:25:39  robertj
 * Old GNU C ompiler compatibility
 *
 * Revision 1.14  1999/08/31 12:34:19  robertj
 * Added gatekeeper support.
 *
 * Revision 1.13  1999/08/31 11:37:30  robertj
 * Fixed problem with apparently randomly losing signalling channel.
 *
 * Revision 1.12  1999/08/25 05:12:23  robertj
 * Changed MakeCall, so immediately spawns thread, no black on TCP connect.
 *
 * Revision 1.11  1999/07/23 02:37:53  robertj
 * Fixed problems with hang ups and crash closes of connections.
 *
 * Revision 1.10  1999/07/22 14:34:16  robertj
 * Fixed shut down problem, terminate packets being flushed on exit.
 *
 * Revision 1.9  1999/07/15 14:45:36  robertj
 * Added propagation of codec open error to shut down logical channel.
 * Fixed control channel start up bug introduced with tunnelling.
 *
 * Revision 1.8  1999/07/14 06:06:14  robertj
 * Fixed termination problems (race conditions) with deleting connection object.
 *
 * Revision 1.7  1999/07/09 06:09:52  robertj
 * Major implementation. An ENORMOUS amount of stuff added everywhere.
 *
 * Revision 1.6  1999/06/25 10:25:35  robertj
 * Added maintentance of callIdentifier variable in H.225 channel.
 *
 * Revision 1.5  1999/06/22 13:42:05  robertj
 * Added user question on listener version to accept incoming calls.
 *
 * Revision 1.4  1999/06/14 08:42:30  robertj
 * GNU C++ compatibility
 *
 * Revision 1.3  1999/06/13 12:41:14  robertj
 * Implement logical channel transmitter.
 * Fixed H245 connect on receiving call.
 *
 * Revision 1.2  1999/06/09 06:18:01  robertj
 * GCC compatibiltiy.
 *
 * Revision 1.1  1999/06/09 05:26:20  robertj
 * Major restructuring of classes.
 *
 */

#ifdef __GNUC__
#pragma implementation "transports.cxx"
#endif


#include <ptlib.h>
#include "h323.h"
#include "h323pdu.h"


class H225TransportThread : public PThread
{
  PCLASSINFO(H225TransportThread, PThread)

  public:
    H225TransportThread(H323EndPoint & endpoint,
                        H323Transport * transport,
                        PChannel * signallingChannel);

  protected:
    void Main();

    H323Transport * transport;
    PChannel * signallingChannel;
};


class H245TransportThread : public PThread
{
  PCLASSINFO(H245TransportThread, PThread)

  public:
    H245TransportThread(H323EndPoint & endpoint,
                        H323Connection & connection,
                        H323Transport & transport);

  protected:
    void Main();

    H323Connection & connection;
    H323Transport  & transport;
};


#define new PNEW


/////////////////////////////////////////////////////////////////////////////

H225TransportThread::H225TransportThread(H323EndPoint & ep,
                                         H323Transport * t,
                                         PChannel * s)
  : PThread(ep.GetSignallingThreadStackSize(), AutoDeleteThread),
    transport(t),
    signallingChannel(s)
{
  Resume();
}


void H225TransportThread::Main()
{
  PTRACE(3, "H225\tStarted incoming call thread");

  if (!transport->HandleFirstSignallingChannelPDU(signallingChannel))
    delete transport;
}

/////////////////////////////////////////////////////////////////////////////

H245TransportThread::H245TransportThread(H323EndPoint & endpoint,
                                         H323Connection & c,
                                         H323Transport & t)
  : PThread(endpoint.GetSignallingThreadStackSize(), NoAutoDeleteThread),
    connection(c),
    transport(t)
{
  transport.AttachThread(this);
  Resume();
}


void H245TransportThread::Main()
{
  PTRACE(3, "H245\tStarted thread");

  if (transport.AcceptControlChannel(connection))
    connection.HandleControlChannel();
}


/////////////////////////////////////////////////////////////////////////////

static const char IpPrefix[] = "ip$";

H323TransportAddress::H323TransportAddress(const char * cstr)
  : PString(cstr)
{
  Validate();
}


H323TransportAddress::H323TransportAddress(const PString & str)
  : PString(str)
{
  Validate();
}


H323TransportAddress::H323TransportAddress(const H225_TransportAddress & transport)
{
  switch (transport.GetTag()) {
    case H225_TransportAddress::e_ipAddress :
    {
      const H225_TransportAddress_ipAddress & ip = transport;
      sprintf("%s%u.%u.%u.%u:%u",
              IpPrefix,
              ip.m_ip[0], ip.m_ip[1], ip.m_ip[2], ip.m_ip[3],
              (unsigned)ip.m_port);
      break;
    }
  }
}


H323TransportAddress::H323TransportAddress(const H245_TransportAddress & transport)
{
  switch (transport.GetTag()) {
    case H245_TransportAddress::e_unicastAddress :
    {
      const H245_UnicastAddress & unicast = transport;
      switch (transport.GetTag()) {
        case H245_UnicastAddress::e_iPAddress :
        {
          const H245_UnicastAddress_iPAddress & ip = unicast;
          sprintf("%s%u.%u.%u.%u:%u",
                  IpPrefix,
                  ip.m_network[0], ip.m_network[1], ip.m_network[2], ip.m_network[3],
                  (unsigned)ip.m_tsapIdentifier);
          break;
        }
      }
      break;
    }
  }
}


H323TransportAddress::H323TransportAddress(const PIPSocket::Address & ip, WORD port)
  : PString(IpPrefix)
{
  *this += ip.AsString();
  if (port != 0)
    sprintf(":%u", port);
}


void H323TransportAddress::Validate()
{
  if (IsEmpty())
    return;

  if (Find('$') == P_MAX_INDEX) {
    Splice(IpPrefix, 0, 0);
    return;
  }

  if (strncmp(theArray, IpPrefix, 3) == 0) {
    return;
  }

  *this = PString();
}


BOOL H323TransportAddress::SetPDU(H225_TransportAddress & pdu) const
{
  PIPSocket::Address ip;
  WORD port = H323ListenerTCP::DefaultSignalPort;
  if (GetIpAndPort(ip, port)) {
    pdu.SetTag(H225_TransportAddress::e_ipAddress);
    H225_TransportAddress_ipAddress & addr = pdu;
    for (PINDEX i = 0; i < 4; i++)
      addr.m_ip[i] = ip[i];
    addr.m_port = port;
    return TRUE;
  }


  return FALSE;
}


BOOL H323TransportAddress::SetPDU(H245_TransportAddress & pdu) const
{
  PIPSocket::Address ip;
  WORD port = 0;
  if (GetIpAndPort(ip, port)) {
    pdu.SetTag(H245_TransportAddress::e_unicastAddress);

    H245_UnicastAddress & unicast = pdu;
    unicast.SetTag(H245_UnicastAddress::e_iPAddress);

    H245_UnicastAddress_iPAddress & addr = unicast;
    for (PINDEX i = 0; i < 4; i++)
      addr.m_network[i] = ip[i];
    addr.m_tsapIdentifier = port;
    return TRUE;
  }

  return FALSE;
}


BOOL H323TransportAddress::GetIpAndPort(PIPSocket::Address & ip,
                                        WORD & port,
                                        const char * proto) const
{
  if (strncmp(theArray, IpPrefix, 3) != 0) {
    PTRACE(2, "H323\tUse of non IP transport address: \"" << *this << '"');
    return FALSE;
  }

  PString host;
  PINDEX colon = Find(':', 3);
  if (colon == P_MAX_INDEX)
    host = Mid(3);
  else {
    host = Mid(3, colon-3);
    port = PIPSocket::GetPortByService(proto, Mid(colon+1));
  }

  if (host.IsEmpty() || port == 0) {
    PTRACE(2, "H323\tIllegal IP transport address: \"" << *this << '"');
    return FALSE;
  }

  if (host == "*") {
    ip = INADDR_ANY;
    return TRUE;
  }

  if (PIPSocket::GetHostAddress(host, ip))
    return TRUE;

  PTRACE(1, "H323\tCould not find host : \"" << host << '"');
  return FALSE;
}


PString H323TransportAddress::GetHostName() const
{
  if (strncmp(theArray, IpPrefix, 3) != 0)
    return *this;

  PString host;
  PINDEX colon = Find(':', 3);
  if (colon == P_MAX_INDEX)
    host = Mid(3);
  else
    host = Mid(3, colon-3);

  PIPSocket::Address ip;
  if (PIPSocket::GetHostAddress(host, ip))
    return ip.AsString();

  return host;
}


H323Listener * H323TransportAddress::CreateListener(H323EndPoint & endpoint) const
{
  /*Have transport type name, create the transport object. Hard coded at the
    moment but would like to add some sort of "registration" of transport
    classes so new transports can be added without changing this source file
    every time. As we have one transport type at the moment and may never
    actually have another, we hard code it for now.
   */

  PIPSocket::Address ip;
  WORD port = H323ListenerTCP::DefaultSignalPort;
  if (GetIpAndPort(ip, port))
    return new H323ListenerTCP(endpoint, ip, port);

  return NULL;
}


H323Transport * H323TransportAddress::CreateTransport(H323EndPoint & endpoint) const
{
  /*Have transport type name, create the transport object. Hard coded at the
    moment but would like to add some sort of "registration" of transport
    classes so new transports can be added without changing this source file
    every time. As we have one transport type at the moment and may never
    actually have another, we hard code it for now.
   */

  if (strncmp(theArray, IpPrefix, 3) == 0)
    return new H323TransportTCP(endpoint);

  return NULL;
}


/////////////////////////////////////////////////////////////////////////////

H323Listener::H323Listener(H323EndPoint & end)
  : PThread(end.GetListenerThreadStackSize(), NoAutoDeleteThread),
    endpoint(end)
{
}


/////////////////////////////////////////////////////////////////////////////

H323Transport::H323Transport(H323EndPoint & end)
  : endpoint(end)
{
  thread = NULL;
}


H323Transport::~H323Transport()
{
  PAssert(thread == NULL, PLogicError);
}


BOOL H323Transport::Close()
{
  /* Do not use PIndirectChannel::Close() as this deletes the sub-channel
     member field crashing the background thread. Just close the base
     sub-channel so breaks the threads I/O block.
   */
  if (IsOpen())
    GetBaseReadChannel()->Close();

  return TRUE;
}


BOOL H323Transport::HandleFirstSignallingChannelPDU(PChannel * signallingChannel)
{
  if (!Open(signallingChannel)) {
    PTRACE(1, "H225\tFailed to open transport, connection not started.");
    return FALSE;
  }

  PTRACE(3, "H225\tAwaiting first PDU");
  SetReadTimeout(15000); // Await 15 seconds after connect for first byte
  H323SignalPDU pdu;
  if (!pdu.Read(*this)) {
    PTRACE(1, "H225\tFailed to get initial Q.931 PDU, connection not started.");
    return FALSE;
  }

  unsigned callReference = pdu.GetQ931().GetCallReference();
  PTRACE(3, "H225\tIncoming call, first PDU: callReference=" << callReference);

  // Now attach this thread to the transport, which is in turn attached to the
  // connection so everything from gets cleaned up by the H323 cleaner thread
  // from now on. So thread must not auto delete and the "transport" variable
  // is not deleted either
  PThread * thread = PThread::Current();
  AttachThread(thread);
  thread->SetNoAutoDelete();

  H323Connection & connection = endpoint.GetConnection(this, callReference, TRUE);

  if (connection.HandleSignalPDU(pdu)) {
    // All subsequent PDU's should wait forever
    SetReadTimeout(PMaxTimeInterval);
    connection.HandleSignallingChannel();
  }
  else {
    connection.ClearCall(H323Connection::EndedByTransportFail);
    PTRACE(1, "H225\tSignal channel stopped on first PDU.");
  }

  return TRUE;
}


void H323Transport::StartControlChannel(H323Connection & connection)
{
  new H245TransportThread(endpoint, connection, *this);
}


void H323Transport::AttachThread(PThread * thrd)
{
  PAssert(thread == NULL, PLogicError);
  thread = thrd;
}


void H323Transport::CleanUpOnTermination()
{
  Close();

  if (thread != NULL) {
    PAssert(thread->WaitForTermination(10000), "Transport thread did not terminate");
    delete thread;
    thread = NULL;
  }
}


BOOL H323Transport::IsCompatibleTransport(const H225_TransportAddress & /*pdu*/) const
{
  PAssertAlways(PUnimplementedFunction);
  return FALSE;
}


void H323Transport::SetUpTransportPDU(H225_TransportAddress & /*pdu*/,
                                      BOOL /*localTsap*/) const
{
  PAssertAlways(PUnimplementedFunction);
}


void H323Transport::SetUpTransportPDU(H245_TransportAddress & /*pdu*/,
                                      unsigned /*port*/) const
{
  PAssertAlways(PUnimplementedFunction);
}


H323Transport * H323Transport::CreateControlChannel(H323Connection & /*connection*/)
{
  PAssertAlways(PUnimplementedFunction);
  return NULL;
}


BOOL H323Transport::AcceptControlChannel(H323Connection & /*connection*/)
{
  PAssertAlways(PUnimplementedFunction);
  return FALSE;
}


BOOL H323Transport::DiscoverGatekeeper(H323Gatekeeper & /*gk*/,
                                       H323RasPDU & /*pdu*/,
                                       const H323TransportAddress & /*address*/)
{
  PAssertAlways(PUnimplementedFunction);
  return FALSE;
}


/////////////////////////////////////////////////////////////////////////////

H323ListenerTCP::H323ListenerTCP(H323EndPoint & end,
                                 PIPSocket::Address binding,
                                 WORD port)
  : H323Listener(end),
    listener(port),
    localAddress(binding)
{
}


H323ListenerTCP::~H323ListenerTCP()
{
  Close();
}


BOOL H323ListenerTCP::Open()
{
#ifdef _DEBUG
  return listener.Listen(localAddress, 5, 0, PSocket::CanReuseAddress);
#else
  return listener.Listen(localAddress);
#endif
}


BOOL H323ListenerTCP::Close()
{
  BOOL ok = listener.Close();
  PAssert(PThread::Current() != this, PLogicError);
  PAssert(WaitForTermination(1000), "Listener thread did not terminate");
  return ok;
}


H323TransportAddress H323ListenerTCP::GetTransportAddress() const
{
  PString addr;

  if (localAddress == INADDR_ANY)
    addr = "*";
  else
    addr = localAddress.AsString();

  addr.sprintf(":%u", listener.GetPort());

  return addr;
}


static void AppendTransportAddress(H225_ArrayOf_TransportAddress & pdu,
                                   const PIPSocket::Address & addr, WORD port)
{
  H225_TransportAddress_ipAddress pduAddr;
  PINDEX i;
  for (i = 0; i < 4; i++)
    pduAddr.m_ip[i] = addr[i];
  pduAddr.m_port = port;

  PINDEX lastPos = pdu.GetSize();

  // Check for already have had that IP address.
  for (i = 0; i < lastPos; i++) {
    H225_TransportAddress & taddr = pdu[i];
    if (taddr.GetTag() == H225_TransportAddress::e_ipAddress) {
      H225_TransportAddress_ipAddress & ipAddr = taddr;
      if (ipAddr == pduAddr)
        return;
    }
  }

  // Put new listener into array
  pdu.SetSize(lastPos+1);
  H225_TransportAddress & taddr = pdu[lastPos];

  taddr.SetTag(H225_TransportAddress::e_ipAddress);
  (H225_TransportAddress_ipAddress &)taddr = pduAddr;
}


void H323ListenerTCP::SetUpTransportPDU(H225_ArrayOf_TransportAddress & pdu,
                                        const H225_TransportAddress & first)
{
  WORD port = listener.GetPort();

  if (localAddress != INADDR_ANY) {
    AppendTransportAddress(pdu, localAddress, port);
    return;
  }

  PIPSocket::InterfaceTable interfaces;
  if (!PIPSocket::GetInterfaceTable(interfaces)) {
    PIPSocket::Address ipAddr;
    PIPSocket::GetHostAddress(ipAddr);
    AppendTransportAddress(pdu, ipAddr, port);
    return;
  }

  PIPSocket::Address firstAddress = 0;
  if (first.GetTag() == H225_TransportAddress::e_ipAddress) {
    const H225_TransportAddress_ipAddress & pduAddr = first;
    firstAddress = PIPSocket::Address(pduAddr.m_ip[0],
                                      pduAddr.m_ip[1],
                                      pduAddr.m_ip[2],
                                      pduAddr.m_ip[3]);
  }

  PINDEX i;
  for (i = 0; i < interfaces.GetSize(); i++) {
    PIPSocket::Address ipAddr = interfaces[i].GetAddress();
    if (ipAddr == firstAddress)
      AppendTransportAddress(pdu, ipAddr, port);
  }

  for (i = 0; i < interfaces.GetSize(); i++) {
    PIPSocket::Address ipAddr = interfaces[i].GetAddress();
    if (ipAddr != 0 && ipAddr != firstAddress && ipAddr != PIPSocket::Address()) // Ignore 127.0.0.1
      AppendTransportAddress(pdu, ipAddr, port);
  }
}


void H323ListenerTCP::Main()
{
  PTRACE(2, "H323\tAwaiting TCP connections on port " << listener.GetPort());

  while (listener.IsOpen()) {
    PTCPSocket * signallingChannel = new PTCPSocket;
    if (signallingChannel->Accept(listener))
      new H225TransportThread(endpoint, new H323TransportTCP(endpoint), signallingChannel);
    else {
      if (signallingChannel->GetErrorCode() != PChannel::Interrupted) {
        PTRACE(1, "Q931\t\tAccept error:" << signallingChannel->GetErrorText());
        listener.Close();
      }
      delete signallingChannel;
    }
  }
}


/////////////////////////////////////////////////////////////////////////////

H323TransportIP::H323TransportIP(H323EndPoint & end, PIPSocket::Address binding, WORD remPort)
  : H323Transport(end),
    localAddress(binding),
    remoteAddress(0)
{
  if (localAddress == INADDR_ANY)
    PIPSocket::GetHostAddress(localAddress);

  localPort = 0;
  remotePort = remPort;
}


H323TransportAddress H323TransportIP::GetLocalAddress() const
{
  return H323TransportAddress(localAddress, localPort);
}


H323TransportAddress H323TransportIP::GetRemoteAddress() const
{
  return H323TransportAddress(remoteAddress, remotePort);
}


BOOL H323TransportIP::IsCompatibleTransport(const H225_TransportAddress & pdu) const
{
  return pdu.GetTag() == H225_TransportAddress::e_ipAddress;
}


void H323TransportIP::SetUpTransportPDU(H225_TransportAddress & pdu, BOOL localTsap) const
{
  pdu.SetTag(H225_TransportAddress::e_ipAddress);
  H225_TransportAddress_ipAddress & pduAddr = pdu;

  PIPSocket::Address ipAddr;
  if (!localTsap) 
    ipAddr = remoteAddress;
  else {
    ipAddr = localAddress;
    endpoint.TranslateTCPAddress(ipAddr, remoteAddress);
  }
 
  for (PINDEX i = 0; i < 4; i++)
    pduAddr.m_ip[i] = ipAddr[i];
  pduAddr.m_port = localTsap ? localPort : remotePort;
}


void H323TransportIP::SetUpTransportPDU(H245_TransportAddress & pdu, unsigned port) const
{
  pdu.SetTag(H245_TransportAddress::e_unicastAddress);

  H245_UnicastAddress & unicast = pdu;
  unicast.SetTag(H245_UnicastAddress::e_iPAddress);

  H245_UnicastAddress_iPAddress & addr = unicast;

  PIPSocket::Address ipAddr = localAddress;
  endpoint.TranslateTCPAddress(ipAddr, remoteAddress);

  for (PINDEX i = 0; i < 4; i++)
    addr.m_network[i] = ipAddr[i];
  addr.m_tsapIdentifier = port;
}


/////////////////////////////////////////////////////////////////////////////

H323TransportTCP::H323TransportTCP(H323EndPoint & end,
                                   PIPSocket::Address binding,
                                   BOOL listen)
  : H323TransportIP(end, binding, H323ListenerTCP::DefaultSignalPort)
{
  h245listener = NULL;

  // construct listener socket if required
  if (listen) {
    h245listener = new PTCPSocket;
    localPort = end.GetTCPPortBase();
    if (localPort == 0) {
      if (h245listener->Listen(binding)) 
        localPort = h245listener->GetPort();
    }
    else {
      while (localPort <= end.GetTCPPortMax() && !h245listener->Listen(binding, 5, localPort))
        localPort++;
    }
    if (h245listener->IsOpen()) {
      PTRACE(3, "H225\tTCP Listen for H245 on " << binding << ':' << localPort);
    }
    else {
      PTRACE(1, "H225\tTCP Listen for H245 failed: " << h245listener->GetErrorText());
      delete h245listener;
      h245listener = NULL;
    }
  }
}


H323TransportTCP::~H323TransportTCP()
{
  delete h245listener;  // Delete and H245 listener that may be present
}


BOOL H323TransportTCP::OnOpen()
{
  PIPSocket * socket = (PIPSocket *)GetReadChannel();

  // Get name of the remote computer for information purposes
  if (!socket->GetPeerAddress(remoteAddress, remotePort)) {
    PTRACE(1, "H323TCP\tGetPeerAddress() failed: " << socket->GetErrorText());
    return FALSE;
  }

  // get local address of incoming socket to ensure that multi-homed machines
  // use a NIC address that is guaranteed to be addressable to destination
  if (!socket->GetLocalAddress(localAddress, localPort)) {
    PTRACE(1, "H323TCP\tGetLocalAddress() failed: " << socket->GetErrorText());
    return FALSE;
  }

#ifndef __BEOS__
  if (!socket->SetOption(TCP_NODELAY, 1, IPPROTO_TCP)) {
    PTRACE(1, "H323TCP\tSetOption(TCP_NODELAY) failed: " << socket->GetErrorText());
  }

  // make sure do not lose outgoing packets on close
  const linger ling = { 1, 3 };
  if (!socket->SetOption(SO_LINGER, &ling, sizeof(ling))) {
    PTRACE(1, "H323TCP\tSetOption(SO_LINGER) failed: " << socket->GetErrorText());
    return FALSE;
  }
#endif

  PTRACE(1, "H323TCP\tStarted connection to "
         << remoteAddress << ':' << remotePort
         << " (if=" << localAddress << ':' << localPort << ')');

  return TRUE;
}


BOOL H323TransportTCP::Close()
{
  // Close listening socket to break waiting accept
  if (IsListening())
    h245listener->Close();

  return H323Transport::Close();
}


BOOL H323TransportTCP::SetRemoteAddress(const H323TransportAddress & address)
{
  return address.GetIpAndPort(remoteAddress, remotePort, "tcp");
}


BOOL H323TransportTCP::ReadPDU(PBYTEArray & pdu)
{
  // Make sure is a RFC1006 TPKT
  switch (ReadChar()) {
    case 3 :  // Only support version 3
      break;

    default :  // Unknown version number
      lastError = Miscellaneous;
      osError = 0x10000;
      // Do case for read error

    case -1 :
      return FALSE;
  }

  // Save timeout
  PTimeInterval oldTimeout = GetReadTimeout();

  // Should get all of PDU in 5 seconds or something is seriously wrong,
  SetReadTimeout(5000);

  // Get TPKT length
  BYTE header[3];
  BOOL ok = ReadBlock(header, sizeof(header));
  if (ok) {
    PINDEX packetLength = ((header[1] << 8)|header[2]) - 4;
    ok = ReadBlock(pdu.GetPointer(packetLength), packetLength);
  }

  SetReadTimeout(oldTimeout);

  return ok;
}


BOOL H323TransportTCP::WritePDU(const PBYTEArray & pdu)
{
  // We copy the data into a new buffer so we can do a single write call. This
  // is necessary as we have disabled the Nagle TCP delay algorithm to improve
  // network performance.

  int packetLength = pdu.GetSize() + 4;

  // Send RFC1006 TPKT length
  PBYTEArray tpkt(packetLength);
  tpkt[0] = 3;
  tpkt[1] = 0;
  tpkt[2] = (BYTE)(packetLength >> 8);
  tpkt[3] = (BYTE)packetLength;
  memcpy(tpkt.GetPointer()+4, (const BYTE *)pdu, pdu.GetSize());

  return Write((const BYTE *)tpkt, packetLength);
}


BOOL H323TransportTCP::Connect()
{
  if (IsListening())
    return TRUE;

  PTCPSocket * socket = new PTCPSocket(remotePort);
  Open(socket);

  WORD portBase = endpoint.GetTCPPortBase();
  WORD portMax  = endpoint.GetTCPPortMax();

  if (portBase == 0) {
    if (!socket->Connect(remoteAddress)) {
      PTRACE(1, "H323TCP\tCould not connect to "
             << remoteAddress << ':' << remotePort << ' ' << socket->GetErrorText());
      osError = socket->GetErrorNumber();
      lastError = socket->GetErrorCode();
      return FALSE;
    }
  }
  else {
    while (!socket->Connect(portBase, remoteAddress)) {
      int code = socket->GetErrorNumber();
      if (((code != EADDRINUSE) && (code != EADDRNOTAVAIL)) || (portBase > portMax)) {
        PTRACE(1, "H323TCP\tCould not connect to "
                  << remoteAddress << ':' << remotePort
                  << ' ' << socket->GetErrorText()
                  << "(" << socket->GetErrorNumber() << ")");
        osError = socket->GetErrorNumber();
        lastError = socket->GetErrorCode();
        return FALSE;
      }
      portBase++;
    }
  }

  PTRACE(3, "H323TCP\tStarting connection to "
         << remoteAddress << ':' << remotePort);

  if (!OnOpen())
    return FALSE;

  return TRUE;
}


H323Transport * H323TransportTCP::CreateControlChannel(H323Connection & connection)
{
  H323TransportTCP * tcpTransport = new H323TransportTCP(endpoint, localAddress, TRUE);

  if (tcpTransport->IsListening()) // Listen() failed
    return tcpTransport;

  delete tcpTransport;
  connection.ClearCall(H323Connection::EndedByTransportFail);
  return FALSE;
}


BOOL H323TransportTCP::AcceptControlChannel(H323Connection & connection)
{
  if (IsOpen())
    return TRUE;

  if (h245listener == NULL) {
    PAssertAlways(PLogicError);
    return FALSE;
  }

  PTRACE(3, "H245\tTCP Accept wait");

  PTCPSocket * h245Socket = new PTCPSocket;

  h245listener->SetReadTimeout(30000); // Wait 30 seconds for remote H245 connect
  if (h245Socket->Accept(*h245listener))
    return Open(h245Socket);

  PTRACE(1, "H225\tAccept for H245 failed: " << h245Socket->GetErrorText());
  delete h245Socket;

  if (connection.FindChannel(RTP_Session::DefaultAudioSessionID, TRUE) == NULL ||
      connection.FindChannel(RTP_Session::DefaultAudioSessionID, FALSE) == NULL)
    connection.ClearCall(H323Connection::EndedByTransportFail);

  return FALSE;
}


BOOL H323TransportTCP::IsListening() const
{
  if (IsOpen())
    return FALSE;

  if (h245listener == NULL)
    return FALSE;

  return h245listener->IsOpen();
}


/////////////////////////////////////////////////////////////////////////////

H323TransportUDP::H323TransportUDP(H323EndPoint & end,
                                   PIPSocket::Address binding,
                                   WORD port)
  : H323TransportIP(end, binding, DefaultRasPort)
{
  PUDPSocket * udp = new PUDPSocket;
  PTRACE(3, "UDP\tBinding to interface: " << binding);
  udp->Listen(binding, 0, port);
  Open(udp);

  localAddress = binding;
  localPort = udp->GetPort();
}


H323TransportUDP::~H323TransportUDP()
{
  Close();
}


BOOL H323TransportUDP::SetRemoteAddress(const H323TransportAddress & address)
{
  return address.GetIpAndPort(remoteAddress, remotePort, "udp");
}


BOOL H323TransportUDP::Connect()
{
  if (remoteAddress == 0 || remotePort == 0)
    return FALSE;

  PUDPSocket * socket = (PUDPSocket *)GetReadChannel();
  socket->SetSendAddress(remoteAddress, remotePort);

  return TRUE;
}


BOOL H323TransportUDP::ReadPDU(PBYTEArray & pdu)
{
  if (!Read(pdu.GetPointer(10000), 10000)) {
    pdu.SetSize(0);
    return FALSE;
  }

  pdu.SetSize(GetLastReadCount());
  return TRUE;
}


BOOL H323TransportUDP::WritePDU(const PBYTEArray & pdu)
{
  return Write((const BYTE *)pdu, pdu.GetSize());
}


BOOL H323TransportUDP::DiscoverGatekeeper(H323Gatekeeper & gk,
                                          H323RasPDU & request,
                                          const H323TransportAddress & address)
{
  PTRACE(3, "H225\tStarted gatekeeper discovery of \"" << address << '"');

  // Skip over the H323Transport::Close to make sure PUDPSocket is deleted.
  PIndirectChannel::Close();

  remoteAddress = 0;
  remotePort = 0;

  PIPSocket::Address destAddr = INADDR_BROADCAST;
  WORD destPort = DefaultRasPort;
  if (!address) {
    if (!address.GetIpAndPort(destAddr, destPort, "udp")) {
      PTRACE(2, "RAS\tError decoding address");
      return FALSE;
    }
  }

  PIPSocket::Address originalLocalAddress = localAddress;
  WORD originalLocalPort = localPort;

  PIPSocket::InterfaceTable interfaces;

  // See if prebound to interface, only use that if so
  if (localAddress != INADDR_ANY) {
    PTRACE(3, "RAS\tGatekeeper discovery on pre-bound interface: " << localAddress);
    interfaces.Append(new PIPSocket::InterfaceEntry("", localAddress, PIPSocket::Address(0xffffffff), ""));
  }
  else if (!PIPSocket::GetInterfaceTable(interfaces)) {
    PTRACE(1, "RAS\tNo interfaces on system!");
    interfaces.Append(new PIPSocket::InterfaceEntry("", localAddress, PIPSocket::Address(0xffffffff), ""));
  }
  else {
    PTRACE(4, "RAS\tSearching interfaces:\n" << setfill('\n') << interfaces << setfill(' '));
  }

  PSocketList sockets;
  PSocket::SelectList selection;
  H225_GatekeeperRequest & grq = request;

  PINDEX i;
  for (i = 0; i < interfaces.GetSize(); i++) {
    localAddress = interfaces[i].GetAddress();
    if (localAddress == 0 || localAddress == PIPSocket::Address())
      continue;

    // Check for already have had that IP address.
    PINDEX j;
    for (j = 0; j < i; j++) {
      if (localAddress == interfaces[j].GetAddress())
        break;
    }
    if (j < i)
      continue;

    PUDPSocket * socket;

    static PIPSocket::Address MulticastRasAddress(224, 0, 1, 41);
    if (destAddr != MulticastRasAddress) {

      // Not explicitly multicast
      socket = new PUDPSocket;
      sockets.Append(socket);

      if (!socket->Listen(localAddress)) {
        PTRACE(2, "RAS\tError on discover request listen: " << socket->GetErrorText());
        return FALSE;
      }

      localPort = socket->GetPort();

#ifndef __BEOS__
      if (destAddr == INADDR_BROADCAST) {
        if (!socket->SetOption(SO_BROADCAST, 1)) {
          PTRACE(2, "RAS\tError allowing broadcast: " << socket->GetErrorText());
          return FALSE;
        }
      }
#else
      PTRACE(2, "RAS\tBroadcast option under BeOS is not implemented yet");
#endif

      // Adjust the PDU to reflect the interface we are writing to.
      SetUpTransportPDU(grq.m_rasAddress, TRUE);

      PTRACE(3, "RAS\tGatekeeper discovery on interface: " << localAddress << ':' << localPort);

      socket->SetSendAddress(destAddr, destPort);
      writeChannel = socket;
      if (request.Write(*this))
        selection.Append(socket);
      else
        PTRACE(2, "RAS\tError writing discovery PDU: " << socket->GetErrorText());

#ifndef __BEOS__
      if (destAddr == INADDR_BROADCAST)
        socket->SetOption(SO_BROADCAST, 0);
#endif
    }


#ifdef IP_ADD_MEMBERSHIP
    // Now do it again for Multicast
    if (destAddr == INADDR_BROADCAST || destAddr == MulticastRasAddress) {
      socket = new PUDPSocket;
      sockets.Append(socket);

      if (!socket->Listen(localAddress)) {
        PTRACE(2, "RAS\tError on discover request listen: " << socket->GetErrorText());
        return FALSE;
      }

      localPort = socket->GetPort();

      struct ip_mreq mreq;
      mreq.imr_multiaddr = MulticastRasAddress;
      mreq.imr_interface = localAddress;    // ip address of host
      if (socket->SetOption(IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq), IPPROTO_IP)) {
        // Adjust the PDU to reflect the interface we are writing to.
        SetUpTransportPDU(grq.m_rasAddress, TRUE);

        socket->SetOption(SO_BROADCAST, 1);

        socket->SetSendAddress(INADDR_BROADCAST, MulticastRasPort);
        writeChannel = socket;
        if (request.Write(*this))
          selection.Append(socket);
        else
          PTRACE(2, "RAS\tError writing discovery PDU: " << socket->GetErrorText());

        socket->SetOption(SO_BROADCAST, 0);
      }
      else
        PTRACE(2, "RAS\tError allowing multicast: " << socket->GetErrorText());
    }
#endif

    writeChannel = NULL;
  }

  if (sockets.IsEmpty()) {
    PTRACE(1, "RAS\tNo suitable interfaces for discovery!");
    return FALSE;
  }

  if (PSocket::Select(selection, endpoint.GetGatekeeperRequestTimeout()) != NoError) {
    PTRACE(3, "RAS\tError on discover request select");
    return FALSE;
  }

  SetReadTimeout(0);

  for (i = 0; i < selection.GetSize(); i++) {
    readChannel = &selection[i];
    H323RasPDU response;
    if (!response.Read(*this)) {
      PTRACE(3, "RAS\tError on discover request read: " << readChannel->GetErrorText());
      readChannel = NULL;
      return FALSE;
    }

    do {
      if (gk.HandleRasPDU(response)) {
        PUDPSocket * socket = (PUDPSocket *)readChannel;
        readChannel = NULL;
        Open(socket);

        sockets.DisallowDeleteObjects();
        sockets.Remove(socket);
        sockets.AllowDeleteObjects();

	WORD dummyPort;
        socket->GetLastReceiveAddress(remoteAddress, dummyPort);
        socket->SetSendAddress(remoteAddress, remotePort);
        socket->GetLocalAddress(localAddress, localPort);
        PTRACE(2, "RAS\tGatekeeper discovered at: "
               << remoteAddress << ':' << remotePort
               << " (if="
               << localAddress << ':' << localPort << ')');
        return TRUE;
      }
    } while (response.Read(*this));
  }

  PTRACE(2, "RAS\tGatekeeper discovery failed");
  localAddress = originalLocalAddress;
  localPort = originalLocalPort;
  readChannel = NULL;
  return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
