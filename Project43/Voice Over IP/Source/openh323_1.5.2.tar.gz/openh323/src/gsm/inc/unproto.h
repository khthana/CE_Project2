/*
 * Copyright 1992 by Jutta Degener and Carsten Bormann, Technische
 * Universitaet Berlin.  See the accompanying file "COPYRIGHT" for
 * details.  THERE IS ABSOLUTELY NO WARRANTY FOR THIS SOFTWARE.
 */

/*$Header: /home/cvsroot/openh323/src/gsm/inc/unproto.h,v 1.1 1999/06/22 14:11:09 robertj Exp $*/

#ifdef	PROTO_H		/* sic */
#undef	PROTO_H

#undef	P
#undef	P0
#undef	P1
#undef	P2
#undef	P3
#undef	P4
#undef	P5
#undef	P6
#undef	P7
#undef	P8

#endif	/* PROTO_H */
