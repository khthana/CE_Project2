/*
 * h235security.cxx
 *
 * H.235 security information
 *
 * Open H323 Library
 *
 * Copyright (c) 1998-2001 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Contributor(s): F�rbass Franz <franz.fuerbass@infonova.at>
 *
 * $Log: h235security.cxx,v $
 * Revision 1.1  2001/03/21 04:52:42  robertj
 * Added H.235 security to gatekeepers, thanks F�rbass Franz!
 *
 */

#ifdef __GNUC__
#pragma implementation "h235security.h"
#endif

#include <ptlib.h>
#include <ptclib/random.h>
#include "h235security.h"


///////////////////////////////////////////////////////////////////////////////

H235SecurityInfo::H235SecurityInfo()
{
  randomSequenceNumber = PRandom::Number();
}


/////////////////////////////////////////////////////////////////////////////
