/*
 * codecs.cxx
 *
 * H.323 protocol handler
 *
 * Open H323 Library
 *
 * Copyright (c) 1998-2000 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Portions of this code were written with the assisance of funding from
 * Vovida Networks, Inc. http://www.vovida.com.
 *
 * Contributor(s): ______________________________________.
 *
 * $Log: codecs.cxx,v $
 * Revision 1.59  2001/04/03 09:34:13  robertj
 * Fixed output of partial frames when short changed by transmitter with G.711
 *
 * Revision 1.58  2001/03/29 23:45:08  robertj
 * Added ability to get current silence detect state and threshold.
 * Changed default signal on deadband time to be much shorter.
 *
 * Revision 1.57  2001/02/09 05:13:55  craigs
 * Added pragma implementation to (hopefully) reduce the executable image size
 * under Linux
 *
 * Revision 1.56  2001/01/25 07:27:16  robertj
 * Major changes to add more flexible OpalMediaFormat class to normalise
 *   all information about media types, especially codecs.
 *
 * Revision 1.55  2000/12/19 22:33:44  dereks
 * Adjust so that the video channel is used for reading/writing raw video
 * data, which better modularizes the video codec.
 *
 * Revision 1.54  2000/09/22 01:35:49  robertj
 * Added support for handling LID's that only do symmetric codecs.
 *
 * Revision 1.53  2000/08/31 08:15:41  robertj
 * Added support for dynamic RTP payload types in H.245 OpenLogicalChannel negotiations.
 *
 * Revision 1.52  2000/07/14 14:08:10  robertj
 * Fixed stream based codec so can support stream "frames" less than maximum specified.
 *
 * Revision 1.51  2000/05/16 02:04:17  craigs
 * Added access functions for silence compression mode
 *
 * Revision 1.50  2000/05/04 11:52:35  robertj
 * Added Packets Too Late statistics, requiring major rearrangement of jitter
 *    buffer code, not also changes semantics of codec Write() function slightly.
 *
 * Revision 1.49  2000/05/02 04:32:26  robertj
 * Fixed copyright notice comment.
 *
 * Revision 1.48  2000/04/28 12:58:37  robertj
 * Changed silence detection code so does not PTRACE unless threshold actually changes.
 *
 * Revision 1.47  2000/04/10 18:52:45  robertj
 * Improved "bootstrap" of silence detection algorithm.
 *
 * Revision 1.46  2000/03/23 03:00:06  robertj
 * Changed framed codec so only writes max of bytesPerFrame regardless of length.
 *
 * Revision 1.45  2000/02/04 05:11:19  craigs
 * Updated for new Makefiles and for new video transmission code
 *
 * Revision 1.44  2000/01/13 04:03:45  robertj
 * Added video transmission
 *
 * Revision 1.43  1999/12/31 00:05:36  robertj
 * Added Microsoft ACM G.723.1 codec capability.
 *
 * Revision 1.42  1999/12/23 23:02:35  robertj
 * File reorganision for separating RTP from H.323 and creation of LID for VPB support.
 *
 * Revision 1.41  1999/12/21 07:36:43  craigs
 * Fixed problem in H323VideoCodec destructor that caused hang or segv on exit
 *
 * Revision 1.40  1999/11/29 08:59:09  craigs
 * Added new code for new video code interface
 *
 * Revision 1.39  1999/11/29 04:50:11  robertj
 * Added adaptive threshold calculation to silence detection.
 *
 * Revision 1.38  1999/11/20 00:53:47  robertj
 * Fixed ability to have variable sized frames in single RTP packet under G.723.1
 *
 * Revision 1.37  1999/11/13 14:10:59  robertj
 * Changes to make silence detection selectable.
 *
 * Revision 1.36  1999/11/11 23:28:46  robertj
 * Added first cut silence detection algorithm.
 *
 * Revision 1.35  1999/11/04 00:45:07  robertj
 * Added extra constructors for nonStandard codecs and fixed receiveAndTransmitAudioCapability problem.
 *
 * Revision 1.34  1999/11/01 00:51:13  robertj
 * Fixed problem where codec close does not dispose of attached channel.
 *
 * Revision 1.33  1999/10/19 00:04:57  robertj
 * Changed OpenAudioChannel and OpenVideoChannel to allow a codec AttachChannel with no autodelete.
 *
 * Revision 1.32  1999/10/14 12:02:40  robertj
 * Fixed assignment of t35 info in nonstandard capabilities (wrong way around).
 *
 * Revision 1.31  1999/10/10 23:00:15  craigs
 * Fixed problem with raw channel ptrs not being NULLed out after deletion
 *
 * Revision 1.30  1999/10/09 02:15:08  craigs
 * Added codec to OpenVideoDevice and OpenAudioChannel
 *
 * Revision 1.29  1999/10/09 01:20:48  robertj
 * Fixed error in G711 packet size and trace message
 *
 * Revision 1.28  1999/10/08 09:59:03  robertj
 * Rewrite of capability for sending multiple audio frames
 *
 * Revision 1.27  1999/10/08 08:32:22  robertj
 * Fixed misleading trace text.
 *
 * Revision 1.26  1999/10/08 04:58:38  robertj
 * Added capability for sending multiple audio frames in single RTP packet
 *
 * Revision 1.25  1999/09/23 07:25:12  robertj
 * Added open audio and video function to connection and started multi-frame codec send functionality.
 *
 * Revision 1.24  1999/09/21 14:51:34  robertj
 * Fixed NonStandardCapabilityInfo class virtual destructor (and name).
 *
 * Revision 1.23  1999/09/21 14:14:36  robertj
 * Added non-standard codec capability classes
 *
 * Revision 1.22  1999/09/21 08:10:03  craigs
 * Added support for video devices and H261 codec
 *
 * Revision 1.21  1999/09/18 13:24:38  craigs
 * Added ability to disable jitter buffer
 * Added ability to access entire RTP packet in codec Write
 *
 * Revision 1.20  1999/09/13 13:59:14  robertj
 * Removed incorrect comment.
 *
 * Revision 1.19  1999/09/08 04:05:49  robertj
 * Added support for video capabilities & codec, still needs the actual codec itself!
 *
 * Revision 1.18  1999/08/31 12:34:18  robertj
 * Added gatekeeper support.
 *
 * Revision 1.17  1999/08/25 05:05:36  robertj
 * Added UserInput capability.
 * Allowed the attachment of a channel on a codec to optionally delete the channel object,
 * Improved opening of audio codecs, PSoundChannel creation now in endpoint.
 *
 * Revision 1.16  1999/07/16 16:05:48  robertj
 * Added "human readable" codec type name display.
 *
 * Revision 1.15  1999/07/16 15:01:30  robertj
 * Added message print when starting GSM codec.
 *
 * Revision 1.14  1999/07/15 14:45:36  robertj
 * Added propagation of codec open error to shut down logical channel.
 * Fixed control channel start up bug introduced with tunnelling.
 *
 * Revision 1.13  1999/07/13 09:53:24  robertj
 * Fixed some problems with jitter buffer and added more debugging.
 *
 * Revision 1.12  1999/07/10 02:42:53  robertj
 * Fixed interopability problem with NetMetting 2.1 G711 capability.
 *
 * Revision 1.11  1999/07/09 06:09:49  robertj
 * Major implementation. An ENORMOUS amount of stuff added everywhere.
 *
 * Revision 1.10  1999/06/24 13:32:45  robertj
 * Fixed ability to change sound device on codec and fixed NM3 G.711 compatibility
 *
 * Revision 1.9  1999/06/22 13:49:40  robertj
 * Added GSM support and further RTP protocol enhancements.
 *
 * Revision 1.8  1999/06/14 15:08:40  robertj
 * Added GSM codec class frame work (still no actual codec).
 *
 * Revision 1.7  1999/06/14 08:44:58  robertj
 * Fixed sound buffers to be correct size for stream based audio.
 * GNU C++ compatibility
 *
 * Revision 1.6  1999/06/14 06:39:08  robertj
 * Fixed problem with getting transmit flag to channel from PDU negotiator
 *
 * Revision 1.5  1999/06/14 05:15:55  robertj
 * Changes for using RTP sessions correctly in H323 Logical Channel context
 *
 * Revision 1.4  1999/06/13 12:41:14  robertj
 * Implement logical channel transmitter.
 * Fixed H245 connect on receiving call.
 *
 * Revision 1.3  1999/06/09 05:26:19  robertj
 * Major restructuring of classes.
 *
 * Revision 1.2  1999/06/06 06:06:36  robertj
 * Changes for new ASN compiler and v2 protocol ASN files.
 *
 * Revision 1.1  1999/01/16 01:31:04  robertj
 * Initial revision
 *
 */

#ifdef __GNUC__
#pragma implementation "codecs.h"
#endif

#include <ptlib.h>
#include "codecs.h"
#include "channels.h"
#include "h323pdu.h"


#define new PNEW

#if !PTRACING // Stuff to remove unised parameters warning
#define PTRACE_bitRateRestriction
#define PTRACE_type
#endif

extern "C" {
  unsigned char linear2ulaw(int pcm_val);
  int ulaw2linear(unsigned char u_val);
  unsigned char linear2alaw(int pcm_val);
  int alaw2linear(unsigned char u_val);
};


/////////////////////////////////////////////////////////////////////////////

H323Codec::H323Codec(const char * fmt, Direction dir)
  : mediaFormat(fmt)
{
  direction = dir;
  rawDataChannel = NULL;
  deleteChannel  = FALSE;
 }


BOOL H323Codec::Open(H323Connection & /*connection*/)
{
  return TRUE;
}


unsigned H323Codec::GetFrameRate() const
{
  return mediaFormat.GetFrameTime();
}


void H323Codec::OnFlowControl(long PTRACE_bitRateRestriction)
{
  PTRACE(3, "Codec\tOnFlowControl: " << PTRACE_bitRateRestriction);
}


void H323Codec::OnMiscellaneousCommand(const H245_MiscellaneousCommand_type & PTRACE_type)
{
  PTRACE(3, "Codec\tOnMiscellaneousCommand: " << PTRACE_type.GetTagName());
}


void H323Codec::OnMiscellaneousIndication(const H245_MiscellaneousIndication_type & PTRACE_type)
{
  PTRACE(3, "Codec\tOnMiscellaneousIndication: " << PTRACE_type.GetTagName());
}


BOOL H323Codec::AttachChannel(PChannel * channel, BOOL autoDelete)
{
  CloseRawDataChannel();

  rawDataChannel = channel;
  deleteChannel = autoDelete;

  if (channel == NULL)
    return FALSE;

  if (channel->IsOpen())
    return TRUE;

  return FALSE;
}

BOOL H323Codec::CloseRawDataChannel()
{
    if ( (rawDataChannel != NULL) && deleteChannel) {   
       rawDataChannel->Close();
       delete rawDataChannel;
       rawDataChannel = NULL;
    }
    
    return TRUE;
    
}  
/////////////////////////////////////////////////////////////////////////////

H323VideoCodec::H323VideoCodec(const char * fmt, Direction dir)
  : H323Codec(fmt, dir)
{
 frameWidth = frameHeight = 0;
}


H323VideoCodec::~H323VideoCodec()
{
  Close();    //The close operation may delete the rawDataChannel.
}


BOOL H323VideoCodec::Open(H323Connection & connection)
{
  return connection.OpenVideoChannel(direction == Encoder, *this);
}


void H323VideoCodec::OnMiscellaneousCommand(const H245_MiscellaneousCommand_type & type)
{
  switch (type.GetTag()) {
    case H245_MiscellaneousCommand_type::e_videoFreezePicture :
      OnFreezePicture();
      break;

    case H245_MiscellaneousCommand_type::e_videoFastUpdatePicture :
      OnFastUpdatePicture();
      break;

    case H245_MiscellaneousCommand_type::e_videoFastUpdateGOB :
    {
      const H245_MiscellaneousCommand_type_videoFastUpdateGOB & fuGOB = type;
      OnFastUpdateGOB(fuGOB.m_firstGOB, fuGOB.m_numberOfGOBs);
      break;
    }

    case H245_MiscellaneousCommand_type::e_videoFastUpdateMB :
    {
      const H245_MiscellaneousCommand_type_videoFastUpdateMB & fuMB = type;
      OnFastUpdateMB(fuMB.HasOptionalField(H245_MiscellaneousCommand_type_videoFastUpdateMB::e_firstGOB) ? (int)fuMB.m_firstGOB : -1,
                     fuMB.HasOptionalField(H245_MiscellaneousCommand_type_videoFastUpdateMB::e_firstMB)  ? (int)fuMB.m_firstMB  : -1,
                     fuMB.m_numberOfMBs);
      break;
    }
  }

  H323Codec::OnMiscellaneousCommand(type);
}


void H323VideoCodec::OnFreezePicture()
{
}


void H323VideoCodec::OnFastUpdatePicture()
{
}


void H323VideoCodec::OnFastUpdateGOB(unsigned /*firstGOB*/, unsigned /*numberOfGOBs*/)
{
}


void H323VideoCodec::OnFastUpdateMB(int /*firstGOB*/, int /*firstMB*/, unsigned /*numberOfMBs*/)
{
}


void H323VideoCodec::OnMiscellaneousIndication(const H245_MiscellaneousIndication_type & type)
{
  switch (type.GetTag()) {
    case H245_MiscellaneousIndication_type::e_videoIndicateReadyToActivate :
      OnVideoIndicateReadyToActivate();
      break;

    case H245_MiscellaneousIndication_type::e_videoTemporalSpatialTradeOff :
      OnVideoTemporalSpatialTradeOff();
      break;

    case H245_MiscellaneousIndication_type::e_videoNotDecodedMBs :
    {
      const H245_MiscellaneousIndication_type_videoNotDecodedMBs & vndMB = type;
      OnVideoNotDecodedMBs(vndMB.m_firstMB, vndMB.m_numberOfMBs, vndMB.m_temporalReference);
      break;
    }
  }

  H323Codec::OnMiscellaneousIndication(type);
}


void H323VideoCodec::OnVideoIndicateReadyToActivate()
{
}


void H323VideoCodec::OnVideoTemporalSpatialTradeOff()
{
}


void H323VideoCodec::OnVideoNotDecodedMBs(unsigned /*firstMB*/,
                                          unsigned /*numberOfMBs*/,
                                          unsigned /*temporalReference*/)
{
}



void H323VideoCodec::Close()
{
  PWaitAndSignal mutex1(videoHandlerActive);  

  CloseRawDataChannel();
}
/////////////////////////////////////////////////////////////////////////////

H323AudioCodec::H323AudioCodec(const char * fmt, Direction dir)
  : H323Codec(fmt, dir)
{
  samplesPerFrame = mediaFormat.GetFrameTime();
  if (samplesPerFrame == 0)
    samplesPerFrame = 8; // Default for non-frame based codecs.

  // Start off in silent mode
  inTalkBurst = FALSE;

  // Initialise the adaptive threshold variables.
  SetSilenceDetectionMode(AdaptiveSilenceDetection);
}


H323AudioCodec::~H323AudioCodec()
{
  Close();

  CloseRawDataChannel();
}


BOOL H323AudioCodec::Open(H323Connection & connection)
{
  return connection.OpenAudioChannel(direction == Encoder, samplesPerFrame*2, *this);
}


void H323AudioCodec::Close()
{
  if (rawDataChannel != NULL)
    rawDataChannel->Close();
}


unsigned H323AudioCodec::GetFrameRate() const
{
  return samplesPerFrame;
}


H323AudioCodec::SilenceDetectionMode H323AudioCodec::GetSilenceDetectionMode(
                                BOOL * isInTalkBurst, unsigned * currentThreshold) const
{
  if (isInTalkBurst != NULL)
    *isInTalkBurst = inTalkBurst;

  if (currentThreshold != NULL)
    *currentThreshold = ulaw2linear((BYTE)(levelThreshold ^ 0xff));

  return silenceDetectMode;
}


void H323AudioCodec::SetSilenceDetectionMode(SilenceDetectionMode mode,
                                             unsigned threshold,
                                             unsigned signalDeadband,
                                             unsigned silenceDeadband,
                                             unsigned adaptivePeriod)
{
  silenceDetectMode = mode;

  // The silence deadband is the number of frames of low energy that have to
  // occur before the system stops sending data over the RTP link.
  signalDeadbandFrames = (signalDeadband+samplesPerFrame-1)/samplesPerFrame;
  silenceDeadbandFrames = (silenceDeadband+samplesPerFrame-1)/samplesPerFrame;

  // This is the period over which the adaptive algorithm operates
  adaptiveThresholdFrames = (adaptivePeriod+samplesPerFrame-1)/samplesPerFrame;

  if (mode != AdaptiveSilenceDetection) {
    levelThreshold = threshold;
    return;
  }

  // Initials threshold levels
  levelThreshold = 0;

  // Initialise the adaptive threshold variables.
  signalMinimum = UINT_MAX;
  silenceMaximum = 0;
  signalFramesReceived = 0;
  silenceFramesReceived = 0;

  // Restart in silent mode
  inTalkBurst = FALSE;
}


BOOL H323AudioCodec::DetectSilence()
{
  // Can never have silence if NoSilenceDetection
  if (silenceDetectMode == NoSilenceDetection)
    return FALSE;

  // Can never have average signal level that high, this indicates that the
  // hardware cannot do silence detection.
  unsigned level = GetAverageSignalLevel();
  if (level == UINT_MAX)
    return FALSE;

  // Convert to a logarithmic scale - use uLaw which is complemented
  level = linear2ulaw(level) ^ 0xff;

  // Now if signal level above threshold we are "talking"
  BOOL haveSignal = level > levelThreshold;

  // If no change ie still talking or still silent, resent frame counter
  if (inTalkBurst == haveSignal)
    framesReceived = 0;
  else {
    framesReceived++;
    // If have had enough consecutive frames talking/silent, swap modes.
    if (framesReceived >= (inTalkBurst ? silenceDeadbandFrames : signalDeadbandFrames)) {
      inTalkBurst = !inTalkBurst;
      PTRACE(4, "Codec\tSilence detection transition: "
             << (inTalkBurst ? "Talk" : "Silent")
             << " level=" << level << " threshold=" << levelThreshold);

      // If we had talk/silence transition restart adaptive threshold measurements
      signalMinimum = UINT_MAX;
      silenceMaximum = 0;
      signalFramesReceived = 0;
      silenceFramesReceived = 0;
    }
  }

  if (silenceDetectMode == FixedSilenceDetection)
    return !inTalkBurst;

  if (levelThreshold == 0) {
    if (level > 1) {
      // Bootstrap condition, use first frame level as silence level
      levelThreshold = level/2;
      PTRACE(4, "Codec\tSilence detection threshold initialised to: " << levelThreshold);
    }
    return TRUE; // inTalkBurst always FALSE here, so return silent
  }

  // Count the number of silent and signal frames and calculate min/max
  if (haveSignal) {
    if (level < signalMinimum)
      signalMinimum = level;
    signalFramesReceived++;
  }
  else {
    if (level > silenceMaximum)
      silenceMaximum = level;
    silenceFramesReceived++;
  }

  // See if we have had enough frames to look at proportions of silence/signal
  if ((signalFramesReceived + silenceFramesReceived) > adaptiveThresholdFrames) {

    /* Now we have had a period of time to look at some average values we can
       make some adjustments to the threshold. There are four cases:
     */
    if (signalFramesReceived >= adaptiveThresholdFrames) {
      /* If every frame was noisy, move threshold up. Don't want to move too
         fast so only go a quarter of the way to minimum signal value over the
         period. This avoids oscillations, and time will continue to make the
         level go up if there really is a lot of background noise.
       */
      int delta = (signalMinimum - levelThreshold)/4;
      if (delta != 0) {
        levelThreshold += delta;
        PTRACE(4, "Codec\tSilence detection threshold increased to: " << levelThreshold);
      }
    }
    else if (silenceFramesReceived >= adaptiveThresholdFrames) {
      /* If every frame was silent, move threshold down. Again do not want to
         move too quickly, but we do want it to move faster down than up, so
         move to halfway to maximum value of the quiet period. As a rule the
         lower the threshold the better as it would improve response time to
         the start of a talk burst.
       */
      unsigned newThreshold = (levelThreshold + silenceMaximum)/2 + 1;
      if (levelThreshold != newThreshold) {
        levelThreshold = newThreshold;
        PTRACE(4, "Codec\tSilence detection threshold decreased to: " << levelThreshold);
      }
    }
    else if (signalFramesReceived > silenceFramesReceived) {
      /* We haven't got a definitive silent or signal period, but if we are
         constantly hovering at the threshold and have more signal than
         silence we should creep up a bit.
       */
      levelThreshold++;
      PTRACE(4, "Codec\tSilence detection threshold incremented to: " << levelThreshold
             << " signal=" << signalFramesReceived << ' ' << signalMinimum
             << " silence=" << silenceFramesReceived << ' ' << silenceMaximum);
    }

    signalMinimum = UINT_MAX;
    silenceMaximum = 0;
    signalFramesReceived = 0;
    silenceFramesReceived = 0;
  }

  return !inTalkBurst;
}


unsigned H323AudioCodec::GetAverageSignalLevel()
{
  return UINT_MAX;
}


/////////////////////////////////////////////////////////////////////////////

H323FramedAudioCodec::H323FramedAudioCodec(const char * fmt, Direction dir)
  : H323AudioCodec(fmt, dir),
    sampleBuffer(samplesPerFrame)
{
  bytesPerFrame = mediaFormat.GetFrameSize();
}


BOOL H323FramedAudioCodec::Read(BYTE * buffer, unsigned & length, RTP_DataFrame &)
{
  if (rawDataChannel == NULL) {
    PTRACE(1, "Codec\tNo audio channel for read");
    return FALSE;
  }

  if (direction != Encoder) {
    PTRACE(1, "Codec\tAttempt to decode from encoder");
    return FALSE;
  }

  if (!rawDataChannel->Read(sampleBuffer.GetPointer(samplesPerFrame), samplesPerFrame*2)) {
    PTRACE(1, "Codec\tAudio read failed: " << rawDataChannel->GetErrorText());
    return FALSE;
  }

  if (DetectSilence()) {
    length = 0;
    return TRUE;
  }

  // Default length is the frame size
  length = bytesPerFrame;
  return EncodeFrame(buffer, length);
}


BOOL H323FramedAudioCodec::Write(const BYTE * buffer,
                                 unsigned length,
                                 const RTP_DataFrame & /*rtpFrame*/,
                                 unsigned & written)
{
  if (rawDataChannel == NULL) {
    PTRACE(1, "Codec\tNo audio channel for write");
    return FALSE;
  }

  if (direction != Decoder) {
    PTRACE(1, "Codec\tAttempt to encode from decoder");
    return FALSE;
  }

  // If length is zero then it indicates silence, do nothing.
  PINDEX bytesOfPCM = samplesPerFrame*2;
  if (length == 0) {
    memset(sampleBuffer.GetPointer(samplesPerFrame), 0, bytesOfPCM);
    written = 0;
  }
  else {
    if (length > bytesPerFrame)
      length = bytesPerFrame;
    written = bytesPerFrame;

    // Decode the data
    if (!DecodeFrame(buffer, length, written))
      return FALSE;

    bytesOfPCM = bytesOfPCM*written/bytesPerFrame;
  }

  // Write as 16bit PCM to sound channel
  if (rawDataChannel->Write(sampleBuffer, bytesOfPCM))
    return TRUE;

  PTRACE(1, "Codec\tWrite failed: " << rawDataChannel->GetErrorText());
  return FALSE;
}


unsigned H323FramedAudioCodec::GetAverageSignalLevel()
{
  // Calculate the average signal level of this frame
  int sum = 0;

  const short * pcm = sampleBuffer;
  const short * end = pcm + samplesPerFrame;
  while (pcm != end) {
    if (*pcm < 0)
      sum -= *pcm++;
    else
      sum += *pcm++;
  }

  return sum/samplesPerFrame;
}


/////////////////////////////////////////////////////////////////////////////

H323StreamedAudioCodec::H323StreamedAudioCodec(const char * fmt,
                                               Direction dir,
                                               unsigned samples,
                                               unsigned bits)
  : H323FramedAudioCodec(fmt, dir)
{
  samplesPerFrame = samples;
  bytesPerFrame = (samples*bits+7)/8;
  bitsPerSample = bits;
}


BOOL H323StreamedAudioCodec::EncodeFrame(BYTE * buffer, unsigned &)
{
  PINDEX i;

  switch (bitsPerSample) {
    case 8 :
      for (i = 0; i < (PINDEX)samplesPerFrame; i++)
        *buffer++ = (BYTE)Encode(sampleBuffer[i]);
      break;

    case 4 :
      for (i = 0; i < (PINDEX)samplesPerFrame; i++) {
        if ((i&1) == 0)
          *buffer = (BYTE)Encode(sampleBuffer[i]);
        else
          *buffer |= (BYTE)(Encode(sampleBuffer[i]) << 4);
      }
      break;

    default :
      PAssertAlways("Unsupported bit size");
      return FALSE;
  }

  return TRUE;
}


BOOL H323StreamedAudioCodec::DecodeFrame(const BYTE * buffer, unsigned length, unsigned & written)
{
  unsigned i;
  short * out = sampleBuffer.GetPointer(samplesPerFrame);

  switch (bitsPerSample) {
    case 8 :
      for (i = 0; i < length; i++)
        *out++ = Decode(*buffer++);
      break;

    case 4 :
      for (i = 0; i < length; i++) {
        *out++ = Decode(*buffer & 15);
        *out++ = Decode(*buffer >> 4);
        buffer++;
      }
      break;

    default :
      PAssertAlways("Unsupported bit size");
      return FALSE;
  }

  written = length;

  return TRUE;
}


/////////////////////////////////////////////////////////////////////////////

static OpalMediaFormat const ALaw_MediaFormat("G.711-ALaw-64k",
                                              RTP_DataFrame::PCMA,
                                              TRUE,  // Needs jitter
                                              64000, // bits/sec
                                              8,  // 8 bytes per "frame"
                                              8,  // 1 millisecond
                                              OpalMediaFormat::AudioTimeUnits);

H323_ALawCodec::H323_ALawCodec(Direction dir,
                               BOOL at56kbps,
                               unsigned frameSize)
  : H323StreamedAudioCodec(ALaw_MediaFormat, dir, frameSize, 8)
{
  sevenBit = at56kbps;

  PTRACE(3, "Codec\tG711 ALaw " << (dir == Encoder ? "en" : "de")
         << "coder created for at "
         << (sevenBit ? "56k" : "64k") << ", " << frameSize << " samples");
}



int H323_ALawCodec::Encode(short sample) const
{
  return linear2alaw(sample);
}


short H323_ALawCodec::Decode(int sample) const
{
  return (short)alaw2linear((unsigned char)sample);
}


/////////////////////////////////////////////////////////////////////////////

static OpalMediaFormat const ULaw_MediaFormat("G.711-uLaw-64k",
                                              RTP_DataFrame::PCMU,
                                              TRUE,  // Needs jitter
                                              64000, // bits/sec
                                              8,  // 8 bytes per "frame"
                                              8,  // 1 millisecond
                                              OpalMediaFormat::AudioTimeUnits);

H323_muLawCodec::H323_muLawCodec(Direction dir,
                                 BOOL at56kbps,
                                 unsigned frameSize)
  : H323StreamedAudioCodec(ULaw_MediaFormat, dir, frameSize, 8)
{
  sevenBit = at56kbps;

  PTRACE(3, "Codec\tG711 uLaw " << (dir == Encoder ? "en" : "de")
         << "coder created for at "
         << (sevenBit ? "56k" : "64k") << ", frame of " << frameSize << " samples");
}


int H323_muLawCodec::Encode(short sample) const
{
  return linear2ulaw(sample);
}


short H323_muLawCodec::Decode(int sample) const
{
  return (short)ulaw2linear((unsigned char)sample);
}


/////////////////////////////////////////////////////////////////////////////
