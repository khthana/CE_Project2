/*
 * h235ras.cxx
 *
 * H.235 security over Gatekeeper RAS PDU's
 *
 * Open H323 Library
 *
 * Copyright (c) 1998-2001 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Contributor(s): F�rbass Franz <franz.fuerbass@infonova.at>
 *
 * $Log: h235ras.cxx,v $
 * Revision 1.6  2001/03/29 23:53:06  robertj
 * Changes to make closer to spec, thanks again F�rbass Franz
 *
 * Revision 1.5  2001/03/24 02:00:47  robertj
 * Fixed incorrect check for secure RAS, always returned FALSE.
 *
 * Revision 1.4  2001/03/24 00:35:43  robertj
 * Added read/write hook functions so don't have to duplicate code in
 *    H323RasH235PDU descendant class of H323RasPDU.
 * Fixed infinite recursion in unregistration confirm PDU build.
 *
 * Revision 1.3  2001/03/21 05:49:18  robertj
 * GNU Compatibility
 *
 * Revision 1.2  2001/03/21 05:32:37  robertj
 * Fixed new H.235 code to be transparent if no security info present.
 *
 * Revision 1.1  2001/03/21 04:52:42  robertj
 * Added H.235 security to gatekeepers, thanks F�rbass Franz!
 *
 */

#ifdef __GNUC__
#pragma implementation "h235ras.h"
#endif

#include <ptlib.h>
#include <openssl/sha.h>

#include "h235ras.h"
#include "h235security.h"


#define REPLY_BUFFER_SIZE    1024
#define TIMESPAN_FOR_VERIFY  10000


static const char ThisIsA[] = "0.0.8.0.1.1";
static const char ThisIsT[] = "0.0.8.0.1.5";
static const char ThisIsU[] = "0.0.8.0.1.6";

static const BYTE pattern[] ="0b0b0b0b0b0b";

#ifndef SHA_DIGESTSIZE
#define SHA_DIGESTSIZE  20
#endif

#ifndef SHA_BLOCKSIZE
#define SHA_BLOCKSIZE   64
#endif



#define new PNEW


///////////////////////////////////////////////////////////////////////////////

/* Function to print the digest */
void
pr_sha(FILE* fp, char* s, int t)
{
        int     i ;

        fprintf(fp, "0x") ;
        for (i = 0 ; i < t ; i++)
                fprintf(fp, "%02x", s[i]) ;
        fprintf(fp, "0x") ;
}

void truncate( unsigned char*    d1,    /* data to be truncated */
               char*             d2,    /* truncated data */
               int               len)   /* length in bytes to keep */
{
        int     i ;
        for (i = 0 ; i < len ; i++) d2[i] = d1[i];
}

/* Function to compute the digest */
void hmac_sha ( unsigned char*    k,      /* secret key */
                int      lk,              /* length of the key in bytes */
                unsigned char*    d,      /* data */
                int      ld,              /* length of data in bytes */
                char*    out,             /* output buffer, at least "t" bytes */
                int      t)
{
        SHA_CTX ictx, octx ;
        unsigned char    isha[SHA_DIGESTSIZE], osha[SHA_DIGESTSIZE] ;
        unsigned char    key[SHA_DIGESTSIZE] ;
        char    buf[SHA_BLOCKSIZE] ;
        int     i ;

        if (lk > SHA_BLOCKSIZE) {

                SHA_CTX         tctx ;

                SHA1_Init(&tctx) ;
                SHA1_Update(&tctx, k, lk) ;
                SHA1_Final(key, &tctx) ;

                k = key ;
                lk = SHA_DIGESTSIZE ;
        }

        /**** Inner Digest ****/

        SHA1_Init(&ictx) ;

        /* Pad the key for inner digest */
        for (i = 0 ; i < lk ; ++i) buf[i] = (char)(k[i] ^ 0x36);
        for (i = lk ; i < SHA_BLOCKSIZE ; ++i) buf[i] = 0x36;

        SHA1_Update(&ictx, buf, SHA_BLOCKSIZE) ;
        SHA1_Update(&ictx, d, ld) ;

        SHA1_Final(isha, &ictx) ;

        /**** Outter Digest ****/

        SHA1_Init(&octx) ;

        /* Pad the key for outter digest */

        for (i = 0 ; i < lk ; ++i) buf[i] = (char)(k[i] ^ 0x5C);
        for (i = lk ; i < SHA_BLOCKSIZE ; ++i) buf[i] = 0x5C;

        SHA1_Update(&octx, buf, SHA_BLOCKSIZE) ;
        SHA1_Update(&octx, isha, SHA_DIGESTSIZE) ;

        SHA1_Final(osha, &octx) ;

        /* truncate and print the results */
        t = t > SHA_DIGESTSIZE ? SHA_DIGESTSIZE : t ;
        truncate(osha, out, t) ;

}

///////////////////////////////////////////////////////////////////////////////

H323RasH235PDU::H323RasH235PDU(H235SecurityInfo * sec)
{
  securityInfo = sec;
}


H225_GatekeeperConfirm & H323RasH235PDU::BuildGatekeeperConfirm(unsigned seqNum)
{
  H225_GatekeeperConfirm & grc = H323RasPDU::BuildGatekeeperConfirm(seqNum);

  if (BeforeEncode(grc.m_cryptoTokens) == SECURE_OK)
    grc.IncludeOptionalField(H225_GatekeeperRequest::e_cryptoTokens);

  return grc;
}


H225_GatekeeperReject & H323RasH235PDU::BuildGatekeeperReject(unsigned seqNum, unsigned reason)
{
  H225_GatekeeperReject & grj = H323RasPDU::BuildGatekeeperReject(seqNum, reason);

  if (BeforeEncode(grj.m_cryptoTokens) == SECURE_OK)
    grj.IncludeOptionalField(H225_GatekeeperRequest::e_cryptoTokens);

  return grj;
}


H225_RegistrationRequest & H323RasH235PDU::BuildRegistrationRequest(unsigned seqNum)
{
  H225_RegistrationRequest & rrq = H323RasPDU::BuildRegistrationRequest (seqNum);

  if (BeforeEncode(rrq.m_cryptoTokens) == SECURE_OK)
    rrq.IncludeOptionalField(H225_RegistrationRequest::e_cryptoTokens);

  return rrq;
}


H225_RegistrationConfirm & H323RasH235PDU::BuildRegistrationConfirm(unsigned seqNum)
{
  H225_RegistrationConfirm & rcf = H323RasPDU::BuildRegistrationConfirm (seqNum);

  if (BeforeEncode(rcf.m_cryptoTokens) == SECURE_OK)
    rcf.IncludeOptionalField(H225_RegistrationConfirm::e_cryptoTokens);

  return rcf;
}


H225_RegistrationReject & H323RasH235PDU::BuildRegistrationReject(unsigned seqNum, unsigned reason)
{
  H225_RegistrationReject & rrj = H323RasPDU::BuildRegistrationReject (seqNum, reason);

  if (BeforeEncode(rrj.m_cryptoTokens) == SECURE_OK)
    rrj.IncludeOptionalField(H225_RegistrationReject::e_cryptoTokens);

  return rrj;
}


H225_UnregistrationRequest & H323RasH235PDU::BuildUnregistrationRequest(unsigned seqNum)
{
  H225_UnregistrationRequest & urq = H323RasPDU::BuildUnregistrationRequest (seqNum);

  if (BeforeEncode(urq.m_cryptoTokens) == SECURE_OK)
    urq.IncludeOptionalField(H225_UnregistrationRequest::e_cryptoTokens);

  return urq;
}


H225_UnregistrationConfirm & H323RasH235PDU::BuildUnregistrationConfirm(unsigned seqNum)
{
  H225_UnregistrationConfirm & ucf = H323RasPDU::BuildUnregistrationConfirm (seqNum);

  if (BeforeEncode(ucf.m_cryptoTokens) == SECURE_OK)
    ucf.IncludeOptionalField(H225_UnregistrationConfirm::e_cryptoTokens);

  return ucf;
}


H225_UnregistrationReject & H323RasH235PDU::BuildUnregistrationReject(unsigned seqNum, unsigned reason)
{
  H225_UnregistrationReject & urj = H323RasPDU::BuildUnregistrationReject (seqNum, reason);

  if (BeforeEncode(urj.m_cryptoTokens) == SECURE_OK)
    urj.IncludeOptionalField(H225_UnregistrationReject::e_cryptoTokens);

  return urj;
}


H225_LocationRequest & H323RasH235PDU::BuildLocationRequest(unsigned seqNum)
{
  H225_LocationRequest & lrq = H323RasPDU::BuildLocationRequest(seqNum);

  if (BeforeEncode(lrq.m_cryptoTokens) == SECURE_OK)
    lrq.IncludeOptionalField(H225_LocationRequest::e_cryptoTokens);

  return lrq;
}


H225_LocationConfirm & H323RasH235PDU::BuildLocationConfirm(unsigned seqNum)
{
  H225_LocationConfirm & lcf = H323RasPDU::BuildLocationConfirm (seqNum);

  if (BeforeEncode(lcf.m_cryptoTokens) == SECURE_OK)
    lcf.IncludeOptionalField(H225_LocationConfirm::e_cryptoTokens);

  return lcf;
}


H225_LocationReject & H323RasH235PDU::BuildLocationReject(unsigned seqNum, unsigned reason)
{
  H225_LocationReject & lrj = H323RasPDU::BuildLocationReject(seqNum, reason);

  if (BeforeEncode(lrj.m_cryptoTokens) == SECURE_OK)
    lrj.IncludeOptionalField(H225_LocationReject::e_cryptoTokens);

  return lrj;
}


H225_AdmissionRequest & H323RasH235PDU::BuildAdmissionRequest(unsigned seqNum)
{
  H225_AdmissionRequest & arq = H323RasPDU::BuildAdmissionRequest(seqNum);

  if (BeforeEncode(arq.m_cryptoTokens) == SECURE_OK)
    arq.IncludeOptionalField(H225_AdmissionRequest::e_cryptoTokens);

  return arq;
}


H225_AdmissionConfirm & H323RasH235PDU::BuildAdmissionConfirm(unsigned seqNum)
{
  H225_AdmissionConfirm & acf = H323RasPDU::BuildAdmissionConfirm(seqNum);

  if (BeforeEncode(acf.m_cryptoTokens) == SECURE_OK)
    acf.IncludeOptionalField(H225_AdmissionConfirm::e_cryptoTokens);

  return acf;
}


H225_AdmissionReject & H323RasH235PDU::BuildAdmissionReject(unsigned seqNum, unsigned reason)
{
  H225_AdmissionReject & arj = H323RasPDU::BuildAdmissionReject(seqNum, reason);

  if (BeforeEncode(arj.m_cryptoTokens) == SECURE_OK)
    arj.IncludeOptionalField(H225_AdmissionReject::e_cryptoTokens);

  return arj;
}


H225_DisengageRequest & H323RasH235PDU::BuildDisengageRequest(unsigned seqNum)
{
  H225_DisengageRequest & drq = H323RasPDU::BuildDisengageRequest(seqNum);

  if (BeforeEncode(drq.m_cryptoTokens) == SECURE_OK)
    drq.IncludeOptionalField(H225_DisengageRequest::e_cryptoTokens);

  return drq;
}


H225_DisengageConfirm & H323RasH235PDU::BuildDisengageConfirm(unsigned seqNum)
{
  H225_DisengageConfirm & dcf = H323RasPDU::BuildDisengageConfirm(seqNum);

  if (BeforeEncode(dcf.m_cryptoTokens) == SECURE_OK)
    dcf.IncludeOptionalField(H225_DisengageConfirm::e_cryptoTokens);

  return dcf;
}


H225_DisengageReject & H323RasH235PDU::BuildDisengageReject(unsigned seqNum, unsigned reason)
{
  H225_DisengageReject & drj = H323RasPDU::BuildDisengageReject(seqNum, reason);

  if (BeforeEncode(drj.m_cryptoTokens) == SECURE_OK)
    drj.IncludeOptionalField(H225_DisengageReject::e_cryptoTokens);

  return drj;
}


H225_BandwidthRequest & H323RasH235PDU::BuildBandwidthRequest(unsigned seqNum)
{
  H225_BandwidthRequest & brq = H323RasPDU::BuildBandwidthRequest(seqNum);

  if (BeforeEncode(brq.m_cryptoTokens) == SECURE_OK)
    brq.IncludeOptionalField(H225_BandwidthRequest::e_cryptoTokens);

  return brq;
}


H225_BandwidthConfirm & H323RasH235PDU::BuildBandwidthConfirm(unsigned seqNum, unsigned bandWidth)
{
  H225_BandwidthConfirm & bcf = H323RasPDU::BuildBandwidthConfirm(seqNum, bandWidth);

  if (BeforeEncode(bcf.m_cryptoTokens) == SECURE_OK)
    bcf.IncludeOptionalField(H225_BandwidthConfirm::e_cryptoTokens);

  return bcf;
}


H225_BandwidthReject & H323RasH235PDU::BuildBandwidthReject(unsigned seqNum, unsigned reason)
{
  H225_BandwidthReject & brj = H323RasPDU::BuildBandwidthReject(seqNum, reason);

  if (BeforeEncode(brj.m_cryptoTokens) == SECURE_OK)
    brj.IncludeOptionalField(H225_BandwidthReject::e_cryptoTokens);

  return brj;
}


H225_InfoRequestResponse & H323RasH235PDU::BuildInfoRequestResponse(unsigned seqNum)
{
  H225_InfoRequestResponse & irr = H323RasPDU::BuildInfoRequestResponse(seqNum);

  if (BeforeEncode(irr.m_cryptoTokens) == SECURE_OK)
    irr.IncludeOptionalField(H225_InfoRequestResponse::e_cryptoTokens);

  return irr;
}


H225_UnknownMessageResponse & H323RasH235PDU::BuildUnknownMessageResponse(unsigned seqNum)
{
  H225_UnknownMessageResponse & umr = H323RasPDU::BuildUnknownMessageResponse(seqNum);

  if (BeforeEncode(umr.m_cryptoTokens) == SECURE_OK)
    umr.IncludeOptionalField(H225_UnknownMessageResponse::e_cryptoTokens);

  return umr;
}


BOOL H323RasH235PDU::OnReadPDU(PPER_Stream & strm)
{
  // Check for no security
  if (securityInfo == NULL)
    return TRUE;

  switch (tag) {
    case e_gatekeeperReject :
    case e_gatekeeperRequest :
    case e_gatekeeperConfirm :
    case e_registrationReject :
      PTRACE(3, GetTagName() << ": CryptoTokens are ignored."); 
      return TRUE;
  }

  //do not accept non secure RAS Messages
  H225_ArrayOf_CryptoH323Token * arr = GetCryptoTokens();
  if (arr == NULL) {
    PTRACE(1, "Received unsecured RAS Message in H323RasH235PDU");
    return FALSE;
  }

  // Verify the security on this PDU
  for (PINDEX i = 0; i < arr->GetSize(); i++) {
    if (VerifyPDU(strm.GetPointer(), strm.GetSize(), (*arr)[i]) != SECURE_OK) {
      PTRACE(1, "H225RAS : Message error");
      return FALSE;
    }
  }

  return TRUE;
}


BOOL H323RasH235PDU::OnWritePDU(PPER_Stream & strm) const
{
  if (securityInfo == NULL)
    return TRUE;
  
  if (securityInfo->password.IsEmpty()) {
    PTRACE(1, "RAS\tInvalid H.235 security information.");
    return FALSE;
  }
  
  int foundat = -1;
  for (PINDEX i = 0; i <= strm.GetSize() - 12; i++) {
    if (memcmp(&strm[i], pattern, 12) == 0) { // i'v found it !
      memset(&strm[i], 0, 12);
      foundat = i;
      break;
    }
  }
  
  if (foundat == -1) {
    //Can't find the pattern in the ASN1 packet.
    PTRACE(1, "RAS\tCould not do H.235 hashing!");
    return FALSE;
  }
  
 /*******
  * 
  * generate a HMAC-SHA1 key over the hole message
  * and save it in at (step 3) located position.
  * in the asn1 packet.
  */
  
  char key[12];
 
  /** make a SHA1 hash before send to the hmac_sha1 */
  unsigned char secretkey[20];
  
  SHA1((unsigned char *)securityInfo->password.GetPointer(),
        securityInfo->password.GetSize() -1, 
        secretkey);

  hmac_sha(secretkey,
           20,
           strm.GetPointer(), 
           strm.GetSize(),
           key,
           12);
  
  memcpy(&strm[foundat], key, 12);
  
  PTRACE(3, "RAS\tH.235 hashing succeeded.");
  return TRUE;
}


H225_ArrayOf_CryptoH323Token * H323RasH235PDU::GetCryptoTokens()
{
  switch(tag) {
  case e_gatekeeperRequest:
    {
      H225_GatekeeperRequest &ref = *this;
      if(!ref.HasOptionalField(H225_GatekeeperRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_gatekeeperConfirm:
    {
      H225_GatekeeperConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_GatekeeperConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_gatekeeperReject:
    {
      H225_GatekeeperReject &ref = *this;
      if(!ref.HasOptionalField(H225_GatekeeperReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_registrationRequest:
    {
      H225_RegistrationRequest &ref = *this;
      if(!ref.HasOptionalField(H225_RegistrationRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_registrationConfirm:
    {
      H225_RegistrationConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_RegistrationConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_registrationReject:
    {
      H225_RegistrationReject &ref = *this;
      if(!ref.HasOptionalField(H225_RegistrationReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_unregistrationRequest:
    {
      H225_UnregistrationRequest &ref = *this;
      if(!ref.HasOptionalField(H225_UnregistrationRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_unregistrationConfirm:
    {
      H225_UnregistrationConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_UnregistrationConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_unregistrationReject:
    {
      H225_UnregistrationReject &ref = *this;
      if(!ref.HasOptionalField(H225_UnregistrationReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_admissionRequest:
    {
      H225_AdmissionRequest &ref = *this;
      if(!ref.HasOptionalField(H225_AdmissionRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_admissionConfirm:
    {
      H225_AdmissionConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_AdmissionConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_admissionReject:
    {
      H225_AdmissionReject &ref = *this;
      if(!ref.HasOptionalField(H225_AdmissionReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_bandwidthRequest:
    {
      H225_BandwidthRequest &ref = *this;
      if(!ref.HasOptionalField(H225_BandwidthRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_bandwidthConfirm:
    {
      H225_BandwidthConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_BandwidthConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_bandwidthReject:
    {
      H225_BandwidthReject &ref = *this;
      if(!ref.HasOptionalField(H225_BandwidthReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_disengageRequest:
    {
      H225_DisengageRequest &ref = *this;
      if(!ref.HasOptionalField(H225_DisengageRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_disengageConfirm:
    {
      H225_DisengageConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_DisengageConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_disengageReject:
    {
      H225_DisengageReject &ref = *this;
      if(!ref.HasOptionalField(H225_DisengageReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_locationRequest:
    {
      H225_LocationRequest &ref = *this;
      if(!ref.HasOptionalField(H225_LocationRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_locationConfirm:
    {
      H225_LocationConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_LocationConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_locationReject:
    {
      H225_LocationReject &ref = *this;
      if(!ref.HasOptionalField(H225_LocationReject::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_infoRequest:
    {
      H225_InfoRequest &ref = *this;
      if(!ref.HasOptionalField(H225_InfoRequest::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_infoRequestResponse:
    {
      H225_InfoRequestResponse &ref = *this;
      if(!ref.HasOptionalField(H225_InfoRequestResponse::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_nonStandardMessage:
    {
      H225_NonStandardMessage &ref = *this;
      if(!ref.HasOptionalField(H225_NonStandardMessage::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_unknownMessageResponse:
    {
      H225_UnknownMessageResponse &ref = *this;
      if(!ref.HasOptionalField(H225_UnknownMessageResponse::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_requestInProgress:
    {
      H225_RequestInProgress &ref = *this;
      if(!ref.HasOptionalField(H225_RequestInProgress::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_resourcesAvailableIndicate:
    {
      H225_ResourcesAvailableIndicate &ref = *this;
      if(!ref.HasOptionalField(H225_ResourcesAvailableIndicate::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_resourcesAvailableConfirm:
    {
      H225_ResourcesAvailableConfirm &ref = *this;
      if(!ref.HasOptionalField(H225_ResourcesAvailableConfirm::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_infoRequestAck:
    {
      H225_InfoRequestAck &ref = *this;
      if(!ref.HasOptionalField(H225_InfoRequestAck::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
  case e_infoRequestNak:
    {
      H225_InfoRequestNak &ref = *this;
      if(!ref.HasOptionalField(H225_InfoRequestNak::e_cryptoTokens))
        return NULL;
      return &ref.m_cryptoTokens;
    }
    break;
    
   }
   return NULL;
}


H323RasH235PDU::SecurityState H323RasH235PDU::BeforeEncode(H225_ArrayOf_CryptoH323Token & cryptoTokens)
{
  if (securityInfo == NULL)
    return SECURE_DISABLED;

  cryptoTokens.SetSize(1);
  return PrepareToken(cryptoTokens[0]);
}


H323RasH235PDU::SecurityState H323RasH235PDU::PrepareToken(H225_CryptoH323Token & h323crypt)
{
  if (securityInfo == NULL)
    return SECURE_DISABLED;

  h323crypt.SetTag(H225_CryptoH323Token::e_nestedcryptoToken); // Create a object
  
  H235_CryptoToken &tk = h323crypt;
  
  tk.SetTag(H235_CryptoToken::e_cryptoHashedToken);
  
  H235_CryptoToken_cryptoHashedToken &hashcrtoken = tk;
  
  // tokenOID = "A"
  hashcrtoken.m_tokenOID = ThisIsA;
  
  //ClearToken
  H235_ClearToken &clstk = hashcrtoken.m_hashedVals;
  
  clstk.IncludeOptionalField(H235_ClearToken::e_timeStamp);
  clstk.IncludeOptionalField(H235_ClearToken::e_random);
  clstk.IncludeOptionalField(H235_ClearToken::e_generalID);
  
  // tokenOID = "T"
  clstk.m_tokenOID  = ThisIsT;
  
  clstk.m_generalID = securityInfo->destination;
  
  clstk.m_random    = ++securityInfo->randomSequenceNumber;
  clstk.m_timeStamp = (unsigned)time(NULL);
  
  //H235_HASHED
  H235_HASHED<H235_EncodedGeneralToken> &has = hashcrtoken.m_token;
  
  //  algorithmOID = "U"
  has.m_algorithmOID = ThisIsU;
  has.m_paramS.m_ranInt = 0;


  /*******
   * step 1
   *
   * set a pattern for the hash value
   *
   */

  has.m_hash.SetData(96, pattern, 12);

  return SECURE_OK;
}



H323RasH235PDU::SecurityState H323RasH235PDU::VerifyPDU(BYTE * asnMsg,
                                                        PINDEX asnLen,
                                                        const H225_CryptoH323Token & crToken)
{
  if (securityInfo == NULL)
    return SECURE_DISABLED;

#if defined(__GNUC__)
#warning "Multi-threading problem, need to remove statics from H323RasH235PDU::VerifyPDU!"
#elif defined(_MSC_VER)
#pragma message("Warning: Multi-threading problem, need to remove statics from H323RasH235PDU::VerifyPDU!")
#endif
  static unsigned int oldrandom    = 0;
  static unsigned int oldtimestamp = 0;


  //verify the CrToken
  if (crToken.GetTag() != H225_CryptoH323Token::e_nestedcryptoToken)
    return SECURE_INVARG;
  
  const H235_CryptoToken & crNested = crToken;
  if (crNested.GetTag() != H235_CryptoToken::e_cryptoHashedToken)
    return SECURE_INVARG;
  
  const H235_CryptoToken_cryptoHashedToken &crHashed = crNested;
  
  //first verify the timestamp
  if (crHashed.m_hashedVals.m_timeStamp > (unsigned int)time(NULL) + TIMESPAN_FOR_VERIFY) {
    PTRACE(1, "Security error(Decode): The time has elapsed.");
    //the time has elapsed
    return SECURE_ERROR;
  }
  
  //verify the randomnumber
  if (crHashed.m_hashedVals.m_random.GetValue() == oldrandom &&
      crHashed.m_hashedVals.m_timeStamp.GetValue() == oldtimestamp) {
    //a message with this timespamp and the same random number was already verified
    PTRACE(1, "Security error(Decode): Two messages with the same random and timestamp");
    return SECURE_ERROR;
  }
  
  //verify the username
  if (!crHashed.m_hashedVals.HasOptionalField(H235_ClearToken::e_generalID))
    return SECURE_ERROR;
  
  if (crHashed.m_hashedVals.m_generalID.GetValue() != securityInfo->username) {
    PTRACE(1, "Security error(Decode): Wrong destination.");
    return SECURE_ERROR;
  }
  
  //verify the crypto OIDs
  
  // "A" indicates that the hole messages is used for authentication.
  if (crHashed.m_tokenOID != ThisIsA) {
    PTRACE(1, "Security error(Decode): Auth. was not computed over all Msg fields.");
    return SECURE_ERROR;
  }
  
  // "T" indicates that the hashed token of the CryptoToken is used for authentication.
  if (crHashed.m_hashedVals.m_tokenOID != ThisIsT) {
    PTRACE(1, "Security error(Decode): ClearToken was not used for Auth.");
    return SECURE_ERROR;
  }
  
  // "U" indicates that the HMAC-SHA1-96 alorigthm is used.
  
  if (crHashed.m_token.m_algorithmOID != ThisIsU) {
    PTRACE(1, "Security error(Decode): HMAC-SHA1-96 was not used");
    return SECURE_ERROR;
  }
  
  
  /****
  * step 1
  * extract the variable hash and save it
  *
  */
  unsigned char  RV [12];
  
  if (crHashed.m_token.m_hash.GetSize() != 96)
    return SECURE_INVARG;
  
  const unsigned char *data = crHashed.m_token.m_hash.GetDataPointer();
  memcpy(RV, data, 12);
  
  
  /****
  * step 4
  * lookup the variable int the orginal ASN1 packet
  * and set it to 0.
  */
  PINDEX foundat = 0;
  bool found = false;
  
  for (;;) {
    for (PINDEX i = foundat; i <= asnLen - 12; i++) {
      if (memcmp(asnMsg+i, data, 12) == 0) { // i'v found it !
        foundat = i;
        found = true;
        break;
      }
    }
    
    if (!found && foundat != 0) {
      //have tryed but does not match
      return SECURE_ATTACKED;
    }

    if (!found)
      return SECURE_ERROR;
    
    found = false;
    
    memset(asnMsg+foundat, 0, 12);
    
    /****
    * step 5
    * generate a HMAC-SHA1 key over the hole packet
    *
    */
    
    char key[12];
    unsigned char secretkey[20];
    SHA1((unsigned char *)securityInfo->password.GetPointer(),
         securityInfo->password.GetSize() -1, 
         secretkey);
    
    hmac_sha(secretkey,
             20,
             asnMsg,
             asnLen,
             key,
             12);
    
    
    /****
    * step 6
    * compare the two keys
    *
    */
    if(memcmp(key, RV, 12) == 0) {
      // Keys are the same !! Ok
      break;
    }

    if(foundat < asnLen - 12)
    {
      
    }
    else
    {
      return SECURE_ATTACKED;
    }
  }
  
  // save the values for the next call
  oldrandom    = crHashed.m_hashedVals.m_random;
  oldtimestamp = crHashed.m_hashedVals.m_timeStamp;
  
  
  return SECURE_OK;
}


/////////////////////////////////////////////////////////////////////////////
