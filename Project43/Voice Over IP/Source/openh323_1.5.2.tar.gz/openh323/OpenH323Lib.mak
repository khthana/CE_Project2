# Microsoft Developer Studio Generated NMAKE File, Based on OpenH323Lib.dsp
!IF "$(CFG)" == ""
CFG=OpenH323Lib - Win32 SSL Debug
!MESSAGE No configuration specified. Defaulting to OpenH323Lib - Win32 SSL Debug.
!ENDIF 

!IF "$(CFG)" != "OpenH323Lib - Win32 Release" && "$(CFG)" != "OpenH323Lib - Win32 Debug" && "$(CFG)" != "OpenH323Lib - Win32 No Trace" && "$(CFG)" != "OpenH323Lib - Win32 SSL Release" && "$(CFG)" != "OpenH323Lib - Win32 SSL Debug" && "$(CFG)" != "OpenH323Lib - Win32 SSL No Trace"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "OpenH323Lib.mak" CFG="OpenH323Lib - Win32 SSL Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "OpenH323Lib - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 No Trace" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 SSL Release" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 SSL Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 SSL No Trace" (based on "Win32 (x86) Static Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

OUTDIR=.\lib
INTDIR=.\lib\Release
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

ALL : ".\src\mcspdu.cxx" ".\src\ldap.cxx" ".\src\h4509.cxx" ".\src\h4508.cxx" ".\src\h4507.cxx" ".\src\h4506.cxx" ".\src\h4505.cxx" ".\src\h4504.cxx" ".\src\h4503.cxx" ".\src\h45011.cxx" ".\src\h45010.cxx" ".\src\gccpdu.cxx" ".\include\mcspdu.h" ".\include\ldap.h" ".\include\h4509.h" ".\include\h4508.h" ".\include\h4507.h" ".\include\h4506.h" ".\include\h4505.h" ".\include\h4504.h" ".\include\h4503.h" ".\include\h45011.h" ".\include\h45010.h" ".\include\gccpdu.h" "$(OUTDIR)\OpenH323s.lib"


CLEAN :
	-@erase "$(INTDIR)\add.obj"
	-@erase "$(INTDIR)\analys.obj"
	-@erase "$(INTDIR)\bsynz.obj"
	-@erase "$(INTDIR)\bv.obj"
	-@erase "$(INTDIR)\channels.obj"
	-@erase "$(INTDIR)\chanwr.obj"
	-@erase "$(INTDIR)\code.obj"
	-@erase "$(INTDIR)\codecs.obj"
	-@erase "$(INTDIR)\dcbias.obj"
	-@erase "$(INTDIR)\dct.obj"
	-@erase "$(INTDIR)\decode.obj"
	-@erase "$(INTDIR)\decode_.obj"
	-@erase "$(INTDIR)\deemp.obj"
	-@erase "$(INTDIR)\difmag.obj"
	-@erase "$(INTDIR)\dyptrk.obj"
	-@erase "$(INTDIR)\encode_.obj"
	-@erase "$(INTDIR)\encoder-h261.obj"
	-@erase "$(INTDIR)\energy.obj"
	-@erase "$(INTDIR)\f2clib.obj"
	-@erase "$(INTDIR)\g711.obj"
	-@erase "$(INTDIR)\gccpdu.obj"
	-@erase "$(INTDIR)\gkclient.obj"
	-@erase "$(INTDIR)\gsm_create.obj"
	-@erase "$(INTDIR)\gsm_decode.obj"
	-@erase "$(INTDIR)\gsm_destroy.obj"
	-@erase "$(INTDIR)\gsm_encode.obj"
	-@erase "$(INTDIR)\gsm_option.obj"
	-@erase "$(INTDIR)\gsmcodec.obj"
	-@erase "$(INTDIR)\guid.obj"
	-@erase "$(INTDIR)\h225.obj"
	-@erase "$(INTDIR)\h235.obj"
	-@erase "$(INTDIR)\h235ras.obj"
	-@erase "$(INTDIR)\h235security.obj"
	-@erase "$(INTDIR)\h245_1.obj"
	-@erase "$(INTDIR)\h245_2.obj"
	-@erase "$(INTDIR)\h261codec.obj"
	-@erase "$(INTDIR)\h323.obj"
	-@erase "$(INTDIR)\h323caps.obj"
	-@erase "$(INTDIR)\h323ep.obj"
	-@erase "$(INTDIR)\h323neg.obj"
	-@erase "$(INTDIR)\h323pdu.obj"
	-@erase "$(INTDIR)\h323rtp.obj"
	-@erase "$(INTDIR)\h4501.obj"
	-@erase "$(INTDIR)\h45010.obj"
	-@erase "$(INTDIR)\h45011.obj"
	-@erase "$(INTDIR)\h4502.obj"
	-@erase "$(INTDIR)\h4503.obj"
	-@erase "$(INTDIR)\h4504.obj"
	-@erase "$(INTDIR)\h4505.obj"
	-@erase "$(INTDIR)\h4506.obj"
	-@erase "$(INTDIR)\h4507.obj"
	-@erase "$(INTDIR)\h4508.obj"
	-@erase "$(INTDIR)\h4509.obj"
	-@erase "$(INTDIR)\h450pdu.obj"
	-@erase "$(INTDIR)\ham84.obj"
	-@erase "$(INTDIR)\hp100.obj"
	-@erase "$(INTDIR)\huffcode.obj"
	-@erase "$(INTDIR)\invert.obj"
	-@erase "$(INTDIR)\irc2pc.obj"
	-@erase "$(INTDIR)\ivfilt.obj"
	-@erase "$(INTDIR)\ixjwin32.obj"
	-@erase "$(INTDIR)\jitter.obj"
	-@erase "$(INTDIR)\ldap.obj"
	-@erase "$(INTDIR)\lid.obj"
	-@erase "$(INTDIR)\long_term.obj"
	-@erase "$(INTDIR)\lpc.obj"
	-@erase "$(INTDIR)\lpc10codec.obj"
	-@erase "$(INTDIR)\lpcdec.obj"
	-@erase "$(INTDIR)\lpcenc.obj"
	-@erase "$(INTDIR)\lpcini.obj"
	-@erase "$(INTDIR)\lpfilt.obj"
	-@erase "$(INTDIR)\mcspdu.obj"
	-@erase "$(INTDIR)\mediafmt.obj"
	-@erase "$(INTDIR)\median.obj"
	-@erase "$(INTDIR)\mload.obj"
	-@erase "$(INTDIR)\mscodecs.obj"
	-@erase "$(INTDIR)\onset.obj"
	-@erase "$(INTDIR)\OpenH323Lib.pch"
	-@erase "$(INTDIR)\p64.obj"
	-@erase "$(INTDIR)\p64encoder.obj"
	-@erase "$(INTDIR)\pitsyn.obj"
	-@erase "$(INTDIR)\placea.obj"
	-@erase "$(INTDIR)\placev.obj"
	-@erase "$(INTDIR)\precompile.obj"
	-@erase "$(INTDIR)\preemp.obj"
	-@erase "$(INTDIR)\prepro.obj"
	-@erase "$(INTDIR)\preprocess.obj"
	-@erase "$(INTDIR)\q931.obj"
	-@erase "$(INTDIR)\random.obj"
	-@erase "$(INTDIR)\rcchk.obj"
	-@erase "$(INTDIR)\rpe.obj"
	-@erase "$(INTDIR)\rtp.obj"
	-@erase "$(INTDIR)\short_term.obj"
	-@erase "$(INTDIR)\synths.obj"
	-@erase "$(INTDIR)\table.obj"
	-@erase "$(INTDIR)\tbdm.obj"
	-@erase "$(INTDIR)\transmitter.obj"
	-@erase "$(INTDIR)\transports.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vid_coder.obj"
	-@erase "$(INTDIR)\videoio.obj"
	-@erase "$(INTDIR)\voicin.obj"
	-@erase "$(INTDIR)\vparms.obj"
	-@erase "$(INTDIR)\vpblid.obj"
	-@erase "$(INTDIR)\x224.obj"
	-@erase "$(INTDIR)\x880.obj"
	-@erase "$(OUTDIR)\OpenH323s.lib"
	-@erase ".\include\gccpdu.h"
	-@erase ".\include\h45010.h"
	-@erase ".\include\h45011.h"
	-@erase ".\include\h4503.h"
	-@erase ".\include\h4504.h"
	-@erase ".\include\h4505.h"
	-@erase ".\include\h4506.h"
	-@erase ".\include\h4507.h"
	-@erase ".\include\h4508.h"
	-@erase ".\include\h4509.h"
	-@erase ".\include\ldap.h"
	-@erase ".\include\mcspdu.h"
	-@erase ".\src\gccpdu.cxx"
	-@erase ".\src\h45010.cxx"
	-@erase ".\src\h45011.cxx"
	-@erase ".\src\h4503.cxx"
	-@erase ".\src\h4504.cxx"
	-@erase ".\src\h4505.cxx"
	-@erase ".\src\h4506.cxx"
	-@erase ".\src\h4507.cxx"
	-@erase ".\src\h4508.cxx"
	-@erase ".\src\h4509.cxx"
	-@erase ".\src\ldap.cxx"
	-@erase ".\src\mcspdu.cxx"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323Lib.bsc" 
BSC32_SBRS= \
	
LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\OpenH323s.lib" 
LIB32_OBJS= \
	"$(INTDIR)\channels.obj" \
	"$(INTDIR)\codecs.obj" \
	"$(INTDIR)\g711.obj" \
	"$(INTDIR)\gkclient.obj" \
	"$(INTDIR)\gsmcodec.obj" \
	"$(INTDIR)\guid.obj" \
	"$(INTDIR)\h235security.obj" \
	"$(INTDIR)\h261codec.obj" \
	"$(INTDIR)\h323.obj" \
	"$(INTDIR)\h323caps.obj" \
	"$(INTDIR)\h323ep.obj" \
	"$(INTDIR)\h323neg.obj" \
	"$(INTDIR)\h323pdu.obj" \
	"$(INTDIR)\h323rtp.obj" \
	"$(INTDIR)\h450pdu.obj" \
	"$(INTDIR)\ixjwin32.obj" \
	"$(INTDIR)\jitter.obj" \
	"$(INTDIR)\lid.obj" \
	"$(INTDIR)\lpc10codec.obj" \
	"$(INTDIR)\mediafmt.obj" \
	"$(INTDIR)\mscodecs.obj" \
	"$(INTDIR)\precompile.obj" \
	"$(INTDIR)\q931.obj" \
	"$(INTDIR)\rtp.obj" \
	"$(INTDIR)\transports.obj" \
	"$(INTDIR)\videoio.obj" \
	"$(INTDIR)\vpblid.obj" \
	"$(INTDIR)\x224.obj" \
	"$(INTDIR)\gccpdu.obj" \
	"$(INTDIR)\h225.obj" \
	"$(INTDIR)\h235.obj" \
	"$(INTDIR)\h245_1.obj" \
	"$(INTDIR)\h245_2.obj" \
	"$(INTDIR)\h4501.obj" \
	"$(INTDIR)\h45010.obj" \
	"$(INTDIR)\h45011.obj" \
	"$(INTDIR)\h4502.obj" \
	"$(INTDIR)\h4503.obj" \
	"$(INTDIR)\h4504.obj" \
	"$(INTDIR)\h4505.obj" \
	"$(INTDIR)\h4506.obj" \
	"$(INTDIR)\h4507.obj" \
	"$(INTDIR)\h4508.obj" \
	"$(INTDIR)\h4509.obj" \
	"$(INTDIR)\ldap.obj" \
	"$(INTDIR)\mcspdu.obj" \
	"$(INTDIR)\x880.obj" \
	"$(INTDIR)\add.obj" \
	"$(INTDIR)\code.obj" \
	"$(INTDIR)\decode.obj" \
	"$(INTDIR)\gsm_create.obj" \
	"$(INTDIR)\gsm_decode.obj" \
	"$(INTDIR)\gsm_destroy.obj" \
	"$(INTDIR)\gsm_encode.obj" \
	"$(INTDIR)\gsm_option.obj" \
	"$(INTDIR)\long_term.obj" \
	"$(INTDIR)\lpc.obj" \
	"$(INTDIR)\preprocess.obj" \
	"$(INTDIR)\rpe.obj" \
	"$(INTDIR)\short_term.obj" \
	"$(INTDIR)\table.obj" \
	"$(INTDIR)\bv.obj" \
	"$(INTDIR)\huffcode.obj" \
	"$(INTDIR)\dct.obj" \
	"$(INTDIR)\encoder-h261.obj" \
	"$(INTDIR)\p64.obj" \
	"$(INTDIR)\p64encoder.obj" \
	"$(INTDIR)\transmitter.obj" \
	"$(INTDIR)\vid_coder.obj" \
	"$(INTDIR)\analys.obj" \
	"$(INTDIR)\bsynz.obj" \
	"$(INTDIR)\chanwr.obj" \
	"$(INTDIR)\dcbias.obj" \
	"$(INTDIR)\decode_.obj" \
	"$(INTDIR)\deemp.obj" \
	"$(INTDIR)\difmag.obj" \
	"$(INTDIR)\dyptrk.obj" \
	"$(INTDIR)\encode_.obj" \
	"$(INTDIR)\energy.obj" \
	"$(INTDIR)\f2clib.obj" \
	"$(INTDIR)\ham84.obj" \
	"$(INTDIR)\hp100.obj" \
	"$(INTDIR)\invert.obj" \
	"$(INTDIR)\irc2pc.obj" \
	"$(INTDIR)\ivfilt.obj" \
	"$(INTDIR)\lpcdec.obj" \
	"$(INTDIR)\lpcenc.obj" \
	"$(INTDIR)\lpcini.obj" \
	"$(INTDIR)\lpfilt.obj" \
	"$(INTDIR)\median.obj" \
	"$(INTDIR)\mload.obj" \
	"$(INTDIR)\onset.obj" \
	"$(INTDIR)\pitsyn.obj" \
	"$(INTDIR)\placea.obj" \
	"$(INTDIR)\placev.obj" \
	"$(INTDIR)\preemp.obj" \
	"$(INTDIR)\prepro.obj" \
	"$(INTDIR)\random.obj" \
	"$(INTDIR)\rcchk.obj" \
	"$(INTDIR)\synths.obj" \
	"$(INTDIR)\tbdm.obj" \
	"$(INTDIR)\voicin.obj" \
	"$(INTDIR)\vparms.obj" \
	"$(INTDIR)\h235ras.obj"

"$(OUTDIR)\OpenH323s.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

OUTDIR=.\lib
INTDIR=.\lib\Debug
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

ALL : ".\src\mcspdu.cxx" ".\src\ldap.cxx" ".\src\h4509.cxx" ".\src\h4508.cxx" ".\src\h4507.cxx" ".\src\h4506.cxx" ".\src\h4505.cxx" ".\src\h4504.cxx" ".\src\h4503.cxx" ".\src\h45011.cxx" ".\src\h45010.cxx" ".\src\gccpdu.cxx" ".\include\mcspdu.h" ".\include\ldap.h" ".\include\h4509.h" ".\include\h4508.h" ".\include\h4507.h" ".\include\h4506.h" ".\include\h4505.h" ".\include\h4504.h" ".\include\h4503.h" ".\include\h45011.h" ".\include\h45010.h" ".\include\gccpdu.h" "$(OUTDIR)\OpenH323sd.lib" "$(OUTDIR)\OpenH323Lib.bsc"


CLEAN :
	-@erase "$(INTDIR)\add.obj"
	-@erase "$(INTDIR)\add.sbr"
	-@erase "$(INTDIR)\analys.obj"
	-@erase "$(INTDIR)\analys.sbr"
	-@erase "$(INTDIR)\bsynz.obj"
	-@erase "$(INTDIR)\bsynz.sbr"
	-@erase "$(INTDIR)\bv.obj"
	-@erase "$(INTDIR)\bv.sbr"
	-@erase "$(INTDIR)\channels.obj"
	-@erase "$(INTDIR)\channels.sbr"
	-@erase "$(INTDIR)\chanwr.obj"
	-@erase "$(INTDIR)\chanwr.sbr"
	-@erase "$(INTDIR)\code.obj"
	-@erase "$(INTDIR)\code.sbr"
	-@erase "$(INTDIR)\codecs.obj"
	-@erase "$(INTDIR)\codecs.sbr"
	-@erase "$(INTDIR)\dcbias.obj"
	-@erase "$(INTDIR)\dcbias.sbr"
	-@erase "$(INTDIR)\dct.obj"
	-@erase "$(INTDIR)\dct.sbr"
	-@erase "$(INTDIR)\decode.obj"
	-@erase "$(INTDIR)\decode.sbr"
	-@erase "$(INTDIR)\decode_.obj"
	-@erase "$(INTDIR)\decode_.sbr"
	-@erase "$(INTDIR)\deemp.obj"
	-@erase "$(INTDIR)\deemp.sbr"
	-@erase "$(INTDIR)\difmag.obj"
	-@erase "$(INTDIR)\difmag.sbr"
	-@erase "$(INTDIR)\dyptrk.obj"
	-@erase "$(INTDIR)\dyptrk.sbr"
	-@erase "$(INTDIR)\encode_.obj"
	-@erase "$(INTDIR)\encode_.sbr"
	-@erase "$(INTDIR)\encoder-h261.obj"
	-@erase "$(INTDIR)\encoder-h261.sbr"
	-@erase "$(INTDIR)\energy.obj"
	-@erase "$(INTDIR)\energy.sbr"
	-@erase "$(INTDIR)\f2clib.obj"
	-@erase "$(INTDIR)\f2clib.sbr"
	-@erase "$(INTDIR)\g711.obj"
	-@erase "$(INTDIR)\g711.sbr"
	-@erase "$(INTDIR)\gccpdu.obj"
	-@erase "$(INTDIR)\gccpdu.sbr"
	-@erase "$(INTDIR)\gkclient.obj"
	-@erase "$(INTDIR)\gkclient.sbr"
	-@erase "$(INTDIR)\gsm_create.obj"
	-@erase "$(INTDIR)\gsm_create.sbr"
	-@erase "$(INTDIR)\gsm_decode.obj"
	-@erase "$(INTDIR)\gsm_decode.sbr"
	-@erase "$(INTDIR)\gsm_destroy.obj"
	-@erase "$(INTDIR)\gsm_destroy.sbr"
	-@erase "$(INTDIR)\gsm_encode.obj"
	-@erase "$(INTDIR)\gsm_encode.sbr"
	-@erase "$(INTDIR)\gsm_option.obj"
	-@erase "$(INTDIR)\gsm_option.sbr"
	-@erase "$(INTDIR)\gsmcodec.obj"
	-@erase "$(INTDIR)\gsmcodec.sbr"
	-@erase "$(INTDIR)\guid.obj"
	-@erase "$(INTDIR)\guid.sbr"
	-@erase "$(INTDIR)\h225.obj"
	-@erase "$(INTDIR)\h225.sbr"
	-@erase "$(INTDIR)\h235.obj"
	-@erase "$(INTDIR)\h235.sbr"
	-@erase "$(INTDIR)\h235ras.obj"
	-@erase "$(INTDIR)\h235ras.sbr"
	-@erase "$(INTDIR)\h235security.obj"
	-@erase "$(INTDIR)\h235security.sbr"
	-@erase "$(INTDIR)\h245_1.obj"
	-@erase "$(INTDIR)\h245_1.sbr"
	-@erase "$(INTDIR)\h245_2.obj"
	-@erase "$(INTDIR)\h245_2.sbr"
	-@erase "$(INTDIR)\h261codec.obj"
	-@erase "$(INTDIR)\h261codec.sbr"
	-@erase "$(INTDIR)\h323.obj"
	-@erase "$(INTDIR)\h323.sbr"
	-@erase "$(INTDIR)\h323caps.obj"
	-@erase "$(INTDIR)\h323caps.sbr"
	-@erase "$(INTDIR)\h323ep.obj"
	-@erase "$(INTDIR)\h323ep.sbr"
	-@erase "$(INTDIR)\h323neg.obj"
	-@erase "$(INTDIR)\h323neg.sbr"
	-@erase "$(INTDIR)\h323pdu.obj"
	-@erase "$(INTDIR)\h323pdu.sbr"
	-@erase "$(INTDIR)\h323rtp.obj"
	-@erase "$(INTDIR)\h323rtp.sbr"
	-@erase "$(INTDIR)\h4501.obj"
	-@erase "$(INTDIR)\h4501.sbr"
	-@erase "$(INTDIR)\h45010.obj"
	-@erase "$(INTDIR)\h45010.sbr"
	-@erase "$(INTDIR)\h45011.obj"
	-@erase "$(INTDIR)\h45011.sbr"
	-@erase "$(INTDIR)\h4502.obj"
	-@erase "$(INTDIR)\h4502.sbr"
	-@erase "$(INTDIR)\h4503.obj"
	-@erase "$(INTDIR)\h4503.sbr"
	-@erase "$(INTDIR)\h4504.obj"
	-@erase "$(INTDIR)\h4504.sbr"
	-@erase "$(INTDIR)\h4505.obj"
	-@erase "$(INTDIR)\h4505.sbr"
	-@erase "$(INTDIR)\h4506.obj"
	-@erase "$(INTDIR)\h4506.sbr"
	-@erase "$(INTDIR)\h4507.obj"
	-@erase "$(INTDIR)\h4507.sbr"
	-@erase "$(INTDIR)\h4508.obj"
	-@erase "$(INTDIR)\h4508.sbr"
	-@erase "$(INTDIR)\h4509.obj"
	-@erase "$(INTDIR)\h4509.sbr"
	-@erase "$(INTDIR)\h450pdu.obj"
	-@erase "$(INTDIR)\h450pdu.sbr"
	-@erase "$(INTDIR)\ham84.obj"
	-@erase "$(INTDIR)\ham84.sbr"
	-@erase "$(INTDIR)\hp100.obj"
	-@erase "$(INTDIR)\hp100.sbr"
	-@erase "$(INTDIR)\huffcode.obj"
	-@erase "$(INTDIR)\huffcode.sbr"
	-@erase "$(INTDIR)\invert.obj"
	-@erase "$(INTDIR)\invert.sbr"
	-@erase "$(INTDIR)\irc2pc.obj"
	-@erase "$(INTDIR)\irc2pc.sbr"
	-@erase "$(INTDIR)\ivfilt.obj"
	-@erase "$(INTDIR)\ivfilt.sbr"
	-@erase "$(INTDIR)\ixjwin32.obj"
	-@erase "$(INTDIR)\ixjwin32.sbr"
	-@erase "$(INTDIR)\jitter.obj"
	-@erase "$(INTDIR)\jitter.sbr"
	-@erase "$(INTDIR)\ldap.obj"
	-@erase "$(INTDIR)\ldap.sbr"
	-@erase "$(INTDIR)\lid.obj"
	-@erase "$(INTDIR)\lid.sbr"
	-@erase "$(INTDIR)\long_term.obj"
	-@erase "$(INTDIR)\long_term.sbr"
	-@erase "$(INTDIR)\lpc.obj"
	-@erase "$(INTDIR)\lpc.sbr"
	-@erase "$(INTDIR)\lpc10codec.obj"
	-@erase "$(INTDIR)\lpc10codec.sbr"
	-@erase "$(INTDIR)\lpcdec.obj"
	-@erase "$(INTDIR)\lpcdec.sbr"
	-@erase "$(INTDIR)\lpcenc.obj"
	-@erase "$(INTDIR)\lpcenc.sbr"
	-@erase "$(INTDIR)\lpcini.obj"
	-@erase "$(INTDIR)\lpcini.sbr"
	-@erase "$(INTDIR)\lpfilt.obj"
	-@erase "$(INTDIR)\lpfilt.sbr"
	-@erase "$(INTDIR)\mcspdu.obj"
	-@erase "$(INTDIR)\mcspdu.sbr"
	-@erase "$(INTDIR)\mediafmt.obj"
	-@erase "$(INTDIR)\mediafmt.sbr"
	-@erase "$(INTDIR)\median.obj"
	-@erase "$(INTDIR)\median.sbr"
	-@erase "$(INTDIR)\mload.obj"
	-@erase "$(INTDIR)\mload.sbr"
	-@erase "$(INTDIR)\mscodecs.obj"
	-@erase "$(INTDIR)\mscodecs.sbr"
	-@erase "$(INTDIR)\onset.obj"
	-@erase "$(INTDIR)\onset.sbr"
	-@erase "$(INTDIR)\OpenH323Lib.pch"
	-@erase "$(INTDIR)\p64.obj"
	-@erase "$(INTDIR)\p64.sbr"
	-@erase "$(INTDIR)\p64encoder.obj"
	-@erase "$(INTDIR)\p64encoder.sbr"
	-@erase "$(INTDIR)\pitsyn.obj"
	-@erase "$(INTDIR)\pitsyn.sbr"
	-@erase "$(INTDIR)\placea.obj"
	-@erase "$(INTDIR)\placea.sbr"
	-@erase "$(INTDIR)\placev.obj"
	-@erase "$(INTDIR)\placev.sbr"
	-@erase "$(INTDIR)\precompile.obj"
	-@erase "$(INTDIR)\precompile.sbr"
	-@erase "$(INTDIR)\preemp.obj"
	-@erase "$(INTDIR)\preemp.sbr"
	-@erase "$(INTDIR)\prepro.obj"
	-@erase "$(INTDIR)\prepro.sbr"
	-@erase "$(INTDIR)\preprocess.obj"
	-@erase "$(INTDIR)\preprocess.sbr"
	-@erase "$(INTDIR)\q931.obj"
	-@erase "$(INTDIR)\q931.sbr"
	-@erase "$(INTDIR)\random.obj"
	-@erase "$(INTDIR)\random.sbr"
	-@erase "$(INTDIR)\rcchk.obj"
	-@erase "$(INTDIR)\rcchk.sbr"
	-@erase "$(INTDIR)\rpe.obj"
	-@erase "$(INTDIR)\rpe.sbr"
	-@erase "$(INTDIR)\rtp.obj"
	-@erase "$(INTDIR)\rtp.sbr"
	-@erase "$(INTDIR)\short_term.obj"
	-@erase "$(INTDIR)\short_term.sbr"
	-@erase "$(INTDIR)\synths.obj"
	-@erase "$(INTDIR)\synths.sbr"
	-@erase "$(INTDIR)\table.obj"
	-@erase "$(INTDIR)\table.sbr"
	-@erase "$(INTDIR)\tbdm.obj"
	-@erase "$(INTDIR)\tbdm.sbr"
	-@erase "$(INTDIR)\transmitter.obj"
	-@erase "$(INTDIR)\transmitter.sbr"
	-@erase "$(INTDIR)\transports.obj"
	-@erase "$(INTDIR)\transports.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\vid_coder.obj"
	-@erase "$(INTDIR)\vid_coder.sbr"
	-@erase "$(INTDIR)\videoio.obj"
	-@erase "$(INTDIR)\videoio.sbr"
	-@erase "$(INTDIR)\voicin.obj"
	-@erase "$(INTDIR)\voicin.sbr"
	-@erase "$(INTDIR)\vparms.obj"
	-@erase "$(INTDIR)\vparms.sbr"
	-@erase "$(INTDIR)\vpblid.obj"
	-@erase "$(INTDIR)\vpblid.sbr"
	-@erase "$(INTDIR)\x224.obj"
	-@erase "$(INTDIR)\x224.sbr"
	-@erase "$(INTDIR)\x880.obj"
	-@erase "$(INTDIR)\x880.sbr"
	-@erase "$(OUTDIR)\OpenH323Lib.bsc"
	-@erase "$(OUTDIR)\OpenH323sd.lib"
	-@erase ".\include\gccpdu.h"
	-@erase ".\include\h45010.h"
	-@erase ".\include\h45011.h"
	-@erase ".\include\h4503.h"
	-@erase ".\include\h4504.h"
	-@erase ".\include\h4505.h"
	-@erase ".\include\h4506.h"
	-@erase ".\include\h4507.h"
	-@erase ".\include\h4508.h"
	-@erase ".\include\h4509.h"
	-@erase ".\include\ldap.h"
	-@erase ".\include\mcspdu.h"
	-@erase ".\src\gccpdu.cxx"
	-@erase ".\src\h45010.cxx"
	-@erase ".\src\h45011.cxx"
	-@erase ".\src\h4503.cxx"
	-@erase ".\src\h4504.cxx"
	-@erase ".\src\h4505.cxx"
	-@erase ".\src\h4506.cxx"
	-@erase ".\src\h4507.cxx"
	-@erase ".\src\h4508.cxx"
	-@erase ".\src\h4509.cxx"
	-@erase ".\src\ldap.cxx"
	-@erase ".\src\mcspdu.cxx"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323Lib.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\channels.sbr" \
	"$(INTDIR)\codecs.sbr" \
	"$(INTDIR)\g711.sbr" \
	"$(INTDIR)\gkclient.sbr" \
	"$(INTDIR)\gsmcodec.sbr" \
	"$(INTDIR)\guid.sbr" \
	"$(INTDIR)\h235security.sbr" \
	"$(INTDIR)\h261codec.sbr" \
	"$(INTDIR)\h323.sbr" \
	"$(INTDIR)\h323caps.sbr" \
	"$(INTDIR)\h323ep.sbr" \
	"$(INTDIR)\h323neg.sbr" \
	"$(INTDIR)\h323pdu.sbr" \
	"$(INTDIR)\h323rtp.sbr" \
	"$(INTDIR)\h450pdu.sbr" \
	"$(INTDIR)\ixjwin32.sbr" \
	"$(INTDIR)\jitter.sbr" \
	"$(INTDIR)\lid.sbr" \
	"$(INTDIR)\lpc10codec.sbr" \
	"$(INTDIR)\mediafmt.sbr" \
	"$(INTDIR)\mscodecs.sbr" \
	"$(INTDIR)\precompile.sbr" \
	"$(INTDIR)\q931.sbr" \
	"$(INTDIR)\rtp.sbr" \
	"$(INTDIR)\transports.sbr" \
	"$(INTDIR)\videoio.sbr" \
	"$(INTDIR)\vpblid.sbr" \
	"$(INTDIR)\x224.sbr" \
	"$(INTDIR)\gccpdu.sbr" \
	"$(INTDIR)\h225.sbr" \
	"$(INTDIR)\h235.sbr" \
	"$(INTDIR)\h245_1.sbr" \
	"$(INTDIR)\h245_2.sbr" \
	"$(INTDIR)\h4501.sbr" \
	"$(INTDIR)\h45010.sbr" \
	"$(INTDIR)\h45011.sbr" \
	"$(INTDIR)\h4502.sbr" \
	"$(INTDIR)\h4503.sbr" \
	"$(INTDIR)\h4504.sbr" \
	"$(INTDIR)\h4505.sbr" \
	"$(INTDIR)\h4506.sbr" \
	"$(INTDIR)\h4507.sbr" \
	"$(INTDIR)\h4508.sbr" \
	"$(INTDIR)\h4509.sbr" \
	"$(INTDIR)\ldap.sbr" \
	"$(INTDIR)\mcspdu.sbr" \
	"$(INTDIR)\x880.sbr" \
	"$(INTDIR)\add.sbr" \
	"$(INTDIR)\code.sbr" \
	"$(INTDIR)\decode.sbr" \
	"$(INTDIR)\gsm_create.sbr" \
	"$(INTDIR)\gsm_decode.sbr" \
	"$(INTDIR)\gsm_destroy.sbr" \
	"$(INTDIR)\gsm_encode.sbr" \
	"$(INTDIR)\gsm_option.sbr" \
	"$(INTDIR)\long_term.sbr" \
	"$(INTDIR)\lpc.sbr" \
	"$(INTDIR)\preprocess.sbr" \
	"$(INTDIR)\rpe.sbr" \
	"$(INTDIR)\short_term.sbr" \
	"$(INTDIR)\table.sbr" \
	"$(INTDIR)\bv.sbr" \
	"$(INTDIR)\huffcode.sbr" \
	"$(INTDIR)\dct.sbr" \
	"$(INTDIR)\encoder-h261.sbr" \
	"$(INTDIR)\p64.sbr" \
	"$(INTDIR)\p64encoder.sbr" \
	"$(INTDIR)\transmitter.sbr" \
	"$(INTDIR)\vid_coder.sbr" \
	"$(INTDIR)\analys.sbr" \
	"$(INTDIR)\bsynz.sbr" \
	"$(INTDIR)\chanwr.sbr" \
	"$(INTDIR)\dcbias.sbr" \
	"$(INTDIR)\decode_.sbr" \
	"$(INTDIR)\deemp.sbr" \
	"$(INTDIR)\difmag.sbr" \
	"$(INTDIR)\dyptrk.sbr" \
	"$(INTDIR)\encode_.sbr" \
	"$(INTDIR)\energy.sbr" \
	"$(INTDIR)\f2clib.sbr" \
	"$(INTDIR)\ham84.sbr" \
	"$(INTDIR)\hp100.sbr" \
	"$(INTDIR)\invert.sbr" \
	"$(INTDIR)\irc2pc.sbr" \
	"$(INTDIR)\ivfilt.sbr" \
	"$(INTDIR)\lpcdec.sbr" \
	"$(INTDIR)\lpcenc.sbr" \
	"$(INTDIR)\lpcini.sbr" \
	"$(INTDIR)\lpfilt.sbr" \
	"$(INTDIR)\median.sbr" \
	"$(INTDIR)\mload.sbr" \
	"$(INTDIR)\onset.sbr" \
	"$(INTDIR)\pitsyn.sbr" \
	"$(INTDIR)\placea.sbr" \
	"$(INTDIR)\placev.sbr" \
	"$(INTDIR)\preemp.sbr" \
	"$(INTDIR)\prepro.sbr" \
	"$(INTDIR)\random.sbr" \
	"$(INTDIR)\rcchk.sbr" \
	"$(INTDIR)\synths.sbr" \
	"$(INTDIR)\tbdm.sbr" \
	"$(INTDIR)\voicin.sbr" \
	"$(INTDIR)\vparms.sbr" \
	"$(INTDIR)\h235ras.sbr"

"$(OUTDIR)\OpenH323Lib.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\OpenH323sd.lib" 
LIB32_OBJS= \
	"$(INTDIR)\channels.obj" \
	"$(INTDIR)\codecs.obj" \
	"$(INTDIR)\g711.obj" \
	"$(INTDIR)\gkclient.obj" \
	"$(INTDIR)\gsmcodec.obj" \
	"$(INTDIR)\guid.obj" \
	"$(INTDIR)\h235security.obj" \
	"$(INTDIR)\h261codec.obj" \
	"$(INTDIR)\h323.obj" \
	"$(INTDIR)\h323caps.obj" \
	"$(INTDIR)\h323ep.obj" \
	"$(INTDIR)\h323neg.obj" \
	"$(INTDIR)\h323pdu.obj" \
	"$(INTDIR)\h323rtp.obj" \
	"$(INTDIR)\h450pdu.obj" \
	"$(INTDIR)\ixjwin32.obj" \
	"$(INTDIR)\jitter.obj" \
	"$(INTDIR)\lid.obj" \
	"$(INTDIR)\lpc10codec.obj" \
	"$(INTDIR)\mediafmt.obj" \
	"$(INTDIR)\mscodecs.obj" \
	"$(INTDIR)\precompile.obj" \
	"$(INTDIR)\q931.obj" \
	"$(INTDIR)\rtp.obj" \
	"$(INTDIR)\transports.obj" \
	"$(INTDIR)\videoio.obj" \
	"$(INTDIR)\vpblid.obj" \
	"$(INTDIR)\x224.obj" \
	"$(INTDIR)\gccpdu.obj" \
	"$(INTDIR)\h225.obj" \
	"$(INTDIR)\h235.obj" \
	"$(INTDIR)\h245_1.obj" \
	"$(INTDIR)\h245_2.obj" \
	"$(INTDIR)\h4501.obj" \
	"$(INTDIR)\h45010.obj" \
	"$(INTDIR)\h45011.obj" \
	"$(INTDIR)\h4502.obj" \
	"$(INTDIR)\h4503.obj" \
	"$(INTDIR)\h4504.obj" \
	"$(INTDIR)\h4505.obj" \
	"$(INTDIR)\h4506.obj" \
	"$(INTDIR)\h4507.obj" \
	"$(INTDIR)\h4508.obj" \
	"$(INTDIR)\h4509.obj" \
	"$(INTDIR)\ldap.obj" \
	"$(INTDIR)\mcspdu.obj" \
	"$(INTDIR)\x880.obj" \
	"$(INTDIR)\add.obj" \
	"$(INTDIR)\code.obj" \
	"$(INTDIR)\decode.obj" \
	"$(INTDIR)\gsm_create.obj" \
	"$(INTDIR)\gsm_decode.obj" \
	"$(INTDIR)\gsm_destroy.obj" \
	"$(INTDIR)\gsm_encode.obj" \
	"$(INTDIR)\gsm_option.obj" \
	"$(INTDIR)\long_term.obj" \
	"$(INTDIR)\lpc.obj" \
	"$(INTDIR)\preprocess.obj" \
	"$(INTDIR)\rpe.obj" \
	"$(INTDIR)\short_term.obj" \
	"$(INTDIR)\table.obj" \
	"$(INTDIR)\bv.obj" \
	"$(INTDIR)\huffcode.obj" \
	"$(INTDIR)\dct.obj" \
	"$(INTDIR)\encoder-h261.obj" \
	"$(INTDIR)\p64.obj" \
	"$(INTDIR)\p64encoder.obj" \
	"$(INTDIR)\transmitter.obj" \
	"$(INTDIR)\vid_coder.obj" \
	"$(INTDIR)\analys.obj" \
	"$(INTDIR)\bsynz.obj" \
	"$(INTDIR)\chanwr.obj" \
	"$(INTDIR)\dcbias.obj" \
	"$(INTDIR)\decode_.obj" \
	"$(INTDIR)\deemp.obj" \
	"$(INTDIR)\difmag.obj" \
	"$(INTDIR)\dyptrk.obj" \
	"$(INTDIR)\encode_.obj" \
	"$(INTDIR)\energy.obj" \
	"$(INTDIR)\f2clib.obj" \
	"$(INTDIR)\ham84.obj" \
	"$(INTDIR)\hp100.obj" \
	"$(INTDIR)\invert.obj" \
	"$(INTDIR)\irc2pc.obj" \
	"$(INTDIR)\ivfilt.obj" \
	"$(INTDIR)\lpcdec.obj" \
	"$(INTDIR)\lpcenc.obj" \
	"$(INTDIR)\lpcini.obj" \
	"$(INTDIR)\lpfilt.obj" \
	"$(INTDIR)\median.obj" \
	"$(INTDIR)\mload.obj" \
	"$(INTDIR)\onset.obj" \
	"$(INTDIR)\pitsyn.obj" \
	"$(INTDIR)\placea.obj" \
	"$(INTDIR)\placev.obj" \
	"$(INTDIR)\preemp.obj" \
	"$(INTDIR)\prepro.obj" \
	"$(INTDIR)\random.obj" \
	"$(INTDIR)\rcchk.obj" \
	"$(INTDIR)\synths.obj" \
	"$(INTDIR)\tbdm.obj" \
	"$(INTDIR)\voicin.obj" \
	"$(INTDIR)\vparms.obj" \
	"$(INTDIR)\h235ras.obj"

"$(OUTDIR)\OpenH323sd.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

OUTDIR=.\lib
INTDIR=.\lib\NoTrace
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

ALL : ".\src\mcspdu.cxx" ".\src\ldap.cxx" ".\src\h4509.cxx" ".\src\h4508.cxx" ".\src\h4507.cxx" ".\src\h4506.cxx" ".\src\h4505.cxx" ".\src\h4504.cxx" ".\src\h4503.cxx" ".\src\h45011.cxx" ".\src\h45010.cxx" ".\src\gccpdu.cxx" ".\include\mcspdu.h" ".\include\ldap.h" ".\include\h4509.h" ".\include\h4508.h" ".\include\h4507.h" ".\include\h4506.h" ".\include\h4505.h" ".\include\h4504.h" ".\include\h4503.h" ".\include\h45011.h" ".\include\h45010.h" ".\include\gccpdu.h" "$(OUTDIR)\OpenH323sn.lib"


CLEAN :
	-@erase "$(INTDIR)\add.obj"
	-@erase "$(INTDIR)\analys.obj"
	-@erase "$(INTDIR)\bsynz.obj"
	-@erase "$(INTDIR)\bv.obj"
	-@erase "$(INTDIR)\channels.obj"
	-@erase "$(INTDIR)\chanwr.obj"
	-@erase "$(INTDIR)\code.obj"
	-@erase "$(INTDIR)\codecs.obj"
	-@erase "$(INTDIR)\dcbias.obj"
	-@erase "$(INTDIR)\dct.obj"
	-@erase "$(INTDIR)\decode.obj"
	-@erase "$(INTDIR)\decode_.obj"
	-@erase "$(INTDIR)\deemp.obj"
	-@erase "$(INTDIR)\difmag.obj"
	-@erase "$(INTDIR)\dyptrk.obj"
	-@erase "$(INTDIR)\encode_.obj"
	-@erase "$(INTDIR)\encoder-h261.obj"
	-@erase "$(INTDIR)\energy.obj"
	-@erase "$(INTDIR)\f2clib.obj"
	-@erase "$(INTDIR)\g711.obj"
	-@erase "$(INTDIR)\gccpdu.obj"
	-@erase "$(INTDIR)\gkclient.obj"
	-@erase "$(INTDIR)\gsm_create.obj"
	-@erase "$(INTDIR)\gsm_decode.obj"
	-@erase "$(INTDIR)\gsm_destroy.obj"
	-@erase "$(INTDIR)\gsm_encode.obj"
	-@erase "$(INTDIR)\gsm_option.obj"
	-@erase "$(INTDIR)\gsmcodec.obj"
	-@erase "$(INTDIR)\guid.obj"
	-@erase "$(INTDIR)\h225.obj"
	-@erase "$(INTDIR)\h235.obj"
	-@erase "$(INTDIR)\h235ras.obj"
	-@erase "$(INTDIR)\h235security.obj"
	-@erase "$(INTDIR)\h245_1.obj"
	-@erase "$(INTDIR)\h245_2.obj"
	-@erase "$(INTDIR)\h261codec.obj"
	-@erase "$(INTDIR)\h323.obj"
	-@erase "$(INTDIR)\h323caps.obj"
	-@erase "$(INTDIR)\h323ep.obj"
	-@erase "$(INTDIR)\h323neg.obj"
	-@erase "$(INTDIR)\h323pdu.obj"
	-@erase "$(INTDIR)\h323rtp.obj"
	-@erase "$(INTDIR)\h4501.obj"
	-@erase "$(INTDIR)\h45010.obj"
	-@erase "$(INTDIR)\h45011.obj"
	-@erase "$(INTDIR)\h4502.obj"
	-@erase "$(INTDIR)\h4503.obj"
	-@erase "$(INTDIR)\h4504.obj"
	-@erase "$(INTDIR)\h4505.obj"
	-@erase "$(INTDIR)\h4506.obj"
	-@erase "$(INTDIR)\h4507.obj"
	-@erase "$(INTDIR)\h4508.obj"
	-@erase "$(INTDIR)\h4509.obj"
	-@erase "$(INTDIR)\h450pdu.obj"
	-@erase "$(INTDIR)\ham84.obj"
	-@erase "$(INTDIR)\hp100.obj"
	-@erase "$(INTDIR)\huffcode.obj"
	-@erase "$(INTDIR)\invert.obj"
	-@erase "$(INTDIR)\irc2pc.obj"
	-@erase "$(INTDIR)\ivfilt.obj"
	-@erase "$(INTDIR)\ixjwin32.obj"
	-@erase "$(INTDIR)\jitter.obj"
	-@erase "$(INTDIR)\ldap.obj"
	-@erase "$(INTDIR)\lid.obj"
	-@erase "$(INTDIR)\long_term.obj"
	-@erase "$(INTDIR)\lpc.obj"
	-@erase "$(INTDIR)\lpc10codec.obj"
	-@erase "$(INTDIR)\lpcdec.obj"
	-@erase "$(INTDIR)\lpcenc.obj"
	-@erase "$(INTDIR)\lpcini.obj"
	-@erase "$(INTDIR)\lpfilt.obj"
	-@erase "$(INTDIR)\mcspdu.obj"
	-@erase "$(INTDIR)\mediafmt.obj"
	-@erase "$(INTDIR)\median.obj"
	-@erase "$(INTDIR)\mload.obj"
	-@erase "$(INTDIR)\mscodecs.obj"
	-@erase "$(INTDIR)\onset.obj"
	-@erase "$(INTDIR)\OpenH323Lib.pch"
	-@erase "$(INTDIR)\p64.obj"
	-@erase "$(INTDIR)\p64encoder.obj"
	-@erase "$(INTDIR)\pitsyn.obj"
	-@erase "$(INTDIR)\placea.obj"
	-@erase "$(INTDIR)\placev.obj"
	-@erase "$(INTDIR)\precompile.obj"
	-@erase "$(INTDIR)\preemp.obj"
	-@erase "$(INTDIR)\prepro.obj"
	-@erase "$(INTDIR)\preprocess.obj"
	-@erase "$(INTDIR)\q931.obj"
	-@erase "$(INTDIR)\random.obj"
	-@erase "$(INTDIR)\rcchk.obj"
	-@erase "$(INTDIR)\rpe.obj"
	-@erase "$(INTDIR)\rtp.obj"
	-@erase "$(INTDIR)\short_term.obj"
	-@erase "$(INTDIR)\synths.obj"
	-@erase "$(INTDIR)\table.obj"
	-@erase "$(INTDIR)\tbdm.obj"
	-@erase "$(INTDIR)\transmitter.obj"
	-@erase "$(INTDIR)\transports.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vid_coder.obj"
	-@erase "$(INTDIR)\videoio.obj"
	-@erase "$(INTDIR)\voicin.obj"
	-@erase "$(INTDIR)\vparms.obj"
	-@erase "$(INTDIR)\vpblid.obj"
	-@erase "$(INTDIR)\x224.obj"
	-@erase "$(INTDIR)\x880.obj"
	-@erase "$(OUTDIR)\OpenH323sn.lib"
	-@erase ".\include\gccpdu.h"
	-@erase ".\include\h45010.h"
	-@erase ".\include\h45011.h"
	-@erase ".\include\h4503.h"
	-@erase ".\include\h4504.h"
	-@erase ".\include\h4505.h"
	-@erase ".\include\h4506.h"
	-@erase ".\include\h4507.h"
	-@erase ".\include\h4508.h"
	-@erase ".\include\h4509.h"
	-@erase ".\include\ldap.h"
	-@erase ".\include\mcspdu.h"
	-@erase ".\src\gccpdu.cxx"
	-@erase ".\src\h45010.cxx"
	-@erase ".\src\h45011.cxx"
	-@erase ".\src\h4503.cxx"
	-@erase ".\src\h4504.cxx"
	-@erase ".\src\h4505.cxx"
	-@erase ".\src\h4506.cxx"
	-@erase ".\src\h4507.cxx"
	-@erase ".\src\h4508.cxx"
	-@erase ".\src\h4509.cxx"
	-@erase ".\src\ldap.cxx"
	-@erase ".\src\mcspdu.cxx"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323Lib.bsc" 
BSC32_SBRS= \
	
LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\OpenH323sn.lib" 
LIB32_OBJS= \
	"$(INTDIR)\channels.obj" \
	"$(INTDIR)\codecs.obj" \
	"$(INTDIR)\g711.obj" \
	"$(INTDIR)\gkclient.obj" \
	"$(INTDIR)\gsmcodec.obj" \
	"$(INTDIR)\guid.obj" \
	"$(INTDIR)\h235security.obj" \
	"$(INTDIR)\h261codec.obj" \
	"$(INTDIR)\h323.obj" \
	"$(INTDIR)\h323caps.obj" \
	"$(INTDIR)\h323ep.obj" \
	"$(INTDIR)\h323neg.obj" \
	"$(INTDIR)\h323pdu.obj" \
	"$(INTDIR)\h323rtp.obj" \
	"$(INTDIR)\h450pdu.obj" \
	"$(INTDIR)\ixjwin32.obj" \
	"$(INTDIR)\jitter.obj" \
	"$(INTDIR)\lid.obj" \
	"$(INTDIR)\lpc10codec.obj" \
	"$(INTDIR)\mediafmt.obj" \
	"$(INTDIR)\mscodecs.obj" \
	"$(INTDIR)\precompile.obj" \
	"$(INTDIR)\q931.obj" \
	"$(INTDIR)\rtp.obj" \
	"$(INTDIR)\transports.obj" \
	"$(INTDIR)\videoio.obj" \
	"$(INTDIR)\vpblid.obj" \
	"$(INTDIR)\x224.obj" \
	"$(INTDIR)\gccpdu.obj" \
	"$(INTDIR)\h225.obj" \
	"$(INTDIR)\h235.obj" \
	"$(INTDIR)\h245_1.obj" \
	"$(INTDIR)\h245_2.obj" \
	"$(INTDIR)\h4501.obj" \
	"$(INTDIR)\h45010.obj" \
	"$(INTDIR)\h45011.obj" \
	"$(INTDIR)\h4502.obj" \
	"$(INTDIR)\h4503.obj" \
	"$(INTDIR)\h4504.obj" \
	"$(INTDIR)\h4505.obj" \
	"$(INTDIR)\h4506.obj" \
	"$(INTDIR)\h4507.obj" \
	"$(INTDIR)\h4508.obj" \
	"$(INTDIR)\h4509.obj" \
	"$(INTDIR)\ldap.obj" \
	"$(INTDIR)\mcspdu.obj" \
	"$(INTDIR)\x880.obj" \
	"$(INTDIR)\add.obj" \
	"$(INTDIR)\code.obj" \
	"$(INTDIR)\decode.obj" \
	"$(INTDIR)\gsm_create.obj" \
	"$(INTDIR)\gsm_decode.obj" \
	"$(INTDIR)\gsm_destroy.obj" \
	"$(INTDIR)\gsm_encode.obj" \
	"$(INTDIR)\gsm_option.obj" \
	"$(INTDIR)\long_term.obj" \
	"$(INTDIR)\lpc.obj" \
	"$(INTDIR)\preprocess.obj" \
	"$(INTDIR)\rpe.obj" \
	"$(INTDIR)\short_term.obj" \
	"$(INTDIR)\table.obj" \
	"$(INTDIR)\bv.obj" \
	"$(INTDIR)\huffcode.obj" \
	"$(INTDIR)\dct.obj" \
	"$(INTDIR)\encoder-h261.obj" \
	"$(INTDIR)\p64.obj" \
	"$(INTDIR)\p64encoder.obj" \
	"$(INTDIR)\transmitter.obj" \
	"$(INTDIR)\vid_coder.obj" \
	"$(INTDIR)\analys.obj" \
	"$(INTDIR)\bsynz.obj" \
	"$(INTDIR)\chanwr.obj" \
	"$(INTDIR)\dcbias.obj" \
	"$(INTDIR)\decode_.obj" \
	"$(INTDIR)\deemp.obj" \
	"$(INTDIR)\difmag.obj" \
	"$(INTDIR)\dyptrk.obj" \
	"$(INTDIR)\encode_.obj" \
	"$(INTDIR)\energy.obj" \
	"$(INTDIR)\f2clib.obj" \
	"$(INTDIR)\ham84.obj" \
	"$(INTDIR)\hp100.obj" \
	"$(INTDIR)\invert.obj" \
	"$(INTDIR)\irc2pc.obj" \
	"$(INTDIR)\ivfilt.obj" \
	"$(INTDIR)\lpcdec.obj" \
	"$(INTDIR)\lpcenc.obj" \
	"$(INTDIR)\lpcini.obj" \
	"$(INTDIR)\lpfilt.obj" \
	"$(INTDIR)\median.obj" \
	"$(INTDIR)\mload.obj" \
	"$(INTDIR)\onset.obj" \
	"$(INTDIR)\pitsyn.obj" \
	"$(INTDIR)\placea.obj" \
	"$(INTDIR)\placev.obj" \
	"$(INTDIR)\preemp.obj" \
	"$(INTDIR)\prepro.obj" \
	"$(INTDIR)\random.obj" \
	"$(INTDIR)\rcchk.obj" \
	"$(INTDIR)\synths.obj" \
	"$(INTDIR)\tbdm.obj" \
	"$(INTDIR)\voicin.obj" \
	"$(INTDIR)\vparms.obj" \
	"$(INTDIR)\h235ras.obj"

"$(OUTDIR)\OpenH323sn.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

OUTDIR=.\lib
INTDIR=.\lib\Release
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

ALL : ".\src\mcspdu.cxx" ".\src\ldap.cxx" ".\src\h4509.cxx" ".\src\h4508.cxx" ".\src\h4507.cxx" ".\src\h4506.cxx" ".\src\h4505.cxx" ".\src\h4504.cxx" ".\src\h4503.cxx" ".\src\h45011.cxx" ".\src\h45010.cxx" ".\src\gccpdu.cxx" ".\include\mcspdu.h" ".\include\ldap.h" ".\include\h4509.h" ".\include\h4508.h" ".\include\h4507.h" ".\include\h4506.h" ".\include\h4505.h" ".\include\h4504.h" ".\include\h4503.h" ".\include\h45011.h" ".\include\h45010.h" ".\include\gccpdu.h" "$(OUTDIR)\OpenH323s.lib"


CLEAN :
	-@erase "$(INTDIR)\add.obj"
	-@erase "$(INTDIR)\analys.obj"
	-@erase "$(INTDIR)\bsynz.obj"
	-@erase "$(INTDIR)\bv.obj"
	-@erase "$(INTDIR)\channels.obj"
	-@erase "$(INTDIR)\chanwr.obj"
	-@erase "$(INTDIR)\code.obj"
	-@erase "$(INTDIR)\codecs.obj"
	-@erase "$(INTDIR)\dcbias.obj"
	-@erase "$(INTDIR)\dct.obj"
	-@erase "$(INTDIR)\decode.obj"
	-@erase "$(INTDIR)\decode_.obj"
	-@erase "$(INTDIR)\deemp.obj"
	-@erase "$(INTDIR)\difmag.obj"
	-@erase "$(INTDIR)\dyptrk.obj"
	-@erase "$(INTDIR)\encode_.obj"
	-@erase "$(INTDIR)\encoder-h261.obj"
	-@erase "$(INTDIR)\energy.obj"
	-@erase "$(INTDIR)\f2clib.obj"
	-@erase "$(INTDIR)\g711.obj"
	-@erase "$(INTDIR)\gccpdu.obj"
	-@erase "$(INTDIR)\gkclient.obj"
	-@erase "$(INTDIR)\gsm_create.obj"
	-@erase "$(INTDIR)\gsm_decode.obj"
	-@erase "$(INTDIR)\gsm_destroy.obj"
	-@erase "$(INTDIR)\gsm_encode.obj"
	-@erase "$(INTDIR)\gsm_option.obj"
	-@erase "$(INTDIR)\gsmcodec.obj"
	-@erase "$(INTDIR)\guid.obj"
	-@erase "$(INTDIR)\h225.obj"
	-@erase "$(INTDIR)\h235.obj"
	-@erase "$(INTDIR)\h235ras.obj"
	-@erase "$(INTDIR)\h235security.obj"
	-@erase "$(INTDIR)\h245_1.obj"
	-@erase "$(INTDIR)\h245_2.obj"
	-@erase "$(INTDIR)\h261codec.obj"
	-@erase "$(INTDIR)\h323.obj"
	-@erase "$(INTDIR)\h323caps.obj"
	-@erase "$(INTDIR)\h323ep.obj"
	-@erase "$(INTDIR)\h323neg.obj"
	-@erase "$(INTDIR)\h323pdu.obj"
	-@erase "$(INTDIR)\h323rtp.obj"
	-@erase "$(INTDIR)\h4501.obj"
	-@erase "$(INTDIR)\h45010.obj"
	-@erase "$(INTDIR)\h45011.obj"
	-@erase "$(INTDIR)\h4502.obj"
	-@erase "$(INTDIR)\h4503.obj"
	-@erase "$(INTDIR)\h4504.obj"
	-@erase "$(INTDIR)\h4505.obj"
	-@erase "$(INTDIR)\h4506.obj"
	-@erase "$(INTDIR)\h4507.obj"
	-@erase "$(INTDIR)\h4508.obj"
	-@erase "$(INTDIR)\h4509.obj"
	-@erase "$(INTDIR)\h450pdu.obj"
	-@erase "$(INTDIR)\ham84.obj"
	-@erase "$(INTDIR)\hp100.obj"
	-@erase "$(INTDIR)\huffcode.obj"
	-@erase "$(INTDIR)\invert.obj"
	-@erase "$(INTDIR)\irc2pc.obj"
	-@erase "$(INTDIR)\ivfilt.obj"
	-@erase "$(INTDIR)\ixjwin32.obj"
	-@erase "$(INTDIR)\jitter.obj"
	-@erase "$(INTDIR)\ldap.obj"
	-@erase "$(INTDIR)\lid.obj"
	-@erase "$(INTDIR)\long_term.obj"
	-@erase "$(INTDIR)\lpc.obj"
	-@erase "$(INTDIR)\lpc10codec.obj"
	-@erase "$(INTDIR)\lpcdec.obj"
	-@erase "$(INTDIR)\lpcenc.obj"
	-@erase "$(INTDIR)\lpcini.obj"
	-@erase "$(INTDIR)\lpfilt.obj"
	-@erase "$(INTDIR)\mcspdu.obj"
	-@erase "$(INTDIR)\mediafmt.obj"
	-@erase "$(INTDIR)\median.obj"
	-@erase "$(INTDIR)\mload.obj"
	-@erase "$(INTDIR)\mscodecs.obj"
	-@erase "$(INTDIR)\onset.obj"
	-@erase "$(INTDIR)\OpenH323Lib.pch"
	-@erase "$(INTDIR)\p64.obj"
	-@erase "$(INTDIR)\p64encoder.obj"
	-@erase "$(INTDIR)\pitsyn.obj"
	-@erase "$(INTDIR)\placea.obj"
	-@erase "$(INTDIR)\placev.obj"
	-@erase "$(INTDIR)\precompile.obj"
	-@erase "$(INTDIR)\preemp.obj"
	-@erase "$(INTDIR)\prepro.obj"
	-@erase "$(INTDIR)\preprocess.obj"
	-@erase "$(INTDIR)\q931.obj"
	-@erase "$(INTDIR)\random.obj"
	-@erase "$(INTDIR)\rcchk.obj"
	-@erase "$(INTDIR)\rpe.obj"
	-@erase "$(INTDIR)\rtp.obj"
	-@erase "$(INTDIR)\short_term.obj"
	-@erase "$(INTDIR)\synths.obj"
	-@erase "$(INTDIR)\table.obj"
	-@erase "$(INTDIR)\tbdm.obj"
	-@erase "$(INTDIR)\transmitter.obj"
	-@erase "$(INTDIR)\transports.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vid_coder.obj"
	-@erase "$(INTDIR)\videoio.obj"
	-@erase "$(INTDIR)\voicin.obj"
	-@erase "$(INTDIR)\vparms.obj"
	-@erase "$(INTDIR)\vpblid.obj"
	-@erase "$(INTDIR)\x224.obj"
	-@erase "$(INTDIR)\x880.obj"
	-@erase "$(OUTDIR)\OpenH323s.lib"
	-@erase ".\include\gccpdu.h"
	-@erase ".\include\h45010.h"
	-@erase ".\include\h45011.h"
	-@erase ".\include\h4503.h"
	-@erase ".\include\h4504.h"
	-@erase ".\include\h4505.h"
	-@erase ".\include\h4506.h"
	-@erase ".\include\h4507.h"
	-@erase ".\include\h4508.h"
	-@erase ".\include\h4509.h"
	-@erase ".\include\ldap.h"
	-@erase ".\include\mcspdu.h"
	-@erase ".\src\gccpdu.cxx"
	-@erase ".\src\h45010.cxx"
	-@erase ".\src\h45011.cxx"
	-@erase ".\src\h4503.cxx"
	-@erase ".\src\h4504.cxx"
	-@erase ".\src\h4505.cxx"
	-@erase ".\src\h4506.cxx"
	-@erase ".\src\h4507.cxx"
	-@erase ".\src\h4508.cxx"
	-@erase ".\src\h4509.cxx"
	-@erase ".\src\ldap.cxx"
	-@erase ".\src\mcspdu.cxx"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323Lib.bsc" 
BSC32_SBRS= \
	
LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\OpenH323s.lib" 
LIB32_OBJS= \
	"$(INTDIR)\channels.obj" \
	"$(INTDIR)\codecs.obj" \
	"$(INTDIR)\g711.obj" \
	"$(INTDIR)\gkclient.obj" \
	"$(INTDIR)\gsmcodec.obj" \
	"$(INTDIR)\guid.obj" \
	"$(INTDIR)\h235ras.obj" \
	"$(INTDIR)\h235security.obj" \
	"$(INTDIR)\h261codec.obj" \
	"$(INTDIR)\h323.obj" \
	"$(INTDIR)\h323caps.obj" \
	"$(INTDIR)\h323ep.obj" \
	"$(INTDIR)\h323neg.obj" \
	"$(INTDIR)\h323pdu.obj" \
	"$(INTDIR)\h323rtp.obj" \
	"$(INTDIR)\h450pdu.obj" \
	"$(INTDIR)\ixjwin32.obj" \
	"$(INTDIR)\jitter.obj" \
	"$(INTDIR)\lid.obj" \
	"$(INTDIR)\lpc10codec.obj" \
	"$(INTDIR)\mediafmt.obj" \
	"$(INTDIR)\mscodecs.obj" \
	"$(INTDIR)\precompile.obj" \
	"$(INTDIR)\q931.obj" \
	"$(INTDIR)\rtp.obj" \
	"$(INTDIR)\transports.obj" \
	"$(INTDIR)\videoio.obj" \
	"$(INTDIR)\vpblid.obj" \
	"$(INTDIR)\x224.obj" \
	"$(INTDIR)\gccpdu.obj" \
	"$(INTDIR)\h225.obj" \
	"$(INTDIR)\h235.obj" \
	"$(INTDIR)\h245_1.obj" \
	"$(INTDIR)\h245_2.obj" \
	"$(INTDIR)\h4501.obj" \
	"$(INTDIR)\h45010.obj" \
	"$(INTDIR)\h45011.obj" \
	"$(INTDIR)\h4502.obj" \
	"$(INTDIR)\h4503.obj" \
	"$(INTDIR)\h4504.obj" \
	"$(INTDIR)\h4505.obj" \
	"$(INTDIR)\h4506.obj" \
	"$(INTDIR)\h4507.obj" \
	"$(INTDIR)\h4508.obj" \
	"$(INTDIR)\h4509.obj" \
	"$(INTDIR)\ldap.obj" \
	"$(INTDIR)\mcspdu.obj" \
	"$(INTDIR)\x880.obj" \
	"$(INTDIR)\add.obj" \
	"$(INTDIR)\code.obj" \
	"$(INTDIR)\decode.obj" \
	"$(INTDIR)\gsm_create.obj" \
	"$(INTDIR)\gsm_decode.obj" \
	"$(INTDIR)\gsm_destroy.obj" \
	"$(INTDIR)\gsm_encode.obj" \
	"$(INTDIR)\gsm_option.obj" \
	"$(INTDIR)\long_term.obj" \
	"$(INTDIR)\lpc.obj" \
	"$(INTDIR)\preprocess.obj" \
	"$(INTDIR)\rpe.obj" \
	"$(INTDIR)\short_term.obj" \
	"$(INTDIR)\table.obj" \
	"$(INTDIR)\bv.obj" \
	"$(INTDIR)\huffcode.obj" \
	"$(INTDIR)\dct.obj" \
	"$(INTDIR)\encoder-h261.obj" \
	"$(INTDIR)\p64.obj" \
	"$(INTDIR)\p64encoder.obj" \
	"$(INTDIR)\transmitter.obj" \
	"$(INTDIR)\vid_coder.obj" \
	"$(INTDIR)\analys.obj" \
	"$(INTDIR)\bsynz.obj" \
	"$(INTDIR)\chanwr.obj" \
	"$(INTDIR)\dcbias.obj" \
	"$(INTDIR)\decode_.obj" \
	"$(INTDIR)\deemp.obj" \
	"$(INTDIR)\difmag.obj" \
	"$(INTDIR)\dyptrk.obj" \
	"$(INTDIR)\encode_.obj" \
	"$(INTDIR)\energy.obj" \
	"$(INTDIR)\f2clib.obj" \
	"$(INTDIR)\ham84.obj" \
	"$(INTDIR)\hp100.obj" \
	"$(INTDIR)\invert.obj" \
	"$(INTDIR)\irc2pc.obj" \
	"$(INTDIR)\ivfilt.obj" \
	"$(INTDIR)\lpcdec.obj" \
	"$(INTDIR)\lpcenc.obj" \
	"$(INTDIR)\lpcini.obj" \
	"$(INTDIR)\lpfilt.obj" \
	"$(INTDIR)\median.obj" \
	"$(INTDIR)\mload.obj" \
	"$(INTDIR)\onset.obj" \
	"$(INTDIR)\pitsyn.obj" \
	"$(INTDIR)\placea.obj" \
	"$(INTDIR)\placev.obj" \
	"$(INTDIR)\preemp.obj" \
	"$(INTDIR)\prepro.obj" \
	"$(INTDIR)\random.obj" \
	"$(INTDIR)\rcchk.obj" \
	"$(INTDIR)\synths.obj" \
	"$(INTDIR)\tbdm.obj" \
	"$(INTDIR)\voicin.obj" \
	"$(INTDIR)\vparms.obj"

"$(OUTDIR)\OpenH323s.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

OUTDIR=.\lib
INTDIR=.\lib\Debug
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

ALL : ".\src\mcspdu.cxx" ".\src\ldap.cxx" ".\src\h4509.cxx" ".\src\h4508.cxx" ".\src\h4507.cxx" ".\src\h4506.cxx" ".\src\h4505.cxx" ".\src\h4504.cxx" ".\src\h4503.cxx" ".\src\h45011.cxx" ".\src\h45010.cxx" ".\src\gccpdu.cxx" ".\include\mcspdu.h" ".\include\ldap.h" ".\include\h4509.h" ".\include\h4508.h" ".\include\h4507.h" ".\include\h4506.h" ".\include\h4505.h" ".\include\h4504.h" ".\include\h4503.h" ".\include\h45011.h" ".\include\h45010.h" ".\include\gccpdu.h" "$(OUTDIR)\OpenH323sd.lib" "$(OUTDIR)\OpenH323Lib.bsc"


CLEAN :
	-@erase "$(INTDIR)\add.obj"
	-@erase "$(INTDIR)\add.sbr"
	-@erase "$(INTDIR)\analys.obj"
	-@erase "$(INTDIR)\analys.sbr"
	-@erase "$(INTDIR)\bsynz.obj"
	-@erase "$(INTDIR)\bsynz.sbr"
	-@erase "$(INTDIR)\bv.obj"
	-@erase "$(INTDIR)\bv.sbr"
	-@erase "$(INTDIR)\channels.obj"
	-@erase "$(INTDIR)\channels.sbr"
	-@erase "$(INTDIR)\chanwr.obj"
	-@erase "$(INTDIR)\chanwr.sbr"
	-@erase "$(INTDIR)\code.obj"
	-@erase "$(INTDIR)\code.sbr"
	-@erase "$(INTDIR)\codecs.obj"
	-@erase "$(INTDIR)\codecs.sbr"
	-@erase "$(INTDIR)\dcbias.obj"
	-@erase "$(INTDIR)\dcbias.sbr"
	-@erase "$(INTDIR)\dct.obj"
	-@erase "$(INTDIR)\dct.sbr"
	-@erase "$(INTDIR)\decode.obj"
	-@erase "$(INTDIR)\decode.sbr"
	-@erase "$(INTDIR)\decode_.obj"
	-@erase "$(INTDIR)\decode_.sbr"
	-@erase "$(INTDIR)\deemp.obj"
	-@erase "$(INTDIR)\deemp.sbr"
	-@erase "$(INTDIR)\difmag.obj"
	-@erase "$(INTDIR)\difmag.sbr"
	-@erase "$(INTDIR)\dyptrk.obj"
	-@erase "$(INTDIR)\dyptrk.sbr"
	-@erase "$(INTDIR)\encode_.obj"
	-@erase "$(INTDIR)\encode_.sbr"
	-@erase "$(INTDIR)\encoder-h261.obj"
	-@erase "$(INTDIR)\encoder-h261.sbr"
	-@erase "$(INTDIR)\energy.obj"
	-@erase "$(INTDIR)\energy.sbr"
	-@erase "$(INTDIR)\f2clib.obj"
	-@erase "$(INTDIR)\f2clib.sbr"
	-@erase "$(INTDIR)\g711.obj"
	-@erase "$(INTDIR)\g711.sbr"
	-@erase "$(INTDIR)\gccpdu.obj"
	-@erase "$(INTDIR)\gccpdu.sbr"
	-@erase "$(INTDIR)\gkclient.obj"
	-@erase "$(INTDIR)\gkclient.sbr"
	-@erase "$(INTDIR)\gsm_create.obj"
	-@erase "$(INTDIR)\gsm_create.sbr"
	-@erase "$(INTDIR)\gsm_decode.obj"
	-@erase "$(INTDIR)\gsm_decode.sbr"
	-@erase "$(INTDIR)\gsm_destroy.obj"
	-@erase "$(INTDIR)\gsm_destroy.sbr"
	-@erase "$(INTDIR)\gsm_encode.obj"
	-@erase "$(INTDIR)\gsm_encode.sbr"
	-@erase "$(INTDIR)\gsm_option.obj"
	-@erase "$(INTDIR)\gsm_option.sbr"
	-@erase "$(INTDIR)\gsmcodec.obj"
	-@erase "$(INTDIR)\gsmcodec.sbr"
	-@erase "$(INTDIR)\guid.obj"
	-@erase "$(INTDIR)\guid.sbr"
	-@erase "$(INTDIR)\h225.obj"
	-@erase "$(INTDIR)\h225.sbr"
	-@erase "$(INTDIR)\h235.obj"
	-@erase "$(INTDIR)\h235.sbr"
	-@erase "$(INTDIR)\h235ras.obj"
	-@erase "$(INTDIR)\h235ras.sbr"
	-@erase "$(INTDIR)\h235security.obj"
	-@erase "$(INTDIR)\h235security.sbr"
	-@erase "$(INTDIR)\h245_1.obj"
	-@erase "$(INTDIR)\h245_1.sbr"
	-@erase "$(INTDIR)\h245_2.obj"
	-@erase "$(INTDIR)\h245_2.sbr"
	-@erase "$(INTDIR)\h261codec.obj"
	-@erase "$(INTDIR)\h261codec.sbr"
	-@erase "$(INTDIR)\h323.obj"
	-@erase "$(INTDIR)\h323.sbr"
	-@erase "$(INTDIR)\h323caps.obj"
	-@erase "$(INTDIR)\h323caps.sbr"
	-@erase "$(INTDIR)\h323ep.obj"
	-@erase "$(INTDIR)\h323ep.sbr"
	-@erase "$(INTDIR)\h323neg.obj"
	-@erase "$(INTDIR)\h323neg.sbr"
	-@erase "$(INTDIR)\h323pdu.obj"
	-@erase "$(INTDIR)\h323pdu.sbr"
	-@erase "$(INTDIR)\h323rtp.obj"
	-@erase "$(INTDIR)\h323rtp.sbr"
	-@erase "$(INTDIR)\h4501.obj"
	-@erase "$(INTDIR)\h4501.sbr"
	-@erase "$(INTDIR)\h45010.obj"
	-@erase "$(INTDIR)\h45010.sbr"
	-@erase "$(INTDIR)\h45011.obj"
	-@erase "$(INTDIR)\h45011.sbr"
	-@erase "$(INTDIR)\h4502.obj"
	-@erase "$(INTDIR)\h4502.sbr"
	-@erase "$(INTDIR)\h4503.obj"
	-@erase "$(INTDIR)\h4503.sbr"
	-@erase "$(INTDIR)\h4504.obj"
	-@erase "$(INTDIR)\h4504.sbr"
	-@erase "$(INTDIR)\h4505.obj"
	-@erase "$(INTDIR)\h4505.sbr"
	-@erase "$(INTDIR)\h4506.obj"
	-@erase "$(INTDIR)\h4506.sbr"
	-@erase "$(INTDIR)\h4507.obj"
	-@erase "$(INTDIR)\h4507.sbr"
	-@erase "$(INTDIR)\h4508.obj"
	-@erase "$(INTDIR)\h4508.sbr"
	-@erase "$(INTDIR)\h4509.obj"
	-@erase "$(INTDIR)\h4509.sbr"
	-@erase "$(INTDIR)\h450pdu.obj"
	-@erase "$(INTDIR)\h450pdu.sbr"
	-@erase "$(INTDIR)\ham84.obj"
	-@erase "$(INTDIR)\ham84.sbr"
	-@erase "$(INTDIR)\hp100.obj"
	-@erase "$(INTDIR)\hp100.sbr"
	-@erase "$(INTDIR)\huffcode.obj"
	-@erase "$(INTDIR)\huffcode.sbr"
	-@erase "$(INTDIR)\invert.obj"
	-@erase "$(INTDIR)\invert.sbr"
	-@erase "$(INTDIR)\irc2pc.obj"
	-@erase "$(INTDIR)\irc2pc.sbr"
	-@erase "$(INTDIR)\ivfilt.obj"
	-@erase "$(INTDIR)\ivfilt.sbr"
	-@erase "$(INTDIR)\ixjwin32.obj"
	-@erase "$(INTDIR)\ixjwin32.sbr"
	-@erase "$(INTDIR)\jitter.obj"
	-@erase "$(INTDIR)\jitter.sbr"
	-@erase "$(INTDIR)\ldap.obj"
	-@erase "$(INTDIR)\ldap.sbr"
	-@erase "$(INTDIR)\lid.obj"
	-@erase "$(INTDIR)\lid.sbr"
	-@erase "$(INTDIR)\long_term.obj"
	-@erase "$(INTDIR)\long_term.sbr"
	-@erase "$(INTDIR)\lpc.obj"
	-@erase "$(INTDIR)\lpc.sbr"
	-@erase "$(INTDIR)\lpc10codec.obj"
	-@erase "$(INTDIR)\lpc10codec.sbr"
	-@erase "$(INTDIR)\lpcdec.obj"
	-@erase "$(INTDIR)\lpcdec.sbr"
	-@erase "$(INTDIR)\lpcenc.obj"
	-@erase "$(INTDIR)\lpcenc.sbr"
	-@erase "$(INTDIR)\lpcini.obj"
	-@erase "$(INTDIR)\lpcini.sbr"
	-@erase "$(INTDIR)\lpfilt.obj"
	-@erase "$(INTDIR)\lpfilt.sbr"
	-@erase "$(INTDIR)\mcspdu.obj"
	-@erase "$(INTDIR)\mcspdu.sbr"
	-@erase "$(INTDIR)\mediafmt.obj"
	-@erase "$(INTDIR)\mediafmt.sbr"
	-@erase "$(INTDIR)\median.obj"
	-@erase "$(INTDIR)\median.sbr"
	-@erase "$(INTDIR)\mload.obj"
	-@erase "$(INTDIR)\mload.sbr"
	-@erase "$(INTDIR)\mscodecs.obj"
	-@erase "$(INTDIR)\mscodecs.sbr"
	-@erase "$(INTDIR)\onset.obj"
	-@erase "$(INTDIR)\onset.sbr"
	-@erase "$(INTDIR)\OpenH323Lib.pch"
	-@erase "$(INTDIR)\p64.obj"
	-@erase "$(INTDIR)\p64.sbr"
	-@erase "$(INTDIR)\p64encoder.obj"
	-@erase "$(INTDIR)\p64encoder.sbr"
	-@erase "$(INTDIR)\pitsyn.obj"
	-@erase "$(INTDIR)\pitsyn.sbr"
	-@erase "$(INTDIR)\placea.obj"
	-@erase "$(INTDIR)\placea.sbr"
	-@erase "$(INTDIR)\placev.obj"
	-@erase "$(INTDIR)\placev.sbr"
	-@erase "$(INTDIR)\precompile.obj"
	-@erase "$(INTDIR)\precompile.sbr"
	-@erase "$(INTDIR)\preemp.obj"
	-@erase "$(INTDIR)\preemp.sbr"
	-@erase "$(INTDIR)\prepro.obj"
	-@erase "$(INTDIR)\prepro.sbr"
	-@erase "$(INTDIR)\preprocess.obj"
	-@erase "$(INTDIR)\preprocess.sbr"
	-@erase "$(INTDIR)\q931.obj"
	-@erase "$(INTDIR)\q931.sbr"
	-@erase "$(INTDIR)\random.obj"
	-@erase "$(INTDIR)\random.sbr"
	-@erase "$(INTDIR)\rcchk.obj"
	-@erase "$(INTDIR)\rcchk.sbr"
	-@erase "$(INTDIR)\rpe.obj"
	-@erase "$(INTDIR)\rpe.sbr"
	-@erase "$(INTDIR)\rtp.obj"
	-@erase "$(INTDIR)\rtp.sbr"
	-@erase "$(INTDIR)\short_term.obj"
	-@erase "$(INTDIR)\short_term.sbr"
	-@erase "$(INTDIR)\synths.obj"
	-@erase "$(INTDIR)\synths.sbr"
	-@erase "$(INTDIR)\table.obj"
	-@erase "$(INTDIR)\table.sbr"
	-@erase "$(INTDIR)\tbdm.obj"
	-@erase "$(INTDIR)\tbdm.sbr"
	-@erase "$(INTDIR)\transmitter.obj"
	-@erase "$(INTDIR)\transmitter.sbr"
	-@erase "$(INTDIR)\transports.obj"
	-@erase "$(INTDIR)\transports.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\vid_coder.obj"
	-@erase "$(INTDIR)\vid_coder.sbr"
	-@erase "$(INTDIR)\videoio.obj"
	-@erase "$(INTDIR)\videoio.sbr"
	-@erase "$(INTDIR)\voicin.obj"
	-@erase "$(INTDIR)\voicin.sbr"
	-@erase "$(INTDIR)\vparms.obj"
	-@erase "$(INTDIR)\vparms.sbr"
	-@erase "$(INTDIR)\vpblid.obj"
	-@erase "$(INTDIR)\vpblid.sbr"
	-@erase "$(INTDIR)\x224.obj"
	-@erase "$(INTDIR)\x224.sbr"
	-@erase "$(INTDIR)\x880.obj"
	-@erase "$(INTDIR)\x880.sbr"
	-@erase "$(OUTDIR)\OpenH323Lib.bsc"
	-@erase "$(OUTDIR)\OpenH323sd.lib"
	-@erase ".\include\gccpdu.h"
	-@erase ".\include\h45010.h"
	-@erase ".\include\h45011.h"
	-@erase ".\include\h4503.h"
	-@erase ".\include\h4504.h"
	-@erase ".\include\h4505.h"
	-@erase ".\include\h4506.h"
	-@erase ".\include\h4507.h"
	-@erase ".\include\h4508.h"
	-@erase ".\include\h4509.h"
	-@erase ".\include\ldap.h"
	-@erase ".\include\mcspdu.h"
	-@erase ".\src\gccpdu.cxx"
	-@erase ".\src\h45010.cxx"
	-@erase ".\src\h45011.cxx"
	-@erase ".\src\h4503.cxx"
	-@erase ".\src\h4504.cxx"
	-@erase ".\src\h4505.cxx"
	-@erase ".\src\h4506.cxx"
	-@erase ".\src\h4507.cxx"
	-@erase ".\src\h4508.cxx"
	-@erase ".\src\h4509.cxx"
	-@erase ".\src\ldap.cxx"
	-@erase ".\src\mcspdu.cxx"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323Lib.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\channels.sbr" \
	"$(INTDIR)\codecs.sbr" \
	"$(INTDIR)\g711.sbr" \
	"$(INTDIR)\gkclient.sbr" \
	"$(INTDIR)\gsmcodec.sbr" \
	"$(INTDIR)\guid.sbr" \
	"$(INTDIR)\h235ras.sbr" \
	"$(INTDIR)\h235security.sbr" \
	"$(INTDIR)\h261codec.sbr" \
	"$(INTDIR)\h323.sbr" \
	"$(INTDIR)\h323caps.sbr" \
	"$(INTDIR)\h323ep.sbr" \
	"$(INTDIR)\h323neg.sbr" \
	"$(INTDIR)\h323pdu.sbr" \
	"$(INTDIR)\h323rtp.sbr" \
	"$(INTDIR)\h450pdu.sbr" \
	"$(INTDIR)\ixjwin32.sbr" \
	"$(INTDIR)\jitter.sbr" \
	"$(INTDIR)\lid.sbr" \
	"$(INTDIR)\lpc10codec.sbr" \
	"$(INTDIR)\mediafmt.sbr" \
	"$(INTDIR)\mscodecs.sbr" \
	"$(INTDIR)\precompile.sbr" \
	"$(INTDIR)\q931.sbr" \
	"$(INTDIR)\rtp.sbr" \
	"$(INTDIR)\transports.sbr" \
	"$(INTDIR)\videoio.sbr" \
	"$(INTDIR)\vpblid.sbr" \
	"$(INTDIR)\x224.sbr" \
	"$(INTDIR)\gccpdu.sbr" \
	"$(INTDIR)\h225.sbr" \
	"$(INTDIR)\h235.sbr" \
	"$(INTDIR)\h245_1.sbr" \
	"$(INTDIR)\h245_2.sbr" \
	"$(INTDIR)\h4501.sbr" \
	"$(INTDIR)\h45010.sbr" \
	"$(INTDIR)\h45011.sbr" \
	"$(INTDIR)\h4502.sbr" \
	"$(INTDIR)\h4503.sbr" \
	"$(INTDIR)\h4504.sbr" \
	"$(INTDIR)\h4505.sbr" \
	"$(INTDIR)\h4506.sbr" \
	"$(INTDIR)\h4507.sbr" \
	"$(INTDIR)\h4508.sbr" \
	"$(INTDIR)\h4509.sbr" \
	"$(INTDIR)\ldap.sbr" \
	"$(INTDIR)\mcspdu.sbr" \
	"$(INTDIR)\x880.sbr" \
	"$(INTDIR)\add.sbr" \
	"$(INTDIR)\code.sbr" \
	"$(INTDIR)\decode.sbr" \
	"$(INTDIR)\gsm_create.sbr" \
	"$(INTDIR)\gsm_decode.sbr" \
	"$(INTDIR)\gsm_destroy.sbr" \
	"$(INTDIR)\gsm_encode.sbr" \
	"$(INTDIR)\gsm_option.sbr" \
	"$(INTDIR)\long_term.sbr" \
	"$(INTDIR)\lpc.sbr" \
	"$(INTDIR)\preprocess.sbr" \
	"$(INTDIR)\rpe.sbr" \
	"$(INTDIR)\short_term.sbr" \
	"$(INTDIR)\table.sbr" \
	"$(INTDIR)\bv.sbr" \
	"$(INTDIR)\huffcode.sbr" \
	"$(INTDIR)\dct.sbr" \
	"$(INTDIR)\encoder-h261.sbr" \
	"$(INTDIR)\p64.sbr" \
	"$(INTDIR)\p64encoder.sbr" \
	"$(INTDIR)\transmitter.sbr" \
	"$(INTDIR)\vid_coder.sbr" \
	"$(INTDIR)\analys.sbr" \
	"$(INTDIR)\bsynz.sbr" \
	"$(INTDIR)\chanwr.sbr" \
	"$(INTDIR)\dcbias.sbr" \
	"$(INTDIR)\decode_.sbr" \
	"$(INTDIR)\deemp.sbr" \
	"$(INTDIR)\difmag.sbr" \
	"$(INTDIR)\dyptrk.sbr" \
	"$(INTDIR)\encode_.sbr" \
	"$(INTDIR)\energy.sbr" \
	"$(INTDIR)\f2clib.sbr" \
	"$(INTDIR)\ham84.sbr" \
	"$(INTDIR)\hp100.sbr" \
	"$(INTDIR)\invert.sbr" \
	"$(INTDIR)\irc2pc.sbr" \
	"$(INTDIR)\ivfilt.sbr" \
	"$(INTDIR)\lpcdec.sbr" \
	"$(INTDIR)\lpcenc.sbr" \
	"$(INTDIR)\lpcini.sbr" \
	"$(INTDIR)\lpfilt.sbr" \
	"$(INTDIR)\median.sbr" \
	"$(INTDIR)\mload.sbr" \
	"$(INTDIR)\onset.sbr" \
	"$(INTDIR)\pitsyn.sbr" \
	"$(INTDIR)\placea.sbr" \
	"$(INTDIR)\placev.sbr" \
	"$(INTDIR)\preemp.sbr" \
	"$(INTDIR)\prepro.sbr" \
	"$(INTDIR)\random.sbr" \
	"$(INTDIR)\rcchk.sbr" \
	"$(INTDIR)\synths.sbr" \
	"$(INTDIR)\tbdm.sbr" \
	"$(INTDIR)\voicin.sbr" \
	"$(INTDIR)\vparms.sbr"

"$(OUTDIR)\OpenH323Lib.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\OpenH323sd.lib" 
LIB32_OBJS= \
	"$(INTDIR)\channels.obj" \
	"$(INTDIR)\codecs.obj" \
	"$(INTDIR)\g711.obj" \
	"$(INTDIR)\gkclient.obj" \
	"$(INTDIR)\gsmcodec.obj" \
	"$(INTDIR)\guid.obj" \
	"$(INTDIR)\h235ras.obj" \
	"$(INTDIR)\h235security.obj" \
	"$(INTDIR)\h261codec.obj" \
	"$(INTDIR)\h323.obj" \
	"$(INTDIR)\h323caps.obj" \
	"$(INTDIR)\h323ep.obj" \
	"$(INTDIR)\h323neg.obj" \
	"$(INTDIR)\h323pdu.obj" \
	"$(INTDIR)\h323rtp.obj" \
	"$(INTDIR)\h450pdu.obj" \
	"$(INTDIR)\ixjwin32.obj" \
	"$(INTDIR)\jitter.obj" \
	"$(INTDIR)\lid.obj" \
	"$(INTDIR)\lpc10codec.obj" \
	"$(INTDIR)\mediafmt.obj" \
	"$(INTDIR)\mscodecs.obj" \
	"$(INTDIR)\precompile.obj" \
	"$(INTDIR)\q931.obj" \
	"$(INTDIR)\rtp.obj" \
	"$(INTDIR)\transports.obj" \
	"$(INTDIR)\videoio.obj" \
	"$(INTDIR)\vpblid.obj" \
	"$(INTDIR)\x224.obj" \
	"$(INTDIR)\gccpdu.obj" \
	"$(INTDIR)\h225.obj" \
	"$(INTDIR)\h235.obj" \
	"$(INTDIR)\h245_1.obj" \
	"$(INTDIR)\h245_2.obj" \
	"$(INTDIR)\h4501.obj" \
	"$(INTDIR)\h45010.obj" \
	"$(INTDIR)\h45011.obj" \
	"$(INTDIR)\h4502.obj" \
	"$(INTDIR)\h4503.obj" \
	"$(INTDIR)\h4504.obj" \
	"$(INTDIR)\h4505.obj" \
	"$(INTDIR)\h4506.obj" \
	"$(INTDIR)\h4507.obj" \
	"$(INTDIR)\h4508.obj" \
	"$(INTDIR)\h4509.obj" \
	"$(INTDIR)\ldap.obj" \
	"$(INTDIR)\mcspdu.obj" \
	"$(INTDIR)\x880.obj" \
	"$(INTDIR)\add.obj" \
	"$(INTDIR)\code.obj" \
	"$(INTDIR)\decode.obj" \
	"$(INTDIR)\gsm_create.obj" \
	"$(INTDIR)\gsm_decode.obj" \
	"$(INTDIR)\gsm_destroy.obj" \
	"$(INTDIR)\gsm_encode.obj" \
	"$(INTDIR)\gsm_option.obj" \
	"$(INTDIR)\long_term.obj" \
	"$(INTDIR)\lpc.obj" \
	"$(INTDIR)\preprocess.obj" \
	"$(INTDIR)\rpe.obj" \
	"$(INTDIR)\short_term.obj" \
	"$(INTDIR)\table.obj" \
	"$(INTDIR)\bv.obj" \
	"$(INTDIR)\huffcode.obj" \
	"$(INTDIR)\dct.obj" \
	"$(INTDIR)\encoder-h261.obj" \
	"$(INTDIR)\p64.obj" \
	"$(INTDIR)\p64encoder.obj" \
	"$(INTDIR)\transmitter.obj" \
	"$(INTDIR)\vid_coder.obj" \
	"$(INTDIR)\analys.obj" \
	"$(INTDIR)\bsynz.obj" \
	"$(INTDIR)\chanwr.obj" \
	"$(INTDIR)\dcbias.obj" \
	"$(INTDIR)\decode_.obj" \
	"$(INTDIR)\deemp.obj" \
	"$(INTDIR)\difmag.obj" \
	"$(INTDIR)\dyptrk.obj" \
	"$(INTDIR)\encode_.obj" \
	"$(INTDIR)\energy.obj" \
	"$(INTDIR)\f2clib.obj" \
	"$(INTDIR)\ham84.obj" \
	"$(INTDIR)\hp100.obj" \
	"$(INTDIR)\invert.obj" \
	"$(INTDIR)\irc2pc.obj" \
	"$(INTDIR)\ivfilt.obj" \
	"$(INTDIR)\lpcdec.obj" \
	"$(INTDIR)\lpcenc.obj" \
	"$(INTDIR)\lpcini.obj" \
	"$(INTDIR)\lpfilt.obj" \
	"$(INTDIR)\median.obj" \
	"$(INTDIR)\mload.obj" \
	"$(INTDIR)\onset.obj" \
	"$(INTDIR)\pitsyn.obj" \
	"$(INTDIR)\placea.obj" \
	"$(INTDIR)\placev.obj" \
	"$(INTDIR)\preemp.obj" \
	"$(INTDIR)\prepro.obj" \
	"$(INTDIR)\random.obj" \
	"$(INTDIR)\rcchk.obj" \
	"$(INTDIR)\synths.obj" \
	"$(INTDIR)\tbdm.obj" \
	"$(INTDIR)\voicin.obj" \
	"$(INTDIR)\vparms.obj"

"$(OUTDIR)\OpenH323sd.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

OUTDIR=.\lib
INTDIR=.\lib\NoTrace
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

ALL : ".\src\mcspdu.cxx" ".\src\ldap.cxx" ".\src\h4509.cxx" ".\src\h4508.cxx" ".\src\h4507.cxx" ".\src\h4506.cxx" ".\src\h4505.cxx" ".\src\h4504.cxx" ".\src\h4503.cxx" ".\src\h45011.cxx" ".\src\h45010.cxx" ".\src\gccpdu.cxx" ".\include\mcspdu.h" ".\include\ldap.h" ".\include\h4509.h" ".\include\h4508.h" ".\include\h4507.h" ".\include\h4506.h" ".\include\h4505.h" ".\include\h4504.h" ".\include\h4503.h" ".\include\h45011.h" ".\include\h45010.h" ".\include\gccpdu.h" "$(OUTDIR)\OpenH323sn.lib"


CLEAN :
	-@erase "$(INTDIR)\add.obj"
	-@erase "$(INTDIR)\analys.obj"
	-@erase "$(INTDIR)\bsynz.obj"
	-@erase "$(INTDIR)\bv.obj"
	-@erase "$(INTDIR)\channels.obj"
	-@erase "$(INTDIR)\chanwr.obj"
	-@erase "$(INTDIR)\code.obj"
	-@erase "$(INTDIR)\codecs.obj"
	-@erase "$(INTDIR)\dcbias.obj"
	-@erase "$(INTDIR)\dct.obj"
	-@erase "$(INTDIR)\decode.obj"
	-@erase "$(INTDIR)\decode_.obj"
	-@erase "$(INTDIR)\deemp.obj"
	-@erase "$(INTDIR)\difmag.obj"
	-@erase "$(INTDIR)\dyptrk.obj"
	-@erase "$(INTDIR)\encode_.obj"
	-@erase "$(INTDIR)\encoder-h261.obj"
	-@erase "$(INTDIR)\energy.obj"
	-@erase "$(INTDIR)\f2clib.obj"
	-@erase "$(INTDIR)\g711.obj"
	-@erase "$(INTDIR)\gccpdu.obj"
	-@erase "$(INTDIR)\gkclient.obj"
	-@erase "$(INTDIR)\gsm_create.obj"
	-@erase "$(INTDIR)\gsm_decode.obj"
	-@erase "$(INTDIR)\gsm_destroy.obj"
	-@erase "$(INTDIR)\gsm_encode.obj"
	-@erase "$(INTDIR)\gsm_option.obj"
	-@erase "$(INTDIR)\gsmcodec.obj"
	-@erase "$(INTDIR)\guid.obj"
	-@erase "$(INTDIR)\h225.obj"
	-@erase "$(INTDIR)\h235.obj"
	-@erase "$(INTDIR)\h235ras.obj"
	-@erase "$(INTDIR)\h235security.obj"
	-@erase "$(INTDIR)\h245_1.obj"
	-@erase "$(INTDIR)\h245_2.obj"
	-@erase "$(INTDIR)\h261codec.obj"
	-@erase "$(INTDIR)\h323.obj"
	-@erase "$(INTDIR)\h323caps.obj"
	-@erase "$(INTDIR)\h323ep.obj"
	-@erase "$(INTDIR)\h323neg.obj"
	-@erase "$(INTDIR)\h323pdu.obj"
	-@erase "$(INTDIR)\h323rtp.obj"
	-@erase "$(INTDIR)\h4501.obj"
	-@erase "$(INTDIR)\h45010.obj"
	-@erase "$(INTDIR)\h45011.obj"
	-@erase "$(INTDIR)\h4502.obj"
	-@erase "$(INTDIR)\h4503.obj"
	-@erase "$(INTDIR)\h4504.obj"
	-@erase "$(INTDIR)\h4505.obj"
	-@erase "$(INTDIR)\h4506.obj"
	-@erase "$(INTDIR)\h4507.obj"
	-@erase "$(INTDIR)\h4508.obj"
	-@erase "$(INTDIR)\h4509.obj"
	-@erase "$(INTDIR)\h450pdu.obj"
	-@erase "$(INTDIR)\ham84.obj"
	-@erase "$(INTDIR)\hp100.obj"
	-@erase "$(INTDIR)\huffcode.obj"
	-@erase "$(INTDIR)\invert.obj"
	-@erase "$(INTDIR)\irc2pc.obj"
	-@erase "$(INTDIR)\ivfilt.obj"
	-@erase "$(INTDIR)\ixjwin32.obj"
	-@erase "$(INTDIR)\jitter.obj"
	-@erase "$(INTDIR)\ldap.obj"
	-@erase "$(INTDIR)\lid.obj"
	-@erase "$(INTDIR)\long_term.obj"
	-@erase "$(INTDIR)\lpc.obj"
	-@erase "$(INTDIR)\lpc10codec.obj"
	-@erase "$(INTDIR)\lpcdec.obj"
	-@erase "$(INTDIR)\lpcenc.obj"
	-@erase "$(INTDIR)\lpcini.obj"
	-@erase "$(INTDIR)\lpfilt.obj"
	-@erase "$(INTDIR)\mcspdu.obj"
	-@erase "$(INTDIR)\mediafmt.obj"
	-@erase "$(INTDIR)\median.obj"
	-@erase "$(INTDIR)\mload.obj"
	-@erase "$(INTDIR)\mscodecs.obj"
	-@erase "$(INTDIR)\onset.obj"
	-@erase "$(INTDIR)\OpenH323Lib.pch"
	-@erase "$(INTDIR)\p64.obj"
	-@erase "$(INTDIR)\p64encoder.obj"
	-@erase "$(INTDIR)\pitsyn.obj"
	-@erase "$(INTDIR)\placea.obj"
	-@erase "$(INTDIR)\placev.obj"
	-@erase "$(INTDIR)\precompile.obj"
	-@erase "$(INTDIR)\preemp.obj"
	-@erase "$(INTDIR)\prepro.obj"
	-@erase "$(INTDIR)\preprocess.obj"
	-@erase "$(INTDIR)\q931.obj"
	-@erase "$(INTDIR)\random.obj"
	-@erase "$(INTDIR)\rcchk.obj"
	-@erase "$(INTDIR)\rpe.obj"
	-@erase "$(INTDIR)\rtp.obj"
	-@erase "$(INTDIR)\short_term.obj"
	-@erase "$(INTDIR)\synths.obj"
	-@erase "$(INTDIR)\table.obj"
	-@erase "$(INTDIR)\tbdm.obj"
	-@erase "$(INTDIR)\transmitter.obj"
	-@erase "$(INTDIR)\transports.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vid_coder.obj"
	-@erase "$(INTDIR)\videoio.obj"
	-@erase "$(INTDIR)\voicin.obj"
	-@erase "$(INTDIR)\vparms.obj"
	-@erase "$(INTDIR)\vpblid.obj"
	-@erase "$(INTDIR)\x224.obj"
	-@erase "$(INTDIR)\x880.obj"
	-@erase "$(OUTDIR)\OpenH323sn.lib"
	-@erase ".\include\gccpdu.h"
	-@erase ".\include\h45010.h"
	-@erase ".\include\h45011.h"
	-@erase ".\include\h4503.h"
	-@erase ".\include\h4504.h"
	-@erase ".\include\h4505.h"
	-@erase ".\include\h4506.h"
	-@erase ".\include\h4507.h"
	-@erase ".\include\h4508.h"
	-@erase ".\include\h4509.h"
	-@erase ".\include\ldap.h"
	-@erase ".\include\mcspdu.h"
	-@erase ".\src\gccpdu.cxx"
	-@erase ".\src\h45010.cxx"
	-@erase ".\src\h45011.cxx"
	-@erase ".\src\h4503.cxx"
	-@erase ".\src\h4504.cxx"
	-@erase ".\src\h4505.cxx"
	-@erase ".\src\h4506.cxx"
	-@erase ".\src\h4507.cxx"
	-@erase ".\src\h4508.cxx"
	-@erase ".\src\h4509.cxx"
	-@erase ".\src\ldap.cxx"
	-@erase ".\src\mcspdu.cxx"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323Lib.bsc" 
BSC32_SBRS= \
	
LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"$(OUTDIR)\OpenH323sn.lib" 
LIB32_OBJS= \
	"$(INTDIR)\channels.obj" \
	"$(INTDIR)\codecs.obj" \
	"$(INTDIR)\g711.obj" \
	"$(INTDIR)\gkclient.obj" \
	"$(INTDIR)\gsmcodec.obj" \
	"$(INTDIR)\guid.obj" \
	"$(INTDIR)\h235ras.obj" \
	"$(INTDIR)\h235security.obj" \
	"$(INTDIR)\h261codec.obj" \
	"$(INTDIR)\h323.obj" \
	"$(INTDIR)\h323caps.obj" \
	"$(INTDIR)\h323ep.obj" \
	"$(INTDIR)\h323neg.obj" \
	"$(INTDIR)\h323pdu.obj" \
	"$(INTDIR)\h323rtp.obj" \
	"$(INTDIR)\h450pdu.obj" \
	"$(INTDIR)\ixjwin32.obj" \
	"$(INTDIR)\jitter.obj" \
	"$(INTDIR)\lid.obj" \
	"$(INTDIR)\lpc10codec.obj" \
	"$(INTDIR)\mediafmt.obj" \
	"$(INTDIR)\mscodecs.obj" \
	"$(INTDIR)\precompile.obj" \
	"$(INTDIR)\q931.obj" \
	"$(INTDIR)\rtp.obj" \
	"$(INTDIR)\transports.obj" \
	"$(INTDIR)\videoio.obj" \
	"$(INTDIR)\vpblid.obj" \
	"$(INTDIR)\x224.obj" \
	"$(INTDIR)\gccpdu.obj" \
	"$(INTDIR)\h225.obj" \
	"$(INTDIR)\h235.obj" \
	"$(INTDIR)\h245_1.obj" \
	"$(INTDIR)\h245_2.obj" \
	"$(INTDIR)\h4501.obj" \
	"$(INTDIR)\h45010.obj" \
	"$(INTDIR)\h45011.obj" \
	"$(INTDIR)\h4502.obj" \
	"$(INTDIR)\h4503.obj" \
	"$(INTDIR)\h4504.obj" \
	"$(INTDIR)\h4505.obj" \
	"$(INTDIR)\h4506.obj" \
	"$(INTDIR)\h4507.obj" \
	"$(INTDIR)\h4508.obj" \
	"$(INTDIR)\h4509.obj" \
	"$(INTDIR)\ldap.obj" \
	"$(INTDIR)\mcspdu.obj" \
	"$(INTDIR)\x880.obj" \
	"$(INTDIR)\add.obj" \
	"$(INTDIR)\code.obj" \
	"$(INTDIR)\decode.obj" \
	"$(INTDIR)\gsm_create.obj" \
	"$(INTDIR)\gsm_decode.obj" \
	"$(INTDIR)\gsm_destroy.obj" \
	"$(INTDIR)\gsm_encode.obj" \
	"$(INTDIR)\gsm_option.obj" \
	"$(INTDIR)\long_term.obj" \
	"$(INTDIR)\lpc.obj" \
	"$(INTDIR)\preprocess.obj" \
	"$(INTDIR)\rpe.obj" \
	"$(INTDIR)\short_term.obj" \
	"$(INTDIR)\table.obj" \
	"$(INTDIR)\bv.obj" \
	"$(INTDIR)\huffcode.obj" \
	"$(INTDIR)\dct.obj" \
	"$(INTDIR)\encoder-h261.obj" \
	"$(INTDIR)\p64.obj" \
	"$(INTDIR)\p64encoder.obj" \
	"$(INTDIR)\transmitter.obj" \
	"$(INTDIR)\vid_coder.obj" \
	"$(INTDIR)\analys.obj" \
	"$(INTDIR)\bsynz.obj" \
	"$(INTDIR)\chanwr.obj" \
	"$(INTDIR)\dcbias.obj" \
	"$(INTDIR)\decode_.obj" \
	"$(INTDIR)\deemp.obj" \
	"$(INTDIR)\difmag.obj" \
	"$(INTDIR)\dyptrk.obj" \
	"$(INTDIR)\encode_.obj" \
	"$(INTDIR)\energy.obj" \
	"$(INTDIR)\f2clib.obj" \
	"$(INTDIR)\ham84.obj" \
	"$(INTDIR)\hp100.obj" \
	"$(INTDIR)\invert.obj" \
	"$(INTDIR)\irc2pc.obj" \
	"$(INTDIR)\ivfilt.obj" \
	"$(INTDIR)\lpcdec.obj" \
	"$(INTDIR)\lpcenc.obj" \
	"$(INTDIR)\lpcini.obj" \
	"$(INTDIR)\lpfilt.obj" \
	"$(INTDIR)\median.obj" \
	"$(INTDIR)\mload.obj" \
	"$(INTDIR)\onset.obj" \
	"$(INTDIR)\pitsyn.obj" \
	"$(INTDIR)\placea.obj" \
	"$(INTDIR)\placev.obj" \
	"$(INTDIR)\preemp.obj" \
	"$(INTDIR)\prepro.obj" \
	"$(INTDIR)\random.obj" \
	"$(INTDIR)\rcchk.obj" \
	"$(INTDIR)\synths.obj" \
	"$(INTDIR)\tbdm.obj" \
	"$(INTDIR)\voicin.obj" \
	"$(INTDIR)\vparms.obj"

"$(OUTDIR)\OpenH323sn.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("OpenH323Lib.dep")
!INCLUDE "OpenH323Lib.dep"
!ELSE 
!MESSAGE Warning: cannot find "OpenH323Lib.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "OpenH323Lib - Win32 Release" || "$(CFG)" == "OpenH323Lib - Win32 Debug" || "$(CFG)" == "OpenH323Lib - Win32 No Trace" || "$(CFG)" == "OpenH323Lib - Win32 SSL Release" || "$(CFG)" == "OpenH323Lib - Win32 SSL Debug" || "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"
SOURCE=.\src\channels.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\channels.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\channels.obj"	"$(INTDIR)\channels.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\channels.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\channels.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\channels.obj"	"$(INTDIR)\channels.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\channels.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\codecs.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\codecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\codecs.obj"	"$(INTDIR)\codecs.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\codecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\codecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\codecs.obj"	"$(INTDIR)\codecs.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\codecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\g711.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\g711.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\g711.obj"	"$(INTDIR)\g711.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\g711.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\g711.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\g711.obj"	"$(INTDIR)\g711.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\g711.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gkclient.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\gkclient.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\gkclient.obj"	"$(INTDIR)\gkclient.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\gkclient.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\gkclient.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\gkclient.obj"	"$(INTDIR)\gkclient.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\gkclient.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\gsmcodec.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\gsmcodec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\gsmcodec.obj"	"$(INTDIR)\gsmcodec.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\gsmcodec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\gsmcodec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\gsmcodec.obj"	"$(INTDIR)\gsmcodec.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\gsmcodec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\guid.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\guid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\guid.obj"	"$(INTDIR)\guid.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\guid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\guid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\guid.obj"	"$(INTDIR)\guid.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\guid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h235ras.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h235ras.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h235ras.obj"	"$(INTDIR)\h235ras.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h235ras.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h235security.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h235security.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h235security.obj"	"$(INTDIR)\h235security.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h235security.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h235security.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h235security.obj"	"$(INTDIR)\h235security.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h235security.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h261codec.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h261codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h261codec.obj"	"$(INTDIR)\h261codec.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h261codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h261codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h261codec.obj"	"$(INTDIR)\h261codec.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h261codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h323.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h323.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h323.obj"	"$(INTDIR)\h323.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h323.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h323.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h323.obj"	"$(INTDIR)\h323.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h323.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h323caps.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h323caps.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h323caps.obj"	"$(INTDIR)\h323caps.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h323caps.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h323caps.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h323caps.obj"	"$(INTDIR)\h323caps.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h323caps.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h323ep.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h323ep.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h323ep.obj"	"$(INTDIR)\h323ep.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h323ep.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h323ep.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h323ep.obj"	"$(INTDIR)\h323ep.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h323ep.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h323neg.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h323neg.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h323neg.obj"	"$(INTDIR)\h323neg.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h323neg.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h323neg.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h323neg.obj"	"$(INTDIR)\h323neg.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h323neg.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h323pdu.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h323pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h323pdu.obj"	"$(INTDIR)\h323pdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h323pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h323pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h323pdu.obj"	"$(INTDIR)\h323pdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h323pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h323rtp.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h323rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h323rtp.obj"	"$(INTDIR)\h323rtp.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h323rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h323rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h323rtp.obj"	"$(INTDIR)\h323rtp.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h323rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h450pdu.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h450pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h450pdu.obj"	"$(INTDIR)\h450pdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h450pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h450pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h450pdu.obj"	"$(INTDIR)\h450pdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h450pdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\ixjwin32.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\ixjwin32.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\ixjwin32.obj"	"$(INTDIR)\ixjwin32.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\ixjwin32.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\ixjwin32.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\ixjwin32.obj"	"$(INTDIR)\ixjwin32.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\ixjwin32.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\jitter.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\jitter.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\jitter.obj"	"$(INTDIR)\jitter.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\jitter.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\jitter.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\jitter.obj"	"$(INTDIR)\jitter.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\jitter.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\lid.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\lid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\lid.obj"	"$(INTDIR)\lid.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\lid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\lid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\lid.obj"	"$(INTDIR)\lid.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\lid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\lpc10codec.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\lpc10codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\lpc10codec.obj"	"$(INTDIR)\lpc10codec.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\lpc10codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\lpc10codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\lpc10codec.obj"	"$(INTDIR)\lpc10codec.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\lpc10codec.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\mediafmt.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\mediafmt.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\mediafmt.obj"	"$(INTDIR)\mediafmt.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\mediafmt.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\mediafmt.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\mediafmt.obj"	"$(INTDIR)\mediafmt.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\mediafmt.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\mscodecs.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\mscodecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\mscodecs.obj"	"$(INTDIR)\mscodecs.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\mscodecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\mscodecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\mscodecs.obj"	"$(INTDIR)\mscodecs.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\mscodecs.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\precompile.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yc"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\precompile.obj"	"$(INTDIR)\OpenH323Lib.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yc"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\precompile.obj"	"$(INTDIR)\precompile.sbr"	"$(INTDIR)\OpenH323Lib.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yc"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\precompile.obj"	"$(INTDIR)\OpenH323Lib.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yc"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\precompile.obj"	"$(INTDIR)\OpenH323Lib.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yc"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\precompile.obj"	"$(INTDIR)\precompile.sbr"	"$(INTDIR)\OpenH323Lib.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fp"$(INTDIR)\OpenH323Lib.pch" /Yc"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\precompile.obj"	"$(INTDIR)\OpenH323Lib.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\q931.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\q931.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h225.h" "./src/h235.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\q931.obj"	"$(INTDIR)\q931.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h225.h" "./src/h235.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\q931.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h225.h" "./src/h235.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\q931.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h225.h" "./src/h235.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\q931.obj"	"$(INTDIR)\q931.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h225.h" "./src/h235.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\q931.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h225.h" "./src/h235.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\rtp.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\rtp.obj"	"$(INTDIR)\rtp.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\rtp.obj"	"$(INTDIR)\rtp.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\rtp.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\transports.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\transports.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\transports.obj"	"$(INTDIR)\transports.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\transports.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\transports.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\transports.obj"	"$(INTDIR)\transports.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h4502.h" "./src/h225.h" "./src/h235.h" "./src/h245.h" "./src/h4501.h" "./src/x880.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\transports.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch" "./src/h245.h" "./src/h4501.h" "./src/h225.h" "./src/h235.h" "./src/x880.h" "./src/h4502.h"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\videoio.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\videoio.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\videoio.obj"	"$(INTDIR)\videoio.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\videoio.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\videoio.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\videoio.obj"	"$(INTDIR)\videoio.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\videoio.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\vpblid.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\vpblid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\vpblid.obj"	"$(INTDIR)\vpblid.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\vpblid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\vpblid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\vpblid.obj"	"$(INTDIR)\vpblid.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\vpblid.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\x224.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\x224.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\x224.obj"	"$(INTDIR)\x224.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\x224.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\x224.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\x224.obj"	"$(INTDIR)\x224.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\x224.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\gccpdu.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\gccpdu.asn
InputName=gccpdu

".\src\gccpdu.cxx"	".\src\gccpdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m GCC -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\gccpdu.asn
InputName=gccpdu

".\src\gccpdu.cxx"	".\src\gccpdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m GCC -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\gccpdu.asn
InputName=gccpdu

".\src\gccpdu.cxx"	".\src\gccpdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m GCC -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\gccpdu.asn
InputName=gccpdu

".\src\gccpdu.cxx"	".\src\gccpdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m GCC -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\gccpdu.asn
InputName=gccpdu

".\src\gccpdu.cxx"	".\src\gccpdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m GCC -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\gccpdu.asn
InputName=gccpdu

".\src\gccpdu.cxx"	".\src\gccpdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m GCC -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\gccpdu.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\gccpdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\gccpdu.obj"	"$(INTDIR)\gccpdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\gccpdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\gccpdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\gccpdu.obj"	"$(INTDIR)\gccpdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\gccpdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h225.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h225.asn
InputName=h225

".\src\h225.cxx"	"./src/h225.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H225 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h225.asn
InputName=h225
USERDEP__H225_=".\include\h235.h"	

".\src\h225.cxx"	"./src/h225.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__H225_)
	<<tempfile.bat 
	@echo off 
	asnparser -m H225 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h225.asn
InputName=h225

".\src\h225.cxx"	"./src/h225.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H225 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h225.asn
InputName=h225

".\src\h225.cxx"	"./src/h225.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H225 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h225.asn
InputName=h225
USERDEP__H225_=".\include\h235.h"	

".\src\h225.cxx"	"./src/h225.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__H225_)
	<<tempfile.bat 
	@echo off 
	asnparser -m H225 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h225.asn
InputName=h225

".\src\h225.cxx"	"./src/h225.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H225 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h225.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h225.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h225.obj"	"$(INTDIR)\h225.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h225.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h225.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h225.obj"	"$(INTDIR)\h225.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h225.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h235.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h235.asn
InputName=h235

".\src\h235.cxx"	"./src/h235.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H235 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h235.asn
InputName=h235

".\src\h235.cxx"	"./src/h235.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H235 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h235.asn
InputName=h235

".\src\h235.cxx"	"./src/h235.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H235 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h235.asn
InputName=h235

".\src\h235.cxx"	"./src/h235.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H235 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h235.asn
InputName=h235

".\src\h235.cxx"	"./src/h235.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H235 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h235.asn
InputName=h235

".\src\h235.cxx"	"./src/h235.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H235 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h235.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h235.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h235.obj"	"$(INTDIR)\h235.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h235.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h235.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h235.obj"	"$(INTDIR)\h235.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h235.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h245.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h245.asn
InputName=h245

".\src\h245_1.cxx"	".\src\h245_2.cxx"	"./src/h245.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -s2 -m H245 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h245.asn
InputName=h245

".\src\h245_1.cxx"	".\src\h245_2.cxx"	"./src/h245.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -s2 -m H245 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h245.asn
InputName=h245

".\src\h245_1.cxx"	".\src\h245_2.cxx"	"./src/h245.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -s2 -m H245 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h245.asn
InputName=h245

".\src\h245_1.cxx"	".\src\h245_2.cxx"	"./src/h245.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -s2 -m H245 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h245.asn
InputName=h245

".\src\h245_1.cxx"	".\src\h245_2.cxx"	"./src/h245.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -s2 -m H245 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h245.asn
InputName=h245

".\src\h245_1.cxx"	".\src\h245_2.cxx"	"./src/h245.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -s2 -m H245 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h245_1.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h245_1.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h245_1.obj"	"$(INTDIR)\h245_1.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h245_1.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h245_1.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h245_1.obj"	"$(INTDIR)\h245_1.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h245_1.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h245_2.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h245_2.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h245_2.obj"	"$(INTDIR)\h245_2.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h245_2.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h245_2.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h245_2.obj"	"$(INTDIR)\h245_2.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h245_2.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4501.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4501.asn
InputName=h4501

".\src\h4501.cxx"	"./src/h4501.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4501 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4501.asn
InputName=h4501

".\src\h4501.cxx"	"./src/h4501.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4501 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4501.asn
InputName=h4501

".\src\h4501.cxx"	"./src/h4501.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4501 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4501.asn
InputName=h4501

".\src\h4501.cxx"	"./src/h4501.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4501 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4501.asn
InputName=h4501

".\src\h4501.cxx"	"./src/h4501.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4501 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4501.asn
InputName=h4501

".\src\h4501.cxx"	"./src/h4501.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4501 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4501.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4501.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4501.obj"	"$(INTDIR)\h4501.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4501.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4501.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4501.obj"	"$(INTDIR)\h4501.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4501.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h45010.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h45010.asn
InputName=h45010

".\src\h45010.cxx"	".\src\h45010.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45010 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h45010.asn
InputName=h45010

".\src\h45010.cxx"	".\src\h45010.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45010 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h45010.asn
InputName=h45010

".\src\h45010.cxx"	".\src\h45010.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45010 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h45010.asn
InputName=h45010

".\src\h45010.cxx"	".\src\h45010.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45010 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h45010.asn
InputName=h45010

".\src\h45010.cxx"	".\src\h45010.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45010 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h45010.asn
InputName=h45010

".\src\h45010.cxx"	".\src\h45010.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45010 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h45010.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h45010.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h45010.obj"	"$(INTDIR)\h45010.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h45010.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h45010.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h45010.obj"	"$(INTDIR)\h45010.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h45010.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h45011.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h45011.asn
InputName=h45011

".\src\h45011.cxx"	".\src\h45011.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45011 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h45011.asn
InputName=h45011

".\src\h45011.cxx"	".\src\h45011.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45011 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h45011.asn
InputName=h45011

".\src\h45011.cxx"	".\src\h45011.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45011 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h45011.asn
InputName=h45011

".\src\h45011.cxx"	".\src\h45011.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45011 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h45011.asn
InputName=h45011

".\src\h45011.cxx"	".\src\h45011.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45011 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h45011.asn
InputName=h45011

".\src\h45011.cxx"	".\src\h45011.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H45011 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h45011.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h45011.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h45011.obj"	"$(INTDIR)\h45011.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h45011.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h45011.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h45011.obj"	"$(INTDIR)\h45011.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h45011.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4502.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4502.asn
InputName=h4502

".\src\h4502.cxx"	"./src/h4502.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4502 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4502.asn
InputName=h4502

".\src\h4502.cxx"	"./src/h4502.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4502 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4502.asn
InputName=h4502

".\src\h4502.cxx"	"./src/h4502.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4502 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4502.asn
InputName=h4502

".\src\h4502.cxx"	"./src/h4502.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4502 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4502.asn
InputName=h4502

".\src\h4502.cxx"	"./src/h4502.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4502 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4502.asn
InputName=h4502

".\src\h4502.cxx"	"./src/h4502.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4502 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4502.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4502.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4502.obj"	"$(INTDIR)\h4502.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4502.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4502.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4502.obj"	"$(INTDIR)\h4502.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4502.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4503.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4503.asn
InputName=h4503

".\src\h4503.cxx"	".\src\h4503.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4503 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4503.asn
InputName=h4503

".\src\h4503.cxx"	".\src\h4503.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4503 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4503.asn
InputName=h4503

".\src\h4503.cxx"	".\src\h4503.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4503 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4503.asn
InputName=h4503

".\src\h4503.cxx"	".\src\h4503.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4503 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4503.asn
InputName=h4503

".\src\h4503.cxx"	".\src\h4503.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4503 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4503.asn
InputName=h4503

".\src\h4503.cxx"	".\src\h4503.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4503 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4503.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4503.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4503.obj"	"$(INTDIR)\h4503.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4503.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4503.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4503.obj"	"$(INTDIR)\h4503.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4503.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4504.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4504.asn
InputName=h4504

".\src\h4504.cxx"	".\src\h4504.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4504 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4504.asn
InputName=h4504

".\src\h4504.cxx"	".\src\h4504.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4504 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4504.asn
InputName=h4504

".\src\h4504.cxx"	".\src\h4504.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4504 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4504.asn
InputName=h4504

".\src\h4504.cxx"	".\src\h4504.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4504 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4504.asn
InputName=h4504

".\src\h4504.cxx"	".\src\h4504.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4504 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4504.asn
InputName=h4504

".\src\h4504.cxx"	".\src\h4504.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4504 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4504.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4504.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4504.obj"	"$(INTDIR)\h4504.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4504.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4504.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4504.obj"	"$(INTDIR)\h4504.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4504.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4505.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4505.asn
InputName=h4505

".\src\h4505.cxx"	".\src\h4505.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4505 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4505.asn
InputName=h4505

".\src\h4505.cxx"	".\src\h4505.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4505 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4505.asn
InputName=h4505

".\src\h4505.cxx"	".\src\h4505.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4505 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4505.asn
InputName=h4505

".\src\h4505.cxx"	".\src\h4505.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4505 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4505.asn
InputName=h4505

".\src\h4505.cxx"	".\src\h4505.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4505 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4505.asn
InputName=h4505

".\src\h4505.cxx"	".\src\h4505.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4505 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4505.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4505.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4505.obj"	"$(INTDIR)\h4505.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4505.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4505.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4505.obj"	"$(INTDIR)\h4505.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4505.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4506.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4506.asn
InputName=h4506

".\src\h4506.cxx"	".\src\h4506.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4506 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4506.asn
InputName=h4506

".\src\h4506.cxx"	".\src\h4506.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4506 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4506.asn
InputName=h4506

".\src\h4506.cxx"	".\src\h4506.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4506 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4506.asn
InputName=h4506

".\src\h4506.cxx"	".\src\h4506.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4506 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4506.asn
InputName=h4506

".\src\h4506.cxx"	".\src\h4506.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4506 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4506.asn
InputName=h4506

".\src\h4506.cxx"	".\src\h4506.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4506 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4506.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4506.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4506.obj"	"$(INTDIR)\h4506.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4506.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4506.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4506.obj"	"$(INTDIR)\h4506.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4506.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4507.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4507.asn
InputName=h4507

".\src\h4507.cxx"	".\src\h4507.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4507 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4507.asn
InputName=h4507

".\src\h4507.cxx"	".\src\h4507.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4507 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4507.asn
InputName=h4507

".\src\h4507.cxx"	".\src\h4507.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4507 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4507.asn
InputName=h4507

".\src\h4507.cxx"	".\src\h4507.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4507 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4507.asn
InputName=h4507

".\src\h4507.cxx"	".\src\h4507.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4507 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4507.asn
InputName=h4507

".\src\h4507.cxx"	".\src\h4507.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4507 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4507.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4507.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4507.obj"	"$(INTDIR)\h4507.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4507.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4507.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4507.obj"	"$(INTDIR)\h4507.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4507.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4508.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4508.asn
InputName=h4508

".\src\h4508.cxx"	".\src\h4508.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4508 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4508.asn
InputName=h4508

".\src\h4508.cxx"	".\src\h4508.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4508 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4508.asn
InputName=h4508

".\src\h4508.cxx"	".\src\h4508.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4508 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4508.asn
InputName=h4508

".\src\h4508.cxx"	".\src\h4508.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4508 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4508.asn
InputName=h4508

".\src\h4508.cxx"	".\src\h4508.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4508 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4508.asn
InputName=h4508

".\src\h4508.cxx"	".\src\h4508.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4508 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4508.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4508.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4508.obj"	"$(INTDIR)\h4508.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4508.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4508.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4508.obj"	"$(INTDIR)\h4508.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4508.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\h4509.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\h4509.asn
InputName=h4509

".\src\h4509.cxx"	".\src\h4509.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4509 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\h4509.asn
InputName=h4509

".\src\h4509.cxx"	".\src\h4509.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4509 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\h4509.asn
InputName=h4509

".\src\h4509.cxx"	".\src\h4509.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4509 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\h4509.asn
InputName=h4509

".\src\h4509.cxx"	".\src\h4509.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4509 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\h4509.asn
InputName=h4509

".\src\h4509.cxx"	".\src\h4509.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4509 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\h4509.asn
InputName=h4509

".\src\h4509.cxx"	".\src\h4509.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m H4509 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\h4509.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\h4509.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\h4509.obj"	"$(INTDIR)\h4509.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\h4509.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\h4509.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\h4509.obj"	"$(INTDIR)\h4509.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\h4509.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\ldap.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\ldap.asn
InputName=ldap

".\src\ldap.cxx"	".\include\ldap.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m LDAP -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\ldap.asn
InputName=ldap

".\src\ldap.cxx"	".\src\ldap.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m LDAP -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\ldap.asn
InputName=ldap

".\src\ldap.cxx"	".\src\ldap.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m LDAP -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\ldap.asn
InputName=ldap

".\src\ldap.cxx"	".\src\ldap.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m LDAP -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\ldap.asn
InputName=ldap

".\src\ldap.cxx"	".\src\ldap.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m LDAP -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\ldap.asn
InputName=ldap

".\src\ldap.cxx"	".\src\ldap.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m LDAP -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\ldap.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\ldap.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\ldap.obj"	"$(INTDIR)\ldap.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\ldap.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\ldap.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\ldap.obj"	"$(INTDIR)\ldap.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\ldap.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\mcspdu.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\mcspdu.asn
InputName=mcspdu

".\src\mcspdu.cxx"	".\src\mcspdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m MCS -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\mcspdu.asn
InputName=mcspdu

".\src\mcspdu.cxx"	".\src\mcspdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m MCS -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\mcspdu.asn
InputName=mcspdu

".\src\mcspdu.cxx"	".\src\mcspdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m MCS -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\mcspdu.asn
InputName=mcspdu

".\src\mcspdu.cxx"	".\src\mcspdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m MCS -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\mcspdu.asn
InputName=mcspdu

".\src\mcspdu.cxx"	".\src\mcspdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m MCS -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\mcspdu.asn
InputName=mcspdu

".\src\mcspdu.cxx"	".\src\mcspdu.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m MCS -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\mcspdu.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\mcspdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\mcspdu.obj"	"$(INTDIR)\mcspdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\mcspdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\mcspdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\mcspdu.obj"	"$(INTDIR)\mcspdu.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\mcspdu.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\x880.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

InputPath=.\src\x880.asn
InputName=x880

".\src\x880.cxx"	"./src/x880.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m X880 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

InputPath=.\src\x880.asn
InputName=x880

".\src\x880.cxx"	"./src/x880.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m X880 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

InputPath=.\src\x880.asn
InputName=x880

".\src\x880.cxx"	"./src/x880.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m X880 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

InputPath=.\src\x880.asn
InputName=x880

".\src\x880.cxx"	"./src/x880.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m X880 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

InputPath=.\src\x880.asn
InputName=x880

".\src\x880.cxx"	"./src/x880.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m X880 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

InputPath=.\src\x880.asn
InputName=x880

".\src\x880.cxx"	"./src/x880.h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	asnparser -m X880 -c $(InputPath) 
	copy .\src\$(InputName).h .\include\$(InputName).h
<< 
	

!ENDIF 

SOURCE=.\src\x880.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"


"$(INTDIR)\x880.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"


"$(INTDIR)\x880.obj"	"$(INTDIR)\x880.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"


"$(INTDIR)\x880.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"


"$(INTDIR)\x880.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"


"$(INTDIR)\x880.obj"	"$(INTDIR)\x880.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"


"$(INTDIR)\x880.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\OpenH323Lib.pch"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\gsm\src\add.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\add.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\add.obj"	"$(INTDIR)\add.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\add.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\add.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\add.obj"	"$(INTDIR)\add.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\add.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\code.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\code.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\code.obj"	"$(INTDIR)\code.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\code.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\code.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\code.obj"	"$(INTDIR)\code.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\code.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\decode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode.obj"	"$(INTDIR)\decode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode.obj"	"$(INTDIR)\decode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\gsm_create.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_create.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_create.obj"	"$(INTDIR)\gsm_create.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_create.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_create.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_create.obj"	"$(INTDIR)\gsm_create.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_create.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\gsm_decode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_decode.obj"	"$(INTDIR)\gsm_decode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_decode.obj"	"$(INTDIR)\gsm_decode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_decode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\gsm_destroy.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_destroy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_destroy.obj"	"$(INTDIR)\gsm_destroy.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_destroy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_destroy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_destroy.obj"	"$(INTDIR)\gsm_destroy.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_destroy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\gsm_encode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_encode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_encode.obj"	"$(INTDIR)\gsm_encode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_encode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_encode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_encode.obj"	"$(INTDIR)\gsm_encode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_encode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\gsm_option.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_option.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_option.obj"	"$(INTDIR)\gsm_option.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_option.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_option.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_option.obj"	"$(INTDIR)\gsm_option.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\gsm_option.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\long_term.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\long_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\long_term.obj"	"$(INTDIR)\long_term.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\long_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\long_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\long_term.obj"	"$(INTDIR)\long_term.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\long_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\lpc.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpc.obj"	"$(INTDIR)\lpc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpc.obj"	"$(INTDIR)\lpc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\preprocess.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preprocess.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preprocess.obj"	"$(INTDIR)\preprocess.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preprocess.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preprocess.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preprocess.obj"	"$(INTDIR)\preprocess.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preprocess.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\rpe.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rpe.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rpe.obj"	"$(INTDIR)\rpe.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rpe.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rpe.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rpe.obj"	"$(INTDIR)\rpe.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rpe.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\short_term.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\short_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\short_term.obj"	"$(INTDIR)\short_term.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\short_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\short_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\short_term.obj"	"$(INTDIR)\short_term.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\short_term.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\gsm\src\table.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\table.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\table.obj"	"$(INTDIR)\table.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\table.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\table.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /I "src\gsm\inc" /D "_DEBUG" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\table.obj"	"$(INTDIR)\table.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Ob2 /I "src\gsm\inc" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D NeedFunctionPrototypes=1 /D "WAV49" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\table.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\bv.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bv.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /D "_DEBUG" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bv.obj"	"$(INTDIR)\bv.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bv.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bv.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /D "_DEBUG" /D "P_SSL" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bv.obj"	"$(INTDIR)\bv.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bv.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\huffcode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\huffcode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /D "_DEBUG" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\huffcode.obj"	"$(INTDIR)\huffcode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\huffcode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\huffcode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /w /W0 /Gm /GX /ZI /Od /D "_DEBUG" /D "P_SSL" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\huffcode.obj"	"$(INTDIR)\huffcode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /w /W0 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\huffcode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\dct.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dct.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dct.obj"	"$(INTDIR)\dct.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dct.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dct.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "P_SSL" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dct.obj"	"$(INTDIR)\dct.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dct.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=".\src\vic\encoder-h261.cxx"

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encoder-h261.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encoder-h261.obj"	"$(INTDIR)\encoder-h261.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encoder-h261.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encoder-h261.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encoder-h261.obj"	"$(INTDIR)\encoder-h261.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encoder-h261.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\p64.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64.obj"	"$(INTDIR)\p64.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "P_SSL" /D "WIN32" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64.obj"	"$(INTDIR)\p64.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /D "WIN32" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\p64encoder.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64encoder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64encoder.obj"	"$(INTDIR)\p64encoder.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64encoder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64encoder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64encoder.obj"	"$(INTDIR)\p64encoder.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\p64encoder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\transmitter.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\transmitter.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\transmitter.obj"	"$(INTDIR)\transmitter.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\transmitter.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\transmitter.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\transmitter.obj"	"$(INTDIR)\transmitter.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\transmitter.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\vic\vid_coder.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vid_coder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vid_coder.obj"	"$(INTDIR)\vid_coder.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vid_coder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vid_coder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vid_coder.obj"	"$(INTDIR)\vid_coder.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vid_coder.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\analys.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\analys.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\analys.obj"	"$(INTDIR)\analys.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\analys.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\analys.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\analys.obj"	"$(INTDIR)\analys.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\analys.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\bsynz.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bsynz.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bsynz.obj"	"$(INTDIR)\bsynz.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bsynz.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bsynz.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bsynz.obj"	"$(INTDIR)\bsynz.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\bsynz.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\chanwr.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\chanwr.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\chanwr.obj"	"$(INTDIR)\chanwr.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\chanwr.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\chanwr.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\chanwr.obj"	"$(INTDIR)\chanwr.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\chanwr.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\dcbias.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dcbias.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dcbias.obj"	"$(INTDIR)\dcbias.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dcbias.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dcbias.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dcbias.obj"	"$(INTDIR)\dcbias.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dcbias.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\decode_.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode_.obj"	"$(INTDIR)\decode_.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode_.obj"	"$(INTDIR)\decode_.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\decode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\deemp.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\deemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\deemp.obj"	"$(INTDIR)\deemp.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\deemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\deemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\deemp.obj"	"$(INTDIR)\deemp.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\deemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\difmag.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\difmag.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\difmag.obj"	"$(INTDIR)\difmag.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\difmag.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\difmag.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\difmag.obj"	"$(INTDIR)\difmag.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\difmag.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\dyptrk.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dyptrk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dyptrk.obj"	"$(INTDIR)\dyptrk.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dyptrk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dyptrk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dyptrk.obj"	"$(INTDIR)\dyptrk.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dyptrk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\encode_.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encode_.obj"	"$(INTDIR)\encode_.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encode_.obj"	"$(INTDIR)\encode_.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\encode_.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\energy.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\energy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\energy.obj"	"$(INTDIR)\energy.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\energy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\energy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\energy.obj"	"$(INTDIR)\energy.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\energy.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\f2clib.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\f2clib.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\f2clib.obj"	"$(INTDIR)\f2clib.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\f2clib.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\f2clib.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\f2clib.obj"	"$(INTDIR)\f2clib.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\f2clib.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\ham84.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ham84.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ham84.obj"	"$(INTDIR)\ham84.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ham84.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ham84.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ham84.obj"	"$(INTDIR)\ham84.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ham84.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\hp100.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\hp100.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\hp100.obj"	"$(INTDIR)\hp100.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\hp100.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\hp100.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\hp100.obj"	"$(INTDIR)\hp100.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\hp100.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\invert.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\invert.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\invert.obj"	"$(INTDIR)\invert.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\invert.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\invert.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\invert.obj"	"$(INTDIR)\invert.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\invert.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\irc2pc.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\irc2pc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\irc2pc.obj"	"$(INTDIR)\irc2pc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\irc2pc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\irc2pc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\irc2pc.obj"	"$(INTDIR)\irc2pc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\irc2pc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\ivfilt.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ivfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ivfilt.obj"	"$(INTDIR)\ivfilt.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ivfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ivfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ivfilt.obj"	"$(INTDIR)\ivfilt.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ivfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\lpcdec.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcdec.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcdec.obj"	"$(INTDIR)\lpcdec.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcdec.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcdec.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcdec.obj"	"$(INTDIR)\lpcdec.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcdec.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\lpcenc.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcenc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcenc.obj"	"$(INTDIR)\lpcenc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcenc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcenc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcenc.obj"	"$(INTDIR)\lpcenc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcenc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\lpcini.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcini.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcini.obj"	"$(INTDIR)\lpcini.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcini.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcini.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcini.obj"	"$(INTDIR)\lpcini.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpcini.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\lpfilt.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpfilt.obj"	"$(INTDIR)\lpfilt.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpfilt.obj"	"$(INTDIR)\lpfilt.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\lpfilt.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\median.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\median.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\median.obj"	"$(INTDIR)\median.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\median.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\median.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\median.obj"	"$(INTDIR)\median.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\median.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\mload.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\mload.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\mload.obj"	"$(INTDIR)\mload.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\mload.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\mload.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\mload.obj"	"$(INTDIR)\mload.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\mload.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\onset.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\onset.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\onset.obj"	"$(INTDIR)\onset.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\onset.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\onset.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\onset.obj"	"$(INTDIR)\onset.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\onset.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\pitsyn.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\pitsyn.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\pitsyn.obj"	"$(INTDIR)\pitsyn.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\pitsyn.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\pitsyn.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\pitsyn.obj"	"$(INTDIR)\pitsyn.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\pitsyn.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\placea.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placea.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placea.obj"	"$(INTDIR)\placea.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placea.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placea.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placea.obj"	"$(INTDIR)\placea.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placea.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\placev.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placev.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placev.obj"	"$(INTDIR)\placev.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placev.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placev.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placev.obj"	"$(INTDIR)\placev.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\placev.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\preemp.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preemp.obj"	"$(INTDIR)\preemp.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preemp.obj"	"$(INTDIR)\preemp.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\preemp.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\prepro.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\prepro.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\prepro.obj"	"$(INTDIR)\prepro.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\prepro.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\prepro.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\prepro.obj"	"$(INTDIR)\prepro.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\prepro.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\random.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\random.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\random.obj"	"$(INTDIR)\random.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\random.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\random.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\random.obj"	"$(INTDIR)\random.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\random.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\rcchk.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rcchk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rcchk.obj"	"$(INTDIR)\rcchk.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rcchk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rcchk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rcchk.obj"	"$(INTDIR)\rcchk.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\rcchk.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\synths.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\synths.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\synths.obj"	"$(INTDIR)\synths.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\synths.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\synths.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\synths.obj"	"$(INTDIR)\synths.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\synths.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\tbdm.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\tbdm.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\tbdm.obj"	"$(INTDIR)\tbdm.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\tbdm.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\tbdm.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\tbdm.obj"	"$(INTDIR)\tbdm.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\tbdm.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\voicin.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\voicin.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\voicin.obj"	"$(INTDIR)\voicin.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\voicin.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\voicin.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\voicin.obj"	"$(INTDIR)\voicin.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\voicin.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\lpc10\src\vparms.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vparms.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vparms.obj"	"$(INTDIR)\vparms.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vparms.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W1 /GX /Zd /O2 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vparms.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W1 /Gm /GX /ZI /Od /I "src/lpc10" /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vparms.obj"	"$(INTDIR)\vparms.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W1 /GX /O1 /Ob2 /I "src/lpc10" /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\vparms.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 


!ENDIF 

