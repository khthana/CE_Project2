/*
 * h235security.h
 *
 * H.235 security information
 *
 * Open H323 Library
 *
 * Copyright (c) 1998-2001 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Contributor(s): F�rbass Franz <franz.fuerbass@infonova.at>
 *
 * $Log: h235security.h,v $
 * Revision 1.1  2001/03/21 04:52:40  robertj
 * Added H.235 security to gatekeepers, thanks F�rbass Franz!
 *
 */

#ifndef __H235SECURITY_H
#define __H235SECURITY_H


class H235SecurityInfo : public PObject
{
    PCLASSINFO(H235SecurityInfo, PObject);
  public:
    H235SecurityInfo();

    PString destination;    //the destination to call
    PString password;       //my password
    PString username;       //my username
    int     randomSequenceNumber;
};


#ifndef P_SSL
#ifdef _MSC_VER
#pragma message("Warning: H.235 security has been included without OpenSSL!")
#else
#warning "Warning: H.235 security has been included without OpenSSL!"
#endif
#endif


#endif //__H235SECURITY_H


/////////////////////////////////////////////////////////////////////////////
