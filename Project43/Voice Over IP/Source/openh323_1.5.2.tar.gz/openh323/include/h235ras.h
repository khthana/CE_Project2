/*
 * h235ras.h
 *
 * H.235 security over Gatekeeper RAS PDU's
 *
 * Open H323 Library
 *
 * Copyright (c) 1998-2001 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Contributor(s): F�rbass Franz <franz.fuerbass@infonova.at>
 *
 * $Log: h235ras.h,v $
 * Revision 1.4  2001/03/24 00:34:35  robertj
 * Added read/write hook functions so don't have to duplicate code in
 *    H323RasH235PDU descendant class of H323RasPDU.
 *
 * Revision 1.3  2001/03/21 05:49:18  robertj
 * GNU Compatibility
 *
 * Revision 1.2  2001/03/21 05:32:37  robertj
 * Fixed new H.235 code to be transparent if no security info present.
 *
 * Revision 1.1  2001/03/21 04:52:40  robertj
 * Added H.235 security to gatekeepers, thanks F�rbass Franz!
 *
 */

#ifndef __H235RAS_H
#define __H235RAS_H

#include "h323pdu.h"


class H225_CryptoH323Token;
class H225_ArrayOf_CryptoH323Token;

class H235SecurityInfo;


/** This wrapperclass provides a secured RasMessage*/
class H323RasH235PDU : public H323RasPDU
{
    PCLASSINFO(H323RasH235PDU, H323RasPDU);
   public:
    H323RasH235PDU(H235SecurityInfo * securityInfo);

    virtual H225_GatekeeperConfirm     & BuildGatekeeperConfirm(unsigned seqNum);
    virtual H225_GatekeeperReject      & BuildGatekeeperReject(unsigned seqNum, unsigned reason = H225_GatekeeperRejectReason::e_undefinedReason);
    virtual H225_RegistrationRequest   & BuildRegistrationRequest(unsigned seqNum);
    virtual H225_RegistrationConfirm   & BuildRegistrationConfirm(unsigned seqNum);
    virtual H225_RegistrationReject    & BuildRegistrationReject(unsigned seqNum, unsigned reason = H225_RegistrationRejectReason::e_undefinedReason);
    virtual H225_UnregistrationRequest & BuildUnregistrationRequest(unsigned seqNum);
    virtual H225_UnregistrationConfirm & BuildUnregistrationConfirm(unsigned seqNum);
    virtual H225_UnregistrationReject  & BuildUnregistrationReject(unsigned seqNum, unsigned reason = H225_UnregRejectReason::e_undefinedReason);
    virtual H225_LocationRequest       & BuildLocationRequest(unsigned seqNum);
    virtual H225_LocationConfirm       & BuildLocationConfirm(unsigned seqNum);
    virtual H225_LocationReject        & BuildLocationReject(unsigned seqNum, unsigned reason = H225_LocationRejectReason::e_undefinedReason);
    virtual H225_AdmissionRequest      & BuildAdmissionRequest(unsigned seqNum);
    virtual H225_AdmissionConfirm      & BuildAdmissionConfirm(unsigned seqNum);
    virtual H225_AdmissionReject       & BuildAdmissionReject(unsigned seqNum, unsigned reason = H225_AdmissionRejectReason::e_undefinedReason);
    virtual H225_DisengageRequest      & BuildDisengageRequest(unsigned seqNum);
    virtual H225_DisengageConfirm      & BuildDisengageConfirm(unsigned seqNum);
    virtual H225_DisengageReject       & BuildDisengageReject(unsigned seqNum, unsigned reason = H225_DisengageRejectReason::e_securityDenial);
    virtual H225_BandwidthRequest      & BuildBandwidthRequest(unsigned seqNum);
    virtual H225_BandwidthConfirm      & BuildBandwidthConfirm(unsigned seqNum, unsigned bandwidth = 0);
    virtual H225_BandwidthReject       & BuildBandwidthReject(unsigned seqNum, unsigned reason = H225_BandRejectReason::e_undefinedReason);
    virtual H225_InfoRequestResponse   & BuildInfoRequestResponse(unsigned seqNum);
    virtual H225_UnknownMessageResponse& BuildUnknownMessageResponse(unsigned seqNum);

    virtual BOOL OnReadPDU(PPER_Stream & strm);
    virtual BOOL OnWritePDU(PPER_Stream & strm) const;

  protected:
    H225_ArrayOf_CryptoH323Token * GetCryptoTokens();

    enum SecurityState
    {
        SECURE_OK = 0,      //parameters and Msg are ok, no security attacks
        SECURE_INVARG,      //parameters incorrect
        SECURE_ERROR,       //a Error occurs while computing
        SECURE_ATTACKED,    //security attack
        SECURE_DISABLED
    };

    SecurityState BeforeEncode(
      H225_ArrayOf_CryptoH323Token & cryptoTokens
    );
    SecurityState PrepareToken(
      H225_CryptoH323Token & cryptoToken
    );
    SecurityState VerifyPDU(
      BYTE   * asnMsg,
      PINDEX   asnlen,
      const H225_CryptoH323Token & crToken
    );

    H235SecurityInfo * securityInfo;
};


#ifdef P_SSL
#define H323_DECLARE_RAS_PDU(identifier, ep) H323RasH235PDU identifier(ep.GetSecurityInfo())
#else
#define H323_DECLARE_RAS_PDU(identifier, ep) H323RasPDU identifier
#endif


#endif //__H235RAS_H


/////////////////////////////////////////////////////////////////////////////
