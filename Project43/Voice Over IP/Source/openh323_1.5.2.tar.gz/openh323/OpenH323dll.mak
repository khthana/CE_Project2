# Microsoft Developer Studio Generated NMAKE File, Based on OpenH323dll.dsp
!IF "$(CFG)" == ""
CFG=OpenH323dll - Win32 SSL Debug
!MESSAGE No configuration specified. Defaulting to OpenH323dll - Win32 SSL Debug.
!ENDIF 

!IF "$(CFG)" != "OpenH323dll - Win32 Release" && "$(CFG)" != "OpenH323dll - Win32 Debug" && "$(CFG)" != "OpenH323dll - Win32 No Trace" && "$(CFG)" != "OpenH323dll - Win32 SSL Release" && "$(CFG)" != "OpenH323dll - Win32 SSL Debug" && "$(CFG)" != "OpenH323dll - Win32 SSL No Trace"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "OpenH323dll.mak" CFG="OpenH323dll - Win32 SSL Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "OpenH323dll - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "OpenH323dll - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "OpenH323dll - Win32 No Trace" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "OpenH323dll - Win32 SSL Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "OpenH323dll - Win32 SSL Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "OpenH323dll - Win32 SSL No Trace" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

OUTDIR=.\lib
INTDIR=.\lib\Release
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\OpenH323.dll" ".\lib\OpenH323.dbg"

!ELSE 

ALL : "Console Components - Win32 Release" "OpenH323Lib - Win32 Release" "$(OUTDIR)\OpenH323.dll" ".\lib\OpenH323.dbg"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"OpenH323Lib - Win32 ReleaseCLEAN" "Console Components - Win32 ReleaseCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\dllmain.obj"
	-@erase "$(INTDIR)\libver.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\OpenH323.dll"
	-@erase "$(OUTDIR)\OpenH323.exp"
	-@erase "$(OUTDIR)\OpenH323.lib"
	-@erase ".\lib\OpenH323.dbg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /Fp"$(INTDIR)\OpenH323dll.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0xc09 /fo"$(INTDIR)\libver.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323dll.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=ptclib.lib ptlib.lib src\vpbapi.lib Delayimp.lib winmm.lib msacm32.lib wsock32.lib kernel32.lib user32.lib advapi32.lib shell32.lib /nologo /subsystem:windows /dll /pdb:none /debug /debugtype:both /machine:I386 /def:".\lib\Release\OpenH323.def" /out:"$(OUTDIR)\OpenH323.dll" /implib:"$(OUTDIR)\OpenH323.lib" /libpath:"lib" /delayload:vpbapi.dll 
DEF_FILE= \
	"$(INTDIR)\OpenH323.def"
LINK32_OBJS= \
	"$(INTDIR)\dllmain.obj" \
	"$(INTDIR)\libver.res" \
	"$(OUTDIR)\OpenH323s.lib"

"$(OUTDIR)\OpenH323.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\lib
TargetName=OpenH323
InputPath=.\lib\OpenH323.dll
SOURCE="$(InputPath)"

"$(OUTDIR)\OpenH323.dbg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	rebase -b 0x30000000 -x . $(OutDir)\$(TargetName).dll
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

OUTDIR=.\lib
INTDIR=.\lib\Debug
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\OpenH323d.dll"

!ELSE 

ALL : "Console Components - Win32 Debug" "OpenH323Lib - Win32 Debug" "$(OUTDIR)\OpenH323d.dll"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"OpenH323Lib - Win32 DebugCLEAN" "Console Components - Win32 DebugCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\dllmain.obj"
	-@erase "$(INTDIR)\libver.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\OpenH323d.dll"
	-@erase "$(OUTDIR)\OpenH323d.exp"
	-@erase "$(OUTDIR)\OpenH323d.ilk"
	-@erase "$(OUTDIR)\OpenH323d.lib"
	-@erase "$(OUTDIR)\OpenH323d.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MDd /W4 /GX /Zi /Od /D "_DEBUG" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0xc09 /fo"$(INTDIR)\libver.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323dll.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=ptclibd.lib ptlibd.lib src\vpbapi.lib Delayimp.lib winmm.lib msacm32.lib wsock32.lib kernel32.lib user32.lib advapi32.lib shell32.lib /nologo /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\OpenH323d.pdb" /debug /machine:I386 /def:".\lib\Debug\OpenH323d.def" /out:"$(OUTDIR)\OpenH323d.dll" /implib:"$(OUTDIR)\OpenH323d.lib" /libpath:"lib" /delayload:vpbapi.dll 
DEF_FILE= \
	"$(INTDIR)\OpenH323d.def"
LINK32_OBJS= \
	"$(INTDIR)\dllmain.obj" \
	"$(INTDIR)\libver.res" \
	"$(OUTDIR)\OpenH323sd.lib"

"$(OUTDIR)\OpenH323d.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

OUTDIR=.\lib
INTDIR=.\lib\NoTrace
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\OpenH323n.dll" ".\lib\OpenH323n.dbg"

!ELSE 

ALL : "OpenH323Lib - Win32 No Trace" "$(OUTDIR)\OpenH323n.dll" ".\lib\OpenH323n.dbg"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"OpenH323Lib - Win32 No TraceCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\dllmain.obj"
	-@erase "$(INTDIR)\libver.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\OpenH323n.dll"
	-@erase "$(OUTDIR)\OpenH323n.exp"
	-@erase "$(OUTDIR)\OpenH323n.lib"
	-@erase ".\lib\OpenH323n.dbg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /Zi /O2 /Ob2 /D "NDEBUG" /Fp"$(INTDIR)\OpenH323dll.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0xc09 /fo"$(INTDIR)\libver.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323dll.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=ptclib.lib ptlib.lib src\vpbapi.lib Delayimp.lib winmm.lib msacm32.lib wsock32.lib kernel32.lib user32.lib advapi32.lib shell32.lib /nologo /subsystem:windows /dll /incremental:no /pdb:"$(OUTDIR)\OpenH323n.pdb" /machine:I386 /def:".\lib\NoTrace\OpenH323n.def" /out:"$(OUTDIR)\OpenH323n.dll" /implib:"$(OUTDIR)\OpenH323n.lib" /libpath:"lib" /delayload:vpbapi.dll 
DEF_FILE= \
	"$(INTDIR)\OpenH323n.def"
LINK32_OBJS= \
	"$(INTDIR)\dllmain.obj" \
	"$(INTDIR)\libver.res" \
	"$(OUTDIR)\OpenH323sn.lib"

"$(OUTDIR)\OpenH323n.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\lib
TargetName=OpenH323n
InputPath=.\lib\OpenH323n.dll
SOURCE="$(InputPath)"

"$(OUTDIR)\OpenH323n.dbg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	rebase -b 0x10000000 -x . $(OutDir)\$(TargetName).dll
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

OUTDIR=.\lib
INTDIR=.\lib\Release
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\OpenH323.dll" ".\lib\OpenH323.dbg"

!ELSE 

ALL : "Console Components - Win32 SSL Release" "OpenH323Lib - Win32 SSL Release" "$(OUTDIR)\OpenH323.dll" ".\lib\OpenH323.dbg"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"OpenH323Lib - Win32 SSL ReleaseCLEAN" "Console Components - Win32 SSL ReleaseCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\dllmain.obj"
	-@erase "$(INTDIR)\libver.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\OpenH323.dll"
	-@erase "$(OUTDIR)\OpenH323.exp"
	-@erase "$(OUTDIR)\OpenH323.lib"
	-@erase ".\lib\OpenH323.dbg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "P_SSL" /Fp"$(INTDIR)\OpenH323dll.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0xc09 /fo"$(INTDIR)\libver.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323dll.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=ptclib.lib ptlib.lib ssleay32.lib libeay32.lib src\vpbapi.lib Delayimp.lib winmm.lib msacm32.lib wsock32.lib kernel32.lib user32.lib advapi32.lib shell32.lib /nologo /subsystem:windows /dll /pdb:none /debug /debugtype:both /machine:I386 /def:".\lib\Release\OpenH323.def" /out:"$(OUTDIR)\OpenH323.dll" /implib:"$(OUTDIR)\OpenH323.lib" /libpath:"lib" /delayload:vpbapi.dll 
DEF_FILE= \
	"$(INTDIR)\OpenH323.def"
LINK32_OBJS= \
	"$(INTDIR)\dllmain.obj" \
	"$(INTDIR)\libver.res" \
	"$(OUTDIR)\OpenH323s.lib"

"$(OUTDIR)\OpenH323.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\lib
TargetName=OpenH323
InputPath=.\lib\OpenH323.dll
SOURCE="$(InputPath)"

"$(OUTDIR)\OpenH323.dbg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	rebase -b 0x30000000 -x . $(OutDir)\$(TargetName).dll
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

OUTDIR=.\lib
INTDIR=.\lib\Debug
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\OpenH323d.dll"

!ELSE 

ALL : "Console Components - Win32 SSL Debug" "OpenH323Lib - Win32 SSL Debug" "$(OUTDIR)\OpenH323d.dll"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"OpenH323Lib - Win32 SSL DebugCLEAN" "Console Components - Win32 SSL DebugCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\dllmain.obj"
	-@erase "$(INTDIR)\libver.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\OpenH323d.dll"
	-@erase "$(OUTDIR)\OpenH323d.exp"
	-@erase "$(OUTDIR)\OpenH323d.ilk"
	-@erase "$(OUTDIR)\OpenH323d.lib"
	-@erase "$(OUTDIR)\OpenH323d.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MDd /W4 /GX /Zi /Od /D "_DEBUG" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0xc09 /fo"$(INTDIR)\libver.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323dll.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=ptclibd.lib ptlibd.lib ssleay32d.lib libeay32d.lib gdi32.lib src\vpbapi.lib Delayimp.lib winmm.lib msacm32.lib wsock32.lib kernel32.lib user32.lib advapi32.lib shell32.lib /nologo /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\OpenH323d.pdb" /debug /machine:I386 /def:".\lib\Debug\OpenH323d.def" /out:"$(OUTDIR)\OpenH323d.dll" /implib:"$(OUTDIR)\OpenH323d.lib" /libpath:"lib" /delayload:vpbapi.dll 
DEF_FILE= \
	"$(INTDIR)\OpenH323d.def"
LINK32_OBJS= \
	"$(INTDIR)\dllmain.obj" \
	"$(INTDIR)\libver.res" \
	"$(OUTDIR)\OpenH323sd.lib"

"$(OUTDIR)\OpenH323d.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

OUTDIR=.\lib
INTDIR=.\lib\NoTrace
# Begin Custom Macros
OutDir=.\lib
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\OpenH323n.dll" ".\lib\OpenH323n.dbg"

!ELSE 

ALL : "OpenH323Lib - Win32 SSL No Trace" "$(OUTDIR)\OpenH323n.dll" ".\lib\OpenH323n.dbg"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"OpenH323Lib - Win32 SSL No TraceCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\dllmain.obj"
	-@erase "$(INTDIR)\libver.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\OpenH323n.dll"
	-@erase "$(OUTDIR)\OpenH323n.exp"
	-@erase "$(OUTDIR)\OpenH323n.lib"
	-@erase ".\lib\OpenH323n.dbg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

"$(INTDIR)" :
    if not exist "$(INTDIR)/$(NULL)" mkdir "$(INTDIR)"

CPP_PROJ=/nologo /MD /W4 /GX /Zi /O2 /Ob2 /D "NDEBUG" /D "P_SSL" /Fp"$(INTDIR)\OpenH323dll.pch" /Yu"ptlib.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0xc09 /fo"$(INTDIR)\libver.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\OpenH323dll.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=ptclib.lib ptlib.lib ssleay32.lib libeay32.lib src\vpbapi.lib Delayimp.lib winmm.lib msacm32.lib wsock32.lib kernel32.lib user32.lib advapi32.lib shell32.lib /nologo /subsystem:windows /dll /incremental:no /pdb:"$(OUTDIR)\OpenH323n.pdb" /machine:I386 /def:".\lib\NoTrace\OpenH323n.def" /out:"$(OUTDIR)\OpenH323n.dll" /implib:"$(OUTDIR)\OpenH323n.lib" /libpath:"lib" /delayload:vpbapi.dll 
DEF_FILE= \
	"$(INTDIR)\OpenH323n.def"
LINK32_OBJS= \
	"$(INTDIR)\dllmain.obj" \
	"$(INTDIR)\libver.res" \
	"$(OUTDIR)\OpenH323sn.lib"

"$(OUTDIR)\OpenH323n.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

OutDir=.\lib
TargetName=OpenH323n
InputPath=.\lib\OpenH323n.dll
SOURCE="$(InputPath)"

"$(OUTDIR)\OpenH323n.dbg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	<<tempfile.bat 
	@echo off 
	rebase -b 0x10000000 -x . $(OutDir)\$(TargetName).dll
<< 
	

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("OpenH323dll.dep")
!INCLUDE "OpenH323dll.dep"
!ELSE 
!MESSAGE Warning: cannot find "OpenH323dll.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "OpenH323dll - Win32 Release" || "$(CFG)" == "OpenH323dll - Win32 Debug" || "$(CFG)" == "OpenH323dll - Win32 No Trace" || "$(CFG)" == "OpenH323dll - Win32 SSL Release" || "$(CFG)" == "OpenH323dll - Win32 SSL Debug" || "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

"OpenH323Lib - Win32 Release" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 Release" 
   cd "."

"OpenH323Lib - Win32 ReleaseCLEAN" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 Release" RECURSE=1 CLEAN 
   cd "."

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

"OpenH323Lib - Win32 Debug" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 Debug" 
   cd "."

"OpenH323Lib - Win32 DebugCLEAN" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 Debug" RECURSE=1 CLEAN 
   cd "."

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

"OpenH323Lib - Win32 No Trace" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 No Trace" 
   cd "."

"OpenH323Lib - Win32 No TraceCLEAN" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 No Trace" RECURSE=1 CLEAN 
   cd "."

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

"OpenH323Lib - Win32 SSL Release" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 SSL Release" 
   cd "."

"OpenH323Lib - Win32 SSL ReleaseCLEAN" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 SSL Release" RECURSE=1 CLEAN 
   cd "."

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

"OpenH323Lib - Win32 SSL Debug" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 SSL Debug" 
   cd "."

"OpenH323Lib - Win32 SSL DebugCLEAN" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 SSL Debug" RECURSE=1 CLEAN 
   cd "."

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

"OpenH323Lib - Win32 SSL No Trace" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 SSL No Trace" 
   cd "."

"OpenH323Lib - Win32 SSL No TraceCLEAN" : 
   cd "."
   $(MAKE) /$(MAKEFLAGS) /F .\OpenH323Lib.mak CFG="OpenH323Lib - Win32 SSL No Trace" RECURSE=1 CLEAN 
   cd "."

!ENDIF 

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

"Console Components - Win32 Release" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 Release" 
   cd "..\..\..\..\h323system\openh323"

"Console Components - Win32 ReleaseCLEAN" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 Release" RECURSE=1 CLEAN 
   cd "..\..\..\..\h323system\openh323"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

"Console Components - Win32 Debug" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 Debug" 
   cd "..\..\..\..\h323system\openh323"

"Console Components - Win32 DebugCLEAN" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 Debug" RECURSE=1 CLEAN 
   cd "..\..\..\..\h323system\openh323"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

"Console Components - Win32 SSL Release" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 SSL Release" 
   cd "..\..\..\..\h323system\openh323"

"Console Components - Win32 SSL ReleaseCLEAN" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 SSL Release" RECURSE=1 CLEAN 
   cd "..\..\..\..\h323system\openh323"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

"Console Components - Win32 SSL Debug" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 SSL Debug" 
   cd "..\..\..\..\h323system\openh323"

"Console Components - Win32 SSL DebugCLEAN" : 
   cd "\Work\pwlib\src\ptlib\msos"
   $(MAKE) /$(MAKEFLAGS) /F ".\Console Components.mak" CFG="Console Components - Win32 SSL Debug" RECURSE=1 CLEAN 
   cd "..\..\..\..\h323system\openh323"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

!ENDIF 

SOURCE=.\src\dllmain.cxx

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

CPP_SWITCHES=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dllmain.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W4 /GX /Zi /Od /D "_DEBUG" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dllmain.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

CPP_SWITCHES=/nologo /MD /W4 /GX /Zi /O2 /Ob2 /D "NDEBUG" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dllmain.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

CPP_SWITCHES=/nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dllmain.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

CPP_SWITCHES=/nologo /MDd /W4 /GX /Zi /Od /D "_DEBUG" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dllmain.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

CPP_SWITCHES=/nologo /MD /W4 /GX /Zi /O2 /Ob2 /D "NDEBUG" /D "P_SSL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\dllmain.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\libver.rc

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"


"$(INTDIR)\libver.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) /l 0xc09 /fo"$(INTDIR)\libver.res" /i "src" /d "NDEBUG" $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"


"$(INTDIR)\libver.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) /l 0xc09 /fo"$(INTDIR)\libver.res" /i "src" /d "_DEBUG" $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"


"$(INTDIR)\libver.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) /l 0xc09 /fo"$(INTDIR)\libver.res" /i "src" /d "NDEBUG" $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"


"$(INTDIR)\libver.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) /l 0xc09 /fo"$(INTDIR)\libver.res" /i "src" /d "NDEBUG" $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"


"$(INTDIR)\libver.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) /l 0xc09 /fo"$(INTDIR)\libver.res" /i "src" /d "_DEBUG" $(SOURCE)


!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"


"$(INTDIR)\libver.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) /l 0xc09 /fo"$(INTDIR)\libver.res" /i "src" /d "NDEBUG" $(SOURCE)


!ENDIF 

SOURCE=src\OpenH323.dtf

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

InputDir=.\src
IntDir=.\lib\Release
OutDir=.\lib
TargetName=OpenH323
InputPath=src\OpenH323.dtf
USERDEP__OPENH="$(OutDir)\OpenH323s.lib"	"src\Private.def"	

"$(INTDIR)\OpenH323.def" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__OPENH)
	<<tempfile.bat 
	@echo off 
	MergeSym -I "$(INCLUDE)" -x ptlib.dtf -x $(InputDir)\Private.def $(OutDir)\OpenH323s.lib $(InputPath) 
	copy $(InputPath)+nul $(IntDir)\$(TargetName).def > nul 
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

InputDir=.\src
IntDir=.\lib\Release
OutDir=.\lib
TargetName=OpenH323
InputPath=src\OpenH323.dtf
USERDEP__OPENH="$(OutDir)\OpenH323s.lib"	"src\Private.def"	

"$(INTDIR)\OpenH323.def" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__OPENH)
	<<tempfile.bat 
	@echo off 
	MergeSym -I "$(INCLUDE)" -x ptlib.dtf -x $(InputDir)\Private.def $(OutDir)\OpenH323s.lib $(InputPath) 
	copy $(InputPath)+nul $(IntDir)\$(TargetName).def > nul 
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

!ENDIF 

SOURCE=src\OpenH323d.dtf

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

InputDir=.\src
IntDir=.\lib\Debug
OutDir=.\lib
TargetName=OpenH323d
InputPath=src\OpenH323d.dtf
USERDEP__OPENH3="$(OutDir)\OpenH323sd.lib"	"src\Private.def"	

"$(INTDIR)\OpenH323d.def" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__OPENH3)
	<<tempfile.bat 
	@echo off 
	MergeSym -I "$(INCLUDE)" -x ptlibd.dtf -x $(InputDir)\Private.def $(OutDir)\OpenH323sd.lib $(InputPath) 
	copy $(InputPath)+nul $(IntDir)\$(TargetName).def  > nul 
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

InputDir=.\src
IntDir=.\lib\Debug
OutDir=.\lib
TargetName=OpenH323d
InputPath=src\OpenH323d.dtf
USERDEP__OPENH3="$(OutDir)\OpenH323sd.lib"	"src\Private.def"	

"$(INTDIR)\OpenH323d.def" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__OPENH3)
	<<tempfile.bat 
	@echo off 
	MergeSym -I "$(INCLUDE)" -x ptlibd.dtf -x $(InputDir)\Private.def $(OutDir)\OpenH323sd.lib $(InputPath) 
	copy $(InputPath)+nul $(IntDir)\$(TargetName).def  > nul 
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

!ENDIF 

SOURCE=.\src\OpenH323n.dtf

!IF  "$(CFG)" == "OpenH323dll - Win32 Release"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 Debug"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 No Trace"

InputDir=.\src
IntDir=.\lib\NoTrace
OutDir=.\lib
TargetName=OpenH323n
InputPath=.\src\OpenH323n.dtf
USERDEP__OPENH32="$(OutDir)\OpenH323sn.lib"	"src\Private.def"	

"$(INTDIR)\OpenH323n.def" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__OPENH32)
	<<tempfile.bat 
	@echo off 
	MergeSym -I "$(INCLUDE)" -x ptlib.dtf -x $(InputDir)\Private.def $(OutDir)\OpenH323sn.lib $(InputPath) 
	copy $(InputPath)+nul $(IntDir)\$(TargetName).def  > nul 
<< 
	

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Release"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL Debug"

!ELSEIF  "$(CFG)" == "OpenH323dll - Win32 SSL No Trace"

InputDir=.\src
IntDir=.\lib\NoTrace
OutDir=.\lib
TargetName=OpenH323n
InputPath=.\src\OpenH323n.dtf
USERDEP__OPENH32="$(OutDir)\OpenH323sn.lib"	"src\Private.def"	

"$(INTDIR)\OpenH323n.def" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)" $(USERDEP__OPENH32)
	<<tempfile.bat 
	@echo off 
	MergeSym -I "$(INCLUDE)" -x ptlib.dtf -x $(InputDir)\Private.def $(OutDir)\OpenH323sn.lib $(InputPath) 
	copy $(InputPath)+nul $(IntDir)\$(TargetName).def  > nul 
<< 
	

!ENDIF 


!ENDIF 

