# Microsoft Developer Studio Project File - Name="OpenH323Lib" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=OpenH323Lib - Win32 SSL Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "OpenH323Lib.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "OpenH323Lib.mak" CFG="OpenH323Lib - Win32 SSL Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "OpenH323Lib - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 No Trace" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 SSL Release" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 SSL Debug" (based on "Win32 (x86) Static Library")
!MESSAGE "OpenH323Lib - Win32 SSL No Trace" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 1
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "lib"
# PROP BASE Intermediate_Dir "lib\Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "lib"
# PROP Intermediate_Dir "lib\Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Yu"ptlib.h" /FD /c
# ADD BASE RSC /l 0xc09
# ADD RSC /l 0xc09
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"lib\OpenH323s.lib"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "lib"
# PROP BASE Intermediate_Dir "lib\Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "lib"
# PROP Intermediate_Dir "lib\Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /Z7 /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR /Yu"ptlib.h" /FD /c
# ADD BASE RSC /l 0xc09
# ADD RSC /l 0xc09
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"lib\OpenH323sd.lib"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "lib"
# PROP BASE Intermediate_Dir "lib\NoTrace"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "lib"
# PROP Intermediate_Dir "lib\NoTrace"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W4 /GX /O1 /Ob2 /I "./include" /D "NDEBUG" /D "PTRACING" /Yu"ptlib.h" /FD /c
# ADD CPP /nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Yu"ptlib.h" /FD /c
# ADD BASE RSC /l 0xc09
# ADD RSC /l 0xc09
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"lib\OpenH323sn.lib"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "OpenH323Lib___Win32_SSL_Release"
# PROP BASE Intermediate_Dir "OpenH323Lib___Win32_SSL_Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "lib"
# PROP Intermediate_Dir "lib\Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /Yu"ptlib.h" /FD /c
# ADD CPP /nologo /MD /W4 /GX /Zd /O2 /Ob2 /D "NDEBUG" /D "PTRACING" /D "P_SSL" /Yu"ptlib.h" /FD /c
# ADD BASE RSC /l 0xc09
# ADD RSC /l 0xc09
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo /out:"lib\OpenH323s.lib"
# ADD LIB32 /nologo /out:"lib\OpenH323s.lib"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "OpenH323Lib___Win32_SSL_Debug"
# PROP BASE Intermediate_Dir "OpenH323Lib___Win32_SSL_Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "lib"
# PROP Intermediate_Dir "lib\Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /FR /Yu"ptlib.h" /FD /c
# ADD CPP /nologo /MDd /W4 /Gm /GX /ZI /Od /D "_DEBUG" /D "PTRACING" /D "P_SSL" /FR /Yu"ptlib.h" /FD /c
# ADD BASE RSC /l 0xc09
# ADD RSC /l 0xc09
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo /out:"lib\OpenH323sd.lib"
# ADD LIB32 /nologo /out:"lib\OpenH323sd.lib"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "OpenH323Lib___Win32_SSL_No_Trace"
# PROP BASE Intermediate_Dir "OpenH323Lib___Win32_SSL_No_Trace"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "lib"
# PROP Intermediate_Dir "lib\NoTrace"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /Yu"ptlib.h" /FD /c
# ADD CPP /nologo /MD /W4 /GX /O1 /Ob2 /D "NDEBUG" /D "PASN_NOPRINTON" /D "PASN_LEANANDMEAN" /D "P_SSL" /Yu"ptlib.h" /FD /c
# ADD BASE RSC /l 0xc09
# ADD RSC /l 0xc09
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo /out:"lib\OpenH323sn.lib"
# ADD LIB32 /nologo /out:"lib\OpenH323sn.lib"

!ENDIF 

# Begin Target

# Name "OpenH323Lib - Win32 Release"
# Name "OpenH323Lib - Win32 Debug"
# Name "OpenH323Lib - Win32 No Trace"
# Name "OpenH323Lib - Win32 SSL Release"
# Name "OpenH323Lib - Win32 SSL Debug"
# Name "OpenH323Lib - Win32 SSL No Trace"
# Begin Group "Source Files"

# PROP Default_Filter ".cxx"
# Begin Source File

SOURCE=.\src\channels.cxx
# End Source File
# Begin Source File

SOURCE=.\src\codecs.cxx
# End Source File
# Begin Source File

SOURCE=.\src\g711.c
# ADD CPP /W1
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\gkclient.cxx
# End Source File
# Begin Source File

SOURCE=.\src\gsmcodec.cxx
# End Source File
# Begin Source File

SOURCE=.\src\guid.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h235ras.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# PROP Exclude_From_Build 1

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# PROP BASE Exclude_From_Build 1

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h235security.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h261codec.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h323.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h323caps.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h323ep.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h323neg.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h323pdu.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h323rtp.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h450pdu.cxx
# End Source File
# Begin Source File

SOURCE=.\src\ixjwin32.cxx
# End Source File
# Begin Source File

SOURCE=.\src\jitter.cxx
# End Source File
# Begin Source File

SOURCE=.\src\lid.cxx
# End Source File
# Begin Source File

SOURCE=.\src\lpc10codec.cxx
# End Source File
# Begin Source File

SOURCE=.\src\mediafmt.cxx
# End Source File
# Begin Source File

SOURCE=.\src\mscodecs.cxx
# End Source File
# Begin Source File

SOURCE=.\src\precompile.cxx
# ADD CPP /Yc"ptlib.h"
# End Source File
# Begin Source File

SOURCE=.\src\q931.cxx
# End Source File
# Begin Source File

SOURCE=.\src\rtp.cxx
# End Source File
# Begin Source File

SOURCE=.\src\transports.cxx
# End Source File
# Begin Source File

SOURCE=.\src\videoio.cxx
# End Source File
# Begin Source File

SOURCE=.\src\vpblid.cxx
# End Source File
# Begin Source File

SOURCE=.\src\x224.cxx
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter ".h"
# Begin Source File

SOURCE=.\include\channels.h
# End Source File
# Begin Source File

SOURCE=.\include\codecs.h
# End Source File
# Begin Source File

SOURCE=.\include\gkclient.h
# End Source File
# Begin Source File

SOURCE=.\include\gsmcodec.h
# End Source File
# Begin Source File

SOURCE=.\include\guid.h
# End Source File
# Begin Source File

SOURCE=.\include\h235ras.h
# End Source File
# Begin Source File

SOURCE=.\include\h235security.h
# End Source File
# Begin Source File

SOURCE=.\include\h261codec.h
# End Source File
# Begin Source File

SOURCE=.\include\h323.h
# End Source File
# Begin Source File

SOURCE=.\include\h323caps.h
# End Source File
# Begin Source File

SOURCE=.\include\h323neg.h
# End Source File
# Begin Source File

SOURCE=.\include\h323pdu.h
# End Source File
# Begin Source File

SOURCE=.\include\h323rtp.h
# End Source File
# Begin Source File

SOURCE=.\include\h450pdu.h
# End Source File
# Begin Source File

SOURCE=.\include\ixjlid.h
# End Source File
# Begin Source File

SOURCE=.\include\jitter.h
# End Source File
# Begin Source File

SOURCE=.\include\lid.h
# End Source File
# Begin Source File

SOURCE=.\include\lpc10codec.h
# End Source File
# Begin Source File

SOURCE=.\include\mediafmt.h
# End Source File
# Begin Source File

SOURCE=.\include\mscodecs.h
# End Source File
# Begin Source File

SOURCE=.\include\q931.h
# End Source File
# Begin Source File

SOURCE=.\include\rtp.h
# End Source File
# Begin Source File

SOURCE=.\include\transports.h
# End Source File
# Begin Source File

SOURCE=.\include\videoio.h
# End Source File
# Begin Source File

SOURCE=.\include\vpblid.h
# End Source File
# Begin Source File

SOURCE=.\include\x224.h
# End Source File
# End Group
# Begin Group "ASN Files"

# PROP Default_Filter ".asn"
# Begin Source File

SOURCE=.\src\gccpdu.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling GCC ASN File
InputPath=.\src\gccpdu.asn
InputName=gccpdu

BuildCmds= \
	asnparser -m GCC -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling GCC ASN File
InputPath=.\src\gccpdu.asn
InputName=gccpdu

BuildCmds= \
	asnparser -m GCC -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling GCC ASN File
InputPath=.\src\gccpdu.asn
InputName=gccpdu

BuildCmds= \
	asnparser -m GCC -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling GCC ASN File
InputPath=.\src\gccpdu.asn
InputName=gccpdu

BuildCmds= \
	asnparser -m GCC -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling GCC ASN File
InputPath=.\src\gccpdu.asn
InputName=gccpdu

BuildCmds= \
	asnparser -m GCC -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling GCC ASN File
InputPath=.\src\gccpdu.asn
InputName=gccpdu

BuildCmds= \
	asnparser -m GCC -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gccpdu.cxx
# End Source File
# Begin Source File

SOURCE=.\include\gccpdu.h
# End Source File
# Begin Source File

SOURCE=.\src\h225.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H225 ASN File
InputPath=.\src\h225.asn
InputName=h225

BuildCmds= \
	asnparser -m H225 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

USERDEP__H225_=".\include\h235.h"	
# Begin Custom Build - Compiling H225 ASN File
InputPath=.\src\h225.asn
InputName=h225

BuildCmds= \
	asnparser -m H225 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H225 ASN File
InputPath=.\src\h225.asn
InputName=h225

BuildCmds= \
	asnparser -m H225 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H225 ASN File
InputPath=.\src\h225.asn
InputName=h225

BuildCmds= \
	asnparser -m H225 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

USERDEP__H225_=".\include\h235.h"	
# Begin Custom Build - Compiling H225 ASN File
InputPath=.\src\h225.asn
InputName=h225

BuildCmds= \
	asnparser -m H225 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H225 ASN File
InputPath=.\src\h225.asn
InputName=h225

BuildCmds= \
	asnparser -m H225 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h225.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h225.h
# End Source File
# Begin Source File

SOURCE=.\src\h235.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H235 ASN File
InputPath=.\src\h235.asn
InputName=h235

BuildCmds= \
	asnparser -m H235 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H235 ASN File
InputPath=.\src\h235.asn
InputName=h235

BuildCmds= \
	asnparser -m H235 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H235 ASN File
InputPath=.\src\h235.asn
InputName=h235

BuildCmds= \
	asnparser -m H235 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H235 ASN File
InputPath=.\src\h235.asn
InputName=h235

BuildCmds= \
	asnparser -m H235 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H235 ASN File
InputPath=.\src\h235.asn
InputName=h235

BuildCmds= \
	asnparser -m H235 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H235 ASN File
InputPath=.\src\h235.asn
InputName=h235

BuildCmds= \
	asnparser -m H235 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h235.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h235.h
# End Source File
# Begin Source File

SOURCE=.\src\h245.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H245 ASN File
InputPath=.\src\h245.asn
InputName=h245

BuildCmds= \
	asnparser -s2 -m H245 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName)_1.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\src\$(InputName)_2.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H245 ASN File
InputPath=.\src\h245.asn
InputName=h245

BuildCmds= \
	asnparser -s2 -m H245 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName)_1.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\src\$(InputName)_2.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H245 ASN File
InputPath=.\src\h245.asn
InputName=h245

BuildCmds= \
	asnparser -s2 -m H245 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName)_1.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\src\$(InputName)_2.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H245 ASN File
InputPath=.\src\h245.asn
InputName=h245

BuildCmds= \
	asnparser -s2 -m H245 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName)_1.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\src\$(InputName)_2.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H245 ASN File
InputPath=.\src\h245.asn
InputName=h245

BuildCmds= \
	asnparser -s2 -m H245 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName)_1.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\src\$(InputName)_2.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H245 ASN File
InputPath=.\src\h245.asn
InputName=h245

BuildCmds= \
	asnparser -s2 -m H245 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName)_1.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\src\$(InputName)_2.cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\include\h245.h
# End Source File
# Begin Source File

SOURCE=.\src\h245_1.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h245_2.cxx
# End Source File
# Begin Source File

SOURCE=.\src\h4501.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.1 ASN File
InputPath=.\src\h4501.asn
InputName=h4501

BuildCmds= \
	asnparser -m H4501 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.1 ASN File
InputPath=.\src\h4501.asn
InputName=h4501

BuildCmds= \
	asnparser -m H4501 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.1 ASN File
InputPath=.\src\h4501.asn
InputName=h4501

BuildCmds= \
	asnparser -m H4501 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.1 ASN File
InputPath=.\src\h4501.asn
InputName=h4501

BuildCmds= \
	asnparser -m H4501 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.1 ASN File
InputPath=.\src\h4501.asn
InputName=h4501

BuildCmds= \
	asnparser -m H4501 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.1 ASN File
InputPath=.\src\h4501.asn
InputName=h4501

BuildCmds= \
	asnparser -m H4501 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4501.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4501.h
# End Source File
# Begin Source File

SOURCE=.\src\h45010.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.10 ASN File
InputPath=.\src\h45010.asn
InputName=h45010

BuildCmds= \
	asnparser -m H45010 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.10 ASN File
InputPath=.\src\h45010.asn
InputName=h45010

BuildCmds= \
	asnparser -m H45010 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.10 ASN File
InputPath=.\src\h45010.asn
InputName=h45010

BuildCmds= \
	asnparser -m H45010 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.10 ASN File
InputPath=.\src\h45010.asn
InputName=h45010

BuildCmds= \
	asnparser -m H45010 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.10 ASN File
InputPath=.\src\h45010.asn
InputName=h45010

BuildCmds= \
	asnparser -m H45010 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.10 ASN File
InputPath=.\src\h45010.asn
InputName=h45010

BuildCmds= \
	asnparser -m H45010 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h45010.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h45010.h
# End Source File
# Begin Source File

SOURCE=.\src\h45011.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.11 ASN File
InputPath=.\src\h45011.asn
InputName=h45011

BuildCmds= \
	asnparser -m H45011 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.11 ASN File
InputPath=.\src\h45011.asn
InputName=h45011

BuildCmds= \
	asnparser -m H45011 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.11 ASN File
InputPath=.\src\h45011.asn
InputName=h45011

BuildCmds= \
	asnparser -m H45011 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.11 ASN File
InputPath=.\src\h45011.asn
InputName=h45011

BuildCmds= \
	asnparser -m H45011 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.11 ASN File
InputPath=.\src\h45011.asn
InputName=h45011

BuildCmds= \
	asnparser -m H45011 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.11 ASN File
InputPath=.\src\h45011.asn
InputName=h45011

BuildCmds= \
	asnparser -m H45011 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h45011.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h45011.h
# End Source File
# Begin Source File

SOURCE=.\src\h4502.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.2 ASN File
InputPath=.\src\h4502.asn
InputName=h4502

BuildCmds= \
	asnparser -m H4502 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.2 ASN File
InputPath=.\src\h4502.asn
InputName=h4502

BuildCmds= \
	asnparser -m H4502 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.2 ASN File
InputPath=.\src\h4502.asn
InputName=h4502

BuildCmds= \
	asnparser -m H4502 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.2 ASN File
InputPath=.\src\h4502.asn
InputName=h4502

BuildCmds= \
	asnparser -m H4502 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.2 ASN File
InputPath=.\src\h4502.asn
InputName=h4502

BuildCmds= \
	asnparser -m H4502 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.2 ASN File
InputPath=.\src\h4502.asn
InputName=h4502

BuildCmds= \
	asnparser -m H4502 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4502.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4502.h
# End Source File
# Begin Source File

SOURCE=.\src\h4503.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.3 ASN File
InputPath=.\src\h4503.asn
InputName=h4503

BuildCmds= \
	asnparser -m H4503 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.3 ASN File
InputPath=.\src\h4503.asn
InputName=h4503

BuildCmds= \
	asnparser -m H4503 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.3 ASN File
InputPath=.\src\h4503.asn
InputName=h4503

BuildCmds= \
	asnparser -m H4503 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.3 ASN File
InputPath=.\src\h4503.asn
InputName=h4503

BuildCmds= \
	asnparser -m H4503 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.3 ASN File
InputPath=.\src\h4503.asn
InputName=h4503

BuildCmds= \
	asnparser -m H4503 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.3 ASN File
InputPath=.\src\h4503.asn
InputName=h4503

BuildCmds= \
	asnparser -m H4503 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4503.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4503.h
# End Source File
# Begin Source File

SOURCE=.\src\h4504.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.4 ASN File
InputPath=.\src\h4504.asn
InputName=h4504

BuildCmds= \
	asnparser -m H4504 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.4 ASN File
InputPath=.\src\h4504.asn
InputName=h4504

BuildCmds= \
	asnparser -m H4504 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.4 ASN File
InputPath=.\src\h4504.asn
InputName=h4504

BuildCmds= \
	asnparser -m H4504 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.4 ASN File
InputPath=.\src\h4504.asn
InputName=h4504

BuildCmds= \
	asnparser -m H4504 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.4 ASN File
InputPath=.\src\h4504.asn
InputName=h4504

BuildCmds= \
	asnparser -m H4504 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.4 ASN File
InputPath=.\src\h4504.asn
InputName=h4504

BuildCmds= \
	asnparser -m H4504 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4504.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4504.h
# End Source File
# Begin Source File

SOURCE=.\src\h4505.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.5 ASN File
InputPath=.\src\h4505.asn
InputName=h4505

BuildCmds= \
	asnparser -m H4505 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.5 ASN File
InputPath=.\src\h4505.asn
InputName=h4505

BuildCmds= \
	asnparser -m H4505 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.5 ASN File
InputPath=.\src\h4505.asn
InputName=h4505

BuildCmds= \
	asnparser -m H4505 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.5 ASN File
InputPath=.\src\h4505.asn
InputName=h4505

BuildCmds= \
	asnparser -m H4505 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.5 ASN File
InputPath=.\src\h4505.asn
InputName=h4505

BuildCmds= \
	asnparser -m H4505 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.5 ASN File
InputPath=.\src\h4505.asn
InputName=h4505

BuildCmds= \
	asnparser -m H4505 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4505.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4505.h
# End Source File
# Begin Source File

SOURCE=.\src\h4506.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.6 ASN File
InputPath=.\src\h4506.asn
InputName=h4506

BuildCmds= \
	asnparser -m H4506 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.6 ASN File
InputPath=.\src\h4506.asn
InputName=h4506

BuildCmds= \
	asnparser -m H4506 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.6 ASN File
InputPath=.\src\h4506.asn
InputName=h4506

BuildCmds= \
	asnparser -m H4506 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.6 ASN File
InputPath=.\src\h4506.asn
InputName=h4506

BuildCmds= \
	asnparser -m H4506 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.6 ASN File
InputPath=.\src\h4506.asn
InputName=h4506

BuildCmds= \
	asnparser -m H4506 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.6 ASN File
InputPath=.\src\h4506.asn
InputName=h4506

BuildCmds= \
	asnparser -m H4506 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4506.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4506.h
# End Source File
# Begin Source File

SOURCE=.\src\h4507.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.7 ASN File
InputPath=.\src\h4507.asn
InputName=h4507

BuildCmds= \
	asnparser -m H4507 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.7 ASN File
InputPath=.\src\h4507.asn
InputName=h4507

BuildCmds= \
	asnparser -m H4507 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.7 ASN File
InputPath=.\src\h4507.asn
InputName=h4507

BuildCmds= \
	asnparser -m H4507 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.7 ASN File
InputPath=.\src\h4507.asn
InputName=h4507

BuildCmds= \
	asnparser -m H4507 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.7 ASN File
InputPath=.\src\h4507.asn
InputName=h4507

BuildCmds= \
	asnparser -m H4507 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.7 ASN File
InputPath=.\src\h4507.asn
InputName=h4507

BuildCmds= \
	asnparser -m H4507 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4507.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4507.h
# End Source File
# Begin Source File

SOURCE=.\src\h4508.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.8 ASN File
InputPath=.\src\h4508.asn
InputName=h4508

BuildCmds= \
	asnparser -m H4508 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.8 ASN File
InputPath=.\src\h4508.asn
InputName=h4508

BuildCmds= \
	asnparser -m H4508 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.8 ASN File
InputPath=.\src\h4508.asn
InputName=h4508

BuildCmds= \
	asnparser -m H4508 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.8 ASN File
InputPath=.\src\h4508.asn
InputName=h4508

BuildCmds= \
	asnparser -m H4508 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.8 ASN File
InputPath=.\src\h4508.asn
InputName=h4508

BuildCmds= \
	asnparser -m H4508 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.8 ASN File
InputPath=.\src\h4508.asn
InputName=h4508

BuildCmds= \
	asnparser -m H4508 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4508.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4508.h
# End Source File
# Begin Source File

SOURCE=.\src\h4509.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling H.450.9 ASN File
InputPath=.\src\h4509.asn
InputName=h4509

BuildCmds= \
	asnparser -m H4509 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling H.450.9 ASN File
InputPath=.\src\h4509.asn
InputName=h4509

BuildCmds= \
	asnparser -m H4509 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling H.450.9 ASN File
InputPath=.\src\h4509.asn
InputName=h4509

BuildCmds= \
	asnparser -m H4509 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling H.450.9 ASN File
InputPath=.\src\h4509.asn
InputName=h4509

BuildCmds= \
	asnparser -m H4509 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling H.450.9 ASN File
InputPath=.\src\h4509.asn
InputName=h4509

BuildCmds= \
	asnparser -m H4509 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling H.450.9 ASN File
InputPath=.\src\h4509.asn
InputName=h4509

BuildCmds= \
	asnparser -m H4509 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\h4509.cxx
# End Source File
# Begin Source File

SOURCE=.\include\h4509.h
# End Source File
# Begin Source File

SOURCE=.\src\ldap.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling LDAP ASN File
InputPath=.\src\ldap.asn
InputName=ldap

BuildCmds= \
	asnparser -m LDAP -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling LDAP ASN File
InputPath=.\src\ldap.asn
InputName=ldap

BuildCmds= \
	asnparser -m LDAP -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling LDAP ASN File
InputPath=.\src\ldap.asn
InputName=ldap

BuildCmds= \
	asnparser -m LDAP -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling LDAP ASN File
InputPath=.\src\ldap.asn
InputName=ldap

BuildCmds= \
	asnparser -m LDAP -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling LDAP ASN File
InputPath=.\src\ldap.asn
InputName=ldap

BuildCmds= \
	asnparser -m LDAP -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling LDAP ASN File
InputPath=.\src\ldap.asn
InputName=ldap

BuildCmds= \
	asnparser -m LDAP -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\ldap.cxx
# End Source File
# Begin Source File

SOURCE=.\include\ldap.h
# End Source File
# Begin Source File

SOURCE=.\src\mcspdu.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling MCS ASN File
InputPath=.\src\mcspdu.asn
InputName=mcspdu

BuildCmds= \
	asnparser -m MCS -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling MCS ASN File
InputPath=.\src\mcspdu.asn
InputName=mcspdu

BuildCmds= \
	asnparser -m MCS -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling MCS ASN File
InputPath=.\src\mcspdu.asn
InputName=mcspdu

BuildCmds= \
	asnparser -m MCS -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling MCS ASN File
InputPath=.\src\mcspdu.asn
InputName=mcspdu

BuildCmds= \
	asnparser -m MCS -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling MCS ASN File
InputPath=.\src\mcspdu.asn
InputName=mcspdu

BuildCmds= \
	asnparser -m MCS -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling MCS ASN File
InputPath=.\src\mcspdu.asn
InputName=mcspdu

BuildCmds= \
	asnparser -m MCS -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\mcspdu.cxx
# End Source File
# Begin Source File

SOURCE=.\include\mcspdu.h
# End Source File
# Begin Source File

SOURCE=.\src\x880.asn

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# Begin Custom Build - Compiling X.880 ASN File
InputPath=.\src\x880.asn
InputName=x880

BuildCmds= \
	asnparser -m X880 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# Begin Custom Build - Compiling X.880 ASN File
InputPath=.\src\x880.asn
InputName=x880

BuildCmds= \
	asnparser -m X880 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# Begin Custom Build - Compiling X.880 ASN File
InputPath=.\src\x880.asn
InputName=x880

BuildCmds= \
	asnparser -m X880 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# Begin Custom Build - Compiling X.880 ASN File
InputPath=.\src\x880.asn
InputName=x880

BuildCmds= \
	asnparser -m X880 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# Begin Custom Build - Compiling X.880 ASN File
InputPath=.\src\x880.asn
InputName=x880

BuildCmds= \
	asnparser -m X880 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# Begin Custom Build - Compiling X.880 ASN File
InputPath=.\src\x880.asn
InputName=x880

BuildCmds= \
	asnparser -m X880 -c $(InputPath) \
	copy .\src\$(InputName).h .\include\$(InputName).h \
	

".\src\$(InputName).cxx" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)

".\include\$(InputName).h" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   $(BuildCmds)
# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\x880.cxx
# End Source File
# Begin Source File

SOURCE=.\include\x880.h
# End Source File
# End Group
# Begin Group "GSM Files"

# PROP Default_Filter ".c"
# Begin Source File

SOURCE=.\src\gsm\src\add.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\code.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\decode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\gsm_create.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\gsm_decode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\gsm_destroy.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\gsm_encode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\gsm_option.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\long_term.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\lpc.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\preprocess.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\rpe.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\short_term.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\gsm\src\table.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD BASE CPP /W1 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /O2 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /ZI /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT BASE CPP /O<none> /YX /Yc /Yu
# ADD CPP /w /W0 /I "src\gsm\inc" /D NeedFunctionPrototypes=1 /D "WAV49"
# SUBTRACT CPP /O<none> /YX /Yc /Yu

!ENDIF 

# End Source File
# End Group
# Begin Group "VIC Files"

# PROP Default_Filter ""
# Begin Group "C Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src\vic\bv.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /D "WIN32"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\vic\huffcode.c

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /w /W0 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /w /W0 /D "WIN32"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /w /W0 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /w /W0 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# End Group
# Begin Group "CXX Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src\vic\dct.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /W1 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /W1 /D "WIN32"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /W1 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=".\src\vic\encoder-h261.cxx"
# ADD CPP /W1
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\vic\p64.cxx

!IF  "$(CFG)" == "OpenH323Lib - Win32 Release"

# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 Debug"

# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 No Trace"

# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Release"

# ADD BASE CPP /W1 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL Debug"

# ADD BASE CPP /W1 /D "WIN32"
# SUBTRACT BASE CPP /D "PTRACING" /YX /Yc /Yu
# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /D "PTRACING" /YX /Yc /Yu

!ELSEIF  "$(CFG)" == "OpenH323Lib - Win32 SSL No Trace"

# ADD BASE CPP /W1 /D "WIN32"
# SUBTRACT BASE CPP /YX /Yc /Yu
# ADD CPP /W1 /D "WIN32"
# SUBTRACT CPP /YX /Yc /Yu

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\src\vic\p64encoder.cxx
# ADD CPP /W1
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\vic\transmitter.cxx
# ADD CPP /W1
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\vic\vid_coder.cxx
# ADD CPP /W1
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# End Group
# Begin Group "H Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=".\src\vic\bsd-endian.h"
# End Source File
# Begin Source File

SOURCE=.\src\vic\config.h
# End Source File
# Begin Source File

SOURCE=.\src\vic\dct.h
# End Source File
# Begin Source File

SOURCE=".\src\vic\encoder-h261.h"
# End Source File
# Begin Source File

SOURCE=.\src\vic\grabber.h
# End Source File
# Begin Source File

SOURCE=".\src\vic\p64-huff.h"
# End Source File
# Begin Source File

SOURCE=.\src\vic\p64.h
# End Source File
# Begin Source File

SOURCE=.\src\vic\p64encoder.h
# End Source File
# Begin Source File

SOURCE=.\src\vic\transmitter.h
# End Source File
# Begin Source File

SOURCE=.\src\vic\vid_coder.h
# End Source File
# End Group
# End Group
# Begin Group "LPC10 Files"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src\lpc10\src\analys.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\bsynz.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\chanwr.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\dcbias.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\decode_.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\deemp.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\difmag.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\dyptrk.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\encode_.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\energy.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\f2clib.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\ham84.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\hp100.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\invert.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\irc2pc.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\ivfilt.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\lpc10.h
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\lpcdec.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\lpcenc.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\lpcini.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\lpfilt.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\median.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\mload.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\onset.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\pitsyn.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\placea.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\placev.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\preemp.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\prepro.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\random.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\rcchk.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\synths.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\tbdm.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\voicin.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# Begin Source File

SOURCE=.\src\lpc10\src\vparms.c
# ADD CPP /W1 /I "src/lpc10"
# SUBTRACT CPP /YX /Yc /Yu
# End Source File
# End Group
# End Target
# End Project
