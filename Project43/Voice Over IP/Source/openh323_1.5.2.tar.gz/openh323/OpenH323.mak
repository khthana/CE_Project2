!ifndef PWLIBDIR
PWLIBDIR=c:\work\pwlib
!endif

!IFDEF OPENSSLDIR
RELEASE_BUILD_TYPE=Win32 SSL Release
!ELSE
RELEASE_BUILD_TYPE=Win32 Release
!ENDIF

INCLUDE=$(INCLUDE);$(PWLIBDIR)\include\ptlib\msos;$(PWLIBDIR)\include\pwlib\mswin;$(PWLIBDIR)\include
LIB=$(LIB);$(PWLIBDIR)\Lib

all:
	nmake /nologo /f "OpenH323Lib.mak" RECURSE=0 CFG="OpenH323Lib - $(RELEASE_BUILD_TYPE)"
	nmake /nologo /f "OpenH323dll.mak" RECURSE=0 CFG="OpenH323dll - $(RELEASE_BUILD_TYPE)"
	cd samples\simple
	nmake /nologo /f "simple.mak" RECURSE=0 CFG="SimpH323 - $(RELEASE_BUILD_TYPE)"

!IFDEF OPENSSLDIR
DEBUG_BUILD_TYPE=Win32 SSL Debug"
!ELSE
DEBUG_BUILD_TYPE=Win32 Debug"
!ENDIF

debug: all
	nmake /nologo /f "OpenH323Lib.mak" RECURSE=0 CFG="OpenH323Lib - $(DEBUG_BUILD_TYPE)"
	nmake /nologo /f "OpenH323dll.mak" RECURSE=0 CFG="OpenH323dll - $(DEBUG_BUILD_TYPE)"
	cd samples\simple
	nmake /nologo /f "simple.mak" RECURSE=0 CFG="SimpH323 - $(DEBUG_BUILD_TYPE)"
