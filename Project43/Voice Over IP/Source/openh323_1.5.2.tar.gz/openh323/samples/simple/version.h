/*
 * version.h
 *
 * Version number header file for simple OpenH323 sample.
 *
 * A H.323 "net telephone" application.
 *
 * Copyright (c) 2000 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Contributor(s): ______________________________________.
 */

#ifndef _SimpleH323_VERSION_H
#define _SimpleH323_VERSION_H

#define MAJOR_VERSION 1
#define MINOR_VERSION 5
#define BUILD_TYPE    ReleaseCode
#define BUILD_NUMBER 2


#endif  // _SimpleH323_VERSION_H


// End of File ///////////////////////////////////////////////////////////////
