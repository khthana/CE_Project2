<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <title>Edit Information</title>
</head>

<body bgcolor="#FFFFFF" background="./images/Sakura.jpg"
 	text="#000000" link="#0000EE" vlink="#551A8B" alink="#FF0000" ><br>

<center><img SRC="./images/edit/Edit_information.gif" BORDER=0></center><br><br><br>

<?php

	$username = "cn=" .$user_id .",ou=user,o=esl.in.th";
	if($password != "")
	{
        	$ds=ldap_connect("localhost");          
        	if ($ds) 
		{
                	$r=ldap_bind($ds,$username,$password);
			if($r != 1)
			{
				exit();
			}      

                	$sr=ldap_search($ds,"ou=user,o=esl.in.th","uid=$user_id");
                	$info = ldap_get_entries($ds, $sr);

                	for ($i=0; $i<$info["count"]; $i++) 
			{
                        	$name =  $info[$i]["name"][0];
                       	 	$surname = $info[$i]["surname"][0];
				$email = $info[$i]["email"][0];
				$address = $info[$i]["address"][0];
                	}

                	ldap_close($ds);
		} 
		else 
		{
        		echo "<h4>Unable to connect to LDAP server</h4>";
		}
	}
	else
	{
		echo "Error : Please enter password" ."<br>";
		echo "<center><h3><a href=edit_inform.html>Go Back to Previous
Page</a></h3></center>";
		exit();
	}
?>

<form action="complete_edit_inform.php3" method="post">

	<input type=hidden name="username" value="<? echo $username ?>">

	<input type=hidden name="password" value="<? echo $password ?>">

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/edit/Name.gif" BORDER=0 >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    

	<input type="text" name="new_name" size=30 maxlength=30 value="<? echo $name; ?>"><br>

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/edit/Surname.gif" BORDER=0 >&nbsp;    

	<input type="text" name="new_surname" size=30 maxlength=30 value="<? echo
$surname; ?>"><br>

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/edit/Email.gif" BORDER=0 >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    

	<input type="text" name="new_email" size=30 maxlength=50 value="<? echo
$email; ?>"><br>


	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/edit/Address.gif" BORDER=0 >&nbsp;    

	<input type="text" name="new_address" size=30 maxlength=100
value="<? echo $address; ?>"><br><br>

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
	
	<input type=IMAGE SRC="./images/Next.gif" border=0>	
</form> 


<div align=right>
	<a href="./index.html"><img SRC="./images/Go_back.gif" border=0></a>
	<a href="./index.html"><img SRC="./images/edit/Panda.gif" border=0></a>
</div>

</body>
</html>


