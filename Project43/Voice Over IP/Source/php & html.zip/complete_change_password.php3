<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <title>Change Password</title>
</head>

<body bgcolor="#FFFFFF" background="./images/Sakura.jpg"
 	text="#000000" link="#0000EE" vlink="#551A8B" alink="#FF0000" ><br>

<center><img SRC="./images/change/Change_password.gif" BORDER=0></center>

<br><br><br>


<?php
	$root = "cn=Directory Manager,o=esl.in.th";
	$root_password = "secret99";
	if($new_password != $re_enter)
	{
		echo "Error : Password that you re_enter does not match";
		echo "<center><h3><a href = change_password.html>Back to Previous
Page</a></h3></center>";
		exit();
	}

	$ds=ldap_connect("localhost");  
        if ($ds) 
	{
	        // bind with appropriate dn to give update access
		$r=ldap_bind($ds,$root,$root_password);
                echo "Bind Operation Pass";
		echo "<br>";

                // prepare data
		$info["userpassword"]=$new_password;

                // add data to directory 
		$r=ldap_mod_replace($ds,$username,$info);
		echo "Change Password Done";
                echo "<br>";
		if(!$r)
		{
			echo ldap_errno($ds);				
			echo ldap_error($ds);
			echo "<br>";
		}

                ldap_close($ds);
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

		// echo "<img SRC="./images/change/Result.gif" BORDER=0 >" ."<br>";	

	} 
	else 
	{
		echo "Unable to connect to LDAP server";
        }
?>

<br>
<div align=right>
	<a href="./index.html"><img SRC="./images/Go_back.gif" border=0></a>
	<a href="./index.html"><img SRC="./images/change/Akane.gif" height=125 width=74
border=0></a>
</div>

</body>
</html>

