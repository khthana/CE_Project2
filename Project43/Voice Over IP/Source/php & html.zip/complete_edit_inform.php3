<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <title>Edit Information</title>
</head>

<body bgcolor="#FFFFFF" background="./images/Sakura.jpg"
 	text="#000000" link="#0000EE" vlink="#551A8B" alink="#FF0000" ><br>

<center><img SRC="./images/edit/Edit_information.gif" BORDER=0></center>

<br><br><br>

<?php
	$ds=ldap_connect("localhost");  
        if ($ds) 
	{
	        // bind with appropriate dn to give update access
		$r=ldap_bind($ds,$username,$password);
                echo "Bind Operation Pass";
		echo "<br>";

                // prepare data
		$info["name"]=$new_name;
		$info["surname"]=$new_surname;
		$info["email"]=$new_email;
		$info["address"]=$new_address;


                // add data to directory 
		$r=ldap_mod_replace($ds,$username,$info);
		echo "Change Attribute pass";
                echo "<br>";
		if(!$r)
		{
			echo ldap_errno($ds);				
			echo ldap_error($ds);
			echo "<br>";
		}

                ldap_close($ds);
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	

	} 
	else 
	{
		echo "Unable to connect to LDAP server";
        }
?>


<br>
<div align=right>
	<a href="./index.html"><img SRC="./images/Go_back.gif" border=0></a>
	<a href="./index.html"><img SRC="./images/edit/Panda.gif" border=0></a>
</div>

</body>
</html>
