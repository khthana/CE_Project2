<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <title>Search for Information</title>
</head>

<body bgcolor="#FFFFFF" background="./images/Sakura.jpg"
 	text="#000000" link="#0000EE" vlink="#551A8B" alink="#FF0000" >

<center><img SRC="./images/search/Search_inform.gif" BORDER=0></center><br>


	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/search/Result.gif" BORDER=0 >


<?php
	echo "<br>";
	echo "<br>";

        $ds=ldap_connect("localhost");
        if ($ds)
	{
                $r=ldap_bind($ds);

		$filter = "($search_by=$search_value)";

                $sr=ldap_search($ds,"ou=user,o=esl.in.th",$filter);
                $info = ldap_get_entries($ds, $sr);

                for ($i=0; $i<$info["count"]; $i++)
		{
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        echo "Name    : ". $info[$i]["name"][0] ."<br>";

		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        echo "Surname : ". $info[$i]["surname"][0] ."<br>";

		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
			echo "Email   : ". $info[$i]["email"][0] ."<br>";

		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
			echo "Address : ". $info[$i]["address"][0] ."<p>";
                }
                ldap_close($ds);
	}
	else
	{
        	echo "<h4>Unable to connect to LDAP server</h4>";
	}
?>

<div align=right>
	<a href="./index.html"><img SRC="./images/Go_back.gif" border=0></a>
	<a href="./index.html"><img SRC="./images/search/Kasumi.gif" border=0></a>
</div>

</body>
</html>




