<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
   <title>Change Password</title>
</head>

<body bgcolor="#FFFFFF" background="./images/Sakura.jpg"
 	text="#000000" link="#0000EE" vlink="#551A8B" alink="#FF0000" ><br>

<center><img SRC="./images/change/Change_password.gif" BORDER=0></center>

<br><br><br>

<?php
	echo "<br>";
	echo "<br>";

	$username = "cn=" .$user_id .",ou=user,o=esl.in.th";
	if($password != "")
	{
        	$ds=ldap_connect("localhost");          
        	if ($ds) 
		{
                	$r=ldap_bind($ds,$username,$password);
			if($r != 1)
			{
				exit();
			}      

                	ldap_close($ds);
		} 
		else 
		{
        		echo "<h4>Unable to connect to LDAP server</h4>";
		}
	}
	else
	{
		echo "Error : Please enter password" ."<br>";
		echo "<center><h3><a href=change_pasword.html>Go Back to Previous
Page</a></h3></center>";
		exit();
	}
?>

<form action="complete_change_password.php3" method="post">
	<input type=hidden name="username" value="<? echo $username ?>">

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/change/Enter_new_password.gif" BORDER=0 ><br>	

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/change/New_password.gif" BORDER=0 >&nbsp;&nbsp;&nbsp;

	<input type="password" name="new_password" size=30 maxlength=30
value="<? echo $name; ?>"><br>

	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img SRC="./images/change/Re_enter.gif" BORDER=0 >&nbsp;    

	<input type="password" name="re_enter" size=30 maxlength=30>&nbsp;&nbsp;

	<input type=IMAGE SRC="./images/Next.gif" border=0>
</form> 

<br>
<div align=right>
	<a href="./index.html"><img SRC="./images/Go_back.gif" border=0></a>
	<a href="./index.html"><img SRC="./images/change/Akane.gif" height=125 width=74
border=0></a>
</div>

</body>
</html>


