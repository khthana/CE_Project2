/*
 * main.h
 *
 * PWLib application header file for VBox
 *
 * A H.323 "net telephone" application.
 *
 * Copyright (c) 1998-2000 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Portions of this code were written with the assisance of funding from
 * Vovida Networks, Inc. http://www.vovida.com.
 *
 * Contributor(s): ______________________________________.
 *
 * $Log: main.h,v $
 * Revision 1.73  2000/12/16 21:54:31  eokerson
 * Added DTMF generation when User Input Indication received.
 *
 */

#ifndef _VBox_MAIN_H
#define _VBox_MAIN_H

#include <h323.h>


class VBox : public PProcess
{
    PCLASSINFO(VBox, PProcess)
  public:
    VBox();
    ~VBox();

    void Main();
};

class CallOptions : public PObject
{
  PCLASSINFO(CallOptions, PObject);

  public:
    BOOL Initialise(PArgList & args);
    void PrintOn(ostream & str) const;

    BOOL   noFastStart;
    BOOL   noH245Tunnelling;
    BOOL   noSilenceSuppression;
    int    jitter;
    PINDEX connectRing;
    WORD   connectPort;
};


class MyH323EndPoint : public H323EndPoint
{
    PCLASSINFO(MyH323EndPoint, H323EndPoint);
  public:
    // overrides from H323EndPoint
    virtual H323Connection * CreateConnection(unsigned callReference);
    virtual BOOL OnIncomingCall(H323Connection &, const H323SignalPDU &, H323SignalPDU &);
    virtual BOOL OnConnectionForwarded(H323Connection &, const PString &, const H323SignalPDU &);
    virtual void OnConnectionEstablished(H323Connection &, const PString &);
    virtual void OnConnectionCleared(H323Connection &, const PString &);
    virtual BOOL OpenAudioChannel(H323Connection &, BOOL, unsigned, H323AudioCodec &);

    // new functions
    BOOL Initialise(PConfigArgs & args, int verbose, BOOL hasMenu);
    void MakeOutgoingCall(const PString &, const PString &);
    void MakeOutgoingCall(const PString &, const PString &, CallOptions callOptions);
    void AwaitTermination();
    void TriggerDisconnect();

    void HandleUserInterface();
    void StartRinging();
    void StopRinging();
    void HandleRinging();
    void StartCall(const PString & str);
    void NewSpeedDial(const PString & str);
    void ListSpeedDials();

    PDECLARE_NOTIFIER(PTimer, MyH323EndPoint, OnAutoDisconnect);

    PString GetCurrentCallToken() const
      { return currentCallToken; }

    BOOL       terminateOnHangup;

  protected:
    // only used internally
    BOOL SetSoundDevice(PConfigArgs &, const char *, PSoundChannel::Directions);
    void AnswerCall(H323Connection::AnswerCallResponse response);

    CallOptions defaultCallOptions;
    CallOptions currentCallOptions;

    int  verbose;
    BOOL autoAnswer;

    PString  alwaysForwardParty;
    PString  busyForwardParty;
    PString  noAnswerForwardParty;
    unsigned noAnswerTime;
    PTimer   noAnswerTimer;
    PDECLARE_NOTIFIER(PTimer, MyH323EndPoint, OnNoAnswerTimeout);
    PString autoDial;
    BOOL dialAfterHangup;
    BOOL callerIdEnable;
    BOOL callerIdCallWaitingEnable;

    PFilePath ringFile;
    int ringDelay;
    PSyncPoint ringFlag;
    PThread * ringThread;

    int autoDisconnect;
    PTimer autoDisconnectTimer;

    int recordVolume;
    int playVolume;

#ifdef HAS_OSS
    BOOL InitialiseMixer(PConfigArgs & args, int _verbose);
    int  mixerDev;
    int  mixerRecChan;
    int  savedMixerRecChan;
    int  ossRecVol;
    int  ossPlayVol;
#endif

    PString currentCallToken;

    enum {
      uiDialtone,
      uiAnsweringCall,
      uiConnectingCall,
      uiWaitingForAnswer,
      uiCallInProgress,
      uiCallHungup,
      uiStateIllegal,
    } uiState;

    PMutex uiStateMutex;

    PSyncPoint exitFlag;
    BOOL       speakerphoneSwitch;
    BOOL       hasMenu;
  friend class MyH323Connection;
};


class MyH323Connection : public H323Connection
{
    PCLASSINFO(MyH323Connection, H323Connection);

  public:
    MyH323Connection(MyH323EndPoint &, unsigned, BOOL, BOOL, WORD, int);

    // overrides from H323Connection
    AnswerCallResponse OnAnswerCall(const PString &, const H323SignalPDU &, H323SignalPDU &);
    BOOL OnStartLogicalChannel(H323Channel &);
    void OnClosedLogicalChannel(H323Channel &);
    BOOL OnAlerting(const H323SignalPDU &, const PString &);
    void OnUserInputString(const PString &);
    PString GetCallerIdString() const;

  protected:
    MyH323EndPoint & myEndpoint;
    int verbose;
    int channelsOpen;
};


class UserInterfaceThread : public PThread
{
    PCLASSINFO(UserInterfaceThread, PThread);
  public:
    UserInterfaceThread(MyH323EndPoint & end)
      : PThread(1000, NoAutoDeleteThread), endpoint(end) { Resume(); }
    void Main()
      { endpoint.HandleUserInterface(); }
  protected:
    MyH323EndPoint & endpoint;
};


#endif  // _Vbox_MAIN_H


// End of File ///////////////////////////////////////////////////////////////
