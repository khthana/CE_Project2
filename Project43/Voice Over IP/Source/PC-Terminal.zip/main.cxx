/*
 * main.cxx
 *
 * PWLib application source file for VBox
 *
 * A H.323 "net telephone" application.
 *
 * Copyright (c) 1998-2000 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open H323 Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Portions of this code were written with the assisance of funding from
 * Vovida Networks, Inc. http://www.vovida.com.
 *
 * Contributor(s): ______________________________________.
 *
 * $Log: main.cxx,v $
 * Revision 1.205  2000/12/16 21:54:31  eokerson
 * Added DTMF generation when User Input Indication received.
 *
 */

#include <ptlib.h>

#include "main.h"
#include "gsmcodec.h"
#include "mscodecs.h"
#include "lpc10codec.h"
#include "h323pdu.h"


/* Header for connect to server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
/* End header for connect to server */

/* header for canonical */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>

/* End header for canonical */


#include "version.h"

PCREATE_PROCESS(VBox);

#define	DEFAULT_TIMEOUT	60000
#define	LAST_CALL_COUNT	16

class RingThread : public PThread
{
  PCLASSINFO(RingThread, PThread);

  public:
    RingThread(MyH323EndPoint & ep)
      : PThread(1000, NoAutoDeleteThread),
        endpoint(ep)
      { Resume(); }

    void Main()
      { endpoint.HandleRinging(); }

  protected:
    MyH323EndPoint & endpoint;
};

#define new PNEW


///////////////////////////////////////////////////////////////

VBox::VBox()
  : PProcess("Open H323 Project", "VBox",
             MAJOR_VERSION, MINOR_VERSION, BUILD_TYPE, BUILD_NUMBER)
{
}


VBox::~VBox()
{
}


void VBox::Main()
{
  //PArgList & args = GetArguments();
  PConfigArgs args(GetArguments());

  args.Parse(
             "h-help."
             "j-jitter:"             "-no-jitter."
             "l-listen."
             "n-no-gatekeeper."
          , FALSE);

  int verbose = 255;

  if (verbose >= 3)
    cout << GetName()
         << " Version " << GetVersion(TRUE)
         << " by " << GetManufacturer()
         << " on " << GetOSClass() << ' ' << GetOSName()
         << " (" << GetOSVersion() << '-' << GetOSHardware() << ")\n\n";

  if (args.HasOption('h') || (!args.HasOption('l') && args.GetCount() == 0)) {
    cout << "Usage : " << GetName() << " [options] -l\n"
            "      : " << GetName() << " [options] [-p host] hostname/alias\n"
	    "\n   where:  hostname/alias = Remote host/alias to call\n"

            "\nOptions:\n"
            "  -h --help               : Display this help message.\n"
            "  -l --listen             : Only listen for incoming calls\n"
            "  -n --no-gatekeeper      : Disable gatekeeper discovery.\n"
            << endl;
    return;
  }


  BOOL hasMenu = !args.HasOption("disable-menu");

  args.Save("save");

  MyH323EndPoint * endpoint = new MyH323EndPoint;
  if (endpoint->Initialise(args, verbose, hasMenu)) {
      if (args.HasOption('l'))
        if (verbose >= 2)
          cout << "Waiting for incoming calls for \"" << endpoint->GetLocalUserName() << "\"\n";
      endpoint->AwaitTermination();
  }

  delete endpoint;

  if (verbose >= 3)
    cout << GetName() << " ended." << endl;
}


///////////////////////////////////////////////////////////////

BOOL MyH323EndPoint::Initialise(PConfigArgs & args, int _verbose, BOOL _hasMenu)
{
  PINDEX i;

  verbose = _verbose;
  hasMenu = _hasMenu;
  uiState = uiDialtone;

  // get ports
  WORD port       = H323ListenerTCP::DefaultSignalPort;
  WORD listenPort = port;
  if (!args.GetOptionString("port").IsEmpty())
    port = (WORD)args.GetOptionString("port").AsInteger();


  defaultCallOptions.jitter      = GetMaxAudioDelayJitter();
  defaultCallOptions.connectPort = port;
  defaultCallOptions.connectRing = 0;

  if (!defaultCallOptions.Initialise(args))
    return FALSE;

  currentCallOptions = defaultCallOptions;

  //////////

  terminateOnHangup    = !args.HasOption('l');
  alwaysForwardParty   = args.GetOptionString('F');
  busyForwardParty     = args.GetOptionString('B');
  noAnswerForwardParty = args.GetOptionString('N');
  noAnswerTime         = args.GetOptionString("answer-timeout", "30").AsUnsigned();
  dialAfterHangup      = args.HasOption("dial-after-hangup");

  noAnswerTimer.SetNotifier(PCREATE_NOTIFIER(OnNoAnswerTimeout));


  if (verbose >= 3) {
    cout << "Local username: " << GetLocalUserName() << "\n"
         << "TerminateOnHangup is " << terminateOnHangup << "\n"
         << "DialAfterHangup is " << dialAfterHangup << "\n"
         << defaultCallOptions
         << endl;

  }

  if (args.HasOption("ringdelay"))
    ringDelay = args.GetOptionString("ringdelay").AsInteger();
  else
    ringDelay = 5;

  // The order in which capabilities are added to the capability table
  // determines which one is selected by default.

  int g711Frames = 30;
  int gsmFrames = 4;

  if (verbose >= 3) {
    cout <<"G.711 frame size: " << g711Frames << endl;
    cout <<"GSM frame size: " << gsmFrames << endl;
  }

  H323_GSM0610Capability * gsmCap;
  SetCapability(0, 0, gsmCap = new H323_GSM0610Capability);
  gsmCap->SetTxFramesInPacket(gsmFrames);

  MicrosoftGSMAudioCapability * msGsmCap;
  SetCapability(0, 0, msGsmCap = new MicrosoftGSMAudioCapability);
  msGsmCap->SetTxFramesInPacket(gsmFrames);

  H323_G711Capability * g711Cap;
  SetCapability(0, 0, g711Cap = new H323_G711Capability(H323_G711Capability::muLaw));
  g711Cap->SetTxFramesInPacket(g711Frames);

  SetCapability(0, 0, g711Cap = new H323_G711Capability(H323_G711Capability::ALaw));
  g711Cap->SetTxFramesInPacket(g711Frames);

  SetCapability(0, 0, new H323_LPC10Capability(*this));

  PStringArray toRemove = args.GetOptionString('D').Lines();
  PStringArray toReorder = args.GetOptionString('P').Lines();

  static const char * const oldArgName[] = {
    "g7231",   "g729",  "g728",  "gsm", "g711-ulaw", "g711-alaw"
  };
  static const char * const capName[] = {
    "G.723.1", "G.729", "G.728", "GSM", "G.711 u-Law", "G.711 A-Law"
  };

  for (i = 0; i < PARRAYSIZE(oldArgName); i++) {
    if (args.HasOption(PString("no-")+oldArgName[i]))
      toRemove[toRemove.GetSize()] = capName[i];
    if (args.HasOption(oldArgName[i]))
      toReorder[toReorder.GetSize()] = capName[i];
  }

  capabilities.Remove(toRemove);
  capabilities.Reorder(toReorder);

  H323_UserInputCapability::AddAllCapabilities(capabilities, 0, P_MAX_INDEX);
  //SetCapability(0, P_MAX_INDEX, new H323_T120Capability);

  if (verbose >= 4)
    cout <<  "Codecs (in preference order):\n" << setprecision(2) << capabilities << endl << endl;


  if (!args.GetOptionString("listenport").IsEmpty())
    listenPort = (WORD)args.GetOptionString("listenport").AsInteger();

  PStringArray interfaceList;
  if (!args.GetOptionString('i').IsEmpty())
    interfaceList = args.GetOptionString('i').Lines();

  PString interfacePrintable;

  // if no interfaces specified, then bind to all interfaces with a single Listener
  // otherwise, bind to specific interfaces
  if (interfaceList.GetSize() == 0) {
    PIPSocket::Address interfaceAddress(INADDR_ANY);
    H323ListenerTCP * listener = new H323ListenerTCP(*this, interfaceAddress, listenPort);
    if (!StartListener(listener)) {
      cerr <<  "Could not open H.323 listener port on "
           << listener->GetListenerPort() << endl;
      return FALSE;
    }
    interfacePrintable = psprintf("ALL:%i", listenPort);
  } else {
    for (i = 0; i < interfaceList.GetSize(); i++) {

      PString interfaceStr = interfaceList[i];
      WORD interfacePort = listenPort;

      PINDEX pos;
      if ((pos = interfaceStr.Find(':')) != P_MAX_INDEX) {
        interfacePort = (WORD)interfaceStr.Mid(pos+1).AsInteger();
        interfaceStr = interfaceStr.Left(pos);
      }
      interfacePrintable &= interfaceStr + ":" + PString(PString::Unsigned, interfacePort);
      PIPSocket::Address interfaceAddress(interfaceStr);

      H323ListenerTCP * listener = new H323ListenerTCP(*this, interfaceAddress, interfacePort);
      if (!StartListener(listener)) {
        cerr << "Could not open H.323 listener port on "
             << interfaceAddress << ":" << interfacePort << endl;
        return FALSE;
      }
    }
  }

  if (verbose >= 3)
    cout << "Listening interfaces : " << interfacePrintable << endl;


  ringThread = NULL;

  autoDisconnect = 0;

  return TRUE;
}


H323Connection * MyH323EndPoint::CreateConnection(unsigned callReference)
{
  return new MyH323Connection(*this, callReference,
                              currentCallOptions.noFastStart,
                              currentCallOptions.noH245Tunnelling,
                              (WORD)currentCallOptions.jitter,
                              verbose);
}


BOOL MyH323EndPoint::OnIncomingCall(H323Connection & connection,
                                    const H323SignalPDU &,
                                    H323SignalPDU &)
{
  currentCallOptions = defaultCallOptions;

  // get remote address so we can call back later
  PString lastCallingParty = connection.GetSignallingChannel()->GetRemoteAddress().GetHostName();

  PConfig config("Callers");
  int index = config.GetInteger("index");
  PString lastLastCallingParty = config.GetString(PString(PString::Unsigned, index));
  index = (index + 1) % LAST_CALL_COUNT;
  PTime now;
  PString indexStr = PString(PString::Unsigned, index);
  config.SetString(indexStr,           lastCallingParty);
  config.SetString(indexStr + "_Time", now.AsString());
  config.SetString("index",            indexStr);

  if (!alwaysForwardParty.IsEmpty()) {
    cout << "Forwarding call to \"" << alwaysForwardParty << "\"." << endl;
    return !connection.ForwardCall(alwaysForwardParty);
  }

  // incoming call is accepted if no call in progress
  // unless the xJack is open and phone is off onhook

  if (!currentCallToken.IsEmpty())
    cout << "WARNING: current call token not empty" << endl;

  if (currentCallToken.IsEmpty()
  )
    return TRUE;

  if (busyForwardParty.IsEmpty()) {
    PTime now;
    cout << "Incoming call from \"" << connection.GetRemotePartyName() << "\" rejected at " << now << ", line busy!" << endl;
    return FALSE;
  }

  cout << "Forwarding call to \"" << busyForwardParty << "\"." << endl;
  return !connection.ForwardCall(busyForwardParty);
}


BOOL MyH323EndPoint::OnConnectionForwarded(H323Connection & /*connection*/,
                                           const PString & forwardParty,
                                           const H323SignalPDU & /*pdu*/)
{
  if (MakeCall(forwardParty, currentCallToken)) {
    cout << GetLocalUserName() << " is being forwarded to host " << forwardParty << endl;
    return TRUE;
  }

  cout << "Error forwarding call to \"" << forwardParty << '"' << endl;
  return FALSE;
}


void MyH323EndPoint::OnNoAnswerTimeout(PTimer &, INT)
{
  H323Connection * connection = FindConnectionWithLock(currentCallToken);
  if (connection != NULL) {
    cout << "Forwarding call to \"" << noAnswerForwardParty << "\"." << endl;
    connection->ForwardCall(noAnswerForwardParty);
    connection->Unlock();
  }
}

void MyH323EndPoint::OnConnectionEstablished(H323Connection & connection,
                                             const PString & token)
{
   ////////////////////Initial for Canonical Serial //////////////////////////////

#define BAUDRATE B9600
#define MODEMDEVICE "/dev/ttyS0"
#define _POSIX_SOURCE 1 /* POSIX compliant source */

#define FALSE 0
#define TRUE 1

//  volatile int STOP=FALSE;
  int fd,res;
  struct termios oldtio,newtio;

 fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK); // NoN block;
 if (fd <0) {perror(MODEMDEVICE); exit(-1); }

 tcgetattr(fd,&oldtio); /* save current serial port settings */
 bzero(&newtio, sizeof(newtio)); /* clear struct for new port settings */

 newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
 newtio.c_iflag = IGNPAR | ICRNL;
 newtio.c_oflag = 0;
 newtio.c_lflag = ICANON;

 tcflush(fd, TCIFLUSH);
 tcsetattr(fd,TCSANOW,&newtio);

  ///////////////////* End  initial Canonical Serial */////////////////////////

 for (int i =0;i < 100;i++) usleep(100);
 res = write(fd,"@O",2);
 close(fd);
  currentCallToken = token;
  cout << "Call with \"" << connection.GetRemotePartyName() << "\" established." << endl;
  uiState = uiCallInProgress;
}

void MyH323EndPoint::OnAutoDisconnect(PTimer &, INT)
{
  if (!currentCallToken.IsEmpty()) {
    ClearCall(currentCallToken);
    cout << "Autodisconnect triggered" << endl;
  }
}

void MyH323EndPoint::TriggerDisconnect()
{
  // we have an autodisconnect timer specified, start the timer
  if (autoDisconnect > 0) {
    autoDisconnectTimer.SetNotifier(PCREATE_NOTIFIER(OnAutoDisconnect));
    autoDisconnectTimer = PTimeInterval(autoDisconnect * 100);
  }
}


void MyH323EndPoint::OnConnectionCleared(H323Connection & connection, const PString & clearedCallToken)
{
////////////////////Initial for Canonical Serial //////////////////////////////

#define BAUDRATE B9600
#define MODEMDEVICE "/dev/ttyS0"
#define _POSIX_SOURCE 1 /* POSIX compliant source */

#define FALSE 0
#define TRUE 1

//  volatile int STOP=FALSE;
  int fd,res;
  struct termios oldtio,newtio;

 fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK); // NoN block;
 if (fd <0) {perror(MODEMDEVICE); exit(-1); }

 tcgetattr(fd,&oldtio); /* save current serial port settings */
 bzero(&newtio, sizeof(newtio)); /* clear struct for new port settings */

 newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
 newtio.c_iflag = IGNPAR | ICRNL;
 newtio.c_oflag = 0;
 newtio.c_lflag = ICANON;

 tcflush(fd, TCIFLUSH);
 tcsetattr(fd,TCSANOW,&newtio);

  ///////////////////* End  initial Canonical Serial */////////////////////////

  // stop any ringing that is occurring
  StopRinging();

  // ignore connections that are not the current connection
  if (clearedCallToken != currentCallToken)
    return;

  // indicate that our connection is now cleared
  currentCallToken = "";

  // indicate call has hungup
  uiState = uiCallHungup;

  if (verbose != 0) {

    BOOL printDuration = TRUE;

    PString remoteName = '"' + connection.GetRemotePartyName() + '"';

    switch (connection.GetCallEndReason()) {
      case H323Connection::EndedByCallForwarded :
        printDuration = FALSE;   // Don't print message here, was printed when forwarded
        break;

      case H323Connection::EndedByRemoteUser :
        cout << remoteName << " has cleared the call";
        //  Add send @N to V-Box
        for (int i =0;i < 100;i++) usleep(1000);
        res = write(fd,"@N",2);
        close(fd);

        break;
      case H323Connection::EndedByCallerAbort :
        cout << remoteName << " has stopped calling";

        for (int i =0;i < 100;i++) usleep(1000);
        res = write(fd,"@N",2);
        close(fd);

        break;
      case H323Connection::EndedByRefusal :
        cout << remoteName << " did not accept your call";

        for (int i =0;i < 100;i++) usleep(1000);
        res = write(fd,"@R",2);
        close(fd);
        break;
      case H323Connection::EndedByNoAnswer :
        cout << remoteName << " did not answer your call";

        for (int i =0;i < 100;i++) usleep(1000);
        res = write(fd,"@N",2);
        close(fd);

        break;
      case H323Connection::EndedByTransportFail :
        cout << "Call with " << remoteName << " ended abnormally";

        for (int i =0;i < 100;i++) usleep(1000);
        res = write(fd,"@N",2);
        close(fd);

        break;
      case H323Connection::EndedByCapabilityExchange :
        cout << "Could not find common codec with " << remoteName;
        break;
      case H323Connection::EndedByNoAccept :
        cout << "Did not accept incoming call from " << remoteName;

        for (int i =0;i < 100;i++) usleep(1000);
        res = write(fd,"@N",2);
        close(fd);

        break;
      case H323Connection::EndedByAnswerDenied :
        cout << "Refused incoming call from " << remoteName;
        break;
      case H323Connection::EndedByNoUser :
        cout << "Gatekeeper could find user " << remoteName;
        break;
      case H323Connection::EndedByNoBandwidth :
        cout << "Call to " << remoteName << " aborted, insufficient bandwidth.";
        break;
      case H323Connection::EndedByConnectFail :
        switch (connection.GetSignallingChannel()->GetErrorNumber()) {
          case ENETUNREACH :
            cout << remoteName << " could not be reached.";
            break;
          case ETIMEDOUT :
            cout << remoteName << " is not online.";
            break;
          case ECONNREFUSED :
            cout << "No phone running for " << remoteName;
            break;
          default :
            cout << "Transport error calling " << remoteName;
            for (int i =0;i < 100;i++) usleep(100);
            res = write(fd,"@N",2);
            close(fd);

        }
        break;
      default :
        cout << "Call with " << remoteName << " completed";
    }

    if (printDuration)
      cout << ", duration "
           << setprecision(0) << setw(5)
           << (PTime() - connection.GetConnectionStartTime())
           << endl;
  }

  if (!hasMenu && terminateOnHangup) {
    exitFlag.Signal();
    exitFlag.Wait();
  }
}


BOOL MyH323EndPoint::OpenAudioChannel(H323Connection & connection,
                                         BOOL isEncoding,
                                         unsigned bufferSize,
                                         H323AudioCodec & codec)
{
  codec.SetSilenceDetectionMode(currentCallOptions.noSilenceSuppression ?
                                   H323AudioCodec::NoSilenceDetection :
                                   H323AudioCodec::AdaptiveSilenceDetection);


  if (H323EndPoint::OpenAudioChannel(connection, isEncoding, bufferSize, codec))
    return TRUE;

  cerr << "Could not open sound device ";
  if (isEncoding)
    cerr << GetSoundChannelRecordDevice();
  else
    cerr << GetSoundChannelPlayDevice();
  cerr << " - Check permissions or full duplex capability." << endl;

  return FALSE;
}

//
//  if gateway is empty, then dest is assumed to be a IP address and optional port
//  if gateway is non-empty, then gateway is assumed to be an IP address and optional port, and
//  dest is passed to the gateway as the e164 address
//
void MyH323EndPoint::MakeOutgoingCall(const PString & dest,
                                      const PString & gateway)
{
  MakeOutgoingCall(dest, gateway, defaultCallOptions);
}

void MyH323EndPoint::MakeOutgoingCall(const PString & dest,
                                      const PString & gateway,
                                      CallOptions callOptions)
{
  currentCallOptions = callOptions;

  PString fullAddress;

  if (!gateway)
    fullAddress = gateway;
  else
    fullAddress = dest;

  if ((fullAddress.Find(':') == P_MAX_INDEX) && (callOptions.connectPort != H323ListenerTCP::DefaultSignalPort))
    fullAddress += psprintf(":%i", currentCallOptions.connectPort);

  if (!gateway)
    fullAddress = dest.Trim() + '@' + fullAddress;


  if (!MakeCall(fullAddress, currentCallToken)) {
    cout << "Error making call to \"" << fullAddress << '"' << endl;
    return;
  }

  PConfig config("Calls");
  int index = config.GetInteger("index");
  PString lastCalledParty = config.GetString(PString(PString::Unsigned, index));
  index = (index + 1) % LAST_CALL_COUNT;
  PTime now;
  PString indexStr = PString(PString::Unsigned, index);
  config.SetString(indexStr,           fullAddress);
  config.SetString(indexStr + "_Time", now.AsString());
  config.SetString("index",            indexStr);

  cout << GetLocalUserName() << " is calling host " << fullAddress << endl;
  uiState = uiConnectingCall;
}

void MyH323EndPoint::NewSpeedDial(const PString & ostr)
{
  PString str = ostr;
  PINDEX idx = str.Find(' ');
  if (str.IsEmpty() || (idx == P_MAX_INDEX)) {
    cout << "Must specify speedial number and string" << endl;
    return;
  }

  PString key  = str.Left(idx).Trim();
  PString data = str.Mid(idx).Trim();

  PConfig config("Speeddial");
  config.SetString(key, data);

  cout << "Speedial " << key << " set to " << data << endl;
}

void MyH323EndPoint::ListSpeedDials()
{
  PConfig config("Speeddial");
  PStringList keys = config.GetKeys();
  if (keys.GetSize() == 0) {
    cout << "No speed dials defined" << endl;
    return;
  }

  PINDEX i;
  for (i = 0; i < keys.GetSize(); i++)
    cout << keys[i] << ":   " << config.GetString(keys[i]) << endl;
}

//
// StartCall accepts any of the following types of arguments
//    speedial '#'      lookup the string in the registry, and continue processing
//    ipaddress         dial this IP address or hostname
//    num ' ' gateway   dial the number using the specified gateway
//

void MyH323EndPoint::StartCall(const PString & ostr)
{
  PString str = ostr.Trim();
  if (str.IsEmpty())
    cout << "Must supply hostname to connect to!\n";

  CallOptions callOptions = defaultCallOptions;

  // check for speed dials, and match wild cards as we go
  PString key, prefix;
  if ((str.GetLength() > 1) && (str[str.GetLength()-1] == '#')) {

    key = str.Left(str.GetLength()-1).Trim();

    str = PString();
    PConfig config("Speeddial");
    PINDEX p;
    for (p = key.GetLength(); p > 0; p--) {

      PString newKey = key.Left(p);
      prefix = newKey;
      PINDEX q;

      // look for wild cards
      str = config.GetString(newKey + '*').Trim();
      if (!str.IsEmpty())
        break;

      // look for digit matches
      for (q = p; q < key.GetLength(); q++)
        newKey += '?';
      str = config.GetString(newKey).Trim();
      if (!str.IsEmpty())
        break;
    }
    if (str.IsEmpty())
      cout << "Speed dial \"" << key << "\" not defined" << endl;
    else if ((p = str.Find('(')) != P_MAX_INDEX) {
      PString argStr = str.Mid(p);
      if (argStr.GetLength() > 0 && argStr[argStr.GetLength()-1] == ')')
        argStr = argStr.Mid(1, argStr.GetLength()-2);
      PArgList strArgs(argStr,
                       "f-fast-disable."
                       "T-h245tunneldisable."
                       "e-silence."
                       "j-jitter:"
                       "-connectport:"
                       "-connectring:");
      callOptions.Initialise(strArgs);
      str = str.Left(p);
      cout << "Per connection call options set: " << argStr << endl
           << callOptions
           << endl;
    }
  }

  if (!str.IsEmpty()) {
    PINDEX idx = str.Find(' ');
    if (idx == P_MAX_INDEX) {
      if (!key && (str[0] == '@'))
        MakeOutgoingCall(key, str.Mid(1), callOptions);
      else if (!key && !prefix && (str[0] == '%')) {
        if (key.Left(prefix.GetLength()) == prefix)
          key = key.Mid(prefix.GetLength());
        MakeOutgoingCall(key, str.Mid(1), callOptions);
      } else
        MakeOutgoingCall(str, PString(), callOptions);
    } else {
      PString host = str.Left(idx).Trim();
      PString gw   = str.Mid(idx).Trim();
      MakeOutgoingCall(host, gw, callOptions);
    }
    return;
  }

  uiState = MyH323EndPoint::uiCallHungup;
}

void MyH323EndPoint::AwaitTermination()
{
  PThread * userInterfaceThread = NULL;
  if (hasMenu)
    userInterfaceThread = new UserInterfaceThread(*this);

  exitFlag.Wait();

  if (userInterfaceThread != NULL) {
    userInterfaceThread->Terminate();
    userInterfaceThread->WaitForTermination();
    delete userInterfaceThread;
  }
}

void MyH323EndPoint::HandleUserInterface()
{
  PConsoleChannel console(PConsoleChannel::StandardInput);

  PTRACE(2, "VBox\tUser interface thread started.");

////////////////////Initial for Canonical Serial //////////////////////////////

  #define BAUDRATE B9600
  #define MODEMDEVICE "/dev/ttyS0"
  #define _POSIX_SOURCE 1 /* POSIX compliant source */
  #define FALSE 0
  #define TRUE 1

//  volatile int STOP=FALSE;
  int fd,res;
  struct termios oldtio,newtio;
  char buf[20];

  fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK); // NoN block;
  if (fd <0) {perror(MODEMDEVICE); exit(-1); }

  tcgetattr(fd,&oldtio); /* save current serial port settings */
  bzero(&newtio, sizeof(newtio)); /* clear struct for new port settings */

  newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
  newtio.c_iflag = IGNPAR | ICRNL;
  newtio.c_oflag = 0;
  newtio.c_lflag = ICANON;

  tcflush(fd, TCIFLUSH);
  tcsetattr(fd,TCSANOW,&newtio);

  ///////////////////* End  initial Canonical Serial */////////////////////////
  /////////////////////////Check V-Box///////////////////////////////////

  char ID[20],Temp[20];
  char *PTemp;
  int  check = TRUE;

  res = write(fd,"@K",2);
  buf[res] = 0;
  cout << "Waiting for incoming ID Number.\n" << endl;

  while(check == TRUE){
     res = read(fd,buf,9);
     buf[res] = 0;

     if (buf[0] == '@'){
          if (buf[1] == 'D'){
            cout << "ID Number = " << buf << endl;
            check = FALSE;
          }
     }
  }

  check = TRUE;
  strcpy(Temp,buf);
  PTemp = &Temp[2];
  strcpy(ID,PTemp);


  //////////////////////End Check V-Box//////////////////////////////////

  /* Define message number for my protocol */
  #define	LOGIN	        1
  #define       CALL	        2
  #define       REQ_USERNAME	3
  #define	REQ_PASSWORD	4
  #define	LOGIN_SUCCESS	5
  #define	LOGIN_FAIL	6
  #define       REQ_CALL_ID	7
  #define	IDLE		8
  #define	BUSY		9
  #define	IDLE_ACK	10
  #define	BUSY_ACK	11
  #define	RE_ACK		12
  #define       OFFLINE		13
  #define       OFFLINE_ACK	14

  /* Define length for array variable */
  #define	USER_LEN	50
  #define	PASS_LEN	50
  #define	IP_LEN		50
  #define       ID_LEN           7

  ///////////////// For connect to server ////////////////////
  /* Variable for register to server */
  int 	sockfd;
  int 	len;
  struct  sockaddr_in address;
  int 	result;
  char	receive_msg,send_msg;
  char	return_value;
  char	username[USER_LEN] = {""},password[PASS_LEN] = {""};
  char  user_id[ID_LEN] = {""}; // Save user id from vbox when online

  /* Variable for create socket to listen connection from server */
  int	 server_sockfd,client_sockfd;
  socklen_t	server_len,client_len;
  //int	return_value;
  struct   sockaddr_in	server_address;
  struct   sockaddr_in	client_address;
  //char	recieve_msg,send_msg;

/* Get user_id from vbox */
  strcpy(user_id,ID);
/* Register to Server by username and password */

    /* Create a socket for the client */
	sockfd = socket(AF_INET, SOCK_STREAM, 0);

    /* Define server address and port */
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = inet_addr("161.246.6.202");
	address.sin_port = 9734;
	len = sizeof(address);

    /* Now connect our socket to server's socket */
	result = connect(sockfd, (struct sockaddr *)&address, len);
	if(result == -1) {
		perror("connect");
		exit(1);
	}

    /* Connect complete and request to Login */
	send_msg = LOGIN;
	return_value = write(sockfd, &send_msg, 1);
	cout << "Send LOGIN msg number = " << send_msg
             << "send byte = " << return_value << endl;
	return_value = read(sockfd, &receive_msg, 1);
	if(receive_msg == REQ_USERNAME){ // Recieve message = REQ_USERNAME
	  cout << "Read REQ_USERNAME msg number = " << receive_msg
               << "read byte = " << return_value << endl;
          strcat(username,user_id);

    /* Send username to server for register */
		return_value = write(sockfd, username, USER_LEN);
		cout << "Send username = " << username << "send byte = " << return_value << endl;

    /* Recieve " REQ_PASSWORD " message from server */
		return_value = read(sockfd, &receive_msg, 1);
		if(receive_msg == REQ_PASSWORD){
			 cout << "Read REQ_PASSWORD msg number = " << receive_msg <<" read byte = " << return_value << endl;
    /* Ask password from user , if incorrect then return to ask until 3 time */
                         cout << "Enter password for this ID : ";
/* change */             cin >> password;
                         cout << endl;


    /* Send password to server for Register */
			return_value = write(sockfd, password, PASS_LEN);
			cout << "Send password = %s send byte = %d" << password << return_value << endl;

		}
		return_value = read(sockfd,&receive_msg,1);
		cout << "Read login status = %d, read byte = %d" << receive_msg << return_value << endl;
		if(receive_msg == LOGIN_SUCCESS)
		{
			cout << "Register to server successful" << endl;
			close(sockfd);
		}
		else if(receive_msg == LOGIN_FAIL){
			cout << "Error to register and Connection close" << endl;
			close(sockfd);
			exit(1);
		}
        }
/* Register to server completed */
    char ID_Destination[7];
    char IP_Destination[15];
    char *PID_Destination;
    int CheckBusy = TRUE;




  cout << " Waiting command from V-Box " << endl;

/************************* POP *************************/
/* Now open socket for listen connection fron server */

    /* Create socket for listen connection from LDAP server */
		printf("Create socket for listen connect from server\n");
		server_sockfd = socket(AF_INET, SOCK_STREAM, 0);

		server_address.sin_family = AF_INET;
		server_address.sin_addr.s_addr = htonl(INADDR_ANY);
		server_address.sin_port = 9740;
		server_len = sizeof(server_address);

                return_value = bind(server_sockfd,(struct sockaddr *)&server_address,server_len);
		if(return_value == -1)
		{
			close(server_sockfd);
			perror("bind");
			exit(1);
		}
    /* Create connection queue,Ignore child exit detail and wait for client */
		return_value = listen(server_sockfd,3);
		if(return_value == -1)
		{
			close(server_sockfd);
			perror("listen");
			//return(1);
		}

                return_value = fcntl(server_sockfd,F_SETFL,FNDELAY);
		printf("Set to non block mode = %d\n",return_value);

/* Complete to open socket for listen connection from server */
/************************* POP *************************/


  while (check == TRUE){

        res = read(fd,buf,20);
        //cout << " Waiting command from V-Box " << endl;
        Temp[0] = 0;
        buf[res] = 0;
        strcpy(Temp,buf);

        if (Temp[0]=='@'){
                switch (Temp[1]) {
                        case 'T' :
                                cout << "Already Set Busy." << endl;
                                CheckBusy = TRUE;
                                break;

                        case 'C' :

                                /* Create a socket for the client */
	                        sockfd = socket(AF_INET, SOCK_STREAM, 0);

                                /* Define server address and port */
	                        address.sin_family = AF_INET;
	                        address.sin_addr.s_addr = inet_addr("161.246.6.202");
	                        address.sin_port = 9734;
	                        len = sizeof(address);

                                /* Now connect our socket to server's socket */
	                        result = connect(sockfd, (struct sockaddr *)&address, len);
	                        if(result == -1) {
		                        perror("connect");
		                        exit(1);
	                        }

                                PTemp = &Temp[2];
                                PID_Destination = &ID_Destination[0];
                                strcpy(PID_Destination,PTemp);
                                cout << "now call number = " << ID_Destination << endl;
                        /* Send ID to Server */
                                send_msg = CALL;
                                return_value = write(sockfd,&send_msg,1); // Send call command to server
                                while (check == TRUE){
                                       return_value = read(sockfd,&receive_msg,1);  // wait for request call ID
                                       if(receive_msg == REQ_CALL_ID){
                                                return_value = write(sockfd,ID_Destination,7);
                                                cout << "Send ID to server" << endl;
                                                check = FALSE;
                                        }
                                }
                                check = TRUE;
                        /* Wait for status */
                                return_value = 0;

                                while (return_value <= 0){
                                       return_value = read(sockfd,&receive_msg,1);//***
                                       if (return_value > 0)
                                           cout << " Receive status "<< receive_msg << endl;
                                }

                                if(receive_msg == BUSY){
                                        cout << "Now another side Busy." << endl;
                                        for (int i =0;i < 150;i++) usleep(1000);
                                        res = write(fd,"@N",2);
                                        check = TRUE;
                                }else if(receive_msg == IDLE){
                                        send_msg = IDLE_ACK;
                                        printf("Now another side Idle. \n");
                                        return_value = write(sockfd,&send_msg,2); // Send idle acknowledgh
                                        return_value = 0;
                                        while (return_value <= 0){
                                               return_value = read(sockfd,buf,15);
                                               if (return_value > 0){
                                                       strcpy(IP_Destination,buf);
                                                       printf("Destination ID = %s\n",ID_Destination);
                                                       check = FALSE;
                                                }
                                        }
                                        for (int i =0;i < 150;i++) usleep(1000);
                                        res = write(fd,"@L",2);

                                                //copy to str for feed command of program
                                        if (!currentCallToken.IsEmpty())
                                                cout << "Cannot make call whilst call in progress\n";
                                        else {
                                                PString str;
                                                str = IP_Destination;
                                                StartCall(str.Trim());
                                                check = TRUE;

                                        }
                                }
                                break;

                        case 'H' :
                               cout << "Hanging Up." << endl;
                               if (!currentCallToken) {
                                        cout << "Hanging up call." << endl;
                                        if (!ClearCall(currentCallToken))
                                                cout << "Could not hang up current call!\n";
                                        speakerphoneSwitch = FALSE;
                                }
                                break;

                        case 'A' :
                                AnswerCall(H323Connection::AnswerCallNow);
                                break;

                        case 'I' :
                                AnswerCall(H323Connection::AnswerCallDenied);
                                break;

                }
        }
        buf[0] = 0;
/************************ POP **************************/
        server_len = sizeof(server_address);
	client_sockfd = accept(server_sockfd,(struct sockaddr*)&client_address,&client_len);

	if(client_sockfd > 0){
            /* Client is Idle, Set to Busy and then send IDLE msg */
        	send_msg = IDLE;
		return_value = write(client_sockfd,&send_msg,1);
		printf("Send Idle msg number = %d,send byte = %d\n",send_msg,return_value);
        	close(client_sockfd);
	} // End if(client_sockfd > 0)
  } // End while 2

}


void MyH323EndPoint::AnswerCall(H323Connection::AnswerCallResponse response)
{
  if (uiState != uiAnsweringCall)
    return;

  StopRinging();

  H323Connection * connection = FindConnectionWithLock(currentCallToken);
  if (connection == NULL)
    return;

  connection->AnsweringCall(response);
  connection->Unlock();

  if (response == H323Connection::AnswerCallNow) {
    cout << "Accepting call." << endl;
    uiState = uiCallInProgress;
  } else {
    cout << "Rejecting call." << endl;
    uiState = uiCallHungup;
  }
}


void MyH323EndPoint::HandleRinging()
{
  PSoundChannel dev(GetSoundChannelPlayDevice(), PSoundChannel::Player);
  if (!dev.IsOpen()) {
    PTRACE(2, "Cannot open sound device for ring");
    return;
  }

  if (ringDelay < 0) {
    PTRACE(2, "Playing " << ringFile);
    dev.PlayFile(ringFile, TRUE);
  } else {
    PTimeInterval delay(0, ringDelay);
    PTRACE(2, "Playing " << ringFile << " with repeat of " << delay << " ms");
    do {
      dev.PlayFile(ringFile, TRUE);
    } while (!ringFlag.Wait(delay));
  }
}


void MyH323EndPoint::StartRinging()
{
  PAssert(ringThread == NULL, "Ringing thread already present");

  if (!noAnswerForwardParty)
    noAnswerTimer = PTimeInterval(0, noAnswerTime);

  if (!ringFile)
    ringThread = new RingThread(*this);
}


void MyH323EndPoint::StopRinging()
{
  noAnswerTimer.Stop();

  if (ringThread == NULL)
    return;

  ringFlag.Signal();
  ringThread->WaitForTermination();
  delete ringThread;
  ringThread = NULL;
}
///////////////////////////////////////////////////////////////

BOOL CallOptions::Initialise(PArgList & args)
{
  // set default connection options
  noFastStart          = args.HasOption('f');
  noH245Tunnelling     = args.HasOption('T');
  noSilenceSuppression = args.HasOption('e');

  if (args.HasOption("connectring"))
    connectRing = args.HasOption("connectring");

  if (!args.GetOptionString("connectport").IsEmpty())
    connectPort = (WORD)args.GetOptionString("connectport").AsInteger();

  if (args.HasOption('j')) {
    int newjitter = args.GetOptionString('j').AsUnsigned();
    if (newjitter >= 20 && newjitter <= 10000)
      jitter = newjitter;
    else {
      cerr << "Jitter should be between 20 milliseconds and 10 seconds." << endl;
      return FALSE;
    }
  }

  return TRUE;
}

void CallOptions::PrintOn(ostream & strm) const
{
  strm << "FastStart is " << !noFastStart << "\n"
       << "H245Tunnelling is " << !noH245Tunnelling << "\n"
       << "SilenceSupression is " << !noSilenceSuppression << "\n"
       << "Jitter buffer: "  << jitter << " ms\n"
       << "Connect port: " << connectPort << "\n";
}

///////////////////////////////////////////////////////////////

MyH323Connection::MyH323Connection(MyH323EndPoint & ep,
                                   unsigned callReference,
                                   BOOL disableFastStart,
                                   BOOL disableTunneling,
                                   WORD jitter,
                                   int _verbose)
  : H323Connection(ep, callReference, disableFastStart, disableTunneling),
    myEndpoint(ep),
    verbose(_verbose)
{
  SetMaxAudioDelayJitter(jitter);
  channelsOpen = 0;
}


H323Connection::AnswerCallResponse
     MyH323Connection::OnAnswerCall(const PString & caller,
                                    const H323SignalPDU & /*setupPDU*/,
                                    H323SignalPDU & /*connectPDU*/)
{
  PTRACE(1, "H225\tOnWaitForAnswer");

  PTime now;

  if (myEndpoint.autoAnswer) {
    cout << "Automatically accepting call at " << now << endl;
    return AnswerCallNow;
  }

  myEndpoint.currentCallToken = GetCallToken();
  myEndpoint.uiState = MyH323EndPoint::uiAnsweringCall;

  ////////////////////Initial for Canonical Serial //////////////////////////////

#define BAUDRATE B9600
#define MODEMDEVICE "/dev/ttyS0"
#define _POSIX_SOURCE 1 /* POSIX compliant source */

#define FALSE 0
#define TRUE 1

//  volatile int STOP=FALSE;
  int fd,res;
  struct termios oldtio,newtio;

 fd = open(MODEMDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK); // NoN block;
 if (fd <0) {perror(MODEMDEVICE); exit(-1); }

 tcgetattr(fd,&oldtio); /* save current serial port settings */
 bzero(&newtio, sizeof(newtio)); /* clear struct for new port settings */

 newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
 newtio.c_iflag = IGNPAR | ICRNL;
 newtio.c_oflag = 0;
 newtio.c_lflag = ICANON;

 tcflush(fd, TCIFLUSH);
 tcsetattr(fd,TCSANOW,&newtio);

  ///////////////////* End  initial Canonical Serial */////////////////////////

 for (int i =0;i < 100;i++) usleep(100);
 res = write(fd,"@R",2);
 close(fd);

  cout << "Incoming call from \""
       << caller
       << "\" at "
       << now
       << ", answer call (Y/n)? "
       << flush;

  myEndpoint.StartRinging();

  return AnswerCallPending;
}


BOOL MyH323Connection::OnStartLogicalChannel(H323Channel & channel)
{
  if (!H323Connection::OnStartLogicalChannel(channel))
    return FALSE;

  if (verbose >= 2) {
    cout << "Started logical channel: ";

    switch (channel.GetDirection()) {
      case H323Channel::IsTransmitter :
        cout << "sending ";
        break;

      case H323Channel::IsReceiver :
        cout << "receiving ";
        break;

      default :
        break;
    }

    cout << channel.GetCapability() << endl;
  }

  // adjust the count of channels we have open
  channelsOpen++;

  // if we get to two channels (one open, one receive), then (perhaps) trigger a timeout for shutdown
  if (channelsOpen == 2)
    myEndpoint.TriggerDisconnect();

  return TRUE;
}

void MyH323Connection::OnClosedLogicalChannel(H323Channel & channel)
{
  channelsOpen--;
  H323Connection::OnClosedLogicalChannel(channel);
}

BOOL MyH323Connection::OnAlerting(const H323SignalPDU & /*alertingPDU*/,
                                  const PString & username)
{
  PAssert((myEndpoint.uiState == MyH323EndPoint::uiConnectingCall) ||
          (myEndpoint.uiState == MyH323EndPoint::uiWaitingForAnswer),
     psprintf("Alerting received in state %i whilst not waiting for incoming call!", myEndpoint.uiState));

  if (verbose > 0)
    cout << "Ringing phone for \"" << username << "\" ..." << endl;

  myEndpoint.uiState = MyH323EndPoint::uiWaitingForAnswer;

  return TRUE;
}


void MyH323Connection::OnUserInputString(const PString & value)
{
  cout << "User input received: \"" << value << '"' << endl;
}

PString MyH323Connection::GetCallerIdString() const
{
  H323TransportAddress addr = GetControlChannel().GetRemoteAddress();
  PIPSocket::Address ip;
  WORD port;
  addr.GetIpAndPort(ip, port);
  DWORD decimalIp = (ip[0] << 24) +
                    (ip[1] << 16) +
                    (ip[2] << 8) +
                     ip[3];
  PString remotePartyName = GetRemotePartyName();
  PINDEX bracket = remotePartyName.Find('[');
  if (bracket != P_MAX_INDEX)
    remotePartyName = remotePartyName.Left(bracket);
  bracket = remotePartyName.Find('(');
  if (bracket != P_MAX_INDEX)
    remotePartyName = remotePartyName.Left(bracket);
  return psprintf("%010li\t\t", decimalIp) + remotePartyName;
}

// End of File ///////////////////////////////////////////////////////////////
