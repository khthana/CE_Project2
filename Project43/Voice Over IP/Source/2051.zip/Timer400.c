#include<reg51.h>
#include<stdio.h>
sbit P10 = 0x90;
sbit P11 = 0x91;
sbit P37 = 0xb7;
sbit P17 = 0x97;
sbit P16 = 0x96;
sbit P15 = 0x95;
bit	n0;

unsigned char c0;
unsigned char c1;
void set_int(void);
void setTimer0(void);
void setTimer1(void);

void main(void)
{
	set_int();
	c0=0;
	c1=0;
	while(1) {
		if (P15==1) {
			EA=0;
		} else EA=1;
	}	
}

void set_int(void)
{
  IE = 0x8a; // EA,-,ET2,ES,ET1,EX1,ET0,EX0
  IE0=1;     // no autoreset counter 0
  IE1=1;     // no autoreset counter 1
  setTimer0();
  setTimer1();
  EA=1;
  TR0=1;     	// Start counter 0
  TR1=1;			// Start counter 1
}

void setTimer0(void)		// Set to 400 Hz
{
  TH0=0xdc;
  TL0=0xe8;
}

void setTimer1(void)   // 2 Hz
{
  TH1=0;
  TL1=0;
}

void Timer0(void) interrupt 1               // Call by Int timer0
{
   setTimer0();
   if (P37) P37=0;
	else P37=1;
	if (!n0) {
		if (P17) P17=0;
		else P17=1;
	}
	if (!c1) {
		if (P16) P16=0;
		else P16=1;
	}
}

void Timer1(void) interrupt 3               // Call by Int timer0
{
	setTimer1();
	if (c0>20) {	
		if (n0) {
			n0=0;
			if (c1>2) c1=0;
			else {P16=0;c1++;}
		}	else {P17=0;n0=1;}
		c0=0;
	} else c0++;	
}

void Int0(void) interrupt 0                // Call by Int 0
{

}
