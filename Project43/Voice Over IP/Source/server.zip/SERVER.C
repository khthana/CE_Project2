/*----------------------------*/
/* Define Library for program */
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "examples.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

/*---------------------------------------*/
/* Define Message number for my protocol */
#define LOGIN	1
#define CALL	2
#define REQ_USERNAME	3
#define REQ_PASSWORD	4
#define LOGIN_SUCCESS	5
#define LOGIN_FAIL	6
#define REQ_CALL_ID     7
#define IDLE            8
#define BUSY            9
#define IDLE_ACK        10
#define BUSY_ACK        11
#define RE_ACK          12
#define OFFLINE         13
#define OFFLINE_ACK     14

/*----------------------------------*/
/* Define Length for array variable */
#define USER_LEN        50
#define PASS_LEN        50
#define CALL_ID_LEN     50
#define FILTER_LEN      50

/*-----------------------------------------------------------*/
/* Variable for Server listen connection from various client */
int	server_sockfd, client_sockfd;
int	server_len, client_len;
int	return_value;
struct	sockaddr_in server_address;
struct	sockaddr_in client_address;
char 	*caller_client_ip;
char	called_client_ip[50];
char	recieve_msg,send_msg;
char	recieve_username[USER_LEN] = {""},recieve_password[PASS_LEN] = {""};
char	recieve_call_id[CALL_ID_LEN] = {""};
char	user_dn[USER_LEN] = {""};

/*-------------------------------------------------------------------------------------------*/
/* Variable for Server create connection to various client ( Ask for current client status ) */
int	sockfd;
int	len;
int	connect_result;
struct	sockaddr_in address;
//char  recieve_msg, send_msg;   This variable already declare
pid_t   pid;
char    flag;

/*------------------------------------------------*/
/* Procedure for Server check status ( Time out ) */
void alarm_do()
{
	if(flag == 'N')
	{
		printf("\n");
		printf("Connection time out , Client has't accept connection\n");
                close(sockfd);

/* After close connection to called_client_ip then Tell status " busy " to caller_client_ip */
                send_msg = BUSY;
                return_value = write(client_sockfd, &send_msg,1);
                printf("%s is busy , Send BUSY msg to %s\n",called_client_ip,caller_client_ip);
		close(client_sockfd);
		printf("Close connection\n");
                exit(0); //exit from fork process
	}
	else
	if(flag == 'C')
	{
		printf("\n");
		printf("Client has accept connection\n");
	}
}

/*--------------------*/
/* Begin Main program */

int main()
{

/* Variable for LDAP Operation */
	LDAP	*ld;
	LDAPMod	mod0,mod1,*mods[3];	// For modify (mod0 for user_ip, mod1 for 	random_number)
	LDAPMessage	*result,*e;
	BerElement	*ber;		// For search
	char	*a,*dn;			// For search
	char	**vals;			// For search
	char    filter[FILTER_LEN];	// Filter for search
	char    *attrs[10] = {"user_ip"};	// Attribute for search
	char    *vals0[2], *vals1[2];		// For modify 
	int	i;				// For search

/* ------------------------------------------------------- */
/* Create socket for listen connection from various client */

/*------------------------------------------------------------------*/
/* Define information for server at 192.168.1.99 , TCP/IP , AF_INET */
	server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	server_address.sin_family = AF_INET;
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
	server_address.sin_port = 9734;
	server_len = sizeof(server_address);

	return_value = bind(server_sockfd, (struct sockaddr *)&server_address,server_len);
	if(return_value == -1)
        {
		perror("bind");
                return(1);
	}
	return_value = listen(server_sockfd, 1);
	if(return_value == -1)
        {
		perror("listen");
                return(1);
	}

/* End of create socket for listen various client */
/*------------------------------------------------*/

	while(1)
	{
		printf("Server waiting connection from client \n");

/* Accept connection and if can't accept then " client_sockfd " < 0 and Client information    return to " client_addr " */

/* Accept set to block mode */
		client_len = sizeof(client_address);
		client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_address, 		&client_len);
		caller_client_ip = inet_ntoa(client_address.sin_addr);

/* Fork to create a process for this client */
/* the child ( fork() = 0 mean child , fork() < 0 maen "can not fork ) */
		if(fork() == 0)
		{
			printf("Oh !!! got connection from %s\n",caller_client_ip);

/* Read command from server ( LOGIN / CALL ) */
			return_value = read(client_sockfd, &recieve_msg, 1);
			printf("Read msg number = %d, read byte = %d\n", recieve_msg, 			return_value);

/* ----------------------------------- */
/* Check command from client ( LOGIN ) */
			if(recieve_msg == LOGIN)   // Recieve " LOGIN " command from client
			{
/* Send " REQ_USERNAME " message to client */
				send_msg = REQ_USERNAME;
				return_value = write(client_sockfd, &send_msg, 1);
				printf("Send REQ_USERNAME msg number = %d, send byte = %d\n", 				send_msg,return_value);
/* Recieve Username from client */
				i = 0;  // Clear data in array " recieve_call_id "
				while(i <= USER_LEN)
				{
					user_dn[i] = '\0';
					i++;
				}       // End clear data
				return_value = read(client_sockfd, recieve_username, USER_LEN);
				printf("Read username = %s, read byte = %d\n", 				recieve_username,return_value);
				strcpy(user_dn,"(cn=");
				strcat(user_dn,recieve_username);
				strcat(user_dn,",ou=People,o=airius.com");
/* Send " REQ_PASSWORD " message to client */
				send_msg = REQ_PASSWORD;
				return_value = write(client_sockfd, &send_msg, 1);
				printf("Send REQ_PASSWORD msg number = %d, send byte = %d\n", 				send_msg,return_value);
/* Recieve Password from client */
				return_value = read(client_sockfd, recieve_password, PASS_LEN);
				printf("Read password = %s read byte = %d\n", recieve_password, 				return_value);
/* End of check command LOGIN */
/* ---------------------------*/

/* Begin connect to LDAP server to Modify LDAP entry by " rootdn " at user directory */
/* --------------------------------------------------------------------------------- */
/* LDAP Init */
				if ( (ld = ldap_init( MY_HOST, MY_PORT )) == NULL )
				{
					perror( "ldap_init" );
					return( 1 );
				}
/* Authenticate to server as recieve_username and recieve_password */
	                	if ( ldap_simple_bind_s( ld, user_dn, recieve_password ) != 				LDAP_SUCCESS )
				{
					send_msg = LOGIN_FAIL;
	                        	return_value = write(client_sockfd, &send_msg, 1);
		                	printf("Error !!! send LOGIN_FAIL msg number = %d, send 					byte = 	%d\n", send_msg, return_value);
					return( 1 );
		        	}
				else
				{
					printf("Username and Password are correct, Begin 					to register\n");
					ldap_unbind(ld);
				}
/* Username and password are correct, Now use rootdn to modify entry */
				if ( (ld = ldap_init( MY_HOST, MY_PORT )) == NULL )
				{
					perror( "ldap_init" );
					return( 1 );
				}
				if ( ldap_simple_bind_s( ld, MGR_DN, MGR_PW ) != LDAP_SUCCESS )
				{
					ldap_perror( ld, "ldap_simple_bind_s" );
					return( 1 );
				}
/* construct the list of modifications to make */
				mod0.mod_op = LDAP_MOD_REPLACE;
				mod0.mod_type = "user_ip";
				vals0[0] = caller_client_ip;
				vals0[1] = NULL;
				mod0.mod_values = vals0;
				mods[ 0 ] = &mod0;
				mods[ 1 ] = NULL;
				mods[ 2 ] = NULL;
/* make the change and clean up after ourselves */
				if ( ldap_modify_s( ld, recieve_username, mods ) != 				LDAP_SUCCESS )
				{
					printf("Modify error\n");
					ldap_perror( ld, "ldap_modify_s" );
					return( 1 );
				}
				ldap_unbind( ld );
/* End of modify user entry */
/* ------------------------ */

				send_msg = LOGIN_SUCCESS;
				return_value = write(client_sockfd, &send_msg, 1);
				printf("SUCCESS !!! send LOGIN_SUCCESS msg number = %d, send 				byte = %d\n", send_msg, return_value);
/* Return " client_id " to client and Close client connection */
				printf("Register to LDAP server has completed and Now close 				connection\n\n");
				close(client_sockfd);
				exit(0);// exit from fork process
			}  // End if(recieve_msg == LOGIN)
			else

/* ---------------------------------- */
/* Check command from client ( CALL ) */
			if(recieve_msg == CALL)  // Recieve " CALL " command from client
			{
/* Send " REQ_CALL_NUM " message to client */
				send_msg = REQ_CALL_ID;
				return_value = write(client_sockfd, &send_msg, 1);
				printf("Send REQ_CALL_ID msg number = %d, send byte = %d\n", 				send_msg,return_value);
/* Recieve " call_number " from client */
				i = 0;  // Clear data in array " recieve_call_id "
				while(i <= USER_LEN)
				{
					recieve_call_id[i] = '\0';
					i++;
				}       // End clear data
				return_value = read(client_sockfd, &recieve_call_id, 				CALL_ID_LEN);
				printf("Read call_id = %s, read byte = %d\n", recieve_call_id, 				return_value);

/* Set filter for search operation "(uid=recieve_callid)" and attrbute for search operation set          by attrs[ATTR_LEN] = {"user_ip"} */
				strcpy(filter,"(uid=");
				strcat(filter,recieve_call_id);
				strcat(filter,")");

/* ----------------------------------------------------------- */
/* Begin connect to LDAP server to Search for called_client_ip */
/* LDAP Init */
				if ( (ld = ldap_init( MY_HOST, MY_PORT )) == NULL )
				{
					perror( "ldap_init" );
					return( 1 );
				}
/* authenticate to the directory as rootdn  */
				if ( ldap_simple_bind_s( ld, MGR_DN, MGR_PW ) != LDAP_SUCCESS )
				{
					ldap_perror( ld, "ldap_simple_bind_s" );
					ldap_unbind( ld );
					return( 1 );
				}
/* search for entries with filter "(cn= recieve_call_number)"  */
				if ( ldap_search_s( ld, MY_SEARCHBASE, LDAP_SCOPE_SUBTREE, 				filter,attrs, 0,&result ) != LDAP_SUCCESS )
				{
					ldap_perror( ld, "ldap_search_s" );
					if ( result == NULL )
					{
						ldap_unbind( ld );
						return( 1 );
					}
				}

/* for each entry print out name + all attrs and values */
				for ( e = ldap_first_entry( ld, result ); 
				e != NULL;e = ldap_next_entry( ld, e ) )
				{
					for ( a = ldap_first_attribute( ld, e, &ber );a != 					NULL; a = ldap_next_attribute( ld, e, ber ) )
					{
						if ((vals = ldap_get_values( ld, e, a)) 
						!= NULL )
                        			{
							for ( i = 0; vals[i] != NULL; i++ )
                                			{
								printf( "%s: %s\n", a, vals[i] 								);
                                        			strcpy(called_client_ip, 								vals[i]);
							}
							ldap_value_free( vals );
						}
						ldap_memfree( a );
					}
					if ( ber != NULL )
                			{
						ldap_free( ber, 0 );
					}
				}
        			ldap_msgfree( result );
				ldap_unbind( ld );
        			printf("%s call to %s\n\n", caller_client_ip, 				called_client_ip);

/* End check IP Address of called_client_ip operation */
/* -------------------------------------------------- */

/* ------------------------------------------------- */
/* Begin Connect to called_client_ip to check status */

/* Check status of refered client */
/* Connect to refered client (called_client_ip) at port number 9740 */
/* Create socket for connect in " sockfd " */
				printf("Create connection to %s to read current 				status\n",called_client_ip);
				sockfd = socket(AF_INET, SOCK_STREAM, 0);
/* Define ip address to connect */
				address.sin_family = AF_INET;
        			address.sin_addr.s_addr = inet_addr(called_client_ip);
        			address.sin_port  = 9740;
        			len = sizeof(address);
/* Now connect our socket */
				connect_result = connect(sockfd, (struct sockaddr *)&address, 				len);
				flag = 'N';
        			signal(SIGALRM, alarm_do);
        			alarm(10);
				if(connect_result == -1)
        			{
					perror("connect");
                			close(sockfd);
/* Tell " Busy" to caller */
					send_msg = OFFLINE;
					return_value = write(client_sockfd, &send_msg,1);
                			printf("%s is offline , Send OFFLINE msg to %s\n", 					called_client_ip,caller_client_ip);
					close(client_sockfd);
					printf("Close connection \n");
					exit(0); //exit from fork process
				}		
/* End Tell " Busy " to caller  and Exit forked process */

/* Client is online */
/* Now can send and recieve message */
				printf("Wait reply from client %s\n", called_client_ip);
        			return_value = read(sockfd, &recieve_msg, 1);
        			printf("Recieve reply from %s\n", called_client_ip);
        			printf("Message number = %d,read byte = 				%d\n",recieve_msg,return_value);
				flag = 'C';  

/* BUSY is handle by procedure Alarm_do() */
/* Client is IDLE */
				if(recieve_msg == IDLE)
        			{
/* Send IDLE_ACK to client */
					printf("Yes !!! client is idle and ready to talk with 					other\n");
					return_value = close(sockfd);
					printf("OK !!! Close connection to %s return = 					%d\n",called_client_ip,return_value);
/* Tell IDLE to caller */
// Tell status " idle " to caller_client_ip and send called_client_ip address to       caller_client_ip
					send_msg = IDLE;
        	        		return_value = write(client_sockfd,&send_msg,1);
                			printf("%s is idle , Send IDLE msg to %s\n", 					called_client_ip,caller_client_ip);
               				return_value = read(client_sockfd, &recieve_msg,1);
                			printf("Read IDLE_ACK from %s , connection close\n", 					caller_client_ip);
				        return_value = write(client_sockfd, 					called_client_ip,15);
       			        	printf("Send \" %s \" value to %s\n", called_client_ip, 					caller_client_ip);
					close(client_sockfd);
					printf("Close connection to %s\n", caller_client_ip);
               				exit(0); //exit from fork process
				}
/* End Tell IDLE to caller */

			}  // End if(recieve_msg == CALL)
/* End of check command CALL */
/* ------------------------- */
		}   // End of if(fork() == 0)
	       	printf("\n");
	}  // End While(1)

} // End of main


