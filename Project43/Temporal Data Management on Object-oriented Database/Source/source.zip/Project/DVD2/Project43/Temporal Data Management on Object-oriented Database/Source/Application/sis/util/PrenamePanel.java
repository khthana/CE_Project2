package sis.util;

/**
 * This type was created in VisualAge.
 */
public class PrenamePanel extends com.sun.java.swing.JPanel implements java.awt.event.ActionListener {
	private com.sun.java.swing.JRadioButton ivjMissJRadioButton = null;
	private com.sun.java.swing.JRadioButton ivjMrJRadioButton = null;
	private com.sun.java.swing.JRadioButton ivjMrsJRadioButton = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public PrenamePanel() {
	super();
	initialize();
}
/**
 * PrenamePanel constructor comment.
 * @param layout java.awt.LayoutManager
 */
public PrenamePanel(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * PrenamePanel constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public PrenamePanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * PrenamePanel constructor comment.
 * @param isDoubleBuffered boolean
 */
public PrenamePanel(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getMrJRadioButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getMissJRadioButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getMrsJRadioButton()) ) {
		connEtoC3(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void clear() {

	getMrJRadioButton().setSelected(false);
	getMissJRadioButton().setSelected(false);
	getMrsJRadioButton().setSelected(false);
	
}
/**
 * connEtoC1:  (MrJRadioButton.action.actionPerformed(java.awt.event.ActionEvent) --> PrenamePanel.manageChange(Lcom.sun.java.swing.JRadioButton;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.manageChange(getMrJRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (MissJRadioButton.action.actionPerformed(java.awt.event.ActionEvent) --> PrenamePanel.manageChange(Lcom.sun.java.swing.JRadioButton;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.manageChange(getMissJRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (MrsJRadioButton.action.actionPerformed(java.awt.event.ActionEvent) --> PrenamePanel.manageChange(Lcom.sun.java.swing.JRadioButton;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.manageChange(getMrsJRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the MissJRadioButton property value.
 * @return com.sun.java.swing.JRadioButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JRadioButton getMissJRadioButton() {
	if (ivjMissJRadioButton == null) {
		try {
			ivjMissJRadioButton = new com.sun.java.swing.JRadioButton();
			ivjMissJRadioButton.setName("MissJRadioButton");
			ivjMissJRadioButton.setText("Miss");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjMissJRadioButton;
}
/**
 * Return the MrJRadioButton property value.
 * @return com.sun.java.swing.JRadioButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JRadioButton getMrJRadioButton() {
	if (ivjMrJRadioButton == null) {
		try {
			ivjMrJRadioButton = new com.sun.java.swing.JRadioButton();
			ivjMrJRadioButton.setName("MrJRadioButton");
			ivjMrJRadioButton.setText("Mr");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjMrJRadioButton;
}
/**
 * Return the MrsJRadioButton property value.
 * @return com.sun.java.swing.JRadioButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JRadioButton getMrsJRadioButton() {
	if (ivjMrsJRadioButton == null) {
		try {
			ivjMrsJRadioButton = new com.sun.java.swing.JRadioButton();
			ivjMrsJRadioButton.setName("MrsJRadioButton");
			ivjMrsJRadioButton.setText("Mrs");
			ivjMrsJRadioButton.setActionCommand("Mrs");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjMrsJRadioButton;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getSelectedItem() {

	if ( getMrJRadioButton().isSelected() ){
		return new String ("Mr");
	} else if ( getMissJRadioButton().isSelected() ){
			return new String("Miss");
	} else if ( getMrsJRadioButton().isSelected() ){
			return new String("Mrs");
	}
	
	return null;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getMrJRadioButton().addActionListener(this);
	getMissJRadioButton().addActionListener(this);
	getMrsJRadioButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsMrJRadioButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsMissJRadioButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsMrsJRadioButton = new java.awt.GridBagConstraints();
	setName("PrenamePanel");
	setLayout(new java.awt.GridBagLayout());
	setSize(156, 36);

	constraintsMrJRadioButton.gridx = 0; constraintsMrJRadioButton.gridy = 0;
	constraintsMrJRadioButton.gridwidth = 1; constraintsMrJRadioButton.gridheight = 1;
	constraintsMrJRadioButton.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsMrJRadioButton.weightx = 0.0;
	constraintsMrJRadioButton.weighty = 0.0;
	add(getMrJRadioButton(), constraintsMrJRadioButton);

	constraintsMissJRadioButton.gridx = 1; constraintsMissJRadioButton.gridy = 0;
	constraintsMissJRadioButton.gridwidth = 1; constraintsMissJRadioButton.gridheight = 1;
	constraintsMissJRadioButton.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsMissJRadioButton.weightx = 0.0;
	constraintsMissJRadioButton.weighty = 0.0;
	add(getMissJRadioButton(), constraintsMissJRadioButton);

	constraintsMrsJRadioButton.gridx = 2; constraintsMrsJRadioButton.gridy = 0;
	constraintsMrsJRadioButton.gridwidth = 1; constraintsMrsJRadioButton.gridheight = 1;
	constraintsMrsJRadioButton.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsMrsJRadioButton.weightx = 0.0;
	constraintsMrsJRadioButton.weighty = 0.0;
	add(getMrsJRadioButton(), constraintsMrsJRadioButton);
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		PrenamePanel aPrenamePanel;
		aPrenamePanel = new PrenamePanel();
		frame.getContentPane().add("Center", aPrenamePanel);
		frame.setSize(aPrenamePanel.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @param select com.sun.java.swing.JRadioButton
 */
public void manageChange(com.sun.java.swing.JRadioButton select) {

	if ( select == getMrJRadioButton() ) {
		getMissJRadioButton().setSelected(false);
		getMrsJRadioButton().setSelected(false);
	} else if ( select == getMissJRadioButton() ){
				getMrJRadioButton().setSelected(false);
				getMrsJRadioButton().setSelected(false);
			} else if ( select == getMrsJRadioButton() ){
						getMrJRadioButton().setSelected(false);
						getMissJRadioButton().setSelected(false);
					}
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public void setSelectedItem(String selectValue) {

	clear();
	try{
		if ( selectValue.equals("Mr") )
			getMrJRadioButton().setSelected(true);
		else if ( selectValue.equals("Miss") )
			getMissJRadioButton().setSelected(true);
		else if ( selectValue.equals("Mrs") )
			getMrsJRadioButton().setSelected(true);

	} catch ( Exception e) {
		System.out.println("Error in setSelectedItem() from sis.util.PrenamePanel\n" + e.getMessage());
		e.printStackTrace();
	}
	
}
}