package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class DepartmentPage extends JPanel implements java.awt.event.ActionListener {
	private JComboBox ivjFacultyListComboBox = null;
	private JLabel ivjFacultyListLabel = null;
	private JLabel ivjIDLabel = null;
	private JTextField ivjIDTextField = null;
	private JPanel ivjInfoPanel = null;
	private JLabel ivjNameLabel = null;
	private JTextField ivjNameTextField = null;
	private DatePanel ivjValidTimeDatePanel = null;
	private JPanel ivjValidTimePanel = null;
	private JTextPane ivjValidTimeTextPane = null;
	private JButton ivjAddToolBarButton = null;
	private JButton ivjClearToolBarButton = null;
	private JButton ivjDeleteToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JButton ivjSaveToolBarButton = null;
	private JButton ivjFindButton = null;
	private JDialog ivjFindDialog = null;
	private JPanel ivjFindDialogContentPane = null;
	private FindPanel ivjFindPanel = null;
	private JButton ivjCancelDelButton = null;
	private JDialog ivjDeleteDialog = null;
	private JLabel ivjDeleteLabel = null;
	private JPanel ivjJPanel1 = null;
	private JPanel ivjJPanel2 = null;
	private JButton ivjOKDelButton = null;
	private JPanel ivjDeleteDialogContentPane = null;
	private JButton ivjExitToolBarButton = null;
	private JToolBar ivjToolBar = null;
	private JPanel ivjButtonFindPanel = null;
	private JButton ivjCancelFindButton = null;
	private Department foundDept = null;
	private JLabel ivjFacultyListLabel1 = null;
	private JComboBox ivjFindFacComboBox = null;
	private JPanel ivjFindFacultyPanel = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public DepartmentPage() {
	super();
	initialize();
}
/**
 * Department constructor comment.
 * @param layout java.awt.LayoutManager
 */
public DepartmentPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Department constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public DepartmentPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * Department constructor comment.
 * @param isDoubleBuffered boolean
 */
public DepartmentPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoM1(e);
	}
	if ((e.getSource() == getCancelDelButton()) ) {
		connEtoM3(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoM4(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoC5(e);
	}
	if ((e.getSource() == getDeleteToolBarButton()) ) {
		connEtoM5(e);
	}
	if ((e.getSource() == getFindButton()) ) {
		connEtoC4(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM7(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC6(e);
	}
	if ((e.getSource() == getFacultyListComboBox()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getFindFacComboBox()) ) {
		connEtoM8(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM9(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM6(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void add() throws Exception, java.rmi.RemoteException {
	try {

		//********************************************************
		// Method
		// 1. Check for valid form
		// 2. Get selected faculty in Faculty type for passing
		// 3. Use create_this method to create new Department
		// 4. Clear form
		//********************************************************

		//Check for valid form
		Message m = new Message();
		if (getIDTextField().getText().length() <= 0) {
			m.show("Department ID is empty.");
			return;
		}
		if (getNameTextField().getText().length() <= 0) {
			m.show("Department Name is empty.");
			return;
		}
		if (getFacultyListComboBox().getSelectedIndex() == 0) {
			m.show("Faculty is not selected.");
			return;
		}
		if (getValidTimeDatePanel().getDate() == null) {
			m.show("Valid Time Start is not selected.");
			return;
		}

		//Start Tx
		Factory.getAdminDB().startTransaction();

		//Argument for getCurrentID(),getCurrentName()
		Object arg[] = new Object[0];

		//get selected Faculty and cast it to DBObject Type
		DBObject selectedFac = (DBObject) Factory.getAllFacs().elementAt(getFacultyListComboBox().getSelectedIndex() - 1);

		//get seleted Faculty ID
		DBObject fac_ID = (DBObject) selectedFac.execMethod("getCurrentID", arg);
		String facID = (String) fac_ID.getProperty("ID");

		//get Faculty in Faculty Type (It will be use for parameter passing)
		Faculty fac = Faculty.findCurrentByID(Factory.getAdminDB(), facID);
		if ( fac == null ) {
			m.show("New Department can't be created. Fail to retrieve Faculty object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		//Create new department
		Department newDept = new Department(Factory.getAdminDB());
		java.sql.Date vts = new java.sql.Date(getValidTimeDatePanel().getDate().getTime());
		newDept.create_this(getIDTextField().getText(), getNameTextField().getText(), fac, vts);

		//End Tx
		Factory.getAdminDB().endTransaction();

		//Clear form
		getIDTextField().setText("");
		getNameTextField().setText("");
		getFacultyListComboBox().setSelectedIndex(0);
		getFacultyListComboBox().repaint();
		
	} catch (DatabaseException dbe) {
		System.out.println("Database Error in add() from sis.admin.DepartmentPage \n" + dbe.getMessage());
		dbe.printStackTrace();
	} catch (Exception e) {
		System.out.println("Error in add() from sis.admin.DepartmentPage \n" + e.getMessage());
		e.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
/**
 * This method was created in VisualAge.
 */
public void clear() {
	//Clear Form
	getIDTextField().setText("");
	getNameTextField().setText("");
	getValidTimeDatePanel().clear();

	getFacultyListComboBox().setSelectedIndex(0);
	getFacultyListComboBox().repaint();

	//Clear founDept
	foundDept = null;

	//Enable&Disable some toolbar buttons
	getAddToolBarButton().setEnabled(true);
	getFindToolBarButton().setEnabled(true);
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);

	
}
/**
 * connEtoC1:  (DefaultToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> Department.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DepartmentPage.add()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.add();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (DeleteToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DepartmentPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> DepartmentPage.find()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.find();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DepartmentPage.delete()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.delete();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC6:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DepartmentPage.update()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.update();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (FacultyListComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyListComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFacultyListComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (CancelDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (DeleteToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindPanel.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM7(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindPanel().clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (FindFacComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> FindFacComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM8(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindFacComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindFacComboBox.setSelectedIndex(I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM9(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindFacComboBox().setSelectedIndex(0);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 */
public void delete() throws Exception, java.rmi.RemoteException {

	try{

		Message m = new Message();
		java.sql.Date vte;
		//if there's no found Department then return
		if ( foundDept == null )  {
			m.show("Can't update. Department didn't found.");
			return;
		}

		//Check for VTE selection
		if ( getValidTimeDatePanel().getDate() == null ){
			m.show("Valid time for deleting is not selected.");
			return;
		} else vte = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	
		Factory.getAdminDB().startTransaction();
		foundDept.delete_this(vte);
		foundDept = null;
		//Factory.setAllDepts(null);
		Factory.getAdminDB().endTransaction();

		clear();
	
	} catch (DatabaseException dbe){
		System.out.println("Database Error in delete() from sis.admin.DepartmentPage\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	}
	
	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
/**
 * This method was created in VisualAge.
 */
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * This method was created in VisualAge.
 */
public void find() throws Exception, java.rmi.RemoteException {

	try{
		//Start Tx
		Factory.getAdminDB().startTransaction();

		Faculty 	fac;
		Department	_foundDept	=	null;
	 	Object 		arg[]		=	new Object[0];

		//Check Faculty in Find Diaglog is selected or not
	 	if ( getFindFacComboBox().getSelectedIndex() == 0 ){
			Message m = new Message();
			m.show("Faculty is not selected.");
			Factory.getAdminDB().endTransaction();
			return;
		} else { //Get seleted Faculty ID
				 DBObject selectedFac = (DBObject) Factory.getAllFacs().elementAt(
									getFindFacComboBox().getSelectedIndex() - 1 );

				 DBObject fac_ID	= (DBObject) selectedFac.execMethod("getCurrentID",arg);
				 fac = Faculty.findCurrentByID( Factory.getAdminDB(), fac_ID.getProperty("ID").toString() );
			   }

		//Find		 
		if ( getFindPanel().getFindType().equals("ID") ){
		
			_foundDept = Department.findCurrentByID( Factory.getAdminDB(),
										            getFindPanel().getText(),
										            fac);
										   
		} else if ( getFindPanel().getFindType().equals("Name") ){
			_foundDept = Department.findCurrentByName( Factory.getAdminDB(),
										              getFindPanel().getText(),
										              fac);
		}
		
		//Check result
		//if department didn't found then show message and return
		if ( _foundDept == null ) {
			Message m = new Message();
			m.show("Deparment not found.");
			Factory.getAdminDB().endTransaction();
			return; }

		foundDept = _foundDept;
		//Show found Department
		getIDTextField().setText( foundDept.getCurrentID().toDBObject().getProperty("ID").toString() );
		getNameTextField().setText( foundDept.getCurrentName().toDBObject().getProperty("eName").toString() );
		getFacultyListComboBox().setSelectedIndex( getFindFacComboBox().getSelectedIndex() );
		getFacultyListComboBox().repaint();
		
		
		getFindFacComboBox().setSelectedIndex(0);
		getFindFacComboBox().repaint();
		getValidTimeDatePanel().clear();
		getFindPanel().clear();
		getFindDialog().dispose();

		//Enable & disable some toolbar bottons
		getAddToolBarButton().setEnabled(false);
		getDeleteToolBarButton().setEnabled(true);
		getSaveToolBarButton().setEnabled(true);
		
		//End Tx
		Factory.getAdminDB().endTransaction();
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in find() from sis.admin.DepartmentPage  :  " + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in find() from sis.admin.DepartmentPage  :  " + e.getMessage() );
		e.printStackTrace();
	}
	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();

}
/**
 * Return the JToolBarButton2 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getAddToolBarButton() {
	if (ivjAddToolBarButton == null) {
		try {
			ivjAddToolBarButton = new com.sun.java.swing.JButton();
			ivjAddToolBarButton.setName("AddToolBarButton");
			ivjAddToolBarButton.setToolTipText("Add new department");
			ivjAddToolBarButton.setText("");
			ivjAddToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjAddToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjAddToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\inserticon.gif"));
			ivjAddToolBarButton.setPreferredSize(new java.awt.Dimension(22, 23));
			ivjAddToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddToolBarButton;
}
/**
 * Return the ButtonFindPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getButtonFindPanel() {
	java.awt.GridBagConstraints constraintsFindButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelFindButton = new java.awt.GridBagConstraints();
	if (ivjButtonFindPanel == null) {
		try {
			ivjButtonFindPanel = new com.sun.java.swing.JPanel();
			ivjButtonFindPanel.setName("ButtonFindPanel");
			ivjButtonFindPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFindButton.gridx = 0; constraintsFindButton.gridy = 0;
			constraintsFindButton.gridwidth = 1; constraintsFindButton.gridheight = 1;
			constraintsFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindButton.weightx = 0.0;
			constraintsFindButton.weighty = 0.0;
			constraintsFindButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getButtonFindPanel().add(getFindButton(), constraintsFindButton);

			constraintsCancelFindButton.gridx = -1; constraintsCancelFindButton.gridy = -1;
			constraintsCancelFindButton.gridwidth = 1; constraintsCancelFindButton.gridheight = 1;
			constraintsCancelFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelFindButton.weightx = 0.0;
			constraintsCancelFindButton.weighty = 0.0;
			getButtonFindPanel().add(getCancelFindButton(), constraintsCancelFindButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonFindPanel;
}
/**
 * Return the CancelDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelDelButton() {
	if (ivjCancelDelButton == null) {
		try {
			ivjCancelDelButton = new com.sun.java.swing.JButton();
			ivjCancelDelButton.setName("CancelDelButton");
			ivjCancelDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelDelButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelDelButton;
}
/**
 * Return the CancelFindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelFindButton() {
	if (ivjCancelFindButton == null) {
		try {
			ivjCancelFindButton = new com.sun.java.swing.JButton();
			ivjCancelFindButton.setName("CancelFindButton");
			ivjCancelFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelFindButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelFindButton;
}
/**
 * Return the DefaultToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the DeleteDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getDeleteDialog() {
	if (ivjDeleteDialog == null) {
		try {
			ivjDeleteDialog = new com.sun.java.swing.JDialog();
			ivjDeleteDialog.setName("DeleteDialog");
			ivjDeleteDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjDeleteDialog.setResizable(false);
			ivjDeleteDialog.setBounds(565, 350, 300, 120);
			ivjDeleteDialog.setModal(true);
			ivjDeleteDialog.setTitle("Delete Department");
			getDeleteDialog().setContentPane(getDeleteDialogContentPane());
			// user code begin {1}
			ivjDeleteDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjDeleteDialog.getBounds();
			ivjDeleteDialog.setBounds ( (screen.width - s.width)/2,
									    (screen.height - s.height)/2,
									  	s.width,
									  	s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialog;
}
/**
 * Return the FindDialogContentPane1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getDeleteDialogContentPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	if (ivjDeleteDialogContentPane == null) {
		try {
			ivjDeleteDialogContentPane = new com.sun.java.swing.JPanel();
			ivjDeleteDialogContentPane.setName("DeleteDialogContentPane");
			ivjDeleteDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjDeleteDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 0;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			getDeleteDialogContentPane().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel2.gridx = 0; constraintsJPanel2.gridy = 1;
			constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
			constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel2.weightx = 0.0;
			constraintsJPanel2.weighty = 0.0;
			constraintsJPanel2.insets = new java.awt.Insets(10, 0, 10, 0);
			getDeleteDialogContentPane().add(getJPanel2(), constraintsJPanel2);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialogContentPane;
}
/**
 * Return the DeleteLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeleteLabel() {
	if (ivjDeleteLabel == null) {
		try {
			ivjDeleteLabel = new com.sun.java.swing.JLabel();
			ivjDeleteLabel.setName("DeleteLabel");
			ivjDeleteLabel.setText("Are you sure to delete this object?");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteLabel;
}
/**
 * Return the DeleteToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getDeleteToolBarButton() {
	if (ivjDeleteToolBarButton == null) {
		try {
			ivjDeleteToolBarButton = new com.sun.java.swing.JButton();
			ivjDeleteToolBarButton.setName("DeleteToolBarButton");
			ivjDeleteToolBarButton.setToolTipText("Delete this department");
			ivjDeleteToolBarButton.setText("");
			ivjDeleteToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDeleteToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDeleteToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\deleteicon.gif"));
			ivjDeleteToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteToolBarButton;
}
/**
 * Return the JToolBarButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the JComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getFacultyListComboBox() {
	if (ivjFacultyListComboBox == null) {
		try {
			ivjFacultyListComboBox = new com.sun.java.swing.JComboBox();
			ivjFacultyListComboBox.setName("FacultyListComboBox");
			ivjFacultyListComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjFacultyListComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacultyListComboBox;
}
/**
 * Return the JLabel2 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getFacultyListLabel() {
	if (ivjFacultyListLabel == null) {
		try {
			ivjFacultyListLabel = new com.sun.java.swing.JLabel();
			ivjFacultyListLabel.setName("FacultyListLabel");
			ivjFacultyListLabel.setText("Faculty");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacultyListLabel;
}
/**
 * Return the FacultyListLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getFacultyListLabel1() {
	if (ivjFacultyListLabel1 == null) {
		try {
			ivjFacultyListLabel1 = new com.sun.java.swing.JLabel();
			ivjFacultyListLabel1.setName("FacultyListLabel1");
			ivjFacultyListLabel1.setText("Faculty");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacultyListLabel1;
}
/**
 * Return the JButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindButton() {
	if (ivjFindButton == null) {
		try {
			ivjFindButton = new com.sun.java.swing.JButton();
			ivjFindButton.setName("FindButton");
			ivjFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjFindButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindButton;
}
/**
 * Return the JDialog1 property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getFindDialog() {
	if (ivjFindDialog == null) {
		try {
			ivjFindDialog = new com.sun.java.swing.JDialog();
			ivjFindDialog.setName("FindDialog");
			ivjFindDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjFindDialog.setResizable(false);
			ivjFindDialog.setBounds(561, 86, 340, 180);
			ivjFindDialog.setModal(true);
			ivjFindDialog.setTitle("Find Department");
			getFindDialog().setContentPane(getFindDialogContentPane());
			// user code begin {1}
			ivjFindDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjFindDialog.getBounds();
			ivjFindDialog.setBounds ( (screen.width - s.width)/2,
									  (screen.height - s.height)/2,
									  s.width,
									  s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialog;
}
/**
 * Return the JDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindDialogContentPane() {
	java.awt.GridBagConstraints constraintsFindPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFindFacultyPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsButtonFindPanel = new java.awt.GridBagConstraints();
	if (ivjFindDialogContentPane == null) {
		try {
			ivjFindDialogContentPane = new com.sun.java.swing.JPanel();
			ivjFindDialogContentPane.setName("FindDialogContentPane");
			ivjFindDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjFindDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsFindPanel.gridx = 0; constraintsFindPanel.gridy = 0;
			constraintsFindPanel.gridwidth = 1; constraintsFindPanel.gridheight = 1;
			constraintsFindPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindPanel.weightx = 1.0;
			constraintsFindPanel.weighty = 0.0;
			constraintsFindPanel.insets = new java.awt.Insets(0, 0, 5, 0);
			getFindDialogContentPane().add(getFindPanel(), constraintsFindPanel);

			constraintsFindFacultyPanel.gridx = 0; constraintsFindFacultyPanel.gridy = 1;
			constraintsFindFacultyPanel.gridwidth = 1; constraintsFindFacultyPanel.gridheight = 1;
			constraintsFindFacultyPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindFacultyPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindFacultyPanel.weightx = 0.0;
			constraintsFindFacultyPanel.weighty = 0.0;
			getFindDialogContentPane().add(getFindFacultyPanel(), constraintsFindFacultyPanel);

			constraintsButtonFindPanel.gridx = 0; constraintsButtonFindPanel.gridy = 2;
			constraintsButtonFindPanel.gridwidth = 1; constraintsButtonFindPanel.gridheight = 1;
			constraintsButtonFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsButtonFindPanel.weightx = 0.0;
			constraintsButtonFindPanel.weighty = 0.0;
			constraintsButtonFindPanel.insets = new java.awt.Insets(10, 0, 10, 0);
			getFindDialogContentPane().add(getButtonFindPanel(), constraintsButtonFindPanel);
			// user code begin {1}
			Factory.addFacultyToBox( getFindFacComboBox() );
			getFindFacComboBox().setSelectedIndex(0);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialogContentPane;
}
/**
 * Return the FindFacComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getFindFacComboBox() {
	if (ivjFindFacComboBox == null) {
		try {
			ivjFindFacComboBox = new com.sun.java.swing.JComboBox();
			ivjFindFacComboBox.setName("FindFacComboBox");
			ivjFindFacComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjFindFacComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindFacComboBox;
}
/**
 * Return the FindFacultyPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindFacultyPanel() {
	java.awt.GridBagConstraints constraintsFacultyListLabel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFindFacComboBox = new java.awt.GridBagConstraints();
	if (ivjFindFacultyPanel == null) {
		try {
			ivjFindFacultyPanel = new com.sun.java.swing.JPanel();
			ivjFindFacultyPanel.setName("FindFacultyPanel");
			ivjFindFacultyPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFacultyListLabel1.gridx = 0; constraintsFacultyListLabel1.gridy = 0;
			constraintsFacultyListLabel1.gridwidth = 1; constraintsFacultyListLabel1.gridheight = 1;
			constraintsFacultyListLabel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFacultyListLabel1.weightx = 0.0;
			constraintsFacultyListLabel1.weighty = 0.0;
			constraintsFacultyListLabel1.insets = new java.awt.Insets(5, 5, 5, 5);
			getFindFacultyPanel().add(getFacultyListLabel1(), constraintsFacultyListLabel1);

			constraintsFindFacComboBox.gridx = 1; constraintsFindFacComboBox.gridy = 0;
			constraintsFindFacComboBox.gridwidth = 1; constraintsFindFacComboBox.gridheight = 1;
			constraintsFindFacComboBox.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindFacComboBox.weightx = 0.0;
			constraintsFindFacComboBox.weighty = 0.0;
			constraintsFindFacComboBox.insets = new java.awt.Insets(5, 0, 5, 5);
			getFindFacultyPanel().add(getFindFacComboBox(), constraintsFindFacComboBox);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindFacultyPanel;
}
/**
 * Return the FindPanel property value.
 * @return sis.util.FindPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private FindPanel getFindPanel() {
	if (ivjFindPanel == null) {
		try {
			ivjFindPanel = new sis.util.FindPanel();
			ivjFindPanel.setName("FindPanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindPanel;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("Find department");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the JLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getIDLabel() {
	if (ivjIDLabel == null) {
		try {
			ivjIDLabel = new com.sun.java.swing.JLabel();
			ivjIDLabel.setName("IDLabel");
			ivjIDLabel.setText("Department ID");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDLabel;
}
/**
 * Return the JTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getInfoPanel() {
	java.awt.GridBagConstraints constraintsIDLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacultyListLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacultyListComboBox = new java.awt.GridBagConstraints();
	if (ivjInfoPanel == null) {
		try {
			ivjInfoPanel = new com.sun.java.swing.JPanel();
			ivjInfoPanel.setName("InfoPanel");
			ivjInfoPanel.setLayout(new java.awt.GridBagLayout());

			constraintsIDLabel.gridx = 0; constraintsIDLabel.gridy = 0;
			constraintsIDLabel.gridwidth = 1; constraintsIDLabel.gridheight = 1;
			constraintsIDLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsIDLabel.weightx = 0.0;
			constraintsIDLabel.weighty = 0.0;
			constraintsIDLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getIDLabel(), constraintsIDLabel);

			constraintsNameLabel.gridx = 0; constraintsNameLabel.gridy = 1;
			constraintsNameLabel.gridwidth = 1; constraintsNameLabel.gridheight = 1;
			constraintsNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsNameLabel.weightx = 0.0;
			constraintsNameLabel.weighty = 0.0;
			constraintsNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getNameLabel(), constraintsNameLabel);

			constraintsFacultyListLabel.gridx = 0; constraintsFacultyListLabel.gridy = 2;
			constraintsFacultyListLabel.gridwidth = 1; constraintsFacultyListLabel.gridheight = 1;
			constraintsFacultyListLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsFacultyListLabel.weightx = 0.0;
			constraintsFacultyListLabel.weighty = 0.0;
			constraintsFacultyListLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getFacultyListLabel(), constraintsFacultyListLabel);

			constraintsIDTextField.gridx = 1; constraintsIDTextField.gridy = 0;
			constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
			constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsIDTextField.weightx = 0.0;
			constraintsIDTextField.weighty = 0.0;
			constraintsIDTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getIDTextField(), constraintsIDTextField);

			constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 1;
			constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
			constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsNameTextField.weightx = 0.0;
			constraintsNameTextField.weighty = 0.0;
			constraintsNameTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getNameTextField(), constraintsNameTextField);

			constraintsFacultyListComboBox.gridx = 1; constraintsFacultyListComboBox.gridy = 2;
			constraintsFacultyListComboBox.gridwidth = 1; constraintsFacultyListComboBox.gridheight = 1;
			constraintsFacultyListComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsFacultyListComboBox.weightx = 0.0;
			constraintsFacultyListComboBox.weighty = 0.0;
			constraintsFacultyListComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getFacultyListComboBox(), constraintsFacultyListComboBox);
			// user code begin {1}
			
			TitledBorder title = new TitledBorder("Department Information");
			ivjInfoPanel.setBorder(title);

			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInfoPanel;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsDeleteLabel = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsDeleteLabel.gridx = 0; constraintsDeleteLabel.gridy = 0;
			constraintsDeleteLabel.gridwidth = 1; constraintsDeleteLabel.gridheight = 1;
			constraintsDeleteLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDeleteLabel.weightx = 0.0;
			constraintsDeleteLabel.weighty = 0.0;
			getJPanel1().add(getDeleteLabel(), constraintsDeleteLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsOKDelButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelDelButton = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsOKDelButton.gridx = 0; constraintsOKDelButton.gridy = 0;
			constraintsOKDelButton.gridwidth = 1; constraintsOKDelButton.gridheight = 1;
			constraintsOKDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKDelButton.weightx = 0.0;
			constraintsOKDelButton.weighty = 0.0;
			constraintsOKDelButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel2().add(getOKDelButton(), constraintsOKDelButton);

			constraintsCancelDelButton.gridx = -1; constraintsCancelDelButton.gridy = -1;
			constraintsCancelDelButton.gridwidth = 1; constraintsCancelDelButton.gridheight = 1;
			constraintsCancelDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelDelButton.weightx = 0.0;
			constraintsCancelDelButton.weighty = 0.0;
			getJPanel2().add(getCancelDelButton(), constraintsCancelDelButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the JLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getNameLabel() {
	if (ivjNameLabel == null) {
		try {
			ivjNameLabel = new com.sun.java.swing.JLabel();
			ivjNameLabel.setName("NameLabel");
			ivjNameLabel.setText("Department Name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameLabel;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(200, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * Return the OKDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKDelButton() {
	if (ivjOKDelButton == null) {
		try {
			ivjOKDelButton = new com.sun.java.swing.JButton();
			ivjOKDelButton.setName("OKDelButton");
			ivjOKDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKDelButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKDelButton;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Save change");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the JToolBar1 property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getToolBar() {
	if (ivjToolBar == null) {
		try {
			ivjToolBar = new com.sun.java.swing.JToolBar();
			ivjToolBar.setName("ToolBar");
			ivjToolBar.add(getClearToolBarButton());
			ivjToolBar.addSeparator();
			getToolBar().add(getAddToolBarButton(), getAddToolBarButton().getName());
			getToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			getToolBar().add(getDeleteToolBarButton(), getDeleteToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjToolBar;
}
/**
 * Return the DatePanel1 property value.
 * @return sis.util.DatePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DatePanel getValidTimeDatePanel() {
	if (ivjValidTimeDatePanel == null) {
		try {
			ivjValidTimeDatePanel = new sis.util.DatePanel();
			ivjValidTimeDatePanel.setName("ValidTimeDatePanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeDatePanel;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getValidTimePanel() {
	java.awt.GridBagConstraints constraintsValidTimeTextPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsValidTimeDatePanel = new java.awt.GridBagConstraints();
	if (ivjValidTimePanel == null) {
		try {
			ivjValidTimePanel = new com.sun.java.swing.JPanel();
			ivjValidTimePanel.setName("ValidTimePanel");
			ivjValidTimePanel.setLayout(new java.awt.GridBagLayout());

			constraintsValidTimeTextPane.gridx = 1; constraintsValidTimeTextPane.gridy = 1;
			constraintsValidTimeTextPane.gridwidth = 1; constraintsValidTimeTextPane.gridheight = 1;
			constraintsValidTimeTextPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsValidTimeTextPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeTextPane.weightx = 1.0;
			constraintsValidTimeTextPane.weighty = 1.0;
			getValidTimePanel().add(getValidTimeTextPane(), constraintsValidTimeTextPane);

			constraintsValidTimeDatePanel.gridx = 1; constraintsValidTimeDatePanel.gridy = 2;
			constraintsValidTimeDatePanel.gridwidth = 1; constraintsValidTimeDatePanel.gridheight = 1;
			constraintsValidTimeDatePanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeDatePanel.weightx = 0.0;
			constraintsValidTimeDatePanel.weighty = 0.0;
			getValidTimePanel().add(getValidTimeDatePanel(), constraintsValidTimeDatePanel);
			// user code begin {1}

			TitledBorder title = new TitledBorder("Valid Time");
			ivjValidTimePanel.setBorder(title);

			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimePanel;
}
/**
 * Return the JTextPane1 property value.
 * @return com.sun.java.swing.JTextPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextPane getValidTimeTextPane() {
	if (ivjValidTimeTextPane == null) {
		try {
			ivjValidTimeTextPane = new com.sun.java.swing.JTextPane();
			ivjValidTimeTextPane.setName("ValidTimeTextPane");
			ivjValidTimeTextPane.setPreferredSize(new java.awt.Dimension(30, 60));
			ivjValidTimeTextPane.setText("This time is used for,\n \t- insert, valid time start of this object\n\t- delete, valid time end of this object\n\t- update, valid time end of old property and valid time start for new property\n\t\t     valid time start of new property");
			ivjValidTimeTextPane.setBackground(new java.awt.Color(204,204,204));
			ivjValidTimeTextPane.setEditable(false);
			// user code begin {1}
			Border empty;
			empty = BorderFactory.createEmptyBorder(0,10,10,10);
			ivjValidTimeTextPane.setBorder(empty);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeTextPane;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getAddToolBarButton().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
	getFindToolBarButton().addActionListener(this);
	getCancelDelButton().addActionListener(this);
	getOKDelButton().addActionListener(this);
	getDeleteToolBarButton().addActionListener(this);
	getFindButton().addActionListener(this);
	getCancelFindButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
	getFacultyListComboBox().addActionListener(this);
	getFindFacComboBox().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Department");
	setLayout(new java.awt.BorderLayout());
	setSize(414, 359);
	add(getToolBar(), "North");
	add(getInfoPanel(), "Center");
	add(getValidTimePanel(), "South");
	initConnections();
	// user code begin {2}

	//Add current faculty to Combobox
	Factory.addFacultyToBox( getFacultyListComboBox() );

	//Disable some toolbar buttons
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
	
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		JFrame frame = new com.sun.java.swing.JFrame();
		DepartmentPage aDepartmentPage;
		aDepartmentPage = new DepartmentPage();
		frame.getContentPane().add("Center", aDepartmentPage);
		frame.setSize(aDepartmentPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 */
public void update() throws Exception, java.rmi.RemoteException{

	Message m = new Message();
	//if there's no found Department then return
	if ( foundDept == null )  {
		m.show("Can't update. Department didn't found.");
		return;
	}

	//Check seleted Faculty
	if ( getFacultyListComboBox().getSelectedIndex() == 0 ){
		m.show("Faculty isn't seleted.");
		return;
	}
	
	//Check for valid time selection
	if ( getValidTimeDatePanel().getDate() == null ) {
		m.show("Valid time isn't selected.");
		return;
	}

	//Valid Time,use for passing
	java.sql.Date valid = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	
	//Set if there's update
	boolean update = false;
	
	try{
		//Strat Tx
		Factory.getAdminDB().startTransaction();

		if ( !getIDTextField().getText().equals( foundDept.getCurrentID().getId() ) ){
			  foundDept.update_ID( foundDept.getCurrentID().getId(),
								 getIDTextField().getText(),
								 valid,
								 valid);
			update = true;
			System.out.println("Department ID has been updated.");
		}

		if ( !getNameTextField().getText().equals( foundDept.getCurrentName().getEname() ) ){
			 foundDept.update_eName( foundDept.getCurrentName().getEname(),
									getNameTextField().getText(),
									valid,
								 	valid);
			update = true;
			System.out.println("Department Name has been updated.");
		}

		
		//Get Faculty ID from form
		Object arg[]		   = new Object[0];
		DBObject currentFac    = (DBObject) Factory.getAllFacs().elementAt( 
										getFacultyListComboBox().getSelectedIndex() - 1 );
		DBObject currentFac_ID = (DBObject) currentFac.execMethod("getCurrentID",arg);
		String   currentFacID  = currentFac_ID.getProperty("ID").toString();

		//Get Faculty ID from foundDept
		String   foundFacID  = foundDept.getCurrentFac().getFac().getCurrentID().getId();
	
		if ( !currentFacID.equals( foundFacID ) ){
			  
			  Faculty newFac = Faculty.findCurrentByID( Factory.getAdminDB(),
				  										currentFacID );
			
			  foundDept.update_Fac( foundDept.getCurrentFac().getFac(), 
			  						  newFac, 
			  						  valid, 
			  						  valid);
			  update = true;
			  System.out.println("Department Fac has been updated.");
		}
		
		//refresh foundDept
		if ( update ){

			int selectedIndex = getFacultyListComboBox().getSelectedIndex();
			Faculty fac;
	 	 	fac = Faculty.findCurrentByID( Factory.getAdminDB(), 
										   currentFacID );
			//Find		 

			foundDept = null;
			foundDept = Department.findCurrentByID( Factory.getAdminDB(),
										            getIDTextField().getText(),
										            fac);

			if ( foundDept == null ){
				m.show("Cannot display updated information");
				clear();
			} else {	//Show
						getIDTextField().setText( foundDept.getCurrentID().getId() );
						getNameTextField().setText( foundDept.getCurrentName().getEname() );
						getFacultyListComboBox().setSelectedIndex( selectedIndex );
						getFacultyListComboBox().repaint();

						getValidTimeDatePanel().clear();
			}
			
			m.show("Department has been updated.");
		} else m.show("Department Information hasn't been changed.");
		
		//End Tx
		Factory.getAdminDB().endTransaction();
	  
	} catch (DatabaseException dbe){
		System.out.println("Database Error in update() from sis.admin.DepartmentPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
}