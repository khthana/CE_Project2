package sis.util;

import com.sun.java.swing.border.Border;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
/**
 * This type was created in VisualAge.
 */
public class Message extends JDialog implements java.awt.event.ActionListener {
	private JPanel ivjJDialogContentPane = null;
	private JPanel ivjJPanel1 = null;
	private JPanel ivjJPanel2 = null;
	private JButton ivjOKButton = null;
	private JLabel ivjMessage = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Message() {
	super();
	initialize();
}
/**
 * Message constructor comment.
 * @param owner java.awt.Frame
 */
public Message(java.awt.Frame owner) {
	super(owner);
}
/**
 * Message constructor comment.
 * @param owner java.awt.Frame
 * @param title java.lang.String
 */
public Message(java.awt.Frame owner, String title) {
	super(owner, title);
}
/**
 * Message constructor comment.
 * @param owner java.awt.Frame
 * @param title java.lang.String
 * @param modal boolean
 */
public Message(java.awt.Frame owner, String title, boolean modal) {
	super(owner, title, modal);
}
/**
 * Message constructor comment.
 * @param owner java.awt.Frame
 * @param modal boolean
 */
public Message(java.awt.Frame owner, boolean modal) {
	super(owner, modal);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getOKButton()) ) {
		connEtoM1(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoM1:  (OKButton.action.actionPerformed(java.awt.event.ActionEvent) --> Message.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJDialogContentPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	if (ivjJDialogContentPane == null) {
		try {
			ivjJDialogContentPane = new com.sun.java.swing.JPanel();
			ivjJDialogContentPane.setName("JDialogContentPane");
			ivjJDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 1; constraintsJPanel1.gridy = 1;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			getJDialogContentPane().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel2.gridx = 1; constraintsJPanel2.gridy = 2;
			constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
			constraintsJPanel2.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel2.weightx = 0.0;
			constraintsJPanel2.weighty = 0.0;
			constraintsJPanel2.insets = new java.awt.Insets(10, 0, 10, 0);
			getJDialogContentPane().add(getJPanel2(), constraintsJPanel2);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJDialogContentPane;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsMessage = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsMessage.gridx = 1; constraintsMessage.gridy = 1;
			constraintsMessage.gridwidth = 1; constraintsMessage.gridheight = 1;
			constraintsMessage.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsMessage.weightx = 0.0;
			constraintsMessage.weighty = 0.0;
			constraintsMessage.insets = new java.awt.Insets(10, 20, 10, 20);
			getJPanel1().add(getMessage(), constraintsMessage);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsOKButton = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsOKButton.gridx = 1; constraintsOKButton.gridy = 1;
			constraintsOKButton.gridwidth = 1; constraintsOKButton.gridheight = 1;
			constraintsOKButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKButton.weightx = 0.0;
			constraintsOKButton.weighty = 0.0;
			getJPanel2().add(getOKButton(), constraintsOKButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the Message property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getMessage() {
	if (ivjMessage == null) {
		try {
			ivjMessage = new com.sun.java.swing.JLabel();
			ivjMessage.setName("Message");
			ivjMessage.setText("JLabel1");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjMessage;
}
/**
 * Return the OKButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKButton() {
	if (ivjOKButton == null) {
		try {
			ivjOKButton = new com.sun.java.swing.JButton();
			ivjOKButton.setName("OKButton");
			ivjOKButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKButton;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getOKButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Message");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(299, 111);
	setModal(true);
	setTitle("Message");
	setContentPane(getJDialogContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Message aMessage;
		aMessage = new Message();
		aMessage.setModal(true);
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aMessage };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aMessage.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JDialog");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @param text java.lang.String
 */
public void show(String text) {

	getMessage().setText( "     " + text + "     ");
	pack();
	setModal(true);
	Dimension screen = getToolkit().getScreenSize();
	Rectangle s = getBounds();
	setBounds ( (screen.width - s.width) / 2,
				(screen.height - s.height) / 2,
   				s.width+20,
				s.height+20);
	setResizable(false);
	show();
	
}
}