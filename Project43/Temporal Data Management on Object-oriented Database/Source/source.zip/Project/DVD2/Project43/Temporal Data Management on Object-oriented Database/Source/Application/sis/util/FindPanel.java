package sis.util;

/**
 * This type was created in VisualAge.
 */
public class FindPanel extends com.sun.java.swing.JPanel implements java.awt.event.ActionListener, java.awt.event.KeyListener {
	private com.sun.java.swing.JRadioButton ivjFindByIDRadioButton = null;
	private com.sun.java.swing.JRadioButton ivjFindByNameRadioButton = null;
	private com.sun.java.swing.JTextField ivjIDTextField = null;
	private com.sun.java.swing.JTextField ivjNameTextField = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public FindPanel() {
	super();
	initialize();
}
/**
 * FindPanel constructor comment.
 * @param layout java.awt.LayoutManager
 */
public FindPanel(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * FindPanel constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public FindPanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * FindPanel constructor comment.
 * @param isDoubleBuffered boolean
 */
public FindPanel(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getFindByIDRadioButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getFindByNameRadioButton()) ) {
		connEtoC2(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void clear() {
	getFindByIDRadioButton().setSelected(false);
	getFindByNameRadioButton().setSelected(false);
	getIDTextField().setText("");
	getNameTextField().setText("");
}
/**
 * connEtoC1:  (FindByIDRadioButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindPanel.selection()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.selection(getFindByIDRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (FindByNameRadioButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindPanel.selection()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.selection(getFindByNameRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (IDTextField.key.keyTyped(java.awt.event.KeyEvent) --> FindPanel.selection(Lcom.sun.java.swing.JRadioButton;)V)
 * @param arg1 java.awt.event.KeyEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.KeyEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.selection(getFindByIDRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (NameTextField.key.keyTyped(java.awt.event.KeyEvent) --> FindPanel.selection(Lcom.sun.java.swing.JRadioButton;)V)
 * @param arg1 java.awt.event.KeyEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.KeyEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.selection(getFindByNameRadioButton());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the FindByIDRadioButton property value.
 * @return com.sun.java.swing.JRadioButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JRadioButton getFindByIDRadioButton() {
	if (ivjFindByIDRadioButton == null) {
		try {
			ivjFindByIDRadioButton = new com.sun.java.swing.JRadioButton();
			ivjFindByIDRadioButton.setName("FindByIDRadioButton");
			ivjFindByIDRadioButton.setText("Find by ID");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindByIDRadioButton;
}
/**
 * Return the FindByNameRadioButton property value.
 * @return com.sun.java.swing.JRadioButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JRadioButton getFindByNameRadioButton() {
	if (ivjFindByNameRadioButton == null) {
		try {
			ivjFindByNameRadioButton = new com.sun.java.swing.JRadioButton();
			ivjFindByNameRadioButton.setName("FindByNameRadioButton");
			ivjFindByNameRadioButton.setText("Find by name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindByNameRadioButton;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getFindType() {

	if ( getFindByIDRadioButton().isSelected() ){
		return new String("ID");
	} else if ( getFindByNameRadioButton().isSelected() ){
				return new String("Name");
	}
	return null;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the JTextField2 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(200, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * This method was created in VisualAge.
 * @return java.lang.String
 */
public String getText() {
	
	if ( getFindByIDRadioButton().isSelected() ){
		return getIDTextField().getText();
	} else if ( getFindByNameRadioButton().isSelected() ){
				return getNameTextField().getText();
	}

	return null;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getFindByIDRadioButton().addActionListener(this);
	getFindByNameRadioButton().addActionListener(this);
	getIDTextField().addKeyListener(this);
	getNameTextField().addKeyListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsFindByIDRadioButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFindByNameRadioButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	setName("FindPanel");
	setLayout(new java.awt.GridBagLayout());
	setSize(338, 76);

	constraintsFindByIDRadioButton.gridx = 1; constraintsFindByIDRadioButton.gridy = 1;
	constraintsFindByIDRadioButton.gridwidth = 1; constraintsFindByIDRadioButton.gridheight = 1;
	constraintsFindByIDRadioButton.anchor = java.awt.GridBagConstraints.WEST;
	constraintsFindByIDRadioButton.weightx = 0.0;
	constraintsFindByIDRadioButton.weighty = 0.0;
	constraintsFindByIDRadioButton.insets = new java.awt.Insets(5, 5, 5, 0);
	add(getFindByIDRadioButton(), constraintsFindByIDRadioButton);

	constraintsFindByNameRadioButton.gridx = 1; constraintsFindByNameRadioButton.gridy = 2;
	constraintsFindByNameRadioButton.gridwidth = 1; constraintsFindByNameRadioButton.gridheight = 1;
	constraintsFindByNameRadioButton.anchor = java.awt.GridBagConstraints.WEST;
	constraintsFindByNameRadioButton.weightx = 0.0;
	constraintsFindByNameRadioButton.weighty = 0.0;
	constraintsFindByNameRadioButton.insets = new java.awt.Insets(0, 5, 5, 0);
	add(getFindByNameRadioButton(), constraintsFindByNameRadioButton);

	constraintsIDTextField.gridx = 2; constraintsIDTextField.gridy = 1;
	constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
	constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
	constraintsIDTextField.weightx = 0.0;
	constraintsIDTextField.weighty = 0.0;
	constraintsIDTextField.insets = new java.awt.Insets(5, 5, 5, 5);
	add(getIDTextField(), constraintsIDTextField);

	constraintsNameTextField.gridx = 2; constraintsNameTextField.gridy = 2;
	constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
	constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
	constraintsNameTextField.weightx = 0.0;
	constraintsNameTextField.weighty = 0.0;
	constraintsNameTextField.insets = new java.awt.Insets(0, 5, 5, 5);
	add(getNameTextField(), constraintsNameTextField);
	initConnections();
	// user code begin {2}
	getFindByIDRadioButton().setSelected(false);
	getFindByNameRadioButton().setSelected(false);
	// user code end
}
/**
 * Method to handle events for the KeyListener interface.
 * @param e java.awt.event.KeyEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void keyPressed(java.awt.event.KeyEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the KeyListener interface.
 * @param e java.awt.event.KeyEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void keyReleased(java.awt.event.KeyEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the KeyListener interface.
 * @param e java.awt.event.KeyEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void keyTyped(java.awt.event.KeyEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getIDTextField()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getNameTextField()) ) {
		connEtoC4(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		FindPanel aFindPanel;
		aFindPanel = new FindPanel();
		frame.getContentPane().add("Center", aFindPanel);
		frame.setSize(aFindPanel.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 */
public void selection(com.sun.java.swing.JRadioButton selected) {

	if ( selected == getFindByIDRadioButton() ){
		getFindByIDRadioButton().setSelected(true);
		getFindByNameRadioButton().setSelected(false);

	} else if ( selected == getFindByNameRadioButton() ){
		getFindByNameRadioButton().setSelected(true);
		getFindByIDRadioButton().setSelected(false);

	}
}
}