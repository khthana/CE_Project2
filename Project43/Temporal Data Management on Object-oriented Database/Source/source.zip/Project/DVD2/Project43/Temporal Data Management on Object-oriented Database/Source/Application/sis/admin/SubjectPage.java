package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class SubjectPage extends JPanel implements java.awt.event.ActionListener, java.awt.event.ItemListener {
	private JLabel ivjCaptionLabel = null;
	private JScrollPane ivjCaptionScrollPane = null;
	private JLabel ivjCreditLabel = null;
	private JTextField ivjCreditTextField = null;
	private JComboBox ivjDeptComboBox = null;
	private JLabel ivjDeptLabel = null;
	private JComboBox ivjFacComboBox = null;
	private JLabel ivjFacLabel = null;
	private JLabel ivjIDLabel = null;
	private JTextField ivjIDTextField = null;
	private JLabel ivjNameLabel = null;
	private JTextField ivjNameTextField = null;
	private JLabel ivjTypeLabel = null;
	private JTextField ivjTypeTextField = null;
	private JTextArea ivjCaptionTextArea = null;
	private JButton ivjAddToolBarButton = null;
	private JButton ivjClearToolBarButton = null;
	private JButton ivjDeleteToolBarButton = null;
	private JButton ivjExitToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JPanel ivjInfoPanel = null;
	private JButton ivjSaveToolBarButton = null;
	private JToolBar ivjToolBar = null;
	private DatePanel ivjValidTimeDatePanel = null;
	private JPanel ivjValidTimePanel = null;
	private JTextPane ivjValidTimeTextPane = null;
	private JButton ivjCancelDelButton = null;
	private JDialog ivjDeleteDialog = null;
	private JPanel ivjDeleteDialogContentPane = null;
	private JLabel ivjDeleteLabel = null;
	private JButton ivjFindButton = null;
	private JDialog ivjFindDialog = null;
	private JPanel ivjFindDialogContentPane = null;
	private FindPanel ivjFindPanel = null;
	private JPanel ivjJPanel1 = null;
	private JPanel ivjJPanel2 = null;
	private JButton ivjOKDelButton = null;
	private JButton ivjCancelFindButton = null;
	private JPanel ivjJPanel = null;
	private Subject foundSbj = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public SubjectPage() {
	super();
	initialize();
}
/**
 * Subject constructor comment.
 * @param layout java.awt.LayoutManager
 */
public SubjectPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Subject constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public SubjectPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * Subject constructor comment.
 * @param isDoubleBuffered boolean
 */
public SubjectPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getFindButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM1(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoM3(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC4(e);
	}
	if ((e.getSource() == getDeleteToolBarButton()) ) {
		connEtoM4(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC5(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoC6(e);
	}
	if ((e.getSource() == getCancelDelButton()) ) {
		connEtoM5(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoM6(e);
	}
	if ((e.getSource() == getFacComboBox()) ) {
		connEtoM7(e);
	}
	if ((e.getSource() == getDeptComboBox()) ) {
		connEtoM8(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void add() throws Exception, java.rmi.RemoteException {
	try{
		
		//Check for valid form
		Message m = new Message();

		if (getIDTextField().getText().length() <= 0) {
			m.show("Subject ID is empty.");
			return;
		}
		if (getNameTextField().getText().length() <= 0) {
			m.show("Subject name is empty.");
			return;
		}
		if (getFacComboBox().getSelectedIndex() == 0) {
			m.show("Subject faculty isn't selected.");
			return;
		}
		if (getDeptComboBox().getSelectedIndex() == 0) {
			m.show("Student department isn't selected.");
			return;
		}


		if (getTypeTextField().getText().length() <= 0) {
			m.show("Subject citizen is empty.");
			return;
		}
		if (getCreditTextField().getText().length() <= 0) {
				m.show("Subject credit is empty.");
				return;
		}
		if (getCaptionTextArea().getText().length() <= 0) {
			m.show("Subject caption is empty.");
			return;
		}
		
		
		if (getValidTimeDatePanel().getDate() == null) {
			m.show("Valid Time Start is not selected.");
			return;
		}

		//Start Tx
		Factory.getAdminDB().startTransaction();

		//Argument for getCurrentID(),getCurrentName()
		Object arg[] = new Object[0];

		//Get Department in Department Type
		DBObject	selectedFac		=	(DBObject)	Factory.getAllFacs().elementAt( getFacComboBox().getSelectedIndex() - 1 );
		DBObject	selectedFac_ID	=	(DBObject)	selectedFac.execMethod("getCurrentID",arg);
		String		selectedFacID	=				selectedFac_ID.getProperty("ID").toString();
		Faculty		stdFac			=				Faculty.findCurrentByID( Factory.getAdminDB(),
																			 selectedFacID );

		if ( stdFac == null ) {
			m.show("Object can't be created. Fail to retrieve Faculty object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		Integer		pos				=	(Integer)	Factory.getRealDeptPos().elementAt( 
															getDeptComboBox().getSelectedIndex() - 1 );
		DBObject	selectedDept	=	(DBObject)	Factory.getAllDepts().elementAt( pos.intValue() );
		DBObject	selectedDept_ID	=	(DBObject)	selectedDept.execMethod("getCurrentID",arg);
		String		selectedDeptID	=				selectedDept_ID.getProperty("ID").toString();		
		Department	stdDept			=				Department.findCurrentByID( Factory.getAdminDB(),
																				selectedDeptID,
																				stdFac);
		if ( stdDept == null ) {
			m.show("Object can't be created. Fail to retrieve Department object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		
		java.sql.Date	vts		=	new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
		//Create new department
		Subject		newSubject	=	new	Subject( Factory.getAdminDB() );
		newSubject.create_this( getIDTextField().getText(),
								getNameTextField().getText(),
								stdDept,
								vts );
		
		newSubject.setCaption( getCaptionTextArea().getText() );
		newSubject.setType( getTypeTextField().getText() );
		newSubject.setCredit( new Integer(getCreditTextField().getText()) );

		//End Tx
		Factory.getAdminDB().endTransaction();

		//Clear form
		getCaptionTextArea().setText("");
		getCreditTextField().setText("");
		
		
		getIDTextField().setText("");
		getNameTextField().setText("");
		getTypeTextField().setText("");

		getFacComboBox().setSelectedIndex(0);
		getFacComboBox().repaint();
		getDeptComboBox().setSelectedIndex(0);
		getDeptComboBox().repaint();

				
	} catch (DatabaseException dbe) {
		System.out.println("Database Error in add() from sis.admin.SubjectPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	} catch (Exception e) {
		System.out.println("Error in add() from sis.admin.SubjectPage\n" + e.getMessage());
		e.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
public void addDeptToBox(JComboBox box, int selected) {

	try{
		if ( selected <= 0 ) {
			box.removeAllItems();
			box.addItem( "Selecte Faculty First");
			box.repaint();
			
		} else Factory.addDeptToBox( box, selected );
	} catch ( Exception e){
		System.out.println("Error in addDeptToBox(JComboBox,int) from sis.admin.SubjectPage\n" +
			e.getMessage() );
		e.printStackTrace();
	
	}


}
/**
 * This method was created in VisualAge.
 */
public void clear() {
	getCaptionTextArea().setText("");
	getCreditTextField().setText("");
	getDeptComboBox().setSelectedIndex(0);
	getFacComboBox().setSelectedIndex(0);
	getIDTextField().setText("");
	getNameTextField().setText("");
	getTypeTextField().setText("");
	
	//Clear	foundSubjectStudent
	foundSbj = null;

	//Enable&Disable some toolbar buttons
	getAddToolBarButton().setEnabled(true);
	getFindToolBarButton().setEnabled(true);
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
}
/**
 * connEtoC1:  (ClearToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SubjectPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SubjectPage.add()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.add();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> SubjectPage.find()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.find();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SubjectPage.update()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.update();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (ExitToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SubjectPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC6:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> SubjectPage.delete()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.delete();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC7:  (FacComboBox.item.itemStateChanged(java.awt.event.ItemEvent) --> SubjectPage.addDeptToBox(Lcom.sun.java.swing.JComboBox;I)V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC7(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.addDeptToBox(getDeptComboBox(), getFacComboBox().getSelectedIndex());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindPanel.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindPanel().clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (DeleteToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (CancelDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (FacComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> FacComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM7(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFacComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (DeptComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> DeptComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM8(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeptComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void delete() throws Exception, java.rmi.RemoteException {
	try{

		Message m = new Message();
		java.sql.Date vte;
		
		//if there's no found Subject then return
		if ( foundSbj == null )  {
			m.show("Can't delete. Subject not found.");	
			return;
		}
		//Check for VTE selection
		if ( getValidTimeDatePanel().getDate() == null ){
			m.show("Valid time for deleting is not selected.");
			return;
		} else vte = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	
		Factory.getAdminDB().startTransaction();
		foundSbj.delete_this(vte);
		foundSbj = null;
		Factory.getAdminDB().endTransaction();

		clear();
	
	} catch (DatabaseException dbe){
		System.out.println("Database Error in delete() from sis.admin.DepartmentPage\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void find() throws Exception, java.rmi.RemoteException {

	try{
		//Start Tx
		Factory.getAdminDB().startTransaction();

	 	Subject		_foundSbj	=	null;	
		Object 		arg[] 		= 	new Object[0];

		//Find		 
		if ( getFindPanel().getFindType().equals("ID") ){
		
			_foundSbj = Subject.findCurrentByID( Factory.getAdminDB(),
												 getFindPanel().getText() );
										   
		} else if ( getFindPanel().getFindType().equals("Name") ){
			_foundSbj = Subject.findCurrentByName( Factory.getAdminDB(),
												   getFindPanel().getText() );
		}

		//Check result
		//if subject didn't found then show message and return
		if ( _foundSbj == null ) {
			Message m = new Message();
			m.show("Subject didn't found.");
			Factory.getAdminDB().endTransaction();
			return; }
		
		foundSbj = _foundSbj;
		getFindPanel().clear();
		getFindDialog().dispose();
		

		//Show found Student

	
		getIDTextField().setText( foundSbj.getCurrentID().getId() );
		getNameTextField().setText( foundSbj.getCurrentName().getEname() );
		getTypeTextField().setText( foundSbj.getType() );
		getCreditTextField().setText( (new Integer(foundSbj.getCredit())).toString() );
		getCaptionTextArea().setText( foundSbj.getCaption() );

		String	sbjDeptID	=	foundSbj.getCurrentDept().getDept().getCurrentID().getId();
		String	sbjFacID	=	foundSbj.getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();

		int	i,pos = -1;
		
		for ( i=0; i < Factory.getAllFacs().size(); i++ ){

			DBObject	fac			=	(DBObject)	Factory.getAllFacs().elementAt(i);
			DBObject	fac_ID		=	(DBObject)	fac.execMethod("getCurrentID",arg);
			String		facID		=				fac_ID.getProperty("ID").toString();

			if ( sbjFacID.equals(facID) )
				pos = i;
			if ( pos >= 0 )
				break;
		}

		Factory.getAdminDB().endTransaction();
		
		if ( pos < 0 ) {	
			Message m = new Message();
			m.show("Can't display Faculty. Fail to retieve object.");
			getFacComboBox().setSelectedIndex( 0 );
			getFacComboBox().repaint();
		} else { getFacComboBox().setSelectedIndex( pos+1 );
				 getFacComboBox().repaint();
	   }

		Factory.getAdminDB().startTransaction();
		
		pos = -1;
		String deptFacPair[]	=	new String[2];
		
		for ( i=0; i < Factory.getRealDeptPos().size(); i++ ){

			deptFacPair	=	(String[])	Factory.getAllDeptIDs().elementAt(
										(new	Integer(Factory.getRealDeptPos().elementAt(i).toString())).intValue() );
			
			if ( sbjDeptID.equals( deptFacPair[0] ) && sbjFacID.equals( deptFacPair[1] ) )
				pos = i;
			if ( pos >= 0 )
				break;
		}

		if ( pos < 0 ) {	
			Message m = new Message();
			m.show("Can't display Department. Fail to retieve object.");
			getDeptComboBox().setSelectedIndex( 0 );
			getDeptComboBox().repaint();
		} else { getDeptComboBox().setSelectedIndex( pos+1 );
				 getDeptComboBox().repaint();
		}

		
		getValidTimeDatePanel().clear();

		
		//Enable & disable some toolbar bottons
		getAddToolBarButton().setEnabled(false);
		getDeleteToolBarButton().setEnabled(true);
		getSaveToolBarButton().setEnabled(true);
		
		//End Tx
		Factory.getAdminDB().endTransaction();
		
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in find() from sis.admin.SubjectPage\n" + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in find() from sis.admin.SubjectPage\n" + e.getMessage() );
		e.printStackTrace();
	}


	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
/**
 * Return the AddToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getAddToolBarButton() {
	if (ivjAddToolBarButton == null) {
		try {
			ivjAddToolBarButton = new com.sun.java.swing.JButton();
			ivjAddToolBarButton.setName("AddToolBarButton");
			ivjAddToolBarButton.setToolTipText("Add new subject");
			ivjAddToolBarButton.setText("");
			ivjAddToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjAddToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjAddToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\inserticon.gif"));
			ivjAddToolBarButton.setPreferredSize(new java.awt.Dimension(22, 23));
			ivjAddToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddToolBarButton;
}
/**
 * Return the CancelDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelDelButton() {
	if (ivjCancelDelButton == null) {
		try {
			ivjCancelDelButton = new com.sun.java.swing.JButton();
			ivjCancelDelButton.setName("CancelDelButton");
			ivjCancelDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelDelButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelDelButton;
}
/**
 * Return the CancelFindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelFindButton() {
	if (ivjCancelFindButton == null) {
		try {
			ivjCancelFindButton = new com.sun.java.swing.JButton();
			ivjCancelFindButton.setName("CancelFindButton");
			ivjCancelFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelFindButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelFindButton;
}
/**
 * Return the CaptionSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getCaptionLabel() {
	if (ivjCaptionLabel == null) {
		try {
			ivjCaptionLabel = new com.sun.java.swing.JLabel();
			ivjCaptionLabel.setName("CaptionLabel");
			ivjCaptionLabel.setText("Caption");
			ivjCaptionLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCaptionLabel;
}
/**
 * Return the JScrollPane property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JScrollPane getCaptionScrollPane() {
	if (ivjCaptionScrollPane == null) {
		try {
			ivjCaptionScrollPane = new com.sun.java.swing.JScrollPane();
			ivjCaptionScrollPane.setName("CaptionScrollPane");
			ivjCaptionScrollPane.setAutoscrolls(true);
			ivjCaptionScrollPane.setPreferredSize(new java.awt.Dimension(200, 50));
			getCaptionScrollPane().setViewportView(getCaptionTextArea());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCaptionScrollPane;
}
/**
 * Return the JTextArea1 property value.
 * @return com.sun.java.swing.JTextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextArea getCaptionTextArea() {
	if (ivjCaptionTextArea == null) {
		try {
			ivjCaptionTextArea = new com.sun.java.swing.JTextArea();
			ivjCaptionTextArea.setName("CaptionTextArea");
			ivjCaptionTextArea.setBounds(0, 0, 15, 19);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCaptionTextArea;
}
/**
 * Return the ClearToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the CreditSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getCreditLabel() {
	if (ivjCreditLabel == null) {
		try {
			ivjCreditLabel = new com.sun.java.swing.JLabel();
			ivjCreditLabel.setName("CreditLabel");
			ivjCreditLabel.setText("Credit");
			ivjCreditLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCreditLabel;
}
/**
 * Return the CreditSubjInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getCreditTextField() {
	if (ivjCreditTextField == null) {
		try {
			ivjCreditTextField = new com.sun.java.swing.JTextField();
			ivjCreditTextField.setName("CreditTextField");
			ivjCreditTextField.setPreferredSize(new java.awt.Dimension(30, 19));
			ivjCreditTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjCreditTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCreditTextField;
}
/**
 * Return the DeleteDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getDeleteDialog() {
	if (ivjDeleteDialog == null) {
		try {
			ivjDeleteDialog = new com.sun.java.swing.JDialog();
			ivjDeleteDialog.setName("DeleteDialog");
			ivjDeleteDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjDeleteDialog.setBounds(777, 409, 300, 100);
			ivjDeleteDialog.setModal(true);
			ivjDeleteDialog.setTitle("Delete Subject");
			getDeleteDialog().setContentPane(getDeleteDialogContentPane());
			// user code begin {1}
			ivjDeleteDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjDeleteDialog.getBounds();
			ivjDeleteDialog.setBounds ( (screen.width - s.width)/2,
									    (screen.height - s.height)/2,
									  	s.width,
									  	s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialog;
}
/**
 * Return the DeleteDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getDeleteDialogContentPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	if (ivjDeleteDialogContentPane == null) {
		try {
			ivjDeleteDialogContentPane = new com.sun.java.swing.JPanel();
			ivjDeleteDialogContentPane.setName("DeleteDialogContentPane");
			ivjDeleteDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjDeleteDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 0;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			getDeleteDialogContentPane().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel2.gridx = 0; constraintsJPanel2.gridy = 1;
			constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
			constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel2.weightx = 0.0;
			constraintsJPanel2.weighty = 0.0;
			constraintsJPanel2.insets = new java.awt.Insets(10, 0, 10, 0);
			getDeleteDialogContentPane().add(getJPanel2(), constraintsJPanel2);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialogContentPane;
}
/**
 * Return the DeleteLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeleteLabel() {
	if (ivjDeleteLabel == null) {
		try {
			ivjDeleteLabel = new com.sun.java.swing.JLabel();
			ivjDeleteLabel.setName("DeleteLabel");
			ivjDeleteLabel.setText("Are you sure to delete this object?");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteLabel;
}
/**
 * Return the DeleteToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getDeleteToolBarButton() {
	if (ivjDeleteToolBarButton == null) {
		try {
			ivjDeleteToolBarButton = new com.sun.java.swing.JButton();
			ivjDeleteToolBarButton.setName("DeleteToolBarButton");
			ivjDeleteToolBarButton.setToolTipText("Delete this subject");
			ivjDeleteToolBarButton.setText("");
			ivjDeleteToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDeleteToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDeleteToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\deleteicon.gif"));
			ivjDeleteToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteToolBarButton;
}
/**
 * Return the DeptSubjInsComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getDeptComboBox() {
	if (ivjDeptComboBox == null) {
		try {
			ivjDeptComboBox = new com.sun.java.swing.JComboBox();
			ivjDeptComboBox.setName("DeptComboBox");
			ivjDeptComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjDeptComboBox.setMinimumSize(new java.awt.Dimension(200, 20));
			ivjDeptComboBox.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeptComboBox;
}
/**
 * Return the DeptSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeptLabel() {
	if (ivjDeptLabel == null) {
		try {
			ivjDeptLabel = new com.sun.java.swing.JLabel();
			ivjDeptLabel.setName("DeptLabel");
			ivjDeptLabel.setText("Department");
			ivjDeptLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeptLabel;
}
/**
 * Return the ExitToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setToolTipText("exit");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the FacSubjInsComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getFacComboBox() {
	if (ivjFacComboBox == null) {
		try {
			ivjFacComboBox = new com.sun.java.swing.JComboBox();
			ivjFacComboBox.setName("FacComboBox");
			ivjFacComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjFacComboBox.setMinimumSize(new java.awt.Dimension(200, 20));
			ivjFacComboBox.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacComboBox;
}
/**
 * Return the FacSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getFacLabel() {
	if (ivjFacLabel == null) {
		try {
			ivjFacLabel = new com.sun.java.swing.JLabel();
			ivjFacLabel.setName("FacLabel");
			ivjFacLabel.setText("Faculty");
			ivjFacLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacLabel;
}
/**
 * Return the FindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindButton() {
	if (ivjFindButton == null) {
		try {
			ivjFindButton = new com.sun.java.swing.JButton();
			ivjFindButton.setName("FindButton");
			ivjFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjFindButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindButton;
}
/**
 * Return the FindDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getFindDialog() {
	if (ivjFindDialog == null) {
		try {
			ivjFindDialog = new com.sun.java.swing.JDialog();
			ivjFindDialog.setName("FindDialog");
			ivjFindDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjFindDialog.setBounds(803, 113, 340, 150);
			ivjFindDialog.setModal(true);
			ivjFindDialog.setTitle("Find Subject");
			getFindDialog().setContentPane(getFindDialogContentPane());
			// user code begin {1}
			ivjFindDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjFindDialog.getBounds();
			ivjFindDialog.setBounds ( (screen.width - s.width)/2,
									  (screen.height - s.height)/2,
									  s.width,
									  s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialog;
}
/**
 * Return the FindDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindDialogContentPane() {
	java.awt.GridBagConstraints constraintsFindPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel = new java.awt.GridBagConstraints();
	if (ivjFindDialogContentPane == null) {
		try {
			ivjFindDialogContentPane = new com.sun.java.swing.JPanel();
			ivjFindDialogContentPane.setName("FindDialogContentPane");
			ivjFindDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjFindDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsFindPanel.gridx = 0; constraintsFindPanel.gridy = 0;
			constraintsFindPanel.gridwidth = 1; constraintsFindPanel.gridheight = 1;
			constraintsFindPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindPanel.weightx = 1.0;
			constraintsFindPanel.weighty = 0.0;
			constraintsFindPanel.insets = new java.awt.Insets(0, 0, 5, 0);
			getFindDialogContentPane().add(getFindPanel(), constraintsFindPanel);

			constraintsJPanel.gridx = 0; constraintsJPanel.gridy = 1;
			constraintsJPanel.gridwidth = 1; constraintsJPanel.gridheight = 1;
			constraintsJPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel.weightx = 0.0;
			constraintsJPanel.weighty = 0.0;
			constraintsJPanel.insets = new java.awt.Insets(10, 0, 10, 0);
			getFindDialogContentPane().add(getJPanel(), constraintsJPanel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialogContentPane;
}
/**
 * Return the FindPanel property value.
 * @return sis.util.FindPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private FindPanel getFindPanel() {
	if (ivjFindPanel == null) {
		try {
			ivjFindPanel = new sis.util.FindPanel();
			ivjFindPanel.setName("FindPanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindPanel;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("Find subject");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the IdSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getIDLabel() {
	if (ivjIDLabel == null) {
		try {
			ivjIDLabel = new com.sun.java.swing.JLabel();
			ivjIDLabel.setName("IDLabel");
			ivjIDLabel.setText("Subject ID");
			ivjIDLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDLabel;
}
/**
 * Return the IdSubjInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			ivjIDTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjIDTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the InfoPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getInfoPanel() {
	java.awt.GridBagConstraints constraintsIDLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsTypeLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsTypeTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCreditLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCreditTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeptLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeptComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCaptionLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCaptionScrollPane = new java.awt.GridBagConstraints();
	if (ivjInfoPanel == null) {
		try {
			ivjInfoPanel = new com.sun.java.swing.JPanel();
			ivjInfoPanel.setName("InfoPanel");
			ivjInfoPanel.setLayout(new java.awt.GridBagLayout());

			constraintsIDLabel.gridx = 0; constraintsIDLabel.gridy = 0;
			constraintsIDLabel.gridwidth = 1; constraintsIDLabel.gridheight = 1;
			constraintsIDLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsIDLabel.weightx = 0.0;
			constraintsIDLabel.weighty = 0.0;
			constraintsIDLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getIDLabel(), constraintsIDLabel);

			constraintsIDTextField.gridx = 1; constraintsIDTextField.gridy = 0;
			constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
			constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsIDTextField.weightx = 0.0;
			constraintsIDTextField.weighty = 0.0;
			constraintsIDTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getIDTextField(), constraintsIDTextField);

			constraintsNameLabel.gridx = 0; constraintsNameLabel.gridy = 1;
			constraintsNameLabel.gridwidth = 1; constraintsNameLabel.gridheight = 1;
			constraintsNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsNameLabel.weightx = 0.0;
			constraintsNameLabel.weighty = 0.0;
			constraintsNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getNameLabel(), constraintsNameLabel);

			constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 1;
			constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
			constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsNameTextField.weightx = 0.0;
			constraintsNameTextField.weighty = 0.0;
			constraintsNameTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getNameTextField(), constraintsNameTextField);

			constraintsTypeLabel.gridx = 0; constraintsTypeLabel.gridy = 2;
			constraintsTypeLabel.gridwidth = 1; constraintsTypeLabel.gridheight = 1;
			constraintsTypeLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsTypeLabel.weightx = 0.0;
			constraintsTypeLabel.weighty = 0.0;
			constraintsTypeLabel.insets = new java.awt.Insets(20, 10, 5, 10);
			getInfoPanel().add(getTypeLabel(), constraintsTypeLabel);

			constraintsTypeTextField.gridx = 1; constraintsTypeTextField.gridy = 2;
			constraintsTypeTextField.gridwidth = 1; constraintsTypeTextField.gridheight = 1;
			constraintsTypeTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsTypeTextField.weightx = 0.0;
			constraintsTypeTextField.weighty = 0.0;
			constraintsTypeTextField.insets = new java.awt.Insets(20, 0, 5, 0);
			getInfoPanel().add(getTypeTextField(), constraintsTypeTextField);

			constraintsCreditLabel.gridx = 0; constraintsCreditLabel.gridy = 3;
			constraintsCreditLabel.gridwidth = 1; constraintsCreditLabel.gridheight = 1;
			constraintsCreditLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsCreditLabel.weightx = 0.0;
			constraintsCreditLabel.weighty = 0.0;
			constraintsCreditLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getCreditLabel(), constraintsCreditLabel);

			constraintsCreditTextField.gridx = 1; constraintsCreditTextField.gridy = 3;
			constraintsCreditTextField.gridwidth = 1; constraintsCreditTextField.gridheight = 1;
			constraintsCreditTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsCreditTextField.weightx = 0.0;
			constraintsCreditTextField.weighty = 0.0;
			constraintsCreditTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getCreditTextField(), constraintsCreditTextField);

			constraintsFacLabel.gridx = 2; constraintsFacLabel.gridy = 0;
			constraintsFacLabel.gridwidth = 1; constraintsFacLabel.gridheight = 1;
			constraintsFacLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsFacLabel.weightx = 0.0;
			constraintsFacLabel.weighty = 0.0;
			constraintsFacLabel.insets = new java.awt.Insets(0, 20, 5, 10);
			getInfoPanel().add(getFacLabel(), constraintsFacLabel);

			constraintsFacComboBox.gridx = 3; constraintsFacComboBox.gridy = 0;
			constraintsFacComboBox.gridwidth = 1; constraintsFacComboBox.gridheight = 1;
			constraintsFacComboBox.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFacComboBox.weightx = 0.0;
			constraintsFacComboBox.weighty = 0.0;
			constraintsFacComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getFacComboBox(), constraintsFacComboBox);

			constraintsDeptLabel.gridx = 2; constraintsDeptLabel.gridy = 1;
			constraintsDeptLabel.gridwidth = 1; constraintsDeptLabel.gridheight = 1;
			constraintsDeptLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDeptLabel.weightx = 0.0;
			constraintsDeptLabel.weighty = 0.0;
			constraintsDeptLabel.insets = new java.awt.Insets(0, 20, 5, 10);
			getInfoPanel().add(getDeptLabel(), constraintsDeptLabel);

			constraintsDeptComboBox.gridx = 3; constraintsDeptComboBox.gridy = 1;
			constraintsDeptComboBox.gridwidth = 1; constraintsDeptComboBox.gridheight = 1;
			constraintsDeptComboBox.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDeptComboBox.weightx = 0.0;
			constraintsDeptComboBox.weighty = 0.0;
			constraintsDeptComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getDeptComboBox(), constraintsDeptComboBox);

			constraintsCaptionLabel.gridx = 2; constraintsCaptionLabel.gridy = 2;
			constraintsCaptionLabel.gridwidth = 1; constraintsCaptionLabel.gridheight = 1;
			constraintsCaptionLabel.anchor = java.awt.GridBagConstraints.NORTHEAST;
			constraintsCaptionLabel.weightx = 0.0;
			constraintsCaptionLabel.weighty = 0.0;
			constraintsCaptionLabel.insets = new java.awt.Insets(20, 20, 5, 10);
			getInfoPanel().add(getCaptionLabel(), constraintsCaptionLabel);

			constraintsCaptionScrollPane.gridx = 3; constraintsCaptionScrollPane.gridy = 2;
			constraintsCaptionScrollPane.gridwidth = 1; constraintsCaptionScrollPane.gridheight = 3;
			constraintsCaptionScrollPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsCaptionScrollPane.anchor = java.awt.GridBagConstraints.WEST;
			constraintsCaptionScrollPane.weightx = 0.0;
			constraintsCaptionScrollPane.weighty = 0.0;
			constraintsCaptionScrollPane.insets = new java.awt.Insets(20, 0, 5, 10);
			getInfoPanel().add(getCaptionScrollPane(), constraintsCaptionScrollPane);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Subject Information");
			ivjInfoPanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInfoPanel;
}
/**
 * Return the JPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel() {
	java.awt.GridBagConstraints constraintsFindButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelFindButton = new java.awt.GridBagConstraints();
	if (ivjJPanel == null) {
		try {
			ivjJPanel = new com.sun.java.swing.JPanel();
			ivjJPanel.setName("JPanel");
			ivjJPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFindButton.gridx = 0; constraintsFindButton.gridy = 0;
			constraintsFindButton.gridwidth = 1; constraintsFindButton.gridheight = 1;
			constraintsFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindButton.weightx = 0.0;
			constraintsFindButton.weighty = 0.0;
			constraintsFindButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel().add(getFindButton(), constraintsFindButton);

			constraintsCancelFindButton.gridx = -1; constraintsCancelFindButton.gridy = -1;
			constraintsCancelFindButton.gridwidth = 1; constraintsCancelFindButton.gridheight = 1;
			constraintsCancelFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelFindButton.weightx = 0.0;
			constraintsCancelFindButton.weighty = 0.0;
			getJPanel().add(getCancelFindButton(), constraintsCancelFindButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsDeleteLabel = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsDeleteLabel.gridx = 0; constraintsDeleteLabel.gridy = 0;
			constraintsDeleteLabel.gridwidth = 1; constraintsDeleteLabel.gridheight = 1;
			constraintsDeleteLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDeleteLabel.weightx = 0.0;
			constraintsDeleteLabel.weighty = 0.0;
			getJPanel1().add(getDeleteLabel(), constraintsDeleteLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsOKDelButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelDelButton = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsOKDelButton.gridx = 0; constraintsOKDelButton.gridy = 0;
			constraintsOKDelButton.gridwidth = 1; constraintsOKDelButton.gridheight = 1;
			constraintsOKDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKDelButton.weightx = 0.0;
			constraintsOKDelButton.weighty = 0.0;
			constraintsOKDelButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel2().add(getOKDelButton(), constraintsOKDelButton);

			constraintsCancelDelButton.gridx = -1; constraintsCancelDelButton.gridy = -1;
			constraintsCancelDelButton.gridwidth = 1; constraintsCancelDelButton.gridheight = 1;
			constraintsCancelDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelDelButton.weightx = 0.0;
			constraintsCancelDelButton.weighty = 0.0;
			getJPanel2().add(getCancelDelButton(), constraintsCancelDelButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the NameSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getNameLabel() {
	if (ivjNameLabel == null) {
		try {
			ivjNameLabel = new com.sun.java.swing.JLabel();
			ivjNameLabel.setName("NameLabel");
			ivjNameLabel.setText("Subject Name");
			ivjNameLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameLabel;
}
/**
 * Return the NameSubjInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			ivjNameTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjNameTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * Return the OKDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKDelButton() {
	if (ivjOKDelButton == null) {
		try {
			ivjOKDelButton = new com.sun.java.swing.JButton();
			ivjOKDelButton.setName("OKDelButton");
			ivjOKDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKDelButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKDelButton;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Save change");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the ToolBar property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getToolBar() {
	if (ivjToolBar == null) {
		try {
			ivjToolBar = new com.sun.java.swing.JToolBar();
			ivjToolBar.setName("ToolBar");
			ivjToolBar.add(getClearToolBarButton());
			ivjToolBar.addSeparator();
			getToolBar().add(getAddToolBarButton(), getAddToolBarButton().getName());
			getToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			getToolBar().add(getDeleteToolBarButton(), getDeleteToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjToolBar;
}
/**
 * Return the TypeSubjInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getTypeLabel() {
	if (ivjTypeLabel == null) {
		try {
			ivjTypeLabel = new com.sun.java.swing.JLabel();
			ivjTypeLabel.setName("TypeLabel");
			ivjTypeLabel.setText("Type");
			ivjTypeLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTypeLabel;
}
/**
 * Return the TypeSubjInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getTypeTextField() {
	if (ivjTypeTextField == null) {
		try {
			ivjTypeTextField = new com.sun.java.swing.JTextField();
			ivjTypeTextField.setName("TypeTextField");
			ivjTypeTextField.setPreferredSize(new java.awt.Dimension(30, 19));
			ivjTypeTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjTypeTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTypeTextField;
}
/**
 * Return the ValidTimeDatePanel property value.
 * @return sis.util.DatePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DatePanel getValidTimeDatePanel() {
	if (ivjValidTimeDatePanel == null) {
		try {
			ivjValidTimeDatePanel = new sis.util.DatePanel();
			ivjValidTimeDatePanel.setName("ValidTimeDatePanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeDatePanel;
}
/**
 * Return the ValidTimePanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getValidTimePanel() {
	java.awt.GridBagConstraints constraintsValidTimeTextPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsValidTimeDatePanel = new java.awt.GridBagConstraints();
	if (ivjValidTimePanel == null) {
		try {
			ivjValidTimePanel = new com.sun.java.swing.JPanel();
			ivjValidTimePanel.setName("ValidTimePanel");
			ivjValidTimePanel.setLayout(new java.awt.GridBagLayout());

			constraintsValidTimeTextPane.gridx = 1; constraintsValidTimeTextPane.gridy = 1;
			constraintsValidTimeTextPane.gridwidth = 1; constraintsValidTimeTextPane.gridheight = 1;
			constraintsValidTimeTextPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsValidTimeTextPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeTextPane.weightx = 1.0;
			constraintsValidTimeTextPane.weighty = 1.0;
			getValidTimePanel().add(getValidTimeTextPane(), constraintsValidTimeTextPane);

			constraintsValidTimeDatePanel.gridx = 1; constraintsValidTimeDatePanel.gridy = 2;
			constraintsValidTimeDatePanel.gridwidth = 1; constraintsValidTimeDatePanel.gridheight = 1;
			constraintsValidTimeDatePanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeDatePanel.weightx = 0.0;
			constraintsValidTimeDatePanel.weighty = 0.0;
			getValidTimePanel().add(getValidTimeDatePanel(), constraintsValidTimeDatePanel);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Valid Time");
			ivjValidTimePanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimePanel;
}
/**
 * Return the ValidTimeTextPane property value.
 * @return com.sun.java.swing.JTextPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextPane getValidTimeTextPane() {
	if (ivjValidTimeTextPane == null) {
		try {
			ivjValidTimeTextPane = new com.sun.java.swing.JTextPane();
			ivjValidTimeTextPane.setName("ValidTimeTextPane");
			ivjValidTimeTextPane.setPreferredSize(new java.awt.Dimension(30, 60));
			ivjValidTimeTextPane.setText("This time is used for,\n \t- insert, valid time start of this object\n\t- delete, valid time end of this object\n\t- update, valid time end of old property and valid time start of new property");
			ivjValidTimeTextPane.setBackground(new java.awt.Color(204,204,204));
			ivjValidTimeTextPane.setEditable(false);
			// user code begin {1}
			Border empty;
			empty = BorderFactory.createEmptyBorder(0,10,10,10);
			ivjValidTimeTextPane.setBorder(empty);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeTextPane;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getAddToolBarButton().addActionListener(this);
	getFindButton().addActionListener(this);
	getCancelFindButton().addActionListener(this);
	getFindToolBarButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
	getDeleteToolBarButton().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
	getOKDelButton().addActionListener(this);
	getCancelDelButton().addActionListener(this);
	getFacComboBox().addItemListener(this);
	getFacComboBox().addActionListener(this);
	getDeptComboBox().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Subject");
	setLayout(new java.awt.BorderLayout());
	setSize(550, 311);
	add(getToolBar(), "North");
	add(getValidTimePanel(), "South");
	add(getInfoPanel(), "Center");
	initConnections();
	// user code begin {2}
	Factory.addFacultyToBox( getFacComboBox() );
	//Disable some toolbar buttons
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
	// user code end
}
/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getFacComboBox()) ) {
		connEtoC7(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		JFrame frame = new com.sun.java.swing.JFrame();
		SubjectPage aSubjectPage;
		aSubjectPage = new SubjectPage();
		frame.getContentPane().add("Center", aSubjectPage);
		frame.setSize(aSubjectPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void update() throws Exception, java.rmi.RemoteException {
	Message m = new Message();
	
	//if there's no found Subject then return
	if ( foundSbj == null )  {
		m.show("Can't update. Student not found.");	
		return;
	}

	//Check seleted Faculty and Department
	if ( getFacComboBox().getSelectedIndex() == 0 ){
		m.show("Faculty isn't seleted.");
		return;
	}
	
	if ( getDeptComboBox().getSelectedIndex() == 0 ){
		m.show("Department isn't seleted.");
		return;
	}
	
	//Check for valid time selection
	if ( getValidTimeDatePanel().getDate() == null ) {
		m.show("Valid time isn't selected.");
		return;
	}

	//Valid Time,use for passing
	java.sql.Date valid = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	//Set if there's update
	boolean update = false;

	try{
		//Strat Tx
		Factory.getAdminDB().startTransaction();

		//Get Dept ID from form
		Object 	arg[]			=	new	Object[0];
		int		i,pos 			= 	-1;
		String 	deptFacPair[]	=	new String[2];
		
		String	sbjDeptID		=	foundSbj.getCurrentDept().getDept().getCurrentID().getId();
		String	sbjFacID		=	foundSbj.getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();

		deptFacPair	=	(String[])	Factory.getAllDeptIDs().elementAt(
								(new	Integer(Factory.getRealDeptPos().elementAt( getDeptComboBox().getSelectedIndex()-1 ).toString())).intValue() );

		if ( !(sbjDeptID.equals(deptFacPair[0]) && sbjFacID.equals(deptFacPair[1])) ){
			
			Faculty		cFac	=	Faculty.findCurrentByID( Factory.getAdminDB(),
															 deptFacPair[1] );
			Department	cDept	=	Department.findCurrentByID( Factory.getAdminDB(),
															 deptFacPair[0],
															 cFac);
			foundSbj.update_Dept( foundSbj.getCurrentDept().getDept(),
								  cDept,
								  valid,
								  valid);
			update = true;
			System.out.println("Subject Department has been updated.");
		}
		

		if ( !getIDTextField().getText().equals( foundSbj.getCurrentID().getId() ) ){
			  foundSbj.update_ID( foundSbj.getCurrentID().getId(),
								  getIDTextField().getText(),
								  valid,
								  valid);
			  update = true;
			  System.out.println("Subject ID has been updated.");
		}

		if ( !getNameTextField().getText().equals( foundSbj.getCurrentName().getEname() ) ){
			 foundSbj.update_eName( foundSbj.getCurrentName().getEname(),
									getNameTextField().getText(),
									valid,
								 	valid);
			  update = true;
			  System.out.println("Subject Name has been updated.");
		}

		if ( !getTypeTextField().getText().equals( foundSbj.getType() ) ){
			foundSbj.setType( getTypeTextField().getText() );
			update = true;
			System.out.println("Subject Type has been updated.");
		}

		if ( !getCreditTextField().getText().equals( (new Integer (foundSbj.getCredit())).toString() ) ){
			foundSbj.setCredit( (new Integer(getCreditTextField().getText())).intValue() );
			update = true;
			System.out.println("Subject Credit has been updated.");
		}

		if ( !getCaptionTextArea().getText().equals( foundSbj.getCaption() ) ){
			foundSbj.setCaption( getCaptionTextArea().getText() );
			update = true;
			System.out.println("Subject Caption has been updated.");
		}


		//Refresh foundSbj
		if ( update ){

			int selectedFacIndex 	=	getFacComboBox().getSelectedIndex();
			int selectedDeptIndex 	=	getDeptComboBox().getSelectedIndex();

			//Find		 
			foundSbj	= 	null;
			foundSbj	= 	Subject.findCurrentByID( Factory.getAdminDB(),
										          	 getIDTextField().getText() );
			
			if ( foundSbj == null ){
				m.show("Cannot display updated information");
				clear();
			} else {	//Show
						getIDTextField().setText( foundSbj.getCurrentID().getId() );
						getNameTextField().setText( foundSbj.getCurrentName().getEname() );
						getFacComboBox().setSelectedIndex( selectedFacIndex );
						getFacComboBox().repaint();
						getDeptComboBox().setSelectedIndex( selectedDeptIndex );
						getDeptComboBox().repaint();
						getCreditTextField().setText( Integer.toString(foundSbj.getCredit()) );
						getTypeTextField().setText( foundSbj.getType() );
						getCaptionTextArea().setText( foundSbj.getCaption() );
						
						getValidTimeDatePanel().clear();
			}

			m.show("Subject has been updated.");
		} else m.show("Subject Information hasn't been changed.");
		
		//End Tx
		Factory.getAdminDB().endTransaction();
	  
	} catch (DatabaseException dbe){
		System.out.println("Database Error in update() from sis.admin.SubjectPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
}