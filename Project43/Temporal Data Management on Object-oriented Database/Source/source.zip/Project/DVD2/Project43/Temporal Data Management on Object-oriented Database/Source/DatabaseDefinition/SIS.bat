jasstart

deleteCF TempCF
createCF TempCF tempStore

codqlie < SIS.def
codqlie < TempObject.method
codqlie < Faculty.method
codqlie < Department.method
codqlie < Teacher.method
codqlie < Subject.method
codqlie < Semester.method
codqlie < Student.method
codqlie < sis.data

jasstop

jpcg TempCF c:\Temporal\ProxyClass

jasstart

codqlie < addProcedure.method

c:\jdk1.1.8\bin\javac c:\Temporal\ProxyClass\Jp\jasmine\TempCF\*.java