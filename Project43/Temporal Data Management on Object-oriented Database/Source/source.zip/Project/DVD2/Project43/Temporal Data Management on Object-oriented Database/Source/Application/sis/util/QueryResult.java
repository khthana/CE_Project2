package sis.util;

import java.lang.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import com.sun.java.swing.*;
import com.sun.java.swing.table.*;
import reg.Methods.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
/**
 * This type was created in VisualAge.
 */
public class QueryResult {
	public QueryModel qModel;
	public DefaultTableModel resultTable;
	private int numRow;
/**
 * QueryResult constructor comment.
 */
public QueryResult() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param varName java.lang.String
 * @param varType java.lang.String
 * @param colName java.lang.String
 * @param queryCode java.lang.String
 */
public QueryResult(String varName, String varType, String colName, String queryCode)  {

	this.qModel = new QueryModel(varName, varType, colName, queryCode);

	Vector col = new Vector();

	for ( int i = 0; i < qModel.getNumberOfCol(); i++){
		col.addElement(qModel.colName.elementAt(i));
	}
	
	this.resultTable = new DefaultTableModel(col,0);
}
/**
 * This method was created in VisualAge.
 * @param QModel sis.QueryModel
 */
public QueryResult(QueryModel QModel) {

	this.qModel = QModel;
	this.resultTable = new DefaultTableModel(this.qModel.colName,0);
	
}
/**
 * This method was created in VisualAge.
 * @param table com.sun.java.swing.table.DefaultTableModel
 */
public void addRowToTable() {

	
	try{

		String 	result 		= new String("");
		String  cellValue 	= new String("");
		Vector 	vResults 	= new Vector();
		Vector  rowData  	= new Vector();
	
		char	element;
		boolean	found = false ;

		Factory.getQueryDB().startTransaction();

		ODQLStatement query = Factory.getQueryDB().getODQLStatement();
		query.execute(qModel.queryCode);
		result = (String) query.getVar(this.qModel.varName);
		Factory.getQueryDB().endTransaction();
		Factory.getQueryDB().endSession();
		Factory.setQueryDB(null);

		if ( qModel.varType.equals("Tuple") ) {
			
			for ( int i = 0; i < result.length(); i++){

				element = result.charAt(i);

				if ( found	) {
					if ( (element != '"') && 
							(element != '[') &&
							(element != ']') &&
							(element != '\n')){
						if ( (element == ',') || (element == '}') ){
							found = false;
							vResults.addElement(cellValue);
							System.out.println(cellValue+"  ");
							cellValue = "";
							
							
						} else  cellValue = cellValue + element; 
					} 
				}
		 		if ( element == ':') 
		 			found = true;
			}
		}

		for ( int i = 0; i < vResults.size(); i++){
			if ( rowData.size() < this.qModel.getNumberOfCol() ){
				rowData.addElement(vResults.elementAt(i));
			} else { 
					this.resultTable.addRow(rowData);
					rowData = new Vector();
					rowData.addElement(vResults.elementAt(i));
				   }
		}
		
		this.resultTable.addRow(rowData); //for last row

	} catch (Exception e){

		System.out.println("Error in addRowToTable() from sis.util.Factory\n" + e.getMessage());
		e.printStackTrace();
	}
}
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[]) {

	String varName = new String("allEmps");
	String varType = new String("Tuple");
	String colName = new String("ID,Name,Dept,Hiredate");
	String queryCode = new String("ODQL");

	QueryResult x= new QueryResult(varName, varType, colName, queryCode);
	//x.addRowToTable(x.resultTable);
	x.addRowToTable();
	x.show();
}
/**
 * This method was created in VisualAge.
 */
public void show() {


		GridBagLayout g1 = new GridBagLayout();
		GridBagConstraints gc = new GridBagConstraints();
	

		JFrame ResultFrame = new JFrame("Query Result");
		ResultFrame.setSize(550,200);
		ResultFrame.getContentPane().setLayout(g1);
		
		JTable table = new JTable(this.resultTable);
		table.setPreferredScrollableViewportSize(new Dimension(500, 70));

		//Create the scroll pane and add the table to it. 
		JScrollPane scrollPane = new JScrollPane(table);

		//Add the scroll pane to this window.

		gc.gridx=0;
		gc.gridy=0;
		gc.weightx=1.0;
		gc.weighty=1.0;
		gc.gridheight=1;
		gc.gridwidth=1;
		gc.fill=GridBagConstraints.BOTH;
		
		ResultFrame.getContentPane().add(scrollPane, gc);

		ResultFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
//				System.exit(0);
			}
		});

		ResultFrame.show();

	
	
	
}
}