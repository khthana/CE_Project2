package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class InsertPage extends JFrame implements java.awt.event.ActionListener {
	private JButton ivjJButton1 = null;
	private JPanel ivjJFrameContentPane = null;
	private JPanel ivjJPanel1 = null;
	private JTabbedPane ivjInsertTabbedPane = null;
	private StudentPage ivjStudent = null;
	private DepartmentPage ivjDepartment = null;
	private FacultyPage ivjFaculty = null;
	private SubjectPage ivjSubject = null;
	private TeacherPage ivjTeacher = null;
	private SemesterPage ivjSemester = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public InsertPage() {
	super();
	initialize();
}
/**
 * InsertPage constructor comment.
 * @param title java.lang.String
 */
public InsertPage(String title) {
	super(title);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJButton1()) ) {
		connEtoC1(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (JButton1.action.actionPerformed(java.awt.event.ActionEvent) --> InsertPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * Return the DepartmentPage1 property value.
 * @return sis.admin.DepartmentPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DepartmentPage getDepartment() {
	if (ivjDepartment == null) {
		try {
			ivjDepartment = new sis.admin.DepartmentPage();
			ivjDepartment.setName("Department");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDepartment;
}
/**
 * Return the FacultyPage1 property value.
 * @return sis.admin.FacultyPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private FacultyPage getFaculty() {
	if (ivjFaculty == null) {
		try {
			ivjFaculty = new sis.admin.FacultyPage();
			ivjFaculty.setName("Faculty");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFaculty;
}
/**
 * Return the JTabbedPane1 property value.
 * @return com.sun.java.swing.JTabbedPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTabbedPane getInsertTabbedPane() {
	if (ivjInsertTabbedPane == null) {
		try {
			ivjInsertTabbedPane = new com.sun.java.swing.JTabbedPane();
			ivjInsertTabbedPane.setName("InsertTabbedPane");
			ivjInsertTabbedPane.insertTab("Student", null, getStudent(), null, 0);
			ivjInsertTabbedPane.insertTab("Subject", null, getSubject(), null, 1);
			ivjInsertTabbedPane.insertTab("Teacher", null, getTeacher(), null, 2);
			ivjInsertTabbedPane.insertTab("Faculty", null, getFaculty(), null, 3);
			ivjInsertTabbedPane.insertTab("Department", null, getDepartment(), null, 4);
			ivjInsertTabbedPane.insertTab("Semester", null, getSemester(), null, 5);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInsertTabbedPane;
}
/**
 * Return the JButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new com.sun.java.swing.JButton();
			ivjJButton1.setName("JButton1");
			ivjJButton1.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjJButton1.setText("Exit");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButton1;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJFrameContentPane() {
	java.awt.GridBagConstraints constraintsInsertTabbedPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsInsertTabbedPane.gridx = 0; constraintsInsertTabbedPane.gridy = 0;
			constraintsInsertTabbedPane.gridwidth = 1; constraintsInsertTabbedPane.gridheight = 1;
			constraintsInsertTabbedPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsInsertTabbedPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsInsertTabbedPane.weightx = 1.0;
			constraintsInsertTabbedPane.weighty = 1.0;
			constraintsInsertTabbedPane.insets = new java.awt.Insets(5, 5, 5, 5);
			getJFrameContentPane().add(getInsertTabbedPane(), constraintsInsertTabbedPane);

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 1;
			constraintsJPanel1.gridwidth = 3; constraintsJPanel1.gridheight = 3;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.EAST;
			constraintsJPanel1.weightx = 0.0;
			constraintsJPanel1.weighty = 0.0;
			constraintsJPanel1.insets = new java.awt.Insets(5, 5, 5, 5);
			getJFrameContentPane().add(getJPanel1(), constraintsJPanel1);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsJButton1 = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsJButton1.gridx = 1; constraintsJButton1.gridy = 1;
			constraintsJButton1.gridwidth = 1; constraintsJButton1.gridheight = 1;
			constraintsJButton1.anchor = java.awt.GridBagConstraints.EAST;
			constraintsJButton1.weightx = 0.0;
			constraintsJButton1.weighty = 0.0;
			getJPanel1().add(getJButton1(), constraintsJButton1);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the Semester property value.
 * @return sis.admin.SemesterPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SemesterPage getSemester() {
	if (ivjSemester == null) {
		try {
			ivjSemester = new sis.admin.SemesterPage();
			ivjSemester.setName("Semester");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSemester;
}
/**
 * Return the Student property value.
 * @return sis.admin.StudentPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private StudentPage getStudent() {
	if (ivjStudent == null) {
		try {
			ivjStudent = new sis.admin.StudentPage();
			ivjStudent.setName("Student");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjStudent;
}
/**
 * Return the SubjectPage1 property value.
 * @return sis.admin.SubjectPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectPage getSubject() {
	if (ivjSubject == null) {
		try {
			ivjSubject = new sis.admin.SubjectPage();
			ivjSubject.setName("Subject");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject;
}
/**
 * Return the TeacherPage1 property value.
 * @return sis.admin.TeacherPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private TeacherPage getTeacher() {
	if (ivjTeacher == null) {
		try {
			ivjTeacher = new sis.admin.TeacherPage();
			ivjTeacher.setName("Teacher");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTeacher;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJButton1().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	Factory.getAdminDB();
	Factory.getAllFacs();
	Factory.getAllTeachers();
	Factory.getAllTeachIDs();
	Factory.getAllDepts();
	Factory.getAllDeptIDs();
	Factory.getAllDeptNames();
	// user code end
	setName("InsertPage");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(707, 526);
	setTitle("Administrator - Student Information System");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	setVisible(false);
	Dimension screen = getToolkit().getScreenSize();
	Rectangle s = getBounds();
	setBounds ( (screen.width - s.width)/2,
			    (screen.height - s.height)/2,
			  	 s.width,
				 s.height);
	show();
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		InsertPage aInsertPage;
		aInsertPage = new InsertPage();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aInsertPage };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aInsertPage.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
}