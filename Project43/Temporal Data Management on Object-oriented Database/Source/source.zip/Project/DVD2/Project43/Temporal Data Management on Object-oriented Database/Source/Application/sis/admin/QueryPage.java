package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.io.*;
import java.applet.*;

/**
 * This type was created in VisualAge.
 */
public class QueryPage extends JPanel implements java.awt.event.ActionListener {
	private JPanel ivjQueryPane = null;
	private JLabel ivjColNameLabel = null;
	private JTextField ivjColNameTextField = null;
	private JLabel ivjODQLLabel = null;
	private JScrollPane ivjODQLScrollPane = null;
	private JLabel ivjVarNameLabel = null;
	private JTextField ivjVarNameTextField = null;
	private JComboBox ivjVarTypeComboBox = null;
	private JLabel ivjVarTypeLabel = null;
	private JButton ivjAddToolBarButton = null;
	private JButton ivjClearToolBarButton = null;
	private JButton ivjExitToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JDialog ivjJDialog = null;
	private JPanel ivjJDialogContentPane = null;
	private JFrame ivjJFrame1 = null;
	private JPanel ivjJFrameContentPane = null;
	private JToolBar ivjJToolBar = null;
	private com.sun.java.swing.preview.JFileChooser ivjSaveAdminQueryFileChooser1 = null;
	private com.sun.java.swing.preview.JFileChooser ivjSaveAdminQueryFileChooser11 = null;
	private JButton ivjSaveToolBarButton = null;
	private JTextArea ivjODQLTextArea = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public QueryPage() {
	super();
	initialize();
}
/**
 * QueryPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public QueryPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * QueryPage constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public QueryPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * QueryPage constructor comment.
 * @param isDoubleBuffered boolean
 */
public QueryPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC5(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoM1(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC4(e);
	}
	// user code begin {2}
	// user code end
}
public void clear() {

	getVarNameTextField().setText("");
	getColNameTextField().setText("");
	getODQLTextArea().setText("");

	getVarTypeComboBox().removeAllItems();
	getVarTypeComboBox().addItem(new String("Select One"));
	getVarTypeComboBox().addItem(new String("Tuple"));
	getVarTypeComboBox().addItem(new String("Collection"));
	getVarTypeComboBox().setSelectedIndex(0);
	getVarTypeComboBox().repaint();
}
/**
 * connEtoC1:  (ClearToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> QueryPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> QueryPage.readQueryFile(Ljava.io.File;Ljava.io.File;Lcom.sun.java.swing.JTextField;Lcom.sun.java.swing.JComboBox;Lcom.sun.java.swing.JTextField;Lcom.sun.java.swing.JTextArea;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.readQueryFile(getSaveAdminQueryFileChooser11().getCurrentDirectory(), getSaveAdminQueryFileChooser11().getSelectedFile(), getVarNameTextField(), getVarTypeComboBox(), getColNameTextField(), getODQLTextArea());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> QueryPage.writeQueryFile(Ljava.io.File;Ljava.io.File;Ljava.lang.String;Ljava.lang.String;Ljava.lang.String;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.writeQueryFile(getSaveAdminQueryFileChooser1().getCurrentDirectory(), getSaveAdminQueryFileChooser1().getSelectedFile(), getVarNameTextField().getText(), String.valueOf(getVarTypeComboBox().getSelectedItem()), getColNameTextField().getText(), getODQLTextArea().getText());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> QueryPage.query(Lcom.sun.java.swing.JTextField;Lcom.sun.java.swing.JComboBox;Lcom.sun.java.swing.JTextField;Lcom.sun.java.swing.JTextArea;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.query(getVarNameTextField(), getVarTypeComboBox(), getColNameTextField(), getODQLTextArea());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (ExitToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> QueryPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SaveAdminQueryFileChooser11.showOpenDialog(Ljava.awt.Component;)I)
 * @return int
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private int connEtoM1(java.awt.event.ActionEvent arg1) {
	int connEtoM1Result = 0;
	try {
		// user code begin {1}
		// user code end
		connEtoM1Result = getSaveAdminQueryFileChooser11().showOpenDialog(getJFrame1());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
	return connEtoM1Result;
}
/**
 * connEtoM2:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SaveAdminQueryFileChooser1.showSaveDialog(Ljava.awt.Component;)I)
 * @return int
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private int connEtoM2(java.awt.event.ActionEvent arg1) {
	int connEtoM2Result = 0;
	try {
		// user code begin {1}
		// user code end
		connEtoM2Result = getSaveAdminQueryFileChooser1().showSaveDialog(getJDialog());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
	return connEtoM2Result;
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * Return the AddToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getAddToolBarButton() {
	if (ivjAddToolBarButton == null) {
		try {
			ivjAddToolBarButton = new com.sun.java.swing.JButton();
			ivjAddToolBarButton.setName("AddToolBarButton");
			ivjAddToolBarButton.setToolTipText("Open quer file");
			ivjAddToolBarButton.setText("");
			ivjAddToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjAddToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjAddToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\openicon.gif"));
			ivjAddToolBarButton.setPreferredSize(new java.awt.Dimension(22, 23));
			ivjAddToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddToolBarButton;
}
/**
 * Return the ClearToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the QueryColNameLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getColNameLabel() {
	if (ivjColNameLabel == null) {
		try {
			ivjColNameLabel = new com.sun.java.swing.JLabel();
			ivjColNameLabel.setName("ColNameLabel");
			ivjColNameLabel.setText("Column Name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjColNameLabel;
}
/**
 * Return the QueryColNameTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getColNameTextField() {
	if (ivjColNameTextField == null) {
		try {
			ivjColNameTextField = new com.sun.java.swing.JTextField();
			ivjColNameTextField.setName("ColNameTextField");
			ivjColNameTextField.setPreferredSize(new java.awt.Dimension(400, 19));
			ivjColNameTextField.setMinimumSize(new java.awt.Dimension(400, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjColNameTextField;
}
/**
 * Return the ExitToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setToolTipText("Exit");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("Save query file");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the JDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getJDialog() {
	if (ivjJDialog == null) {
		try {
			ivjJDialog = new com.sun.java.swing.JDialog();
			ivjJDialog.setName("JDialog");
			ivjJDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjJDialog.setBounds(809, 75, 530, 240);
			ivjJDialog.setModal(true);
			ivjJDialog.setTitle("Save Query File");
			getJDialog().setContentPane(getJDialogContentPane());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJDialog;
}
/**
 * Return the JDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJDialogContentPane() {
	java.awt.GridBagConstraints constraintsSaveAdminQueryFileChooser1 = new java.awt.GridBagConstraints();
	if (ivjJDialogContentPane == null) {
		try {
			ivjJDialogContentPane = new com.sun.java.swing.JPanel();
			ivjJDialogContentPane.setName("JDialogContentPane");
			ivjJDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsSaveAdminQueryFileChooser1.gridx = 1; constraintsSaveAdminQueryFileChooser1.gridy = 1;
			constraintsSaveAdminQueryFileChooser1.gridwidth = 1; constraintsSaveAdminQueryFileChooser1.gridheight = 1;
			constraintsSaveAdminQueryFileChooser1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsSaveAdminQueryFileChooser1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSaveAdminQueryFileChooser1.weightx = 1.0;
			constraintsSaveAdminQueryFileChooser1.weighty = 1.0;
			getJDialogContentPane().add(getSaveAdminQueryFileChooser1(), constraintsSaveAdminQueryFileChooser1);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJDialogContentPane;
}
/**
 * Return the JFrame1 property value.
 * @return com.sun.java.swing.JFrame
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JFrame getJFrame1() {
	if (ivjJFrame1 == null) {
		try {
			ivjJFrame1 = new com.sun.java.swing.JFrame();
			ivjJFrame1.setName("JFrame1");
			ivjJFrame1.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjJFrame1.setBounds(813, 392, 530, 240);
			ivjJFrame1.setTitle("Open Query File");
			getJFrame1().setContentPane(getJFrameContentPane());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrame1;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJFrameContentPane() {
	java.awt.GridBagConstraints constraintsSaveAdminQueryFileChooser11 = new java.awt.GridBagConstraints();
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsSaveAdminQueryFileChooser11.gridx = 1; constraintsSaveAdminQueryFileChooser11.gridy = 1;
			constraintsSaveAdminQueryFileChooser11.gridwidth = 1; constraintsSaveAdminQueryFileChooser11.gridheight = 1;
			constraintsSaveAdminQueryFileChooser11.fill = java.awt.GridBagConstraints.BOTH;
			constraintsSaveAdminQueryFileChooser11.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSaveAdminQueryFileChooser11.weightx = 1.0;
			constraintsSaveAdminQueryFileChooser11.weighty = 1.0;
			getJFrameContentPane().add(getSaveAdminQueryFileChooser11(), constraintsSaveAdminQueryFileChooser11);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JToolBar property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getJToolBar() {
	if (ivjJToolBar == null) {
		try {
			ivjJToolBar = new com.sun.java.swing.JToolBar();
			ivjJToolBar.setName("JToolBar");
			ivjJToolBar.add(getClearToolBarButton());
			ivjJToolBar.addSeparator();
			getJToolBar().add(getAddToolBarButton(), getAddToolBarButton().getName());
			getJToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjJToolBar.addSeparator();
			getJToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			ivjJToolBar.addSeparator();
			getJToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJToolBar;
}
/**
 * Return the QueryODQLLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getODQLLabel() {
	if (ivjODQLLabel == null) {
		try {
			ivjODQLLabel = new com.sun.java.swing.JLabel();
			ivjODQLLabel.setName("ODQLLabel");
			ivjODQLLabel.setText("ODQL");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjODQLLabel;
}
/**
 * Return the QueryODQLScrollPane property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JScrollPane getODQLScrollPane() {
	if (ivjODQLScrollPane == null) {
		try {
			ivjODQLScrollPane = new com.sun.java.swing.JScrollPane();
			ivjODQLScrollPane.setName("ODQLScrollPane");
			ivjODQLScrollPane.setAutoscrolls(true);
			ivjODQLScrollPane.setVerticalScrollBarPolicy(com.sun.java.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			ivjODQLScrollPane.setHorizontalScrollBarPolicy(com.sun.java.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			ivjODQLScrollPane.setPreferredSize(new java.awt.Dimension(400, 300));
			ivjODQLScrollPane.setMinimumSize(new java.awt.Dimension(400, 300));
			getODQLScrollPane().setViewportView(getODQLTextArea());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjODQLScrollPane;
}
/**
 * Return the JTextArea1 property value.
 * @return com.sun.java.swing.JTextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextArea getODQLTextArea() {
	if (ivjODQLTextArea == null) {
		try {
			ivjODQLTextArea = new com.sun.java.swing.JTextArea();
			ivjODQLTextArea.setName("ODQLTextArea");
			ivjODQLTextArea.setBounds(0, 0, 15, 19);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjODQLTextArea;
}
/**
 * Return the QueryPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getQueryPane() {
	java.awt.GridBagConstraints constraintsVarNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsVarTypeLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsColNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsODQLLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsVarNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsVarTypeComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsColNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsODQLScrollPane = new java.awt.GridBagConstraints();
	if (ivjQueryPane == null) {
		try {
			ivjQueryPane = new com.sun.java.swing.JPanel();
			ivjQueryPane.setName("QueryPane");
			ivjQueryPane.setLayout(new java.awt.GridBagLayout());

			constraintsVarNameLabel.gridx = 0; constraintsVarNameLabel.gridy = 0;
			constraintsVarNameLabel.gridwidth = 1; constraintsVarNameLabel.gridheight = 1;
			constraintsVarNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsVarNameLabel.weightx = 0.0;
			constraintsVarNameLabel.weighty = 0.0;
			constraintsVarNameLabel.insets = new java.awt.Insets(20, 10, 5, 10);
			getQueryPane().add(getVarNameLabel(), constraintsVarNameLabel);

			constraintsVarTypeLabel.gridx = 0; constraintsVarTypeLabel.gridy = 1;
			constraintsVarTypeLabel.gridwidth = 1; constraintsVarTypeLabel.gridheight = 1;
			constraintsVarTypeLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsVarTypeLabel.weightx = 0.0;
			constraintsVarTypeLabel.weighty = 0.0;
			getQueryPane().add(getVarTypeLabel(), constraintsVarTypeLabel);

			constraintsColNameLabel.gridx = 0; constraintsColNameLabel.gridy = 2;
			constraintsColNameLabel.gridwidth = 1; constraintsColNameLabel.gridheight = 1;
			constraintsColNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsColNameLabel.weightx = 0.0;
			constraintsColNameLabel.weighty = 0.0;
			constraintsColNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getQueryPane().add(getColNameLabel(), constraintsColNameLabel);

			constraintsODQLLabel.gridx = 0; constraintsODQLLabel.gridy = 3;
			constraintsODQLLabel.gridwidth = 1; constraintsODQLLabel.gridheight = 1;
			constraintsODQLLabel.anchor = java.awt.GridBagConstraints.NORTHEAST;
			constraintsODQLLabel.weightx = 0.0;
			constraintsODQLLabel.weighty = 0.0;
			constraintsODQLLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getQueryPane().add(getODQLLabel(), constraintsODQLLabel);

			constraintsVarNameTextField.gridx = 1; constraintsVarNameTextField.gridy = 0;
			constraintsVarNameTextField.gridwidth = 1; constraintsVarNameTextField.gridheight = 1;
			constraintsVarNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsVarNameTextField.weightx = 0.0;
			constraintsVarNameTextField.weighty = 0.0;
			constraintsVarNameTextField.insets = new java.awt.Insets(20, 0, 5, 10);
			getQueryPane().add(getVarNameTextField(), constraintsVarNameTextField);

			constraintsVarTypeComboBox.gridx = 1; constraintsVarTypeComboBox.gridy = 1;
			constraintsVarTypeComboBox.gridwidth = 1; constraintsVarTypeComboBox.gridheight = 1;
			constraintsVarTypeComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsVarTypeComboBox.weightx = 0.0;
			constraintsVarTypeComboBox.weighty = 0.0;
			constraintsVarTypeComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getQueryPane().add(getVarTypeComboBox(), constraintsVarTypeComboBox);

			constraintsColNameTextField.gridx = 1; constraintsColNameTextField.gridy = 2;
			constraintsColNameTextField.gridwidth = 1; constraintsColNameTextField.gridheight = 1;
			constraintsColNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsColNameTextField.weightx = 0.0;
			constraintsColNameTextField.weighty = 0.0;
			constraintsColNameTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getQueryPane().add(getColNameTextField(), constraintsColNameTextField);

			constraintsODQLScrollPane.gridx = 1; constraintsODQLScrollPane.gridy = 3;
			constraintsODQLScrollPane.gridwidth = 1; constraintsODQLScrollPane.gridheight = 1;
			constraintsODQLScrollPane.anchor = java.awt.GridBagConstraints.WEST;
			constraintsODQLScrollPane.weightx = 0.0;
			constraintsODQLScrollPane.weighty = 0.0;
			constraintsODQLScrollPane.insets = new java.awt.Insets(0, 0, 5, 10);
			getQueryPane().add(getODQLScrollPane(), constraintsODQLScrollPane);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjQueryPane;
}
/**
 * Return the SaveAdminQueryFileChooser1 property value.
 * @return com.sun.java.swing.preview.JFileChooser
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.preview.JFileChooser getSaveAdminQueryFileChooser1() {
	if (ivjSaveAdminQueryFileChooser1 == null) {
		try {
			ivjSaveAdminQueryFileChooser1 = new com.sun.java.swing.preview.JFileChooser();
			ivjSaveAdminQueryFileChooser1.setName("SaveAdminQueryFileChooser1");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveAdminQueryFileChooser1;
}
/**
 * Return the SaveAdminQueryFileChooser11 property value.
 * @return com.sun.java.swing.preview.JFileChooser
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.preview.JFileChooser getSaveAdminQueryFileChooser11() {
	if (ivjSaveAdminQueryFileChooser11 == null) {
		try {
			ivjSaveAdminQueryFileChooser11 = new com.sun.java.swing.preview.JFileChooser();
			ivjSaveAdminQueryFileChooser11.setName("SaveAdminQueryFileChooser11");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveAdminQueryFileChooser11;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Query");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the QueryVarNameLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getVarNameLabel() {
	if (ivjVarNameLabel == null) {
		try {
			ivjVarNameLabel = new com.sun.java.swing.JLabel();
			ivjVarNameLabel.setName("VarNameLabel");
			ivjVarNameLabel.setText("Variable Name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjVarNameLabel;
}
/**
 * Return the QueryVarNameTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getVarNameTextField() {
	if (ivjVarNameTextField == null) {
		try {
			ivjVarNameTextField = new com.sun.java.swing.JTextField();
			ivjVarNameTextField.setName("VarNameTextField");
			ivjVarNameTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjVarNameTextField;
}
/**
 * Return the QueryVarTypeComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getVarTypeComboBox() {
	if (ivjVarTypeComboBox == null) {
		try {
			ivjVarTypeComboBox = new com.sun.java.swing.JComboBox();
			ivjVarTypeComboBox.setName("VarTypeComboBox");
			ivjVarTypeComboBox.setPreferredSize(new java.awt.Dimension(130, 20));
			ivjVarTypeComboBox.setMinimumSize(new java.awt.Dimension(126, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjVarTypeComboBox;
}
/**
 * Return the QueryVarTypeLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getVarTypeLabel() {
	if (ivjVarTypeLabel == null) {
		try {
			ivjVarTypeLabel = new com.sun.java.swing.JLabel();
			ivjVarTypeLabel.setName("VarTypeLabel");
			ivjVarTypeLabel.setText("Variable Type");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjVarTypeLabel;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
	getAddToolBarButton().addActionListener(this);
	getFindToolBarButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsQueryPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJToolBar = new java.awt.GridBagConstraints();
	setName("QueryPage");
	setLayout(new java.awt.GridBagLayout());
	setSize(548, 474);

	constraintsQueryPane.gridx = 0; constraintsQueryPane.gridy = 1;
	constraintsQueryPane.gridwidth = 1; constraintsQueryPane.gridheight = 1;
	constraintsQueryPane.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsQueryPane.weightx = 0.0;
	constraintsQueryPane.weighty = 0.0;
	add(getQueryPane(), constraintsQueryPane);

	constraintsJToolBar.gridx = 0; constraintsJToolBar.gridy = 0;
	constraintsJToolBar.gridwidth = 1; constraintsJToolBar.gridheight = 1;
	constraintsJToolBar.fill = java.awt.GridBagConstraints.HORIZONTAL;
	constraintsJToolBar.anchor = java.awt.GridBagConstraints.WEST;
	constraintsJToolBar.weightx = 0.0;
	constraintsJToolBar.weighty = 0.0;
	add(getJToolBar(), constraintsJToolBar);
	initConnections();
	// user code begin {2}
	getVarTypeComboBox().removeAllItems();
	getVarTypeComboBox().addItem(new String("Select One"));
	getVarTypeComboBox().addItem(new String("Tuple"));
	getVarTypeComboBox().addItem(new String("Collection"));
	getVarTypeComboBox().setSelectedIndex(0);
	getVarTypeComboBox().repaint();
	
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		QueryPage aQueryPage;
		aQueryPage = new QueryPage();
		frame.getContentPane().add("Center", aQueryPage);
		frame.setSize(aQueryPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @param varName com.sun.java.swing.JTextField
 * @param varType com.sun.java.swing.JComboBox
 * @param colName com.sun.java.swing.JTextField
 * @param queryCode com.sun.java.swing.JTextArea
 */
public void query(JTextField varName, JComboBox varType, JTextField colName, JTextArea queryCode) {
	
	QueryResult queryResult = new QueryResult( varName.getText(),
											   varType.getSelectedItem().toString(), 
											   colName.getText(), 
											   queryCode.getText() );

	queryResult.addRowToTable();
	queryResult.show();

}
/**
 * This method was created in VisualAge.
 * @param varName com.sun.java.swing.JTextField
 * @param varType com.sun.java.swing.JComboBox
 * @param colName com.sun.java.swing.JTextField
 * @param queryCode com.sun.java.swing.JTextArea
 */
public void query(QueryModel qModel) {

	
	QueryResult queryResult = new QueryResult(qModel);
	queryResult.addRowToTable();
	queryResult.show();
	
}
/**
 * This method was created in VisualAge.
 * @param dirName java.io.File
 * @param fileName java.io.File
 * @param varName JTextField
 * @param varType JComboBox
 * @param colName JTextField
 * @param queryCode JTextArea
 */
public void readQueryFile(File dirName, File fileName, JTextField varName, JComboBox varType, JTextField colName, JTextArea queryCode) {


		FileReader fileInStream = null;
		BufferedReader dataInStream;
		String result;
		String crlf = System.getProperties().getProperty("line.separator");

		// if valid directory and filenames have been passed in, 
		// read the file and fill the list
		if ((dirName != null) && (fileName != null)) {
		   try {
				   fileInStream= new FileReader(fileName);
		   }
		   catch (IOException e) { 
				   System.err.println
				   ("IO exception opening Query File " +fileName);
				   return;       
		   }
		   dataInStream = new BufferedReader(fileInStream);
		   // clear the existing entries from the list
		   clear();
		   
		   try {
				   // for each line in the file create an item in the list
				   if ((result = dataInStream.readLine()) != null)  {
						   if (result.length() != 0)
								   varName.setText(result);                                                 
				   }
				   if ((result = dataInStream.readLine()) != null)  {
						   if (result.length() != 0)
								   if ( result.equals( varType.getItemAt(0) )) varType.setSelectedIndex(0);
								   else varType.setSelectedIndex(1);

								   								   
				   }
				   if ((result = dataInStream.readLine()) != null)  {
						   if (result.length() != 0)
								    colName.setText(result);
								   				   }
				   while ((result = dataInStream.readLine()) != null)  {
						   if (result.length() != 0)
								   queryCode.setText( queryCode.getText() + result + crlf);                                                 
				   }
		   }
		   catch (IOException e) {System.err.println
				 ("IO exception reading Query File " +fileName);}
		   try {
				   fileInStream.close();
				   dataInStream.close();
		   }
		   catch (IOException e) { System.err.println
				 ("IO exception closing Query File " +fileName);}       
		}
		else {
				System.err.println
				   ("Null file name and/or directory reading Query File");      
		}       
	return;	
	
	
		
	
}
public void writeQueryFile(File dirName, File fileName, String varName, String varType, String colName, String queryCode) {

  
		QueryModel	qModel = new QueryModel(varName, varType, colName, queryCode);
	
		FileWriter fileOutStream = null;
		PrintWriter dataOutStream;
		// carriage return and line feed constant
		String crlf = System.getProperties().getProperty("line.separator");
		// if valid directory and filenames passed, write the file from the Model
		if ((dirName != null) && (fileName != null)) {
				try {
						fileOutStream = new FileWriter(fileName);
				}
				catch (IOException e) { 
						System.err.println
						("IO exception opening Query file " +fileName); 
						return;
				}
				dataOutStream = new PrintWriter(fileOutStream);
				// for every item in the list, write a line to the output file
				/*for (int i = 0; i < e(); i++) {
						try {
								dataOutStream.write(fillList.get(i)+crlf);
						}
						catch (Exception e) { System.err.println
						("Exception writing To-Do File "  +fileName);}
				}*/



				try{

					dataOutStream.write(varName+crlf);
					dataOutStream.write(varType+crlf);
					dataOutStream.write(colName+crlf);
					dataOutStream.write(queryCode+crlf);

				} catch (Exception e) { 
					System.err.println ("Exception writing Query File "  +fileName);}
				

				
				try {
						fileOutStream.close();
						dataOutStream.close();
				}
				catch (IOException e) { System.err.println
				("IO exception closing To-Do File " +fileName);}        
		}       
		else {
				System.err.println
				("Null file name and/or directory writing To-Do File"); 
		}
		return;	
}
}