package sis.util;

import java.lang.*;
import java.awt.*;
import java.util.*;
/**
 * This type was created in VisualAge.
 */
public class QueryModel {

	public String varName,varType,queryCode;
	public Vector colName;

/**
 * This method was created in VisualAge.
 */
public QueryModel() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param varName java.lang.String
 * @param typeVar java.lang.String
 * @param colName java.lang.String
 * @param queryCode java.lang.String
 */
public QueryModel(String varName, String varType, String colName, String queryCode) {
	
	
	int		i;
	String	comma 		= new String(",");
	String	tempStr 	= new String("");
	char	ele;
				
	
	this.varName 	= new String(varName);
	this.varType 	= new String(varType);
	this.queryCode	= new String(queryCode);
	this.colName 	= new Vector();

//	System.out.println(colName);
	

	
	for ( i = 0; i < colName.length(); i++ ){

//		System.out.print(i+"   ");
		ele = colName.charAt(i);
//		System.out.println(ele);

		if ( ele == ',' ){
			
//			System.out.println(tempStr);
			this.colName.addElement( tempStr );
			tempStr = "";
		} else { tempStr = tempStr + ele;
		
					}
	}

//	System.out.println(tempStr);
	this.colName.addElement( tempStr );


}
/**
 * This method was created in VisualAge.
 * @return java.lang.Object
 * @param pos int
 */
public Object getColName(int pos) {

		
	
	return colName.elementAt(pos);
}
/**
 * This method was created in VisualAge.
 * @return int
 */
public int getNumberOfCol() {

	return colName.size();
}
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[]) {

	String varName = new String("allEmps");
	String varType = new String("Tuple");
	String colName = new String("ID,Name,Address");
	String queryCode = new String("ODQL");

	QueryModel query = new QueryModel(varName,varType,colName,queryCode);

//	System.out.println( query.getNumberOfCol() );

	for ( int i = 0; i < query.getNumberOfCol(); i++){

		System.out.println( query.getColName(i).toString() );
	}

	System.out.println(query.varName);
	System.out.println(query.varType);
	System.out.println(query.colName);
	System.out.println(query.queryCode);

}
}