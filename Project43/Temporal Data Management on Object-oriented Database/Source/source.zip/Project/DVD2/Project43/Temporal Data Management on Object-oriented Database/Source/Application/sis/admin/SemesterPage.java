package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;

/**
 * This type was created in VisualAge.
 */
public class SemesterPage extends JPanel implements java.awt.event.ActionListener {
	private JButton ivjClearToolBarButton = null;
	private JTextPane ivjDescription = null;
	private JButton ivjExitToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JPanel ivjJPanel1 = null;
	private JButton ivjSaveToolBarButton = null;
	private JToolBar ivjToolBar = null;
	private JPanel ivjJPanel2 = null;
	private JPanel ivjJPanel3 = null;
	private JLabel ivjDefaultTermLabel = null;
	private JTextField ivjDefaultTermTextField = null;
	private JLabel ivjDefaultYearLabel = null;
	private JTextField ivjDefaultYearTextField = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public SemesterPage() {
	super();
	initialize();
}
/**
 * Semester constructor comment.
 * @param layout java.awt.LayoutManager
 */
public SemesterPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Semester constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public SemesterPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * Semester constructor comment.
 * @param isDoubleBuffered boolean
 */
public SemesterPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC4(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void clear() {
	getDefaultYearTextField().setText("");
	getDefaultTermTextField().setText("");
}
/**
 * connEtoC1:  (ClearToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SemesterPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SemesterPage.find()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.find();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SemesterPage.update()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.update();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (ExitToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> SemesterPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
public void find() throws Exception, java.rmi.RemoteException {
	try{
		//Start Tx
		Factory.getAdminDB().startTransaction();

		getDefaultYearTextField().setText( Semester.getDefaultyear(Factory.getAdminDB()) );
		getDefaultTermTextField().setText( Semester.getDefaultterm(Factory.getAdminDB()) );


		//Enable & disable some toolbar bottons
		getSaveToolBarButton().setEnabled(true);
		
		//End Tx
		Factory.getAdminDB().endTransaction();
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in find() from sis.admin.SemesterPage\n" + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in find() from sis.admin.SemesterPage\n" + e.getMessage() );
		e.printStackTrace();
	}
	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();

}
/**
 * Return the ClearToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the JLabel2 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDefaultTermLabel() {
	if (ivjDefaultTermLabel == null) {
		try {
			ivjDefaultTermLabel = new com.sun.java.swing.JLabel();
			ivjDefaultTermLabel.setName("DefaultTermLabel");
			ivjDefaultTermLabel.setText("Default Term");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDefaultTermLabel;
}
/**
 * Return the JTextField2 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getDefaultTermTextField() {
	if (ivjDefaultTermTextField == null) {
		try {
			ivjDefaultTermTextField = new com.sun.java.swing.JTextField();
			ivjDefaultTermTextField.setName("DefaultTermTextField");
			ivjDefaultTermTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDefaultTermTextField;
}
/**
 * Return the JLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDefaultYearLabel() {
	if (ivjDefaultYearLabel == null) {
		try {
			ivjDefaultYearLabel = new com.sun.java.swing.JLabel();
			ivjDefaultYearLabel.setName("DefaultYearLabel");
			ivjDefaultYearLabel.setPreferredSize(new java.awt.Dimension(85, 15));
			ivjDefaultYearLabel.setText("Default Year");
			ivjDefaultYearLabel.setMinimumSize(new java.awt.Dimension(85, 15));
			ivjDefaultYearLabel.setHorizontalAlignment(com.sun.java.swing.SwingConstants.RIGHT);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDefaultYearLabel;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getDefaultYearTextField() {
	if (ivjDefaultYearTextField == null) {
		try {
			ivjDefaultYearTextField = new com.sun.java.swing.JTextField();
			ivjDefaultYearTextField.setName("DefaultYearTextField");
			ivjDefaultYearTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDefaultYearTextField;
}
/**
 * Return the Description property value.
 * @return com.sun.java.swing.JTextPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextPane getDescription() {
	if (ivjDescription == null) {
		try {
			ivjDescription = new com.sun.java.swing.JTextPane();
			ivjDescription.setName("Description");
			ivjDescription.setPreferredSize(new java.awt.Dimension(300, 70));
			ivjDescription.setText("Default year value and default term value will obtain automatically to year and term property of Semester object when student register.\n");
			ivjDescription.setBackground(new java.awt.Color(204,204,204));
			ivjDescription.setMinimumSize(new java.awt.Dimension(150, 145));
			// user code begin {1}
			Border empty;
			empty = BorderFactory.createEmptyBorder(0,10,10,10);
			ivjDescription.setBorder(empty);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDescription;
}
/**
 * Return the ExitToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setToolTipText("Exit");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("View");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsDefaultYearLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDefaultTermLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDefaultYearTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDefaultTermTextField = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsDefaultYearLabel.gridx = 0; constraintsDefaultYearLabel.gridy = 0;
			constraintsDefaultYearLabel.gridwidth = 1; constraintsDefaultYearLabel.gridheight = 1;
			constraintsDefaultYearLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDefaultYearLabel.weightx = 0.0;
			constraintsDefaultYearLabel.weighty = 0.0;
			constraintsDefaultYearLabel.insets = new java.awt.Insets(10, 10, 5, 10);
			getJPanel1().add(getDefaultYearLabel(), constraintsDefaultYearLabel);

			constraintsDefaultTermLabel.gridx = 0; constraintsDefaultTermLabel.gridy = 1;
			constraintsDefaultTermLabel.gridwidth = 1; constraintsDefaultTermLabel.gridheight = 1;
			constraintsDefaultTermLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDefaultTermLabel.weightx = 0.0;
			constraintsDefaultTermLabel.weighty = 0.0;
			constraintsDefaultTermLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getJPanel1().add(getDefaultTermLabel(), constraintsDefaultTermLabel);

			constraintsDefaultYearTextField.gridx = 1; constraintsDefaultYearTextField.gridy = 0;
			constraintsDefaultYearTextField.gridwidth = 1; constraintsDefaultYearTextField.gridheight = 1;
			constraintsDefaultYearTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsDefaultYearTextField.weightx = 0.0;
			constraintsDefaultYearTextField.weighty = 0.0;
			constraintsDefaultYearTextField.insets = new java.awt.Insets(10, 0, 5, 10);
			getJPanel1().add(getDefaultYearTextField(), constraintsDefaultYearTextField);

			constraintsDefaultTermTextField.gridx = 1; constraintsDefaultTermTextField.gridy = 1;
			constraintsDefaultTermTextField.gridwidth = 1; constraintsDefaultTermTextField.gridheight = 1;
			constraintsDefaultTermTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsDefaultTermTextField.weightx = 0.0;
			constraintsDefaultTermTextField.weighty = 0.0;
			constraintsDefaultTermTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getJPanel1().add(getDefaultTermTextField(), constraintsDefaultTermTextField);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel3 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDescription = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 1; constraintsJPanel1.gridy = 2;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 0.0;
			constraintsJPanel1.weighty = 0.0;
			getJPanel2().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel3.gridx = 2; constraintsJPanel3.gridy = 2;
			constraintsJPanel3.gridwidth = 1; constraintsJPanel3.gridheight = 1;
			constraintsJPanel3.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel3.weightx = 0.0;
			constraintsJPanel3.weighty = 0.0;
			getJPanel2().add(getJPanel3(), constraintsJPanel3);

			constraintsDescription.gridx = 1; constraintsDescription.gridy = 0;
			constraintsDescription.gridwidth = 1; constraintsDescription.gridheight = 1;
			constraintsDescription.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDescription.weightx = 0.0;
			constraintsDescription.weighty = 0.0;
			getJPanel2().add(getDescription(), constraintsDescription);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the JPanel3 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel3() {
	if (ivjJPanel3 == null) {
		try {
			ivjJPanel3 = new com.sun.java.swing.JPanel();
			ivjJPanel3.setName("JPanel3");
			ivjJPanel3.setLayout(new java.awt.GridBagLayout());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel3;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Save change");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the ToolBar property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getToolBar() {
	if (ivjToolBar == null) {
		try {
			ivjToolBar = new com.sun.java.swing.JToolBar();
			ivjToolBar.setName("ToolBar");
			ivjToolBar.add(getClearToolBarButton());
			ivjToolBar.addSeparator();
			getToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjToolBar;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getFindToolBarButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsToolBar = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	setName("Semester");
	setLayout(new java.awt.GridBagLayout());
	setSize(448, 425);

	constraintsToolBar.gridx = 1; constraintsToolBar.gridy = 1;
	constraintsToolBar.gridwidth = 1; constraintsToolBar.gridheight = 1;
	constraintsToolBar.fill = java.awt.GridBagConstraints.HORIZONTAL;
	constraintsToolBar.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsToolBar.weightx = 0.0;
	constraintsToolBar.weighty = 0.0;
	add(getToolBar(), constraintsToolBar);

	constraintsJPanel2.gridx = 1; constraintsJPanel2.gridy = 2;
	constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
	constraintsJPanel2.fill = java.awt.GridBagConstraints.BOTH;
	constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsJPanel2.weightx = 1.0;
	constraintsJPanel2.weighty = 1.0;
	add(getJPanel2(), constraintsJPanel2);
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		JFrame frame = new com.sun.java.swing.JFrame();
		SemesterPage aSemesterPage;
		aSemesterPage = new SemesterPage();
		frame.getContentPane().add("Center", aSemesterPage);
		frame.setSize(aSemesterPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
public void update() throws Exception, java.rmi.RemoteException{

	Message m = new Message();

	//Set if there's update
	boolean update = false;
	
	try{
		//Strat Tx
		Factory.getAdminDB().startTransaction();

		if ( !getDefaultYearTextField().getText().equals( 
			Semester.getDefaultyear(Factory.getAdminDB())) ){
			Semester.setDefaultyear(Factory.getAdminDB(), 
				getDefaultYearTextField().getText());
			update = true;
		}

		if ( !getDefaultTermTextField().getText().equals( 
			Semester.getDefaultterm(Factory.getAdminDB())) ){
			Semester.setDefaultterm(Factory.getAdminDB(), 
				getDefaultTermTextField().getText());
			update = true;
		}

		if ( update ){

			m.show("Semester has been updated.");
		} else m.show("Semester Information hasn't been changed.");
		
		//End Tx
		Factory.getAdminDB().endTransaction();
	  
	} catch (DatabaseException dbe){
		System.out.println("Database Error in update() from sis.admin.SemesterPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
}