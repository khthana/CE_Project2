package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class Query extends JFrame implements java.awt.event.ActionListener {
	private JButton ivjExitButton = null;
	private JPanel ivjJFrameContentPane = null;
	private JPanel ivjJPanel1 = null;
	private JTabbedPane ivjJTabbedPane1 = null;
	private QueryPage ivjQuery = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public Query() {
	super();
	initialize();
}
/**
 * Query constructor comment.
 * @param title java.lang.String
 */
public Query(String title) {
	super(title);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getExitButton()) ) {
		connEtoC1(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (ExitButton.action.actionPerformed(java.awt.event.ActionEvent) --> Query.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
public void exit() {
	//Factory.disconnect( Factory.getQueryDB() );
	System.exit(0);
}
/**
 * Return the ExitButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitButton() {
	if (ivjExitButton == null) {
		try {
			ivjExitButton = new com.sun.java.swing.JButton();
			ivjExitButton.setName("ExitButton");
			ivjExitButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjExitButton.setText("Exit");
			ivjExitButton.setMinimumSize(new java.awt.Dimension(85, 25));
			ivjExitButton.setMaximumSize(new java.awt.Dimension(85, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitButton;
}
/**
 * Return the JFrameContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJFrameContentPane() {
	java.awt.GridBagConstraints constraintsJTabbedPane1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new com.sun.java.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane");
			ivjJFrameContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJTabbedPane1.gridx = 0; constraintsJTabbedPane1.gridy = 0;
			constraintsJTabbedPane1.gridwidth = 1; constraintsJTabbedPane1.gridheight = 1;
			constraintsJTabbedPane1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJTabbedPane1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJTabbedPane1.weightx = 1.0;
			constraintsJTabbedPane1.weighty = 1.0;
			constraintsJTabbedPane1.insets = new java.awt.Insets(5, 5, 5, 5);
			getJFrameContentPane().add(getJTabbedPane1(), constraintsJTabbedPane1);

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 1;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.EAST;
			constraintsJPanel1.weightx = 0.0;
			constraintsJPanel1.weighty = 0.0;
			constraintsJPanel1.insets = new java.awt.Insets(5, 0, 10, 10);
			getJFrameContentPane().add(getJPanel1(), constraintsJPanel1);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJFrameContentPane;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsExitButton = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsExitButton.gridx = 1; constraintsExitButton.gridy = 1;
			constraintsExitButton.gridwidth = 1; constraintsExitButton.gridheight = 1;
			constraintsExitButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsExitButton.weightx = 0.0;
			constraintsExitButton.weighty = 0.0;
			getJPanel1().add(getExitButton(), constraintsExitButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JTabbedPane1 property value.
 * @return com.sun.java.swing.JTabbedPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTabbedPane getJTabbedPane1() {
	if (ivjJTabbedPane1 == null) {
		try {
			ivjJTabbedPane1 = new com.sun.java.swing.JTabbedPane();
			ivjJTabbedPane1.setName("JTabbedPane1");
			ivjJTabbedPane1.insertTab("General", null, getQuery(), null, 0);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJTabbedPane1;
}
/**
 * Return the Query property value.
 * @return sis.admin.QueryPage
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private QueryPage getQuery() {
	if (ivjQuery == null) {
		try {
			ivjQuery = new sis.admin.QueryPage();
			ivjQuery.setName("Query");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjQuery;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getExitButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	Factory.getQueryDB();
	// user code end
	setName("Query");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(535, 544);
	setTitle("Query - Student Information System");
	setContentPane(getJFrameContentPane());
	initConnections();
	// user code begin {2}
	setVisible(false);
	Dimension screen = getToolkit().getScreenSize();
	Rectangle s = getBounds();
	setBounds ( (screen.width - s.width)/2,
			    (screen.height - s.height)/2,
			  	 s.width,
				 s.height);
	show();
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		Query aQuery;
		aQuery = new Query();
		try {
			Class aCloserClass = Class.forName("com.ibm.uvm.abt.edit.WindowCloser");
			Class parmTypes[] = { java.awt.Window.class };
			Object parms[] = { aQuery };
			java.lang.reflect.Constructor aCtor = aCloserClass.getConstructor(parmTypes);
			aCtor.newInstance(parms);
		} catch (java.lang.Throwable exc) {};
		aQuery.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JFrame");
		exception.printStackTrace(System.out);
	}
}
}