package sis.util;

import java.lang.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import com.sun.java.swing.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;

/**
 * This type was created in VisualAge.
 */
public class Factory {
	public static java.sql.Date currentDate = null;
	public static java.sql.Date foreverDate = null;
	public static Database adminDB = null;
	public static Vector allFacs = null;
	public static Vector allTeachers = null;
	public static Vector allDepts = null;
	public static Vector allFacNames;
	public static Vector realDeptPos = null;
	public static Vector allTeachIDs = null;
	public static Vector allDeptIDs = null;
	public static Vector allDeptNames = null;
	public static Database queryDB = null;
	public static Database stdDB = null;
/**
 * Factory constructor comment.
 */
public Factory() {
	super();
}
/**
 * This method was created in VisualAge.
 * @param box JComboBox
 */
public static void addDeptToBox(JComboBox box,int select) {

	System.out.println("addDeptToBox() from sis.util.Factory has started . . ." );
	box.removeAllItems();
	box.addItem(new String("Select Department"));
	getRealDeptPos().removeAllElements();
	getAllDepts();

	//Argument of Procedure in ODQL
	Object arg[] = new Object[0];
	
	try {
		Factory.getAdminDB().startTransaction();
		
		DBObject	selectedFac		=	(DBObject)	getAllFacs().elementAt( select-1 );
		DBObject	selectedFac_ID	=	(DBObject)	selectedFac.execMethod("getCurrentID",arg);
		String		selectedFacID	=				selectedFac_ID.getProperty("ID").toString();
		String 		deptFacPair[]	=	new String[2];

		for (int i = 0; i < getAllDeptIDs().size(); i++) {

			deptFacPair	=	(String[])	getAllDeptIDs().elementAt(i);

			if ( selectedFacID.equals( deptFacPair[1] ) ){
				//Add Department to box
				box.addItem( getAllDeptNames().elementAt(i).toString() );
				getRealDeptPos().addElement( new Integer(i) );
			}
		}


		box.setSelectedIndex(0);
		box.repaint();

		Factory.getAdminDB().endTransaction();
		
		System.out.println("addDeptToBox() from sis.util.Factory has Finished.");
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in addDeptToBox(JComboBox,int) from sis.util.Factory\n" + dbe.getMessage());
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in addDeptToBox(JComboBox,int) from sis.util.Factory\n" + e.getMessage());
		e.printStackTrace();
	}
	
}
public static void addFacultyToBox(com.sun.java.swing.JComboBox box) {

	box.removeAllItems();
	box.addItem(new String("Select Faculty"));

	//Argument of Procedure in ODQL
	Object arg[] = new Object[0];
	getAllFacs();
	try {
		
		for (int i = 0; i < getAllFacs().size(); i++) {
			
			getAdminDB().startTransaction();
			
			DBObject fac = (DBObject) getAllFacs().elementAt(i);
			DBObject fac_eName = (DBObject) fac.execMethod("getCurrentName",arg);
			String name = (String) fac_eName.getProperty("eName");
			box.addItem( name );
			
			getAdminDB().endTransaction();
		}

		box.setSelectedIndex(0);
		System.out.println("addFacultyToBox() from sis.util.Factory has Finished.");

		

		
	} catch (DatabaseException dbe){
		System.out.println("Error in addFacultyToBox(JComboBox) from sis.util.Factory \n" + dbe.getMessage() + "\n\n" );
		dbe.printStackTrace();
	}
}
		
public static void addTeacherToBox(com.sun.java.swing.JComboBox box) {

	box.removeAllItems();
	box.addItem(new String("Select Teacher"));

	//Argument of Procedure in ODQL
	Object arg[] = new Object[0];
	getAllTeachers();
	try {
		
		for (int i = 0; i < getAllTeachers().size(); i++) {
			
			getAdminDB().startTransaction();
			
			DBObject teacher     = (DBObject) getAllTeachers().elementAt(i);
			DBObject teach_eName = (DBObject) teacher.execMethod("getCurrentName",arg);
			String name = (String) teach_eName.getProperty("eName");
			box.addItem( name );
			getAdminDB().endTransaction();
		}

		System.out.println("addTeacherToBox() from sis.util.Factory has Finished.");
		
	} catch (DatabaseException dbe){
		System.out.println("Error in addTeacherToBox(JComboBox) from sis.util.Factory \n" + dbe.getMessage() + "\n\n" );
	}
}
		
/**
 * This method was created in VisualAge.
 */
public static void  disconnect() {

	getAdminDB();
}
/**
 * This method was created in VisualAge.
 */
public static void  disconnect(Database db) {

	
		try {
			db.endSession();
		} catch (DatabaseException dbe) {
			System.out.println("Error in disconnect(Database) from sis.util.Factory \n" 
				+ dbe.getMessage());
			dbe.printStackTrace();
		}
	
	
}
/**
 * This method was created in VisualAge.
 * @return jp.jasmine.japi.Database
 */
public static jp.jasmine.japi.Database getAdminDB() {
	if (adminDB == null) {
		try {
			adminDB = new Database();
			adminDB.startSession();
			String que = new String();
			{
				Vector q2 = new Vector();
				q2.addElement(new String("defaultCF 		TempCF;"));
				q2.addElement(new String("Teacher 			teacher;"));
				q2.addElement(new String("Set<Teacher>		allTeachers;"));
				q2.addElement(new String("Faculty 			fac;"));
				q2.addElement(new String("Set<Faculty>		allFacs;"));
				q2.addElement(new String("Department 		Dept;"));
				q2.addElement(new String("Set<Department>	allDepts;"));
				q2.addElement(new String("Set<systemCF::String>	allFacNames;"));
				q2.addElement(new String("systemCF::Date  			vts,vte;"));
				for (int i = 0; i < q2.size(); i++)
					que = que + q2.elementAt(i).toString();
			}

			adminDB.startTransaction();
			ODQLStatement query = Factory.adminDB.getODQLStatement();
			query.execute(que);
			adminDB.endTransaction();

		} catch (DatabaseException dbe) {
			System.out.println("Error in getAdminDB() from sis.util.Factory\n" + dbe.getMessage());
			dbe.printStackTrace();
		}
	}
	return adminDB;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllDeptIDs() {
	
	if (allDeptIDs == null) {
		try {
			int i;
			Object arg[] 	= new Object[0];
			boolean localTx = false;
			allDeptIDs 		= new Vector();
	
			getAdminDB().startTransaction();
			
			for (i = 0; i < getAllDepts().size(); i++) {
				DBObject dept 		= (DBObject)	Factory.getAllDepts().elementAt(i);
				DBObject dept_ID 	= (DBObject)	dept.execMethod("getCurrentID", arg);
				String deptID 		= 				dept_ID.getProperty("ID").toString();
				DBObject dept_Fac 	= (DBObject)	dept.execMethod("getCurrentFac", arg);
				DBObject deptFac 	= (DBObject) 	dept_Fac.getProperty("Fac");
				DBObject dept_FacID = (DBObject) 	deptFac.execMethod("getCurrentID", arg);
				String deptFacID 	= 				dept_FacID.getProperty("ID").toString();
				
				String deptFacPair[] 	= new String[2];
				deptFacPair[0] 			= new String(deptID);
				deptFacPair[1] 			= new String(deptFacID);
				
				allDeptIDs.addElement(deptFacPair);
			}
			
			getAdminDB().endTransaction();
			
			System.out.println("getAllDeptIDs() has finished.");
		} catch (Exception e) {
			System.out.println("Error in getAllDeptIDs() from sis.util.Factory\n" + e.getMessage());
			e.printStackTrace();
		}
	}
	return allDeptIDs;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllDeptNames() {
	
	if ( allDeptNames == null ){
		try{

			int i;
			Object arg[] 	= new Object[0];
			allDeptNames 		= new Vector();
	
			getAdminDB().startTransaction();
			
			for (i = 0; i < getAllDepts().size(); i++) {
				DBObject dept 		= (DBObject)	Factory.getAllDepts().elementAt(i);
				DBObject dept_Name 	= (DBObject)	dept.execMethod("getCurrentName", arg);
				String	 deptName	= 				dept_Name.getProperty("eName").toString();
				
				allDeptNames.addElement(deptName);
			}
			
			getAdminDB().endTransaction();
			
			System.out.println("getAllDeptNames() has finished.");

		} catch (Exception e) {
			System.out.println("Error in getAllDeptNames() from sis.util.Factory\n" + e.getMessage());
			e.printStackTrace();
		}
	}
	return allDeptNames;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllDepts() {

	if ( allDepts == null ){
	
	try{
		allDepts 	= new Vector();
		String que 	= new String();
		{
			Vector q = new Vector();

			q.addElement( new String("defaultCF 	TempCF;") );
			q.addElement( new String("vts = systemCF::Date.getCurrent();") );
			q.addElement( new String("vte = systemCF::Date.construct(2382, 12, 31);") );
			q.addElement( new String("allDepts = Department from Department;") );
			q.addElement( new String("allDepts = allDepts.getDepartment(vts,vte);") );

			for ( int i = 0; i < q.size(); i++)
				que = que + q.elementAt(i).toString();
		}

		// Start Tx
		getAdminDB().startTransaction();

		java.sql.Date vts = Factory.getCurrentDate();
		java.sql.Date vte = Factory.getForeverDate();

		ODQLStatement query = getAdminDB().getODQLStatement();
		query.execute(que);
		
		//Argument of Procedure in ODQL
		Object arg[] = new Object[0];
		
		//Get Variable Value from ODQL
		DBCollection dbc = (DBCollection) query.getVar("allDepts");
		Enumeration all = dbc.elements();
		
		//Add each teacher to allTeachers Vector
		while (all.hasMoreElements()) {
			DBObject dbo  = (DBObject) all.nextElement();
			allDepts.addElement(dbo);
		}

		Factory.getAdminDB().endTransaction();

		System.out.println("getAllDepts() from sis.util.Factory has Finished.");

	} catch (DatabaseException dbe){

		System.out.println("Database Error in getAllDepts() from sis.util.Factory\n" + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){

		System.out.println("Error in getAllDepts() from sis.util.Factory \n" + e.getMessage() );
		e.printStackTrace();
	}
	}	

	return allDepts;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllFacNames() {
	return allFacNames;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllFacs() {

	if ( allFacs == null ){
	
	try{
		allFacs = new Vector();
		String que = new String();
		{
			String q[] = new String[10];
		
			q[0] = new String("defaultCF 	TempCF;");
			q[1] = new String("vts = systemCF::Date.getCurrent();");
			q[2] = new String("vte = systemCF::Date.construct(2382, 12, 31);");
			q[3] = new String("allFacs = Faculty from Faculty;");
			q[4] = new String("allFacs = allFacs.getFaculty(vts,vte);");
			q[5] = new String("allFacs = allFacs.remove(NIL);");
			q[6] = new String("allFacNames = {NIL};");
			q[7] = new String("scan (allFacs,fac){ ");
			q[8] = new String("allFacNames = allFacNames.add( fac.getCurrentName().eName );};");
			q[9] = new String("allFacNames = allFacNames.remove(NIL);");

			for ( int i =0; i <= 9; i++)
				que = que + q[i];
		}


		// Start Tx
		getAdminDB().startTransaction();
		
		ODQLStatement query = sis.util.Factory.getAdminDB().getODQLStatement();
		query.execute(que);
		
		//Argument of Procedure in ODQL
		Date date = new Date();
		java.sql.Date valid = new java.sql.Date( date.getTime() );
		Object arg[] = new Object[0];
		//arg[0] = valid;

		//Get Variable Value from ODQL
		DBCollection dbc = (DBCollection) query.getVar("allFacs");
		Enumeration all = dbc.elements();
		
		//Add each faculty to allFacs Vector
		while (all.hasMoreElements()) {
			DBObject dbo = (DBObject) all.nextElement();
			allFacs.addElement(dbo);
		}

/*
		//Print Name of each Faculty
		for( int i = 0; i < allFacs.size(); i++){
			DBObject dbo = (DBObject) allFacs.elementAt(i);
			DBObject fac_name = (DBObject) dbo.execMethod("getCurrentName",arg);
			System.out.println( fac_name.getProperty("eName").toString() );
		}
*/
		Factory.getAdminDB().endTransaction();
		System.out.println("getAllFacs() from sis.util.Factory has Finished.");

	} catch (DatabaseException dbe){

		System.out.println("DataBase Error in getAllFacs() from sis.util.Factory \n" + dbe.getMessage());
		dbe.printStackTrace();
	}catch (Exception e){

		System.out.println("Error in getAllFacs() from sis.util.Factory \n" + e.getMessage());
		e.printStackTrace();
	}
	}	

	return allFacs;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllTeachers() {

	if ( allTeachers == null ){
	
	try{
		allTeachers = new Vector();
		String que = new String();
		{
			Vector q2 = new Vector();

			q2.addElement( new String("defaultCF 	TempCF;") );
			q2.addElement( new String("vts = systemCF::Date.getCurrent();") );
			q2.addElement( new String("vte = systemCF::Date.construct(2382, 12, 31);") );
			q2.addElement( new String("allTeachers = Teacher from Teacher;") );
			q2.addElement( new String("allTeachers = allTeachers.getTeacher(vts,vte);") );

			for ( int i = 0; i < q2.size(); i++)
				que = que + q2.elementAt(i).toString();
		}

		// Start Tx
		getAdminDB().startTransaction();

		ODQLStatement query = getAdminDB().getODQLStatement();
		query.execute(que);
		
		//Argument of Procedure in ODQL
		Object arg[] = new Object[0];
		
		//Get Variable Value from ODQL
		DBCollection dbc = (DBCollection) query.getVar("allTeachers");
		Enumeration all = dbc.elements();
		
		//Add each teacher to allTeachers Vector

		while (all.hasMoreElements()) {
			DBObject dbo  = (DBObject) all.nextElement();
			allTeachers.addElement(dbo);
		}

		Factory.getAdminDB().endTransaction();

		System.out.println("getAllTeachers() from sis.util.Factory has Finished.");

	} catch (DatabaseException dbe){

		System.out.println("DatabaseError in getAllTeachers() from sis.util.Factory \n" + dbe.getMessage() +"\n\n");
		dbe.printStackTrace();
	} catch (Exception e){

		System.out.println("Error in getAllTeachers() from sis.util.Factory \n" + e.getMessage() +"\n\n");
		e.printStackTrace();
	}
	}	

	return allTeachers;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getAllTeachIDs() {

	if ( allTeachIDs == null ) {
		try {

			int	i;
			Object	arg[] 	= new Object[0];
			allTeachIDs 	= new Vector();
			
			getAdminDB().startTransaction();
			
			for( i=0; i <getAllTeachers().size(); i++){
				
			
				DBObject	teacher			=	(DBObject)	Factory.getAllTeachers().elementAt(i);
				DBObject	teacher_ID		=	(DBObject)	teacher.execMethod("getCurrentID",arg);
				String		teacherID		=				teacher_ID.getProperty("ID").toString();
			
				DBObject	teacher_Dept	=	(DBObject)	teacher.execMethod("getCurrentDept",arg);
				DBObject	teacherDept		=	(DBObject)	teacher_Dept.getProperty("Dept");
				DBObject	teacher_Fac		=	(DBObject)	teacherDept.execMethod("getCurrentFac",arg);
				DBObject	teacherFac		=	(DBObject)	teacher_Fac.getProperty("Fac");
				DBObject	teacher_FacID	=	(DBObject)	teacherFac.execMethod("getCurrentID",arg);
				String		teacherFacID	=				teacher_FacID.getProperty("ID").toString();

				String teachFacPair[] = new String[2];
				teachFacPair[0] = new String( teacherID );
				teachFacPair[1] = new String( teacherFacID );

				allTeachIDs.addElement( teachFacPair );
		
			}

			getAdminDB().endTransaction();
			
			System.out.println("getAllTeachIDs() has finished.");


		} catch (Exception e) {
			System.out.println("Error in getAllTeachIDs() from sis.util.Factory\n"+e.getMessage() );
			e.printStackTrace();
		}
	}
	
	return allTeachIDs;
}
/**
 * This method was created in VisualAge.
 * @return java.sql.Date
 */
public static java.sql.Date getCurrentDate() {
	if (currentDate == null) {
		try {
				Date date = new Date();
				currentDate = new java.sql.Date( date.getTime() );
		} catch (Exception e) {
			System.out.println("Error in getCurrentDate() from sis.util.Factory\n" + e.getMessage());
		}
	}
	return currentDate;
}
/**
 * This method was created in VisualAge.
 * @return java.sql.Date
 */
public static java.sql.Date getForeverDate() {
	if (foreverDate == null) {
		try {
			GregorianCalendar calendar = new GregorianCalendar(2382,11,31);
			Date date = calendar.getTime();
			foreverDate = new java.sql.Date( date.getTime() );
		} catch (Exception e) {
			System.out.println("Error in getCurrentDate() from sis.util.Factory : " + e.getMessage());
		}
	}
	return foreverDate;
}
/**
 * This method was created in VisualAge.
 * @return jp.jasmine.japi.Database
 */
public static Database getQueryDB() {
	if (queryDB == null) {
		try {
			queryDB = new Database();
			queryDB.startSession();
			String que = new String();
	

		} catch (DatabaseException dbe) {
			System.out.println("Error in getQueryDB() from sis.util.Factory\n" + dbe.getMessage());
			dbe.printStackTrace();
		}
	}
	return queryDB;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public static Vector getRealDeptPos() {

	if ( realDeptPos == null )
		realDeptPos = new Vector();
	return realDeptPos;
}
/**
 * This method was created in VisualAge.
 * @return jp.jasmine.japi.Database
 */
public static Database getStdDB() {
	if (stdDB == null) {
		try {
			stdDB = new Database();
			stdDB.startSession();
			String que = new String();
		} catch (DatabaseException dbe) {
			System.out.println("Error in getstdDB() from sis.util.Factory\n" + dbe.getMessage());
			dbe.printStackTrace();
		}
	}
	return stdDB;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAdminDB(Database newValue) {
	Factory.adminDB = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAllDeptIDs(Vector newValue) {
	Factory.allDeptIDs = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAllDeptNames(Vector newValue) {
	Factory.allDeptNames = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAllDepts(Vector newValue) {
	Factory.allDepts = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAllFacNames(Vector newValue) {
	Factory.allFacNames = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAllFacs(Vector newValue) {
	Factory.allFacs = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setAllTeachIDs(Vector newValue) {
	Factory.allTeachIDs = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue jp.jasmine.japi.Database
 */
public static void setQueryDB(Database newValue) {
	Factory.queryDB = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public static void setRealDeptPos(Vector newValue) {
	Factory.realDeptPos = newValue;
}
/**
 * This method was created in VisualAge.
 * @param newValue jp.jasmine.japi.Database
 */
public static void setStdDB(Database newValue) {
	Factory.stdDB = newValue;
}
}