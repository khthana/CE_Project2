package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class StudentPage extends JPanel implements java.awt.event.ActionListener, java.awt.event.ItemListener {
	private JLabel ivjAddressLabel = null;
	private JLabel ivjNameLabel = null;
	private JScrollPane ivjAddressScrollPane = null;
	private JLabel ivjCitizenLabel = null;
	private JTextField ivjCitizenTextField = null;
	private JComboBox ivjDeptComboBox = null;
	private JLabel ivjDeptLabel = null;
	private JLabel ivjDOBLabel = null;
	private JComboBox ivjFacComboBox = null;
	private JLabel ivjIDLabel = null;
	private JTextField ivjIDTextField = null;
	private JTextField ivjNameTextField = null;
	private JLabel ivjOriginLabel = null;
	private JTextField ivjOriginTextField = null;
	private JLabel ivjReligionLabel = null;
	private JTextField ivjReligionTextField = null;
	private JLabel ivjStatusLabel = null;
	private JTextField ivjStatusTextField = null;
	private JLabel ivjTelLabel = null;
	private JTextArea ivjAddressTextArea = null;
	private JTextField ivjTelTextField = null;
	private JLabel ivjFacultyLabel = null;
	private JPanel ivjInfoPanel = null;
	private DatePanel ivjDOB = null;
	private JButton ivjAddToolBarButton = null;
	private JButton ivjClearToolBarButton = null;
	private JButton ivjDeleteToolBarButton = null;
	private JButton ivjExitToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JButton ivjSaveToolBarButton = null;
	private JToolBar ivjToolBar = null;
	private DatePanel ivjValidTimeDatePanel = null;
	private JPanel ivjValidTimePanel = null;
	private JTextPane ivjValidTimeTextPane = null;
	private PrenamePanel ivjPreName = null;
	private JButton ivjCancelDelButton = null;
	private JDialog ivjDeleteDialog = null;
	private JPanel ivjDeleteDialogContentPane = null;
	private JLabel ivjDeleteLabel = null;
	private JButton ivjFindButton = null;
	private JDialog ivjFindDialog = null;
	private JPanel ivjFindDialogContentPane = null;
	private FindPanel ivjFindPanel = null;
	private JPanel ivjJPanel1 = null;
	private JPanel ivjJPanel2 = null;
	private JButton ivjOKDelButton = null;
	private JButton ivjCancelFindButton = null;
	private JPanel ivjJPanel = null;
	private Student foundStd = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public StudentPage() {
	super();
	initialize();
}
/**
 * Student constructor comment.
 * @param layout java.awt.LayoutManager
 */
public StudentPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Student constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public StudentPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * Student constructor comment.
 * @param isDoubleBuffered boolean
 */
public StudentPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoM1(e);
	}
	if ((e.getSource() == getFindButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getDeleteToolBarButton()) ) {
		connEtoM4(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoC4(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoM5(e);
	}
	if ((e.getSource() == getCancelDelButton()) ) {
		connEtoM6(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM3(e);
	}
	if ((e.getSource() == getDeptComboBox()) ) {
		connEtoM8(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC6(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC7(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void add() throws Exception, java.rmi.RemoteException {


	try{
		
		//Check for valid form
		Message m = new Message();


		if (getIDTextField().getText().length() <= 0) {
			m.show("Student ID is empty.");
			return;
		}
		if (getNameTextField().getText().length() <= 0) {
			m.show("Student name is empty.");
			return;
		}
		if (getPreName().getSelectedItem() == null) {
			m.show("Student prename is empty.");
			return;
		}
		if (getFacComboBox().getSelectedIndex() == 0) {
			m.show("Student faculty is not selected.");
			return;
		}
		if (getDeptComboBox().getSelectedIndex() == 0) {
			m.show("Student department is not selected.");
			return;
		}



		
		if (getAddressTextArea().getText().length() <= 0) {
			m.show("Student address is empty.");
			return;
		}
		if (getCitizenTextField().getText().length() <= 0) {
			m.show("Student citizen is empty.");
			return;
		}
		if (getOriginTextField().getText().length() <= 0) {
				m.show("Student origin is empty.");
				return;
		}
		if (getDOB().getDate() == null) {
				m.show("Student birthdate is empty.");
				return;
		}
		if (getReligionTextField().getText().length() <= 0) {
				m.show("Student religion is empty.");
				return;
		}
		if (getStatusTextField().getText().length() <= 0) {
				m.show("Student status is empty.");
				return;
		}
		if (getTelTextField().getText().length() <= 0) {
			m.show("Student telephone number is empty.");
			return;
		}


		
		if (getValidTimeDatePanel().getDate() == null) {
			m.show("Valid Time Start is not selected.");
			return;
		}

		//Start Tx
		Factory.getAdminDB().startTransaction();

		//Argument for getCurrentID(),getCurrentName()
		Object arg[] = new Object[0];

		//Get Department in Department Type
		DBObject	selectedFac		=	(DBObject)	Factory.getAllFacs().elementAt( getFacComboBox().getSelectedIndex() - 1 );
		DBObject	selectedFac_ID	=	(DBObject)	selectedFac.execMethod("getCurrentID",arg);
		String		selectedFacID	=				selectedFac_ID.getProperty("ID").toString();
		Faculty		stdFac			=				Faculty.findCurrentByID( Factory.getAdminDB(),
																			 selectedFacID );

		if ( stdFac == null ) {
			m.show("New Student can't be created. Fail to retrieve Faculty object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		Integer		pos				=	(Integer)	Factory.getRealDeptPos().elementAt( 
															getDeptComboBox().getSelectedIndex() - 1 );
		DBObject	selectedDept	=	(DBObject)	Factory.getAllDepts().elementAt( pos.intValue() );
		DBObject	selectedDept_ID	=	(DBObject)	selectedDept.execMethod("getCurrentID",arg);
		String		selectedDeptID	=				selectedDept_ID.getProperty("ID").toString();		
		Department	stdDept			=				Department.findCurrentByID( Factory.getAdminDB(),
																				selectedDeptID,
																				stdFac);
		if ( stdDept == null ) {
			m.show("New Student can't be created. Fail to retrieve Department object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		
		java.sql.Date	vts		=	new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
		//Create new department
		Student		newStudent		=	new	Student( Factory.getAdminDB() );
		newStudent.create_this( getIDTextField().getText(),
								getPreName().getSelectedItem(),
								getNameTextField().getText(),
								stdDept,
								vts );
		
		newStudent.setAddress( getAddressTextArea().getText() );
		newStudent.setCitizen( getCitizenTextField().getText() );
		newStudent.setOrigin( getOriginTextField().getText() );
		newStudent.setReligion( getReligionTextField().getText() );
		newStudent.setTel( getTelTextField().getText() );
		newStudent.setStatus( getStatusTextField().getText() );
		newStudent.setBirthdate( new java.sql.Date( getDOB().getDate().getTime() ));

		//End Tx
		Factory.getAdminDB().endTransaction();

		//Clear form
		getIDTextField().setText("");
		getNameTextField().setText("");
		getPreName().clear();
		getFacComboBox().setSelectedIndex(0);
		getFacComboBox().repaint();
		getDeptComboBox().setSelectedIndex(0);
		getDeptComboBox().repaint();

		getAddressTextArea().setText("");
		getCitizenTextField().setText("");
		getOriginTextField().setText("");
		getDOB().clear();
		getReligionTextField().setText("");
		getStatusTextField().setText("");
		getTelTextField().setText("");

				
	} catch (DatabaseException dbe) {
		System.out.println("Database Error in add() from sis.admin.StudentPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	} catch (Exception e) {
		System.out.println("Error in add() from sis.admin.StudentPage\n" + e.getMessage());
		e.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
/**
 * This method was created in VisualAge.
 * @param box com.sun.java.swing.JComboBox
 */
public void addDeptToBox(JComboBox box, int selected) {

	try{
		if ( selected <= 0 ) {
			box.removeAllItems();
			box.addItem( "Selecte Faculty First");
			box.repaint();
			
		} else Factory.addDeptToBox( box, selected );
	} catch ( Exception e){
		System.out.println("Error in addDeptToBox(JComboBox,int) from sis.admin.Student\n" +
			e.getMessage() );
		e.printStackTrace();
	
	}


}
/**
 * This method was created in VisualAge.
 */
public void clear() {

	//Clear form
	getAddressTextArea().setText("");
	getCitizenTextField().setText("");
	getDOB().clear();
	getOriginTextField().setText("");
	getReligionTextField().setText("");
	getStatusTextField().setText("");
	getTelTextField().setText("");
	
	getIDTextField().setText("");
	getNameTextField().setText("");
	getPreName().clear();
	
	getFacComboBox().setSelectedIndex(0);
	getFacComboBox().repaint();

	//Clear	foundStudent
	foundStd = null;

	//Enable&Disable some toolbar buttons
	getAddToolBarButton().setEnabled(true);
	getFindToolBarButton().setEnabled(true);
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);

}
/**
 * connEtoC1:  (ClearToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> StudentPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> StudentPage.add()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.add();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> StudentPage.find()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.find();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> StudentPage.delete()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.delete();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (FacComboBox.item.itemStateChanged(java.awt.event.ItemEvent) --> StudentPage.addDeptToBox(Lcom.sun.java.swing.JComboBox;Ljava.lang.String;)V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.addDeptToBox(getDeptComboBox(), getFacComboBox().getSelectedIndex());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC6:  (ExitToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> StudentPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC7:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> StudentPage.update()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC7(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.update();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindPanel().clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (DeleteToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (CancelDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (FacComboBox.item.itemStateChanged(java.awt.event.ItemEvent) --> FacComboBox.repaint()V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM7(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFacComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (DeptComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> DeptComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM8(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeptComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 */
public void delete() throws Exception, java.rmi.RemoteException {
	
	try{

		Message m = new Message();
		java.sql.Date vte;

		//if there's no found Student then return
		if ( foundStd == null )  {
			m.show("Can't update. Student not found.");	
			return;
		}
		//Check for VTE selection
		if ( getValidTimeDatePanel().getDate() == null ){
			m.show("Valid time for deleting is not selected.");
			return;
		} else vte = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	
		Factory.getAdminDB().startTransaction();
		foundStd.delete_this(vte);
		foundStd = null;
		Factory.getAdminDB().endTransaction();

		clear();
	
	} catch (DatabaseException dbe){
		System.out.println("Database Error in delete() from sis.admin.DepartmentPage\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void find() throws Exception, java.rmi.RemoteException {

	try{
		//Start Tx
		Factory.getAdminDB().startTransaction();

	 	Student		_foundStd	=	null;	
		Object 		arg[] 		= 	new Object[0]; //Argument fot getCurrentID

		//Find		 
		if ( getFindPanel().getFindType().equals("ID") ){
		
			_foundStd = Student.findCurrentByID( Factory.getAdminDB(),
												 getFindPanel().getText() );
										   
		} else if ( getFindPanel().getFindType().equals("Name") ){
			_foundStd = Student.findCurrentByName( Factory.getAdminDB(),
												   getFindPanel().getText() );
		}

		//Check result
		//if student didn't found then show message and return
		if ( _foundStd == null ) {
			Message m = new Message();
			m.show("Student not found.");
			Factory.getAdminDB().endTransaction();
			return; }
		
		foundStd = _foundStd;
		getFindPanel().clear();
		getFindDialog().dispose();

		//Show found Student

		getReligionTextField().setText( foundStd.getReligion() );
		getOriginTextField().setText( foundStd.getOrigin() );
		getCitizenTextField().setText( foundStd.getCitizen() );
		getStatusTextField().setText( foundStd.getStatus() );

		getTelTextField().setText( foundStd.getTel() );
		getAddressTextArea().setText( foundStd.getAddress() );


		getIDTextField().setText( foundStd.getCurrentID().getId() );
		getNameTextField().setText( foundStd.getCurrentName().getEname() );
		getPreName().setSelectedItem( foundStd.getCurrentPreName().getEpren() );
		getDOB().setDate( foundStd.getBirthdate() );

		String	stdDeptID	=	foundStd.getCurrentDept().getDept().getCurrentID().getId();
		String	stdFacID	=	foundStd.getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();

		int	i,pos = -1;
		
		for ( i=0; i < Factory.getAllFacs().size(); i++ ){

			DBObject	fac			=	(DBObject)	Factory.getAllFacs().elementAt(i);
			DBObject	fac_ID		=	(DBObject)	fac.execMethod("getCurrentID",arg);
			String		facID		=				fac_ID.getProperty("ID").toString();

			if ( stdFacID.equals(facID) )
				pos = i;
			if ( pos >= 0 )
				break;
		}

		Factory.getAdminDB().endTransaction();
		

		if ( pos < 0 ) {	
			Message m = new Message();
			m.show("Can't display Faculty. Fail to retieve object.");
			getFacComboBox().setSelectedIndex( 0 );
			getFacComboBox().repaint();
		} else { getFacComboBox().setSelectedIndex( pos+1 );
				 getFacComboBox().repaint();
	   }

		Factory.getAdminDB().startTransaction();

		
		pos = -1;
		String deptFacPair[]	=	new String[2];
		
		for ( i=0; i < Factory.getRealDeptPos().size(); i++ ){

			deptFacPair	=	(String[])	Factory.getAllDeptIDs().elementAt(
										(new	Integer(Factory.getRealDeptPos().elementAt(i).toString())).intValue() );
			
			if ( stdDeptID.equals( deptFacPair[0] ) && stdFacID.equals( deptFacPair[1] ) )
				pos = i;
			if ( pos >= 0 )
				break;
		}

		if ( pos < 0 ) {	
			Message m = new Message();
			m.show("Can't display Department. Fail to retieve object.");
			getDeptComboBox().setSelectedIndex( 0 );
			getDeptComboBox().repaint();
		} else { getDeptComboBox().setSelectedIndex( pos+1 );
				 getDeptComboBox().repaint();
			   }

		
		getValidTimeDatePanel().clear();
		
		//Enable & disable some toolbar bottons
		getAddToolBarButton().setEnabled(false);
		getDeleteToolBarButton().setEnabled(true);
		getSaveToolBarButton().setEnabled(true);
		
		//End Tx
		Factory.getAdminDB().endTransaction();
		
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in find() from sis.admin.StudentPage\n" + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in find() from sis.admin.StudentPage\n" + e.getMessage() );
		e.printStackTrace();
	}


	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
/**
 * Return the AddressLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getAddressLabel() {
	if (ivjAddressLabel == null) {
		try {
			ivjAddressLabel = new com.sun.java.swing.JLabel();
			ivjAddressLabel.setName("AddressLabel");
			ivjAddressLabel.setOpaque(true);
			ivjAddressLabel.setText("Address");
			ivjAddressLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddressLabel;
}
/**
 * Return the JScrollPane property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JScrollPane getAddressScrollPane() {
	if (ivjAddressScrollPane == null) {
		try {
			ivjAddressScrollPane = new com.sun.java.swing.JScrollPane();
			ivjAddressScrollPane.setName("AddressScrollPane");
			ivjAddressScrollPane.setPreferredSize(new java.awt.Dimension(200, 40));
			getAddressScrollPane().setViewportView(getAddressTextArea());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddressScrollPane;
}
/**
 * Return the AddresStdInsTextArea property value.
 * @return com.sun.java.swing.JTextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextArea getAddressTextArea() {
	if (ivjAddressTextArea == null) {
		try {
			ivjAddressTextArea = new com.sun.java.swing.JTextArea();
			ivjAddressTextArea.setName("AddressTextArea");
			ivjAddressTextArea.setBounds(0, 0, 15, 19);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddressTextArea;
}
/**
 * Return the AddToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getAddToolBarButton() {
	if (ivjAddToolBarButton == null) {
		try {
			ivjAddToolBarButton = new com.sun.java.swing.JButton();
			ivjAddToolBarButton.setName("AddToolBarButton");
			ivjAddToolBarButton.setToolTipText("Add new student");
			ivjAddToolBarButton.setText("");
			ivjAddToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjAddToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjAddToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\inserticon.gif"));
			ivjAddToolBarButton.setPreferredSize(new java.awt.Dimension(22, 23));
			ivjAddToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddToolBarButton;
}
/**
 * Return the CancelDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelDelButton() {
	if (ivjCancelDelButton == null) {
		try {
			ivjCancelDelButton = new com.sun.java.swing.JButton();
			ivjCancelDelButton.setName("CancelDelButton");
			ivjCancelDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelDelButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelDelButton;
}
/**
 * Return the CancelFindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelFindButton() {
	if (ivjCancelFindButton == null) {
		try {
			ivjCancelFindButton = new com.sun.java.swing.JButton();
			ivjCancelFindButton.setName("CancelFindButton");
			ivjCancelFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelFindButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelFindButton;
}
/**
 * Return the CitizenStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getCitizenLabel() {
	if (ivjCitizenLabel == null) {
		try {
			ivjCitizenLabel = new com.sun.java.swing.JLabel();
			ivjCitizenLabel.setName("CitizenLabel");
			ivjCitizenLabel.setText("Citizen");
			ivjCitizenLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCitizenLabel;
}
/**
 * Return the CitizenStdInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getCitizenTextField() {
	if (ivjCitizenTextField == null) {
		try {
			ivjCitizenTextField = new com.sun.java.swing.JTextField();
			ivjCitizenTextField.setName("CitizenTextField");
			ivjCitizenTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			ivjCitizenTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjCitizenTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCitizenTextField;
}
/**
 * Return the ClearToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the DeleteDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getDeleteDialog() {
	if (ivjDeleteDialog == null) {
		try {
			ivjDeleteDialog = new com.sun.java.swing.JDialog();
			ivjDeleteDialog.setName("DeleteDialog");
			ivjDeleteDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjDeleteDialog.setBounds(804, 327, 300, 100);
			ivjDeleteDialog.setModal(true);
			ivjDeleteDialog.setTitle("Delete Student");
			getDeleteDialog().setContentPane(getDeleteDialogContentPane());
			// user code begin {1}
			ivjDeleteDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjDeleteDialog.getBounds();
			ivjDeleteDialog.setBounds ( (screen.width - s.width)/2,
									    (screen.height - s.height)/2,
									  	s.width,
									  	s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialog;
}
/**
 * Return the DeleteDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getDeleteDialogContentPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	if (ivjDeleteDialogContentPane == null) {
		try {
			ivjDeleteDialogContentPane = new com.sun.java.swing.JPanel();
			ivjDeleteDialogContentPane.setName("DeleteDialogContentPane");
			ivjDeleteDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjDeleteDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 0;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			getDeleteDialogContentPane().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel2.gridx = 0; constraintsJPanel2.gridy = 1;
			constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
			constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel2.weightx = 0.0;
			constraintsJPanel2.weighty = 0.0;
			constraintsJPanel2.insets = new java.awt.Insets(10, 0, 10, 0);
			getDeleteDialogContentPane().add(getJPanel2(), constraintsJPanel2);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialogContentPane;
}
/**
 * Return the DeleteLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeleteLabel() {
	if (ivjDeleteLabel == null) {
		try {
			ivjDeleteLabel = new com.sun.java.swing.JLabel();
			ivjDeleteLabel.setName("DeleteLabel");
			ivjDeleteLabel.setText("Are you sure to delete this object?");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteLabel;
}
/**
 * Return the DeleteToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getDeleteToolBarButton() {
	if (ivjDeleteToolBarButton == null) {
		try {
			ivjDeleteToolBarButton = new com.sun.java.swing.JButton();
			ivjDeleteToolBarButton.setName("DeleteToolBarButton");
			ivjDeleteToolBarButton.setToolTipText("Delete this student");
			ivjDeleteToolBarButton.setText("");
			ivjDeleteToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDeleteToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDeleteToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\deleteicon.gif"));
			ivjDeleteToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteToolBarButton;
}
/**
 * Return the DeptStdInsComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getDeptComboBox() {
	if (ivjDeptComboBox == null) {
		try {
			ivjDeptComboBox = new com.sun.java.swing.JComboBox();
			ivjDeptComboBox.setName("DeptComboBox");
			ivjDeptComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjDeptComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			ivjDeptComboBox.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeptComboBox;
}
/**
 * Return the DeptStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeptLabel() {
	if (ivjDeptLabel == null) {
		try {
			ivjDeptLabel = new com.sun.java.swing.JLabel();
			ivjDeptLabel.setName("DeptLabel");
			ivjDeptLabel.setOpaque(true);
			ivjDeptLabel.setText("Department");
			ivjDeptLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeptLabel;
}
/**
 * Return the DOBDatePanel property value.
 * @return sis.util.DatePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DatePanel getDOB() {
	if (ivjDOB == null) {
		try {
			ivjDOB = new sis.util.DatePanel();
			ivjDOB.setName("DOB");
			ivjDOB.setPreferredSize(new java.awt.Dimension(200, 30));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDOB;
}
/**
 * Return the DOBStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDOBLabel() {
	if (ivjDOBLabel == null) {
		try {
			ivjDOBLabel = new com.sun.java.swing.JLabel();
			ivjDOBLabel.setName("DOBLabel");
			ivjDOBLabel.setOpaque(true);
			ivjDOBLabel.setText("Date of Birth");
			ivjDOBLabel.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			ivjDOBLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDOBLabel;
}
/**
 * Return the ExitToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the FacStdInsComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getFacComboBox() {
	if (ivjFacComboBox == null) {
		try {
			ivjFacComboBox = new com.sun.java.swing.JComboBox();
			ivjFacComboBox.setName("FacComboBox");
			ivjFacComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjFacComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			ivjFacComboBox.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacComboBox;
}
/**
 * Return the FacultyLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getFacultyLabel() {
	if (ivjFacultyLabel == null) {
		try {
			ivjFacultyLabel = new com.sun.java.swing.JLabel();
			ivjFacultyLabel.setName("FacultyLabel");
			ivjFacultyLabel.setOpaque(true);
			ivjFacultyLabel.setText("Faculty");
			ivjFacultyLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacultyLabel;
}
/**
 * Return the FindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindButton() {
	if (ivjFindButton == null) {
		try {
			ivjFindButton = new com.sun.java.swing.JButton();
			ivjFindButton.setName("FindButton");
			ivjFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjFindButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindButton;
}
/**
 * Return the FindDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getFindDialog() {
	if (ivjFindDialog == null) {
		try {
			ivjFindDialog = new com.sun.java.swing.JDialog();
			ivjFindDialog.setName("FindDialog");
			ivjFindDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjFindDialog.setBounds(793, 32, 340, 150);
			ivjFindDialog.setModal(true);
			ivjFindDialog.setTitle("Find Student");
			getFindDialog().setContentPane(getFindDialogContentPane());
			// user code begin {1}
			ivjFindDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjFindDialog.getBounds();
			ivjFindDialog.setBounds ( (screen.width - s.width)/2,
									  (screen.height - s.height)/2,
									  s.width,
									  s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialog;
}
/**
 * Return the FindDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindDialogContentPane() {
	java.awt.GridBagConstraints constraintsFindPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel = new java.awt.GridBagConstraints();
	if (ivjFindDialogContentPane == null) {
		try {
			ivjFindDialogContentPane = new com.sun.java.swing.JPanel();
			ivjFindDialogContentPane.setName("FindDialogContentPane");
			ivjFindDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjFindDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsFindPanel.gridx = 0; constraintsFindPanel.gridy = 0;
			constraintsFindPanel.gridwidth = 1; constraintsFindPanel.gridheight = 1;
			constraintsFindPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindPanel.weightx = 1.0;
			constraintsFindPanel.weighty = 0.0;
			constraintsFindPanel.insets = new java.awt.Insets(0, 0, 5, 0);
			getFindDialogContentPane().add(getFindPanel(), constraintsFindPanel);

			constraintsJPanel.gridx = 0; constraintsJPanel.gridy = 1;
			constraintsJPanel.gridwidth = 1; constraintsJPanel.gridheight = 1;
			constraintsJPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel.weightx = 0.0;
			constraintsJPanel.weighty = 0.0;
			constraintsJPanel.insets = new java.awt.Insets(10, 0, 10, 0);
			getFindDialogContentPane().add(getJPanel(), constraintsJPanel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialogContentPane;
}
/**
 * Return the FindPanel property value.
 * @return sis.util.FindPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private FindPanel getFindPanel() {
	if (ivjFindPanel == null) {
		try {
			ivjFindPanel = new sis.util.FindPanel();
			ivjFindPanel.setName("FindPanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindPanel;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("Find student");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the IdStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getIDLabel() {
	if (ivjIDLabel == null) {
		try {
			ivjIDLabel = new com.sun.java.swing.JLabel();
			ivjIDLabel.setName("IDLabel");
			ivjIDLabel.setText("ID");
			ivjIDLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDLabel;
}
/**
 * Return the IdStdInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			ivjIDTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjIDTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the InfoPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getInfoPanel() {
	java.awt.GridBagConstraints constraintsIDLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsPreName = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacultyLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeptLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeptComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDOBLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDOB = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsReligionLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsReligionTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsOriginLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsOriginTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCitizenLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsStatusLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCitizenTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsStatusTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsTelLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsTelTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsAddressLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsAddressScrollPane = new java.awt.GridBagConstraints();
	if (ivjInfoPanel == null) {
		try {
			ivjInfoPanel = new com.sun.java.swing.JPanel();
			ivjInfoPanel.setName("InfoPanel");
			ivjInfoPanel.setLayout(new java.awt.GridBagLayout());

			constraintsIDLabel.gridx = 0; constraintsIDLabel.gridy = 0;
			constraintsIDLabel.gridwidth = 1; constraintsIDLabel.gridheight = 1;
			constraintsIDLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsIDLabel.weightx = 0.0;
			constraintsIDLabel.weighty = 0.0;
			constraintsIDLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getIDLabel(), constraintsIDLabel);

			constraintsIDTextField.gridx = 1; constraintsIDTextField.gridy = 0;
			constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
			constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsIDTextField.weightx = 0.0;
			constraintsIDTextField.weighty = 0.0;
			constraintsIDTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getIDTextField(), constraintsIDTextField);

			constraintsNameLabel.gridx = 0; constraintsNameLabel.gridy = 1;
			constraintsNameLabel.gridwidth = 1; constraintsNameLabel.gridheight = 1;
			constraintsNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsNameLabel.weightx = 0.0;
			constraintsNameLabel.weighty = 0.0;
			constraintsNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getNameLabel(), constraintsNameLabel);

			constraintsPreName.gridx = 1; constraintsPreName.gridy = 1;
			constraintsPreName.gridwidth = 1; constraintsPreName.gridheight = 1;
			constraintsPreName.anchor = java.awt.GridBagConstraints.WEST;
			constraintsPreName.weightx = 0.0;
			constraintsPreName.weighty = 0.0;
			constraintsPreName.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getPreName(), constraintsPreName);

			constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 2;
			constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
			constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsNameTextField.weightx = 0.0;
			constraintsNameTextField.weighty = 0.0;
			constraintsNameTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getNameTextField(), constraintsNameTextField);

			constraintsFacultyLabel.gridx = 2; constraintsFacultyLabel.gridy = 0;
			constraintsFacultyLabel.gridwidth = 1; constraintsFacultyLabel.gridheight = 1;
			constraintsFacultyLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsFacultyLabel.weightx = 0.0;
			constraintsFacultyLabel.weighty = 0.0;
			constraintsFacultyLabel.insets = new java.awt.Insets(0, 20, 5, 10);
			getInfoPanel().add(getFacultyLabel(), constraintsFacultyLabel);

			constraintsFacComboBox.gridx = 3; constraintsFacComboBox.gridy = 0;
			constraintsFacComboBox.gridwidth = 1; constraintsFacComboBox.gridheight = 1;
			constraintsFacComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsFacComboBox.weightx = 0.0;
			constraintsFacComboBox.weighty = 0.0;
			constraintsFacComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getFacComboBox(), constraintsFacComboBox);

			constraintsDeptLabel.gridx = 2; constraintsDeptLabel.gridy = 1;
			constraintsDeptLabel.gridwidth = 1; constraintsDeptLabel.gridheight = 1;
			constraintsDeptLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDeptLabel.weightx = 0.0;
			constraintsDeptLabel.weighty = 0.0;
			constraintsDeptLabel.insets = new java.awt.Insets(0, 20, 5, 10);
			getInfoPanel().add(getDeptLabel(), constraintsDeptLabel);

			constraintsDeptComboBox.gridx = 3; constraintsDeptComboBox.gridy = 1;
			constraintsDeptComboBox.gridwidth = 1; constraintsDeptComboBox.gridheight = 1;
			constraintsDeptComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsDeptComboBox.weightx = 0.0;
			constraintsDeptComboBox.weighty = 0.0;
			constraintsDeptComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getDeptComboBox(), constraintsDeptComboBox);

			constraintsDOBLabel.gridx = 2; constraintsDOBLabel.gridy = 2;
			constraintsDOBLabel.gridwidth = 1; constraintsDOBLabel.gridheight = 1;
			constraintsDOBLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDOBLabel.weightx = 0.0;
			constraintsDOBLabel.weighty = 0.0;
			constraintsDOBLabel.insets = new java.awt.Insets(0, 20, 5, 10);
			getInfoPanel().add(getDOBLabel(), constraintsDOBLabel);

			constraintsDOB.gridx = 3; constraintsDOB.gridy = 2;
			constraintsDOB.gridwidth = 1; constraintsDOB.gridheight = 1;
			constraintsDOB.anchor = java.awt.GridBagConstraints.WEST;
			constraintsDOB.weightx = 0.0;
			constraintsDOB.weighty = 0.0;
			constraintsDOB.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getDOB(), constraintsDOB);

			constraintsReligionLabel.gridx = 0; constraintsReligionLabel.gridy = 3;
			constraintsReligionLabel.gridwidth = 1; constraintsReligionLabel.gridheight = 1;
			constraintsReligionLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsReligionLabel.weightx = 0.0;
			constraintsReligionLabel.weighty = 0.0;
			constraintsReligionLabel.insets = new java.awt.Insets(20, 10, 5, 10);
			getInfoPanel().add(getReligionLabel(), constraintsReligionLabel);

			constraintsReligionTextField.gridx = 1; constraintsReligionTextField.gridy = 3;
			constraintsReligionTextField.gridwidth = 1; constraintsReligionTextField.gridheight = 1;
			constraintsReligionTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsReligionTextField.weightx = 0.0;
			constraintsReligionTextField.weighty = 0.0;
			constraintsReligionTextField.insets = new java.awt.Insets(20, 0, 5, 0);
			getInfoPanel().add(getReligionTextField(), constraintsReligionTextField);

			constraintsOriginLabel.gridx = 0; constraintsOriginLabel.gridy = 4;
			constraintsOriginLabel.gridwidth = 1; constraintsOriginLabel.gridheight = 1;
			constraintsOriginLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsOriginLabel.weightx = 0.0;
			constraintsOriginLabel.weighty = 0.0;
			constraintsOriginLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getOriginLabel(), constraintsOriginLabel);

			constraintsOriginTextField.gridx = 1; constraintsOriginTextField.gridy = 4;
			constraintsOriginTextField.gridwidth = 1; constraintsOriginTextField.gridheight = 1;
			constraintsOriginTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsOriginTextField.weightx = 0.0;
			constraintsOriginTextField.weighty = 0.0;
			constraintsOriginTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getOriginTextField(), constraintsOriginTextField);

			constraintsCitizenLabel.gridx = 0; constraintsCitizenLabel.gridy = 5;
			constraintsCitizenLabel.gridwidth = 1; constraintsCitizenLabel.gridheight = 1;
			constraintsCitizenLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsCitizenLabel.weightx = 0.0;
			constraintsCitizenLabel.weighty = 0.0;
			constraintsCitizenLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getCitizenLabel(), constraintsCitizenLabel);

			constraintsStatusLabel.gridx = 0; constraintsStatusLabel.gridy = 6;
			constraintsStatusLabel.gridwidth = 1; constraintsStatusLabel.gridheight = 1;
			constraintsStatusLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsStatusLabel.weightx = 0.0;
			constraintsStatusLabel.weighty = 0.0;
			constraintsStatusLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getStatusLabel(), constraintsStatusLabel);

			constraintsCitizenTextField.gridx = 1; constraintsCitizenTextField.gridy = 5;
			constraintsCitizenTextField.gridwidth = 1; constraintsCitizenTextField.gridheight = 1;
			constraintsCitizenTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsCitizenTextField.weightx = 0.0;
			constraintsCitizenTextField.weighty = 0.0;
			constraintsCitizenTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getCitizenTextField(), constraintsCitizenTextField);

			constraintsStatusTextField.gridx = 1; constraintsStatusTextField.gridy = 6;
			constraintsStatusTextField.gridwidth = 1; constraintsStatusTextField.gridheight = 1;
			constraintsStatusTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsStatusTextField.weightx = 0.0;
			constraintsStatusTextField.weighty = 0.0;
			constraintsStatusTextField.insets = new java.awt.Insets(0, 0, 5, 0);
			getInfoPanel().add(getStatusTextField(), constraintsStatusTextField);

			constraintsTelLabel.gridx = 2; constraintsTelLabel.gridy = 3;
			constraintsTelLabel.gridwidth = 1; constraintsTelLabel.gridheight = 1;
			constraintsTelLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsTelLabel.weightx = 0.0;
			constraintsTelLabel.weighty = 0.0;
			constraintsTelLabel.insets = new java.awt.Insets(20, 20, 5, 10);
			getInfoPanel().add(getTelLabel(), constraintsTelLabel);

			constraintsTelTextField.gridx = 3; constraintsTelTextField.gridy = 3;
			constraintsTelTextField.gridwidth = 1; constraintsTelTextField.gridheight = 1;
			constraintsTelTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsTelTextField.weightx = 0.0;
			constraintsTelTextField.weighty = 0.0;
			constraintsTelTextField.insets = new java.awt.Insets(20, 0, 5, 10);
			getInfoPanel().add(getTelTextField(), constraintsTelTextField);

			constraintsAddressLabel.gridx = 2; constraintsAddressLabel.gridy = 4;
			constraintsAddressLabel.gridwidth = 1; constraintsAddressLabel.gridheight = 1;
			constraintsAddressLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsAddressLabel.weightx = 0.0;
			constraintsAddressLabel.weighty = 0.0;
			constraintsAddressLabel.insets = new java.awt.Insets(0, 20, 5, 10);
			getInfoPanel().add(getAddressLabel(), constraintsAddressLabel);

			constraintsAddressScrollPane.gridx = 3; constraintsAddressScrollPane.gridy = 4;
			constraintsAddressScrollPane.gridwidth = 1; constraintsAddressScrollPane.gridheight = 3;
			constraintsAddressScrollPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsAddressScrollPane.anchor = java.awt.GridBagConstraints.WEST;
			constraintsAddressScrollPane.weightx = 0.0;
			constraintsAddressScrollPane.weighty = 0.0;
			constraintsAddressScrollPane.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getAddressScrollPane(), constraintsAddressScrollPane);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Student Information");
			ivjInfoPanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInfoPanel;
}
/**
 * Return the JPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel() {
	java.awt.GridBagConstraints constraintsFindButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelFindButton = new java.awt.GridBagConstraints();
	if (ivjJPanel == null) {
		try {
			ivjJPanel = new com.sun.java.swing.JPanel();
			ivjJPanel.setName("JPanel");
			ivjJPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFindButton.gridx = 0; constraintsFindButton.gridy = 0;
			constraintsFindButton.gridwidth = 1; constraintsFindButton.gridheight = 1;
			constraintsFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindButton.weightx = 0.0;
			constraintsFindButton.weighty = 0.0;
			constraintsFindButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel().add(getFindButton(), constraintsFindButton);

			constraintsCancelFindButton.gridx = -1; constraintsCancelFindButton.gridy = -1;
			constraintsCancelFindButton.gridwidth = 1; constraintsCancelFindButton.gridheight = 1;
			constraintsCancelFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelFindButton.weightx = 0.0;
			constraintsCancelFindButton.weighty = 0.0;
			getJPanel().add(getCancelFindButton(), constraintsCancelFindButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsDeleteLabel = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsDeleteLabel.gridx = 0; constraintsDeleteLabel.gridy = 0;
			constraintsDeleteLabel.gridwidth = 1; constraintsDeleteLabel.gridheight = 1;
			constraintsDeleteLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDeleteLabel.weightx = 0.0;
			constraintsDeleteLabel.weighty = 0.0;
			getJPanel1().add(getDeleteLabel(), constraintsDeleteLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsOKDelButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelDelButton = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsOKDelButton.gridx = 0; constraintsOKDelButton.gridy = 0;
			constraintsOKDelButton.gridwidth = 1; constraintsOKDelButton.gridheight = 1;
			constraintsOKDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKDelButton.weightx = 0.0;
			constraintsOKDelButton.weighty = 0.0;
			constraintsOKDelButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel2().add(getOKDelButton(), constraintsOKDelButton);

			constraintsCancelDelButton.gridx = -1; constraintsCancelDelButton.gridy = -1;
			constraintsCancelDelButton.gridwidth = 1; constraintsCancelDelButton.gridheight = 1;
			constraintsCancelDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelDelButton.weightx = 0.0;
			constraintsCancelDelButton.weighty = 0.0;
			getJPanel2().add(getCancelDelButton(), constraintsCancelDelButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the NameLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getNameLabel() {
	if (ivjNameLabel == null) {
		try {
			ivjNameLabel = new com.sun.java.swing.JLabel();
			ivjNameLabel.setName("NameLabel");
			ivjNameLabel.setText("Name");
			ivjNameLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameLabel;
}
/**
 * Return the NameStdInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			ivjNameTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjNameTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * Return the OKDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKDelButton() {
	if (ivjOKDelButton == null) {
		try {
			ivjOKDelButton = new com.sun.java.swing.JButton();
			ivjOKDelButton.setName("OKDelButton");
			ivjOKDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKDelButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKDelButton;
}
/**
 * Return the OriginStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getOriginLabel() {
	if (ivjOriginLabel == null) {
		try {
			ivjOriginLabel = new com.sun.java.swing.JLabel();
			ivjOriginLabel.setName("OriginLabel");
			ivjOriginLabel.setText("Origin");
			ivjOriginLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOriginLabel;
}
/**
 * Return the OriginStdInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getOriginTextField() {
	if (ivjOriginTextField == null) {
		try {
			ivjOriginTextField = new com.sun.java.swing.JTextField();
			ivjOriginTextField.setName("OriginTextField");
			ivjOriginTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			ivjOriginTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjOriginTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOriginTextField;
}
/**
 * Return the Prename property value.
 * @return sis.util.PrenamePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private PrenamePanel getPreName() {
	if (ivjPreName == null) {
		try {
			ivjPreName = new sis.util.PrenamePanel();
			ivjPreName.setName("PreName");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjPreName;
}
/**
 * Return the ReligionStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getReligionLabel() {
	if (ivjReligionLabel == null) {
		try {
			ivjReligionLabel = new com.sun.java.swing.JLabel();
			ivjReligionLabel.setName("ReligionLabel");
			ivjReligionLabel.setText("Religion");
			ivjReligionLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjReligionLabel;
}
/**
 * Return the ReligionStdInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getReligionTextField() {
	if (ivjReligionTextField == null) {
		try {
			ivjReligionTextField = new com.sun.java.swing.JTextField();
			ivjReligionTextField.setName("ReligionTextField");
			ivjReligionTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			ivjReligionTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjReligionTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjReligionTextField;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Save change");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the StatusStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getStatusLabel() {
	if (ivjStatusLabel == null) {
		try {
			ivjStatusLabel = new com.sun.java.swing.JLabel();
			ivjStatusLabel.setName("StatusLabel");
			ivjStatusLabel.setText("Status");
			ivjStatusLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjStatusLabel;
}
/**
 * Return the StatusStdInsTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getStatusTextField() {
	if (ivjStatusTextField == null) {
		try {
			ivjStatusTextField = new com.sun.java.swing.JTextField();
			ivjStatusTextField.setName("StatusTextField");
			ivjStatusTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			ivjStatusTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			ivjStatusTextField.setRequestFocusEnabled(true);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjStatusTextField;
}
/**
 * Return the TelStdInsLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getTelLabel() {
	if (ivjTelLabel == null) {
		try {
			ivjTelLabel = new com.sun.java.swing.JLabel();
			ivjTelLabel.setName("TelLabel");
			ivjTelLabel.setOpaque(false);
			ivjTelLabel.setText("Telephone");
			ivjTelLabel.setRequestFocusEnabled(false);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTelLabel;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getTelTextField() {
	if (ivjTelTextField == null) {
		try {
			ivjTelTextField = new com.sun.java.swing.JTextField();
			ivjTelTextField.setName("TelTextField");
			ivjTelTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjTelTextField;
}
/**
 * Return the ToolBar property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getToolBar() {
	if (ivjToolBar == null) {
		try {
			ivjToolBar = new com.sun.java.swing.JToolBar();
			ivjToolBar.setName("ToolBar");
			ivjToolBar.add(getClearToolBarButton());
			ivjToolBar.addSeparator();
			getToolBar().add(getAddToolBarButton(), getAddToolBarButton().getName());
			getToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			getToolBar().add(getDeleteToolBarButton(), getDeleteToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjToolBar;
}
/**
 * Return the ValidTimeDatePanel property value.
 * @return sis.util.DatePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DatePanel getValidTimeDatePanel() {
	if (ivjValidTimeDatePanel == null) {
		try {
			ivjValidTimeDatePanel = new sis.util.DatePanel();
			ivjValidTimeDatePanel.setName("ValidTimeDatePanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeDatePanel;
}
/**
 * Return the ValidTimePanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getValidTimePanel() {
	java.awt.GridBagConstraints constraintsValidTimeTextPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsValidTimeDatePanel = new java.awt.GridBagConstraints();
	if (ivjValidTimePanel == null) {
		try {
			ivjValidTimePanel = new com.sun.java.swing.JPanel();
			ivjValidTimePanel.setName("ValidTimePanel");
			ivjValidTimePanel.setLayout(new java.awt.GridBagLayout());

			constraintsValidTimeTextPane.gridx = 1; constraintsValidTimeTextPane.gridy = 1;
			constraintsValidTimeTextPane.gridwidth = 1; constraintsValidTimeTextPane.gridheight = 1;
			constraintsValidTimeTextPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsValidTimeTextPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeTextPane.weightx = 1.0;
			constraintsValidTimeTextPane.weighty = 1.0;
			getValidTimePanel().add(getValidTimeTextPane(), constraintsValidTimeTextPane);

			constraintsValidTimeDatePanel.gridx = 1; constraintsValidTimeDatePanel.gridy = 2;
			constraintsValidTimeDatePanel.gridwidth = 1; constraintsValidTimeDatePanel.gridheight = 1;
			constraintsValidTimeDatePanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeDatePanel.weightx = 0.0;
			constraintsValidTimeDatePanel.weighty = 0.0;
			getValidTimePanel().add(getValidTimeDatePanel(), constraintsValidTimeDatePanel);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Valid Time");
			ivjValidTimePanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimePanel;
}
/**
 * Return the ValidTimeTextPane property value.
 * @return com.sun.java.swing.JTextPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextPane getValidTimeTextPane() {
	if (ivjValidTimeTextPane == null) {
		try {
			ivjValidTimeTextPane = new com.sun.java.swing.JTextPane();
			ivjValidTimeTextPane.setName("ValidTimeTextPane");
			ivjValidTimeTextPane.setPreferredSize(new java.awt.Dimension(30, 60));
			ivjValidTimeTextPane.setText("This time is used for,\n \t- insert, valid time start of this object\n\t- delete, valid time end of this object\n\t- update, valid time end of old property and valid time start for new property\n\t\t     valid time start of new property");
			ivjValidTimeTextPane.setBackground(new java.awt.Color(204,204,204));
			ivjValidTimeTextPane.setEditable(false);
			// user code begin {1}
			Border empty;
			empty = BorderFactory.createEmptyBorder(0,10,10,10);
			ivjValidTimeTextPane.setBorder(empty);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeTextPane;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getAddToolBarButton().addActionListener(this);
	getFindToolBarButton().addActionListener(this);
	getFindButton().addActionListener(this);
	getDeleteToolBarButton().addActionListener(this);
	getOKDelButton().addActionListener(this);
	getCancelDelButton().addActionListener(this);
	getCancelFindButton().addActionListener(this);
	getFacComboBox().addItemListener(this);
	getDeptComboBox().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Student");
	setPreferredSize(new java.awt.Dimension(510, 210));
	setLayout(new java.awt.BorderLayout());
	setSize(550, 500);
	add(getInfoPanel(), "Center");
	add(getToolBar(), "North");
	add(getValidTimePanel(), "South");
	initConnections();
	// user code begin {2}
	Factory.addFacultyToBox( getFacComboBox() );
	Factory.getAllDepts();

	//Disable some toolbar buttons
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
	// user code end
}
/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getFacComboBox()) ) {
		connEtoM7(e);
	}
	if ((e.getSource() == getFacComboBox()) ) {
		connEtoC5(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		JFrame frame = new com.sun.java.swing.JFrame();
		StudentPage aStudentPage;
		aStudentPage = new StudentPage();
		frame.getContentPane().add("Center", aStudentPage);
		frame.setSize(aStudentPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void update() throws Exception, java.rmi.RemoteException {
	Message m = new Message();
	
	//if there's no found Student then return
	if ( foundStd == null )  {
		m.show("Can't update. Student not found.");	
		return;
	}

	//Check seleted Faculty and Department
	if ( getFacComboBox().getSelectedIndex() == 0 ){
		m.show("Faculty isn't seleted.");
		return;
	}
	
	if ( getDeptComboBox().getSelectedIndex() == 0 ){
		m.show("Department isn't seleted.");
		return;
	}
	
	//Check for valid time selection
	if ( getValidTimeDatePanel().getDate() == null ) {
		m.show("Valid time isn't selected.");
		return;
	}

	//Valid Time,use for passing
	java.sql.Date valid = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	//Set if there's update
	boolean update = false;

	try{
		//Strat Tx
		Factory.getAdminDB().startTransaction();

		//Get Dept ID from form
		Object 	arg[]			=	new	Object[0];
		int		i,pos 			= 	-1;
		String 	deptFacPair[]	=	new String[2];
		
		String	stdDeptID		=	foundStd.getCurrentDept().getDept().getCurrentID().getId();
		String	stdFacID		=	foundStd.getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();

		deptFacPair	=	(String[])	Factory.getAllDeptIDs().elementAt(
								(new	Integer(Factory.getRealDeptPos().elementAt( getDeptComboBox().getSelectedIndex()-1 ).toString())).intValue() );

		if ( !(stdDeptID.equals(deptFacPair[0]) && stdFacID.equals(deptFacPair[1])) ){
			
			Faculty		cFac	=	Faculty.findCurrentByID( Factory.getAdminDB(),
															 deptFacPair[1] );
			Department	cDept	=	Department.findCurrentByID( Factory.getAdminDB(),
															 deptFacPair[0],
															 cFac);
			foundStd.update_Dept( foundStd.getCurrentDept().getDept(),
								  cDept,
								  valid,
								  valid);
			update = true;
			System.out.println("Student Department has been updated.");
		}
		

		if ( !getIDTextField().getText().equals( foundStd.getCurrentID().getId() ) ){
			  foundStd.update_ID( foundStd.getCurrentID().getId(),
								  getIDTextField().getText(),
								  valid,
								  valid);
			  update = true;
			  System.out.println("Student ID has been updated.");
		}

		if ( !getPreName().getSelectedItem().equals(foundStd.getCurrentPreName().getEpren()) ){
			foundStd.update_ePren( foundStd.getCurrentPreName().getEpren(),
								   getPreName().getSelectedItem(),
								   valid,
								   valid);
			  update = true;
			  System.out.println("Student Prename has been updated.");
		}
		

		if ( !getNameTextField().getText().equals( foundStd.getCurrentName().getEname() ) ){
			 foundStd.update_eName( foundStd.getCurrentName().getEname(),
									getNameTextField().getText(),
									valid,
								 	valid);
			  update = true;
			  System.out.println("Student Name has been updated.");
		}

		if ( !getReligionTextField().getText().equals( foundStd.getReligion() ) ){
			foundStd.setReligion( getReligionTextField().getText() );
			update = true;
			System.out.println("Student Religion has been updated.");
		}

		if ( !getCitizenTextField().getText().equals( foundStd.getCitizen() ) ){
			foundStd.setCitizen( getCitizenTextField().getText() );
			update = true;
			System.out.println("Student Citizen has been updated.");
		}
		if ( !getOriginTextField().getText().equals( foundStd.getOrigin() ) ){
			foundStd.setOrigin( getOriginTextField().getText() );
			update = true;
			System.out.println("Student Origin has been updated.");
		}
		if ( !getStatusTextField().getText().equals( foundStd.getStatus() ) ){
			foundStd.setStatus( getStatusTextField().getText() );
			update = true;
			System.out.println("Student Status has been updated.");
		}
		if ( !getTelTextField().getText().equals( foundStd.getTel() ) ){
			foundStd.setTel( getTelTextField().getText() );
			update = true;
			System.out.println("Student Telephone Number has been updated.");
		}
		if ( !getAddressTextArea().getText().equals( foundStd.getAddress() ) ){
			foundStd.setAddress( getAddressTextArea().getText() );
			update = true;
			System.out.println("Student Address has been updated.");
		}

		if ( !getDOB().getDate().equals( foundStd.getBirthdate() ) ){
			foundStd.setBirthdate( new java.sql.Date( getDOB().getDate().getTime() ) );
			update	= true;
			System.out.println("Student Birthdate has been updated");
		}

		//Refresh foundStd
		if ( update ){

			int selectedFacIndex 	=	getFacComboBox().getSelectedIndex();
			int selectedDeptIndex 	=	getDeptComboBox().getSelectedIndex();

			//Find		 
			foundStd	= 	null;
			foundStd	= 	Student.findCurrentByID( Factory.getAdminDB(),
										          	 getIDTextField().getText() );
			
			if ( foundStd == null ){
				m.show("Cannot display updated information");
				clear();
			} else {	//Show
						getIDTextField().setText( foundStd.getCurrentID().getId() );
						getPreName().setSelectedItem( foundStd.getCurrentPreName().getEpren() );
						getNameTextField().setText( foundStd.getCurrentName().getEname() );
						getFacComboBox().setSelectedIndex( selectedFacIndex );
						getFacComboBox().repaint();
						getDeptComboBox().setSelectedIndex( selectedDeptIndex );
						getDeptComboBox().repaint();
						getDOB().setDate( foundStd.getBirthdate() );
						getCitizenTextField().setText( foundStd.getCitizen() );
						getOriginTextField().setText( foundStd.getOrigin() );
						getReligionTextField().setText( foundStd.getReligion() );
						getStatusTextField().setText( foundStd.getStatus() );
						getTelTextField().setText( foundStd.getTel() );
						getAddressTextArea().setText( foundStd.getAddress() );
						

						getValidTimeDatePanel().clear();
			}

			m.show("Student has been updated.");
		} else m.show("Student Information hasn't been changed.");
		
		//End Tx
		Factory.getAdminDB().endTransaction();
	  
	} catch (DatabaseException dbe){
		System.out.println("Database Error in update() from sis.admin.StudentPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
}