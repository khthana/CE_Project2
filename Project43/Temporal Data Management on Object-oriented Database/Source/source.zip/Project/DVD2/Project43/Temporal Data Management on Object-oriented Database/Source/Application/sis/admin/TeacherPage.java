package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class TeacherPage extends JPanel implements java.awt.event.ActionListener, java.awt.event.ItemListener {
	private JComboBox ivjDeptComboBox = null;
	private JLabel ivjDeptLabel = null;
	private JComboBox ivjFacComboBox = null;
	private JLabel ivjFacLabel = null;
	private JLabel ivjIDLabel = null;
	private JTextField ivjIDTextField = null;
	private JLabel ivjNameLabel = null;
	private JTextField ivjNameTextField = null;
	private JButton ivjAddToolBarButton = null;
	private JButton ivjClearToolBarButton = null;
	private JButton ivjDeleteToolBarButton = null;
	private JButton ivjExitToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JButton ivjSaveToolBarButton = null;
	private JToolBar ivjToolBar = null;
	private DatePanel ivjValidTimeDatePanel = null;
	private JPanel ivjValidTimePanel = null;
	private JTextPane ivjValidTimeTextPane = null;
	private JPanel ivjInfoPanel = null;
	private PrenamePanel ivjPreName = null;
	private JButton ivjCancelDelButton = null;
	private JDialog ivjDeleteDialog = null;
	private JPanel ivjDeleteDialogContentPane = null;
	private JLabel ivjDeleteLabel = null;
	private JPanel ivjJPanel1 = null;
	private JPanel ivjJPanel2 = null;
	private JButton ivjOKDelButton = null;
	private Teacher foundTeach = null;
	private JPanel ivjButtonFindPanel = null;
	private JButton ivjCancelFindButton1 = null;
	private JLabel ivjFacultyListLabel1 = null;
	private JButton ivjFindButton1 = null;
	private JComboBox ivjFindFacComboBox = null;
	private JPanel ivjFindFacultyPanel = null;
	private JDialog ivjFindDialog = null;
	private JPanel ivjFindDialogContentPane = null;
	private FindPanel ivjFindPanel = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public TeacherPage() {
	super();
	initialize();
}
/**
 * Teacher constructor comment.
 * @param layout java.awt.LayoutManager
 */
public TeacherPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Teacher constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public TeacherPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * Teacher constructor comment.
 * @param isDoubleBuffered boolean
 */
public TeacherPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getDeleteToolBarButton()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC4(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoC6(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoM5(e);
	}
	if ((e.getSource() == getCancelDelButton()) ) {
		connEtoM6(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoM1(e);
	}
	if ((e.getSource() == getCancelFindButton1()) ) {
		connEtoM3(e);
	}
	if ((e.getSource() == getFindButton1()) ) {
		connEtoC5(e);
	}
	if ((e.getSource() == getCancelFindButton1()) ) {
		connEtoM8(e);
	}
	if ((e.getSource() == getCancelFindButton1()) ) {
		connEtoM4(e);
	}
	if ((e.getSource() == getFindFacComboBox()) ) {
		connEtoM9(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void add() throws Exception, java.rmi.RemoteException {
	
	try{
		
		//Check for valid form
		Message m = new Message();


		if (getIDTextField().getText().length() <= 0) {
			m.show("Teacher ID is empty.");
			return;
		}
		if (getNameTextField().getText().length() <= 0) {
			m.show("Teacher name is empty.");
			return;
		}
		if (getPreName().getSelectedItem() == null) {
			m.show("Teacher prename is empty.");
			return;
		}
		if (getFacComboBox().getSelectedIndex() == 0) {
			m.show("Teacher faculty is not selected.");
			return;
		}
		if (getDeptComboBox().getSelectedIndex() == 0) {
			m.show("Teacher department is not selected.");
			return;
		}
		
		if (getValidTimeDatePanel().getDate() == null) {
			m.show("Valid Time Start is not selected.");
			return;
		}

		//Start Tx
		Factory.getAdminDB().startTransaction();

		//Argument for getCurrentID(),getCurrentName()
		Object arg[] = new Object[0];

		//Get Department in Department Type
		DBObject	selectedFac		=	(DBObject)	Factory.getAllFacs().elementAt( getFacComboBox().getSelectedIndex() - 1 );
		DBObject	selectedFac_ID	=	(DBObject)	selectedFac.execMethod("getCurrentID",arg);
		String		selectedFacID	=				selectedFac_ID.getProperty("ID").toString();
		Faculty		teachFac		=				Faculty.findCurrentByID( Factory.getAdminDB(),
																			 selectedFacID );

		if ( teachFac == null ) {
			m.show("New Teacher can't be created. Fail to retrieve Faculty cbject.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		Integer		pos				=	(Integer)	Factory.getRealDeptPos().elementAt( 
															getDeptComboBox().getSelectedIndex() - 1 );
		DBObject	selectedDept	=	(DBObject)	Factory.getAllDepts().elementAt( pos.intValue() );
		DBObject	selectedDept_ID	=	(DBObject)	selectedDept.execMethod("getCurrentID",arg);
		String		selectedDeptID	=				selectedDept_ID.getProperty("ID").toString();		
		Department	teachDept			=				Department.findCurrentByID( Factory.getAdminDB(),
																				selectedDeptID,
																				teachFac);
		if ( teachDept == null ) {
			m.show("New Teacher can't be created. Fail to retrieve Department object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		
		java.sql.Date	vts		=	new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
		//Create new department
		Teacher		newTeacher	=	new	Teacher( Factory.getAdminDB() );
		newTeacher.create_this( getIDTextField().getText(),
								getPreName().getSelectedItem(),
								getNameTextField().getText(),
								teachDept,
								vts );
		
		//End Tx
		Factory.getAdminDB().endTransaction();

		//Clear form
		getIDTextField().setText("");
		getNameTextField().setText("");
		getPreName().clear();
		getFacComboBox().setSelectedIndex(0);
		getFacComboBox().repaint();
		getDeptComboBox().setSelectedIndex(0);
		getDeptComboBox().repaint();

				
	} catch (DatabaseException dbe) {
		System.out.println("Database Error in add() from sis.admin.TeacherPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	} catch (Exception e) {
		System.out.println("Error in add() from sis.admin.TeacherPage\n" + e.getMessage());
		e.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
public void addDeptToBox(JComboBox box, int selected) {

	try{
		if ( selected <= 0 ) {
			box.removeAllItems();
			box.addItem( "Selecte Faculty First");
			box.repaint();
			
		} else Factory.addDeptToBox( box, selected );
	} catch ( Exception e){
		System.out.println("Error in addDeptToBox(JComboBox,int) from sis.admin.Student\n" +
			e.getMessage() );
		e.printStackTrace();
	
	}


}
/**
 * This method was created in VisualAge.
 */
public void clear() {

	getDeptComboBox().setSelectedIndex(0);
	getFacComboBox().setSelectedIndex(0);
	getIDTextField().setText("");
	getNameTextField().setText("");
	getPreName().clear();

	//Clear	foundStudent
	foundTeach = null;

	//Enable&Disable some toolbar buttons
	getAddToolBarButton().setEnabled(true);
	getFindToolBarButton().setEnabled(true);
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);

}
/**
 * connEtoC1:  (ClearToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> TeacherPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> TeacherPage.add()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.add();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> TeacherPage.update()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.update();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (ExitToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> TeacherPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> TeacherPage.find()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.find();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC6:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> TeacherPage.delete()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.delete();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC7:  (FacComboBox.item.itemStateChanged(java.awt.event.ItemEvent) --> TeacherPage.addDeptToBox(Lcom.sun.java.swing.JComboBox;I)V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC7(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.addDeptToBox(getDeptComboBox(), getFacComboBox().getSelectedIndex());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (DeleteToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindPanel.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindPanel().clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (CancelDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (FacComboBox.item.itemStateChanged(java.awt.event.ItemEvent) --> FacComboBox.repaint()V)
 * @param arg1 java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM7(java.awt.event.ItemEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFacComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM8:  (CancelFindButton1.action.actionPerformed(java.awt.event.ActionEvent) --> FindFacComboBox.setSelectedIndex(I)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM8(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindFacComboBox().setSelectedIndex(0);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM9:  (FindFacComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> FindFacComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM9(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindFacComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void delete() throws Exception, java.rmi.RemoteException {
	
	try{

		Message m = new Message();
		java.sql.Date vte;

		//if there's no found Teacher then return
		if ( foundTeach == null )  {
			m.show("Can't update. Teacher not found.");	
			return;
		}
		//Check for VTE selection
		if ( getValidTimeDatePanel().getDate() == null ){
			m.show("Valid time for deleting is not selected.");
			return;
		} else vte = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	
		Factory.getAdminDB().startTransaction();
		foundTeach.delete_this(vte);
		foundTeach = null;
		Factory.getAdminDB().endTransaction();

		clear();
	
	} catch (DatabaseException dbe){
		System.out.println("Database Error in delete() from sis.admin.TeacherPage\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void find() throws Exception, java.rmi.RemoteException {
	try{
		//Start Tx
		Factory.getAdminDB().startTransaction();

	 	Teacher		_foundTeach	=	null;
	 	Faculty		sFac			=	null;
		Object 		arg[] 		= 	new Object[0];

		//Check Faculty in Find Diaglog is selected or not
	 	if ( getFindFacComboBox().getSelectedIndex() == 0 ){
			Message m = new Message();
			m.show("Faculty is not selected.");
			Factory.getAdminDB().endTransaction();
			return;
		} else { //Get seleted Faculty ID
				 DBObject selectedFac = (DBObject) Factory.getAllFacs().elementAt(
									getFindFacComboBox().getSelectedIndex() - 1 );

				 DBObject fac_ID	= (DBObject) selectedFac.execMethod("getCurrentID",arg);
				 sFac = Faculty.findCurrentByID( Factory.getAdminDB(), fac_ID.getProperty("ID").toString() );
			   }

		//Find		 
		if ( getFindPanel().getFindType().equals("ID") ){
		
			_foundTeach = Teacher.findCurrentByID( Factory.getAdminDB(),
												 getFindPanel().getText(),
												 sFac);
										   
		} else if ( getFindPanel().getFindType().equals("Name") ){
			_foundTeach = Teacher.findCurrentByName( Factory.getAdminDB(),
												   getFindPanel().getText(),
												   sFac);
		}

		//Check result
		//if Teacher didn't found then show message and return
		if ( _foundTeach == null ) {
			Message m = new Message();
			m.show("Teacher not found.");
			Factory.getAdminDB().endTransaction();
			return; }
		
		foundTeach = _foundTeach;
		

		//Show found Teacher

		getIDTextField().setText( foundTeach.getCurrentID().getId() );
		getNameTextField().setText( foundTeach.getCurrentName().getEname() );
		getPreName().setSelectedItem( foundTeach.getCurrentPreName().getEpren() );

		String	teachDeptID	=	foundTeach.getCurrentDept().getDept().getCurrentID().getId();
		String	teachFacID	=	foundTeach.getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();

		int	i,pos = -1;
		
		for ( i=0; i < Factory.getAllFacs().size(); i++ ){

			DBObject	fac			=	(DBObject)	Factory.getAllFacs().elementAt(i);
			DBObject	fac_ID		=	(DBObject)	fac.execMethod("getCurrentID",arg);
			String		facID		=				fac_ID.getProperty("ID").toString();

			if ( teachFacID.equals(facID) )
				pos = i;
			if ( pos >= 0 )
				break;
		}

		Factory.getAdminDB().endTransaction();
		

		if ( pos < 0 ) {	
			Message m = new Message();
			m.show("Can't display Faculty. Fail to retieve object.");
			getFacComboBox().setSelectedIndex( 0 );
			getFacComboBox().repaint();
		} else { getFacComboBox().setSelectedIndex( pos+1 );
				 getFacComboBox().repaint();
	   }

		Factory.getAdminDB().startTransaction();

		
		pos = -1;
		String deptFacPair[]	=	new String[2];
		
		for ( i=0; i < Factory.getRealDeptPos().size(); i++ ){

			deptFacPair	=	(String[])	Factory.getAllDeptIDs().elementAt(
										(new	Integer(Factory.getRealDeptPos().elementAt(i).toString())).intValue() );
			
			if ( teachDeptID.equals( deptFacPair[0] ) && teachFacID.equals( deptFacPair[1] ) )
				pos = i;
			if ( pos >= 0 )
				break;
		}

		if ( pos < 0 ) {	
			Message m = new Message();
			m.show("Can't display Department. Fail to retieve object.");
			getDeptComboBox().setSelectedIndex( 0 );
			getDeptComboBox().repaint();
		} else { getDeptComboBox().setSelectedIndex( pos+1 );
				 getDeptComboBox().repaint();
			   }

		
		getFindFacComboBox().setSelectedIndex(0);
		getFindFacComboBox().repaint();
		getValidTimeDatePanel().clear();
		getFindPanel().clear();
		getFindDialog().dispose();
		
		//Enable & disable some toolbar bottons
		getAddToolBarButton().setEnabled(false);
		getDeleteToolBarButton().setEnabled(true);
		getSaveToolBarButton().setEnabled(true);
		
		//End Tx
		Factory.getAdminDB().endTransaction();
		
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in find() from sis.admin.TeacherPage\n" + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in find() from sis.admin.TeacherPage\n" + e.getMessage() );
		e.printStackTrace();
	}


	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
/**
 * Return the AddToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getAddToolBarButton() {
	if (ivjAddToolBarButton == null) {
		try {
			ivjAddToolBarButton = new com.sun.java.swing.JButton();
			ivjAddToolBarButton.setName("AddToolBarButton");
			ivjAddToolBarButton.setToolTipText("Add new teacher");
			ivjAddToolBarButton.setText("");
			ivjAddToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjAddToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjAddToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\inserticon.gif"));
			ivjAddToolBarButton.setPreferredSize(new java.awt.Dimension(22, 23));
			ivjAddToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddToolBarButton;
}
/**
 * Return the ButtonFindPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getButtonFindPanel() {
	java.awt.GridBagConstraints constraintsFindButton1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelFindButton1 = new java.awt.GridBagConstraints();
	if (ivjButtonFindPanel == null) {
		try {
			ivjButtonFindPanel = new com.sun.java.swing.JPanel();
			ivjButtonFindPanel.setName("ButtonFindPanel");
			ivjButtonFindPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFindButton1.gridx = 0; constraintsFindButton1.gridy = 0;
			constraintsFindButton1.gridwidth = 1; constraintsFindButton1.gridheight = 1;
			constraintsFindButton1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindButton1.weightx = 0.0;
			constraintsFindButton1.weighty = 0.0;
			constraintsFindButton1.insets = new java.awt.Insets(0, 0, 0, 20);
			getButtonFindPanel().add(getFindButton1(), constraintsFindButton1);

			constraintsCancelFindButton1.gridx = -1; constraintsCancelFindButton1.gridy = -1;
			constraintsCancelFindButton1.gridwidth = 1; constraintsCancelFindButton1.gridheight = 1;
			constraintsCancelFindButton1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelFindButton1.weightx = 0.0;
			constraintsCancelFindButton1.weighty = 0.0;
			getButtonFindPanel().add(getCancelFindButton1(), constraintsCancelFindButton1);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonFindPanel;
}
/**
 * Return the CancelDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelDelButton() {
	if (ivjCancelDelButton == null) {
		try {
			ivjCancelDelButton = new com.sun.java.swing.JButton();
			ivjCancelDelButton.setName("CancelDelButton");
			ivjCancelDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelDelButton.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelDelButton;
}
/**
 * Return the CancelFindButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelFindButton1() {
	if (ivjCancelFindButton1 == null) {
		try {
			ivjCancelFindButton1 = new com.sun.java.swing.JButton();
			ivjCancelFindButton1.setName("CancelFindButton1");
			ivjCancelFindButton1.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelFindButton1.setText("Calcel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelFindButton1;
}
/**
 * Return the ClearToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the DeleteDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getDeleteDialog() {
	if (ivjDeleteDialog == null) {
		try {
			ivjDeleteDialog = new com.sun.java.swing.JDialog();
			ivjDeleteDialog.setName("DeleteDialog");
			ivjDeleteDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjDeleteDialog.setBounds(743, 436, 300, 100);
			ivjDeleteDialog.setModal(true);
			ivjDeleteDialog.setTitle("Delete Department");
			getDeleteDialog().setContentPane(getDeleteDialogContentPane());
			// user code begin {1}
			ivjDeleteDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjDeleteDialog.getBounds();
			ivjDeleteDialog.setBounds ( (screen.width - s.width)/2,
									    (screen.height - s.height)/2,
									  	s.width,
									  	s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialog;
}
/**
 * Return the DeleteDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getDeleteDialogContentPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	if (ivjDeleteDialogContentPane == null) {
		try {
			ivjDeleteDialogContentPane = new com.sun.java.swing.JPanel();
			ivjDeleteDialogContentPane.setName("DeleteDialogContentPane");
			ivjDeleteDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjDeleteDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 0;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			getDeleteDialogContentPane().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel2.gridx = 0; constraintsJPanel2.gridy = 1;
			constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
			constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel2.weightx = 0.0;
			constraintsJPanel2.weighty = 0.0;
			constraintsJPanel2.insets = new java.awt.Insets(10, 0, 10, 0);
			getDeleteDialogContentPane().add(getJPanel2(), constraintsJPanel2);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialogContentPane;
}
/**
 * Return the DeleteLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeleteLabel() {
	if (ivjDeleteLabel == null) {
		try {
			ivjDeleteLabel = new com.sun.java.swing.JLabel();
			ivjDeleteLabel.setName("DeleteLabel");
			ivjDeleteLabel.setText("Are you sure to delete this object?");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteLabel;
}
/**
 * Return the DeleteToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getDeleteToolBarButton() {
	if (ivjDeleteToolBarButton == null) {
		try {
			ivjDeleteToolBarButton = new com.sun.java.swing.JButton();
			ivjDeleteToolBarButton.setName("DeleteToolBarButton");
			ivjDeleteToolBarButton.setToolTipText("Delete this teacher");
			ivjDeleteToolBarButton.setText("");
			ivjDeleteToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDeleteToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDeleteToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\deleteicon.gif"));
			ivjDeleteToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteToolBarButton;
}
/**
 * Return the DeptComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getDeptComboBox() {
	if (ivjDeptComboBox == null) {
		try {
			ivjDeptComboBox = new com.sun.java.swing.JComboBox();
			ivjDeptComboBox.setName("DeptComboBox");
			ivjDeptComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjDeptComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeptComboBox;
}
/**
 * Return the DeptLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeptLabel() {
	if (ivjDeptLabel == null) {
		try {
			ivjDeptLabel = new com.sun.java.swing.JLabel();
			ivjDeptLabel.setName("DeptLabel");
			ivjDeptLabel.setText("Department");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeptLabel;
}
/**
 * Return the ExitToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the FacComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getFacComboBox() {
	if (ivjFacComboBox == null) {
		try {
			ivjFacComboBox = new com.sun.java.swing.JComboBox();
			ivjFacComboBox.setName("FacComboBox");
			ivjFacComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjFacComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacComboBox;
}
/**
 * Return the FacLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getFacLabel() {
	if (ivjFacLabel == null) {
		try {
			ivjFacLabel = new com.sun.java.swing.JLabel();
			ivjFacLabel.setName("FacLabel");
			ivjFacLabel.setText("Faculty");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacLabel;
}
/**
 * Return the FacultyListLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getFacultyListLabel1() {
	if (ivjFacultyListLabel1 == null) {
		try {
			ivjFacultyListLabel1 = new com.sun.java.swing.JLabel();
			ivjFacultyListLabel1.setName("FacultyListLabel1");
			ivjFacultyListLabel1.setText("Faculty");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFacultyListLabel1;
}
/**
 * Return the FindButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindButton1() {
	if (ivjFindButton1 == null) {
		try {
			ivjFindButton1 = new com.sun.java.swing.JButton();
			ivjFindButton1.setName("FindButton1");
			ivjFindButton1.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjFindButton1.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindButton1;
}
/**
 * Return the FindDialog1 property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getFindDialog() {
	if (ivjFindDialog == null) {
		try {
			ivjFindDialog = new com.sun.java.swing.JDialog();
			ivjFindDialog.setName("FindDialog");
			ivjFindDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjFindDialog.setResizable(false);
			ivjFindDialog.setBounds(717, 82, 340, 180);
			ivjFindDialog.setModal(true);
			ivjFindDialog.setTitle("Find Teacher");
			getFindDialog().setContentPane(getFindDialogContentPane());
			// user code begin {1}
			ivjFindDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjFindDialog.getBounds();
			ivjFindDialog.setBounds ( (screen.width - s.width)/2,
									  (screen.height - s.height)/2,
									  s.width,
									  s.height);			
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialog;
}
/**
 * Return the FindDialogContentPane1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindDialogContentPane() {
	java.awt.GridBagConstraints constraintsFindPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFindFacultyPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsButtonFindPanel = new java.awt.GridBagConstraints();
	if (ivjFindDialogContentPane == null) {
		try {
			ivjFindDialogContentPane = new com.sun.java.swing.JPanel();
			ivjFindDialogContentPane.setName("FindDialogContentPane");
			ivjFindDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjFindDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsFindPanel.gridx = 0; constraintsFindPanel.gridy = 0;
			constraintsFindPanel.gridwidth = 1; constraintsFindPanel.gridheight = 1;
			constraintsFindPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindPanel.weightx = 1.0;
			constraintsFindPanel.weighty = 0.0;
			constraintsFindPanel.insets = new java.awt.Insets(0, 0, 5, 0);
			getFindDialogContentPane().add(getFindPanel(), constraintsFindPanel);

			constraintsFindFacultyPanel.gridx = 0; constraintsFindFacultyPanel.gridy = 1;
			constraintsFindFacultyPanel.gridwidth = 1; constraintsFindFacultyPanel.gridheight = 1;
			constraintsFindFacultyPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindFacultyPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindFacultyPanel.weightx = 0.0;
			constraintsFindFacultyPanel.weighty = 0.0;
			getFindDialogContentPane().add(getFindFacultyPanel(), constraintsFindFacultyPanel);

			constraintsButtonFindPanel.gridx = 0; constraintsButtonFindPanel.gridy = 2;
			constraintsButtonFindPanel.gridwidth = 1; constraintsButtonFindPanel.gridheight = 1;
			constraintsButtonFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsButtonFindPanel.weightx = 0.0;
			constraintsButtonFindPanel.weighty = 0.0;
			constraintsButtonFindPanel.insets = new java.awt.Insets(10, 0, 10, 0);
			getFindDialogContentPane().add(getButtonFindPanel(), constraintsButtonFindPanel);
			// user code begin {1}
			Factory.addFacultyToBox( getFindFacComboBox() );
			getFindFacComboBox().setSelectedIndex(0);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialogContentPane;
}
/**
 * Return the FindFacComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getFindFacComboBox() {
	if (ivjFindFacComboBox == null) {
		try {
			ivjFindFacComboBox = new com.sun.java.swing.JComboBox();
			ivjFindFacComboBox.setName("FindFacComboBox");
			ivjFindFacComboBox.setPreferredSize(new java.awt.Dimension(200, 20));
			ivjFindFacComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindFacComboBox;
}
/**
 * Return the FindFacultyPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindFacultyPanel() {
	java.awt.GridBagConstraints constraintsFacultyListLabel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFindFacComboBox = new java.awt.GridBagConstraints();
	if (ivjFindFacultyPanel == null) {
		try {
			ivjFindFacultyPanel = new com.sun.java.swing.JPanel();
			ivjFindFacultyPanel.setName("FindFacultyPanel");
			ivjFindFacultyPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFacultyListLabel1.gridx = 0; constraintsFacultyListLabel1.gridy = 0;
			constraintsFacultyListLabel1.gridwidth = 1; constraintsFacultyListLabel1.gridheight = 1;
			constraintsFacultyListLabel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFacultyListLabel1.weightx = 0.0;
			constraintsFacultyListLabel1.weighty = 0.0;
			constraintsFacultyListLabel1.insets = new java.awt.Insets(5, 5, 5, 5);
			getFindFacultyPanel().add(getFacultyListLabel1(), constraintsFacultyListLabel1);

			constraintsFindFacComboBox.gridx = 1; constraintsFindFacComboBox.gridy = 0;
			constraintsFindFacComboBox.gridwidth = 1; constraintsFindFacComboBox.gridheight = 1;
			constraintsFindFacComboBox.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindFacComboBox.weightx = 0.0;
			constraintsFindFacComboBox.weighty = 0.0;
			constraintsFindFacComboBox.insets = new java.awt.Insets(5, 0, 5, 5);
			getFindFacultyPanel().add(getFindFacComboBox(), constraintsFindFacComboBox);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindFacultyPanel;
}
/**
 * Return the FindPanel1 property value.
 * @return sis.util.FindPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private FindPanel getFindPanel() {
	if (ivjFindPanel == null) {
		try {
			ivjFindPanel = new sis.util.FindPanel();
			ivjFindPanel.setName("FindPanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindPanel;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("Find teacher");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the IDLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getIDLabel() {
	if (ivjIDLabel == null) {
		try {
			ivjIDLabel = new com.sun.java.swing.JLabel();
			ivjIDLabel.setName("IDLabel");
			ivjIDLabel.setText("ID");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDLabel;
}
/**
 * Return the IDTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getInfoPanel() {
	java.awt.GridBagConstraints constraintsIDLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsPreName = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsFacComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeptLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeptComboBox = new java.awt.GridBagConstraints();
	if (ivjInfoPanel == null) {
		try {
			ivjInfoPanel = new com.sun.java.swing.JPanel();
			ivjInfoPanel.setName("InfoPanel");
			ivjInfoPanel.setLayout(new java.awt.GridBagLayout());

			constraintsIDLabel.gridx = 0; constraintsIDLabel.gridy = 0;
			constraintsIDLabel.gridwidth = 1; constraintsIDLabel.gridheight = 1;
			constraintsIDLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsIDLabel.weightx = 0.0;
			constraintsIDLabel.weighty = 0.0;
			constraintsIDLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getIDLabel(), constraintsIDLabel);

			constraintsIDTextField.gridx = 1; constraintsIDTextField.gridy = 0;
			constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
			constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsIDTextField.weightx = 0.0;
			constraintsIDTextField.weighty = 0.0;
			constraintsIDTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getIDTextField(), constraintsIDTextField);

			constraintsNameLabel.gridx = 0; constraintsNameLabel.gridy = 1;
			constraintsNameLabel.gridwidth = 1; constraintsNameLabel.gridheight = 1;
			constraintsNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsNameLabel.weightx = 0.0;
			constraintsNameLabel.weighty = 0.0;
			constraintsNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getNameLabel(), constraintsNameLabel);

			constraintsPreName.gridx = 1; constraintsPreName.gridy = 1;
			constraintsPreName.gridwidth = 1; constraintsPreName.gridheight = 1;
			constraintsPreName.anchor = java.awt.GridBagConstraints.WEST;
			constraintsPreName.weightx = 0.0;
			constraintsPreName.weighty = 0.0;
			constraintsPreName.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getPreName(), constraintsPreName);

			constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 2;
			constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
			constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsNameTextField.weightx = 0.0;
			constraintsNameTextField.weighty = 0.0;
			constraintsNameTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getNameTextField(), constraintsNameTextField);

			constraintsFacLabel.gridx = 0; constraintsFacLabel.gridy = 3;
			constraintsFacLabel.gridwidth = 1; constraintsFacLabel.gridheight = 1;
			constraintsFacLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsFacLabel.weightx = 0.0;
			constraintsFacLabel.weighty = 0.0;
			constraintsFacLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getFacLabel(), constraintsFacLabel);

			constraintsFacComboBox.gridx = 1; constraintsFacComboBox.gridy = 3;
			constraintsFacComboBox.gridwidth = 1; constraintsFacComboBox.gridheight = 1;
			constraintsFacComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsFacComboBox.weightx = 0.0;
			constraintsFacComboBox.weighty = 0.0;
			constraintsFacComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getFacComboBox(), constraintsFacComboBox);

			constraintsDeptLabel.gridx = 0; constraintsDeptLabel.gridy = 4;
			constraintsDeptLabel.gridwidth = 1; constraintsDeptLabel.gridheight = 1;
			constraintsDeptLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDeptLabel.weightx = 0.0;
			constraintsDeptLabel.weighty = 0.0;
			constraintsDeptLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getDeptLabel(), constraintsDeptLabel);

			constraintsDeptComboBox.gridx = 1; constraintsDeptComboBox.gridy = 4;
			constraintsDeptComboBox.gridwidth = 1; constraintsDeptComboBox.gridheight = 1;
			constraintsDeptComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsDeptComboBox.weightx = 0.0;
			constraintsDeptComboBox.weighty = 0.0;
			constraintsDeptComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getDeptComboBox(), constraintsDeptComboBox);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Teacher Information");
			ivjInfoPanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInfoPanel;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsDeleteLabel = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsDeleteLabel.gridx = 0; constraintsDeleteLabel.gridy = 0;
			constraintsDeleteLabel.gridwidth = 1; constraintsDeleteLabel.gridheight = 1;
			constraintsDeleteLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDeleteLabel.weightx = 0.0;
			constraintsDeleteLabel.weighty = 0.0;
			getJPanel1().add(getDeleteLabel(), constraintsDeleteLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsOKDelButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelDelButton = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsOKDelButton.gridx = 0; constraintsOKDelButton.gridy = 0;
			constraintsOKDelButton.gridwidth = 1; constraintsOKDelButton.gridheight = 1;
			constraintsOKDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKDelButton.weightx = 0.0;
			constraintsOKDelButton.weighty = 0.0;
			constraintsOKDelButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel2().add(getOKDelButton(), constraintsOKDelButton);

			constraintsCancelDelButton.gridx = -1; constraintsCancelDelButton.gridy = -1;
			constraintsCancelDelButton.gridwidth = 1; constraintsCancelDelButton.gridheight = 1;
			constraintsCancelDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelDelButton.weightx = 0.0;
			constraintsCancelDelButton.weighty = 0.0;
			getJPanel2().add(getCancelDelButton(), constraintsCancelDelButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the NameLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getNameLabel() {
	if (ivjNameLabel == null) {
		try {
			ivjNameLabel = new com.sun.java.swing.JLabel();
			ivjNameLabel.setName("NameLabel");
			ivjNameLabel.setText("Teach Name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameLabel;
}
/**
 * Return the NameTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(200, 19));
			ivjNameTextField.setMinimumSize(new java.awt.Dimension(200, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * Return the OKDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKDelButton() {
	if (ivjOKDelButton == null) {
		try {
			ivjOKDelButton = new com.sun.java.swing.JButton();
			ivjOKDelButton.setName("OKDelButton");
			ivjOKDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKDelButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKDelButton;
}
/**
 * Return the PrenamePanel property value.
 * @return sis.util.PrenamePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private PrenamePanel getPreName() {
	if (ivjPreName == null) {
		try {
			ivjPreName = new sis.util.PrenamePanel();
			ivjPreName.setName("PreName");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjPreName;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Save change");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the ToolBar property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getToolBar() {
	if (ivjToolBar == null) {
		try {
			ivjToolBar = new com.sun.java.swing.JToolBar();
			ivjToolBar.setName("ToolBar");
			ivjToolBar.add(getClearToolBarButton());
			ivjToolBar.addSeparator();
			getToolBar().add(getAddToolBarButton(), getAddToolBarButton().getName());
			getToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			getToolBar().add(getDeleteToolBarButton(), getDeleteToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjToolBar;
}
/**
 * Return the ValidTimeDatePanel property value.
 * @return sis.util.DatePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DatePanel getValidTimeDatePanel() {
	if (ivjValidTimeDatePanel == null) {
		try {
			ivjValidTimeDatePanel = new sis.util.DatePanel();
			ivjValidTimeDatePanel.setName("ValidTimeDatePanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeDatePanel;
}
/**
 * Return the ValidTimePanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getValidTimePanel() {
	java.awt.GridBagConstraints constraintsValidTimeTextPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsValidTimeDatePanel = new java.awt.GridBagConstraints();
	if (ivjValidTimePanel == null) {
		try {
			ivjValidTimePanel = new com.sun.java.swing.JPanel();
			ivjValidTimePanel.setName("ValidTimePanel");
			ivjValidTimePanel.setLayout(new java.awt.GridBagLayout());

			constraintsValidTimeTextPane.gridx = 1; constraintsValidTimeTextPane.gridy = 1;
			constraintsValidTimeTextPane.gridwidth = 1; constraintsValidTimeTextPane.gridheight = 1;
			constraintsValidTimeTextPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsValidTimeTextPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeTextPane.weightx = 1.0;
			constraintsValidTimeTextPane.weighty = 1.0;
			getValidTimePanel().add(getValidTimeTextPane(), constraintsValidTimeTextPane);

			constraintsValidTimeDatePanel.gridx = 1; constraintsValidTimeDatePanel.gridy = 2;
			constraintsValidTimeDatePanel.gridwidth = 1; constraintsValidTimeDatePanel.gridheight = 1;
			constraintsValidTimeDatePanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeDatePanel.weightx = 0.0;
			constraintsValidTimeDatePanel.weighty = 0.0;
			getValidTimePanel().add(getValidTimeDatePanel(), constraintsValidTimeDatePanel);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Valid Time");
			ivjValidTimePanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimePanel;
}
/**
 * Return the ValidTimeTextPane property value.
 * @return com.sun.java.swing.JTextPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextPane getValidTimeTextPane() {
	if (ivjValidTimeTextPane == null) {
		try {
			ivjValidTimeTextPane = new com.sun.java.swing.JTextPane();
			ivjValidTimeTextPane.setName("ValidTimeTextPane");
			ivjValidTimeTextPane.setPreferredSize(new java.awt.Dimension(30, 60));
			ivjValidTimeTextPane.setText("This time is used for,\n \t- insert, valid time start of this object\n\t- delete, valid time end of this object\n\t- update, valid time end of old property and valid time start for new property\n\t\t     valid time start of new property");
			ivjValidTimeTextPane.setBackground(new java.awt.Color(204,204,204));
			ivjValidTimeTextPane.setEditable(false);
			// user code begin {1}
			Border empty;
			empty = BorderFactory.createEmptyBorder(0,10,10,10);
			ivjValidTimeTextPane.setBorder(empty);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeTextPane;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getAddToolBarButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
	getDeleteToolBarButton().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
	getOKDelButton().addActionListener(this);
	getCancelDelButton().addActionListener(this);
	getFacComboBox().addItemListener(this);
	getFindToolBarButton().addActionListener(this);
	getCancelFindButton1().addActionListener(this);
	getFindButton1().addActionListener(this);
	getFindFacComboBox().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Teacher");
	setLayout(new java.awt.BorderLayout());
	setSize(457, 391);
	add(getToolBar(), "North");
	add(getInfoPanel(), "Center");
	add(getValidTimePanel(), "South");
	initConnections();
	// user code begin {2}
	Factory.addFacultyToBox( getFacComboBox() );
	//Disable some toolbar buttons
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
	// user code end
}
/**
 * Method to handle events for the ItemListener interface.
 * @param e java.awt.event.ItemEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void itemStateChanged(java.awt.event.ItemEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getFacComboBox()) ) {
		connEtoM7(e);
	}
	if ((e.getSource() == getFacComboBox()) ) {
		connEtoC7(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		TeacherPage aTeacherPage;
		aTeacherPage = new TeacherPage();
		frame.getContentPane().add("Center", aTeacherPage);
		frame.setSize(aTeacherPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void update() throws Exception, java.rmi.RemoteException {
	Message m = new Message();

	//if there's no found Teacher then return
	if ( foundTeach == null )  {
		m.show("Can't update. Teacher not found.");	
		return;
	}

	//Check seleted Faculty and Department
	if ( getFacComboBox().getSelectedIndex() == 0 ){
		m.show("Faculty isn't seleted.");
		return;
	}
	
	if ( getDeptComboBox().getSelectedIndex() == 0 ){
		m.show("Department isn't seleted.");
		return;
	}
	
	//Check for valid time selection
	if ( getValidTimeDatePanel().getDate() == null ) {
		m.show("Valid time isn't selected.");
		return;
	}

	//Valid Time,use for passing
	java.sql.Date valid = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	//Set if there's update
	boolean update = false;

	try{
		//Strat Tx
		Factory.getAdminDB().startTransaction();

		//Get Dept ID from form
		Object 	arg[]			=	new	Object[0];
		int		i,pos 			= 	-1;
		String 	deptFacPair[]	=	new String[2];
		
		String	teachDeptID		=	foundTeach.getCurrentDept().getDept().getCurrentID().getId();
		String	teachFacID		=	foundTeach.getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();

		Faculty	cFac			=	foundTeach.getCurrentDept().getDept().getCurrentFac().getFac();

		deptFacPair	=	(String[])	Factory.getAllDeptIDs().elementAt(
								(new	Integer(Factory.getRealDeptPos().elementAt( getDeptComboBox().getSelectedIndex()-1 ).toString())).intValue() );

		if ( !(teachDeptID.equals(deptFacPair[0]) && teachFacID.equals(deptFacPair[1])) ){
			
			        	cFac	=	Faculty.findCurrentByID( Factory.getAdminDB(),
															 deptFacPair[1] );
			Department	cDept	=	Department.findCurrentByID( Factory.getAdminDB(),
															 deptFacPair[0],
															 cFac);
			foundTeach.update_Dept( foundTeach.getCurrentDept().getDept(),
									cDept,
									valid,
									valid);
			update = true;
			System.out.println("Teacher Department has been updated.");
		}
		

		if ( !getIDTextField().getText().equals( foundTeach.getCurrentID().getId() ) ){
			  foundTeach.update_ID( foundTeach.getCurrentID().getId(),
									getIDTextField().getText(),
									valid,
									valid);
			  update = true;
			  System.out.println("Teacher ID has been updated.");
		}

		if ( !getPreName().getSelectedItem().equals(foundTeach.getCurrentPreName().getEpren()) ){
			  foundTeach.update_ePren( foundTeach.getCurrentPreName().getEpren(),
									   getPreName().getSelectedItem(),
									   valid,
									   valid);
			  update = true;
			  System.out.println("Teacher Prename has been updated.");
		}
		

		if ( !getNameTextField().getText().equals( foundTeach.getCurrentName().getEname() ) ){
			 foundTeach.update_eName( foundTeach.getCurrentName().getEname(),
									  getNameTextField().getText(),
									  valid,
								 	  valid);
			  update = true;
			  System.out.println("Teacher Name has been updated.");
		}

		//Refresh foundStd
		if ( update ){

			int selectedFacIndex 	=	getFacComboBox().getSelectedIndex();
			int selectedDeptIndex 	=	getDeptComboBox().getSelectedIndex();

			//Find		 
			foundTeach	= 	null;
			foundTeach	= 	Teacher.findCurrentByID( Factory.getAdminDB(),
										          	 getIDTextField().getText(),
										          	 cFac);
			
			if ( foundTeach == null ){
				m.show("Can't display updated information");
				clear();
			} else {	//Show
						getIDTextField().setText( foundTeach.getCurrentID().getId() );
						getPreName().setSelectedItem( foundTeach.getCurrentPreName().getEpren() );
						getNameTextField().setText( foundTeach.getCurrentName().getEname() );
						getFacComboBox().setSelectedIndex( selectedFacIndex );
						getFacComboBox().repaint();
						getDeptComboBox().setSelectedIndex( selectedDeptIndex );
						getDeptComboBox().repaint();

						getValidTimeDatePanel().clear();
			}

			m.show("Teacher has been updated.");
		} else m.show("Teacher Information hasn't been changed.");

		
		//End Tx
		Factory.getAdminDB().endTransaction();
	  
	} catch (DatabaseException dbe){
		System.out.println("Database Error in update() from sis.admin.TeacherPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
}