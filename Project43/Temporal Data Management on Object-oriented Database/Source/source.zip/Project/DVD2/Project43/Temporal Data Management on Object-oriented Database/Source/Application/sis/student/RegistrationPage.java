package sis.student;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class RegistrationPage extends JPanel implements java.awt.event.ActionListener {
	private JLabel ivjRegCreditLabel = null;
	private JLabel ivjRegIdLabel = null;
	private JLabel ivjRegNameLabel = null;
	private JLabel ivjRegSubjIdLabel = null;
	private JLabel ivjRegSubjNameLabel = null;
	private JPanel ivjButtonPane = null;
	private JButton ivjOKButton = null;
	private JPanel ivjRegInfoPane = null;
	private JPanel ivjSbjInfoPane = null;
	private JPanel ivjStdInfoPane = null;
	public Vector regSubjects = null;
	private JPanel ivjJPanel1 = null;
	private SubjectForm ivjSubject0 = null;
	private SubjectForm ivjSubject1 = null;
	private SubjectForm ivjSubject2 = null;
	private SubjectForm ivjSubject3 = null;
	private SubjectForm ivjSubject4 = null;
	private SubjectForm ivjSubject5 = null;
	private SubjectForm ivjSubject6 = null;
	private SubjectForm ivjSubject7 = null;
	private JButton ivjClearButton = null;
	private JTextField ivjIDTextField = null;
	private JTextField ivjNameTextField = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public RegistrationPage() {
	super();
	initialize();
}
/**
 * RegistrationPage constructor comment.
 * @param layout java.awt.LayoutManager
 */
public RegistrationPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * RegistrationPage constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public RegistrationPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * RegistrationPage constructor comment.
 * @param isDoubleBuffered boolean
 */
public RegistrationPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getOKButton()) ) {
		connEtoC2(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * This method was created in VisualAge.
 */
public void clear() {

	getIDTextField().setText("");
	getNameTextField().setText("");
	getSubject0().clear();
	getSubject1().clear();
	getSubject2().clear();
	getSubject3().clear();
	getSubject4().clear();
	getSubject5().clear();
	getSubject6().clear();
	getSubject7().clear();
}
/**
 * connEtoC1:  (CancelButton.action.actionPerformed(java.awt.event.ActionEvent) --> RegistrationPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (OKButton.action.actionPerformed(java.awt.event.ActionEvent) --> RegistrationPage.register()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.register();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the RegBottonPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getButtonPane() {
	java.awt.GridBagConstraints constraintsOKButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsClearButton = new java.awt.GridBagConstraints();
	if (ivjButtonPane == null) {
		try {
			ivjButtonPane = new com.sun.java.swing.JPanel();
			ivjButtonPane.setName("ButtonPane");
			ivjButtonPane.setLayout(new java.awt.GridBagLayout());

			constraintsOKButton.gridx = 0; constraintsOKButton.gridy = 0;
			constraintsOKButton.gridwidth = 1; constraintsOKButton.gridheight = 1;
			constraintsOKButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKButton.weightx = 0.0;
			constraintsOKButton.weighty = 0.0;
			constraintsOKButton.insets = new java.awt.Insets(5, 5, 5, 5);
			getButtonPane().add(getOKButton(), constraintsOKButton);

			constraintsClearButton.gridx = 1; constraintsClearButton.gridy = 0;
			constraintsClearButton.gridwidth = 1; constraintsClearButton.gridheight = 1;
			constraintsClearButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsClearButton.weightx = 0.0;
			constraintsClearButton.weighty = 0.0;
			constraintsClearButton.insets = new java.awt.Insets(5, 5, 5, 5);
			getButtonPane().add(getClearButton(), constraintsClearButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonPane;
}
/**
 * Return the RegCancelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearButton() {
	if (ivjClearButton == null) {
		try {
			ivjClearButton = new com.sun.java.swing.JButton();
			ivjClearButton.setName("ClearButton");
			ivjClearButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjClearButton.setText("Clear");
			ivjClearButton.setMinimumSize(new java.awt.Dimension(85, 25));
			ivjClearButton.setMaximumSize(new java.awt.Dimension(85, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearButton;
}
/**
 * Return the RegIdTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(100, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsRegSubjIdLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsRegSubjNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsRegCreditLabel = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsRegSubjIdLabel.gridx = 1; constraintsRegSubjIdLabel.gridy = 1;
			constraintsRegSubjIdLabel.gridwidth = 1; constraintsRegSubjIdLabel.gridheight = 1;
			constraintsRegSubjIdLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsRegSubjIdLabel.weightx = 0.0;
			constraintsRegSubjIdLabel.weighty = 0.0;
			constraintsRegSubjIdLabel.insets = new java.awt.Insets(0, 10, 5, 5);
			getJPanel1().add(getRegSubjIdLabel(), constraintsRegSubjIdLabel);

			constraintsRegSubjNameLabel.gridx = 2; constraintsRegSubjNameLabel.gridy = 1;
			constraintsRegSubjNameLabel.gridwidth = 1; constraintsRegSubjNameLabel.gridheight = 1;
			constraintsRegSubjNameLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsRegSubjNameLabel.weightx = 0.0;
			constraintsRegSubjNameLabel.weighty = 0.0;
			constraintsRegSubjNameLabel.insets = new java.awt.Insets(0, 15, 5, 15);
			getJPanel1().add(getRegSubjNameLabel(), constraintsRegSubjNameLabel);

			constraintsRegCreditLabel.gridx = 3; constraintsRegCreditLabel.gridy = 1;
			constraintsRegCreditLabel.gridwidth = 1; constraintsRegCreditLabel.gridheight = 1;
			constraintsRegCreditLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsRegCreditLabel.weightx = 0.0;
			constraintsRegCreditLabel.weighty = 0.0;
			constraintsRegCreditLabel.insets = new java.awt.Insets(0, 5, 5, 10);
			getJPanel1().add(getRegCreditLabel(), constraintsRegCreditLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the RegNameTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * Return the RegOKButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKButton() {
	if (ivjOKButton == null) {
		try {
			ivjOKButton = new com.sun.java.swing.JButton();
			ivjOKButton.setName("OKButton");
			ivjOKButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKButton.setText("OK");
			ivjOKButton.setMinimumSize(new java.awt.Dimension(85, 25));
			ivjOKButton.setMaximumSize(new java.awt.Dimension(85, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKButton;
}
/**
 * Return the RegCreditLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getRegCreditLabel() {
	if (ivjRegCreditLabel == null) {
		try {
			ivjRegCreditLabel = new com.sun.java.swing.JLabel();
			ivjRegCreditLabel.setName("RegCreditLabel");
			ivjRegCreditLabel.setText("Credit");
			ivjRegCreditLabel.setMaximumSize(new java.awt.Dimension(50, 15));
			ivjRegCreditLabel.setPreferredSize(new java.awt.Dimension(50, 15));
			ivjRegCreditLabel.setMinimumSize(new java.awt.Dimension(50, 15));
			ivjRegCreditLabel.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegCreditLabel;
}
/**
 * Return the RegIdLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getRegIdLabel() {
	if (ivjRegIdLabel == null) {
		try {
			ivjRegIdLabel = new com.sun.java.swing.JLabel();
			ivjRegIdLabel.setName("RegIdLabel");
			ivjRegIdLabel.setText("ID");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegIdLabel;
}
/**
 * Return the Page property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getRegInfoPane() {
	java.awt.GridBagConstraints constraintsSbjInfoPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsButtonPane = new java.awt.GridBagConstraints();
	if (ivjRegInfoPane == null) {
		try {
			ivjRegInfoPane = new com.sun.java.swing.JPanel();
			ivjRegInfoPane.setName("RegInfoPane");
			ivjRegInfoPane.setLayout(new java.awt.GridBagLayout());

			constraintsSbjInfoPane.gridx = 0; constraintsSbjInfoPane.gridy = 0;
			constraintsSbjInfoPane.gridwidth = 1; constraintsSbjInfoPane.gridheight = 1;
			constraintsSbjInfoPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsSbjInfoPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSbjInfoPane.weightx = 1.0;
			constraintsSbjInfoPane.weighty = 1.0;
			getRegInfoPane().add(getSbjInfoPane(), constraintsSbjInfoPane);

			constraintsButtonPane.gridx = 0; constraintsButtonPane.gridy = 1;
			constraintsButtonPane.gridwidth = 1; constraintsButtonPane.gridheight = 1;
			constraintsButtonPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsButtonPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsButtonPane.weightx = 0.0;
			constraintsButtonPane.weighty = 0.0;
			constraintsButtonPane.insets = new java.awt.Insets(20, 0, 0, 0);
			getRegInfoPane().add(getButtonPane(), constraintsButtonPane);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegInfoPane;
}
/**
 * Return the RegNameLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getRegNameLabel() {
	if (ivjRegNameLabel == null) {
		try {
			ivjRegNameLabel = new com.sun.java.swing.JLabel();
			ivjRegNameLabel.setName("RegNameLabel");
			ivjRegNameLabel.setText("Name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegNameLabel;
}
/**
 * This method was created in VisualAge.
 * @return java.util.Vector
 */
public Vector getRegSubjects() {

		
	return regSubjects;
}
/**
 * Return the RegSubjIdLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getRegSubjIdLabel() {
	if (ivjRegSubjIdLabel == null) {
		try {
			ivjRegSubjIdLabel = new com.sun.java.swing.JLabel();
			ivjRegSubjIdLabel.setName("RegSubjIdLabel");
			ivjRegSubjIdLabel.setText("Subject ID");
			ivjRegSubjIdLabel.setMaximumSize(new java.awt.Dimension(100, 15));
			ivjRegSubjIdLabel.setPreferredSize(new java.awt.Dimension(100, 15));
			ivjRegSubjIdLabel.setMinimumSize(new java.awt.Dimension(100, 15));
			ivjRegSubjIdLabel.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegSubjIdLabel;
}
/**
 * Return the RegSubjNameLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getRegSubjNameLabel() {
	if (ivjRegSubjNameLabel == null) {
		try {
			ivjRegSubjNameLabel = new com.sun.java.swing.JLabel();
			ivjRegSubjNameLabel.setName("RegSubjNameLabel");
			ivjRegSubjNameLabel.setText("Subject Name");
			ivjRegSubjNameLabel.setMaximumSize(new java.awt.Dimension(250, 15));
			ivjRegSubjNameLabel.setPreferredSize(new java.awt.Dimension(250, 15));
			ivjRegSubjNameLabel.setMinimumSize(new java.awt.Dimension(250, 15));
			ivjRegSubjNameLabel.setHorizontalAlignment(com.sun.java.swing.SwingConstants.CENTER);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjRegSubjNameLabel;
}
/**
 * Return the RegSubjInfoPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getSbjInfoPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject0 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject2 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject3 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject4 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject5 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject6 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSubject7 = new java.awt.GridBagConstraints();
	if (ivjSbjInfoPane == null) {
		try {
			ivjSbjInfoPane = new com.sun.java.swing.JPanel();
			ivjSbjInfoPane.setName("SbjInfoPane");
			ivjSbjInfoPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 0;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			constraintsJPanel1.insets = new java.awt.Insets(10, 5, 20, 5);
			getSbjInfoPane().add(getJPanel1(), constraintsJPanel1);

			constraintsSubject0.gridx = 0; constraintsSubject0.gridy = 1;
			constraintsSubject0.gridwidth = 1; constraintsSubject0.gridheight = 1;
			constraintsSubject0.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject0.weightx = 0.0;
			constraintsSubject0.weighty = 0.0;
			getSbjInfoPane().add(getSubject0(), constraintsSubject0);

			constraintsSubject1.gridx = 0; constraintsSubject1.gridy = 2;
			constraintsSubject1.gridwidth = 1; constraintsSubject1.gridheight = 1;
			constraintsSubject1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject1.weightx = 0.0;
			constraintsSubject1.weighty = 0.0;
			getSbjInfoPane().add(getSubject1(), constraintsSubject1);

			constraintsSubject2.gridx = 0; constraintsSubject2.gridy = 3;
			constraintsSubject2.gridwidth = 1; constraintsSubject2.gridheight = 1;
			constraintsSubject2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject2.weightx = 0.0;
			constraintsSubject2.weighty = 0.0;
			getSbjInfoPane().add(getSubject2(), constraintsSubject2);

			constraintsSubject3.gridx = 0; constraintsSubject3.gridy = 4;
			constraintsSubject3.gridwidth = 1; constraintsSubject3.gridheight = 1;
			constraintsSubject3.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject3.weightx = 0.0;
			constraintsSubject3.weighty = 0.0;
			getSbjInfoPane().add(getSubject3(), constraintsSubject3);

			constraintsSubject4.gridx = 0; constraintsSubject4.gridy = 5;
			constraintsSubject4.gridwidth = 1; constraintsSubject4.gridheight = 1;
			constraintsSubject4.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject4.weightx = 0.0;
			constraintsSubject4.weighty = 0.0;
			getSbjInfoPane().add(getSubject4(), constraintsSubject4);

			constraintsSubject5.gridx = 0; constraintsSubject5.gridy = 6;
			constraintsSubject5.gridwidth = 1; constraintsSubject5.gridheight = 1;
			constraintsSubject5.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject5.weightx = 0.0;
			constraintsSubject5.weighty = 0.0;
			getSbjInfoPane().add(getSubject5(), constraintsSubject5);

			constraintsSubject6.gridx = 0; constraintsSubject6.gridy = 8;
			constraintsSubject6.gridwidth = 1; constraintsSubject6.gridheight = 1;
			constraintsSubject6.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject6.weightx = 0.0;
			constraintsSubject6.weighty = 0.0;
			getSbjInfoPane().add(getSubject6(), constraintsSubject6);

			constraintsSubject7.gridx = 0; constraintsSubject7.gridy = 7;
			constraintsSubject7.gridwidth = 1; constraintsSubject7.gridheight = 1;
			constraintsSubject7.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsSubject7.weightx = 0.0;
			constraintsSubject7.weighty = 0.0;
			getSbjInfoPane().add(getSubject7(), constraintsSubject7);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Subject Information");
			ivjSbjInfoPane.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSbjInfoPane;
}
/**
 * Return the RegStdInfoPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getStdInfoPane() {
	java.awt.GridBagConstraints constraintsRegIdLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsRegNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	if (ivjStdInfoPane == null) {
		try {
			ivjStdInfoPane = new com.sun.java.swing.JPanel();
			ivjStdInfoPane.setName("StdInfoPane");
			ivjStdInfoPane.setLayout(new java.awt.GridBagLayout());

			constraintsRegIdLabel.gridx = 0; constraintsRegIdLabel.gridy = 0;
			constraintsRegIdLabel.gridwidth = 1; constraintsRegIdLabel.gridheight = 1;
			constraintsRegIdLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsRegIdLabel.weightx = 0.0;
			constraintsRegIdLabel.weighty = 0.0;
			constraintsRegIdLabel.insets = new java.awt.Insets(10, 10, 5, 10);
			getStdInfoPane().add(getRegIdLabel(), constraintsRegIdLabel);

			constraintsRegNameLabel.gridx = 0; constraintsRegNameLabel.gridy = 1;
			constraintsRegNameLabel.gridwidth = 1; constraintsRegNameLabel.gridheight = 1;
			constraintsRegNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsRegNameLabel.weightx = 0.0;
			constraintsRegNameLabel.weighty = 0.0;
			constraintsRegNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getStdInfoPane().add(getRegNameLabel(), constraintsRegNameLabel);

			constraintsIDTextField.gridx = 1; constraintsIDTextField.gridy = 0;
			constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
			constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsIDTextField.weightx = 0.0;
			constraintsIDTextField.weighty = 0.0;
			constraintsIDTextField.insets = new java.awt.Insets(10, 0, 5, 10);
			getStdInfoPane().add(getIDTextField(), constraintsIDTextField);

			constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 1;
			constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
			constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsNameTextField.weightx = 0.0;
			constraintsNameTextField.weighty = 0.0;
			constraintsNameTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getStdInfoPane().add(getNameTextField(), constraintsNameTextField);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Student Information");
			ivjStdInfoPane.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjStdInfoPane;
}
/**
 * Return the sbj property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject0() {
	if (ivjSubject0 == null) {
		try {
			ivjSubject0 = new sis.student.SubjectForm();
			ivjSubject0.setName("Subject0");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject0;
}
/**
 * Return the SubjectForm property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject1() {
	if (ivjSubject1 == null) {
		try {
			ivjSubject1 = new sis.student.SubjectForm();
			ivjSubject1.setName("Subject1");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject1;
}
/**
 * Return the SubjectForm1 property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject2() {
	if (ivjSubject2 == null) {
		try {
			ivjSubject2 = new sis.student.SubjectForm();
			ivjSubject2.setName("Subject2");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject2;
}
/**
 * Return the SubjectForm2 property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject3() {
	if (ivjSubject3 == null) {
		try {
			ivjSubject3 = new sis.student.SubjectForm();
			ivjSubject3.setName("Subject3");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject3;
}
/**
 * Return the SubjectForm3 property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject4() {
	if (ivjSubject4 == null) {
		try {
			ivjSubject4 = new sis.student.SubjectForm();
			ivjSubject4.setName("Subject4");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject4;
}
/**
 * Return the SubjectForm4 property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject5() {
	if (ivjSubject5 == null) {
		try {
			ivjSubject5 = new sis.student.SubjectForm();
			ivjSubject5.setName("Subject5");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject5;
}
/**
 * Return the SubjectForm5 property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject6() {
	if (ivjSubject6 == null) {
		try {
			ivjSubject6 = new sis.student.SubjectForm();
			ivjSubject6.setName("Subject6");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject6;
}
/**
 * Return the SubjectForm6 property value.
 * @return sis.student.SubjectForm
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private SubjectForm getSubject7() {
	if (ivjSubject7 == null) {
		try {
			ivjSubject7 = new sis.student.SubjectForm();
			ivjSubject7.setName("Subject7");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSubject7;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearButton().addActionListener(this);
	getOKButton().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsStdInfoPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsRegInfoPane = new java.awt.GridBagConstraints();
	setName("RegistrationPage");
	setLayout(new java.awt.GridBagLayout());
	setSize(511, 424);

	constraintsStdInfoPane.gridx = 0; constraintsStdInfoPane.gridy = 0;
	constraintsStdInfoPane.gridwidth = 1; constraintsStdInfoPane.gridheight = 1;
	constraintsStdInfoPane.anchor = java.awt.GridBagConstraints.WEST;
	constraintsStdInfoPane.weightx = 0.0;
	constraintsStdInfoPane.weighty = 0.0;
	constraintsStdInfoPane.insets = new java.awt.Insets(10, 10, 10, 10);
	add(getStdInfoPane(), constraintsStdInfoPane);

	constraintsRegInfoPane.gridx = 0; constraintsRegInfoPane.gridy = 1;
	constraintsRegInfoPane.gridwidth = 1; constraintsRegInfoPane.gridheight = 1;
	constraintsRegInfoPane.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsRegInfoPane.weightx = 0.0;
	constraintsRegInfoPane.weighty = 0.0;
	constraintsRegInfoPane.insets = new java.awt.Insets(5, 10, 5, 10);
	add(getRegInfoPane(), constraintsRegInfoPane);
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		RegistrationPage aRegistrationPage;
		aRegistrationPage = new RegistrationPage();
		frame.getContentPane().add("Center", aRegistrationPage);
		frame.setSize(aRegistrationPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 */
public void register()throws Exception, java.rmi.RemoteException {
	
	try {

		Factory.getStdDB().startTransaction();

		Message m	= 	new Message();
		boolean	reg	= 	false;
		Student	std	=	Student.findCurrentByID( Factory.getStdDB(),
											getIDTextField().getText() );

		if ( std == null ){
			m.show("Fail to retieve Student oObject.");
			Factory.getStdDB().endTransaction();
			clear();
			return;
		}
			

		


		if ( (getSubject0().getID().length() > 0) && (getSubject0().getSubject() == null) ){
			m.show("Subject ID " +  getSubject0().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject1().getID().length() > 0) && (getSubject1().getSubject() == null) ){
			m.show("Subject ID " +  getSubject1().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject2().getID().length() > 0) && (getSubject2().getSubject() == null) ){
			m.show("Subject ID " +  getSubject2().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject3().getID().length() > 0) && (getSubject3().getSubject() == null) ){
			m.show("Subject ID " +  getSubject3().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject4().getID().length() > 0) && (getSubject4().getSubject() == null) ){
			m.show("Subject ID " +  getSubject4().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject5().getID().length() > 0) && (getSubject5().getSubject() == null) ){
			m.show("Subject ID " +  getSubject5().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject5().getID().length() > 0) && (getSubject5().getSubject() == null) ){
			m.show("Subject ID " +  getSubject4().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}

		if ( (getSubject6().getID().length() > 0) && (getSubject6().getSubject() == null) ){
			m.show("Subject ID " +  getSubject4().getID() + " is incorrect.");
			Factory.getStdDB().endTransaction();
			return;
		}


		Semester	newSemester		=	new	Semester( Factory.getStdDB() );
		
		newSemester.setYear( Semester.getDefaultyear(Factory.getStdDB()) );
		newSemester.setTerm( Semester.getDefaultterm(Factory.getStdDB()) );
		newSemester.setRegtype("Normal");
		newSemester.setCa(0);
		newSemester.setCp(0);
		newSemester.setCd(0);
		newSemester.setSemester_status("Normal");
		
		SetOfObject	subjGrade	=	new SetOfObject(Factory.getStdDB(),
													"jp.jasmine.TempCF.Semester" );

		
		if ( getSubject0().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject0().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject0().getSubject().getCredit() );
			reg	=	true;
		}

		if ( getSubject1().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject1().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject1().getSubject().getCredit() );
			reg	=	true;
		}

		if ( getSubject2().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject2().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject2().getSubject().getCredit() );
			reg	=	true;
		}
		if ( getSubject3().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject3().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject3().getSubject().getCredit() );
			reg	=	true;
		}
		if ( getSubject4().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject4().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject4().getSubject().getCredit() );
			reg	=	true;
		}
		if ( getSubject5().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject5().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject5().getSubject().getCredit() );
			reg	=	true;
		}
		if ( getSubject6().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject6().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject6().getSubject().getCredit() );
			reg	=	true;
		}
		if ( getSubject7().getID().length() == 8 ){
			newSemester.insert_Subject( getSubject7().getSubject() );
			newSemester.setCa( newSemester.getCa() + getSubject7().getSubject().getCredit() );
			reg	=	true;
		}


		if ( reg ){
			std.insert_Semester( newSemester );
			m.show("Registration Complete");
			clear();
		} else m.show("Registration Incomplete");
		
		
		Factory.getStdDB().endTransaction();


	} catch (DatabaseException dbe){
		System.out.println("Database Error in register() from sis.student.RegistrationPage\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in in register() from sis.student.RegistrationPage\n" +
			e.getMessage() );
		e.printStackTrace();
	}

	if ( Factory.getStdDB().isWithinTransaction() )
		Factory.getStdDB().rollbackTransaction();

}
/**
 * This method was created in VisualAge.
 * @param newValue java.util.Vector
 */
public void setRegSubjects(Vector newValue) {
	this.regSubjects = newValue;
}
}