package sis.student;

import sis.util.*;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class SubjectForm extends JPanel {
	private JTextField ivjCreditTextField = null;
	private JTextField ivjIDTextField = null;
	private JTextField ivjNameTextField = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public SubjectForm() {
	super();
	initialize();
}
/**
 * SubjectForm constructor comment.
 * @param layout java.awt.LayoutManager
 */
public SubjectForm(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * SubjectForm constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public SubjectForm(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * SubjectForm constructor comment.
 * @param isDoubleBuffered boolean
 */
public SubjectForm(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * This method was created in VisualAge.
 */
public void clear() {
	getIDTextField().setText("");
	getNameTextField().setText("");
	getCreditTextField().setText("");
}
/**
 * Return the CreditTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getCreditTextField() {
	if (ivjCreditTextField == null) {
		try {
			ivjCreditTextField = new com.sun.java.swing.JTextField();
			ivjCreditTextField.setName("CreditTextField");
			ivjCreditTextField.setPreferredSize(new java.awt.Dimension(50, 19));
			ivjCreditTextField.setMinimumSize(new java.awt.Dimension(50, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCreditTextField;
}
/**
 * This method was created in VisualAge.
 */
public String getID() {
	return getIDTextField().getText();
}
/**
 * Return the IDTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(100, 19));
			ivjIDTextField.setMinimumSize(new java.awt.Dimension(100, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the NameTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(250, 19));
			ivjNameTextField.setMinimumSize(new java.awt.Dimension(250, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * This method was created in VisualAge.
 * @return Subject
 */
public Subject getSubject() throws Exception, java.rmi.RemoteException {
	
	
	if ( getIDTextField().getText().length() <= 0 )
		return null;

	try {

		Subject regSubject = Subject.findCurrentByID( Factory.getStdDB(), 
								getIDTextField().getText() );

		if (regSubject == null){
			Factory.getStdDB().endTransaction();
			return null;
		}
			
		return regSubject;

	} catch (DatabaseException dbe){
		System.out.println("Database Error in getSubject() from sis.student.SubjectForm\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in in getSubject() from sis.student.SubjectForm\n" +
			e.getMessage() );
		e.printStackTrace();
	}

	if ( Factory.getStdDB().isWithinTransaction() )
		Factory.getStdDB().rollbackTransaction();
	
	
	return null;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCreditTextField = new java.awt.GridBagConstraints();
	setName("SubjectForm");
	setLayout(new java.awt.GridBagLayout());
	setSize(460, 30);

	constraintsIDTextField.gridx = 0; constraintsIDTextField.gridy = 0;
	constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
	constraintsIDTextField.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsIDTextField.weightx = 0.0;
	constraintsIDTextField.weighty = 0.0;
	constraintsIDTextField.insets = new java.awt.Insets(0, 10, 5, 5);
	add(getIDTextField(), constraintsIDTextField);

	constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 0;
	constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
	constraintsNameTextField.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsNameTextField.weightx = 0.0;
	constraintsNameTextField.weighty = 0.0;
	constraintsNameTextField.insets = new java.awt.Insets(0, 15, 5, 15);
	add(getNameTextField(), constraintsNameTextField);

	constraintsCreditTextField.gridx = 2; constraintsCreditTextField.gridy = 0;
	constraintsCreditTextField.gridwidth = 1; constraintsCreditTextField.gridheight = 1;
	constraintsCreditTextField.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsCreditTextField.weightx = 0.0;
	constraintsCreditTextField.weighty = 0.0;
	constraintsCreditTextField.insets = new java.awt.Insets(0, 10, 5, 10);
	add(getCreditTextField(), constraintsCreditTextField);
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		SubjectForm aSubjectForm;
		aSubjectForm = new SubjectForm();
		frame.getContentPane().add("Center", aSubjectForm);
		frame.setSize(aSubjectForm.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
}