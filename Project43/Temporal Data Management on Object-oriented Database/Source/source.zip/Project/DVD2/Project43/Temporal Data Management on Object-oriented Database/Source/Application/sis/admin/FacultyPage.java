package sis.admin;

import sis.util.*;
import com.sun.java.swing.border.Border;
import com.sun.java.swing.border.TitledBorder;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;
import jp.jasmine.japi.*;
import jp.jasmine.rmi.*;
import jp.collection.*;
import jp.jasmine.TempCF.*;
/**
 * This type was created in VisualAge.
 */
public class FacultyPage extends JPanel implements java.awt.event.ActionListener {
	private JButton ivjAddToolBarButton = null;
	private JButton ivjClearToolBarButton = null;
	private JButton ivjDeleteToolBarButton = null;
	private JButton ivjFindToolBarButton = null;
	private JButton ivjSaveToolBarButton = null;
	private DatePanel ivjValidTimeDatePanel = null;
	private JPanel ivjValidTimePanel = null;
	private JTextPane ivjValidTimeTextPane = null;
	private JComboBox ivjDeanComboBox = null;
	private JLabel ivjDeanLabel = null;
	private JLabel ivjIDLabel = null;
	private JTextField ivjIDTextField = null;
	private JLabel ivjNameLabel = null;
	private JTextField ivjNameTextField = null;
	private JButton ivjExitToolBarButton = null;
	private JToolBar ivjToolBar = null;
	private JPanel ivjInfoPanel = null;
	private JButton ivjCancelDelButton = null;
	private JDialog ivjDeleteDialog = null;
	private JPanel ivjDeleteDialogContentPane = null;
	private JLabel ivjDeleteLabel = null;
	private JButton ivjFindButton = null;
	private JDialog ivjFindDialog = null;
	private JPanel ivjFindDialogContentPane = null;
	private FindPanel ivjFindPanel = null;
	private JPanel ivjJPanel1 = null;
	private JPanel ivjJPanel2 = null;
	private JButton ivjOKDelButton = null;
	private JButton ivjCancelFindButton = null;
	private JPanel ivjButtonFindPanel = null;
	private Faculty foundFac = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public FacultyPage() {
	super();
	initialize();
}
/**
 * Faculty constructor comment.
 * @param layout java.awt.LayoutManager
 */
public FacultyPage(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * Faculty constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public FacultyPage(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * Faculty constructor comment.
 * @param isDoubleBuffered boolean
 */
public FacultyPage(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getClearToolBarButton()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getAddToolBarButton()) ) {
		connEtoC2(e);
	}
	if ((e.getSource() == getFindToolBarButton()) ) {
		connEtoM1(e);
	}
	if ((e.getSource() == getDeleteToolBarButton()) ) {
		connEtoM3(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getOKDelButton()) ) {
		connEtoC4(e);
	}
	if ((e.getSource() == getCancelDelButton()) ) {
		connEtoM4(e);
	}
	if ((e.getSource() == getFindButton()) ) {
		connEtoC3(e);
	}
	if ((e.getSource() == getExitToolBarButton()) ) {
		connEtoC5(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM6(e);
	}
	if ((e.getSource() == getCancelFindButton()) ) {
		connEtoM5(e);
	}
	if ((e.getSource() == getSaveToolBarButton()) ) {
		connEtoC6(e);
	}
	if ((e.getSource() == getDeanComboBox()) ) {
		connEtoM7(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * add method comment.
 */
public void add() throws Exception, java.rmi.RemoteException {

	
	try {
		
		//Check for valid form
		Message m = new Message();
		if ( getIDTextField().getText().length() <= 0 ) {
			m.show("Faculty ID is empty.");
			return;}
		
		if ( getNameTextField().getText().length() <= 0 ){
			m.show("Faculty Name is empty.");
			return;}
		
		if ( getDeanComboBox().getSelectedIndex() == 0 ){
			m.show("Dean is not selected.");
			return;}
		
		if ( getValidTimeDatePanel().getDate() == null ){
			m.show("Valid Time Start is not selected.");
			return;}

		//Start Tx
		Factory.getAdminDB().startTransaction();

		java.sql.Date vts 	= 	new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
		Faculty newFac 		= 	new Faculty( Factory.getAdminDB() );
		Object	arg[]		= 	new Object[0];

		//Get selected teacher ID
		DBObject selectedTeacher		=	(DBObject) Factory.getAllTeachers().elementAt( 
												getDeanComboBox().getSelectedIndex() - 1 );
		DBObject selectedTeacher_ID		=	(DBObject) selectedTeacher.execMethod("getCurrentID",arg);
		String	 selectedTeacherID		=	selectedTeacher_ID.getProperty("ID").toString();

		//Get selected teacher's faculty ID		
		DBObject selectedTeacher_Dept	=	(DBObject) selectedTeacher.execMethod("getCurrentDept",arg);
		DBObject selectedTeacherDept	=	(DBObject) selectedTeacher_Dept.getProperty("Dept");
		DBObject selectedTeacher_Fac	=	(DBObject) selectedTeacherDept.execMethod("getCurrentFac",arg);
		DBObject selectedTeacherFac		=	(DBObject) selectedTeacher_Fac.getProperty("Fac");
		DBObject selectedTeacher_FacID	=	(DBObject) selectedTeacherFac.execMethod("getCurrentID",arg);
		String   selectedTeacherFacID	=	selectedTeacher_FacID.getProperty("ID").toString();
		

		//Get teacher faculty in Faculty type and dean in Teacher type
		Faculty teacherFac		= 	Faculty.findCurrentByID(Factory.getAdminDB(), selectedTeacherFacID);
		if ( teacherFac == null ){
			m.show("New Faculty can't be created. Fail to retrieve dean Faculy Object.");
			Factory.getAdminDB().endTransaction();
			return;
		}
		
		Teacher dean 			= 	Teacher.findCurrentByID(Factory.getAdminDB(), selectedTeacherID, teacherFac);
		if ( dean == null ){
			m.show("New Faculty can't be created. Fail to retrieve dean object.");
			Factory.getAdminDB().endTransaction();
			return;
		}

		//Create new faculty
		newFac.create_this( getIDTextField().getText(),
							getNameTextField().getText(),
							dean,
							vts);

		
		//End Tx
		Factory.getAdminDB().endTransaction();

		//Clear Form
		getIDTextField().setText("");
		getNameTextField().setText("");
		getDeanComboBox().setSelectedIndex(0);
		getDeanComboBox().repaint();
		
	} catch ( DatabaseException dbe){

		System.out.println("Database Error in add() from sis.admin.FacultyPage\n" + 
			dbe.getMessage() );
		dbe.printStackTrace();
	} catch ( Exception e){

		System.out.println("Error in add() from sis.admin.FacultyPage\n" + 
			e.getMessage() );
		e.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
		
}
/**
 * clear method comment.
 */
public void clear() {

	//Clear form
	getIDTextField().setText("");
	getNameTextField().setText("");
	getValidTimeDatePanel().clear();

	getDeanComboBox().setSelectedIndex(0);
	getDeanComboBox().repaint();

	//Clear foundFac
	foundFac = null;

	//Enable&Disable some toolbar buttons
	getAddToolBarButton().setEnabled(true);
	getFindToolBarButton().setEnabled(true);
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
	
}
/**
 * connEtoC1:  (ClearToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyPage.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (AddToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyPage.add()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.add();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyPage.find()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.find();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (OKDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyPage.delete()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.delete();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (ExitToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyPage.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC6:  (SaveToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FacultyPage.update()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.update();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (FindToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (FindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (DeleteToolBarButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.show()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().show();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM4:  (CancelDelButton.action.actionPerformed(java.awt.event.ActionEvent) --> DeleteDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeleteDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM5:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindDialog.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindDialog().dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM6:  (CancelFindButton.action.actionPerformed(java.awt.event.ActionEvent) --> FindPanel.clear()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getFindPanel().clear();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM7:  (DeanComboBox.action.actionPerformed(java.awt.event.ActionEvent) --> DeanComboBox.repaint()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM7(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		getDeanComboBox().repaint();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Comment
 */
public void connEtoM8_ABoolean(boolean arg1) {
	arg1 = true;
	return;
}
/**
 * Comment
 */
public boolean connEtoM8_ABoolean1() {
	
	return true;
}
/**
 * This method was created in VisualAge.
 */
public void delete() throws Exception, java.rmi.RemoteException {
	
	try{

		Message m = new Message();
		java.sql.Date vte;

		//if there's no found Faculty then return
		if ( foundFac == null )  {
			m.show("Can't update. Faculty didn't found.");
			return;
		}
		//Check for VTE selection
		if ( getValidTimeDatePanel().getDate() == null ){
			m.show("Valid time for deleting is not selected.");
			return;
		} else vte = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	
		Factory.getAdminDB().startTransaction();
		foundFac.delete_this(vte);
		foundFac = null;
		//Factory.setAllFacs(null);
		Factory.getAdminDB().endTransaction();

		clear();
	
	} catch (DatabaseException dbe){
		System.out.println("Database Error in delete() from sis.admin.DepartmentPage\n" +
			dbe.getMessage() );
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
}
public void exit() {
	Factory.disconnect( Factory.getAdminDB() );
	System.exit(0);
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void find() throws Exception, java.rmi.RemoteException {

	try{
		//Start Tx
		Factory.getAdminDB().startTransaction();

	 	Faculty		_foundFac	=	null;	
		Object 		arg[] 		= 	new Object[0]; //Argument fot getCurrentID

		//Find		 
		if ( getFindPanel().getFindType().equals("ID") ){
		
			_foundFac = Faculty.findCurrentByID( Factory.getAdminDB(),
										        getFindPanel().getText() );
										   
		} else if ( getFindPanel().getFindType().equals("Name") ){
			_foundFac = Faculty.findCurrentByName( Factory.getAdminDB(),
										          getFindPanel().getText() );
		}

		//Check result
		//if faculty didn't found then show message and return
		if ( _foundFac == null ) {
			Message m = new Message();
			m.show("Faculty not found.");
			Factory.getAdminDB().endTransaction();
			return; }
		
		foundFac = _foundFac;
		getFindPanel().clear();
		getFindDialog().dispose();

		//Show found Faculty
		getIDTextField().setText( foundFac.getCurrentID().toDBObject().getProperty("ID").toString() );
		getNameTextField().setText( foundFac.getCurrentName().toDBObject().getProperty("eName").toString() );
		
		String		deanID 		= 	foundFac.getCurrentDean().getDean().getCurrentID().getId();
		String		deanFacID	=	foundFac.getCurrentDean().getDean().getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();
		int			pos = -1;

		String teachFacPair[]	=	new String[2];
		
		for ( int i=0; i < Factory.getAllTeachIDs().size(); i++ ){

			teachFacPair	=	(String[])	Factory.getAllTeachIDs().elementAt(i)			;
			if ( deanID.equals( teachFacPair[0] ) && deanFacID.equals( teachFacPair[1] ) )
				pos = i;
			if ( pos >= 0 )
				break;
		}
		
		
		if ( pos < 0 ) {
			Message m = new Message();
			m.show("Can't display dean. Fail to retieve object.");
			getDeanComboBox().setSelectedIndex( 0 );
			getDeanComboBox().repaint();
		} else { getDeanComboBox().setSelectedIndex( pos+1 );
				 getDeanComboBox().repaint();
			   }
		
		getValidTimeDatePanel().clear();
		
		//Enable & disable some toolbar bottons
		getAddToolBarButton().setEnabled(false);
		getDeleteToolBarButton().setEnabled(true);
		getSaveToolBarButton().setEnabled(true);
		
		//End Tx
		Factory.getAdminDB().endTransaction();
		
		
	} catch (DatabaseException dbe){
		System.out.println("Database Error in find() from sis.admin.FacultyPage\n" + dbe.getMessage() );
		dbe.printStackTrace();
	} catch (Exception e){
		System.out.println("Error in find() from sis.admin.FacultyPage\n" + e.getMessage() );
		e.printStackTrace();
	}


	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
/**
 * Return the AddToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getAddToolBarButton() {
	if (ivjAddToolBarButton == null) {
		try {
			ivjAddToolBarButton = new com.sun.java.swing.JButton();
			ivjAddToolBarButton.setName("AddToolBarButton");
			ivjAddToolBarButton.setToolTipText("Add new faculty");
			ivjAddToolBarButton.setText("");
			ivjAddToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjAddToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjAddToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\inserticon.gif"));
			ivjAddToolBarButton.setPreferredSize(new java.awt.Dimension(22, 23));
			ivjAddToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjAddToolBarButton;
}
/**
 * Return the FindButtonPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getButtonFindPanel() {
	java.awt.GridBagConstraints constraintsFindButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelFindButton = new java.awt.GridBagConstraints();
	if (ivjButtonFindPanel == null) {
		try {
			ivjButtonFindPanel = new com.sun.java.swing.JPanel();
			ivjButtonFindPanel.setName("ButtonFindPanel");
			ivjButtonFindPanel.setLayout(new java.awt.GridBagLayout());

			constraintsFindButton.gridx = 0; constraintsFindButton.gridy = 0;
			constraintsFindButton.gridwidth = 1; constraintsFindButton.gridheight = 1;
			constraintsFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindButton.weightx = 0.0;
			constraintsFindButton.weighty = 0.0;
			constraintsFindButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getButtonFindPanel().add(getFindButton(), constraintsFindButton);

			constraintsCancelFindButton.gridx = -1; constraintsCancelFindButton.gridy = -1;
			constraintsCancelFindButton.gridwidth = 1; constraintsCancelFindButton.gridheight = 1;
			constraintsCancelFindButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelFindButton.weightx = 0.0;
			constraintsCancelFindButton.weighty = 0.0;
			getButtonFindPanel().add(getCancelFindButton(), constraintsCancelFindButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjButtonFindPanel;
}
/**
 * Return the CancelDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelDelButton() {
	if (ivjCancelDelButton == null) {
		try {
			ivjCancelDelButton = new com.sun.java.swing.JButton();
			ivjCancelDelButton.setName("CancelDelButton");
			ivjCancelDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelDelButton.setText("Cancel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelDelButton;
}
/**
 * Return the CancelFindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getCancelFindButton() {
	if (ivjCancelFindButton == null) {
		try {
			ivjCancelFindButton = new com.sun.java.swing.JButton();
			ivjCancelFindButton.setName("CancelFindButton");
			ivjCancelFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjCancelFindButton.setText("Cancel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelFindButton;
}
/**
 * Return the ClearToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getClearToolBarButton() {
	if (ivjClearToolBarButton == null) {
		try {
			ivjClearToolBarButton = new com.sun.java.swing.JButton();
			ivjClearToolBarButton.setName("ClearToolBarButton");
			ivjClearToolBarButton.setToolTipText("Clear Form");
			ivjClearToolBarButton.setText("");
			ivjClearToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjClearToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjClearToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\clearicon.gif"));
			ivjClearToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjClearToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			ivjClearToolBarButton.setMinimumSize(new java.awt.Dimension(25, 25));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjClearToolBarButton;
}
/**
 * Return the JComboBox property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getDeanComboBox() {
	if (ivjDeanComboBox == null) {
		try {
			ivjDeanComboBox = new com.sun.java.swing.JComboBox();
			ivjDeanComboBox.setName("DeanComboBox");
			ivjDeanComboBox.setPreferredSize(new java.awt.Dimension(150, 20));
			ivjDeanComboBox.setMinimumSize(new java.awt.Dimension(150, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeanComboBox;
}
/**
 * Return the JLabel2 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeanLabel() {
	if (ivjDeanLabel == null) {
		try {
			ivjDeanLabel = new com.sun.java.swing.JLabel();
			ivjDeanLabel.setName("DeanLabel");
			ivjDeanLabel.setText("Dean");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeanLabel;
}
/**
 * Return the DeleteDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getDeleteDialog() {
	if (ivjDeleteDialog == null) {
		try {
			ivjDeleteDialog = new com.sun.java.swing.JDialog();
			ivjDeleteDialog.setName("DeleteDialog");
			ivjDeleteDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjDeleteDialog.setBounds(667, 284, 300, 120);
			ivjDeleteDialog.setModal(true);
			ivjDeleteDialog.setTitle("Delete Faculty");
			getDeleteDialog().setContentPane(getDeleteDialogContentPane());
			// user code begin {1}
			ivjDeleteDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjDeleteDialog.getBounds();
			ivjDeleteDialog.setBounds ( (screen.width - s.width)/2,
									    (screen.height - s.height)/2,
									  	s.width,
									  	s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialog;
}
/**
 * Return the DeleteDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getDeleteDialogContentPane() {
	java.awt.GridBagConstraints constraintsJPanel1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJPanel2 = new java.awt.GridBagConstraints();
	if (ivjDeleteDialogContentPane == null) {
		try {
			ivjDeleteDialogContentPane = new com.sun.java.swing.JPanel();
			ivjDeleteDialogContentPane.setName("DeleteDialogContentPane");
			ivjDeleteDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjDeleteDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsJPanel1.gridx = 0; constraintsJPanel1.gridy = 0;
			constraintsJPanel1.gridwidth = 1; constraintsJPanel1.gridheight = 1;
			constraintsJPanel1.fill = java.awt.GridBagConstraints.BOTH;
			constraintsJPanel1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel1.weightx = 1.0;
			constraintsJPanel1.weighty = 1.0;
			getDeleteDialogContentPane().add(getJPanel1(), constraintsJPanel1);

			constraintsJPanel2.gridx = 0; constraintsJPanel2.gridy = 1;
			constraintsJPanel2.gridwidth = 1; constraintsJPanel2.gridheight = 1;
			constraintsJPanel2.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsJPanel2.weightx = 0.0;
			constraintsJPanel2.weighty = 0.0;
			constraintsJPanel2.insets = new java.awt.Insets(10, 0, 10, 0);
			getDeleteDialogContentPane().add(getJPanel2(), constraintsJPanel2);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteDialogContentPane;
}
/**
 * Return the DeleteLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getDeleteLabel() {
	if (ivjDeleteLabel == null) {
		try {
			ivjDeleteLabel = new com.sun.java.swing.JLabel();
			ivjDeleteLabel.setName("DeleteLabel");
			ivjDeleteLabel.setText("Are you sure to delete this object?");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteLabel;
}
/**
 * Return the DeleteToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getDeleteToolBarButton() {
	if (ivjDeleteToolBarButton == null) {
		try {
			ivjDeleteToolBarButton = new com.sun.java.swing.JButton();
			ivjDeleteToolBarButton.setName("DeleteToolBarButton");
			ivjDeleteToolBarButton.setToolTipText("Delete this faculty");
			ivjDeleteToolBarButton.setText("");
			ivjDeleteToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjDeleteToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjDeleteToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\deleteicon.gif"));
			ivjDeleteToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDeleteToolBarButton;
}
/**
 * Return the JToolBarButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getExitToolBarButton() {
	if (ivjExitToolBarButton == null) {
		try {
			ivjExitToolBarButton = new com.sun.java.swing.JButton();
			ivjExitToolBarButton.setName("ExitToolBarButton");
			ivjExitToolBarButton.setToolTipText("Exit");
			ivjExitToolBarButton.setText("");
			ivjExitToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjExitToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjExitToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\exiticon.gif"));
			ivjExitToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjExitToolBarButton;
}
/**
 * Return the FindButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindButton() {
	if (ivjFindButton == null) {
		try {
			ivjFindButton = new com.sun.java.swing.JButton();
			ivjFindButton.setName("FindButton");
			ivjFindButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjFindButton.setText("Find");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindButton;
}
/**
 * Return the FindDialog property value.
 * @return com.sun.java.swing.JDialog
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JDialog getFindDialog() {
	if (ivjFindDialog == null) {
		try {
			ivjFindDialog = new com.sun.java.swing.JDialog();
			ivjFindDialog.setName("FindDialog");
			ivjFindDialog.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjFindDialog.setBounds(661, 47, 340, 150);
			ivjFindDialog.setModal(true);
			ivjFindDialog.setTitle("Find Faculty");
			getFindDialog().setContentPane(getFindDialogContentPane());
			// user code begin {1}
			ivjFindDialog.setVisible(false);
			Dimension screen = getToolkit().getScreenSize();
			Rectangle s = ivjFindDialog.getBounds();
			ivjFindDialog.setBounds ( (screen.width - s.width)/2,
									  (screen.height - s.height)/2,
									  s.width,
									  s.height);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialog;
}
/**
 * Return the FindDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getFindDialogContentPane() {
	java.awt.GridBagConstraints constraintsFindPanel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsButtonFindPanel = new java.awt.GridBagConstraints();
	if (ivjFindDialogContentPane == null) {
		try {
			ivjFindDialogContentPane = new com.sun.java.swing.JPanel();
			ivjFindDialogContentPane.setName("FindDialogContentPane");
			ivjFindDialogContentPane.setPreferredSize(new java.awt.Dimension(330, 120));
			ivjFindDialogContentPane.setLayout(new java.awt.GridBagLayout());

			constraintsFindPanel.gridx = 0; constraintsFindPanel.gridy = 0;
			constraintsFindPanel.gridwidth = 1; constraintsFindPanel.gridheight = 1;
			constraintsFindPanel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsFindPanel.weightx = 1.0;
			constraintsFindPanel.weighty = 0.0;
			constraintsFindPanel.insets = new java.awt.Insets(0, 0, 5, 0);
			getFindDialogContentPane().add(getFindPanel(), constraintsFindPanel);

			constraintsButtonFindPanel.gridx = 0; constraintsButtonFindPanel.gridy = 1;
			constraintsButtonFindPanel.gridwidth = 1; constraintsButtonFindPanel.gridheight = 1;
			constraintsButtonFindPanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsButtonFindPanel.weightx = 0.0;
			constraintsButtonFindPanel.weighty = 0.0;
			constraintsButtonFindPanel.insets = new java.awt.Insets(10, 0, 10, 0);
			getFindDialogContentPane().add(getButtonFindPanel(), constraintsButtonFindPanel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindDialogContentPane;
}
/**
 * Return the FindPanel property value.
 * @return sis.util.FindPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private FindPanel getFindPanel() {
	if (ivjFindPanel == null) {
		try {
			ivjFindPanel = new sis.util.FindPanel();
			ivjFindPanel.setName("FindPanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindPanel;
}
/**
 * Return the FindToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getFindToolBarButton() {
	if (ivjFindToolBarButton == null) {
		try {
			ivjFindToolBarButton = new com.sun.java.swing.JButton();
			ivjFindToolBarButton.setName("FindToolBarButton");
			ivjFindToolBarButton.setToolTipText("Find faculty");
			ivjFindToolBarButton.setText("");
			ivjFindToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjFindToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjFindToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\findicon.gif"));
			ivjFindToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjFindToolBarButton;
}
/**
 * Return the JLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getIDLabel() {
	if (ivjIDLabel == null) {
		try {
			ivjIDLabel = new com.sun.java.swing.JLabel();
			ivjIDLabel.setName("IDLabel");
			ivjIDLabel.setText("Faculty ID");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDLabel;
}
/**
 * Return the JTextField property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getIDTextField() {
	if (ivjIDTextField == null) {
		try {
			ivjIDTextField = new com.sun.java.swing.JTextField();
			ivjIDTextField.setName("IDTextField");
			ivjIDTextField.setPreferredSize(new java.awt.Dimension(85, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjIDTextField;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getInfoPanel() {
	java.awt.GridBagConstraints constraintsIDLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsIDTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsNameTextField = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeanLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsDeanComboBox = new java.awt.GridBagConstraints();
	if (ivjInfoPanel == null) {
		try {
			ivjInfoPanel = new com.sun.java.swing.JPanel();
			ivjInfoPanel.setName("InfoPanel");
			ivjInfoPanel.setLayout(new java.awt.GridBagLayout());

			constraintsIDLabel.gridx = 0; constraintsIDLabel.gridy = 0;
			constraintsIDLabel.gridwidth = 1; constraintsIDLabel.gridheight = 1;
			constraintsIDLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsIDLabel.weightx = 0.0;
			constraintsIDLabel.weighty = 0.0;
			constraintsIDLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getIDLabel(), constraintsIDLabel);

			constraintsIDTextField.gridx = 1; constraintsIDTextField.gridy = 0;
			constraintsIDTextField.gridwidth = 1; constraintsIDTextField.gridheight = 1;
			constraintsIDTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsIDTextField.weightx = 0.0;
			constraintsIDTextField.weighty = 0.0;
			constraintsIDTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getIDTextField(), constraintsIDTextField);

			constraintsNameLabel.gridx = 0; constraintsNameLabel.gridy = 1;
			constraintsNameLabel.gridwidth = 1; constraintsNameLabel.gridheight = 1;
			constraintsNameLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsNameLabel.weightx = 0.0;
			constraintsNameLabel.weighty = 0.0;
			constraintsNameLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getNameLabel(), constraintsNameLabel);

			constraintsNameTextField.gridx = 1; constraintsNameTextField.gridy = 1;
			constraintsNameTextField.gridwidth = 1; constraintsNameTextField.gridheight = 1;
			constraintsNameTextField.anchor = java.awt.GridBagConstraints.WEST;
			constraintsNameTextField.weightx = 0.0;
			constraintsNameTextField.weighty = 0.0;
			constraintsNameTextField.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getNameTextField(), constraintsNameTextField);

			constraintsDeanLabel.gridx = 0; constraintsDeanLabel.gridy = 2;
			constraintsDeanLabel.gridwidth = 1; constraintsDeanLabel.gridheight = 1;
			constraintsDeanLabel.anchor = java.awt.GridBagConstraints.EAST;
			constraintsDeanLabel.weightx = 0.0;
			constraintsDeanLabel.weighty = 0.0;
			constraintsDeanLabel.insets = new java.awt.Insets(0, 10, 5, 10);
			getInfoPanel().add(getDeanLabel(), constraintsDeanLabel);

			constraintsDeanComboBox.gridx = 1; constraintsDeanComboBox.gridy = 2;
			constraintsDeanComboBox.gridwidth = 1; constraintsDeanComboBox.gridheight = 1;
			constraintsDeanComboBox.anchor = java.awt.GridBagConstraints.WEST;
			constraintsDeanComboBox.weightx = 0.0;
			constraintsDeanComboBox.weighty = 0.0;
			constraintsDeanComboBox.insets = new java.awt.Insets(0, 0, 5, 10);
			getInfoPanel().add(getDeanComboBox(), constraintsDeanComboBox);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Faculty Information");
			ivjInfoPanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjInfoPanel;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel1() {
	java.awt.GridBagConstraints constraintsDeleteLabel = new java.awt.GridBagConstraints();
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(new java.awt.GridBagLayout());

			constraintsDeleteLabel.gridx = 0; constraintsDeleteLabel.gridy = 0;
			constraintsDeleteLabel.gridwidth = 1; constraintsDeleteLabel.gridheight = 1;
			constraintsDeleteLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsDeleteLabel.weightx = 0.0;
			constraintsDeleteLabel.weighty = 0.0;
			getJPanel1().add(getDeleteLabel(), constraintsDeleteLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getJPanel2() {
	java.awt.GridBagConstraints constraintsOKDelButton = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelDelButton = new java.awt.GridBagConstraints();
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(new java.awt.GridBagLayout());

			constraintsOKDelButton.gridx = 0; constraintsOKDelButton.gridy = 0;
			constraintsOKDelButton.gridwidth = 1; constraintsOKDelButton.gridheight = 1;
			constraintsOKDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsOKDelButton.weightx = 0.0;
			constraintsOKDelButton.weighty = 0.0;
			constraintsOKDelButton.insets = new java.awt.Insets(0, 0, 0, 20);
			getJPanel2().add(getOKDelButton(), constraintsOKDelButton);

			constraintsCancelDelButton.gridx = -1; constraintsCancelDelButton.gridy = -1;
			constraintsCancelDelButton.gridwidth = 1; constraintsCancelDelButton.gridheight = 1;
			constraintsCancelDelButton.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelDelButton.weightx = 0.0;
			constraintsCancelDelButton.weighty = 0.0;
			getJPanel2().add(getCancelDelButton(), constraintsCancelDelButton);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the JLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getNameLabel() {
	if (ivjNameLabel == null) {
		try {
			ivjNameLabel = new com.sun.java.swing.JLabel();
			ivjNameLabel.setName("NameLabel");
			ivjNameLabel.setText("Faculty Name");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameLabel;
}
/**
 * Return the JTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextField getNameTextField() {
	if (ivjNameTextField == null) {
		try {
			ivjNameTextField = new com.sun.java.swing.JTextField();
			ivjNameTextField.setName("NameTextField");
			ivjNameTextField.setPreferredSize(new java.awt.Dimension(150, 19));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjNameTextField;
}
/**
 * Return the OKDelButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getOKDelButton() {
	if (ivjOKDelButton == null) {
		try {
			ivjOKDelButton = new com.sun.java.swing.JButton();
			ivjOKDelButton.setName("OKDelButton");
			ivjOKDelButton.setPreferredSize(new java.awt.Dimension(85, 25));
			ivjOKDelButton.setText("OK");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjOKDelButton;
}
/**
 * Return the SaveToolBarButton property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JButton getSaveToolBarButton() {
	if (ivjSaveToolBarButton == null) {
		try {
			ivjSaveToolBarButton = new com.sun.java.swing.JButton();
			ivjSaveToolBarButton.setName("SaveToolBarButton");
			ivjSaveToolBarButton.setToolTipText("Save change");
			ivjSaveToolBarButton.setText("");
			ivjSaveToolBarButton.setHorizontalTextPosition(com.sun.java.swing.SwingConstants.CENTER);
			ivjSaveToolBarButton.setVerticalTextPosition(com.sun.java.swing.SwingConstants.BOTTOM);
			ivjSaveToolBarButton.setIcon(new com.sun.java.swing.ImageIcon("..\\Student Information System\\saveicon.gif"));
			ivjSaveToolBarButton.setPreferredSize(new java.awt.Dimension(25, 25));
			ivjSaveToolBarButton.setMargin(new java.awt.Insets(0, 0, 0, 0));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSaveToolBarButton;
}
/**
 * Return the JToolBar property value.
 * @return com.sun.java.swing.JToolBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JToolBar getToolBar() {
	if (ivjToolBar == null) {
		try {
			ivjToolBar = new com.sun.java.swing.JToolBar();
			ivjToolBar.setName("ToolBar");
			ivjToolBar.add(getClearToolBarButton());
			ivjToolBar.addSeparator();
			getToolBar().add(getAddToolBarButton(), getAddToolBarButton().getName());
			getToolBar().add(getFindToolBarButton(), getFindToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getSaveToolBarButton(), getSaveToolBarButton().getName());
			getToolBar().add(getDeleteToolBarButton(), getDeleteToolBarButton().getName());
			ivjToolBar.addSeparator();
			getToolBar().add(getExitToolBarButton(), getExitToolBarButton().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjToolBar;
}
/**
 * Return the ValidTimeDatePanel property value.
 * @return sis.util.DatePanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private DatePanel getValidTimeDatePanel() {
	if (ivjValidTimeDatePanel == null) {
		try {
			ivjValidTimeDatePanel = new sis.util.DatePanel();
			ivjValidTimeDatePanel.setName("ValidTimeDatePanel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeDatePanel;
}
/**
 * Return the ValidTimePanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JPanel getValidTimePanel() {
	java.awt.GridBagConstraints constraintsValidTimeTextPane = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsValidTimeDatePanel = new java.awt.GridBagConstraints();
	if (ivjValidTimePanel == null) {
		try {
			ivjValidTimePanel = new com.sun.java.swing.JPanel();
			ivjValidTimePanel.setName("ValidTimePanel");
			ivjValidTimePanel.setLayout(new java.awt.GridBagLayout());

			constraintsValidTimeTextPane.gridx = 1; constraintsValidTimeTextPane.gridy = 1;
			constraintsValidTimeTextPane.gridwidth = 1; constraintsValidTimeTextPane.gridheight = 1;
			constraintsValidTimeTextPane.fill = java.awt.GridBagConstraints.BOTH;
			constraintsValidTimeTextPane.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeTextPane.weightx = 1.0;
			constraintsValidTimeTextPane.weighty = 1.0;
			getValidTimePanel().add(getValidTimeTextPane(), constraintsValidTimeTextPane);

			constraintsValidTimeDatePanel.gridx = 1; constraintsValidTimeDatePanel.gridy = 2;
			constraintsValidTimeDatePanel.gridwidth = 1; constraintsValidTimeDatePanel.gridheight = 1;
			constraintsValidTimeDatePanel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsValidTimeDatePanel.weightx = 0.0;
			constraintsValidTimeDatePanel.weighty = 0.0;
			getValidTimePanel().add(getValidTimeDatePanel(), constraintsValidTimeDatePanel);
			// user code begin {1}
			TitledBorder title = new TitledBorder("Valid Time");
			ivjValidTimePanel.setBorder(title);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimePanel;
}
/**
 * Return the ValidTimeTextPane property value.
 * @return com.sun.java.swing.JTextPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JTextPane getValidTimeTextPane() {
	if (ivjValidTimeTextPane == null) {
		try {
			ivjValidTimeTextPane = new com.sun.java.swing.JTextPane();
			ivjValidTimeTextPane.setName("ValidTimeTextPane");
			ivjValidTimeTextPane.setPreferredSize(new java.awt.Dimension(30, 60));
			ivjValidTimeTextPane.setText("This time is used for,\n \t- insert, valid time start of this object\n\t- delete, valid time end of this object\n\t- update, valid time end of old property and valid time start for new property\n          valid time start for new property\n\t\t     valid time start of new property");
			ivjValidTimeTextPane.setBackground(new java.awt.Color(204,204,204));
			ivjValidTimeTextPane.setEditable(false);
			// user code begin {1}
			Border empty;
			empty = BorderFactory.createEmptyBorder(0,10,10,10);
			ivjValidTimeTextPane.setBorder(empty);
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjValidTimeTextPane;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getClearToolBarButton().addActionListener(this);
	getAddToolBarButton().addActionListener(this);
	getFindToolBarButton().addActionListener(this);
	getDeleteToolBarButton().addActionListener(this);
	getOKDelButton().addActionListener(this);
	getCancelDelButton().addActionListener(this);
	getFindButton().addActionListener(this);
	getExitToolBarButton().addActionListener(this);
	getCancelFindButton().addActionListener(this);
	getSaveToolBarButton().addActionListener(this);
	getDeanComboBox().addActionListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("Faculty");
	setLayout(new java.awt.BorderLayout());
	setSize(455, 351);
	add(getToolBar(), "North");
	add(getInfoPanel(), "Center");
	add(getValidTimePanel(), "South");
	initConnections();
	// user code begin {2}
	
	//Add all teachers to Comboboxc
	Factory.addTeacherToBox( getDeanComboBox() );
	
	//Disable some toolbar buttons
	getDeleteToolBarButton().setEnabled(false);
	getSaveToolBarButton().setEnabled(false);
	
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		JFrame frame = new com.sun.java.swing.JFrame();
		FacultyPage aFacultyPage;
		aFacultyPage = new FacultyPage();
		frame.getContentPane().add("Center", aFacultyPage);
		frame.setSize(aFacultyPage.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @exception java.lang.Exception The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void update() throws Exception, java.rmi.RemoteException {

	Message m = new Message();
	
	//if there's no found Faculty then return
	if ( foundFac == null )  {
		m.show("Can't update. Faculty didn't found.");
		return;
	}

	//Check seleted Dean
	if ( getDeanComboBox().getSelectedIndex() == 0 ){
		m.show("Dean isn't seleted.");
		return;
	}
	
	//Check for valid time selection
	if ( getValidTimeDatePanel().getDate() == null ) {
		m.show("Valid time isn't selected.");
		return;
	}

	//Valid Time,use for passing
	java.sql.Date valid = new java.sql.Date( getValidTimeDatePanel().getDate().getTime() );
	//Set if there's update
	boolean update = false;

	try{
		//Strat Tx
		Factory.getAdminDB().startTransaction();

		//Get Dean ID from form
		Object arg[]		   = new Object[0];

		DBObject	currentDean		=	(DBObject) Factory.getAllTeachers().elementAt(
											getDeanComboBox().getSelectedIndex() - 1 );
		DBObject	currentDean_ID	=	(DBObject) currentDean.execMethod("getCurrentID",arg);
		String		currentDeanID	=			   currentDean_ID.getProperty("ID").toString();
		
		DBObject	currentDean_Dept =	(DBObject) currentDean.execMethod("getCurrentDept",arg);
		DBObject	currentDeanDept	=	(DBObject) currentDean_Dept.getProperty("Dept");
		DBObject	currentDean_Fac =	(DBObject) currentDeanDept.execMethod("getCurrentFac",arg);
		DBObject	_currentDeanFac	=	(DBObject) currentDean_Fac.getProperty("Fac");
		DBObject	cDeanFac_ID		=	(DBObject) _currentDeanFac.execMethod("getCurrentID",arg);
		String		cDeanFacID		=			   cDeanFac_ID.getProperty("ID").toString();
		
		Faculty		currentDeanFac	=	Faculty.findCurrentByID( Factory.getAdminDB(), 
																 cDeanFacID );


		//Get Dean ID from foundFac
		String		foundDeanID		=	foundFac.getCurrentDean().getDean().getCurrentID().getId();
		String		fDeanFacID		=	foundFac.getCurrentDean().getDean().getCurrentDept().getDept().getCurrentFac().getFac().getCurrentID().getId();
		Faculty		foundDeanFac	=	Faculty.findCurrentByID( Factory.getAdminDB(), fDeanFacID );

		if ( !(currentDeanID.equals(foundDeanID) && cDeanFacID.equals(fDeanFacID))  ){
			  
			  Teacher	newDean		=	Teacher.findCurrentByID( Factory.getAdminDB(),
				  												 currentDeanID,
				  												 currentDeanFac);
			 
			  foundFac.update_Dean( foundFac.getCurrentDean().getDean(),
			  						newDean, 
			  						valid, 
			  						valid);
			  update = true;
			  System.out.println("Dean of Faculty has been updated.");
			 
		}


		if ( !getIDTextField().getText().equals( foundFac.getCurrentID().getId() ) ){
			  foundFac.update_ID( foundFac.getCurrentID().getId(),
								  getIDTextField().getText(),
								  valid,
								  valid);
			  update = true;
			  System.out.println("Faculty ID has been updated.");
		}
		

		if ( !getNameTextField().getText().equals( foundFac.getCurrentName().getEname() ) ){
			 foundFac.update_eName( foundFac.getCurrentName().getEname(),
									getNameTextField().getText(),
									valid,
								 	valid);
			  update = true;
			  System.out.println("Faculty Name has been updated.");
		}

		//Refresh foundFac
		if ( update ){

			int selectedIndex 	=	getDeanComboBox().getSelectedIndex();

			//Find		 
			foundFac	= 	null;
			foundFac	= 	Faculty.findCurrentByID( Factory.getAdminDB(),
										          	 getIDTextField().getText() );
			
			if ( foundFac == null ){
				m.show("Can't display updated information.");
				clear();
			} else {	//Show
						getIDTextField().setText( foundFac.getCurrentID().getId() );
						getNameTextField().setText( foundFac.getCurrentName().getEname() );
						getDeanComboBox().setSelectedIndex( selectedIndex );
						getDeanComboBox().repaint();

						getValidTimeDatePanel().clear();
			}

			m.show("Faculty has been updated.");
		} else m.show("Faculty Information hasn't been changed.");
		
		//End Tx
		Factory.getAdminDB().endTransaction();
	  
	} catch (DatabaseException dbe){
		System.out.println("Database Error in update() from sis.admin.FacultyPage\n" + dbe.getMessage());
		dbe.printStackTrace();
	}

	if ( Factory.getAdminDB().isWithinTransaction() )
		Factory.getAdminDB().rollbackTransaction();
	
}
}