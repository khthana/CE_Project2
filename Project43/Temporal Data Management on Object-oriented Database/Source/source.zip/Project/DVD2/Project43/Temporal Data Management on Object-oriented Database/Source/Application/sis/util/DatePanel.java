package sis.util;

import com.sun.java.swing.border.Border;
import com.sun.java.swing.BorderFactory;
import com.sun.java.swing.*;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;

/**
 * This type was created in VisualAge.
 */
public class DatePanel extends JPanel {
	private JLabel ivjSlash1 = null;
	private JLabel ivjSlash2 = null;
	private JComboBox ivjMonthComboBox = null;
	private JComboBox ivjYearComboBox = null;
	private JComboBox ivjDayComboBox = null;
	private static Vector day = null;
	private static Vector month = null;
	private static Vector year = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public DatePanel() {
	super();
	initialize();
}
/**
 * DatePanel constructor comment.
 * @param layout java.awt.LayoutManager
 */
public DatePanel(java.awt.LayoutManager layout) {
	super(layout);
}
/**
 * DatePanel constructor comment.
 * @param layout java.awt.LayoutManager
 * @param isDoubleBuffered boolean
 */
public DatePanel(java.awt.LayoutManager layout, boolean isDoubleBuffered) {
	super(layout, isDoubleBuffered);
}
/**
 * DatePanel constructor comment.
 * @param isDoubleBuffered boolean
 */
public DatePanel(boolean isDoubleBuffered) {
	super(isDoubleBuffered);
}
/**
 * This method was created in VisualAge.
 */
public void addDate() {

		int	i;
		
		//Add Date
		getDayComboBox().removeAllItems();
		getDayComboBox().addItem("dd");
		for ( i = 0; i < getDay().size(); i++) 
			getDayComboBox().addItem( getDay().elementAt(i).toString() );
	
		//Add Month
		getMonthComboBox().removeAllItems();
		getMonthComboBox().addItem("mm");
		for ( i = 0; i < getMonth().size(); i++) 
			getMonthComboBox().addItem( getMonth().elementAt(i).toString() );
		
		//Add Year
		getYearComboBox().removeAllItems();
		getYearComboBox().addItem("yyyy");
		for ( i = 0; i < getYear().size(); i++) 
			getYearComboBox().addItem( getYear().elementAt(i).toString() );	
}
/**
 * This method was created in VisualAge.
 */
public void clear() {

	getDayComboBox().setSelectedIndex(0);
	getDayComboBox().repaint();
	
	getMonthComboBox().setSelectedIndex(0);
	getMonthComboBox().repaint();
	
	getYearComboBox().setSelectedIndex(0);
	getYearComboBox().repaint();
}
public Date getDate() {
	
	GregorianCalendar calendar;
	Date date;

	if ( (getYearComboBox().getSelectedItem() != "yyyy" ) && 
		 (getMonthComboBox().getSelectedItem() != "mm") &&
		 (getDayComboBox().getSelectedItem() != "dd") ){


		try{

			int day   = Integer.valueOf( getDayComboBox().getSelectedItem().toString() ).intValue();
			int month = Integer.valueOf( getMonthComboBox().getSelectedItem().toString() ).intValue();
			int year  = Integer.valueOf( getYearComboBox().getSelectedItem().toString() ).intValue();
			calendar = new GregorianCalendar( year,month-1,day );
			date = calendar.getTime();

			return date;

		} catch (Exception e){
			System.out.println("Error in getDate() from sis.util.Panel\n"+e.getMessage() );
			e.printStackTrace();
		}
			 
	}
	
	return null;
}
/**
 * This method was created in VisualAge.
 */
private Vector getDay() {

	try{
		if ( day == null ){
			day = new Vector();
			for ( int i = 1; i <= 31; i++)
				day.addElement( String.valueOf(i) );
		}
	} catch (Exception e){
		System.out.println("Error in getDay() from sis.util.DataPanel\n"+e.getMessage() );
		e.printStackTrace();
	}

	return day;
			
}
/**
 * Return the JComboBox1 property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getDayComboBox() {
	if (ivjDayComboBox == null) {
		try {
			ivjDayComboBox = new com.sun.java.swing.JComboBox();
			ivjDayComboBox.setName("DayComboBox");
			ivjDayComboBox.setPreferredSize(new java.awt.Dimension(50, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjDayComboBox;
}
/**
 * This method was created in VisualAge.
 */
private Vector getMonth() {

	try{
		if ( month == null ){
			month = new Vector();
			for ( int i = 1; i <= 12; i++) 
				month.addElement( String.valueOf(i) );
		}
	} catch (Exception e){
		System.out.println("Error in getMonth() from sis.util.DataPanel\n"+e.getMessage() );
		e.printStackTrace();
	}

	return month;
			
}
/**
 * Return the JComboBox2 property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getMonthComboBox() {
	if (ivjMonthComboBox == null) {
		try {
			ivjMonthComboBox = new com.sun.java.swing.JComboBox();
			ivjMonthComboBox.setName("MonthComboBox");
			ivjMonthComboBox.setPreferredSize(new java.awt.Dimension(50, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjMonthComboBox;
}
/**
 * Return the Slash1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getSlash1() {
	if (ivjSlash1 == null) {
		try {
			ivjSlash1 = new com.sun.java.swing.JLabel();
			ivjSlash1.setName("Slash1");
			ivjSlash1.setText("/");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSlash1;
}
/**
 * Return the Slash2 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JLabel getSlash2() {
	if (ivjSlash2 == null) {
		try {
			ivjSlash2 = new com.sun.java.swing.JLabel();
			ivjSlash2.setName("Slash2");
			ivjSlash2.setText("/");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjSlash2;
}
/**
 * This method was created in VisualAge.
 */
private Vector getYear() {

	try{
		if ( year == null ){
			GregorianCalendar calendar = new GregorianCalendar();
			year = new Vector();
			for ( int i = calendar.get(Calendar.YEAR)+2; i >= 1970; i--) 
				year.addElement( String.valueOf(i) );
		}
	} catch (Exception e){
		System.out.println("Error in getYear() from sis.util.DataPanel\n"+e.getMessage() );
		e.printStackTrace();
	}

	return year;
			
}
/**
 * Return the JComboBox3 property value.
 * @return com.sun.java.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private JComboBox getYearComboBox() {
	if (ivjYearComboBox == null) {
		try {
			ivjYearComboBox = new com.sun.java.swing.JComboBox();
			ivjYearComboBox.setName("YearComboBox");
			ivjYearComboBox.setPreferredSize(new java.awt.Dimension(60, 20));
			ivjYearComboBox.setMinimumSize(new java.awt.Dimension(80, 20));
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjYearComboBox;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	java.awt.GridBagConstraints constraintsDayComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSlash1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsMonthComboBox = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsSlash2 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsYearComboBox = new java.awt.GridBagConstraints();
	setName("DatePanel");
	setPreferredSize(new java.awt.Dimension(250, 50));
	setBorder(new com.sun.java.swing.border.CompoundBorder());
	setLayout(new java.awt.GridBagLayout());
	setSize(195, 29);
	setMinimumSize(new java.awt.Dimension(250, 50));

	constraintsDayComboBox.gridx = 0; constraintsDayComboBox.gridy = 0;
	constraintsDayComboBox.gridwidth = 1; constraintsDayComboBox.gridheight = 1;
	constraintsDayComboBox.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsDayComboBox.weightx = 0.0;
	constraintsDayComboBox.weighty = 0.0;
	add(getDayComboBox(), constraintsDayComboBox);

	constraintsSlash1.gridx = 1; constraintsSlash1.gridy = 0;
	constraintsSlash1.gridwidth = 1; constraintsSlash1.gridheight = 1;
	constraintsSlash1.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsSlash1.weightx = 0.0;
	constraintsSlash1.weighty = 0.0;
	constraintsSlash1.insets = new java.awt.Insets(0, 5, 0, 0);
	add(getSlash1(), constraintsSlash1);

	constraintsMonthComboBox.gridx = 2; constraintsMonthComboBox.gridy = 0;
	constraintsMonthComboBox.gridwidth = 1; constraintsMonthComboBox.gridheight = 1;
	constraintsMonthComboBox.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsMonthComboBox.weightx = 0.0;
	constraintsMonthComboBox.weighty = 0.0;
	constraintsMonthComboBox.insets = new java.awt.Insets(0, 5, 0, 0);
	add(getMonthComboBox(), constraintsMonthComboBox);

	constraintsSlash2.gridx = 3; constraintsSlash2.gridy = 0;
	constraintsSlash2.gridwidth = 1; constraintsSlash2.gridheight = 1;
	constraintsSlash2.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsSlash2.weightx = 0.0;
	constraintsSlash2.weighty = 0.0;
	constraintsSlash2.insets = new java.awt.Insets(0, 5, 0, 0);
	add(getSlash2(), constraintsSlash2);

	constraintsYearComboBox.gridx = 4; constraintsYearComboBox.gridy = 0;
	constraintsYearComboBox.gridwidth = 1; constraintsYearComboBox.gridheight = 1;
	constraintsYearComboBox.anchor = java.awt.GridBagConstraints.CENTER;
	constraintsYearComboBox.weightx = 0.0;
	constraintsYearComboBox.weighty = 0.0;
	constraintsYearComboBox.insets = new java.awt.Insets(0, 5, 0, 0);
	add(getYearComboBox(), constraintsYearComboBox);
	// user code begin {2}
/*
	Border blackline, etched, raisedbevel, loweredbevel, empty;
	
	//A border that puts 10 extra pixels at the sides and
	//bottom of each pane.
	Border paneEdge = BorderFactory.createEmptyBorder(0,10,10,10);

	blackline = BorderFactory.createLineBorder(Color.black);
	etched = BorderFactory.createEtchedBorder();
	raisedbevel = BorderFactory.createRaisedBevelBorder();
	loweredbevel = BorderFactory.createLoweredBevelBorder();
	empty = BorderFactory.createEmptyBorder();	

	Border compound;
	compound = BorderFactory.createCompoundBorder(raisedbevel, loweredbevel);

	setBorder(compound);


	Border title;
	title = BorderFactory.createTitledBorder("Valid Time Start");
	setBorder(title);*/
	addDate();
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		com.sun.java.swing.JFrame frame = new com.sun.java.swing.JFrame();
		DatePanel aDatePanel;
		aDatePanel = new DatePanel();
		frame.getContentPane().add("Center", aDatePanel);
		frame.setSize(aDatePanel.getSize());
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of com.sun.java.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * This method was created in VisualAge.
 * @param date java.sql.Date
 */
public void setDate(java.sql.Date date) {

	GregorianCalendar calendar = new GregorianCalendar();
	calendar.setTime(date);

	int dyear 	= 	calendar.get( Calendar.YEAR );
	int dmonth 	= 	calendar.get( Calendar.MONTH ) + 1;
	int dday 	=	calendar.get( Calendar.DATE );

	//Set Day
	getDayComboBox().setSelectedIndex( getDay().indexOf(String.valueOf(dday))+1 );
	getDayComboBox().repaint();

	//Set Month
	getMonthComboBox().setSelectedIndex( getMonth().indexOf(String.valueOf(dmonth))+1 );
	getMonthComboBox().repaint();

	//Set Year
	getYearComboBox().setSelectedIndex( getYear().indexOf( String.valueOf(dyear))+1 );
	getYearComboBox().repaint();
	
}
/**
 * This method was created in VisualAge.
 * @param enabled boolean
 */
public void setEnabled(boolean enabled) {

	if ( enabled ){

		getDayComboBox().setEnabled(true);
		getMonthComboBox().setEnabled(true);
		getYearComboBox().setEnabled(true);

	} else {
				getDayComboBox().setEnabled(false);
				getMonthComboBox().setEnabled(false);
				getYearComboBox().setEnabled(false);
			}
}
}