@echo off
c:\jdk1.1.8\bin\java sis.admin.InsertPage