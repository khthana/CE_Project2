import java.awt.*;
import java.applet.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.net.URL.*;

public class TestRead extends Applet
{
	TextField text_name = new TextField(20);
	TextField text_password = new TextField(10);
	Choice book_choice = new Choice();
	TextField text_status = new TextField(20);

	TextField text_book_name = new TextField(20);
	TextField text_volume = new TextField(20);
	TextField text_page_quantity = new TextField(20);
	TextField text_book_path = new TextField(20);
	TextField text_book_mark = new TextField(20);
	TextField text_expire = new TextField(20);
	TextField text_id_book = new TextField(20);

	String[] data = new String[20];
	String username_buf = "";
	String password_buf = "";

	String var_book_name="";
	String var_volume="";
	String var_page_quantity="";
	String var_book_path="";
	String var_book_mark="";
	String var_expire="";
	String var_id_book="";

	public void init(){
		setLayout(null);
		Label name = new Label("Name");
		Label password = new Label("Password");
		text_password.setEchoChar('*');
		Button B_Send = new Button("Login");
		Button B_Remove = new Button("Remove");
		name.setBounds(10,25,30,10);
		text_name.setBounds(45,20,100,20);
		password.setBounds(155,25,50,10);
		text_password.setBounds(210,20,100,20);
		B_Send.setBounds(315,20,50,20);
		book_choice.setBounds(370,20,100,20);
		B_Remove.setBounds(475,20,70,20);
		text_status.setBounds(550,20,100,20);

		text_book_name.setBounds(20,100,150,20);
		text_volume.setBounds(20,130,150,20);
		text_page_quantity.setBounds(20,160,150,20);
		text_book_path.setBounds(20,190,150,20);
		text_book_mark.setBounds(20,220,150,20);
		text_expire.setBounds(20,250,150,20);
		text_id_book.setBounds(20,280,150,20);

		add(name);
		add(text_name);
		add(password);
		add(text_password);
		add(B_Send);
		add(book_choice);
		add(B_Remove);
		add(text_book_name);add(text_volume);add(text_page_quantity);
		add(text_book_path);add(text_book_mark);add(text_expire);add(text_id_book);
		add(text_status);
	}
	
	private void setMarkUsingHttpObject() {
		try
		{											
			text_status.setText("Please wait...");
			book_choice.removeAll();
			text_name.setText("");
			text_password.setText("");
			var_book_name = "";
			text_book_name.setText(var_book_name);
			var_volume = "";
			text_volume.setText(var_volume);
			var_page_quantity = "";
			text_page_quantity.setText(var_page_quantity);
			var_book_path = "";
			text_book_path.setText(var_book_path);
			var_book_mark = "";
			text_book_mark.setText(var_book_mark);
			var_expire = "";
			text_expire.setText(var_expire);
			var_id_book = "";
			text_id_book.setText(var_id_book);

			URL url = new URL(getCodeBase(), "/jservlets/DaytimeServlet");
			HttpMessage msg = new HttpMessage(url);
			Properties props = new Properties();
			Properties output = new Properties();
			props.put("user", username_buf);
			props.put("password", password_buf);
			InputStream in = msg.sendGetMessage(props);
			ObjectInputStream result = new ObjectInputStream(in);
			Object obj = result.readObject();
			output = (Properties)obj;

			
			if (output.getProperty("status")!=null)	{
				text_status.setText(output.getProperty("status"));
				book_choice.addItem("Sorry!!");
			}
			else { 
				text_status.setText("Login compleate");
				Enumeration e = output.propertyNames();
				int count_book=0;
				while (e.hasMoreElements())	{
					String str_value = (String)e.nextElement();
					data[count_book++] = (String)output.getProperty(str_value);
				}
				if (count_book==0){
					book_choice.addItem("No have cartoon");
				}
				int k,m;
				String str="";
				for (int i=0;i<count_book ;i++ ){
					k = data[i].indexOf('+');
					str = data[i].substring(0,k);
					m = data[i].indexOf('+', k+1);
					str = str +" "+ data[i].substring(k+1, m);
					book_choice.addItem(str);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	 }


private void setRemoveUsingHttpObject() {
		try
		{		
			text_status.setText("Please wait...");
			URL url = new URL(getCodeBase(), "/jservlets/DaytimeServlet");
			HttpMessage msg = new HttpMessage(url);
			Properties props = new Properties();
			props.put("remove_user", username_buf);
			props.put("remove_id_book", var_id_book);
			InputStream in = msg.sendGetMessage(props);
			ObjectInputStream result = new ObjectInputStream(in);
			Object obj = result.readObject();
			String str1 = (String)obj;
			text_status.setText(str1);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	 }
	public boolean action(Event e, Object aa){
		if (e.target instanceof Button)
		{
			Button buttonTarget = (Button)e.target;
			String sButtonString = buttonTarget.getLabel();
			if (sButtonString.equals("Login")){
				username_buf = text_name.getText();
				password_buf = text_password.getText();
				setMarkUsingHttpObject();
				
			}
			else if (sButtonString.equals("Remove")){
				book_choice.remove(book_choice.getSelectedItem());
				setRemoveUsingHttpObject();
			}
			return true;
		}
		if (e.target instanceof Choice)
		{
			int a,b;
			//String strc;
			Choice x = (Choice)e.target;
			a = data[x.getSelectedIndex()].indexOf('+');
			var_book_name = data[x.getSelectedIndex()].substring(0,a);
			text_book_name.setText(var_book_name);

			b = data[x.getSelectedIndex()].indexOf('+', ++a);
			var_volume = data[x.getSelectedIndex()].substring(a,b);
			text_volume.setText(var_volume);

			a = data[x.getSelectedIndex()].indexOf('+', ++b);
			var_page_quantity = data[x.getSelectedIndex()].substring(b,a);
			text_page_quantity.setText(var_page_quantity);

			b = data[x.getSelectedIndex()].indexOf('+', ++a);
			var_book_path = data[x.getSelectedIndex()].substring(a,b);
			text_book_path.setText(var_book_path);

			a = data[x.getSelectedIndex()].indexOf('+', ++b);
			var_book_mark = data[x.getSelectedIndex()].substring(b,a);
			text_book_mark.setText(var_book_mark);

			b = data[x.getSelectedIndex()].indexOf('+', ++a);
			var_expire = data[x.getSelectedIndex()].substring(a,b);
			text_expire.setText(var_expire);

			var_id_book = data[x.getSelectedIndex()].substring(++b);
			text_id_book.setText(var_id_book);

			return true;
		}
		
		return false;
	}
};
class HttpMessage{

	URL servlet = null;
	String args = null;

	public HttpMessage(URL servlet){
		this.servlet = servlet;
	}

	public InputStream sendGetMessage() throws IOException {
		return sendGetMessage(null);
	}
				
	public  InputStream sendGetMessage(Properties args) throws IOException {
		String argString = "";
		if (args != null)
		{
			argString = "?" + toEncodedString(args);
		}
		URL url = new URL(servlet.toExternalForm() + argString);
		//return url.toString();
		URLConnection con = url.openConnection();
		con.setUseCaches(false);
		return con.getInputStream(); 
	}

	public InputStream sendPostMessage() throws IOException {
		return sendPostMessage(null);
	}

	public InputStream sendPostMessage(Properties args) throws IOException {
		String argString = "";
		
		if (args != null)
		{
			argString = toEncodedString(args);
		}
		URLConnection con = servlet.openConnection();
		con.setDoInput(true);
		con.setDoOutput(true);
		con.setUseCaches(false);
		con.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		DataOutputStream out = new DataOutputStream(con.getOutputStream());
		out.writeBytes(argString);
		out.flush();
		out.close();

		return con.getInputStream();
	}
	private String toEncodedString(Properties args){
		StringBuffer buf = new StringBuffer();
		Enumeration names = args.propertyNames();
		while (names.hasMoreElements())
		{
			String name = (String) names.nextElement();
			String value = args.getProperty(name);
			buf.append(URLEncoder.encode(name) + "=" + URLEncoder.encode(value));
			if (names.hasMoreElements()) buf.append("&");
		}
		return buf.toString();
	}

};
