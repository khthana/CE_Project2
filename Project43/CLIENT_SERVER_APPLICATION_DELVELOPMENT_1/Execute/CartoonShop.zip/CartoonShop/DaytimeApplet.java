import java.applet.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.net.URL;
//import HttpMessage;

public class DaytimeApplet extends Applet
{
	TextField httpObject, httpObject1;
	Button refresh;

	public void init() {
		setLayout(new BorderLayout());
		Panel west = new Panel();
		west.setLayout(new GridLayout(5, 1));
		west.add(new Label("HTTP object: ",Label.RIGHT));
		west.add(new Label("HTTP object1: ",Label.RIGHT));

		add("West", west);

		Panel center = new Panel();
		center.setLayout(new GridLayout(5, 1));

		httpObject = new TextField();
		httpObject.setEditable(false);
		center.add(httpObject);

		httpObject1 = new TextField();
		httpObject1.setEditable(false);
		center.add(httpObject1);


		add("Center", center);

		Panel south = new Panel();
		refresh = new Button("refresh");
		south.add(refresh);
		add("South", south);
	}
	public void start() {
		refresh();
	}
	 private void refresh() {
		httpObject.setText(getDateUsingHttpObject());
		httpObject1.setText(getDateUsingHttpObject1());
	 }

	 private String getDateUsingHttpObject() {
		try
		{											
			URL url = new URL(getCodeBase(), "/jservlets/DaytimeServlet");
			HttpMessage msg = new HttpMessage(url);
			Properties props = new Properties();
			props.put("scott", "100");
			InputStream in = msg.sendGetMessage(props);
			ObjectInputStream result = new ObjectInputStream(in);
			Object obj = result.readObject();
			String datex = (String)obj;
			return datex;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return "xxx";
		}
	 }

	 private String getDateUsingHttpObject1() {
		try
		{											
			URL url = new URL(getCodeBase(), "/jservlets/DaytimeServlet");
			HttpMessage msg = new HttpMessage(url);
			Properties props = new Properties();
			props.put("vichet", "juatee");
			InputStream in = msg.sendGetMessage(props);
			ObjectInputStream result = new ObjectInputStream(in);
			Object obj = result.readObject();
			String datey = (String)obj;
			return datey;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return "yyy";//null
		}
	 }

	 public boolean handleEvent (Event event) {
		switch (event.id)
		{
		case Event.ACTION_EVENT:
					if (event.target == refresh)
					{
						refresh();
						return true;
					}
		}
		return false;
	 }
};
class HttpMessage{

	URL servlet = null;
	String args = null;

	public HttpMessage(URL servlet){
		this.servlet = servlet;
	}

	public InputStream sendGetMessage() throws IOException {
		return sendGetMessage(null);
	}
				//InputStream
	public  InputStream sendGetMessage(Properties args) throws IOException {

		String argString = "";
		if (args != null)
		{
			argString = "?" + toEncodedString(args);
		}
		URL url = new URL(servlet.toExternalForm() + argString);
		//return url.toString();
		URLConnection con = url.openConnection();
		con.setUseCaches(false);
		return con.getInputStream();
	}

	public InputStream sendPostMessage() throws IOException {
		return sendPostMessage(null);
	}

	public InputStream sendPostMessage(Properties args) throws IOException {
		String argString = "";
		
		if (args != null)
		{
			argString = toEncodedString(args);
		}
		URLConnection con = servlet.openConnection();
		con.setDoInput(true);
		con.setDoOutput(true);
		con.setUseCaches(false);
		con.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		DataOutputStream out = new DataOutputStream(con.getOutputStream());
		out.writeBytes(argString);
		out.flush();
		out.close();

		return con.getInputStream();
	}
	private String toEncodedString(Properties args){
		StringBuffer buf = new StringBuffer();
		Enumeration names = args.propertyNames();
		while (names.hasMoreElements())
		{
			String name = (String) names.nextElement();
			String value = args.getProperty(name);
			buf.append(URLEncoder.encode(name) + "=" + URLEncoder.encode(value));
			if (names.hasMoreElements()) buf.append("&");
		}
		return buf.toString();
	}

};