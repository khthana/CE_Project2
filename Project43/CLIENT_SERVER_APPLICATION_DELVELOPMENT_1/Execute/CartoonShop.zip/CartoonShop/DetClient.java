//package examples.hello;
import java.io.*;
import java.awt.*;
import java.awt.Graphics;
import java.rmi.Naming;
import java.rmi.RemoteException;


public class DetClient{
       public static void main(String args[]){
              HelloApp A=new HelloApp();
              A.HelloApps();
              while(true);
       }
}
class HelloApp extends Frame {

    String message = "blank";
    final int NUM=260,SEMI=261,NEWLINE=262;
    String inPut=new String("");
    int tokenval=0,index=0,numServer=2;
    Hello obj = null;
    public void HelloApp(){
      //super();
    }
    public void HelloApps() {
      FileInputStream s;
      int readVar;
      long[][] x=new long[100][100];
      int N=0,r=0;
      try
      {
         s = new FileInputStream("t.txt");
         readVar = 0;
         //--------------------Read File to String-----------
         while (readVar != -1)
         {
           try
           {
             readVar = s.read();
             inPut+=(char)readVar;
           }
           catch (IOException e)
           {
             System.out.println("Unknown IO error reading file ");
             System.exit(2);
           }
         }
         //--------------Cal size-----------
         int t=0;
         N=0;
         while(!(t==NEWLINE)){
               t=lexan();
               if(t==NUM)N++;
         }
         //------------------keep to array-----------
         index=0;
         for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++){
                t=lexan();
                while(!(t==NUM))t=lexan();
                x[i][j]=tokenval;
            }
         for(int i=1;i<=N;i++){
            for(int j=1;j<=N;j++)
                System.out.print(x[i][j]+" ");
            System.out.println("");
         }
         System.out.println("");
         message=calDet(x,N)+"";
         System.out.println(message);
      }
      catch (FileNotFoundException e)
      {
        System.out.println("File " + " not found");
        System.exit(1);
      }
       Color c=new Color(200,200,200);
       setBackground(c);
	     setVisible(true);
       setSize(200,200);
    }

    public void paint(Graphics g) {
           g.drawString(message, 25, 50);
    }
    //--------------------------- Cal Det---------------------------------
    public long calDet(long a[][],int size){
          int sign=1,j=0;
          long detVal=0;
          long[] x=new long[size+1];
          long[][] m1=new long[size+1][size+1],
                   m2=new long[size+1][size+1],
                   m3=new long[size+1][size+1],
                   m4=new long[size+1][size+1],
                   m5=new long[size+1][size+1],
                   m6=new long[size+1][size+1],
                   m7=new long[size+1][size+1];
          CalDetThread s1=new CalDetThread("161.246.5.153");// Kling
          CalDetThread s2=new CalDetThread("161.246.5.154");// Pop
          CalDetThread s3=new CalDetThread("161.246.5.163");// Bom
          CalDetThread s4=new CalDetThread("161.246.5.153");// Jim
          CalDetThread s5=new CalDetThread("161.246.5.x");
          CalDetThread s6=new CalDetThread("161.246.5.x");
          CalDetThread s7=new CalDetThread("161.246.5.x");
          if(size==1)return a[1][1];
          else{
               for(int i=1;i<=size;i++){
                   if((i%2)==0)sign=-1;else sign=1;
                   //----------------send Matrix for cal---------------
                   if(s1.getIdle()){
                     for(int r=2;r<=size;r++){
                       j=1;
                       for(int c=1;c<=size;c++)
                         if(c!=i) {
                           m1[r-1][j]=a[r][c];j++;
                         }
                     }
                     s1.setI(i);s1.calDet(m1,(size-1));
                     System.out.println("Column:"+i);
                   }
                   else
                    if(s2.getIdle()){
                      for(int r=2;r<=size;r++){
                        j=1;
                        for(int c=1;c<=size;c++)
                          if(c!=i){
                            m2[r-1][j]=a[r][c];j++;
                          }
                      }
                      s2.setI(i);s2.calDet(m2,(size-1));
                      System.out.println("Column:"+i);
                    }
                   else
                    if(s3.getIdle()){
                      for(int r=2;r<=size;r++){
                        j=1;
                        for(int c=1;c<=size;c++)
                           if(c!=i){
                              m3[r-1][j]=a[r][c];j++;
                           }
                      }
                      s3.setI(i);s3.calDet(m3,(size-1));
                      System.out.println("Column:"+i);
                    }
                   else
                    if(s4.getIdle()){
                      for(int r=2;r<=size;r++){
                        j=1;
                        for(int c=1;c<=size;c++)
                           if(c!=i){
                              m4[r-1][j]=a[r][c];j++;
                           }
                      }
                      s4.setI(i);s4.calDet(m4,(size-1));
                      System.out.println("Column:"+i);
                    }
                   else
                    if(s5.getIdle()){
                      for(int r=2;r<=size;r++){
                        j=1;
                        for(int c=1;c<=size;c++)
                           if(c!=i){
                              m5[r-1][j]=a[r][c];j++;
                           }
                      }
                      s5.setI(i);s5.calDet(m5,(size-1));
                      System.out.println("Column:"+i);
                    }
                   else
                    if(s6.getIdle()){
                      for(int r=2;r<=size;r++){
                        j=1;
                        for(int c=1;c<=size;c++)
                           if(c!=i){
                              m6[r-1][j]=a[r][c];j++;
                           }
                      }
                      s6.setI(i);s6.calDet(m6,(size-1));
                      System.out.println("Column:"+i);
                    }
                   else
                    if(s7.getIdle()){
                      for(int r=2;r<=size;r++){
                        j=1;
                        for(int c=1;c<=size;c++)
                           if(c!=i){
                              m7[r-1][j]=a[r][c];j++;
                           }
                      }
                      s7.setI(i);s7.calDet(m7,(size-1));
                      System.out.println("Column:"+i);
                    }
               //-----------wait some server idle----------
                   while(!(  (s1.getIdle()&&(numServer>=1))
                           ||(s2.getIdle()&&(numServer>=2))
                           ||(s3.getIdle()&&(numServer>=3))
                           ||(s4.getIdle()&&(numServer>=4))
                           ||(s5.getIdle()&&(numServer>=5))
                           ||(s6.getIdle()&&(numServer>=6))
                           ||(s7.getIdle()&&(numServer>=7))
                        ));
                   if(s1.getIdle()&&s1.waitAns){
                      x[s1.getI()]=a[1][s1.getI()]*s1.getAns();s1.waitAns = false;
                   }
                   if(s2.getIdle()&&s2.waitAns){
                      x[s2.getI()]=a[1][s2.getI()]*s2.getAns();s2.waitAns = false;
                   }
                   if(s3.getIdle()&&s3.waitAns){
                      x[s3.getI()]=a[1][s3.getI()]*s3.getAns();s3.waitAns = false;
                   }
                   if(s4.getIdle()&&s4.waitAns){
                      x[s4.getI()]=a[1][s4.getI()]*s4.getAns();s4.waitAns = false;
                   }
               }
               //--------wait server idle all-------
               while(!(s1.getIdle()&&s2.getIdle()&&s3.getIdle()&&s4.getIdle()));
                   if(s1.getIdle()&&s1.waitAns)
                      x[s1.getI()]=a[1][s1.getI()]*s1.getAns();
                   if(s2.getIdle()&&s2.waitAns)
                      x[s2.getI()]=a[1][s2.getI()]*s2.getAns();
                   if(s3.getIdle()&&s3.waitAns)
                      x[s3.getI()]=a[1][s3.getI()]*s3.getAns();
                   if(s4.getIdle()&&s4.waitAns)
                      x[s4.getI()]=a[1][s4.getI()]*s4.getAns();
               //------------SUM-------------
               for(int i=1;i<=size;i++)
                   detVal=detVal+x[i];
          }
          return detVal;
    }
 //-------------------------------- Get Token ------------------------------
    public int lexan(){
          int t=0,sign=1;
          tokenval=0;
          while(true){
                t=inPut.charAt(index);index++;
                if(t==' '||t=='\t');
                else if(t=='\n')return NEWLINE;
                else if((((t-'0')>=0)&&((t-'0')<=9))||(t=='-')){
                       if(t=='-'){
                          sign=-1;
                          t=inPut.charAt(index);index++;
                       }
                       tokenval=t-'0';
                       t=inPut.charAt(index);index++;
                       while(((t-'0')>=0)&&((t-'0')<=9)){
                              tokenval=tokenval*10+t-'0';
                              t=inPut.charAt(index);index++;
                       }
                       tokenval=tokenval*sign;
                       index--;
                       return NUM;
                     }
                else {
                      return t;
                }
          }
    }
}
//------------------------------ Server Thread -----------------------------------------
class CalDetThread extends Thread{
      int size=0,i=0;
      long ans=0;
      boolean idle=true,first=true,waitAns = false;
      long[][] a;
      Hello obj = null;
      String hostName="";
      CalDetThread(String hostName){
          this.hostName=hostName;
          idle=true;
      }
      public void calDet(long a[][],int size){
          this.a=new long[size+1][size+1];
          this.a=a;
          this.size=size;
          idle=false;
          waitAns = true;
          if(first){start();first=false;}
          resume();
      }
      public synchronized void run(){
       while(true){
         try {
	        obj = (Hello)Naming.lookup("//" +
		  	 //getCodeBase().getHost() + "/HelloServer");
          hostName + "/HelloServer");
          ans=obj.calDet(a,size);
          if((i%2)==0)ans=-ans;else;
          System.out.println(obj.sayHello()+ans);
          } catch (Exception e) {
	           System.out.println("DetClient exception: " +
				     e.getMessage());
	           e.printStackTrace();
       	    }
         idle=true;
         suspend();
       }
      }
      public long getAns(){
             return  ans;
      }
      public boolean getIdle(){
             return  idle;
      }
      public void clearIdle(){
             idle=false;
      }
      public void setI(int i){
             this.i=i;
      }
      public int  getI(){
             return i;
      }
}













