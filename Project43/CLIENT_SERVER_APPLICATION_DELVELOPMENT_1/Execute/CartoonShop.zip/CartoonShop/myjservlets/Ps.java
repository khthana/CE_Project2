import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Ps extends HttpServlet {

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
			
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();

			HttpSession session = req.getSession(true);
						
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Untitled Document</title>");
			out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">");
			out.println("</head>");

			out.println("<body bgcolor=\"#FFFFFF\">");
			out.println("<p align=\"center\">&nbsp;</p>");
			out.println("<p align=\"center\"><b><font face=\"MS Sans Serif\" size=\"3\">Please enter your Username/Password</font></b></p>");
			out.println("<form method=\"get\" action=\"http://myproject/jservlets/ReadIndex\" target = \"_parent\">");
			out.println("  <table width=\"99%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">");
			out.println("    <tr> ");
			out.println("      <td width=\"34%\">&nbsp;</td>");
			out.println("      <td width=\"57%\"><font face=\"MS Sans Serif\" size=\"2\">User name ");
			out.println("        <input type=\"text\" name=\"textfield\" maxlength=\"20\" size=\"20\">");
			out.println("        </font></td>");
			out.println("      <td width=\"9%\">"); 
			out.println("        <div align=\"center\"></div>");
			out.println("      </td>");
			out.println("    </tr>");
			out.println("    <tr> ");
			out.println("      <td width=\"34%\">&nbsp;</td>");
			out.println("      <td width=\"57%\"><font face=\"MS Sans Serif\" size=\"2\">Password&nbsp;&nbsp; ");
			out.println("        <input type=\"password\" name=\"textfield2\" maxlength=\"20\" size=\"20\">");
			out.println("        </font></td>");
			out.println("      <td width=\"9%\">&nbsp;</td>");
			out.println("    </tr>");
			out.println("    <tr> ");
			out.println("      <td width=\"34%\" height=\"41\">&nbsp;</td>");
			out.println("      <td width=\"57%\" height=\"41\" valign=\"bottom\">"); 
			out.println("        <div align=\"left\"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ");
			out.println("          <input type=\"submit\" name=\"Submit\" value=\"Submit\">");
			out.println("          <input type=\"reset\" name=\"Submit2\" value=\"Reset\">");
			out.println("        </div>");
			out.println("      </td>");
			out.println("      <td width=\"9%\" height=\"41\">&nbsp;</td>");
			out.println("    </tr>");
			out.println("  </table>");
			out.println("  <p>&nbsp; </p>");
			out.println("</form>");
			out.println("<p align=\"center\">&nbsp;</p>");

			
			out.println("</body>");
			out.println("</html>");
			
		}
}