import java.util.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ReadDetail extends HttpServlet {

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
			
			Connection conn= null;
			Statement  stmtt = null;
			Statement  stmtx = null;
			ResultSet  rss = null;
			ResultSet  rss1 = null;
			ResultSet  rss2 = null;

			
			String st1 = "",st2 = "",st3="";
			
			//int sum = 0;

			

			HttpSession session = req.getSession(true);

			try
			{
				Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
				conn = DriverManager.getConnection("jdbc:odbc:projdb","","");

				//conn.setAutoCommit(false);
				stmtt = conn.createStatement();
				stmtx = conn.createStatement();

				//String name = req.getParameter("name");
				//Input
				String cname =req.getParameter("book_name");// "chinjung";
				String id_book =req.getParameter("id_book");// "1";
				String user =req.getParameter("user");//"x";
				
				if (id_book!=null && user!=null)
				{
					//String[] namesxx = session.getValueNames();
					//for (int i =0;i<namesxx.length ;i++ )
					//		{
					//			session.removeValue(namesxx[i]);
					//		}
					String struser = "userx";
					session.putValue(struser,user);
					String stridbook = "id_bookx";
					session.putValue(stridbook,id_book);
				}
				String strx = req.getParameter("markx");
				if (strx!=null)
				{
					
					String str_user = (String)session.getValue("userx");
					String str_id_book = (String)session.getValue("id_bookx");
					stmtt.executeUpdate("update read set mark = '"+strx+"' where id_book = '"+str_id_book+"' and user = '"+str_user+"'");
					//ObjectOutputStream outx = new ObjectOutputStream(res.getOutputStream());
					//outx.writeObject("Hello World!!!!!!!"+strx);
					//str = null;
				}
				else {
				//Input
				
				res.setContentType("text/html");
				PrintWriter out = res.getWriter();

				String book_path = "";
				String num_of_page = "0";
				String volume = "0";
				String book_mark = "0";

				rss = stmtt.executeQuery("select book_path from cartoon_details where book_name = '"+cname+"'");
				if (rss.next())
				{
					book_path = rss.getString("book_path");
				}

				rss1 = stmtt.executeQuery("select mark from read where id_book = '"+id_book+"' and user = '"+user+"'");
				if (rss1.next())
				{
					book_mark = rss1.getString("mark");
				}

				rss2 = stmtx.executeQuery("select volume, page_quantity from cartoon where id_book = "+id_book+"");
				while (rss2.next())
				{
					volume = rss2.getString("volume");
					num_of_page = rss2.getString("page_quantity");
				}
				//if (rss2.next())
				//	{
				//		num_of_page = rss2.getString("page_quantity");
				//	}

				//if ("numpage".equals(req.getParameter("numpage")))
				//{
				//	ObjectOutputStream outx = new ObjectOutputStream(res.getOutputStream());
				//	outx.writeObject(num_of_page);
				//}
				//if ("volume".equals(req.getParameter("volume")))
				//{
				//	ObjectOutputStream outx = new ObjectOutputStream(res.getOutputStream());
				//	outx.writeObject(volume);
				//}
				//if ("path".equals(req.getParameter("path")))
				//{
				//	ObjectOutputStream outx = new ObjectOutputStream(res.getOutputStream());
				//	outx.writeObject(book_path);
				//}
				//if ("mark".equals(req.getParameter("mark")))
				//{
				//	ObjectOutputStream outx = new ObjectOutputStream(res.getOutputStream());
				//	outx.writeObject(book_mark);
				//}

				out.println("<BASE HREF=\"http://myproject/\">");
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Untitled Document</title>");
				out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">");
				out.println("</head>");

				out.println("<body bgcolor=\"#FFFFFF\">");
				out.println("<applet code=\"ImageFormat.class\" width=\"750\" height=\"650\">");
				out.println("<param name=numpage value="+num_of_page+">");
				out.println("<param name=volume value="+volume+">");
				out.println("<param name=pt value=\""+book_path+"\">");
				out.println("<param name=bmark value="+book_mark+">");
				out.println("</applet> ");

				//String[] namesxx = session.getValueNames();
				//for (int i =0;i<namesxx.length ;i++ )
				//			{
				//				session.removeValue(namesxx[i]);
				//			}
				
				//Ps.first_time = true;
				//out.println("<br>After of first_time "+Ps.first_time);
				//Ps.first_time = false;
				//out.println("<br>After of first_time "+Ps.first_time);
				out.println("</body>");
				out.println("</html>");
				
				//out.println("</BODY></HTML>");

				
				}
			}
			catch ( SQLException e ) {
						System.err.println("Could not establish connection.");
						//out.println("1</BODY>");
				}
				catch ( ClassNotFoundException e ) {
						System.err.println("Could not load database driver.");
						//out.println("2</BODY>");
				}

				finally {
						try{
							if (conn != null)
								conn.close();
							}
						catch (SQLException ignored)	{	}
				}
			
		}
}