import java.util.*;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ReadList extends HttpServlet {
			String user = "",password = "";

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
			
			Connection conn= null;
			Statement  stmtt = null;
			Statement  stmtx = null;
			Statement  stmty = null;
			Statement  stmtz = null;
			ResultSet  rss = null;
			ResultSet  rss1 = null;
			ResultSet  rss2 = null;
			ResultSet  rss3 = null;
			String st1 = "",id_book = "",book_name="",volume="";
			
			
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();

			HttpSession session = req.getSession(true);
			
			String first = (String)session.getValue("first_time");
			if (first != null){
						user = (String)session.getValue("user");
						password = (String)session.getValue("password");
						session.removeValue("user");
						session.removeValue("password");
						session.removeValue("first_time");
			}
		try
			{
				Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
				conn = DriverManager.getConnection("jdbc:odbc:projdb","","");

				//conn.setAutoCommit(false);
				stmtt = conn.createStatement();
				stmtx = conn.createStatement();
				stmty = conn.createStatement();
				stmtz = conn.createStatement();
				String buttonremove = req.getParameter("Submit");
				String[] bookremove =  req.getParameterValues("checkbox");

				if (bookremove != null)
						if (buttonremove.equals("Remove"))
						{						
							for (int i = 0;i < bookremove.length ;i++ ){
								stmtz.executeUpdate("delete from read where user = '"+user+"' and id_book='"+bookremove[i]+"'");
							}
						}

				out.println("<html>");
				out.println("<head>");
				out.println("<title>Untitled Document</title>");
				out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">");
				out.println("<SCRIPT LANGUAGE=\"JavaScript\">");
				out.println("	function ConfirmRemove(){");
				out.println("		var check_rv=false;");
				out.println("		if (form1.length>1){");
				out.println("			if (form1.length>2)");
				out.println("				for (ct=0; ct<(form1.length-1); ct++){");
				out.println("					if (form1.checkbox[ct].checked){");
				out.println("						check_rv=true;break;");
				out.println("					}");
				out.println("				}");
				out.println("			else if (form1.checkbox.checked)");
				out.println("					check_rv=true;");
				out.println("		}");
				out.println("		if (check_rv)");
				out.println("			if (!confirm('Are you sure ?')) {");
				out.println("				if (form1.length>2){");
				out.println("					for (count=0; count<(form1.length-1); count++)");
				out.println("						form1.checkbox[count].checked=false;");
				out.println("				}");
				out.println("				else form1.checkbox.checked=false;");
				out.println("			}");
				out.println("	}");
				out.println("</SCRIPT>");
				out.println("</head>");
				out.println("<p>List</p>");
				out.println("<form name=\"form1\" method=\"get\" action=\"http://myproject/jservlets/ReadList\" onSubmit='ConfirmRemove()'>");
				out.println("  <table width=\"102%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">");

				out.println("<body bgcolor=\"#CCFFFF\">");
				rss = stmtt.executeQuery("select password from user where user = '"+user+"'");
				if (rss.next()){
					if ((st1=rss.getString("password")).equals(password)){
					//Right User Password
							out.println("Welcome " +user+ " to my store");
							rss1 = stmtx.executeQuery("select id_book, expire from read where user = '"+user+"'");
							while (rss1.next())
							{
								id_book = rss1.getString("id_book");
								long expire = Long.parseLong( rss1.getString("expire"));
								java.util.Date dd1 = new java.util.Date(expire);
								java.util.Date today = new java.util.Date();
								//int gdate = dd1.getDate();
								//int gmonth = dd1.getMonth();
								//int gyear = dd1.getYear();
								rss2 = stmty.executeQuery("select book_name, volume from cartoon where id_book = "+id_book);
								if (rss2.next()){
										book_name = rss2.getString("book_name");volume = rss2.getString("volume");
								}
								out.println("    <tr> ");
								out.println("      <td width=\"7%\">");
								out.println("        <input type=\"checkbox\" name=\"checkbox\" value=\""+id_book+"\">");
								out.println("      </td>");
								if (today.before(dd1))
								{
									out.println("      <td width=\"93%\"> <a href=\"http://myproject/jservlets/ReadDetail?book_name="+book_name+"&id_book="+id_book+"&user="+user+"\" target=\"mainFrame\"><b>"+book_name+"  "+volume); 
									out.println("        </b></a><br>");
									out.println("        <i>Expire : </i>"+dd1.toGMTString()+"</td>");
								}
								else
								{
									out.println("      <td width=\"93%\"> "+book_name+" "+id_book+" was expired"); 
									out.println("        <br>");
									out.println("        <i>Please remove </i></td>");
								}
								
								out.println("    </tr>");
							}
							out.println("  </table>");
							out.println("  <h1> ");
							out.println("    <input type=\"submit\" name=\"Submit\" value=\"Remove\">");
							out.println("  </h1>");
							out.println("</form>");
					}
					else 
							out.println("Sorry it's wrong password");
				}
				else
					out.println("No have user name <b>"+user+"</b> in my store");
				//--------------------------------
				out.println("<br><a href=\"http://myproject/\" target=\"_parent\">Back to Home</a> ");
			
				out.println("</body>");
				out.println("</html>");
				//out.println("</BODY></HTML>");
				
			}
			catch ( SQLException e ) {
						System.err.println("Could not establish connection.");
						out.println("1</BODY>");
				}
				catch ( ClassNotFoundException e ) {
						System.err.println("Could not load database driver.");
						out.println("2</BODY>");
				}

				finally {
						try{
							if (conn != null)
								conn.close();
							}
						catch (SQLException ignored)	{out.println("3</BODY>");	}
				}
			
		};
}