
public class InfoRead 
{
	private String book_name = null;
	private String volume = null;
	private String expire = null;
	private String book_path = null;
	private String book_mark = null;
	private String number_of_page = null;

	InfoRead(String book_name,String volume,String expire,
			String book_path,String book_mark,String number_of_page)
	{
		this.book_name = book_name;
		this.volume = volume;
		this.expire = expire;
		this.book_path = book_path;
		this.book_mark = book_mark;
		this.number_of_page = number_of_page;
	}
	InfoRead(String book_name,String volume,String expire)		
	{
		this.book_name = book_name;
		this.volume = volume;
		this.expire = expire;
	}
	InfoRead() { };

	public String getBook_name(){
		return book_name;
	}
	public String getVolume(){
		return volume;
	}
	public String getExpire(){
		return expire;
	}
	public String getBook_path(){
		return book_path;
	}
	public String getBook_mark(){
		return book_mark;
	}
	public String getNumber_of_page(){
		return number_of_page;
	}
	
}
