import java.io.*;
import java.net.*;
import java.util.*;

public class HttpMessage{

	URL servlet = null;
	String args = null;

	public HttpMessage(URL servlet){
		this.servlet = servlet;
	}

	public InputStream sendGetMessage() throws IOException {
		return sendGetMessage(null);
	}
				//InputStream
	public  InputStream sendGetMessage(Properties args) throws IOException {

		String argString = "";
		if (args != null)
		{
			argString = "?" + toEncodedString(args);
		}
		URL url = new URL(servlet.toExternalForm() + argString);
		//return url.toString();
		URLConnection con = url.openConnection();
		con.setUseCaches(false);
		return con.getInputStream();
	}

	public InputStream sendPostMessage() throws IOException {
		return sendPostMessage(null);
	}

	public InputStream sendPostMessage(Properties args) throws IOException {
		String argString = "";
		
		if (args != null)
		{
			argString = toEncodedString(args);
		}
		URLConnection con = servlet.openConnection();
		con.setDoInput(true);
		con.setDoOutput(true);
		con.setUseCaches(false);
		con.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		DataOutputStream out = new DataOutputStream(con.getOutputStream());
		out.writeBytes(argString);
		out.flush();
		out.close();

		return con.getInputStream();
	}
	private String toEncodedString(Properties args){
		StringBuffer buf = new StringBuffer();
		Enumeration names = args.propertyNames();
		while (names.hasMoreElements())
		{
			String name = (String) names.nextElement();
			String value = args.getProperty(name);
			buf.append(URLEncoder.encode(name) + "=" + URLEncoder.encode(value));
			if (names.hasMoreElements()) buf.append("&");
		}
		return buf.toString();
	}

};