import java.io.* ;
import javax.servlet.* ;
import javax.servlet.http.* ;

public class HelloServlet extends HttpServlet {
      public void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

             res.setContentType("text/html");

             PrintWriter out = res.getWriter();
			out.println("<BASE HREF=\"http://myproject/\">");
           	out.println("<html>");
			out.println("<head>");
			out.println("<link rel=\"stylesheet\" href=\"ftie4style.css\">");
			out.println("	<!-- Infrastructure code for the tree -->");
			out.println("<script src=\"ftiens4.js\"></script>");
			out.println("	<!-- Execution of the code that actually builds the specific tree -->");
			out.println("<script>");
			out.println("foldersTree = gFld(\"<i>My Cartoon Bookstorexxxxxxxxx</i>\")");
			out.println("	aux1 = insFld(foldersTree, gFld(\"Europe\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"United Kingdom\"))");
			out.println("		      aux3 = insFld(aux2, gFld(\"Scotland\"))");
			out.println("				insDoc(aux3, gLnk(2, \"Edinburgh\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_edinburgh.gif\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"London\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_london.jpg\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"Germany\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"Munich\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_munich.jpg\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"Greece\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"Athens\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_athens.jpg\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"Italy\"))");
			out.println("		      aux3 = insFld(aux2, gFld(\"Tuscany\"))");
			out.println("				insDoc(aux3, gLnk(2, \"Florence\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_florence.jpg\"))");
			out.println("				insDoc(aux3, gLnk(2, \"Pisa\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_pisa.jpg\"))");
			out.println("			insDoc(aux2, gLnk(2, \"Rome\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_rome.jpg\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"Portugal\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"Lisboa\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_lisbon.jpg\"))");
			out.println("     aux1 = insFld(foldersTree, gFld(\"America\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"Canada\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"Montreal\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_montreal.jpg\"))");
			out.println("	      aux2 = insFld(aux1, gFld(\"United States\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"Boston\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_boston.jpg\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"New York\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_newyork.jpg\"))");
			out.println(" 			insDoc(aux2, gLnk(2, \"Washington\", \"www.geocities.com/Paris/LeftBank/2178/beenthere_washington.jpg\"))");
			out.println("</script>");
			out.println("<script>");
			out.println("		initializeDocument()");
			out.println("</script>");
			out.println("</head>");
			out.println("<body bgcolor=\"#CCFFFF\">");
			out.println("</html>");
      } // doGet
} // HelloServlet

