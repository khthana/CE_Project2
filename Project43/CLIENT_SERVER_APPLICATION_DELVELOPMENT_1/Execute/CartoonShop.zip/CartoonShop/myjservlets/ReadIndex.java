import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ReadIndex extends HttpServlet {

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{

				HttpSession session = req.getSession(true);

				res.setContentType("text/html");
				PrintWriter out = res.getWriter();
		
				String user = req.getParameter("textfield");
				String password =  req.getParameter("textfield2");
				String first_time = "first";

				 String put_user = "user";
				 String put_password ="password";
				 String put_first_time = "first_time";

				 session.putValue(put_user,user);
				 session.putValue(put_password,password);
				 session.putValue(put_first_time,first_time);

				out.println("<html>");
				out.println("<head>");
				out.println("<title>Untitled Document</title>");
				out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">");
				out.println("</head>");
				out.println("<frameset cols=\"144,639*\" frameborder=\"NO\" border=\"0\" framespacing=\"0\" rows=\"*\">"); 
				out.println("  <frame name=\"leftFrame\" scrolling=\"AUTO\" noresize src=\"http://myproject/jservlets/ReadList\">");
				out.println("  <frame name=\"mainFrame\" src=\"http://myproject/readfirst.html\">");
				out.println("</frameset>");
				out.println("<noframes><body bgcolor=\"#FFFFFF\">");
				out.println("</body></noframes>");
				out.println("</html>");
		};

}