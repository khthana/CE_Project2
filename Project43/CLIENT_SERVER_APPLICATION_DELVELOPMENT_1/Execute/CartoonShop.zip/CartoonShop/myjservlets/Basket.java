public class  Basket extends Object{
	private String[] idbook = new String[50];
	private int countid = 0;

	public void addID(String st){
		idbook[countid] = st;	
		countid++;
	}
	public String getID(int index){
		return idbook[index];
	}
	public int getlength(){
		return countid + 1;
	}
}
