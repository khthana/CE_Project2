import java.util.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ExtendCradit extends HttpServlet {

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
			
			Connection conn = null;
			Statement  stmt = null;
			//Statement  stmtx = null;
			ResultSet  rss = null;
			//String st1 = "",st2 = "",st3="";
			//java.util.Date d1 = new java.util.Date();			
			//System.currentTimeMillis()
			
			//int sum = 0;

			res.setContentType("text/html");
			PrintWriter out = res.getWriter();

			//HttpSession session = req.getSession(true);
						
			String user = req.getParameter("textfield1");
			String password =  req.getParameter("textfield2");
			String cradit_card =  req.getParameter("textfield3");
			String cradit_size = req.getParameter("select4");
						
			int cradit_sizex = Integer.parseInt(cradit_size);

			out.println("<HTML><HEAD><TITLE>New Member</TITLE></HEAD>");
			out.println("<BODY><H1>Extend Cradit</H1>");

			try
			{
				Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
				conn = DriverManager.getConnection("jdbc:odbc:projdb","","");
				stmt = conn.createStatement();
				//conn.setAutoCommit(false);
				boolean err_all=false;
				boolean err_blank_user=false,err_blank_password=false,err_blank_cradit_card=false;
				
				//Check blank
				if (user.equals("")){
					err_blank_user = true;
					err_all = true;
				}
				if (password.equals("")){
					err_blank_password = true;
					err_all = true;
				}
				if (cradit_card.equals("")){
					err_blank_cradit_card = true;
					err_all = true;
				}
				//end check blank
				
				if (!err_blank_user && !err_blank_password && !err_blank_cradit_card){
					rss = stmt.executeQuery("select user from user where user='"+user+"' and password='"+password+"'");
					if (!rss.next())
					{
						err_all=true;
						out.println("<br>No user and password there!!");
					}
				}
				if (!err_all){
					stmt.executeUpdate("update user set cradit = cradit + "+cradit_size+" where user = '"+user+"'");
					
					out.println("<br>Your cradit was extended<br><br>");
					//out.println("<br><a href =\"http://myproject/\">Back to Home</a>");
					out.println("<br><INPUT type=\"button\" name=\"bClose\" value=\"Close window\" onClick=\"self.close()\">");
				}
				else 
				{
					int n=0;
					//begin blank
					if (err_blank_user)
						out.println("<br> "+(++n)+" User name must not blank");
					if (err_blank_password)
						out.println("<br> "+(++n)+" Password must not blank");
					if (err_blank_cradit_card)
						out.println("<br> "+(++n)+" Cradit card number must not blank");
					//end blank
				}
				

				
				out.println("</BODY></HTML>");

			}
			catch ( SQLException e ) {
						System.err.println("Could not establish connection.");
							
						out.println("1</BODY>");
				}
				catch ( ClassNotFoundException e ) {
						System.err.println("Could not load database driver.");
						out.println("2</BODY>");
				}

				finally {
						try{
							if (conn != null)
								conn.close();
							}
						catch (SQLException ignored)	{out.println("3</BODY>");	}
				}
			
		}
}