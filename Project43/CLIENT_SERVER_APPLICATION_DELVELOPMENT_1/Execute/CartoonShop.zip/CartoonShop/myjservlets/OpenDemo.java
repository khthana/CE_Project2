import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class OpenDemo extends HttpServlet{

		public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException {
				
				Connection conn= null;
				Connection connn = null;
				Statement  stmtt = null;
				Statement  stmtt1 = null;
				ResultSet  rss = null;
				ResultSet  rss1 = null;
				String st1 = "",st2="",st3="";
				String[] st4 = new String[20];
				int countbook = 0;

				//HttpSession session = req.getSession(true);
			
				res.setContentType("text/html");
				PrintWriter out = res.getWriter();

				
				
				try {
						Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
						conn = DriverManager.getConnection("jdbc:odbc:projdb","","");
						connn = DriverManager.getConnection("jdbc:odbc:projdb","","");
						stmtt = conn.createStatement();
						stmtt1 = connn.createStatement();
						
						String name = req.getParameter("name");

						rss = stmtt.executeQuery("select book_name_t, book_desc, book_path from cartoon_details where book_name = '"+name+"'");
											
						while(rss.next()){
							st1 = rss.getString("book_name_t"); 
							st2 = rss.getString("book_desc");
							st3 = rss.getString("book_path");
						}
						rss1 = stmtt1.executeQuery("select id_book from cartoon where book_name = '"+name+"'");
						
						while(rss1.next()){
							st4[countbook + 1] = rss1.getString("id_book");
							countbook += 1;
						}
						
						out.println("<BASE HREF=\"http://myproject/\">");
						out.println("<html>");
						out.println("<head>");
						out.println("<title>Untitled Document</title>");
						out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">");
						out.println("</head>");

						out.println("<body bgcolor=\"#FFFFFF\">");
						out.println("<table width=\"96%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">");
						out.println("  <tr bgcolor=\"#FFFFFF\">"); 
						out.println("    <td colspan=\"2\">"); 
						
						
						out.println("      <p align=\"center\"><font face=\"MS Sans Serif\"><b>"+st1+"</b></font></p>");
						out.println("      <hr align=\"center\">");
						out.println("    </td>");
						out.println("  </tr>");
						out.println("  <tr> ");
						out.println("    <td rowspan=\"2\" align=\"left\" valign=\"top\" width=\"49%\" bgcolor=\"#FFFFFF\">"); 
						out.println("      <div align=\"center\"><img src=\"images/"+st3+"/demo.jpg\" width=\"353\" height=\"527\">&nbsp;&nbsp;</div>");
						out.println("    </td>");
						out.println("    <td width=\"51%\" height=\"173\" align=\"left\" valign=\"top\" bgcolor=\"#FFFFFF\">"); 
						out.println("      <p>&nbsp;&nbsp;<font face=\"MS Sans Serif\" size=\"3\"><b>Description :</b></font></p>");
						out.println("      <p><font face=\"MS Sans Serif\" size=\"2\">"+st2+"</font></p>");
						out.println("      <p>&nbsp;</p>");
						out.println("    </td>");
						out.println("  </tr>");
						out.println("  <tr> ");
						out.println("    <td width=\"51%\" height=\"288\" align=\"left\" valign=\"top\" bgcolor=\"#FFFFFF\">"); 
						out.println("      <p>&nbsp;&nbsp;&nbsp;<b><font face=\"MS Sans Serif\" size=\"3\">Select the book</font></b></p>");
						out.println("      <form method=\"get\" action=\"http://myproject/jservlets/SessionTracker\">");
						out.println("        <p> <font face=\"MS Sans Serif\" size=\"2\">"); 
						for (int i=1;i<=countbook ;i++ )
						{
							out.println("          <input type=\"checkbox\" name=\"checkbox\" value=\""+st4[i]+"\">");
							out.println("          Book "+i+" "); 
						}
						out.println("        <p> <font face=\"MS Sans Serif\" size=\"2\">"); 
						out.println("          <input type=\"submit\" name=\"Submit\" value=\"Add to basket\">");
						//out.println("          &nbsp;&nbsp; ");
						out.println("          <input type=\"submit\" name=\"Submit\" value=\"Check basket\">");
						out.println("          </font></p>");
						out.println("        </form>");
						out.println("    </td>");
						out.println("  </tr>");
						out.println("</table>");
						out.println("<div align=\"center\"></div>");
						out.println("</body>");
						out.println("</html>");

			    		
						
				} 
				catch ( SQLException e ) {
						System.err.println("Could not establish connection.");
						out.println("1</BODY>");
				}
				catch ( ClassNotFoundException e ) {
						System.err.println("Could not load database driver.");
						out.println("2</BODY>");
				}

				finally {
						try{
							if (conn != null){
								conn.close();connn.close();
								}
						}
						catch (SQLException ignored)	{out.println("3</BODY>");	}
				}

	} 
}
