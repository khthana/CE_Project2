import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SessionTracker extends HttpServlet {

public void doGet(HttpServletRequest req, HttpServletResponse res)
throws ServletException, IOException {
String ListIDnew="";
String n="";
String x="name";
String cartoonName="";
int j=1;
HttpSession session = req.getSession(true);
cartoonName=req.getParameter("cartoonName");
for(j=1;j<99;j++){
x="c"+j;
n = req.getParameter(x);
if(!(n==null))
ListIDnew=ListIDnew+j+",";
}
String namess=(String)session.getValue("ListID");
if (namess == null)
namess = cartoonName+":"+ListIDnew+";";
else
namess = namess+cartoonName+":"+ListIDnew+";";
session.putValue("ListID",namess);
res.setContentType("text/html");
PrintWriter out = res.getWriter();
out.println("<HTML><HEAD><TITLE>BookSelect</TITLE></HEAD>");
out.println("<BODY><H1>Book in basket</H1><br>");
out.println(getBookList(namess));
out.println("<form method=get action=\"http://projecti.kmitl/jservlets/CheckOut\">");
out.println("<br><input type=submit value=\"Remove that select\">");
out.println("<input type=submit name=\"out\" value=\"Check out\">");
out.println("</form>");
out.println("</BODY></HTML>");
}
//-----------------------------------------------------
public String getBookList(String a) {
Book[] bookList=new Book[20];
    String b ="",nameTemp="",verTemp="";
    String listReturn="";
    int j=0;
    for(int i=1;i<=19;i++)
        bookList[i]=new Book();
		while(!(a.indexOf(";")==-1)){
        b=a.substring(0,a.indexOf(";")+1);
        a=a.substring(a.indexOf(";")+1);
        nameTemp=b.substring(0,b.indexOf(":"));
        b=b.substring(b.indexOf(":")+1);
        while(!(b.indexOf(",")==-1)){
          boolean already=false;
          for(int i=1;i<=19;i++){
              if(bookList[i].getName().equals(nameTemp)
                 &&bookList[i].getVer().equals(b.substring(0,b.indexOf(","))))
                 already=true;
          }
          if(!already){
             j++;
             bookList[j].setName(nameTemp);
             bookList[j].setVer(b.substring(0,b.indexOf(",")));
             listReturn=listReturn+"<input type=checkbox name=\"c"+j+"\">"+j+". "+bookList[j].getName()+"  version  "+bookList[j].getVer()+"<br>";
          }
          b=b.substring(b.indexOf(",")+1);
        }
    }
    return listReturn;
  }
}
//---------------------------Book Class--------------------------
class Book{
String name=" ",ver=" ";
      public void book(){
      }
      public String getName(){
             return name;
      }
      public String getVer(){
             return ver;
      }
      public void setName(String n){
             name=n;
      }
      public void setVer(String v){
             ver=v;
      }
}
