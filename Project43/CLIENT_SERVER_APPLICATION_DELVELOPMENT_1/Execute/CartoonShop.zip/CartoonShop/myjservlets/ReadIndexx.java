import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ReadIndexx extends HttpServlet {

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
			
			//Connection conn= null;
			//Statement  stmtt = null;
			//Statement  stmtx = null;
			//ResultSet  rss = null;
			//String st1 = "",st2 = "",st3="";
			//String user="x";
			//int sum = 0;

			res.setContentType("text/html");
			PrintWriter out = res.getWriter();

			HttpSession session = req.getSession(true);
						
						
			//out.println("<HTML><HEAD><TITLE>Read Detail</TITLE></HEAD>");
			//out.println("<BODY><H1>ReadDetail</H1>");

			//try
			//{
			//	Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
			//	conn = DriverManager.getConnection("jdbc:odbc:projdb","","");

				//conn.setAutoCommit(false);
			//	stmtt = conn.createStatement();
			//	stmtx = conn.createStatement();
				//rss = stmtt.executeQuery("select password from user where user = '"+user+"'");

				//String user = req.getParameter("textfield");
			    //String password =  req.getParameter("textfield2");

				//String put_user = "user";
				//String put_password = "password";
				
				//session.putValue(put_user,user);
				//session.putValue(put_password,password);

				out.println("<html>");
				out.println("<head>");
				out.println("<title>Untitled Document</title>");
				out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">");
				out.println("</head>");

				out.println("<H1><CENTER>Hello World</CENTER></H1>");
				//out.println("<frameset cols=\"144,639*\" frameborder=\"NO\" border=\"0\" framespacing=\"0\" rows=\"*\">"); 
				//out.println("  <frame name=\"leftFrame\" scrolling=\"NO\" noresize src=\"http://myproject/jservlets/ReadList\">");
				//out.println("  <frame name=\"mainFrame\" src=\"http://myproject/readdetail.html\">");
				//out.println("</frameset>");
				//out.println("<noframes><body bgcolor=\"#FFFFFF\">");

				out.println("</body></noframes>");
				out.println("</html>");

				
				//out.println("</BODY></HTML>");

			//}
			//catch ( SQLException e ) {
			//			System.err.println("Could not establish connection.");
			//			out.println("1</BODY>");
			//	}
			//	catch ( ClassNotFoundException e ) {
			//			System.err.println("Could not load database driver.");
			//			out.println("2</BODY>");
			//	}

			//	finally {
			//			try{
			//				if (conn != null)
			//					conn.close();
			//				}
			//			catch (SQLException ignored)	{out.println("3</BODY>");	}
			//	}
			
		}
}