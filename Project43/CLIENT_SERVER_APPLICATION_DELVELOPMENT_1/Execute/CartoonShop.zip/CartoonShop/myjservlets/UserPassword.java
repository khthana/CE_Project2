import java.util.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UserPassword extends HttpServlet {

		public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
			
			Connection conn= null;
			Statement  stmtt = null;
			Statement  stmtx = null;
			ResultSet  rss = null;
			String st1 = "",st2 = "",st3="",cradit="";
			java.util.Date d1 = new java.util.Date();			
			//System.currentTimeMillis()
			
			//int sum = 0;

			res.setContentType("text/html");
			PrintWriter out = res.getWriter();

			HttpSession session = req.getSession(true);
						
			String user = req.getParameter("textfield");
			String password =  req.getParameter("textfield2");
			String sum = req.getParameter("sum");
			
			

			out.println("<HTML><HEAD><TITLE>SessionTracker</TITLE></HEAD>");
			out.println("<BODY><H1>UserPassword</H1>");

			try
			{
				Class.forName ("sun.jdbc.odbc.JdbcOdbcDriver");
				if (conn != null)
							conn.close();
				
				conn = DriverManager.getConnection("jdbc:odbc:projdb","","");

				//conn.setAutoCommit(false);
				stmtt = conn.createStatement();
				stmtx = conn.createStatement();
				rss = stmtt.executeQuery("select password,cradit from user where user = '"+user+"'");
				if (rss.next()){
					if ((st1=rss.getString("password")).equals(password)){
							//out.println("Welcome " +user+ " to my store");
						cradit = rss.getString("cradit");
						int sum_int = Integer.parseInt(sum);
						int cradit_int = Integer.parseInt(cradit);
						if (sum_int<cradit_int)	{
							stmtx.executeUpdate("update user set cradit = cradit - "+sum+" where user = '"+user+"'");
							rss = stmtt.executeQuery("select id_book from read where user = '"+user+"'");
							while (rss.next())
							{
								String[] names = session.getValueNames();
								st2 = rss.getString("id_book");
				ok_point:for (int i=0;i < names.length ;i++ )
								{
									if (st2.equals(names[i]))													//mm/dd/yy	
									{
										stmtx.executeUpdate("update read set expire = '"+(d1.getTime()+(3*24*60*60*1000)+(8*60*60*1000))+"' where user = '"+user+"' and id_book = '"+st2+"'");
										session.removeValue(names[i]);
										break ok_point;
									}
								}
							}
							
							String[] namesxx = session.getValueNames();
							for (int i =0;i<namesxx.length ;i++ )
							{
								stmtx.executeUpdate("insert into read (id_book,user,expire,mark) values ('"+namesxx[i]+ "','"+user+"','"+(d1.getTime()+(3*24*60*60*1000)+(8*60*60*1000))+"','1')");
							}
							
							for (int i =0;i<namesxx.length ;i++ )
							{
								session.removeValue(namesxx[i]);
							}
							out.println("Record into your database OK");
							out.println("<BR>Do you want to read ?");
							///out.println("<BR>Sum = "+sum);
						
							out.println("<br><a href=\"http://myproject/TestRead.html\"target=\"_blank\">Read</a> ");
						}
						else {
							out.println("<h2>Sorry! Now your cradit is not enought.</h2>");
							out.println("<br>Your cradit is "+cradit+" ,but your total price is "+sum);
							out.println("<br><h3>You can select one of below </h3>");
							out.println("<br><a href=\"http://myproject/extend.html\" target=\"_blank\">1.Extend your cradit</a>");
							out.println("<br><a href=\"http://myproject/jservlets/SessionTracker\">2.Remove cartoon book from basket</a>");
						}

					}
					else 
							out.println("Sorry it's wrong password");
				}
				else
					out.println("No have user name <b>"+user+"</b> in my store");
				
				//conn.commit();
				out.println("</BODY></HTML>");

			}
			catch ( SQLException e ) {
						System.err.println("Could not establish connection.");
							out.println("<BR>"+d1.getTime());
						out.println("1</BODY>");
				}
				catch ( ClassNotFoundException e ) {
						System.err.println("Could not load database driver.");
						out.println("2</BODY>");
				}

				finally {
						try{
							if (conn != null)
								conn.close();
							}
						catch (SQLException ignored)	{out.println("3</BODY>");	}
				}
			
		}
}