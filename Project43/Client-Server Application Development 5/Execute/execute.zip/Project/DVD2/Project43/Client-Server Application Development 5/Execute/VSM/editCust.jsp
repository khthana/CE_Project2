<jsp:useBean id="rcObj" class="RetrieveCustomerTable" scope="session" />
<jsp:setProperty name="rcObj" property="*" />

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#99CCFF" text="#000000">
<% try{
	   Object obj=null;
	   HttpSession custSession = request.getSession(false);
	   if (custSession==null){
	   response.sendRedirect(response.encodeUrl("loginCust.jsp"));
	   }
	   obj =custSession.getValue("State");
	   if (obj==null){
	   response.sendRedirect(response.encodeUrl("loginCust.jsp"));
	   }
	   Vector State = (Vector)obj ;
	   String userName_Cus=(String)State.elementAt(2);
	   if (userName_Cus.equals("")){
	   response.sendRedirect(response.encodeUrl("loginCust.jsp"));
	   }
	   rcObj.selectByPrimaryKey(userName_Cus); 
	   }catch (Exception e){}
	%>
<div align="center"><font size="6"><b><font color="#339900">EDIT CUSTOMER PROFILE</font></b></font></div>
<form name="form1" method="get" action="editCustManage.jsp">
  <p>&nbsp;</p>
  <table width="100%" border="0">
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%"><font size="2" color="#6633FF">USERNAME :</font></td>
      <td width="51%"> <%= rcObj.getUserName_Cus() %> </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">PASSWORD</font></td>
      <td width="51%"> 
        <input type="password" name="password" value="<%= rcObj.getPassword() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">CONFIRM PASSWORD</font></td>
      <td width="51%"> 
        <input type="password" name="confirmPassword"value="<%= rcObj.getPassword() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%"><font color="#6633FF"></font></td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">NAME SURNAME</font></td>
      <td width="51%"> 
        <input type="text" name="name_Cus" value= "<%= rcObj.getName_Cus() %>" >
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">ADDRESS</font></td>
      <td width="51%"> 
        <input type="text" name="address" size="50" value="<%= rcObj.getAddress()%>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">AMPHUR</font></td>
      <td width="51%"> 
        <input type="text" name="amphur" value="<%= rcObj.getAmphur() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">CITY</font></td>
      <td width="51%"> 
        <input type="text" name="jungwat"value="<%= rcObj.getJungwat() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">POSTAL</font></td>
      <td width="51%"> 
        <input type="text" name="zip_Code" size="10" value="<%= rcObj.getZip_Code() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">TELEPHONE</font></td>
      <td width="51%"> 
        <input type="text" name="phone" value="<%= rcObj.getPhone() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">EMAIL</font></td>
      <td width="51%"> 
        <input type="text" name="email" size="24" value="<%= rcObj.getEmail() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF">ACCOUNTID</font></td>
      <td width="51%"> 
        <input type="text" name="bank_Code" value="<%= rcObj.getBank_Code() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%"><font color="#6633FF"></font></td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF"></font></td>
      <td width="51%"> 
        <input type="submit" name="Submit" value="UPDATE">
        <input type="reset" name="Submit2" value="CLEAR">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2" color="#6633FF"></font></td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
