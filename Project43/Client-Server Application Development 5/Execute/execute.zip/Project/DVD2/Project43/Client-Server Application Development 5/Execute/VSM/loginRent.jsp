<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<p align="center"><font size="6"><b><font color="#3366FF">LOGIN RENT</font></b></font></p>
<form name="form1" method="get" action = "loginRentAlias">
  <table width="75%" border="0" align="center">
    <tr> 
      <td width="16%">&nbsp;</td>
      <td width="28%"><b>USERNAME</b></td>
      <td width="40%"> 
        <input type="text" name="rent_ID">
      </td>
      <td width="16%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="16%">&nbsp;</td>
      <td width="28%"><b>PASSWORD</b></td>
      <td width="40%"> 
        <input type="password" name="password">
      </td>
      <td width="16%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="16%">&nbsp;</td>
      <td width="28%">&nbsp;</td>
      <td width="40%"> 
        <input type="submit" name="Submit" value="Login">
      </td>
      <td width="16%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="16%">&nbsp;</td>
      <td width="28%">New Rent</td>
      <td width="40%"><a href="registRent.jsp"><b><i>SIGN UP</i></b></a></td>
      <td width="16%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="16%">&nbsp;</td>
      <td width="28%">&nbsp;</td>
      <td width="40%">&nbsp;</td>
      <td width="16%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="16%">&nbsp;</td>
      <td width="28%">&nbsp;</td>
      <td width="40%">&nbsp;</td>
      <td width="16%">&nbsp;</td>
    </tr>
  </table>
</form>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
