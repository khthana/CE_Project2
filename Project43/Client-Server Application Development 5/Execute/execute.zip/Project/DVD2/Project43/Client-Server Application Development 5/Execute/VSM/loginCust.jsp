<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<div align="center">
  <p><font size="6"><b><font color="#3366FF">LOGIN CUSTOMER</font></b></font></p>
  <p>&nbsp;</p>
  <form name="form1" method="get" action="loginCustAlias">
    <table width="75%" border="0">
      <tr> 
        <td width="16%">&nbsp;</td>
        <td width="28%"><b>USERNAME</b></td>
        <td width="40%"> 
          <input type="text" name="userName_Cus">
        </td>
        <td width="16%">&nbsp;</td>
      </tr>
      <tr> 
        <td width="16%">&nbsp;</td>
        <td width="28%"><b>PASSWORD</b></td>
        <td width="40%"> 
          <input type="password" name="password">
        </td>
        <td width="16%">&nbsp;</td>
      </tr>
      <tr> 
        <td width="16%">&nbsp;</td>
        <td width="28%">&nbsp;</td>
        <td width="40%"> 
          <input type="submit" name="Submit" value="Login">
        </td>
        <td width="16%">&nbsp;</td>
      </tr>
      <tr> 
        <td width="16%">&nbsp;</td>
        <td width="28%">New Customer</td>
        <td width="40%"><a href="registCust.jsp"><b><i>SIGN UP</i></b></a></td>
        <td width="16%">&nbsp;</td>
      </tr>
      <tr> 
        <td width="16%">&nbsp;</td>
        <td width="28%">&nbsp;</td>
        <td width="40%">&nbsp;</td>
        <td width="16%">&nbsp;</td>
      </tr>
      <tr> 
        <td width="16%">&nbsp;</td>
        <td width="28%">&nbsp;</td>
        <td width="40%">&nbsp;</td>
        <td width="16%">&nbsp;</td>
      </tr>
    </table>
    <p></p>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
</body>
</html>
