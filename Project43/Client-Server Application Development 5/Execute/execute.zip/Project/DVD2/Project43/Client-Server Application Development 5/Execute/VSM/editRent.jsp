<jsp:useBean id="rrObj" class="RetrieveRentTable" scope="session" />
<jsp:setProperty name="rrObj" property="*" />

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#99CCFF" text="#000000">
<% try{
	   Object obj=null;
	   HttpSession rentSession = request.getSession(false);
	   if (rentSession==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   obj =rentSession.getValue("State");
	   if (obj==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   Vector State = (Vector)obj ;
	   String rent_ID=(String)State.elementAt(3);
	   if (rent_ID.equals("")){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   rrObj.selectByPrimaryKey(rent_ID); 
	   }catch (Exception e){}
	%>
<div align="center"><font size="6"><b><font color="#339900">EDIT RENT PROFILE</font></b></font></div>
<form name="form1" method="get" action="editRentManage.jsp">
  <p>&nbsp;</p>
  <table width="100%" border="0">
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%"><font size="2">USERNAME :</font></td>
      <td width="51%"> 
        <%= rrObj.getRent_ID() %>
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">PASSWORD</font></td>
      <td width="51%"> 
        <input type="password" name="password" value="<%= rrObj.getPassword() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">CONFIRM PASSWORD</font></td>
      <td width="51%"> 
        <input type="password" name="confirmPassword" value="<%= rrObj.getPassword() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr>
      <td width="14%">&nbsp;</td>
      <td width="22%">&nbsp;</td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%"><font size="2">RENT NAME</font></td>
      <td width="51%"> 
        <input type="text" name="name_Rent" value="<%= rrObj.getName_Rent() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">NAME SURNAME</font></td>
      <td width="51%"> 
        <input type="text" name="owner_Name" value="<%= rrObj.getOwner_Name() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">ADDRESS</font></td>
      <td width="51%"> 
        <input type="text" name="address" size="50" value="<%= rrObj.getAddress() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">AMPHUR</font></td>
      <td width="51%"> 
        <input type="text" name="amphur" value="<%= rrObj.getAmphur() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">CITY</font></td>
      <td width="51%"> 
        <input type="text" name="jungwat" value="<%= rrObj.getJungwat() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">POSTAL</font></td>
      <td width="51%"> 
        <input type="text" name="zip_Code" size="10" value="<%= rrObj.getZip_Code() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">TELEPHONE</font></td>
      <td width="51%"> 
        <input type="text" name="phone" value="<%= rrObj.getPhone() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">EMAIL</font></td>
      <td width="51%"> 
        <input type="text" name="email" size="24" value="<%= rrObj.getEmail() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">ACCOUNTID</font></td>
      <td width="51%"> 
        <input type="text" name="bank_Code" value="<%= rrObj.getBank_Code() %>">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%">ADD DBSPACE</td>
      <td width="51%"> 
        <input type="text" name="add_DbSpace" value="0">
        MB </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%">REMAIN DBSPACE</td>
      <td width="51%"> 
      <%= rrObj.getRent_DbSpace() %>
        MB </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%">&nbsp;</td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2"></font></td>
      <td width="51%"> 
        <input type="submit" name="Submit" value="UPDATE">
        <input type="reset" name="Submit2" value="CLEAR">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2"></font></td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
