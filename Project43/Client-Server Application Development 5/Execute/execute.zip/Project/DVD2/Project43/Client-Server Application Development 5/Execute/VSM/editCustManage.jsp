<jsp:useBean id="rcObj" class="RetrieveCustomerTable" scope="session" />
<jsp:setProperty name="rcObj" property="*" />
	
	<% 
	int zip_Code=0;
	long bank_Code=0;
	String password = request.getParameter("password");
	String name_Cus = request.getParameter("name_Cus");
	String address = request.getParameter("address");
	String amphur = request.getParameter("amphur");
	String jungwat = request.getParameter("jungwat");
	String zip_CodeText = request.getParameter("zip_Code");
	try{
	zip_Code= Integer.parseInt(zip_CodeText);
	}catch(Exception e1){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=POSTAL is Invalid&fileLink=editCust.jsp"));
	}
	String phone = request.getParameter("phone");
	String email = request.getParameter("email");
	String bank_CodeText = request.getParameter("bank_Code");
	try{
	bank_Code= Long.parseLong(bank_CodeText);
	}catch(Exception e2){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ACCOUNTID is Invalid&fileLink=editCust.jsp"));
	}
	
	if (password.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=PASSWORD is Empty&fileLink=editCust.jsp"));
	}else
	if (name_Cus.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=RENT NAME is Empty&fileLink=editCust.jsp"));
	}else
	if (address.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ADDRESS is Empty&fileLink=editCust.jsp"));
	}else
	if (amphur.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=AMPHUR is Empty&fileLink=editCust.jsp"));
	}else
	if (jungwat.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=CITY is Empty&fileLink=editCust.jsp"));
	}else
	if (zip_CodeText.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=POSTAL is Empty&fileLink=editCust.jsp"));
	}else
	if (phone.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=TELEPHONE is  Empty&fileLink=editCust.jsp"));
	}else
	if (email.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=EMAIL is Empty&fileLink=editCust.jsp"));
	}else
	if (bank_CodeText.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ACCOUNTID is Empty&fileLink=editCust.jsp"));
	}else{
	rcObj.setPassword(password);
	rcObj.setName_Cus(name_Cus);
	rcObj.setAddress(address);
	rcObj.setAmphur(amphur );
	rcObj.setJungwat(jungwat);
	rcObj.setZip_Code(zip_Code);
	rcObj.setPhone(phone);
	rcObj.setEmail(email);
	rcObj.setBank_Code(bank_Code);
	response.sendRedirect(response.encodeUrl("p1.jsp"));
	}
	%>
