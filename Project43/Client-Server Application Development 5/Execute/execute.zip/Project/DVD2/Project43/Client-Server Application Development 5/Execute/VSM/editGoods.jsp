<jsp:useBean id="rdObj" class="RetrieveDeptTable" scope="session" />
<jsp:setProperty name="rdObj" property="*" />
<html>
<head>
<title>Rent Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#FFFFFF" text="#000000">
	<% String rent_ID=null;
	   try{
	   Object obj=null;
	   HttpSession rentSession = request.getSession(false);
	   if (rentSession==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   obj =rentSession.getValue("State");
	   if (obj==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   Vector State = (Vector)obj ;
	   rent_ID=(String)State.elementAt(3);
	   if (rent_ID.equals("")){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   rdObj.selectByRent_ID(rent_ID); 
	   }catch (Exception e){}
	%>
<table width="100%" border="0">
  <tr> 
    <td width="33%"><font size="4"><b>Function :</b></font></td>
    <td width="67%"> 
      <div align="center"><font size="7"><%= rent_ID%></font></div>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><a href="editRent.jsp"><i>Edit Rent Profile</i></a></li>
      </ul>
    </td>
    <td rowspan="5" valign="top"> 
      <div align="left"> 
        <p>&nbsp; </p>
        <p>SELECT DEPART</p>
        <form name="form1" method="get" action="editDeptManage.jsp">
		  <table width="100%" border="0">
            <tr>
          <% while(!rdObj.isEnd() ){ 
	   		String dept_Name=rdObj.getDept_Name();
		  %>
		  <tr>
          <td width="76%"><a href="EditGAlias?Action=1&P=Edit&Dept=<%=dept_Name %>"> <%=dept_Name %></a> </td>
          <td width="24%"><a href="AddGAlias?Dept=<%=dept_Name %>">ADD GOODS</a></td>  
		  </tr>
			<% }//for %>
          <p>&nbsp;
            
          </table>
        </form>
        <p>&nbsp;</p>
      </div>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><i><a href="editDept.jsp">Edit DepartMent</a></i></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><i><a href="editGoods.jsp">Edit Goods Detail</a></i></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><i><a href="PurchaseAlias">View Order</a></i></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height="82" width="33%">&nbsp;</td>
  </tr>
</table>
</body>
</html>
