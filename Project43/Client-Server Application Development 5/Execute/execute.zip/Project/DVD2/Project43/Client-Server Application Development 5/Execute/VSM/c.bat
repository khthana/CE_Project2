@Echo off
javac  bankPack\BankInterface.java bankPack\BankImplement.java bankPack\BankHome.java
javac  bPack\BInterface.java bPack\BImplement.java bPack\BHome.java
javac  buyPack\BuyInterface.java buyPack\BuyImplement.java buyPack\BuyHome.java buyPack\Pk_BuyTable.java
javac  CPack\CInterface.java CPack\CImplement.java CPack\CHome.java
javac  customerPack\CustomerInterface.java customerPack\CustomerImplement.java customerPack\CustomerHome.java
javac  deptPack\DeptInterface.java deptPack\DeptImplement.java deptPack\DeptHome.java deptPack\Pk_DeptTable.java
javac  GPack\GInterface.java GPack\GImplement.java GPack\GHome.java
javac  rentPack\RentInterface.java rentPack\RentImplement.java rentPack\RentHome.java
javac -classpath %CPATH% *.java