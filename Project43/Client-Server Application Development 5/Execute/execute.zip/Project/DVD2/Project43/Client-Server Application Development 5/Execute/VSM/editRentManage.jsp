<jsp:useBean id="rrObj" class="RetrieveRentTable" scope="session" />
<jsp:setProperty name="rrObj" property="*" />
	
	<% 
	int zip_Code=0;
	long bank_Code=0;
	float add_DbSpace=0;
	String password = request.getParameter("password");
	String name_Rent = request.getParameter("name_Rent");
	String owner_Name = request.getParameter("owner_Name");
	String address = request.getParameter("address");
	String amphur = request.getParameter("amphur");
	String jungwat = request.getParameter("jungwat");
	String zip_CodeText = request.getParameter("zip_Code");
	float remain_DbSpace=rrObj.getRent_DbSpace();
	try{
	zip_Code= Integer.parseInt(zip_CodeText);
	}catch(Exception e1){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=POSTAL is Invalid&fileLink=editRent.jsp"));
	}
	String phone = request.getParameter("phone");
	String email = request.getParameter("email");
	String bank_CodeText = request.getParameter("bank_Code");
	try{
	bank_Code= Long.parseLong(bank_CodeText);
	}catch(Exception e2){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ACCOUNTID is Invalid&fileLink=editRent.jsp"));
	}
	String add_DbSpaceText = request.getParameter("add_DbSpace");
	try{
	add_DbSpace= Float.parseFloat(add_DbSpaceText);
	if (remain_DbSpace+add_DbSpace<0 ) {
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ADD DBSPACE is Invalid&fileLink=editRent.jsp"));
	}
	}catch(Exception e2){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=SIZE OF DBSPACE is Invalid&fileLink=editRent.jsp"));
	}

	if (password.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=PASSWORD is Empty&fileLink=editRent.jsp"));
	}else
	if (name_Rent.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=RENT NAME is Empty&fileLink=editRent.jsp"));
	}else
	if (owner_Name.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=NAME SURNAME is_Empty&fileLink=editRentt.jsp"));
	}else
	if (address.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ADDRESS is Empty&fileLink=editRent.jsp"));
	}else
	if (amphur.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=AMPHUR is Empty&fileLink=editRent.jsp"));
	}else
	if (jungwat.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=CITY is Empty&fileLink=editRent.jsp"));
	}else
	if (zip_CodeText.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=POSTAL is Empty&fileLink=editRent.jsp"));
	}else
	if (phone.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=TELEPHONE is  Empty&fileLink=editRent.jsp"));
	}else
	if (email.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=EMAIL is Empty&fileLink=editRent.jsp"));
	}else
	if (bank_CodeText.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=ACCOUNTID is Empty&fileLink=editRent.jsp"));
	}else
	if (add_DbSpaceText.length()==0){
	response.sendRedirect(response.encodeUrl("displayError.jsp?type=SIZE OF DBSPACE is Empty&fileLink=editRent.jsp"));
	}else{
	float t=0;
		t=50*add_DbSpace;
	float rental=rrObj.getRental();
	rental =rental+t;
	rrObj.setRental(rental);

	rrObj.setPassword(password);
	rrObj.setName_Rent(name_Rent);
	rrObj.setOwner_Name(owner_Name );
	rrObj.setAddress(address);
	rrObj.setAmphur(amphur );
	rrObj.setJungwat(jungwat);
	rrObj.setZip_Code(zip_Code);
	rrObj.setPhone(phone);
	rrObj.setEmail(email);
	rrObj.setBank_Code(bank_Code);
	float rent_DbSpace=remain_DbSpace+add_DbSpace;
	rrObj.setRent_DbSpace( rent_DbSpace);
	response.sendRedirect(response.encodeUrl("p2.jsp"));
	}
	%>
