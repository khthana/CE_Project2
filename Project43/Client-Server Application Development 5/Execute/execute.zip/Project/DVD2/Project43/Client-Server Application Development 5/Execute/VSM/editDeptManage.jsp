<jsp:useBean id="rdObj" class="RetrieveDeptTable" scope="session" />
<jsp:setProperty name="rdObj" property="*" />
<jsp:useBean id="rgObj" class="RetrieveGoodsTable" scope="session" />
<jsp:setProperty name="rgObj" property="*" />
<jsp:useBean id="rbObj" class="RetrieveBuyTable" scope="session" />
<jsp:setProperty name="rbObj" property="*" />

<%@ page import="java.util.Enumeration" %>
<%@ page import = "doTransaction" %>
	<% String rent_ID=null;
	   try{
	   Object obj=null;
	   HttpSession rentSession = request.getSession(false);
	   if (rentSession==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   obj =rentSession.getValue("State");
	   if (obj==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   Vector State = (Vector)obj ;
	   rent_ID=(String)State.elementAt(3);
	   if (rent_ID.equals("")){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   rdObj.selectByRent_ID(rent_ID); 
	   }catch (Exception e){}
	   Enumeration para=request.getParameterNames();

	   while(para.hasMoreElements()) {
	   String para_Name=(String)para.nextElement();
	   String para_Value = (String)request.getParameter(para_Name);
	   rdObj.genPK(rent_ID,para_Name);
	   rdObj.selectByPrimaryKey();
	   
	   if ( para_Value.equals("") ){
	   //delete department
		doTransaction dt = new doTransaction();
		if (!dt.deletedept(para_Name,rent_ID)){
		response.sendRedirect(response.encodeUrl("displayError.jsp?type=DATABASE ERROR&fileLink=editDeptManage.jsp"));
		}
	   }//if dept =""
	   else if (!para_Name.equals("Submit")){
   		doTransaction dt = new doTransaction();
		if(!dt.updatedept(para_Name,para_Value,rent_ID)){
		response.sendRedirect(response.encodeUrl("displayError.jsp?type=DATABASE ERROR&fileLink=editDeptManage.jsp"));
		}
	   }//else para_name != submit
	   }//while hasMoreElement
	   response.sendRedirect(response.encodeUrl("p2.jsp"));
	%>