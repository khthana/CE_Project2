<jsp:useBean id="rdObj" class="RetrieveDeptTable" scope="session" />
<jsp:setProperty name="rdObj" property="*" />
<jsp:useBean id="rgObj" class="RetrieveGoodsTable" scope="session" />
<jsp:setProperty name="rgObj" property="*" />
<jsp:useBean id="rrObj" class="RetrieveRentTable" scope="session" />
<jsp:setProperty name="rrObj" property="*" />


<html>
<head>
<title>DEPART NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

	<% 
	   String dept_Name=request.getParameter("dept_Name");
	   String displayDept_Name = dept_Name;
	   String rent_ID = request.getParameter("rent_ID");
	   rdObj.selectByRent_ID(rent_ID);
	   if (dept_Name.equals("promotion")){
	   displayDept_Name=rent_ID;
	   rgObj.selectGoodsPromotion(rent_ID);
	   }
   	   else {
	   rgObj.selectByDept_NameAndRent_ID(dept_Name,rent_ID);
	   }
	%>

<body bgcolor="#FFFFFF" text="#000000" background="pic/backDept.jpg">
<table width="99%" border="0" height="226">
  <tr> 
    <td rowspan="2" height="53" width="36%" valign=top> 
   <p><a href="p1.jsp"><font size="2">Home</font></a> <font size="2"><a href="loginCust.jsp">Login</a> 
        <a href="editCust.jsp"> Edit Profile</a> <a href="GoodSearch.htm">AdvanceSearch</a></font><br>
        <font size="2"><a href="ReAlias">View Reserve Goods</a> <a href="SearchAlias?Action=1&P=View">View 
        Cart</a></font> </p>
      <p>&nbsp;</p>
      <p><font size="5"><b>DEPARTMENT LIST</b></font></p>
      <% while(!rdObj.isEnd() ){ 
	   dept_Name=rdObj.getDept_Name();
	%>
      <ul>
        <li><a href="showShop_GoodsList.jsp?dept_Name=<%= dept_Name %>&rent_ID=<%= rent_ID %>"><%= dept_Name %></a></li>
      </ul>
      <% }//for %>
      <p>&nbsp;</p>
     <p><font size="5"><b>SHOP LIST</b></font></p>
      <% String name_Rent=null;
         rrObj.selectAll(); %>
      <form name="form1">
        <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
		<option selected>SELECT SHOP</option>
          <% while(!rrObj.isEnd() ){ 
	   rrObj.nextElement();
	   rent_ID=rrObj.getRent_ID();
	%>
          <option value="showShop_GoodsList.jsp?rent_ID=<%= rent_ID %>&dept_Name=promotion"><%= rrObj.getName_Rent() %></option>
          <% }//while %>
        </select>
      </form>	  
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </td>
    <td width="64%" height="68" valign=MIDDLE > 
      <p align="center"><font color="#FF0000"><b><font size="6" color="#0066FF"><%= displayDept_Name %> </font></b></font></p>
      <div align="left"></div>
    </td>
  </tr>
  <tr> 
    <td width="64%" height="452" valign=top> 
      <p><font color="#000000"> 
        <% while(!rgObj.isEnd() ){ 
	   rgObj.nextElement();
	%>
        </font> </p>
      <ul>
           <li><font size="3"><b><i>GOODS ID :</i></b><a href ="DetailAlias?ID=<%= rgObj.getId_goods() %>"> 
          <%=rgObj.getId_goods()%></a>
		  <br></font><font size="3" color="#CC33FF"><i>DETAIL :</i></font><font size="3"><%=rgObj.getDetail()%></font></li>
        <br><font size="3" color="#CC33FF"><i>COST :</i></font><font size="3"><%=rgObj.getCost()%></font> 
          <font size="3" color="#CC33FF"><i>REMAIN AMOUNT :</i></font><font size="3"><%=rgObj.getCount()%></font> 
          <br><font size="3" color="#CC33FF"><i>RENT ID :</i></font><font size="3"><%=rgObj.getRent_ID()%></font> 
          <br><font size="3" color="#CC33FF"><i>DEPART NAME :</i></font><font size="3"><%=rgObj.getDept_Name()%></font>
        <br> <font size="3" color="#CC33FF"><i>DESCRIPTION :</i></font><font size="3"><%=rgObj.getOther()%></font> 
      </ul>
      <% }//while %>
    </td>
  </tr>
</table>
</body>
</html>
