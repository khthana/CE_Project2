<jsp:useBean id="rrObj" class="RetrieveRentTable" scope="session" />
<jsp:setProperty name="rrObj" property="*" />

<html>
<head>
<title>Rent Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#FFFFEE" text="#000000">
<% String rent_ID=null;
	   try{
	   Object obj=null;
	   HttpSession rentSession = request.getSession(false);
	   if (rentSession==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   obj =rentSession.getValue("State");
	   if (obj==null){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   Vector State = (Vector)obj ;
	   rent_ID=(String)State.elementAt(3);
	   if (rent_ID.equals("")){
	   response.sendRedirect(response.encodeUrl("loginRent.jsp"));
	   }
	   rrObj.selectByPrimaryKey(rent_ID); 
	   }catch (Exception e){}
	%>
<table width="100%" border="0">
  <tr> 
    <td width="33%"><font size="4"><b>Function :</b></font></td>
    <td width="67%"> 
      <div align="center"><font size="7"><%= rent_ID %></font></div>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><a href="editRent.jsp"><i>Edit Rent Profile</i></a></li>
      </ul>
    </td>
    <td rowspan="5" valign="top"> 
      <div align="left"> 
        <p><b>RENT DETAIL</b><b></b><i><b> </b></i></p>
        <p>USERNAME :<b> <%= rrObj.getRent_ID() %></b></p>
        <p>RENT NAME : <%= rrObj.getName_Rent() %></p>
        <p>NAME SURNAME : <%= rrObj.getOwner_Name() %></p>
        <p>ADDRESS : <%= rrObj.getAddress() %></p>
        <p>AMPHUR : <%= rrObj.getAmphur() %></p>
        <p>CITY : <%= rrObj.getJungwat() %></p>
        <p>POSTAL : <%= rrObj.getZip_Code() %></p>
        <p>TELEPHONE : <%= rrObj.getPhone() %></p>
        <p>EMAIL : <%= rrObj.getEmail() %></p>
        <p>ACCOUNTID : <%= rrObj.getBank_Code() %></p>
        <p>RENTAL :<%= rrObj.getRental() %></p>
        <p>PAY DATE : <%= rrObj.getDate_Pay() %></p>
        <p>LATE COUNT : <%= rrObj.getCount_Late() %></p>
        <p>SIZE OF DBSPACE : <%= rrObj.getRent_DbSpace() %></p>
      </div>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><i><a href="editDept.jsp">Edit DepartMent</a></i></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><i><a href="editGoods.jsp">Edit Goods Detail</a></i></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td width="33%" height="82"> 
      <p>&nbsp;</p>
      <ul>
        <li><i><a href="PurchaseAlias">View Order</a></i></li>
      </ul>
    </td>
  </tr>
  <tr> 
    <td height="82" width="33%">&nbsp;</td>
  </tr>
</table>
</body>
</html>
