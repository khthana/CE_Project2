<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<div align="center"><font size="6"><b><font color="#339900">CUSTOMER REGISTATION</font></b></font></div>
<form name="form1" method="get" action="registCustAlias">
  <p>&nbsp;</p>
  <table width="100%" border="0">
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%"><font size="2">USERNAME</font></td>
      <td width="51%"> 
        <input type="text" name="userName_Cus">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">PASSWORD</font></td>
      <td width="51%"> 
        <input type="password" name="password">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">CONFIRM PASSWORD</font></td>
      <td width="51%"> 
        <input type="password" name="confirmPassword">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%">&nbsp;</td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">NAME SURNAME</font></td>
      <td width="51%"> 
        <input type="text" name="name_Cus">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">ADDRESS</font></td>
      <td width="51%"> 
        <input type="text" name="address" size="50">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">AMPHUR</font></td>
      <td width="51%"> 
        <input type="text" name="amphur">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">CITY</font></td>
      <td width="51%"> 
        <input type="text" name="jungwat">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">POSTAL</font></td>
      <td width="51%"> 
        <input type="text" name="zip_Code" size="10">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">TELEPHONE</font></td>
      <td width="51%"> 
        <input type="text" name="phone">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">EMAIL</font></td>
      <td width="51%"> 
        <input type="text" name="email" size="24">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2">ACCOUNTID</font></td>
      <td width="51%"> 
        <input type="text" name="bank_Code">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%">&nbsp;</td>
      <td width="22%">&nbsp;</td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2"></font></td>
      <td width="51%"> 
        <input type="submit" name="Submit" value="REGISTER">
        <input type="reset" name="Submit2" value="CLEAR">
      </td>
      <td width="13%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="14%"><font color="#66CCFF"></font></td>
      <td width="22%"><font size="2"></font></td>
      <td width="51%">&nbsp;</td>
      <td width="13%">&nbsp;</td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
