<jsp:useBean id="rbObj" class="RetrieveBuyTable" scope="session" />
<jsp:setProperty name="rbObj" property="*" />
