<% String errorType =request.getParameter("type");
   String fileLink  =request.getParameter("fileLink");
 %>
<html>
<head><title>DISPLAY ERROR</title></head>
<body bgcolor="#CCFFFF">
<P>&nbsp;
<P align="center"><font size="6" color="#FF6600"><b>ERROR :</b><%= errorType %> 
  </font> 
<P align="center">&nbsp;
<P align="center"><a href=<%= fileLink %>>Try Again </a> 
</body>
</html>