@echo off
set java_home=d:\jdk1.3
set j2ee_home=d:\j2sdkee1.2.1
set path=%java_home%\bin;%j2ee_home%\bin;
set classpath=%j2ee_home%\lib\j2ee.jar;%java_home%\lib\tools.jar;%java_home%\lib\dt.jar;%j2ee_home%\lib\system\classes12.zip;d:\VSM
set CPATH=%j2ee_home%\lib\j2ee.jar;%j2ee_home%\lib\system\classes12.zip;d:\VSM

