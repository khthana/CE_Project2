@echo off
set CPATH=d:\j2sdkee1.2.1\lib\j2ee.jar;d:\j2sdkee1.2.1\lib\system\classes12.zip;%1
javac -classpath %CPATH% E?Servlet.java
javac -classpath %CPATH% EServlet.java
javac -classpath %CPATH% R*Servlet.java
javac -classpath %CPATH% B*Servlet.java
javac -classpath %CPATH% G*Servlet.java
javac -classpath %CPATH% DServlet.java
javac doTransaction.java