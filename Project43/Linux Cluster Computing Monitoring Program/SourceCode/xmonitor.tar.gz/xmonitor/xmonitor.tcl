#!/bin/sh
# the next line restarts using wish\
exec wish "$0" "$@" 
if {![info exist vTcl(sourcing)]} {

}


############################
# vTcl Code to Load Stock Images


if {![info exist vTcl(sourcing)]} {
proc vTcl:rename {name} {
    regsub -all "\\." $name "_" ret
    regsub -all "\\-" $ret "_" ret
    regsub -all " " $ret "_" ret
    regsub -all "/" $ret "__" ret
    regsub -all "::" $ret "__" ret

    return [string tolower $ret]
}

proc vTcl:image:create_new_image {filename description type data} {
    global vTcl env

    # Does the image already exist?
    if {[info exists vTcl(images,files)]} {
	if {[lsearch -exact $vTcl(images,files) $filename] > -1} { return }
    }

    if {![info exists vTcl(sourcing)] && [string length $data] > 0} {
	set object [image create  [vTcl:image:get_creation_type $filename]  -data $data]
    } else {
        # Wait a minute... Does the file actually exist?
        if {! [file exists $filename] } {
            # Try current directory
            set script [file dirname [info script]]
            set filename [file join $script [file tail $filename] ]
        }

        if {![file exists $filename]} {
            set description "file not found!"
            set object [image create photo -data [vTcl:image:broken_image] ]
        } else {
            set object [image create  [vTcl:image:get_creation_type $filename]  -file $filename]
        }
    }

    set reference [vTcl:rename $filename]

    set vTcl(images,$reference,image)       $object
    set vTcl(images,$reference,description) $description
    set vTcl(images,$reference,type)        $type
    set vTcl(images,filename,$object)       $filename

    lappend vTcl(images,files) $filename
    lappend vTcl(images,$type) $object

    # return image name in case caller might want it
    return $object
}

proc vTcl:image:get_image {filename} {
    global vTcl
    set reference [vTcl:rename $filename]

    # Let's do some checking first
    if {![info exists vTcl(images,$reference,image)]} {
	# Well, the path may be wrong; in that case check
	# only the filename instead, without the path.

	set imageTail [file tail $filename]

	foreach oneFile $vTcl(images,files) {
	    if {[file tail $oneFile] == $imageTail} {
		set reference [vTcl:rename $oneFile]
		break
	    }
	}
    }
    return $vTcl(images,$reference,image)
}

proc vTcl:image:get_creation_type {filename} {
    set ext [file extension $filename]
    set ext [string tolower $ext]

    switch $ext {
	.ppm -
	.gif    {return photo}
	.xbm    {return bitmap}
	default {return photo}
    }
}

proc vTcl:image:broken_image {} {
    return {
        R0lGODdhFAAUAPcAAAAAAIAAAACAAICAAAAAgIAAgACAgMDAwICAgP8AAAD/
        AP//AAAA//8A/wD//////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAACwAAAAAFAAUAAAIhAAPCBxIsKDBgwgPAljIUOBC
        BAkBPJg4UeBEBBAVPkCI4EHGghIHChAwsKNHgyEPCFBA0mFDkBtVjiz4AADK
        mAds0tRJMCVBBkAl8hwYMsFPBwyE3jzQwKhAoASUwmTagCjDmksbVDWIderC
        g1174gQ71CHFigfOhrXKUGfbrwnjyp0bEAA7
    }
}

foreach img {


            } {
    vTcl:image:create_new_image\
        [lindex $img 0] [lindex $img 1] [lindex $img 2] [lindex $img 3]
}

}
############################
# vTcl Code to Load User Images

foreach img {

        {/home/red/vtcl-1.5.1b2/background/config.ppm {user image} user {}}
        {/home/red/vtcl-1.5.1b2/background/over.ppm {user image} user {}}
        {/home/red/vtcl-1.5.1b2/background/cpu.ppm {user image} user {}}
        {/home/red/vtcl-1.5.1b2/background/mem.ppm {user image} user {}}
        {/home/red/vtcl-1.5.1b2/background/task.ppm {user image} user {}}

            } {
    vTcl:image:create_new_image\
        [lindex $img 0] [lindex $img 1] [lindex $img 2] [lindex $img 3]
}

############################
# vTcl Code to Load Stock Fonts


if {![info exist vTcl(sourcing)]} {
set vTcl(fonts,counter) 0
proc vTcl:font:add_font {font_descr font_type newkey} {
     global vTcl

     incr vTcl(fonts,counter)
     set newfont [eval font create $font_descr]

     lappend vTcl(fonts,objects) $newfont

     # each font has its unique key so that when a project is
     # reloaded, the key is used to find the font description

     if {$newkey == ""} {
          set newkey vTcl:font$vTcl(fonts,counter)
     }

     set vTcl(fonts,$newfont,type)                      $font_type
     set vTcl(fonts,$newfont,key)                       $newkey
     set vTcl(fonts,$vTcl(fonts,$newfont,key),object)   $newfont

     lappend vTcl(fonts,$font_type) $newfont

     # in case caller needs it
     return $newfont
}

proc vTcl:font:get_font {key} {
    global vTcl
    return $vTcl(fonts,$key,object)
}

vTcl:font:add_font \
    "-family helvetica -size 12 -weight normal -slant roman -underline 0 -overstrike 0" \
    stock \
    vTcl:font1
}
############################
# vTcl Code to Load User Fonts

vTcl:font:add_font \
    "-family helvetica -size 10 -weight normal -slant roman -underline 0 -overstrike 0" \
    user \
    vTcl:font11
#############################################################################
# Visual Tcl v1.51 Project
#

#################################
# VTCL LIBRARY PROCEDURES
#

proc Window {args} {
    global vTcl
    set cmd [lindex $args 0]
    set name [lindex $args 1]
    set newname [lindex $args 2]
    set rest [lrange $args 3 end]
    if {$name == "" || $cmd == ""} {return}
    if {$newname == ""} {
        set newname $name
    }
    if {$name == "."} { wm withdraw $name; return }
    set exists [winfo exists $newname]
    switch $cmd {
        show {
	    if {$exists} { wm deiconify $name; return }
            if {[info procs vTclWindow(pre)$name] != ""} {
                eval "vTclWindow(pre)$name $newname $rest"
            }
            if {[info procs vTclWindow$name] != ""} {
                eval "vTclWindow$name $newname $rest"
            }
            if {[info procs vTclWindow(post)$name] != ""} {
                eval "vTclWindow(post)$name $newname $rest"
            }
        }
        hide    { if $exists {wm withdraw $newname; return} }
        iconify { if $exists {wm iconify $newname; return} }
        destroy { if $exists {destroy $newname; return} }
    }
}

if {![info exists vTcl(sourcing)]} {
namespace eval ::progressbar {

proc {::progressbar::Build} {w args} {
variable widgetOptions
  variable widgetGlobals

  if {$widgetGlobals(debug)} {
    puts stderr "pb_Build '$w' '$args'"
  }

  # create the namespace for this instance, and define a few
  # variables
  namespace eval ::progressbar::$w {
    variable options
    variable widgets
    variable info
  }

  # this gives us access to the namespace variables within
  # this proc
  upvar ::progressbar::${w}::widgets widgets
  upvar ::progressbar::${w}::options options
  upvar ::progressbar::${w}::info info

  set info(rgb) ""
  set info(rgbHasChanged) 0

  # this is our widget -- a frame of class Progressbar. Naturally,
  # it will contain other widgets. We create it here because
  # we need it to be able to set our default options.
  set widgets(this) [frame $w -class Progressbar1]

  # this defines all of the default options. We get the
  # values from the option database. Note that if an array
  # value is a list of length one it is an alias to another
  # option, so we just ignore it
  foreach name [array names widgetOptions] {
    if {[llength $widgetOptions($name)] == 1} continue
    set optName  [lindex $widgetOptions($name) 0]
    set optClass [lindex $widgetOptions($name) 1]
    set options($name) [option get $w $optName $optClass]
    if {$widgetGlobals(debug) > 1} {
      puts stderr "pb_Build:Opt '$w' '$optName' '$optClass' '$options($name)'"
    }
  }

  # now apply any of the options supplied on the command
  # line. This may overwrite our defaults, which is OK
  if {[llength $args] > 0} {
    array set options $args
  }
  
  # this will only set the name of canvas's widget, we will
  # later create the canvas in our drawing procedure.
  set widgets(canvas) $w.pb

  # we will later rename the frame's widget proc to be our
  # own custom widget proc. We need to keep track of this
  # new name, so we'll define and store it here...
  set widgets(frame) ::progressbar::${w}::$w

  # this moves the original frame widget proc into our
  # namespace and gives it a handy name
  rename ::$w $widgets(frame)

  # Alias the window to our WidgetProc and pass the window name.
  interp alias {} ::$w {} ::progressbar::WidgetProc $w

  # ok, the thing exists... let's do a bit more configuration. 
  if {[catch "Configure $widgets(this) [array get options]" error]} {
    return -code error $error
    catch {destroy $w}
  }

  return $w
}

}

namespace eval ::progressbar {

proc {::progressbar::Canonize} {w object opt} {
variable widgetOptions
  variable widgetCommands
  variable widgetGlobals
  variable widgetShapes

  if {$widgetGlobals(debug)} {
    puts stderr "pb_Canonize '$w' '$object' '$opt'"
  }

  switch $object {
    command {
      if {[lsearch -exact $widgetCommands $opt] >= 0} {
	return $opt
      }

      # command names aren't stored in an array, and there
      # isn't a way to get all the matches in a list, so
      # we'll stuff the columns in a temporary array so
      # we can use [array names]
      set list $widgetCommands
      foreach element $list {
	set tmp($element) ""
      }
      set matches [array names tmp ${opt}*]
    }

    option {
      if {[info exists widgetOptions($opt)]  && [llength $widgetOptions($opt)] == 3} {
	return $opt
      }
      set list [array names widgetOptions]
      set matches [array names widgetOptions ${opt}*]
    }

    shape {
      if {[lsearch -exact $widgetShapes $opt] >= 0} {
	return $opt
      }

      # same procedure as command
      set list $widgetShapes
      foreach element $list {
	set tmp($element) ""
      }
      set matches [array names tmp ${opt}*]
    }
  }
  if {[llength $matches] == 0} {
    set choices [HumanizeList $list]
    return -code error "unknown $object \"$opt\"; must be one of $choices"
  } elseif {[llength $matches] == 1} {
    # deal with option aliases
    set opt [lindex $matches 0]
    switch $object {
      option {
	if {[llength $widgetOptions($opt)] == 1} {
	  set opt $widgetOptions($opt)
	}
      }
    }
    return $opt
  } else {
      set choices [HumanizeList $list]
      return -code error "ambiguous $object \"$opt\"; must be one of $choices"
  }
}

}

namespace eval ::progressbar {

proc {::progressbar::Configure} {w args} {
variable widgetOptions
  variable widgetGlobals

  if {$widgetGlobals(debug)} {
    puts stderr "pb_Configure '$w' '$args'"
  }

  upvar ${w}::widgets widgets
  upvar ${w}::options options
  upvar ${w}::info info
  
  if {[llength $args] == 0} {
    # hmmm. User must be wanting all configuration information
    # note that if the value of an array element is of length
    # one it is an alias, which needs to be handled slightly
    # differently
    set results {}
    foreach opt [lsort [array names widgetOptions]] {
      if {[llength $widgetOptions($opt)] == 1} {
	set alias $widgetOptions($opt)
	set optName $widgetOptions($alias)
	lappend results [list $opt $optName]
      } else {
	set optName  [lindex $widgetOptions($opt) 0]
	set optClass [lindex $widgetOptions($opt) 1]
	set default [option get $w $optName $optClass]
	lappend results [list $opt $optName $optClass $default $options($opt)]
      }
    }
    return $results
  }
  
  # one argument means we are looking for configuration
  # information on a single option
  if {[llength $args] == 1} {
    set opt [Canonize $w option [lindex $args 0]]
    set optName  [lindex $widgetOptions($opt) 0]
    set optClass [lindex $widgetOptions($opt) 1]
    set default [option get $w $optName $optClass]
    set results [list $opt $optName $optClass $default $options($opt)]
    return $results
  }

  # if we have an odd number of values, bail. 
  if {[expr {[llength $args]%2}] == 1} {
    # hmmm. An odd number of elements in args
    return -code error "value for \"[lindex $args end]\" missing"
  }
  
  # Great. An even number of options. Let's make sure they 
  # are all valid before we do anything. Note that Canonize
  # will generate an error if it finds a bogus option; otherwise
  # it returns the canonical option name
  foreach {name value} $args {
    set name [Canonize $w option $name]
    set opts($name) $value
  }

  # process all of the configuration options
  foreach option [array names opts] {
    set newValue $opts($option)
    if {[info exists options($option)]} {
      set oldValue $options($option)
    }

    if {$widgetGlobals(debug) > 2} {
      puts stderr "pb_Configure:Opt '$option' n='$newValue' o='$oldValue'"
    }
    switch -- $option {
      -background  -
      -borderwidth -
      -relief      {
	if {[winfo exists $widgets(this)]} {
	  $widgets(frame) configure $option $newValue
	  set options($option) [$widgets(frame) cget $option]
	}
      }
      -color {
        switch -- $newValue {
	  @blue0    -
	  @blue1    -
	  @blue2    -
	  @blue3    -
	  @blue4    -
	  @green0   -
	  @green1   -
	  @green2   -
	  @green3   -
	  @yellow0  -
	  @yellow1  -
	  @red0     -
	  @red1     -
	  @magenta0 -
	  @brown0   -
	  @brown1   -
	  @gray0    {
	    set info(rgb) $widgetGlobals($newValue)
	  }
	  @* {
	    set info(rgb) $widgetGlobals(@saphir)
	  }
	  default {
	    set info(rgb) [RGBs $newValue]
	  }
	}
	set info(rgbHasChanged) 1
      }
      -percent {
	set options($option) $newValue
      }
      -shape {
	set options($option) [Canonize $w shape $newValue]
	set info(rgbHasChanged) 1
      }
      -variable {
	# hmmm .. are there any traces left? Yes! Destroy!
	if {[info procs Trace($w)] != ""} {
	  uplevel #0 trace vdelete $oldValue wu ::progressbar::Trace($w)
	  unset widgetGlobals($w)
	  rename Trace($w) {}
	}
	if {$newValue != ""} {
	  # there is a new variable to trace. build a new proc to trace it.
	  proc ::progressbar::Trace($w) {name1 name2 op} "
	    variable widgetGlobals

	    if {\$widgetGlobals(debug)} {
	      puts stderr \"pb_Trace($w) '\$name1' '\$name2' '\$op'\"
	    }
	    switch -- \$op {
	      w {
		if {\$name2 != \"\"} {
		  upvar 1 \${name1}(\$name2) var
		  catch {$w configure -percent \$var}
		} else {
		  upvar 1 \$name1 var
		  catch {$w configure -percent \$var}
		}
	      }
	      u {
		if {\[info procs Trace($w)\] != \"\"} {  unset widgetGlobals($w);  rename Trace($w) {};  }
	      }
	    }
	  "
	  # install trace proc for variable
	  uplevel #0 trace variable $newValue wu ::progressbar::Trace($w)
	}
	set options($option) $newValue
	set widgetGlobals($w) $newValue
      }
      -width {
	if {$newValue < 20} {
	  return -code error "a -width of less than 20 is not supported."
	}
	if {[winfo exists $widgets(canvas)]} {
	  $widgets(canvas) configure $option $newValue
	  set options($option) [$widgets(canvas) cget $option]
	} else {
          set options($option) $newValue
	}
      }
      -textvalue {
        set options($option) $newValue
	if {![winfo exists $widgets(canvas)]} { continue }
	$widgets(canvas) itemconfigure ttxt -text $newValue
      }
      -textcolor {
        set options($option) $newValue
	if {![winfo exists $widgets(canvas)]} { continue }
	$widgets(canvas) itemconfigure ttxt -fill $newValue
      }
    }
  }

  Draw $w
}

}

namespace eval ::progressbar {

proc {::progressbar::DestroyHandler} {w} {
variable widgetGlobals

  if {$widgetGlobals(debug)} {
    puts stderr "pb_DestroyHandler '$w'"
  }

  # hmmm .. are there any traces left? Yes! Destroy!
  if {[info procs Trace($w)] != ""} {
    uplevel 1 trace vdelete $widgetGlobals($w) wu ::progressbar::Trace($w)
    unset widgetGlobals($w)
    rename Trace($w) {}
  }

  # if the widget actually being destroyed is of class Progressbar,
  # crush the namespace and kill the proc. Get it? Crush. Kill. 
  # Destroy. Heh. Danger Will Robinson! Oh, man! I'm so funny it
  # brings tears to my eyes.
  if {[string compare [winfo class $w] "Progressbar1"] == 0} {
    namespace delete ::progressbar::$w
    rename $w {}
  }
}

}

namespace eval ::progressbar {

proc {::progressbar::Draw} {w} {
variable widgetGlobals

  if {$widgetGlobals(debug) > 2} {
    puts stderr "pb_Draw '$w'"
  }

  upvar ${w}::widgets widgets
  upvar ${w}::options options
  upvar ${w}::info info

  set width   $options(-width)
  set percent $options(-percent)
  set text    $options(-textvalue)

  if {$options(-shape) == "flat"} {
    set minDisplay 0
    if {[llength $info(rgb)] == 7} {
      set rgb(0) [lindex $info(rgb) 6]
    } else {
      set rgb(0) [lindex $info(rgb) 2]
    }
    set rgb(1) $rgb(0)
    set rgb(2) $rgb(0)
    set rgb(3) $rgb(0)
    set rgb(4) $rgb(0)
    set rgb(5) $rgb(0)
  } else {
    set minDisplay 7
    set rgb(0) [lindex $info(rgb) 0]
    set rgb(1) [lindex $info(rgb) 1]
    set rgb(2) [lindex $info(rgb) 2]
    set rgb(3) [lindex $info(rgb) 3]
    set rgb(4) [lindex $info(rgb) 4]
    set rgb(5) [lindex $info(rgb) 5]
  }

  if {$percent < 0} {
    set percent 0
  } elseif {$percent > 100} {
    set percent 100
  }
  if {$percent == 0} {
    set mark $minDisplay
  } else {
    set mark [expr (($width - $minDisplay) / 100.0 * $percent) + $minDisplay]
  }

  if {![winfo exists $widgets(canvas)]} {
    canvas $widgets(canvas) -width $width -height 14 -bd 0 -highlightthickness 0
    pack $widgets(canvas) -side left -anchor nw -fill both

    foreach {type color tag coords opts} $widgetGlobals(toDraw) {
      eval $widgets(canvas) create $type $coords -fill $color -tag t$tag $opts
    }

    set info(rgbHasChanged) 0
    # nothing more to do
    return
  }

  foreach {type color tag coords opts} $widgetGlobals(toDraw) {
    eval $widgets(canvas) coords t$tag $coords
    if {$info(rgbHasChanged)} {
      eval $widgets(canvas) itemconfigure t$tag -fill $color
    }
  }
  set info(rgbHasChanged) 0
}

}

namespace eval ::progressbar {

proc {::progressbar::HumanizeList} {list} {
variable widgetGlobals

  if {$widgetGlobals(debug)} {
    puts stderr "pb_HumanizeList $list"
  }

  if {[llength $list] == 1} {
    return [lindex $list 0]
  } else {
    set list [lsort $list]
    set secondToLast [expr {[llength $list] -2}]
    set most [lrange $list 0 $secondToLast]
    set last [lindex $list end]

    return "[join $most {, }] or $last"
  }
}

}

namespace eval ::progressbar {

proc {::progressbar::Init} {} {
variable widgetOptions
  variable widgetCommands
  variable widgetGlobals
  variable widgetShapes

  if {$widgetGlobals(debug)} {
    puts stderr "pb_Init"
  }

  # here we match up command line options with option database names
  # and classes. As it turns out, this is a handy reference of all of the
  # available options. Note that if an item has a value with only one
  # item (like -bd, for example) it is a synonym and the value is the
  # actual item.

  array set widgetOptions {
    -background		{background	Background	}
    -borderwidth	{borderWidth	BorderWidth	}
    -color		{color		Color		}
    -cursor		{cursor		Cursor		}
    -percent		{percent	Percent		}
    -relief		{relief		Relief		}
    -shape		{shape		Shape		}
    -variable		{variable	Variable	}
    -width		{width		Width		}
    -textvalue		{textValue	TextValue	}
    -textcolor		{textColor	TextColor	}

    -bg			-background
    -bd			-borderwidth
    -pc			-percent
  } 

  # this defines the valid widget commands. It's important to
  # list them here; we use this list to validate commands and
  # expand abbreviations.

  set widgetCommands {
      cget
      configure
      incr
      step
  }

  # this defines the valid shape options. It's important to
  # list them here; we use this list to validate options and
  # expand abbreviations.

  set widgetShapes {
      3D
      3d
      flat
  }
      
  set widgetGlobals(toDraw) {
    rect #bdbdbd es0 {[expr $mark +3] 2 [expr $width -2] 11} {-outline ""}
    line #525252 es1 {[expr $mark +1] 2 [expr $mark +1] 11} {}
    line #8c8c8c es2 {[expr $mark +2] 11 [expr $mark +2] 2  [expr $width -4] 2} {}
    line #8c8c8c es3 {[expr $mark +3] 11 [expr $width -3] 11  [expr $width -3] 3} {}
    line $rgb(0) pb0 {4 11 [expr $mark -1] 11 [expr $mark -1] 3} {}
    line $rgb(1) pb1 {3 11 3 10 [expr $mark -2] 10 [expr $mark -2] 2  [expr $mark -1] 2 4 2} {}
    line $rgb(2) pb2 {3 2 2 2 2 11 2 10 3 10 3 9 [expr $mark -3] 9  [expr $mark -3] 3 [expr $mark -2] 3 4 3} {}
    line $rgb(3) pb3 {3 3 3 9 3 8 [expr $mark -3] 8 [expr $mark -3] 4 4 4} {}
    line $rgb(4) pb4 {3 4 3 8 3 7 [expr $mark -3] 7 [expr $mark -3] 5 4 5} {}
    line $rgb(5) pb5 {3 5 3 7 3 6 [expr $mark -3] 6} {}
    line #000000 mrk {$mark 1 $mark 12} {}
    line #adadad fr0 {0 12 0 0 [expr $width -1] 0} {}
    line #ffffff fr1 {1 13 [expr $width -1] 13 [expr $width -1] 1} {}
    line #000000 fr2 {1 1 [expr $width -2] 1 [expr $width -2] 12 1 12 1 1} {}
    text #000000 txt {[expr $width / 2] 8} {-text $text}
  }

  set widgetGlobals(@blue0) {#000052 #0031ce #3163ff #639cff #9cceff #efefef}
  set widgetGlobals(@blue1) {#000021 #00639c #009cce #00ceff #63ffff #ceffff}
  set widgetGlobals(@blue2) {#000052 #31319c #6363ce #9c9cff #ceceff #efefef}
  set widgetGlobals(@blue3)	 {#21214a #52527b #63639c #8484bd #b5b5ef #ceceff}
  set widgetGlobals(@blue4) {#29396b #4a6b9c #6384b5 #739cd6 #94b5ef #adceff}
  set widgetGlobals(@green0)	 {#003131 #08736b #318c94 #5abdad #63dece #ceffef}
  set widgetGlobals(@green1) {#001000 #003100 #316331 #639c63 #9cce9c #ceffce}
  set widgetGlobals(@green2) {#002100 #006331 #319c63 #31ce63 #63ff9c #ceffce}
  set widgetGlobals(@green3) {#003131 #316363 #427b7b #639c9c #9ccece #bdefef}
  set widgetGlobals(@yellow0) {#101010 #636300 #9c9c00 #cece00 #ffff00 #ffff9c}
  set widgetGlobals(@yellow1) {#8c7321 #cead39 #e7c642 #f7de63 #f7de63 #ffffe7}
  set widgetGlobals(@red0) {#420000 #9c0000 #ce3131 #ff6363 #ff9c9c #ffcece}
  set widgetGlobals(@red1) {#210000 #9c3100 #ce6331 #ff9c63 #ffce9c #ffffce}
  set widgetGlobals(@magenta0) {#210000 #630063 #9c319c #ce63ce #ff9cff #ffceff}
  set widgetGlobals(@brown0) {#210000 #633100 #9c6331 #ce9c63 #efb573 #ffdeb5}
  set widgetGlobals(@brown1) {#310000 #7b4242 #9c6363 #ce9c9c #efcece #ffdede}
  set widgetGlobals(@gray0) {#212121 #525252 #737373 #adadad #cecece #efefef}

  # this initializes the option database. Kinda gross, but it works
  # (I think).
  set tmpWidget ".__tmp__"

  # steal some options from frame widgets; we only want a subset
  # so we'll use a slightly different method. No harm in *not*
  # adding in the one or two that we don't use... :-)
  label $tmpWidget
  foreach option [list Background Relief] {
    set values [$tmpWidget configure -[string tolower $option]]
    option add *Progressbar1.$option [lindex $values 3]
  }
  destroy $tmpWidget

  # these are unique to us...
  option add *Progressbar1.borderWidth	5		widgetDefault
  option add *Progressbar1.color	@blue0		widgetDefault
  option add *Progressbar1.percent	0		widgetDefault
  option add *Progressbar1.shape	3D		widgetDefault
  option add *Progressbar1.variable	{}		widgetDefault
  option add *Progressbar1.width	180		widgetDefault
  option add *Progressbar1.textColor	black		widgetDefault

  # define the class bindings
  # this allows us to clean up some things when we go away
  bind Progressbar1 <Destroy> [list ::progressbar::DestroyHandler %W]
}

}

namespace eval ::progressbar {

proc {::progressbar::RGBs} {color} {
variable widgetGlobals

  if {$widgetGlobals(debug)} {
    puts stderr "pb_RGB '$color'"
  }

  # get rgb values of given color
  set color [winfo rgb . $color]

  set R [expr int([lindex $color 0] / 256)]
  set G [expr int([lindex $color 1] / 256)]
  set B [expr int([lindex $color 2] / 256)]

  set rgb {}
  foreach factor {0.13 0.32 0.45 0.68 0.8 0.93} {
    set r [expr int($R * $factor)]
    set g [expr int($G * $factor)]
    set b [expr int($B * $factor)]
    lappend rgb [format "#%02x%02x%02x" $r $g $b]
  }
  lappend rgb [format "#%02x%02x%02x" $R $G $B]

  return $rgb
}

}

namespace eval ::progressbar {

proc {::progressbar::WidgetProc} {w args} {
variable widgetOptions
  variable widgetGlobals

  if {[llength $args] == 0} {
      return -code error [vTcl:WrongNumArgs "$w option ?arg arg ...?"]
  }

  set command [lindex $args 0]
  set args [lrange $args 1 end]

  if {$widgetGlobals(debug)} {
    puts stderr "pb_WidgetProc '$w' '$command' '$args'"
  }

  upvar ::progressbar::${w}::widgets   widgets
  upvar ::progressbar::${w}::options   options
  upvar ::progressbar::${w}::info info

  set command [Canonize $w command $command]

  set result ""

  switch $command {
    cget {
      if {[llength $args] != 1} {
	return -code error "wrong # args: should be $w cget option"
      }
      set opt [Canonize $w option [lindex $args 0]]
      set result $options($opt)
    }

    configure {
      set result [eval Configure {$w} $args]
    }

    incr -
    step {
      set val 1
      if {[llength $args] > 1} {
      	return -code error "wrong # args: should be $w $command <incrValue>"
      } elseif {[llength $args] == 1} {
      	set val $args
      }
      set percent [$w cget -percent]
      set result [eval Configure $w -percent [expr $percent + $val]]
    }

    default {
	return -code error "bad option \"$command\": must be cget or configure"
    }
  }
  return $result
}

}

namespace eval ::progressbar {

proc {::progressbar::progressbar} {args} {
variable widgetOptions
  variable widgetGlobals

  # perform a one time initialization
  if {![info exists widgetOptions]} {
    __progressbar_Setup
    Init
  }

  if {$widgetGlobals(debug)} {
    puts stderr "pb_progressbar '$args'"
  }

  # make sure we at least have a widget name
  if {[llength $args] == 0} {
    return -code error  "wrong # args: should be \"progressbar pathName ?options?\""
  }

  # ... and make sure a widget doesn't already exist by that name
  if {[winfo exists [lindex $args 0]]} {
    return -code error "window name \"[lindex $args 0]\" already exists"
  }

  # and check that all of the args are valid
  foreach {name value} [lrange $args 1 end] {
    Canonize [lindex $args 0] option $name
  }

  # build it...
  set w [eval Build $args]

  # and we are done!
  return $w
}

}

proc {__progressbar_Setup} {} {
namespace eval ::progressbar {
    # this is the public interface
    namespace export progressbar

    # these contain references to available options
    variable widgetOptions

    # these contain references to available commands
    variable widgetCommands

    # these contain references to available options for shape option
    variable widgetShapes

    # these contain references to global variables
    variable widgetGlobals

    set widgetGlobals(debug) 0
  }
}

proc {vTcl:Toplevel:WidgetProc} {w args} {
if {[llength $args] == 0} {
    	return -code error [vTcl:WrongNumArgs "$w option ?arg arg ...?"]
    }

    ## The first argument is a switch, they must be doing a configure.
    if {[string index $args 0] == "-"} {
    	set command configure

	## There's only one argument, must be a cget.
	if {[llength $args] == 1} {
	    set command cget
	}
    } else {
    	set command [lindex $args 0]
	set args [lrange $args 1 end]
    }

    switch -- $command {
	"hide" -
	"Hide" {
	    Window hide $w
	}

	"show" -
	"Show" {
	    Window show $w
	}

	"ShowModal" {
	    Window show $w
          raise $w
	    grab $w
	    tkwait window $w
	    grab release $w
	}

    	default {
	    eval $w $command $args
	}
    }
}

proc {vTcl:WidgetProc} {w args} {
if {[llength $args] == 0} {
    	return -code error "wrong # args: should be \"$w option ?arg arg ...?\""
    }

    ## The first argument is a switch, they must be doing a configure.
    if {[string index $args 0] == "-"} {
    	set command configure

	## There's only one argument, must be a cget.
	if {[llength $args] == 1} {
	    set command cget
	}
    } else {
    	set command [lindex $args 0]
	set args [lrange $args 1 end]
    }

    eval $w $command $args
}
}

proc vTcl:project:info {} {
    namespace eval ::widgets::.top21 {
        array set save {-cursor 1}
    }
    namespace eval ::widgets::.top21.can21 {
        array set save {-borderwidth 1 -closeenough 1 -cursor 1 -height 1 -width 1}
    }
    namespace eval ::widgets::.top21.can21.but21 {
        array set save {-borderwidth 1 -command 1 -height 1 -highlightthickness 1 -image 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.can21.but22 {
        array set save {-borderwidth 1 -command 1 -height 1 -highlightthickness 1 -image 1 -width 1}
    }
    namespace eval ::widgets::.top21.can21.but23 {
        array set save {-borderwidth 1 -command 1 -height 1 -highlightthickness 1 -image 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.can21.but24 {
        array set save {-borderwidth 1 -command 1 -height 1 -highlightthickness 1 -image 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.can21.but25 {
        array set save {-borderwidth 1 -command 1 -height 1 -highlightthickness 1 -image 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.can21.mes21 {
        array set save {-background 1 -font 1 -foreground 1 -padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.but22 {
        array set save {-borderwidth 1 -command 1 -font 1 -text 1}
    }
    namespace eval ::widgets::.top21.fra24 {
        array set save {-borderwidth 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.scr25 {
        array set save {-command 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21 {
        array set save {-borderwidth 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.mes24 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.lis26 {
        array set save {-height 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.ent30 {
        array set save {-borderwidth 1 -highlightthickness 1 -textvariable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.ent31 {
        array set save {-borderwidth 1 -highlightthickness 1 -textvariable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.ent32 {
        array set save {-borderwidth 1 -highlightthickness 1 -textvariable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.mes33 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.mes34 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.mes35 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.but36 {
        array set save {-command 1 -foreground 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.but38 {
        array set save {-command 1 -foreground 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.but39 {
        array set save {-command 1 -foreground 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.mes41 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.but21 {
        array set save {-command 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.but22 {
        array set save {-command 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra21.but23 {
        array set save {-command 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22 {
        array set save {-borderwidth 1 -cursor 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.mes23 {
        array set save {-foreground 1 -padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.ent24 {
        array set save {-cursor 1 -highlightthickness 1 -textvariable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.mes25 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.che28 {
        array set save {-cursor 1 -text 1 -variable 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.che29 {
        array set save {-text 1 -textvariable 1 -variable 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.but30 {
        array set save {-command 1 -text 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.but31 {
        array set save {-command 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.scr33 {
        array set save {-command 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.scr34 {
        array set save {-command 1 -orient 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.mes35 {
        array set save {-cursor 1 -padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.ent36 {
        array set save {-highlightthickness 1 -textvariable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.lis53 {
        array set save {-height 1 -width 1 -xscrollcommand 1 -yscrollcommand 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.che55 {
        array set save {-cursor 1 -height 1 -text 1 -variable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.mes56 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra22.but21 {
        array set save {-command 1 -height 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37 {
        array set save {-borderwidth 1 -cursor 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes38 {
        array set save {-foreground 1 -padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes39 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes40 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes41 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes42 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.can49 {
        array set save {-borderwidth 1 -closeenough 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.can50 {
        array set save {-borderwidth 1 -closeenough 1 -cursor 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.pro54 {
        array set save {-shape 1 -textcolor 1 -variable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.pro22 {
        array set save {-variable 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes23 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra37.mes24 {
        array set save {-padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra23 {
        array set save {-borderwidth 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra23.scr25 {
        array set save {-command 1 -cursor 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra23.can21 {
        array set save {-borderwidth 1 -closeenough 1 -cursor 1 -height 1 -relief 1 -width 1 -yscrollcommand 1}
    }
    namespace eval ::widgets::.top21.fra24.fra23.can21.pro22 {
        array set save {-width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra23.scr21 {
        array set save {-command 1 -cursor 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra24 {
        array set save {-borderwidth 1 -cursor 1 -height 1 -relief 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra24.scr25 {
        array set save {-command 1 -cursor 1 -width 1}
    }
    namespace eval ::widgets::.top21.fra24.fra24.mes21 {
        array set save {-foreground 1 -padx 1 -pady 1 -text 1 -width 1}
    }
    namespace eval ::widgets_bindings {
        set tagslist {}
    }
}

#################################
# USER DEFINED PROCEDURES
#

proc {config} {} {
global widget
global ListOfHosts
global IP_Address
global Domain_Name
global Alias

.top21.fra24.fra21.but38 configure -state disabled
.top21.fra24.fra21.but39 configure -state disabled
.top21.fra24.fra21.ent30 configure -state disabled
.top21.fra24.fra21.ent31 configure -state disabled
.top21.fra24.fra21.ent32 configure -state disabled
.top21.fra24.fra21.ent30 configure -borderwidth 0
.top21.fra24.fra21.ent31 configure -borderwidth 0
.top21.fra24.fra21.ent32 configure -borderwidth 0



place forget .top21.fra24.fra22
place forget .top21.fra24.fra23
place forget .top21.fra24.fra37
place forget .top21.fra24.fra24
place forget .top21.fra24.mc123
place forget .top21.fra24.scr25
place forget .top21.but22
place .top21.fra24.fra21 -x 9 -y 9 -width 350 -height 335 -anchor nw -bordermode ignore

.top21.fra24.fra21.lis26 delete 0 end
foreach host $ListOfHosts {
    .top21.fra24.fra21.lis26 insert end $host
    }
.top21.fra24.fra21.lis26 insert end ""



set IP_Address ""
set Domain_Name ""
set Alias ""

.top21.fra24.fra21.but38 configure -state disabled
.top21.fra24.fra21.but39 configure -state disabled
place forget .top21.fra24.fra21.but21
place forget .top21.fra24.fra21.but22
place forget .top21.fra24.fra21.but23
place .top21.fra24.fra21.but36 -x 280 -y 45 -width 50 -height 26 -anchor nw -bordermode ignore 
place .top21.fra24.fra21.but38 -x 279 -y 85 -width 52 -height 26 -anchor nw -bordermode ignore 
place .top21.fra24.fra21.but39 -x 279 -y 126 -width 52 -height 26 -anchor nw -bordermode ignore
}

proc {config_add} {} {
global widget
global IP_Address
global Domain_Name
global Alias


.top21.fra24.fra21.ent30 configure -state normal -borderwidth 2
.top21.fra24.fra21.ent31 configure -state normal -borderwidth 2
.top21.fra24.fra21.ent32 configure -state normal -borderwidth 2

set IP_Address ""
set Domain_Name ""
set Alias ""
.top21.fra24.fra21.lis26 selection clear 0 end

place forget .top21.fra24.fra21.but36
place forget .top21.fra24.fra21.but38
place forget .top21.fra24.fra21.but39



place .top21.fra24.fra21.but21 -x 225 -y 45 -width 50 -height 26 -anchor nw -bordermode ignore 
place .top21.fra24.fra21.but22 -x 225 -y 80 -width 50 -height 26 -anchor nw -bordermode ignore 


.top21.fra24.fra21.but21 configure -state normal
.top21.fra24.fra21.but22 configure -state normal
}

proc {config_cancel} {} {
global widget
global IP_Address
global Domain_Name
global Alias





#place forget .top21.fra24.fra21.but21
#place forget .top21.fra24.fra21.but22
#place .top21.fra24.fra21.but36 -x 280 -y 45 -width 50 -height 26 -anchor nw -bordermode ignore 
#place .top21.fra24.fra21.but38 -x 279 -y 85 -width 52 -height 26 -anchor nw -bordermode ignore 
#place .top21.fra24.fra21.but39 -x 279 -y 126 -width 52 -height 26 -anchor nw -bordermode ignore 

#.top21.fra24.fra21.ent30 configure -state normal -borderwidth 0
#.top21.fra24.fra21.ent31 configure -state normal -borderwidth 0
#.top21.fra24.fra21.ent32 configure -state normal -borderwidth 0
#.top21.fra24.fra21.ent30 configure -state disabled
#.top21.fra24.fra21.ent31 configure -state disabled
#.top21.fra24.fra21.ent32 configure -state disabled
#.top21.fra24.fra21.but38 configure -state disabled
#.top21.fra24.fra21.but39 configure -state disabled



#set IP_Address ""
#set Domain_Name ""
#set Alias ""

config
}

proc {config_delete} {} {
global widget
global ListOfHosts
global IP_Address
global Domain_Name
global Alias

if { ($IP_Address != "") && ($Domain_Name != "") && ($Alias != "") } {
set Hosts_File [exec cat /etc/hosts]
set Index 0
set Cursor 0
set Select_Cursor [.top21.fra24.fra21.lis26 curselection]

set tab "    "

exec echo -n [lindex $Hosts_File $Index] > /etc/hosts
exec echo -n $tab >> /etc/hosts
incr Index
exec echo -n [lindex $Hosts_File $Index] >> /etc/hosts
exec echo -n $tab >> /etc/hosts
incr Index
exec echo [lindex $Hosts_File $Index] >> /etc/hosts
incr Index

while {$Index < [llength $Hosts_File]} {
    if {$Select_Cursor == $Cursor} {
#        exec echo -n $IP_Address >> /etc/hosts
        } else {
        exec echo -n [lindex $Hosts_File $Index] >> /etc/hosts
        exec echo -n $tab >> /etc/hosts
        }
    incr Index
    
    if {$Select_Cursor == $Cursor} {
#        exec echo -n $Domain_Name >> /etc/hosts
        } else {
        exec echo -n [lindex $Hosts_File $Index] >> /etc/hosts
        exec echo -n $tab >> /etc/hosts
        }
    incr Index
    
    if {$Select_Cursor == $Cursor} {
#        exec echo $Alias >> /etc/hosts
        } else {
        exec echo [lindex $Hosts_File $Index] >> /etc/hosts
        }
    incr Index
    incr Cursor    
    }


set ListOfHosts [lreplace $ListOfHosts $Select_Cursor $Select_Cursor]
exec echo -n $ListOfHosts > xmonitor.conf

config
.top21.fra24.fra21.lis26 selection set $Select_Cursor $Select_Cursor
config_select
}
}

proc {config_edit} {} {
global widget

place forget .top21.fra24.fra21.but36
place forget .top21.fra24.fra21.but38
place forget .top21.fra24.fra21.but39

place .top21.fra24.fra21.but23 -x 225 -y 45 -width 50 -height 26 -anchor nw -bordermode ignore 
place .top21.fra24.fra21.but22 -x 225 -y 80 -width 50 -height 26 -anchor nw -bordermode ignore 


.top21.fra24.fra21.ent30 configure -state normal -borderwidth 2
.top21.fra24.fra21.ent31 configure -state normal -borderwidth 2
.top21.fra24.fra21.ent32 configure -state normal -borderwidth 2

.top21.fra24.fra21.but23 configure -state normal
.top21.fra24.fra21.but22 configure -state normal
}

proc {config_ok} {} {
global widget
global ListOfHosts
global IP_Address
global Domain_Name
global Alias

if {($IP_Address != "") && ($Domain_Name != "") && ($Alias != "")} {




set ListOfHosts [linsert $ListOfHosts end $Alias]
exec echo $ListOfHosts > xmonitor.conf


set Hosts_File [exec cat /etc/hosts]
set Index 0
set flag 0
set tab "    "

while {$Index <= [llength Hosts_File]} {
    if {$IP_Address == [lindex $Hosts_File $Index]} {
        set flag 1
        }
    if {$Domain_Name == [lindex $Hosts_File $Index]} {
        set flag 1
        }
    if {$Alias == [lindex $Hosts_File $Index]} {
        set flag 1
        }
    incr Index
    }


if {$flag == 0} {
    exec echo -n $IP_Address$tab >> /etc/hosts
    exec echo -n $Domain_Name$tab >> /etc/hosts
    exec echo $Alias >> /etc/hosts
    }

config
}
}

proc {config_select} {} {
global widget
global ListOfHosts
global IP_Address
global Domain_Name
global Alias


place forget .top21.fra24.fra21.but21
place forget .top21.fra24.fra21.but22
place forget .top21.fra24.fra21.but23
place .top21.fra24.fra21.but36 -x 280 -y 45 -width 50 -height 26 -anchor nw -bordermode ignore 
place .top21.fra24.fra21.but38 -x 279 -y 85 -width 52 -height 26 -anchor nw -bordermode ignore 
place .top21.fra24.fra21.but39 -x 279 -y 126 -width 52 -height 26 -anchor nw -bordermode ignore 


.top21.fra24.fra21.but38 configure -state normal
.top21.fra24.fra21.but39 configure -state normal

.top21.fra24.fra21.ent30 configure -state normal -borderwidth 0
.top21.fra24.fra21.ent31 configure -state normal -borderwidth 0
.top21.fra24.fra21.ent32 configure -state normal -borderwidth 0
.top21.fra24.fra21.ent30 configure -state disabled
.top21.fra24.fra21.ent31 configure -state disabled
.top21.fra24.fra21.ent32 configure -state disabled




set Select_Cursor [.top21.fra24.fra21.lis26 curselection]
set Select_Item [.top21.fra24.fra21.lis26 get $Select_Cursor]


set Hosts_File [exec cat /etc/hosts]
set Index 0

while {$Index < [llength $Hosts_File]} {
    set IP_Address [lindex $Hosts_File $Index]
    incr Index
    set Domain_Name [lindex $Hosts_File $Index]
    incr Index
    set Alias [lindex $Hosts_File $Index]
    incr Index
    if { $Alias == $Select_Item } {
        set Index [llength $Hosts_File]
        }
    }


if {$Select_Item != $Alias} {
    .top21.fra24.fra21.but39 configure -state disabled
    set IP_Address ""
    set Domain_Name ""
    set Alias ""
    }
if {$Select_Item == ""} {
    .top21.fra24.fra21.lis26 selection clear 0 end
    .top21.fra24.fra21.but38 configure -state disabled
    }
}

proc {config_update} {} {
global widget
global ListOfHosts
global IP_Address
global Domain_Name
global Alias

if { ($IP_Address != "") && ($Domain_Name != "") && ($Alias != "") } {
set Hosts_File [exec cat /etc/hosts]
set Index 0
set Cursor 0
set Select_Cursor [.top21.fra24.fra21.lis26 curselection]

set tab "    "

exec echo -n [lindex $Hosts_File $Index] > /etc/hosts
exec echo -n $tab >> /etc/hosts
incr Index
exec echo -n [lindex $Hosts_File $Index] >> /etc/hosts
exec echo -n $tab >> /etc/hosts
incr Index
exec echo [lindex $Hosts_File $Index] >> /etc/hosts
incr Index

while {$Index < [llength $Hosts_File]} {
    if {$Select_Cursor == $Cursor} {
        exec echo -n $IP_Address >> /etc/hosts
        } else {
        exec echo -n [lindex $Hosts_File $Index] >> /etc/hosts
        }
    exec echo -n $tab >> /etc/hosts
    incr Index
    
    if {$Select_Cursor == $Cursor} {
        exec echo -n $Domain_Name >> /etc/hosts
        } else {
        exec echo -n [lindex $Hosts_File $Index] >> /etc/hosts
        }
    exec echo -n $tab >> /etc/hosts
    incr Index
    
    if {$Select_Cursor == $Cursor} {
        exec echo $Alias >> /etc/hosts
        } else {
        exec echo [lindex $Hosts_File $Index] >> /etc/hosts
        }
    incr Index
    incr Cursor    
    }


set ListOfHosts [lreplace $ListOfHosts $Select_Cursor $Select_Cursor $Alias]
exec echo -n $ListOfHosts > xmonitor.conf

config
.top21.fra24.fra21.lis26 selection set $Select_Cursor $Select_Cursor
config_select

}
}

proc {cpu} {} {
global widget
global ListOfHosts


place forget .top21.fra24.fra22
place forget .top21.fra24.fra24
place forget .top21.fra24.fra37
place forget .top21.fra24.mc123
place forget .top21.fra24.scr25
place forget .top21.but22

place .top21.fra24.fra23 -x 10 -y 12 -width 520 -height 335 -anchor nw -bordermode ignore
place .top21.fra24.fra23.mc123 -x 10 -y 17 -width 237 -height 295
.top21.fra24.fra23.mc123 delete 0 end


set i 5
foreach host $ListOfHosts {
    set cpuinfo [exec rsh -n $host cat /proc/cpuinfo]
    set cpu_name [lrange $cpuinfo 16 17]
    set xxx [lsearch $cpuinfo MHz]
    incr xxx 2
    set cpu_clock [lindex $cpuinfo $xxx]
    set xxx [string length $cpu_clock]
    incr xxx -8
    set cpu_clock [string range $cpu_clock 0 $xxx]
    .top21.fra24.fra23.mc123 insert end [list $host $cpu_name $cpu_clock]
    
    place .top21.fra24.fra23.can21.$host -x 10 -y $i -width 60 -height 22 -anchor nw -bordermode ignore
    incr i 20
    place .top21.fra24.fra23.can21.pro$host -x 10 -y $i -width 90 -height 24 -anchor nw -bordermode ignore 
    incr i -9
    place .top21.fra24.fra23.can21.can$host -x 105 -y $i -width 106 -height 28 -anchor nw -bordermode ignore 
    incr i 41
    }
cpu_update
}

proc {cpu_update} {} {
global widget
global ListOfHosts
foreach host $ListOfHosts {
    global load$host
    }

foreach host $ListOfHosts {
    set upTime [exec rsh -n $host /usr/bin/uptime]
    if  {[lindex $upTime 3] == "min,"} {
    set upTime [lreplace $upTime 3 3]
    }

    set Load [lindex $upTime 7]
    set Load [string trimright $Load ',']
    set Load [string trimleft $Load '0']
    set Load [string trimleft $Load '.']
    set load$host $Load
    exec echo $Load >> cpu$host
    set xyz [exec cat cpu$host]
    set i 5
    foreach yyy $xyz {
        set peak 24
        set zzz [string trimleft $yyy '0']
        if {$zzz == ""} {
            set zzz 0
            }
        set aaa $zzz        
        incr zzz $aaa
        incr zzz $aaa
        if {[string length $zzz] == 3} {
            set zzz [string range $zzz 0 1]
            } else {
                    if {[string length $zzz] == 2} {
                    set zzz [string range $zzz 0 0]
                    } else {
                            if {[string length $zzz] <= 1} {
                            set zzz 0
                            }
                            }
                    }
        set zzz [incr peak -$zzz]
        .top21.fra24.fra23.can21.can$host create line $i 200 $i $zzz -fill green
        incr i
        }
    update
    }
after 10000 cpu_update
}

proc {mem} {} {
global widget
global ListOfHosts

place forget .top21.fra24.fra22
place forget .top21.fra24.fra23
place forget .top21.fra24.fra37
place forget .top21.fra24.mc123
place forget .top21.fra24.scr25
place forget .top21.but22

place .top21.fra24.fra24 -x 10 -y 12 -width 520 -height 335 -anchor nw -bordermode ignore
place .top21.fra24.fra24.mc123 -x 10 -y 30 -width 481 -height 295
.top21.fra24.fra24.mc123 delete 0 end

set pad "  "

foreach host $ListOfHosts {
    set xxx [exec rsh -n $host cat /proc/meminfo]
    set Total [lindex $xxx 18]
    set Free [lindex $xxx 21]
    set Shared [lindex $xxx 24]
    set Buffer [lindex $xxx 27]
    set Cached [lindex $xxx 30]
    set SwapTotal [lindex $xxx 39]
    set SwapFree [lindex $xxx 42]
    .top21.fra24.fra24.mc123 insert end [list $pad$host $pad$Total $pad$Free $pad$Shared $pad$Buffer $pad$Cached $pad$SwapTotal $pad$SwapFree]
    }
}

proc {overview} {} {
global widget
global ListOfHosts

place forget .top21.fra24.fra22
place forget .top21.fra24.fra24
place forget .top21.fra24.fra37
place forget .top21.fra24.fra21
place forget .top21.fra24.fra23
place .top21.fra24.mc123 -x 5 -y 17 -width 300 -height 318
place .top21.fra24.scr25 -x 306 -y 19 -width 18 -height 317 -anchor nw -bordermode ignore
place .top21.but22 -x 590 -y 55 -anchor nw -bordermode ignore
}

proc {refresh} {} {
global widget 
global ListOfHosts

#rebuild all column to refresh , i can find better than this way
set ListOfColumn [.top21.fra24.mc123 column names]
foreach ColumnID $ListOfColumn {
	.top21.fra24.mc123 column delete $ColumnID
	}
.top21.fra24.mc123 column add host -label "Host" -width 10  -font [vTcl:font:get_font "vTcl:font1"]
.top21.fra24.mc123 column add time -label "Time" -width 8  -font [vTcl:font:get_font "vTcl:font1"]
.top21.fra24.mc123 column add users -label "Users" -width 8  -font [vTcl:font:get_font "vTcl:font1"]
.top21.fra24.mc123 column add load -label "Load" -width 8  -font [vTcl:font:get_font "vTcl:font1"]
.top21.fra24.mc123 column add process -label "Process" -width 8  -font [vTcl:font:get_font "vTcl:font1"]
#end rebuild column

set Pad "    "
set Pad2 "    -"
foreach host $ListOfHosts {
	set errorCode [catch {set pingResult [exec /bin/ping -c 1 $host]} errorMessage]
	if $errorCode {
	.top21.fra24.mc123 insert end [list $Pad$host $Pad2 $Pad2 $Pad2 $Pad2 $Pad2 $Pad2 $Pad2]
	} else {
		set upTime [catch {exec rsh -n $host /usr/bin/uptime}]
		if $upTime {
		.top21.fra24.mc123 insert end [list $Pad$host $Pad2 $Pad2 $Pad2 $Pad2 $Pad2 $Pad2 $Pad2]
		} else {
			set upTime [exec rsh -n $host /usr/bin/uptime]
			if  {[lindex $upTime 3] == "min,"} {
				set upTime [lreplace $upTime 3 3]
    				}
			set Users [lindex $upTime 3]
			set Time [lindex $upTime 2]
			set Time [string trimright $Time ',']
			set Load [lindex $upTime 7]
			set Load [string trimright $Load ',']
			exec rsh -n $host /bin/ps -ax > xmonitor.tmp
			set numProcess [exec wc xmonitor.tmp]
			set numProcess [lindex $numProcess 0]
			exec rm -f xmonitor.tmp
			.top21.fra24.mc123 insert end [list $Pad$host $Pad$Time $Pad$Users $Pad$Load $Pad$numProcess]


			}
		}


update
}


#after 10000 refresh
#update
}

proc {task} {} {
global widget
global source_filename
global node_number
global che29
global che28
global che55

set node_number "2"
set che29 1
set che28 1
set che55 0
exec wipe

place forget .top21.fra24.mc123
place forget .top21.fra24.scr25
place forget .top21.but22
place forget .top21.fra24.fra21
place forget .top21.fra24.fra23
place forget .top21.fra24.fra24

place .top21.fra24.fra37 -x 343 -y 10 -width 190 -height 335 -anchor nw -bordermode ignore 
place .top21.fra24.fra22 -x 10 -y 9 -width 325 -height 335 -anchor nw -bordermode ignore
}

proc {task_clear} {} {
global widget

.top21.fra24.fra22.lis53 delete 0 end
}

proc {task_run} {} {
global widget
global source_filename
global node_number
global che29
global che28
global che55


set xxx "v"
set homo "v"
set background " "

if {$che29 == 1} {
    set homo "O"
    }

if {$che28 == 1} {
    set xxx "c2c"
    }

if {$che55 == 1} {
    set background "&"
    }

exec lamboot &
set msg [exec mpirun -v -$xxx -$homo -s h -c $node_number $source_filename $background]
task_update
exec wipe

set msg [split $msg \n]
foreach msg_line $msg {
    .top21.fra24.fra22.lis53 insert end $msg_line
    }
}

proc {task_stop} {} {
global widget

exec wipe
}

proc {task_update} {} {
global widget
global source_filename
global cpu_time
global mem_use


set start_time "00:00:00"
set cpu_time 0
set mem_use 0
set pad " %"
exec ps -auxw > xmonitor.tmp
exec grep $source_filename xmonitor.tmp > xmonitor.tm2 &
set xxx [exec cat xmonitor.tm2]

set start_time [lindex $xxx 8]
set run_time [lindex $xxx 9]
set cpu_time [lindex $xxx 2]
set mem_use [lindex $xxx 3]

exec rm -f xmonitor.tmp
exec rm -f xmonitor.tm2


.top21.fra24.fra37.pro54 configure -textvalue $cpu_time$pad
.top21.fra24.fra37.pro22 configure -textvalue $mem_use$pad
.top21.fra24.fra37.mes23 configure -text $start_time
.top21.fra24.fra37.mes24 configure -text $run_time


exec echo $cpu_time >> cpustats
exec echo $mem_use >> memstats


#this part update mem & cpu stats

set cpu_list [exec cat cpustats]
set mem_list [exec cat memstats]
set i 5
set cpu_peak 35
set mem_peak 35


foreach cpu_item $cpu_list {
    set xxx [string length $cpu_item]
    incr xxx -3
    set cpu_item [string range $cpu_item 0 $xxx]
    if {$cpu_item == ""} {
        set cpu_item 0
        }
    incr cpu_peak -$cpu_item       
    .top21.fra24.fra37.can49 create line $i 100 $i $cpu_peak -fill green
    incr i
    }


set i 5
foreach mem_item $mem_list {
    set xxx [string length $mem_item]
    incr xxx -3
    set mem_item [string range $mem_item 0 $xxx]
    if {$mem_item == ""} {
        set mem_item 0
        }
    incr mem_peak -$mem_item       
    .top21.fra24.fra37.can50 create line $i 100 $i $mem_peak -fill green
    incr i
    }

after 10000 task_update
}

proc {main} {argc argv} {
wm protocol .top21 WM_DELETE_WINDOW {exit}
global ListOfHosts

exec rm -f cpustats
exec touch cpustats
exec rm -f memstats
exec touch memstats
foreach host $ListOfHosts {
    exec rm -f cpu$host
    exec touch cpu$host
    }

#this following for initial multicolumn listbox
source mclistbox.tcl
catch {namespace import mclistbox::*}
mclistbox .top21.fra24.mc123 -yscrollcommand [list .top21.fra24.scr25 set] -resizablecolumns false
.top21.fra24.mc123 column add host -label "Host" -width 10  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.mc123 column add time -label "Time" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.mc123 column add users -label "Users" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.mc123 column add load -label "Load" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.mc123 column add process -label "Process" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false




mclistbox .top21.fra24.fra23.mc123 -yscrollcommand [list .top21.fra24.fra23.scr21 set] -resizablecolumns false
.top21.fra24.fra23.mc123 column add name -label "name" -width 10  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra23.mc123 column add cpu -label "cpu" -width 15  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra23.mc123 column add clock -label "clock" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false


mclistbox .top21.fra24.fra24.mc123 -yscrollcommand [list .top21.fra24.fra24.scr25 set] -resizablecolumns false
.top21.fra24.fra24.mc123 column add name -label "name" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add total -label "Total" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add free -label "Free" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add shared -label "Shared" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add buffer -label "Buffer" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add cached -label "Cached" -width 8  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add swaptotal -label "SwapTotal" -width 10  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false
.top21.fra24.fra24.mc123 column add swapfree -label "SwapFree" -width 10  -font [vTcl:font:get_font "vTcl:font1"]  -resizable false


foreach host $ListOfHosts {
    message .top21.fra24.fra23.can21.$host -padx 5 -pady 2 -text $host -width 70
    ::progressbar::progressbar .top21.fra24.fra23.can21.pro$host -width 80 -variable load$host
    canvas .top21.fra24.fra23.can21.can$host -borderwidth 2 -closeenough 1.0 -height 28 -relief ridge -width 96 
    global load$host
    }












image create photo p1 -file "background/bg1.ppm"
.top21.can21 create image 342 235 -image p1

overview
#cpu
#mem
bind .top21.fra24.fra21.lis26 <ButtonRelease-1> {config_select}
}

proc init {argc argv} {
global ListOfHosts
set ListOfHosts [exec cat xmonitor.conf]
}

init $argc $argv

#################################
# VTCL GENERATED GUI PROCEDURES
#

proc vTclWindow. {base {container 0}} {
    if {$base == ""} {
        set base .
    }
    ###################
    # CREATING WIDGETS
    ###################
    if {!$container} {
    wm focusmodel $base passive
    wm geometry $base 1x1+0+0; update
    wm maxsize $base 785 570
    wm minsize $base 1 1
    wm overrideredirect $base 0
    wm resizable $base 1 1
    wm withdraw $base
    wm title $base "vtcl.tcl"
    bindtags $base "$base Vtcl.tcl all"
    }
    ###################
    # SETTING GEOMETRY
    ###################
}

proc vTclWindow.top21 {base {container 0}} {
    if {$base == ""} {
        set base .top21
    }
    if {[winfo exists $base] && (!$container)} {
        wm deiconify $base; return
    }

    global widget
    set widget(rev,$base) {Toplevel1}
    set {widget(Toplevel1)} "$base"
    set widget(Toplevel1,Toplevel1) "$base"
    interp alias {} Toplevel1 {} vTcl:Toplevel:WidgetProc $base
    set widget(rev,$base.but22) {Button1}
    set {widget(Button1)} "$base.but22"
    set widget(Toplevel1,Button1) "$base.but22"
    interp alias {} Button1 {} vTcl:WidgetProc $base.but22
    interp alias {} Toplevel1.Button1 {} vTcl:WidgetProc $base.but22
    set widget(rev,$base.can21) {Canvas1}
    set {widget(Canvas1)} "$base.can21"
    set widget(Toplevel1,Canvas1) "$base.can21"
    interp alias {} Canvas1 {} vTcl:WidgetProc $base.can21
    interp alias {} Toplevel1.Canvas1 {} vTcl:WidgetProc $base.can21
    set widget(rev,$base.can21.but21) {Button2}
    set {widget(Button2)} "$base.can21.but21"
    set widget(Toplevel1,Button2) "$base.can21.but21"
    interp alias {} Button2 {} vTcl:WidgetProc $base.can21.but21
    interp alias {} Toplevel1.Button2 {} vTcl:WidgetProc $base.can21.but21
    set widget(rev,$base.can21.but22) {Button3}
    set {widget(Button3)} "$base.can21.but22"
    set widget(Toplevel1,Button3) "$base.can21.but22"
    interp alias {} Button3 {} vTcl:WidgetProc $base.can21.but22
    interp alias {} Toplevel1.Button3 {} vTcl:WidgetProc $base.can21.but22
    set widget(rev,$base.can21.but23) {Button4}
    set {widget(Button4)} "$base.can21.but23"
    set widget(Toplevel1,Button4) "$base.can21.but23"
    interp alias {} Button4 {} vTcl:WidgetProc $base.can21.but23
    interp alias {} Toplevel1.Button4 {} vTcl:WidgetProc $base.can21.but23
    set widget(rev,$base.can21.but24) {Button5}
    set {widget(Button5)} "$base.can21.but24"
    set widget(Toplevel1,Button5) "$base.can21.but24"
    interp alias {} Button5 {} vTcl:WidgetProc $base.can21.but24
    interp alias {} Toplevel1.Button5 {} vTcl:WidgetProc $base.can21.but24
    set widget(rev,$base.can21.but25) {Button6}
    set {widget(Button6)} "$base.can21.but25"
    set widget(Toplevel1,Button6) "$base.can21.but25"
    interp alias {} Button6 {} vTcl:WidgetProc $base.can21.but25
    interp alias {} Toplevel1.Button6 {} vTcl:WidgetProc $base.can21.but25
    set widget(rev,$base.can21.mes21) {Message6}
    set {widget(Message6)} "$base.can21.mes21"
    set widget(Toplevel1,Message6) "$base.can21.mes21"
    interp alias {} Message6 {} vTcl:WidgetProc $base.can21.mes21
    interp alias {} Toplevel1.Message6 {} vTcl:WidgetProc $base.can21.mes21
    set widget(rev,$base.fra24) {Frame4}
    set {widget(Frame4)} "$base.fra24"
    set widget(Toplevel1,Frame4) "$base.fra24"
    interp alias {} Frame4 {} vTcl:WidgetProc $base.fra24
    interp alias {} Toplevel1.Frame4 {} vTcl:WidgetProc $base.fra24
    set widget(rev,$base.fra24.fra21) {Frame5}
    set {widget(Frame5)} "$base.fra24.fra21"
    set widget(Toplevel1,Frame5) "$base.fra24.fra21"
    interp alias {} Frame5 {} vTcl:WidgetProc $base.fra24.fra21
    interp alias {} Toplevel1.Frame5 {} vTcl:WidgetProc $base.fra24.fra21
    set widget(rev,$base.fra24.fra21.but21) {Button12}
    set {widget(Button12)} "$base.fra24.fra21.but21"
    set widget(Toplevel1,Button12) "$base.fra24.fra21.but21"
    interp alias {} Button12 {} vTcl:WidgetProc $base.fra24.fra21.but21
    interp alias {} Toplevel1.Button12 {} vTcl:WidgetProc $base.fra24.fra21.but21
    set widget(rev,$base.fra24.fra21.but22) {Button13}
    set {widget(Button13)} "$base.fra24.fra21.but22"
    set widget(Toplevel1,Button13) "$base.fra24.fra21.but22"
    interp alias {} Button13 {} vTcl:WidgetProc $base.fra24.fra21.but22
    interp alias {} Toplevel1.Button13 {} vTcl:WidgetProc $base.fra24.fra21.but22
    set widget(rev,$base.fra24.fra21.but23) {Button14}
    set {widget(Button14)} "$base.fra24.fra21.but23"
    set widget(Toplevel1,Button14) "$base.fra24.fra21.but23"
    interp alias {} Button14 {} vTcl:WidgetProc $base.fra24.fra21.but23
    interp alias {} Toplevel1.Button14 {} vTcl:WidgetProc $base.fra24.fra21.but23
    set widget(rev,$base.fra24.fra21.but36) {Button9}
    set {widget(Button9)} "$base.fra24.fra21.but36"
    set widget(Toplevel1,Button9) "$base.fra24.fra21.but36"
    interp alias {} Button9 {} vTcl:WidgetProc $base.fra24.fra21.but36
    interp alias {} Toplevel1.Button9 {} vTcl:WidgetProc $base.fra24.fra21.but36
    set widget(rev,$base.fra24.fra21.but38) {Button10}
    set {widget(Button10)} "$base.fra24.fra21.but38"
    set widget(Toplevel1,Button10) "$base.fra24.fra21.but38"
    interp alias {} Button10 {} vTcl:WidgetProc $base.fra24.fra21.but38
    interp alias {} Toplevel1.Button10 {} vTcl:WidgetProc $base.fra24.fra21.but38
    set widget(rev,$base.fra24.fra21.but39) {Button11}
    set {widget(Button11)} "$base.fra24.fra21.but39"
    set widget(Toplevel1,Button11) "$base.fra24.fra21.but39"
    interp alias {} Button11 {} vTcl:WidgetProc $base.fra24.fra21.but39
    interp alias {} Toplevel1.Button11 {} vTcl:WidgetProc $base.fra24.fra21.but39
    set widget(rev,$base.fra24.fra21.ent30) {Entry1}
    set {widget(Entry1)} "$base.fra24.fra21.ent30"
    set widget(Toplevel1,Entry1) "$base.fra24.fra21.ent30"
    interp alias {} Entry1 {} vTcl:WidgetProc $base.fra24.fra21.ent30
    interp alias {} Toplevel1.Entry1 {} vTcl:WidgetProc $base.fra24.fra21.ent30
    set widget(rev,$base.fra24.fra21.ent31) {Entry2}
    set {widget(Entry2)} "$base.fra24.fra21.ent31"
    set widget(Toplevel1,Entry2) "$base.fra24.fra21.ent31"
    interp alias {} Entry2 {} vTcl:WidgetProc $base.fra24.fra21.ent31
    interp alias {} Toplevel1.Entry2 {} vTcl:WidgetProc $base.fra24.fra21.ent31
    set widget(rev,$base.fra24.fra21.ent32) {Entry3}
    set {widget(Entry3)} "$base.fra24.fra21.ent32"
    set widget(Toplevel1,Entry3) "$base.fra24.fra21.ent32"
    interp alias {} Entry3 {} vTcl:WidgetProc $base.fra24.fra21.ent32
    interp alias {} Toplevel1.Entry3 {} vTcl:WidgetProc $base.fra24.fra21.ent32
    set widget(rev,$base.fra24.fra21.lis26) {Listbox1}
    set {widget(Listbox1)} "$base.fra24.fra21.lis26"
    set widget(Toplevel1,Listbox1) "$base.fra24.fra21.lis26"
    interp alias {} Listbox1 {} vTcl:WidgetProc $base.fra24.fra21.lis26
    interp alias {} Toplevel1.Listbox1 {} vTcl:WidgetProc $base.fra24.fra21.lis26
    set widget(rev,$base.fra24.fra21.mes24) {Message1}
    set {widget(Message1)} "$base.fra24.fra21.mes24"
    set widget(Toplevel1,Message1) "$base.fra24.fra21.mes24"
    interp alias {} Message1 {} vTcl:WidgetProc $base.fra24.fra21.mes24
    interp alias {} Toplevel1.Message1 {} vTcl:WidgetProc $base.fra24.fra21.mes24
    set widget(rev,$base.fra24.fra21.mes33) {Message2}
    set {widget(Message2)} "$base.fra24.fra21.mes33"
    set widget(Toplevel1,Message2) "$base.fra24.fra21.mes33"
    interp alias {} Message2 {} vTcl:WidgetProc $base.fra24.fra21.mes33
    interp alias {} Toplevel1.Message2 {} vTcl:WidgetProc $base.fra24.fra21.mes33
    set widget(rev,$base.fra24.fra21.mes34) {Message3}
    set {widget(Message3)} "$base.fra24.fra21.mes34"
    set widget(Toplevel1,Message3) "$base.fra24.fra21.mes34"
    interp alias {} Message3 {} vTcl:WidgetProc $base.fra24.fra21.mes34
    interp alias {} Toplevel1.Message3 {} vTcl:WidgetProc $base.fra24.fra21.mes34
    set widget(rev,$base.fra24.fra21.mes35) {Message4}
    set {widget(Message4)} "$base.fra24.fra21.mes35"
    set widget(Toplevel1,Message4) "$base.fra24.fra21.mes35"
    interp alias {} Message4 {} vTcl:WidgetProc $base.fra24.fra21.mes35
    interp alias {} Toplevel1.Message4 {} vTcl:WidgetProc $base.fra24.fra21.mes35
    set widget(rev,$base.fra24.fra21.mes41) {Message5}
    set {widget(Message5)} "$base.fra24.fra21.mes41"
    set widget(Toplevel1,Message5) "$base.fra24.fra21.mes41"
    interp alias {} Message5 {} vTcl:WidgetProc $base.fra24.fra21.mes41
    interp alias {} Toplevel1.Message5 {} vTcl:WidgetProc $base.fra24.fra21.mes41
    set widget(rev,$base.fra24.fra22) {Frame6}
    set {widget(Frame6)} "$base.fra24.fra22"
    set widget(Toplevel1,Frame6) "$base.fra24.fra22"
    interp alias {} Frame6 {} vTcl:WidgetProc $base.fra24.fra22
    interp alias {} Toplevel1.Frame6 {} vTcl:WidgetProc $base.fra24.fra22
    set widget(rev,$base.fra24.fra22.but21) {Button18}
    set {widget(Button18)} "$base.fra24.fra22.but21"
    set widget(Toplevel1,Button18) "$base.fra24.fra22.but21"
    interp alias {} Button18 {} vTcl:WidgetProc $base.fra24.fra22.but21
    interp alias {} Toplevel1.Button18 {} vTcl:WidgetProc $base.fra24.fra22.but21
    set widget(rev,$base.fra24.fra22.but30) {Button15}
    set {widget(Button15)} "$base.fra24.fra22.but30"
    set widget(Toplevel1,Button15) "$base.fra24.fra22.but30"
    interp alias {} Button15 {} vTcl:WidgetProc $base.fra24.fra22.but30
    interp alias {} Toplevel1.Button15 {} vTcl:WidgetProc $base.fra24.fra22.but30
    set widget(rev,$base.fra24.fra22.but31) {Button16}
    set {widget(Button16)} "$base.fra24.fra22.but31"
    set widget(Toplevel1,Button16) "$base.fra24.fra22.but31"
    interp alias {} Button16 {} vTcl:WidgetProc $base.fra24.fra22.but31
    interp alias {} Toplevel1.Button16 {} vTcl:WidgetProc $base.fra24.fra22.but31
    set widget(rev,$base.fra24.fra22.che28) {Checkbutton3}
    set {widget(Checkbutton3)} "$base.fra24.fra22.che28"
    set widget(Toplevel1,Checkbutton3) "$base.fra24.fra22.che28"
    interp alias {} Checkbutton3 {} vTcl:WidgetProc $base.fra24.fra22.che28
    interp alias {} Toplevel1.Checkbutton3 {} vTcl:WidgetProc $base.fra24.fra22.che28
    set widget(rev,$base.fra24.fra22.che29) {Checkbutton4}
    set {widget(Checkbutton4)} "$base.fra24.fra22.che29"
    set widget(Toplevel1,Checkbutton4) "$base.fra24.fra22.che29"
    interp alias {} Checkbutton4 {} vTcl:WidgetProc $base.fra24.fra22.che29
    interp alias {} Toplevel1.Checkbutton4 {} vTcl:WidgetProc $base.fra24.fra22.che29
    set widget(rev,$base.fra24.fra22.che55) {Checkbutton5}
    set {widget(Checkbutton5)} "$base.fra24.fra22.che55"
    set widget(Toplevel1,Checkbutton5) "$base.fra24.fra22.che55"
    interp alias {} Checkbutton5 {} vTcl:WidgetProc $base.fra24.fra22.che55
    interp alias {} Toplevel1.Checkbutton5 {} vTcl:WidgetProc $base.fra24.fra22.che55
    set widget(rev,$base.fra24.fra22.ent24) {Entry4}
    set {widget(Entry4)} "$base.fra24.fra22.ent24"
    set widget(Toplevel1,Entry4) "$base.fra24.fra22.ent24"
    interp alias {} Entry4 {} vTcl:WidgetProc $base.fra24.fra22.ent24
    interp alias {} Toplevel1.Entry4 {} vTcl:WidgetProc $base.fra24.fra22.ent24
    set widget(rev,$base.fra24.fra22.ent36) {Entry6}
    set {widget(Entry6)} "$base.fra24.fra22.ent36"
    set widget(Toplevel1,Entry6) "$base.fra24.fra22.ent36"
    interp alias {} Entry6 {} vTcl:WidgetProc $base.fra24.fra22.ent36
    interp alias {} Toplevel1.Entry6 {} vTcl:WidgetProc $base.fra24.fra22.ent36
    set widget(rev,$base.fra24.fra22.lis53) {Listbox2}
    set {widget(Listbox2)} "$base.fra24.fra22.lis53"
    set widget(Toplevel1,Listbox2) "$base.fra24.fra22.lis53"
    interp alias {} Listbox2 {} vTcl:WidgetProc $base.fra24.fra22.lis53
    interp alias {} Toplevel1.Listbox2 {} vTcl:WidgetProc $base.fra24.fra22.lis53
    set widget(rev,$base.fra24.fra22.mes23) {Message7}
    set {widget(Message7)} "$base.fra24.fra22.mes23"
    set widget(Toplevel1,Message7) "$base.fra24.fra22.mes23"
    interp alias {} Message7 {} vTcl:WidgetProc $base.fra24.fra22.mes23
    interp alias {} Toplevel1.Message7 {} vTcl:WidgetProc $base.fra24.fra22.mes23
    set widget(rev,$base.fra24.fra22.mes25) {Message8}
    set {widget(Message8)} "$base.fra24.fra22.mes25"
    set widget(Toplevel1,Message8) "$base.fra24.fra22.mes25"
    interp alias {} Message8 {} vTcl:WidgetProc $base.fra24.fra22.mes25
    interp alias {} Toplevel1.Message8 {} vTcl:WidgetProc $base.fra24.fra22.mes25
    set widget(rev,$base.fra24.fra22.mes35) {Message9}
    set {widget(Message9)} "$base.fra24.fra22.mes35"
    set widget(Toplevel1,Message9) "$base.fra24.fra22.mes35"
    interp alias {} Message9 {} vTcl:WidgetProc $base.fra24.fra22.mes35
    interp alias {} Toplevel1.Message9 {} vTcl:WidgetProc $base.fra24.fra22.mes35
    set widget(rev,$base.fra24.fra22.mes56) {Message15}
    set {widget(Message15)} "$base.fra24.fra22.mes56"
    set widget(Toplevel1,Message15) "$base.fra24.fra22.mes56"
    interp alias {} Message15 {} vTcl:WidgetProc $base.fra24.fra22.mes56
    interp alias {} Toplevel1.Message15 {} vTcl:WidgetProc $base.fra24.fra22.mes56
    set widget(rev,$base.fra24.fra22.scr33) {Scrollbar2}
    set {widget(Scrollbar2)} "$base.fra24.fra22.scr33"
    set widget(Toplevel1,Scrollbar2) "$base.fra24.fra22.scr33"
    interp alias {} Scrollbar2 {} vTcl:WidgetProc $base.fra24.fra22.scr33
    interp alias {} Toplevel1.Scrollbar2 {} vTcl:WidgetProc $base.fra24.fra22.scr33
    set widget(rev,$base.fra24.fra22.scr34) {Scrollbar3}
    set {widget(Scrollbar3)} "$base.fra24.fra22.scr34"
    set widget(Toplevel1,Scrollbar3) "$base.fra24.fra22.scr34"
    interp alias {} Scrollbar3 {} vTcl:WidgetProc $base.fra24.fra22.scr34
    interp alias {} Toplevel1.Scrollbar3 {} vTcl:WidgetProc $base.fra24.fra22.scr34
    set widget(rev,$base.fra24.fra23) {Frame8}
    set {widget(Frame8)} "$base.fra24.fra23"
    set widget(Toplevel1,Frame8) "$base.fra24.fra23"
    interp alias {} Frame8 {} vTcl:WidgetProc $base.fra24.fra23
    interp alias {} Toplevel1.Frame8 {} vTcl:WidgetProc $base.fra24.fra23
    set widget(rev,$base.fra24.fra23.can21) {Canvas6}
    set {widget(Canvas6)} "$base.fra24.fra23.can21"
    set widget(Toplevel1,Canvas6) "$base.fra24.fra23.can21"
    interp alias {} Canvas6 {} vTcl:WidgetProc $base.fra24.fra23.can21
    interp alias {} Toplevel1.Canvas6 {} vTcl:WidgetProc $base.fra24.fra23.can21
    set widget(rev,$base.fra24.fra23.can21.pro22) {Progressbar1}
    set {widget(Progressbar1)} "$base.fra24.fra23.can21.pro22"
    set widget(Toplevel1,Progressbar1) "$base.fra24.fra23.can21.pro22"
    interp alias {} Progressbar1 {} vTcl:WidgetProc $base.fra24.fra23.can21.pro22
    interp alias {} Toplevel1.Progressbar1 {} vTcl:WidgetProc $base.fra24.fra23.can21.pro22
    set widget(rev,$base.fra24.fra23.scr21) {Scrollbar5}
    set {widget(Scrollbar5)} "$base.fra24.fra23.scr21"
    set widget(Toplevel1,Scrollbar5) "$base.fra24.fra23.scr21"
    interp alias {} Scrollbar5 {} vTcl:WidgetProc $base.fra24.fra23.scr21
    interp alias {} Toplevel1.Scrollbar5 {} vTcl:WidgetProc $base.fra24.fra23.scr21
    set widget(rev,$base.fra24.fra23.scr25) {Scrollbar4}
    set {widget(Scrollbar4)} "$base.fra24.fra23.scr25"
    set widget(Toplevel1,Scrollbar4) "$base.fra24.fra23.scr25"
    interp alias {} Scrollbar4 {} vTcl:WidgetProc $base.fra24.fra23.scr25
    interp alias {} Toplevel1.Scrollbar4 {} vTcl:WidgetProc $base.fra24.fra23.scr25
    set widget(rev,$base.fra24.fra24) {Frame9}
    set {widget(Frame9)} "$base.fra24.fra24"
    set widget(Toplevel1,Frame9) "$base.fra24.fra24"
    interp alias {} Frame9 {} vTcl:WidgetProc $base.fra24.fra24
    interp alias {} Toplevel1.Frame9 {} vTcl:WidgetProc $base.fra24.fra24
    set widget(rev,$base.fra24.fra24.mes21) {Message18}
    set {widget(Message18)} "$base.fra24.fra24.mes21"
    set widget(Toplevel1,Message18) "$base.fra24.fra24.mes21"
    interp alias {} Message18 {} vTcl:WidgetProc $base.fra24.fra24.mes21
    interp alias {} Toplevel1.Message18 {} vTcl:WidgetProc $base.fra24.fra24.mes21
    set widget(rev,$base.fra24.fra24.scr25) {Scrollbar6}
    set {widget(Scrollbar6)} "$base.fra24.fra24.scr25"
    set widget(Toplevel1,Scrollbar6) "$base.fra24.fra24.scr25"
    interp alias {} Scrollbar6 {} vTcl:WidgetProc $base.fra24.fra24.scr25
    interp alias {} Toplevel1.Scrollbar6 {} vTcl:WidgetProc $base.fra24.fra24.scr25
    set widget(rev,$base.fra24.fra37) {Frame7}
    set {widget(Frame7)} "$base.fra24.fra37"
    set widget(Toplevel1,Frame7) "$base.fra24.fra37"
    interp alias {} Frame7 {} vTcl:WidgetProc $base.fra24.fra37
    interp alias {} Toplevel1.Frame7 {} vTcl:WidgetProc $base.fra24.fra37
    set widget(rev,$base.fra24.fra37.can49) {Canvas4}
    set {widget(Canvas4)} "$base.fra24.fra37.can49"
    set widget(Toplevel1,Canvas4) "$base.fra24.fra37.can49"
    interp alias {} Canvas4 {} vTcl:WidgetProc $base.fra24.fra37.can49
    interp alias {} Toplevel1.Canvas4 {} vTcl:WidgetProc $base.fra24.fra37.can49
    set widget(rev,$base.fra24.fra37.can50) {Canvas5}
    set {widget(Canvas5)} "$base.fra24.fra37.can50"
    set widget(Toplevel1,Canvas5) "$base.fra24.fra37.can50"
    interp alias {} Canvas5 {} vTcl:WidgetProc $base.fra24.fra37.can50
    interp alias {} Toplevel1.Canvas5 {} vTcl:WidgetProc $base.fra24.fra37.can50
    set widget(rev,$base.fra24.fra37.mes23) {Message16}
    set {widget(Message16)} "$base.fra24.fra37.mes23"
    set widget(Toplevel1,Message16) "$base.fra24.fra37.mes23"
    interp alias {} Message16 {} vTcl:WidgetProc $base.fra24.fra37.mes23
    interp alias {} Toplevel1.Message16 {} vTcl:WidgetProc $base.fra24.fra37.mes23
    set widget(rev,$base.fra24.fra37.mes24) {Message17}
    set {widget(Message17)} "$base.fra24.fra37.mes24"
    set widget(Toplevel1,Message17) "$base.fra24.fra37.mes24"
    interp alias {} Message17 {} vTcl:WidgetProc $base.fra24.fra37.mes24
    interp alias {} Toplevel1.Message17 {} vTcl:WidgetProc $base.fra24.fra37.mes24
    set widget(rev,$base.fra24.fra37.mes38) {Message10}
    set {widget(Message10)} "$base.fra24.fra37.mes38"
    set widget(Toplevel1,Message10) "$base.fra24.fra37.mes38"
    interp alias {} Message10 {} vTcl:WidgetProc $base.fra24.fra37.mes38
    interp alias {} Toplevel1.Message10 {} vTcl:WidgetProc $base.fra24.fra37.mes38
    set widget(rev,$base.fra24.fra37.mes39) {Message11}
    set {widget(Message11)} "$base.fra24.fra37.mes39"
    set widget(Toplevel1,Message11) "$base.fra24.fra37.mes39"
    interp alias {} Message11 {} vTcl:WidgetProc $base.fra24.fra37.mes39
    interp alias {} Toplevel1.Message11 {} vTcl:WidgetProc $base.fra24.fra37.mes39
    set widget(rev,$base.fra24.fra37.mes40) {Message12}
    set {widget(Message12)} "$base.fra24.fra37.mes40"
    set widget(Toplevel1,Message12) "$base.fra24.fra37.mes40"
    interp alias {} Message12 {} vTcl:WidgetProc $base.fra24.fra37.mes40
    interp alias {} Toplevel1.Message12 {} vTcl:WidgetProc $base.fra24.fra37.mes40
    set widget(rev,$base.fra24.fra37.mes41) {Message13}
    set {widget(Message13)} "$base.fra24.fra37.mes41"
    set widget(Toplevel1,Message13) "$base.fra24.fra37.mes41"
    interp alias {} Message13 {} vTcl:WidgetProc $base.fra24.fra37.mes41
    interp alias {} Toplevel1.Message13 {} vTcl:WidgetProc $base.fra24.fra37.mes41
    set widget(rev,$base.fra24.fra37.mes42) {Message14}
    set {widget(Message14)} "$base.fra24.fra37.mes42"
    set widget(Toplevel1,Message14) "$base.fra24.fra37.mes42"
    interp alias {} Message14 {} vTcl:WidgetProc $base.fra24.fra37.mes42
    interp alias {} Toplevel1.Message14 {} vTcl:WidgetProc $base.fra24.fra37.mes42
    set widget(rev,$base.fra24.fra37.pro22) {Progressbar1}
    set {widget(Progressbar1)} "$base.fra24.fra23.can21.pro22"
    set widget(Toplevel1,Progressbar1) "$base.fra24.fra23.can21.pro22"
    interp alias {} Progressbar1 {} vTcl:WidgetProc $base.fra24.fra23.can21.pro22
    interp alias {} Toplevel1.Progressbar1 {} vTcl:WidgetProc $base.fra24.fra23.can21.pro22
    set widget(rev,$base.fra24.fra37.pro54) {Progressbar1}
    set {widget(Progressbar1)} "$base.fra24.fra23.can21.pro22"
    set widget(Toplevel1,Progressbar1) "$base.fra24.fra23.can21.pro22"
    interp alias {} Progressbar1 {} vTcl:WidgetProc $base.fra24.fra23.can21.pro22
    interp alias {} Toplevel1.Progressbar1 {} vTcl:WidgetProc $base.fra24.fra23.can21.pro22
    set widget(rev,$base.fra24.scr25) {Scrollbar1}
    set {widget(Scrollbar1)} "$base.fra24.scr25"
    set widget(Toplevel1,Scrollbar1) "$base.fra24.scr25"
    interp alias {} Scrollbar1 {} vTcl:WidgetProc $base.fra24.scr25
    interp alias {} Toplevel1.Scrollbar1 {} vTcl:WidgetProc $base.fra24.scr25

    ###################
    # CREATING WIDGETS
    ###################
    if {!$container} {
    toplevel $base -class Toplevel \
        -cursor {} 
    wm focusmodel $base passive
    wm geometry $base 676x464+89+45; update
    wm maxsize $base 785 570
    wm minsize $base 1 1
    wm overrideredirect $base 0
    wm resizable $base 0 0
    wm deiconify $base
    wm title $base "xmonitor"
    }
    canvas $base.can21 \
        -borderwidth 2 -closeenough 1.0 -cursor fleur -height 473 -width 681 
    button $base.can21.but21 \
        -borderwidth 0 -command config -height 51 -highlightthickness 0 \
        -image [vTcl:image:get_image "/home/red/vtcl-1.5.1b2/background/config.ppm"] \
        -text button -width 92 
    button $base.can21.but22 \
        -borderwidth 0 -command overview -height 51 -highlightthickness 0 \
        -image [vTcl:image:get_image "/home/red/vtcl-1.5.1b2/background/over.ppm"] \
        -width 97 
    button $base.can21.but23 \
        -borderwidth 0 -command cpu -height 50 -highlightthickness 0 \
        -image [vTcl:image:get_image "/home/red/vtcl-1.5.1b2/background/cpu.ppm"] \
        -text button -width 91 
    button $base.can21.but24 \
        -borderwidth 0 -command mem -height 45 -highlightthickness 0 \
        -image [vTcl:image:get_image "/home/red/vtcl-1.5.1b2/background/mem.ppm"] \
        -text button -width 94 
    button $base.can21.but25 \
        -borderwidth 0 -command task -height 51 -highlightthickness 0 \
        -image [vTcl:image:get_image "/home/red/vtcl-1.5.1b2/background/task.ppm"] \
        -text button -width 94 
    message $base.can21.mes21 \
        -background #d2d3ef -font [vTcl:font:get_font "vTcl:font11"] \
        -foreground #0000fe -padx 5 -pady 2 \
        -text {                              Edit by Komkrit Yensirikul
Department of Computer Engineering, KMITL} \
        -width 217 
    button $base.but22 \
        -borderwidth 1 -command refresh \
        -font [vTcl:font:get_font "vTcl:font1"] -text Refresh 
    frame $base.fra24 \
        -borderwidth 2 -height 370 -relief groove -width 545 
    scrollbar $base.fra24.scr25 \
        -command "$base.fra24.mc123 yview" -width 16 
    frame $base.fra24.fra21 \
        -borderwidth 2 -height 335 -relief groove -width 350 
    message $base.fra24.fra21.mes24 \
        -padx 5 -pady 2 -text {hosts node config} -width 112 
    listbox $base.fra24.fra21.lis26 \
        -height 271 -width 88 
    bind $base.fra24.fra21.lis26 <ButtonRelease-1> {
        config_select
    }
    entry $base.fra24.fra21.ent30 \
        -borderwidth 0 -highlightthickness 0 -textvariable IP_Address \
        -width 93 
    entry $base.fra24.fra21.ent31 \
        -borderwidth 0 -highlightthickness 0 -textvariable Domain_Name \
        -width 148 
    entry $base.fra24.fra21.ent32 \
        -borderwidth 0 -highlightthickness 0 -textvariable Alias -width 83 
    message $base.fra24.fra21.mes33 \
        -padx 5 -pady 2 -text {ip address} -width 75 
    message $base.fra24.fra21.mes34 \
        -padx 5 -pady 2 -text {domain name} -width 86 
    message $base.fra24.fra21.mes35 \
        -padx 5 -pady 2 -text alias -width 41 
    button $base.fra24.fra21.but36 \
        -command config_add -foreground #003000 -height 26 -text Add \
        -width 50 
    button $base.fra24.fra21.but38 \
        -command config_edit -foreground #707000 -height 26 -text Edit \
        -width 52 
    button $base.fra24.fra21.but39 \
        -command config_delete -foreground #4a0000 -height 26 -text Delete \
        -width 52 
    message $base.fra24.fra21.mes41 \
        -padx 5 -pady 2 -text {List of node} -width 84 
    button $base.fra24.fra21.but21 \
        -command config_ok -height 26 -text OK -width 54 
    button $base.fra24.fra21.but22 \
        -command config_cancel -height 26 -text Cancel -width 49 
    button $base.fra24.fra21.but23 \
        -command config_update -height 26 -text update -width 57 
    frame $base.fra24.fra22 \
        -borderwidth 2 -cursor fleur -height 335 -relief groove -width 325 
    message $base.fra24.fra22.mes23 \
        -foreground #0068ba -padx 5 -pady 2 -text {load task} -width 70 
    entry $base.fra24.fra22.ent24 \
        -cursor {} -highlightthickness 0 -textvariable source_filename \
        -width 278 
    message $base.fra24.fra22.mes25 \
        -padx 5 -pady 2 -text {source file name} -width 112 
    checkbutton $base.fra24.fra22.che28 \
        -cursor fleur -text {client to client} -variable che28 
    checkbutton $base.fra24.fra22.che29 \
        -text Homogenious -textvariable check_homo -variable che29 
    button $base.fra24.fra22.but30 \
        -command task_run -text run 
    button $base.fra24.fra22.but31 \
        -command task_stop -text stop -width 0 
    scrollbar $base.fra24.fra22.scr33 \
        -command "$base.fra24.fra22.lis53 yview" -width 16 
    scrollbar $base.fra24.fra22.scr34 \
        -command "$base.fra24.fra22.lis53 xview" -orient horizontal \
        -width 297 
    message $base.fra24.fra22.mes35 \
        -cursor fleur -padx 5 -pady 2 -text console -width 70 
    entry $base.fra24.fra22.ent36 \
        -highlightthickness 0 -textvariable node_number -width 38 
    listbox $base.fra24.fra22.lis53 \
        -height 116 -width 293 -xscrollcommand "$base.fra24.fra22.scr34 set" \
        -yscrollcommand "$base.fra24.fra22.scr33 set" 
    checkbutton $base.fra24.fra22.che55 \
        -cursor fleur -height 22 -text {run background} -variable che55 \
        -width 116 
    message $base.fra24.fra22.mes56 \
        -padx 5 -pady 2 -text {number of node} -width 104 
    button $base.fra24.fra22.but21 \
        -command task_clear -height 26 -text {clear console} -width 92 
    frame $base.fra24.fra37 \
        -borderwidth 2 -cursor fleur -height 335 -relief groove -width 190 
    message $base.fra24.fra37.mes38 \
        -foreground #0068ba -padx 5 -pady 2 -text status -width 70 
    message $base.fra24.fra37.mes39 \
        -padx 5 -pady 2 -text {memory usage} -width 103 
    message $base.fra24.fra37.mes40 \
        -padx 5 -pady 2 -text {cpu usage} -width 70 
    message $base.fra24.fra37.mes41 \
        -padx 5 -pady 2 -text start -width 70 
    message $base.fra24.fra37.mes42 \
        -padx 5 -pady 2 -text time -width 70 
    canvas $base.fra24.fra37.can49 \
        -borderwidth 2 -closeenough 1.0 -height 38 -relief ridge -width 141 
    canvas $base.fra24.fra37.can50 \
        -borderwidth 2 -closeenough 1.0 -cursor fleur -height 38 \
        -relief ridge -width 141 
    ::progressbar::progressbar $base.fra24.fra37.pro54 \
        -shape 3d -textcolor #000000 -variable cpu_time -width 110 
    ::progressbar::progressbar $base.fra24.fra37.pro22 \
        -variable mem_use -width 110 
    message $base.fra24.fra37.mes23 \
        -padx 5 -pady 2 -text 00:00:00 -width 70 
    message $base.fra24.fra37.mes24 \
        -padx 5 -pady 2 -text 00:00:00 -width 70 
    frame $base.fra24.fra23 \
        -borderwidth 2 -height 335 -relief groove -width 520 
    scrollbar $base.fra24.fra23.scr25 \
        -command "$base.fra24.fra23.can21 yview" -cursor fleur -width 16 
    canvas $base.fra24.fra23.can21 \
        -borderwidth 2 -closeenough 1.0 -cursor fleur -height 298 \
        -relief ridge -width 216 \
        -yscrollcommand "$base.fra24.fra23.scr25 set" 
    ::progressbar::progressbar $base.fra24.fra23.can21.pro22 \
        -width 65 
    scrollbar $base.fra24.fra23.scr21 \
        -command "$base.fra24.fra23.mc123 yview" -cursor fleur -width 16 
    frame $base.fra24.fra24 \
        -borderwidth 2 -cursor fleur -height 335 -relief groove -width 520 
    scrollbar $base.fra24.fra24.scr25 \
        -command "$base.fra24.fra24.mc123 yview" -cursor fleur -width 16 
    message $base.fra24.fra24.mes21 \
        -foreground #7890d0 -padx 5 -pady 2 -text {Memory Info} -width 93 
    ###################
    # SETTING GEOMETRY
    ###################
    place $base.can21 \
        -x -3 -y -4 -width 681 -height 473 -anchor nw -bordermode ignore 
    place $base.can21.but21 \
        -x 23 -y 121 -width 92 -height 51 -anchor nw -bordermode ignore 
    place $base.can21.but22 \
        -x 24 -y 184 -width 94 -height 51 -anchor nw -bordermode ignore 
    place $base.can21.but23 \
        -x 24 -y 247 -width 91 -height 51 -anchor nw -bordermode ignore 
    place $base.can21.but24 \
        -x 24 -y 312 -width 94 -height 51 -anchor nw -bordermode ignore 
    place $base.can21.but25 \
        -x 20 -y 372 -width 94 -height 51 -anchor nw -bordermode ignore 
    place $base.can21.mes21 \
        -x 458 -y 10 -width 217 -height 27 -anchor nw -bordermode ignore 
    place $base.fra24 \
        -x 131 -y 104 -width 545 -height 360 -anchor nw -bordermode ignore 
    place $base.fra24.scr25 \
        -x 0 -y 0 -anchor nw 
    place $base.fra24.fra21.mes24 \
        -x 231 -y 6 -width 112 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.lis26 \
        -x 12 -y 36 -width 88 -height 271 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.ent30 \
        -x 117 -y 110 -width 93 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.ent31 \
        -x 118 -y 164 -width 148 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.ent32 \
        -x 116 -y 54 -width 83 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.mes33 \
        -x 112 -y 88 -width 75 -height 17 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.mes34 \
        -x 116 -y 144 -width 86 -height 16 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.mes35 \
        -x 110 -y 37 -width 41 -height 17 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.but36 \
        -x 280 -y 45 -width 50 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.but38 \
        -x 279 -y 85 -width 52 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.but39 \
        -x 279 -y 126 -width 52 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra21.mes41 \
        -x 7 -y 20 -width 84 -height 12 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.mes23 \
        -x 230 -y 10 -width 70 -height 17 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.ent24 \
        -x 15 -y 49 -width 278 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.mes25 \
        -x 10 -y 28 -width 112 -height 17 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.che28 \
        -x 16 -y 104 -width 110 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.che29 \
        -x 16 -y 76 -width 105 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.but30 \
        -x 209 -y 173 -width 43 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.but31 \
        -x 256 -y 173 -width 50 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.scr33 \
        -x 305 -y 200 -width 16 -height 117 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.scr34 \
        -x 12 -y 317 -width 297 -height 16 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.mes35 \
        -x 8 -y 181 -width 59 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.ent36 \
        -x 252 -y 106 -width 38 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.lis53 \
        -x 13 -y 200 -width 293 -height 116 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.che55 \
        -x 17 -y 130 -width 116 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.mes56 \
        -x 193 -y 80 -width 104 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra22.but21 \
        -x 91 -y 173 -width 92 -height 26 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes38 \
        -x 122 -y 5 -width 52 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes39 \
        -x 17 -y 187 -width 103 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes40 \
        -x 15 -y 90 -width 74 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes41 \
        -x 15 -y 30 -width 43 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes42 \
        -x 15 -y 60 -width 40 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.can49 \
        -x 20 -y 134 -width 141 -height 40 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.can50 \
        -x 22 -y 231 -width 141 -height 40 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.pro54 \
        -x 16 -y 108 -width 120 -height 24 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.pro22 \
        -x 17 -y 204 -width 120 -height 24 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes23 \
        -x 70 -y 31 -width 64 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra37.mes24 \
        -x 70 -y 60 -width 64 -height 22 -anchor nw -bordermode ignore 
    place $base.fra24.fra23.scr25 \
        -x 497 -y 18 -width 16 -height 297 -anchor nw -bordermode ignore 
    place $base.fra24.fra23.can21 \
        -x 281 -y 18 -width 216 -height 298 -anchor nw -bordermode ignore 
    place $base.fra24.fra23.can21.pro22 \
        -x 15 -y 25 -width 75 -height 24 -anchor nw -bordermode ignore 
    place $base.fra24.fra23.scr21 \
        -x 249 -y 20 -width 16 -height 295 -anchor nw -bordermode ignore 
    place $base.fra24.fra24 \
        -x 10 -y 12 -width 520 -height 335 -anchor nw -bordermode ignore 
    place $base.fra24.fra24.scr25 \
        -x 493 -y 34 -width 16 -height 292 -anchor nw -bordermode ignore 
    place $base.fra24.fra24.mes21 \
        -x 420 -y 4 -width 93 -height 21 -anchor nw -bordermode ignore 
}

Window show .
Window show .top21

main $argc $argv
