Public Function SearchStation(ByVal Keyword As String, _
                                                            ByRef strResult As String) _
                                                            As ADODB.Recordset
On Error GoTo Oops:
    Dim strCommand As String
    Dim rsResult As ADODB.Recordset
    
    Set rsResult = New ADODB.Recordset
    strCommand = "SELECT  PlaceID, PlaceName " & _
                                 "FROM       Place "
    
    If Keyword <> "" Then
        strCommand = strCommand & "WHERE Description LIKE '%" & Keyword & "%'"
    End If
    
    If oSql.SqlExecute(strCommand, rsResult) Then
        If rsResult.EOF And rsResult.BOF Then
            strResult = "Not Found"
        Else
            strResult = "Found"
            Set SearchStation = rsResult
        End If
    Else
        strResult = "[BusService.dll,BusService.ISearch,SearchStation]Can not search bus's station." & vbCrLf & _
                             "Command : """ & strCommand & """"
        oContext.SetAbort
    End If
    Exit Function
    
Oops:
    strResult = "[BusService.dll,BusService.ISearch,SearchStation]" & Err.Description
    oContext.SetAbort
End Function