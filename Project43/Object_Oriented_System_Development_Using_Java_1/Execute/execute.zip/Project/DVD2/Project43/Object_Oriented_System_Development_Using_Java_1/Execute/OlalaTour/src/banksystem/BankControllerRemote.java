package banksystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
public interface BankControllerRemote extends EJBObject {
  public String payByDebitCardID(String debitCardID, String relateAccountID, double amount)  throws  RemoteException, InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException ,InvalidAmountException;
  public String payByCreditCardID(String creditCardID, String relateAccountID, double amount) throws  RemoteException, InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException ,InvalidAmountException;

  public void checkTransfer(String relateAccountID, String transactionID, double amount )  throws  RemoteException, InvalidPasswordException, InvalidAmountException,  AccountNotExistException , TransactionNotExistException ,InvalidAccountException;
  public String transfer(java.lang.String accountIDSource, java.lang.String relateAccountID, double amount) throws InvalidPasswordException, InvalidAccountException, AccountNotExistException, InsufficientBalanceException, RemoteException, InvalidAmountException, BankControllerException;
}