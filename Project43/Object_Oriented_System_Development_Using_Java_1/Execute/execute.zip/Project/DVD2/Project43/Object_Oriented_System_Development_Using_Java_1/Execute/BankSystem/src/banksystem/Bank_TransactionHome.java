package banksystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public interface Bank_TransactionHome extends EJBHome {
  public Bank_TransactionRemote create(String transactionID, String accountID, String relateAccountID, int transactionType, double money, java.sql.Timestamp txDate) throws RemoteException, CreateException;
  public Bank_TransactionRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
  public Collection findByAccountID(String accountID) throws RemoteException, FinderException;
}