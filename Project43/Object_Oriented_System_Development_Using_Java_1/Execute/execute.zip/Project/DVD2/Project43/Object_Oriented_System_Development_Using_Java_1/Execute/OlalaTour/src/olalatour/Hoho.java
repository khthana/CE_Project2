package olalatour;

import java.sql.Date;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class Hoho {

  public Hoho() {
	ViewerBean v = new ViewerBean();
	v.findPackageTour("A", "", "", "", "", 5000, new Date(1988, 1, 1), 500);
	while (v.nextPackageTour()) {
	  System.out.println("roomClass = " + v.getPackageName());
	  System.out.println("numberOfSingleBed = " + v.getTotalPrice());
	}

  }
  public static void main(String[] args) {
	Hoho hoho1 = new Hoho();
  }
}