package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface RestaurantRemote extends EJBObject {
  public int getStar() throws RemoteException;
  public void setStar(int newStar) throws RemoteException;
  public java.lang.String getAddress() throws RemoteException;
  public void setAddress(java.lang.String newAddress) throws RemoteException;
  public int getTotalSeat() throws RemoteException;
  public void setTotalSeat(int newTotalSeat) throws RemoteException;
  public java.lang.String getDescription() throws RemoteException;
  public void setDescription(java.lang.String newDescription) throws RemoteException;
  public java.lang.String getRestaurantID() throws RemoteException;
  public java.lang.String getRestaurantName() throws RemoteException;
  public void setRestaurantName(java.lang.String newRestaurantName) throws RemoteException;
  public java.lang.String getTelephoneNo() throws RemoteException;
  public void setTelephoneNo(java.lang.String newTelephoneNo) throws RemoteException;
}