package busservice;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface ReserveController extends EJBObject {
public ArrayList BookSeat(ArrayList info) throws RemoteException,InvalidRouteIDException ,SeatNotAvailableException, ReserveErrorException , CustomerIDNotExistException;
public String CreateCustomer( String strFirstName ,String strLastName,String  strAddress, String strTelephoneNo) throws CreateException ,RemoteException;
}