package hotelsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface RoomRemote extends EJBObject {
  public void setHotelID(java.lang.String newHotelID) throws RemoteException;
  public int getFloor() throws RemoteException;
  public void setFloor(int newFloor) throws RemoteException;
  public void setNumberOfSingleBed(int newNumberOfSingleBed) throws RemoteException;
  public double getPricePerDay() throws RemoteException;
  public void setPricePerDay(double newPricePerDay) throws RemoteException;
  public java.lang.String getRoomNo() throws RemoteException;
  public java.lang.String getHotelID() throws RemoteException;
  public java.lang.String getDescription() throws RemoteException;
  public void setDescription(java.lang.String newDescription) throws RemoteException;
  public int getNumberOfSingleBed() throws RemoteException;
  public int getRoomClass() throws RemoteException;
  public void setRoomClass(int newRoomClass) throws RemoteException;
  public int getNumberOfCoupleBed() throws RemoteException;
  public void setNumberOfMaximumGuest(int newNumberOfMaximumGuest) throws RemoteException;
  public int getNumberOfMaximumGuest() throws RemoteException;
  public void setNumberOfCoupleBed(int newNumberOfCoupleBed) throws RemoteException;
  public java.lang.String getTelephoneNo() throws RemoteException;
  public void setTelephoneNo(java.lang.String newTelephoneNo) throws RemoteException;
}