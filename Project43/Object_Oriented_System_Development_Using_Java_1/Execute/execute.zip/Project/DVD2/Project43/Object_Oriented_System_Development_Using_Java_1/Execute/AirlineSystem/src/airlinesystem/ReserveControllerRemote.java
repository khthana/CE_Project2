package airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface ReserveControllerRemote extends EJBObject {
public ArrayList BookSeat(ArrayList info) throws RemoteException , ReservationErrorException , CustomerIDNotExistException;
public String CreateCustomer( String strFirstName ,String strLastName,String  strAddress, String strTelephoneNo) throws CreateException, RemoteException;
public ArrayList  viewBooking(String BookingID)  throws CreateException ,RemoteException ;
}