package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookingBMP extends Booking {
  DataSource dataSource;
  public String ejbCreate(String bookingId, Double totalPrice, Timestamp bookingTime, Integer confirmed, java.sql.Date deadline, String memberId, String busGroupBooking, String aircraftGroupBooking, String hotelGroupBookingId) throws CreateException {
	super.ejbCreate(bookingId, totalPrice, bookingTime, confirmed, deadline, memberId, busGroupBooking, aircraftGroupBooking, hotelGroupBookingId);
	try {
	  //First see if the object already exists
	  ejbFindByPrimaryKey(bookingId);
	  //If so, then we have to throw an exception
	  throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	  //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("INSERT INTO BOOKING (BOOKING_ID, TOTAL_PRICE, BOOKING_TIME, CONFIRMED, DEADLINE, MEMBER_ID, BUS_GROUP_BOOKING, AIRCRAFT_GROUP_BOOKING, HOTEL_GROUP_BOOKING_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
	  statement.setString(1, bookingId);
	  statement.setDouble(2, totalPrice.doubleValue());
	  statement.setTimestamp(3, bookingTime);
	  statement.setInt(4, confirmed.intValue());
	  statement.setDate(5, deadline);
	  statement.setString(6, memberId);
	  statement.setString(7, busGroupBooking);
	  statement.setString(8, aircraftGroupBooking);
	  statement.setString(9, hotelGroupBookingId);
	  if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	  return bookingId;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL INSERT INTO BOOKING (BOOKING_ID, TOTAL_PRICE, BOOKING_TIME, CONFIRMED, DEADLINE, MEMBER_ID, BUS_GROUP_BOOKING, AIRCRAFT_GROUP_BOOKING, HOTEL_GROUP_BOOKING_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public String ejbCreate(String bookingId) throws CreateException {
	return ejbCreate(bookingId, null, null, null, null, null, null, null, null);
  }
  public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("DELETE FROM BOOKING WHERE BOOKING_ID = ?");
	  statement.setString(1, bookingId);
	  if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL DELETE FROM BOOKING WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public void ejbLoad() {
	bookingId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("SELECT TOTAL_PRICE, BOOKING_TIME, CONFIRMED, DEADLINE, MEMBER_ID, BUS_GROUP_BOOKING, AIRCRAFT_GROUP_BOOKING, HOTEL_GROUP_BOOKING_ID FROM BOOKING WHERE BOOKING_ID = ?");
	  statement.setString(1, bookingId);
	  ResultSet resultSet = statement.executeQuery();
	  if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	  }
	  totalPrice = new Double(resultSet.getDouble(1));
	  bookingTime = resultSet.getTimestamp(2);
	  confirmed = new Integer(resultSet.getInt(3));
	  deadline = resultSet.getDate(4);
	  memberId = resultSet.getString(5);
	  busGroupBooking = resultSet.getString(6);
	  aircraftGroupBooking = resultSet.getString(7);
	  hotelGroupBookingId = resultSet.getString(8);
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL SELECT TOTAL_PRICE, BOOKING_TIME, CONFIRMED, DEADLINE, MEMBER_ID, BUS_GROUP_BOOKING, AIRCRAFT_GROUP_BOOKING, HOTEL_GROUP_BOOKING_ID FROM BOOKING WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
	super.ejbLoad();
  }
  public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("UPDATE BOOKING SET TOTAL_PRICE = ?, BOOKING_TIME = ?, CONFIRMED = ?, DEADLINE = ?, MEMBER_ID = ?, BUS_GROUP_BOOKING = ?, AIRCRAFT_GROUP_BOOKING = ?, HOTEL_GROUP_BOOKING_ID = ? WHERE BOOKING_ID = ?");
	  statement.setDouble(1, totalPrice.doubleValue());
	  statement.setTimestamp(2, bookingTime);
	  statement.setInt(3, confirmed.intValue());
	  statement.setDate(4, deadline);
	  statement.setString(5, memberId);
	  statement.setString(6, busGroupBooking);
	  statement.setString(7, aircraftGroupBooking);
	  statement.setString(8, hotelGroupBookingId);
	  statement.setString(9, bookingId);
	  if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL UPDATE BOOKING SET TOTAL_PRICE = ?, BOOKING_TIME = ?, CONFIRMED = ?, DEADLINE = ?, MEMBER_ID = ?, BUS_GROUP_BOOKING = ?, AIRCRAFT_GROUP_BOOKING = ?, HOTEL_GROUP_BOOKING_ID = ? WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("SELECT BOOKING_ID FROM BOOKING WHERE BOOKING_ID = ?");
	  statement.setString(1, key);
	  ResultSet resultSet = statement.executeQuery();
	  if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	  return key;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL SELECT BOOKING_ID FROM BOOKING WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	  connection = dataSource.getConnection();
	  statement = connection.prepareStatement("SELECT BOOKING_ID FROM BOOKING");
	  ResultSet resultSet = statement.executeQuery();
	  Vector keys = new Vector();
	  while (resultSet.next()) {
		String bookingId = resultSet.getString(1);
		keys.addElement(bookingId);
	  }
	  statement.close();
	  statement = null;
	  connection.close();
	  connection = null;
	  return keys;
	}
	catch(SQLException e) {
	  throw new EJBException("Error executing SQL SELECT BOOKING_ID FROM BOOKING: " + e.toString());
	}
	finally {
	  try {
		if (statement != null) {
		  statement.close();
		}
	  }
	  catch(SQLException e) {
	  }
	  try {
		if (connection != null) {
		  connection.close();
		}
	  }
	  catch(SQLException e) {
	  }
	}
  }
  public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	  javax.naming.Context context = new javax.naming.InitialContext();
	  dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	  throw new EJBException("Error looking up dataSource:" + e.toString());
	}
  }
  public boolean confirm() {
	if (confirmed.intValue() == 2) {
	  return false;
	}
	else {
	  confirmed = new Integer(1);
	  return true;
	}
  }
  public boolean cancel() {
	if (confirmed.intValue() == 1) {
	  return false;
	}
	else {
	  confirmed = new Integer(2);
	  return true;
	}
  }
}