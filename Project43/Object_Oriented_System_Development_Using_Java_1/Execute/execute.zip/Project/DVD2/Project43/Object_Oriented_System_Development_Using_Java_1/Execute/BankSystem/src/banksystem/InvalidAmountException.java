package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidAmountException extends Exception {

   public InvalidAmountException () { }

   public InvalidAmountException (String msg) {
      super(msg);
   }
}