package busservice;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class ModifyControllerTestClient2 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private ModifyControllerHome modifyControllerHome = null;
  private ModifyControllerRemote modifyControllerRemote = null;

  /**Construct the EJB test client*/
  public ModifyControllerTestClient2() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("ModifyController");

      //cast to Home interface
      modifyControllerHome = (ModifyControllerHome) PortableRemoteObject.narrow(ref, ModifyControllerHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public ModifyControllerRemote create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      modifyControllerRemote = modifyControllerHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + modifyControllerRemote + ".");
    }
    return modifyControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public boolean confirmBooking(String BookingID) {
    boolean returnValue = true;
    if (modifyControllerRemote == null) {
      System.out.println("Error in confirmBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling confirmBooking(" + BookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = modifyControllerRemote.confirmBooking(BookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: confirmBooking(" + BookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: confirmBooking(" + BookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from confirmBooking(" + BookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public boolean CancelBooking(String BookingID) {
    boolean returnValue = true;
    if (modifyControllerRemote == null) {
      System.out.println("Error in CancelBooking(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelBooking(" + BookingID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = modifyControllerRemote.CancelBooking(BookingID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelBooking(" + BookingID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelBooking(" + BookingID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from CancelBooking(" + BookingID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    ModifyControllerTestClient2 client = new ModifyControllerTestClient2();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    client.create();
//    client.CancelBooking("FCA80CA4-FFFF-FFD3-0049-66CC460F4D52");
//    client.confirmBooking("0BC9F940-FFFF-FFD3-006B-AF24DE8BB803");
//    client.CancelBooking("0BC9F940-FFFF-FFD3-006B-AF24DE8BB803");
client.CancelBooking("0BC9F940-FFFF-FFD3-006B-AF24DE8BB803");

  }
}