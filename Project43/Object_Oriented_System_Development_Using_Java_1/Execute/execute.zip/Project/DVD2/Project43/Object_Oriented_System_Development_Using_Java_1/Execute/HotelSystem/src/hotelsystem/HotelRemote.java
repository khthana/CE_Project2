package hotelsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface HotelRemote extends EJBObject {
  public void setDescription(java.lang.String newDescription) throws RemoteException;
  public void setHotelName(java.lang.String newHotelName) throws RemoteException;
  public void setLogo(java.lang.String newLogo) throws RemoteException;
  public void setPassword(java.lang.String newPassword) throws RemoteException;
  public void setAccountId(java.lang.String newAccountId) throws RemoteException;
  public java.lang.String getDescription() throws RemoteException;
  public java.lang.String getHotelID() throws RemoteException;
  public java.lang.String getHotelName() throws RemoteException;
  public int getStar() throws RemoteException;
  public void setTelephoneNo(java.lang.String newTelephoneNo) throws RemoteException;
  public java.lang.String getTelephoneNo() throws RemoteException;
  public java.lang.String getAccountId() throws RemoteException;
  public java.lang.String getPassword() throws RemoteException;
  public java.lang.String getLogo() throws RemoteException;
  public void setHotelPicture(java.lang.String newHotelPicture) throws RemoteException;
  public java.lang.String getHotelPicture() throws RemoteException;
  public void setStar(int newStar) throws RemoteException;
  public void setAddress(java.lang.String newAddress) throws RemoteException;
  public java.lang.String getAddress() throws RemoteException;
  public int getNoOfRooms() throws RemoteException;
}