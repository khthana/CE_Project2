package olalatour;

import airlinesystem.*;
import busservice.*;
import hotelsystem.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.sql.Timestamp;
import java.rmi.RemoteException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class ControllerBean {
	private String sample = "Start value";
	private OlalaAgencyControllerRemote olalaAgencyControllerRemote = null;
	private FullBookingInformation fullBookingInformation = new FullBookingInformation(new ArrayList(), new ArrayList(), new ArrayList(), new ArrayList(), null);
	private java.util.Iterator busBookingInformations = null;
	// Collection of busservice.BookSeatInfo
	private java.util.Iterator hotelBookingInformations = null;
	// Collection of hotelsystem.ReserveHotelInformation
	private java.util.Iterator airlineBookingInformation = null;
	// Collection of airlinesystem.BookSeatInfo
	private java.util.Iterator packageBookingInformation = null;
	// Collection of olalatour.PackageBookingInformation
	private String memberID = null;
//------------------------- AIRLINE ----------------------------------
  private String CustomerID = null;
  private String FirstName = null;
  private String LastName= null;
  private String Address = null;
  private String TelephoneNo= null ;
  private String FlightID  ;
  private int SrcIdx ;
  private int DstIdx;
  private int SeatType;
  private int ClassType;
  private java.sql.Timestamp DepartTime;
  private boolean CanSmoking;
  private double Price;
//------------------------- AIRLINE ----------------------------------
//----------------------------bus------------------------------------
  private int RouteID;
//-----------------------------bus------------------------------------
//-----------------------------hotel---------------------------------
  private java.sql.Date bookCheckInTime;
  private java.sql.Date bookCheckOutTime;
  private String hotelID;
  private double pricePerDay;
  private String description;
  private int numberOfSingleBed;
  private int numberOfCoupleBed;
  private int numberOfMaximumGuest;
  private int roomClass;
  private int numberOfRoom;
//-----------------------------hotel--------------------------------
//----------------------------package ------------------------------
	private String packageID;
	private java.sql.Timestamp departTIme;
	private String travellerID;
//----------------------------package ------------------------------
	/**Access sample property*/
	public String getSample() {
	return sample;
	}
	/**Access sample property*/
	public void setSample(String newValue) {
	if (newValue!=null) {
		sample = newValue;
	}
	}
	synchronized public void addAirlineItem(String CustomerID, String FirstName, String LastName,String Address,String TelephoneNo, String FlightID,int SrcIdx, int DstIdx, int SeatType,int ClassType,java.sql.Timestamp DepartTime, boolean CanSmoking, double Price) {
	System.out.println("addAirlineItem");
	Collection collection = fullBookingInformation.getAirlineBookingInformation();
	collection.add(new airlinesystem.BookSeatInfo(CustomerID, null, null, null, null, FlightID, SrcIdx, DstIdx, SeatType, ClassType, DepartTime, CanSmoking, Price));
	System.out.println("end addAirlineItem");
	}
	synchronized public void addBusItem(String CustomerID, String FirstName, String LastName,String Address,String TelephoneNo,  int RouteID,int SrcIdx, int DstIdx, int SeatType,java.sql.Timestamp DepartTime,double Price) {
	System.out.println("addBusItem");
	Collection collection = fullBookingInformation.getBusBookingInformations();
	collection.add(new busservice.BookSeatInfo(CustomerID, null, null, null, null, RouteID, SrcIdx, DstIdx, SeatType, DepartTime, Price));
	System.out.println("end addBusItem");
	}
	synchronized public void addHotelItem(java.sql.Date bookCheckInTime, java.sql.Date bookCheckOutTime, String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass, int numberOfRoom) {
	System.out.println("addHotelItem");
	Collection collection = fullBookingInformation.getHotelBookingInformations();
	collection.add(new hotelsystem.ReserveHotelInformation(bookCheckInTime, bookCheckOutTime, hotelID, pricePerDay, description, numberOfSingleBed, numberOfCoupleBed, numberOfMaximumGuest, roomClass, numberOfRoom));
	System.out.println("end addHotelItem");
	}
	synchronized public void addPackageItem(String packageID, java.sql.Timestamp departTIme, String travellerID) {
	System.out.println("addPackageItem");
	Collection collection = fullBookingInformation.getPackageBookingInformation();
	collection.add(new olalatour.PackageBookingInformation(packageID, departTIme, travellerID));
	System.out.println("end addPackageItem");
	}
	synchronized public void removeItem(String item, int index) {
	  System.out.println("removeItem");
	  Collection c = null;
	  if (item.equals("airline")) {
	c = fullBookingInformation.getAirlineBookingInformation();
	  }
	  else if (item.equals("bus")){
	c = fullBookingInformation.getBusBookingInformations();
	  }
	  else if (item.equals("hotel")) {
	c = fullBookingInformation.getHotelBookingInformations();
	  }
	  else if (item.equals("package")) {
	c = fullBookingInformation.getPackageBookingInformation();
	  }
	  Iterator it = c.iterator();
	  Object object = null;
	  object = it.next();
	  for (int i = 0; i < index; i++) {
	object = it.next();
	System.out.println("i = " + i + ",  object = " + object.toString());
	  }
	  //it = null;
	  c.remove(object);
	  System.out.println("end removeItem");
	}
  public void connectServer() {
	try {
		//get naming context
		if (olalaAgencyControllerRemote == null) {
		  Context ctx = new InitialContext();
		  System.out.println("initial");

		  //look up jndi name
		  Object ref = ctx.lookup("olalatour/OlalaAgencyController");
		  System.out.println("lookup");

		  //cast to Home interface
		  OlalaAgencyControllerHome olalaAgencyControllerHome = (OlalaAgencyControllerHome)PortableRemoteObject.narrow(ref, OlalaAgencyControllerHome.class);
		  System.out.println("narrow");
		  olalaAgencyControllerRemote = olalaAgencyControllerHome.create();
		  System.out.println("create");
		}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
  }
	synchronized public String reserve() {
	  System.out.println("reserve");
	  connectServer();
	  /** @todo call OlalaAgencyController.reserve(.....) */

//	  try {
//		return olalaAgencyControllerRemote.reserve(fullBookingInformation);
//	  }
//	  catch (Exception ex) {
//
//	  }
//	  return "Not complet";



	  java.util.Random x = new java.util.Random();

	  System.out.println("end reserve");
	  return String.valueOf(x.nextLong());
	}
//    synchronized public String confirm() {
//      System.out.println("confirm");
//      /** @todo call OlalaAgencyController.confirm(.....) */
//
//      System.out.println("end confirm");
//    }
//    synchronized public String cancel() {
//      System.out.println("cancel");
//      /** @todo call OlalaAgencyController.cancel(.....) */
//
//      System.out.println("end cancel");
//    }
//-----------------------------------AIRLINE---------------------------------
  synchronized public boolean nextAirlineItem() {
	System.out.println("nextAirlineItem");
	if (airlineBookingInformation == null) {
		airlineBookingInformation = fullBookingInformation.getAirlineBookingInformation().iterator();
	}
	if (airlineBookingInformation.hasNext()) {
		airlinesystem.BookSeatInfo info = (airlinesystem.BookSeatInfo)airlineBookingInformation.next();
		this.CustomerID = info.getCustomerID();
		this.FlightID = info.getFlightID();
		this.SrcIdx = info.getSrcIdx();
		this.DstIdx = info.getDstIdx();
		this.SeatType = info.getSeatType();
		this.ClassType= info.getClassType();
		this.DepartTime = info.getDepartTime();
		this.CanSmoking= info.getCanSmoking();
		this.Price = info.getPrice();
		System.out.println("end nextAirlineItem");
		return true;
	}
	else {
		airlineBookingInformation = null;
		System.out.println("end nextAirlineItem");
		return false;
	}
	}
  public String getCustomerID() {
	return CustomerID;
  }

  public String getFirstName() {
	return FirstName;
  }

  public String getLastName() {
	return LastName;
  }

  public String getAddress() {
	return Address;
  }

  public String getTelephoneNo() {
	return TelephoneNo;
  }

  public String getFlightID() {
	return FlightID;
  }


  public int getSrcIdx() {
	return SrcIdx;
  }

  public int getDstIdx () {
	return DstIdx ;
  }

 public int getClassType () {
	return ClassType;
  }

  public int getSeatType() {
	return SeatType;
  }

  public java.sql.Timestamp getDepartTime() {
	return DepartTime;
  }

  public boolean getCanSmoking() {
   return CanSmoking;
   }

  public double getPrice() {
	return Price;
  }
//-----------------------------------AIRLINE---------------------------------
//-----------------------------------BUS--------------------------------------
  synchronized public boolean nextBusItem() {
	System.out.println("nextBusItem");
	if (busBookingInformations == null) {
		busBookingInformations = fullBookingInformation.getBusBookingInformations().iterator();
	}
	if (busBookingInformations.hasNext()) {
		busservice.BookSeatInfo info = (busservice.BookSeatInfo)busBookingInformations.next();
		this.CustomerID = info.getCustomerID();
		this.RouteID = info.getRouteID();
		this.SrcIdx = info.getSrcIdx();
		this.DstIdx = info.getDstIdx();
		this.SeatType = info.getSeatType();
		this.DepartTime = info.getDepartTime();
		this.Price = info.getPrice();
		System.out.println("end nextBusItem");
		return true;
	}
	else {
		busBookingInformations = null;
		System.out.println("end nextBusItem");
		return false;
	}
	}
  public int getRouteID() {
	return RouteID;
  }
//-----------------------------------BUS--------------------------------------

// ----------------------------------- Hotel ----------------------------------
  synchronized public boolean nextHotelItem() {
	System.out.println("nextHotelItem");
	if (hotelBookingInformations == null) {
		hotelBookingInformations = fullBookingInformation.getHotelBookingInformations().iterator();
	}
	if (hotelBookingInformations.hasNext()) {
		hotelsystem.ReserveHotelInformation info = (hotelsystem.ReserveHotelInformation)hotelBookingInformations.next();
		this.bookCheckInTime = info.getBookCheckInTime();
		this.bookCheckOutTime = info.getBookCheckOutTime();
		this.hotelID = info.getHotelID();
		this.pricePerDay = info.getPricePerDay();
		this.description = info.getDescription();
		this.numberOfSingleBed = info.getNumberOfSingleBed();
		this.numberOfCoupleBed = info.getNumberOfCoupleBed();
		this.numberOfMaximumGuest = info.getNumberOfMaximumGuest();
		this.roomClass = info.getRoomClass();
		this.numberOfRoom = info.getNumberOfRoom();
		System.out.println("end nextHotelItem");
		return true;
	}
	else {
		hotelBookingInformations = null;
		System.out.println("end nextHotelItem");
		return false;
	}
	}
  public java.sql.Date getBookCheckInTime() {
	return bookCheckInTime;
  }
  public java.sql.Date getBookCheckOutTime() {
	return bookCheckOutTime;
  }
  public String getHotelID() {
	return hotelID;
  }
	public double getPricePerDay() {
	return pricePerDay;
	}
	public String getDescription() {
	return description;
	}
	public int getNumberOfSingleBed() {
	return numberOfSingleBed;
	}
	public int getNumberOfCoupleBed() {
	return numberOfCoupleBed;
	}
	public int getNumberOfMaximumGuest() {
	return numberOfMaximumGuest;
	}
	public int getRoomClass() {
	return roomClass;
	}
	public int getNumberOfRoom() {
	return numberOfRoom;
	}

// ----------------------------------- Hotel ----------------------------------

// ------------------------------------ package ------------------------------
  synchronized public boolean nextPackageItem() {
	System.out.println("nextPackageItem");
	if (packageBookingInformation == null) {
		packageBookingInformation = fullBookingInformation.getPackageBookingInformation().iterator();
	}
	if (packageBookingInformation.hasNext()) {
		olalatour.PackageBookingInformation info = (olalatour.PackageBookingInformation)packageBookingInformation.next();
		this.packageID = info.getPackageID();
		this.departTIme = info.getDepartTIme();
		this.travellerID = info.getTravellerID();
		System.out.println("end nextPackageItem");
		return true;
	}
	else {
		packageBookingInformation = null;
		System.out.println("end nextPackageItem");
		return false;
	}
	}
	public String getPackageID() {
	return packageID;
	}
	public java.sql.Timestamp getDepartTIme() {
	return departTIme;
	}
	public String getTravellerID() {
	return travellerID;
	}

// ------------------------------------package --------------------------------

}