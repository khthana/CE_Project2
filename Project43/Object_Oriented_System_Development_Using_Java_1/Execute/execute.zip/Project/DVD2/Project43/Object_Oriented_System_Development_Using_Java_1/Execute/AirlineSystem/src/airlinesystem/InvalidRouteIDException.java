package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidRouteIDException  extends Exception {

   public InvalidRouteIDException () { }

   public InvalidRouteIDException (String msg) {
      super(msg);
   }
}