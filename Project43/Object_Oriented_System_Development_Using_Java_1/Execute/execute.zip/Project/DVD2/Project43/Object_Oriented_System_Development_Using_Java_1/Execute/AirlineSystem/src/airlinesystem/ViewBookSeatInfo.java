package airlinesystem;
import java.util.ArrayList;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ViewBookSeatInfo  implements java.io.Serializable {


private  String CustomerID;
private String FirstName;
private String LastName;
private  String FlightID;
private java.sql.Timestamp DepartTime;
private String SeatNo;
private double Price;

 public ViewBookSeatInfo( String CustomerID,String FirstName , String LastName, String FlightID ,  java.sql.Timestamp DepartTime, String SeatNo, double price ) {
 this.CustomerID = CustomerID;
 this.FirstName = FirstName;
 this.LastName = LastName;
 this.FlightID = FlightID;
 this.DepartTime = DepartTime;
 this.SeatNo = SeatNo;
 this.Price = Price;
   }



  public String getCustomerID() {
	return CustomerID;
  }

  public String getFirstName()  {
	return  FirstName;
  }

	public String getLastName() {
	return  LastName;
  }

  public String getFlightID() {
	return FlightID;
  }

	public java.sql.Timestamp getDepartTime() {
	return DepartTime;
  }

  public String getSeatNo() {
	return SeatNo;
  }

  public double getPrice() {
	return Price;
  }

}

