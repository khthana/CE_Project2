package hotelsystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class DuplicateTransactionIDException extends Exception {

  public DuplicateTransactionIDException() {
  }
}