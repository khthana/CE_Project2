<%@ page errorPage="BankSystemErrorPage.jsp" %>
<jsp:useBean id="bankSystemBean" scope="page" class="banksystem.BankSystemBean"/>
<head>
<title>Untitled Document</title>
</head>

<body bgcolor="#FFFFFF">
<p><font size="+3">Pay by Credit card :</font><br>
</p>
<form name="form1" >
  <table width="700" border="1">
	<tr>
	  <td>credit card id :
		<input type="text" name="textfield">
	  </td>
	  <td>destination account :
		<input type="text" name="textfield2">
	  </td>
	  <td>amount :
		<input type="text" name="textfield3">
	  </td>
	  <td>
		<input type="submit" name="Submit" value="Submit">
	  </td>
	</tr>
  </table>
  </form>
<hr>
<p><font size="+3"> Pay by Debit card :<br>
  </font> </p>
<form name="form2" >
  <table width="700" border="1">
	<tr>
	  <td>debit card id :
		<input type="text" name="textfield4">
	  </td>
	  <td>destination account :
		<input type="text" name="textfield5">
	  </td>
	  <td>amount :
		<input type="text" name="textfield6">
	  </td>
	  <td>
		<input type="submit" name="Submit2" value="Submit">
	  </td>
	</tr>
  </table>
  </form>
<hr>
<p> <font size="+3">Transfer :</font></p>
<form name="form3" >
  <table width="700" border="1">
	<tr>
	  <td>source account id :
		<input type="text" name="textfield7">
	  </td>
	  <td>destination id :
		<input type="text" name="textfield8">
	  </td>
	  <td>amount :
		<input type="text" name="textfield9">
	  </td>
	  <td>amount :
		<input type="text" name="textfield9">
	  </td>
	  <td>
		<input type="submit" name="Submit3" value="Submit">
	  </td>
	</tr>
  </table>
  </form>
<hr>
<p><font size="+3">result :</font></p>
<%
  String submit = request.getParameter("Submit");
  String submit2 = request.getParameter("Submit2");
  String submit3 = request.getParameter("Submit3");
  String transactionID = null;

  bankSystemBean.init();

  if (submit == null)
	submit = "";
  if (submit2 == null)
	submit2 = "";
  if (submit3 == null)
	submit3 = "";

  if (submit.equals("Submit")) {
	try {
	  transactionID = bankSystemBean.payByCreditCardID(request.getParameter("textfield"), request.getParameter("textfield2"), Double.parseDouble(request.getParameter("textfield3")));
	}
	catch (Exception ex) {
	  out.print(ex.getMessage());
	}
	out.print("pay by credit success. TransactionID is : " + transactionID);
  }
  else if (submit2.equals("Submit")) {
	try {
	  transactionID = bankSystemBean.payByDebitCardID(request.getParameter("textfield4"), request.getParameter("textfield5"), Double.parseDouble(request.getParameter("textfield6")));
	}
	catch (Exception ex) {
	  out.print(ex.getMessage());
	}
	out.print("pay by debit success. TransactionID is : " + transactionID);
  }
  else if (submit3.equals("Submit")) {
	try {
	  transactionID = bankSystemBean.transfer(request.getParameter("textfield7"), request.getParameter("textfield8"), Double.parseDouble(request.getParameter("textfield9")));
	}
	catch (Exception ex) {
	  out.print(ex.getMessage());
	}
	out.print("Transfer success. TransactionID is : " + transactionID);
  }
%>



</body>
</html>
