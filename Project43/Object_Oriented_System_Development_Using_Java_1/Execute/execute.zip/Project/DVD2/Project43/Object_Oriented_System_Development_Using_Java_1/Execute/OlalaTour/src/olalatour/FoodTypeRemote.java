package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface FoodTypeRemote extends EJBObject {
    String getFoodTypeId() throws RemoteException;
    String getFoodTypeName() throws RemoteException;
    void setFoodTypeName(String foodTypeName) throws RemoteException;
    String getFoodTypeDetail() throws RemoteException;
    void setFoodTypeDetail(String foodTypeDetail) throws RemoteException;
}