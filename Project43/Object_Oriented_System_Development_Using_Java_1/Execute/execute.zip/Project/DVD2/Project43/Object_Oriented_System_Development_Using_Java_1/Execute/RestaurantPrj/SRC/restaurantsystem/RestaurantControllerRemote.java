package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface RestaurantControllerRemote extends EJBObject {
  public Collection findRestaurant(String name, String description, String address, int star) throws RemoteException;
  public FullRestaurantInformation viewRestaurant(String restaurantID) throws RemoteException;
  public FullBookingInformation viewBooking(String bookingID) throws RemoteException;
  public String reserve(String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, String agencyID) throws RemoteException, InvalidRestaurantException, InvalidMealException,
	  SeatNotAvailableException, InvalidAgentException;
  public void confirm(String bookingID) throws RemoteException, AlreadyCancelException;
  public void cancel(String bookingID) throws RemoteException, AlreadyConfirmException;
  public void modify(java.lang.String bookingID, java.lang.String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, java.lang.String agencyID) throws InvalidRestaurantException, InvalidMealException, SeatNotAvailableException, InvalidAgentException, RemoteException, AlreadyCancelException, AlreadyConfirmException;
}