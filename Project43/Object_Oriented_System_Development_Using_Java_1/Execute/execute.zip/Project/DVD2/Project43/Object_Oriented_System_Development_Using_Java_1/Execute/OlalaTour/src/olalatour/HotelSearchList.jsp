<%@ page errorPage="Jsp1ErrorPage.jsp" %>
<html>
<head>
<jsp:useBean id="viewerBean" scope="page" class="olalatour.ViewerBean" />
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<title>Search result</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<%
  String submit = request.getParameter("submit");
	if (submit != null) {
	  if (submit.equals("hotel")) {
		out.print("hotel");
		  String strBookCheckInTimeDay = request.getParameter("BookCheckInTimeDay");
		  String strBookCheckInTimeMonth = request.getParameter("BookCheckInTimeMonth");
		  String strBookCheckInTimeYear = request.getParameter("BookCheckInTimeYear");
		  String strBookCheckOutTimeDay = request.getParameter("BookCheckOutTimeDay");
		  String strBookCheckOutTimeMonth = request.getParameter("BookCheckOutTimeMonth");
		  String strBookCheckOutTimeYear = request.getParameter("BookCheckOutTimeYear");
		  String strHotelID = request.getParameter("HotelID");
		  String strPricePerDay = request.getParameter("PricePerDay");
		  String strDescription = request.getParameter("Description");
		  String strNumberOfSingleBed = request.getParameter("NumberOfSingleBed");
		  String strNumberOfCoupleBed = request.getParameter("NumberOfCoupleBed");
		  String strNumberOfMaximumGuest = request.getParameter("NumberOfMaximumGuest");
		  String strRoomClass = request.getParameter("RoomClass");
		  String strNumberOfRoom = request.getParameter("NumberOfRoom");

		  out.print("getParameter");
		  java.sql.Date BookCheckInTime = new java.sql.Date(Integer.parseInt(strBookCheckInTimeYear), Integer.parseInt(strBookCheckInTimeMonth), Integer.parseInt(strBookCheckInTimeDay));
		  java.sql.Date BookCheckOutTime = new java.sql.Date(Integer.parseInt(strBookCheckOutTimeYear), Integer.parseInt(strBookCheckOutTimeDay), Integer.parseInt(strBookCheckOutTimeDay));

		  out.print("call addHotelItem");
		  controllerBean.addHotelItem(BookCheckInTime, BookCheckOutTime, strHotelID, Double.parseDouble(strPricePerDay), strDescription, Integer.parseInt(strNumberOfSingleBed), Integer.parseInt(strNumberOfCoupleBed), Integer.parseInt(strNumberOfMaximumGuest), Integer.parseInt(strRoomClass), Integer.parseInt(strNumberOfRoom));
	  }
	}
%>

<%
	String strSubmit = request.getParameter("Submit");
	if (!strSubmit.equals("SearchHotel")) {%>
	error !!!
<%
	}
	else {
	String strHotelName = request.getParameter("hotelName");
	String strDescription = request.getParameter("description");
	String strAddress = request.getParameter("address");
	String strStar = request.getParameter("star");
	String strBookCheckInDateDay = request.getParameter("BookCheckInDateDay");
	String strBookCheckInDateMonth = request.getParameter("BookCheckInDateMonth");
	String strBookCheckInDateYear = request.getParameter("BookCheckInDateYear");
	String strBookCheckOutDateDay = request.getParameter("BookCheckOutDateDay");
	String strBookCheckOutDateMonth = request.getParameter("BookCheckOutDateMonth");
	String strBookCheckOutDateYear = request.getParameter("BookCheckOutDateYear");


	if (strHotelName == null) {
		strHotelName = "";
	}
	if (strDescription == null) {
		strDescription = "";
	}
	if (strAddress == null) {
		strAddress = "";
	}
	if (strStar == null) {
		strStar = "500";
	}
	viewerBean.findHotel(strHotelName, strDescription, strAddress, Integer.parseInt(strStar));
%>

<table width="750" border="1">
  <tr>
	<td> <% out.print(viewerBean.getHotelLogo() + "&nbsp;" + viewerBean.getHotelName() + "&nbsp;" + viewerBean.getNoOfRooms() + "&nbsp;" + viewerBean.getStar());%></td>
  </tr>
  <tr>
	<td>
	<% while (viewerBean.nextRoom()) {%>
	  <table width="100%" border="1">
	<tr>
	  <td rowspan="6" colspan="2">
		<div align="center"></div>
		<div align="center"><img src="images/LogoHotelList.gif" width="55" height="55"><br>
		  <a href="HotelSearchList.jsp?<%=request.getQueryString()%>&BookCheckInTimeDay=<%=strBookCheckInDateDay%>&BookCheckInTimeMonth=<%=strBookCheckInDateMonth%>&BookCheckInTimeYear=<%=strBookCheckInDateYear%>&BookCheckOutTimeDay=<%=strBookCheckOutDateDay%>&BookCheckOutTimeMonth=<%=strBookCheckOutDateMonth%>&BookCheckOutTimeYear=<%=strBookCheckOutDateYear%>&HotelID=<%=viewerBean.getHotelID()%>&PricePerDay=<%=viewerBean.getPricePerDay()%>&Description=<%=viewerBean.getDescription()%>&NumberOfSingleBed=<%=viewerBean.getNumberOfSingleBed()%>&NumberOfCoupleBed=<%=viewerBean.getNumberOfCoupleBed()%>&NumberOfMaximumGuest=<%=viewerBean.getNumberOfMaximumGuest()%>&RoomClass=<%=viewerBean.getRoomClass()%>&NumberOfRoom=1&submit=hotel">ReserveRoom</a><a href="HotelSearchDetail.htm"><br>
		  </a></div>
	  </td>
	  <td width="568"> roomClass = <%=viewerBean.getRoomClass()%></td>
	</tr>
	<tr>
	  <td width="568">numberOfSingleBed = <%=viewerBean.getNumberOfSingleBed()%>, numberOfCoupleBed = <%=viewerBean.getNumberOfCoupleBed()%>, numberOfMaximumGuest = <%=viewerBean.getNumberOfMaximumGuest()%></td>
	</tr>
	<tr>
	  <td width="568">description = <%=viewerBean.getDescription()%></td>
	</tr>
	<tr>
	  <td rowspan="3" width="568">pricePerDay = <%=viewerBean.getPricePerDay()%></td>
	</tr>
	<tr> </tr>
	<tr> </tr>
	  </table>
	  <%}%>

	</td>
  </tr>
</table>
<%
	}
%>
</body>
</html>
