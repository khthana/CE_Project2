<table width="750" border="1">
  <tr> 
    <td  colspan="5"> 
      <table width="100%" border="1" height="100%">
        <tr> 
          <td width="96%"> 
            <div align="center"><b><font size="7">OLALA TOUR</font></b></div>
          </td>
          <td valign="bottom" colspan="2" width="4%"> 
            <div align="center"></div>
            <div align="center"><img src="images/cart.jpg" width="26" height="19"><br>
              <a href="ViewCart.jsp">ViewCart</a> </div>
            </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td>
      <table width="100%" border="1">
        <tr> 
          <td width="25%"> 
            <div align="center"><img src="images/Airline.JPG" width="128" height="42"><br>
              <a href="AirSeatSearch.jsp">Airline Booking</a></div>
          </td>
          <td width="25%"> 
            <div align="center"><img src="images/Bus.gif" width="80" height="60"><br>
              <a href="BusSearch.jsp">Bus Booking</a></div>
          </td>
          <td width="25%"> 
            <div align="center"><img src="images/Hotel.jpg" width="59" height="60"><br>
              <a href="HotelSearch.jsp">Hotel Booking</a></div>
          </td>
          <td width="25%"> 
            <div align="center"><img src="images/Package.jpg" width="80" height="69"><br>
              <a href="PackageSearch.jsp">Package Booking</a></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  </table>