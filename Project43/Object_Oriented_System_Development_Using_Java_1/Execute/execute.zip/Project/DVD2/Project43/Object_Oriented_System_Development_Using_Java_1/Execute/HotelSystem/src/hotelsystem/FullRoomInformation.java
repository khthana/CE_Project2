package hotelsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullRoomInformation implements Serializable {

  public FullRoomInformation(double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass) {
	this.description = description;
	this.numberOfSingleBed = numberOfSingleBed;
	this.numberOfCoupleBed = numberOfCoupleBed;
	this.numberOfMaximumGuest = numberOfMaximumGuest;
	this.roomClass = roomClass;
	this.pricePerDay = pricePerDay;
  }
  private double pricePerDay;
  private String description;
  private int numberOfSingleBed;
  private int numberOfCoupleBed;
  private int numberOfMaximumGuest;
  private int roomClass;
  public double getPricePerDay() {
	return pricePerDay;
  }
  public String getDescription() {
	return description;
  }
  public int getNumberOfSingleBed() {
	return numberOfSingleBed;
  }
  public int getNumberOfCoupleBed() {
	return numberOfCoupleBed;
  }
  public int getNumberOfMaximumGuest() {
	return numberOfMaximumGuest;
  }
  public int getRoomClass() {
	return roomClass;
  }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
}