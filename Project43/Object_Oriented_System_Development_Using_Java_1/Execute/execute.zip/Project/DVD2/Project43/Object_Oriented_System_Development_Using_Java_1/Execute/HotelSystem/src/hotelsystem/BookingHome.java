package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingHome extends EJBHome {
    public BookingRemote create(String bookingId, Timestamp bookingTime, Integer confirm, Double price, String transactionId, String customerId) throws RemoteException, CreateException;
    public BookingRemote create(String bookingId) throws RemoteException, CreateException;
    public BookingRemote create(String bookingId, String customerId) throws RemoteException, CreateException;
    public BookingRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
}