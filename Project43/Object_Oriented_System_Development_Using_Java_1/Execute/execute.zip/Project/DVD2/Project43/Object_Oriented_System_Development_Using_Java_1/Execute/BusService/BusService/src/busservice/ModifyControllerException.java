package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ModifyControllerException extends Exception {

   public ModifyControllerException() { }

   public ModifyControllerException(String msg) {
      super(msg);
   }
}
