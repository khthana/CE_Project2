package banksystem;

import java.rmi.RemoteException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BankSystemBean {
  private String sample = "Start value";
  private BankControllerHome bankControllerHome = null;
  private BankControllerRemote bankControllerRemote = null;

  /**Access sample property*/
  public String getSample() {
	return sample;
  }
  /**Access sample property*/
  public void setSample(String newValue) {
	if (newValue!=null) {
	  sample = newValue;
	}
  }
  public void init() {
	try {
		//get naming context
		Context ctx = new InitialContext();
		System.out.println("initial");

		//look up jndi name
		Object ref = ctx.lookup("banksystem/BankController");
		System.out.println("lookup");

		//cast to Home interface
		bankControllerHome = (BankControllerHome)PortableRemoteObject.narrow(ref, BankControllerHome.class);
		System.out.println("narrow");
		bankControllerRemote = bankControllerHome.create();
		System.out.println("create");
	}
	catch(Exception e) {
		e.printStackTrace();
	}

  }
  public String transfer(java.lang.String accountIDSource, java.lang.String relateAccountID, double amount, String password) throws InvalidPasswordException, InvalidAccountException, AccountNotExistException, InsufficientBalanceException, RemoteException, InvalidAmountException, BankControllerException {
	return bankControllerRemote.transfer(accountIDSource, relateAccountID, amount, password);
  }
  public String payByDebitCardID(String debitCardID, String relateAccountID, double amount)  throws  RemoteException, InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException ,InvalidAmountException {
	return bankControllerRemote.payByDebitCardID(debitCardID, relateAccountID, amount);
  }
  public String payByCreditCardID(String creditCardID, String relateAccountID, double amount) throws  RemoteException, InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException ,InvalidAmountException {
	return bankControllerRemote.payByCreditCardID(creditCardID, relateAccountID, amount);
  }





}