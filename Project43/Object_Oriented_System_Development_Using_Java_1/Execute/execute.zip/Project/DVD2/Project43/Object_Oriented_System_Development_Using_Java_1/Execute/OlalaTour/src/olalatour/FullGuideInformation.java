package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullGuideInformation implements Serializable {

    public FullGuideInformation(String guideID, String firstName, String lastName, int gender, String spokenLanguage, String officeAddress) {
	this.guideID = guideID;
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
	this.spokenLanguage = spokenLanguage;
	this.officeAddress = officeAddress;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getGuideID() {
	return guideID;
    }
    public String getFirstName() {
	return firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public int getGender() {
	return gender;
    }
    public String getSpokenLanguage() {
	return spokenLanguage;
    }
    public String getOfficeAddress() {
	return officeAddress;
    }
    private String guideID;
    private String firstName;
    private String lastName;
    private int gender;
    private String spokenLanguage;
    private String officeAddress;
}