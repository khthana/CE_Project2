<%@ page import="olalatour.BusSearchBean" %>
<jsp:useBean id="bussearchbean" scope="page" class="olalatour.BusSearchBean" />
<jsp:setProperty name="bussearchbean" property="*" />

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function LinkToBusSearchList(NumberTraveller,PlaceFrom,PlaceTo,Month,Year,Day,Time,CompanyName,BusType,SeatPosition) {
	 window.navigate("BusSearchList.jsp?strNumberTraveller=" + NumberTraveller + "&strPlaceFrom=" + PlaceFrom + 	"&strPlaceTo=" + PlaceTo +	 "&strMonth=" + Month + "&strYear=" + Year + "&strDay=" + Day + "&strTime=" + Time + "&strCompanyName=" + CompanyName + "&strBusType=" + BusType + "&strSeatPosition=" + SeatPosition);
  }	

 function ShowCountryList(Country) {
       window.navigate("CountryList.jsp?strCountry="+Country);
  }
 function radio_onclickDisable(Choice1, Choice2, Choice3) {
			 Choice1.disabled = true;		
			 Choice2.disabled = true;		
			 Choice3.disabled = true;		
  }
  function radio_onclickEnable(Choice1, Choice2, Choice3) {
			 Choice1.disabled = false;		
		         Choice2.disabled = false;		
			 Choice3.disabled = false;		
  }
  function Year(Year,Month,selectDay) {
		imonth = parseInt(Month); 
		selectDay.options.length = 0;

		if ((Year== "2004" || Year =="2008") && (imonth == 2)){
					selectDay.options.length = 0;
					i = 0;
					for( ; i < 29 ; i++) {
							selectDay.options[i] = new Option(i+1,i+1);
					}
		} 
		else if (imonth == 1 || imonth == 3 || imonth == 5 || imonth == 7 || imonth == 8 || imonth == 10 || imonth == 12 ) {
									i1= 0;
									for( ; i1 < 31; i1++) {
										selectDay.options[i1] = new Option(i1+1,i1+1);				
									}
		} 
		else if (imonth == 2) {
									i2 = 0;
									for( ; i2 < 28; i2++) {
										selectDay.options[i2] = new Option(i2+1,i2+1);				
									}
		}
		else if (imonth == 4 || imonth == 6 || imonth == 9 || imonth == 11) {
									i3 = 0;
									for( ; i3 < 30; i3++) {
										selectDay.options[i3] = new Option(i3+1,i3+1);				
									}
		}
  }
  function Month(Year,Month, selectDay) {	 
			imonth = parseInt(Month); 
			selectDay.options.length = 0;
		if ((Year== "2004" || Year =="2008") && (imonth == 2)){
					selectDay.options.length = 0;
					i = 0;
					for( ; i < 29 ; i++) {
							selectDay.options[i] = new Option(i+1,i+1);
					}
		} 
		else if (imonth == 1 || imonth == 3 || imonth == 5 || imonth == 7 || imonth == 8 || imonth == 10 || imonth == 12 ) {
									i1= 0;
									for( ; i1 < 31; i1++) {
										selectDay.options[i1] = new Option(i1+1,i1+1);				
									}
		} 
		else if (imonth == 2) {
									i2 = 0;
									for( ; i2 < 28; i2++) {
										selectDay.options[i2] = new Option(i2+1,i2+1);				
									}
		}
		else if (imonth == 4 || imonth == 6 || imonth == 9 || imonth == 11) {
									i3 = 0;
									for( ; i3 < 30; i3++) {
										selectDay.options[i3] = new Option(i3+1,i3+1);				
									}
		}
	}

//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<table width="700" border="1">
  <tr>
    <td height="50"> 
      <table width="100%" border="1" height="50">
        <tr> 
          <td height="45" width="25%"><b><font size="5">OLALA TOUR</font></b></td>
          <td height="45" width="75%"><font size="4">BUS SEARCH</font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="50">
      <table width="100%" border="1" height="50">
        <tr> 
          <td width="36%"> 
            <form method="post" action="">
              Search 
              <input type="text" name="textfield">
              <input type="submit" name="Submit" value="GO">
            </form>
          </td>
          <td width="64%">
            <table width="100%" border="1" height="100%">
              <tr> 
                <td width="70%"> 
                  <div align="right"></div>
                </td>
                <td width="16%"> 
                  <div align="center"><img src="photocart2.jpg" width="26" height="19"><br>
                    <a href="Cart.htm">ViewCart</a> </div>
                </td>
                <td width="14%"> 
                  <div align="center"><img src="home.gif" width="20" height="20"><br>
                    <a href="olalatour.htm">Home </a></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="30"> 
      <table width="100%" border="1" height="30">
        <tr> 
          <td width="16%">Airline Booking</td>
          <td width="13%">Bus Booking</td>
          <td width="15%">Hotel Booking</td>
          <td width="18%">Package Booking</td>
          <td width="16%">LocationSearch </td>
          <td colspan="2" width="22%">Place&amp;ActivitySearch</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="513"> 
      <table width="100%" border="1">
        <tr> 
          <td width="30%"><b><font size="5">Weather<br>
            </font></b> 
            <table width="200" border="1">
              <tr> 
                <td width="78%" height="15"><font size="2">London,UK 30-34.5F</font></td>
                <td width="22%"> 
                  <div align="center"><b><font size="5"><img src="weather1.gif" width="32" height="24"></font></b></div>
                </td>
              </tr>
              <tr> 
                <td width="78%" height="15"><font size="3">Ban<font size="2">gkok,TH 
                  21-25F</font></font></td>
                <td width="22%" height="15"> 
                  <div align="center"><b><img src="weather2.gif" width="32" height="24"></b></div>
                </td>
              </tr>
              <tr> 
                <td width="78%" height="15"><font size="2">Tokyo,Ja 5-10F</font><font size="5"></font><b><font size="5"><br>
                  </font></b></td>
                <td width="22%" height="15"> 
                  <div align="center"><img src="weather3.gif" width="32" height="24"></div>
                </td>
              </tr>
            </table>
          </td>

          <td width="70%" rowspan="2">One Way |<a href="BusSearchRoundTrip.htm"> RoundTrip </a>
		<form name="form1" method="get">
		       <font size="5"><b>Fill Data For Bus Search</b></font> 
		              <table width="100%" border="0">
				<tr> 
					  <td colspan="2"><b>How many of passengers?</b> *</td>
				</tr>

		                <tr> 
					<td width="57%"> 
			                    <div align="right">Total number of travellers?</div>
					</td>
					<td width="43%"> 
			                    <select name="selectNumberTraveller">
							<option value="1" selected>1</option>
							<option value="2">	2</option>
							<option value="3">	3</option>
			                    </select>
			                </td>
				</tr>
			    </table>
              <b> </b> 

			    <table width="100%" border="0" height="71">
		                <tr>
					  <td colspan="3"><b>Where would you like to go?(Internal Country)  * </b></td>
		                </tr>
				<tr> 
			                  <td colspan="3">
						
                    <div align="center"><b> <!--RECIEVE COUNTRY CODE FROM COUNTRYLIST.JSP --> 
                      <%	String  countrycode = " ";
									countrycode = request.getParameter("strCountryCode");
							%> <!--BUTTON CHOOSE COUNTRY ....LINK TO COUNTRY LIST.... --> 
                      <select name="selectCountry">
                        <option value="Thailand" selected>Thailand</option>
                      </select>
                    </div>
			                  </td>
		                </tr>
				<tr> 
			                  <td width="129"> 
				                    <div align="right">From : </div>
			                  </td>
			                  <td width="234"> 
				                 
                    <div align="center"><b> 
                      <select name="selectPlaceFrom">
                        <option  value="Bangkok" selected>Bangkok</option>
                        <option  value="Saraburi">Saraburi</option>
                      </select>
                      </b> </div>

			                  </td>
			                  <td width="113">&nbsp; </td>
		                </tr>
				<tr> 
			                  <td colspan="3" height="2"> 
				                    <blockquote> 
				                    <blockquote> 
				                    <blockquote> 
				                    <blockquote> 
			                            
                            <p>&nbsp; </p>
					                        </blockquote>
					                        </blockquote>
						                </blockquote>
						                </blockquote>
					 </td>
		              </tr>
		              <tr> 
			                  <td width="129" height="2"> 
				                    <div align="right">To : </div>
			                  </td>
			                  <td width="234" height="2"> 
				                 
                    <div align="center"><b> 
                      <select name="selectPlaceTo">
                        <option  value="Bangkok" selected>Bangkok</option>
                        <option  value="Saraburi">Saraburi</option>
                      </select>
                      </b> </div>

			                  </td>
			                  <td width="113" height="2">&nbsp;</td>
		             </tr>
		             <tr> 
			                  <td colspan="3" height="2"> 
				                    <blockquote> 
				                    <blockquote> 
				                    <blockquote> 
				                    <blockquote> 
			                            
                            <p>&nbsp; </p>
						    </blockquote>
				                    </blockquote>
				                    </blockquote>
				                    </blockquote>
			               </td>
	                </tr>
		    </table>

	              <div align="center">You can go on any day that lowest fare? If so,stop here<br>
		                By clicking "Show me Buses", you indicate that you agree to the following <br>
						<!--BUTTON SHOW ME BUS ....LINK TO BUS SEARCH LIST.... -->
					   <input type="button" name="buttonShowMeBus1" value="Show Me Bus" 
					   onclick="LinkToBusSearchList(selectNumberTraveller.value,selectPlaceFrom.value,selectPlaceTo.value,null,null,null,null,null,null,null)">			   
   				</div>

		      <table width="500" border="0">
		                <tr> 
					  <td><b>When would you like to go?</b></td>
		                </tr>
				<tr> 
			                  <td> 
				                 <table width="100%" border="0" height="87">
					               <tr> 
					                        <td colspan="7" height="30"> 
						                          <div align="right">Departing : </div>
					                        </td>
					                        <td width="70" height="30"> 
						                          <select name="selectMonth" onChange="Month(selectYear.value,selectMonth.value,selectDay)">
							                            <option value="1"selected>January</option>
							                            <option value="2">		Febuary</option>
													    <option value="3">		March</option>
									                    <option value="4">		April</option>
													    <option value="5">		May</option>
													    <option value="6">		June</option>
													    <option value="7">		July</option>
										                <option value="8">		August</option>
												        <option value="9">		September</option>
													    <option value="10">		October</option>
													    <option value="11">		November</option>
													    <option value="12">		December</option>
						                          </select>
					                        </td>
					                        <td height="30" width="45"> 
						                          <select name="selectYear" onChange="Year(selectYear.value,selectMonth.value,selectDay)">
							                            <option value="2001"selected>2001</option>
													    <option value="2002">		 2002</option>
													    <option value="2003">         2003</option>
									            	    <option value="2004">         2004</option>
						                          </select>
					                        </td>
					                        <td height="30" width="270"> 
						                          <select name="selectDay">
							                            <option value="1"selected>1</option>
						                          </select>
					                        </td>
							</tr>
							<tr> 
					                        <td colspan="7" height="26"> 
						                          <div align="right">Time : </div>
					                        </td>
					                        <td height="26" colspan="3"> 
						                          <select name="selectTime">
							                          <option value="1:00am" selected>1:00 am</option>
											          <option value="2:00am" >2:00 am</option>
				 									  <option value="3:00am" >3:00 am</option>
											          <option value="4:00am" >4:00 am</option>
													  <option value="5:00am" >5:00 am</option>
											          <option value="6:00am">6:00 am</option>
													  <option value="7:00am">7:00 am</option>
													  <option value="8:00am">8:00 am</option>
													  <option value="9:00am">9:00 am</option>
													  <option value="10:00am">10:00 am</option>
										              <option value="11:00am">11:00 am</option>
													  <option value="12:00am">12:00 am</option>
													  <option value="1:00pm" >1:00 pm</option>                        
													  <option value="2:00pm">2:00 pm</option>                        
													  <option value="3:00pm">3:00 pm</option>                        
													  <option value="4:00pm">4:00 pm</option>                        
													  <option value="5:00pm">5:00 pm</option>                        
													  <option value="6:00pm">6:00 pm</option>                        
													  <option value="7:00pm">7:00 pm</option>                        
													  <option value="8:00pm">8:00 pm</option>                        
													  <option value="9:00pm">9:00 pm</option>                        
													  <option value="10:00pm">10:00 pm</option>                        
													  <option value="11:00pm">11:00 pm</option>                        
													  <option value="12:00pm">12:00 pm</option>   
						                          </select>
					                        </td>
				                       </tr>
						</table>                 
					</td>
				</tr>
			</table>
	                <table width="100%" border="0" height="81">
				<tr> 
			                  <td colspan="3" height="22"><b>What bus company do you like prefer?</b></td>
		                </tr>											
				<tr> 
			                  <td width="52" height="24">&nbsp;</td>				          
			                  <td height="24" width="345"> 
				                    <select name="selectBusCompany"  size="1">
					                      <option value="Surachai Bus" selected>Surachai Bus</option>
				                    </select>
			                  </td>
		                </tr>			
	               </table>
		       <table width="100%" border="0">
				<tr> 
			                  <td colspan="2"><b>Optional</b></td>
		                </tr>
				<tr> 
			                  <td width="26%"> 
				                    <div align="right">Bus Type : </div>
			                  </td>
			                  <td width="74%"> 
				                    <select name="selectBusType">
					                      <option value="Show me all buses" selected>Show me all buses</option>
					                      <option value="P1 VIP"> P1 VIP </option>
					                      <option value="P1">P1</option>
										  <option value="P2">P2</option>
				                    </select>
			                  </td>
		                </tr>
				<tr> 
			                  <td width="26%"> 
				                    <div align="right">Seat Position :</div>
			                  </td>
			                  <td width="74%"> 
				                    <select name="selectSeatPosition">
					                      <option value="Any Position" selected>Any Position</option>
					                      <option value="Near Window"> Near Window</option>
 					                      <option value="Aisel">Aisel</option>
				                    </select>
			                  </td>
		                </tr>
			</table>
			<div align="center"> 
		                <table width="100%" border="0">
					<tr> 
			                    <td width="95%"> 
				                      <div align="center"> 
					<!--BUTTON SHOW ME BUS -->
						<input type="button" name="buttonShowMeBus2" value="Show Me Bus"
							onclick="LinkToBusSearchList(selectNumberTraveller.value,selectPlaceFrom.value,selectPlaceTo.value,selectMonth.value,selectYear.value,selectDay.value,selectTime.value,selectBusCompany.value,selectBusType.value,selectSeatPosition.value)">		
							

	        </div>
			            </td>
					    <td width="5%"> 
				                      <div align="right"><a href="file:///C%7C/My%20Documents/Project/New%20Folder/olalatour2.html"><img src="file:///C%7C/My%20Documents/Project/New%20Folder/home.gif" width="20" height="20" border="0"></a></div>
			                    </td>
			               </tr>
		                </table>
	               </div>
            </form>
          </td>
        </tr>

        <tr>
		<td width="30%" valign="top"><b><font size="5">Calender<br></font></b> 
	            <table width="100%" border="1">
			<tr> 
			        <td height="15" colspan="7"> 
			                  <form name="form2">
				                    <div align="center"><font size="2"> </font> 
					                      <select name="select15" onChange="MM_jumpMenu('parent',this,0)">
						                        <option selected>January</option>
						                        <option>February</option>
						                        <option>March</option>
						                        <option>April</option>
					                      </select>
					                      <select name="select16" onChange="MM_jumpMenu('parent',this,0)">
						                        <option selected>2001</option>
						                        <option>2002</option>
						                        <option>2003</option>
					                      </select>
				                    </div>
			                  </form>
		                </td>
			</tr>
		        <tr> 
		                <td>Su </td>
				<td>Mo</td>
		                <td>Tu</td>
		                <td>We</td>
		                <td>Th</td>
		                <td>Fr</td>
		                <td>Sa</td>
			</tr>
			<tr> 
		                <td>&nbsp;</td>
		                <td>&nbsp;</td>
				<td>&nbsp;</td>
		                <td>1</td>
				<td>2</td>
				<td>3</td>
				<td>4</td>
			</tr>
			<tr> 
		                <td>5</td>
				<td>6</td>
		                <td>7</td>
				<td>8</td>
		                <td>9</td>
				<td>10</td>
		                <td>11</td>
			</tr>
		        <tr> 
		                <td>12</td>
				<td>13</td>
		                <td>14</td>
				<td>15</td>
		                <td>16</td>
				<td>17</td>
		                <td>18</td>
			</tr>
	                <tr> 
		                <td>19</td>
				<td>20</td>
		                <td>21</td>
				<td>22</td>
		                <td>23</	td>
				<td>24</td>
		                <td>25</td>
		       </tr>
	               <tr> 
		                <td>26</td>
				<td>27</td>
		                <td>28</td>
				<td>29</td>
		                <td>30</td>
				<td>31</td>
		                <td>&nbsp;</td>
			</tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
