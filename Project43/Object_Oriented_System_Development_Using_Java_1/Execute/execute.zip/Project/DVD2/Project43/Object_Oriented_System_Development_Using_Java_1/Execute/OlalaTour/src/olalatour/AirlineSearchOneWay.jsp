<%@ page import="olalatour.AirlineSearchBean"%>
<jsp:useBean id="airlinesearchbean" scope="page" class="olalatour.AirlineSearchBean" />
<jsp:setProperty name="airlinesearchbean" property="*" />

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<SCRIPT LANGUAGE=javascript>
<!--
function LinkToAirlineSearchList(NumTraveller,NumChildren,
								StartAirportID,StartAirportName,StopAirportID,StopAirportName,
								Month,Year,Day,Time,	AirlineClass,radioNonStopFlight,AirlineName,SeatPosition) {

	window.navigate("AirlineSearchList.jsp?strNumTraveller" +NumTraveller+ "&strNumChildren" +NumChildren+ 
				"&strStartAirportID" +StartAirportID+ "&strStartAirportName" +StartAirportName + 
				"&strStopAirport" +StopAirport+ "&strStopAirportName" +StopAirportName +
				"&strMonth" +Month+ "&strYear" +Year+ "&strDay" +Day+ "&strTime" +Time + 
				"&strAirlineClass" +AirlineClass+ "&bRadioNonStopFlight" +RadioNonStopFlight +
				"&strAirlineName" +AirlineName+ "&strSeatPosition" +SeatPosition);
}
function ShowAirportList(Airport) {      
       window.navigate("AirportList.jsp?strAirport="+Airport);
    }
function Year(Year,Month,selectDay) {
		imonth = parseInt(Month); 
		selectDay.options.length = 0;

		if ((Year== "2004" || Year =="2008") && (imonth == 2)){
					selectDay.options.length = 0;
					i = 0;
					for( ; i < 29 ; i++) {
							selectDay.options[i] = new Option(i+1,i+1);
					}
		} 
		else if (imonth == 1 || imonth == 3 || imonth == 5 || imonth == 7 || imonth == 8 || imonth == 10 || imonth == 12 ) {
									i1= 0;
									for( ; i1 < 31; i1++) {
										selectDay.options[i1] = new Option(i1+1,i1+1);				
									}
		} 
		else if (imonth == 2) {
									i2 = 0;
									for( ; i2 < 28; i2++) {
										selectDay.options[i2] = new Option(i2+1,i2+1);				
									}
		}
		else if (imonth == 4 || imonth == 6 || imonth == 9 || imonth == 11) {
									i3 = 0;
									for( ; i3 < 30; i3++) {
										selectDay.options[i3] = new Option(i3+1,i3+1);				
									}
		}
  }
  function Month(Year,Month, selectDay) {	 
			imonth = parseInt(Month); 
			selectDay.options.length = 0;
		if ((Year== "2004" || Year =="2008") && (imonth == 2)){
					selectDay.options.length = 0;
					i = 0;
					for( ; i < 29 ; i++) {
							selectDay.options[i] = new Option(i+1,i+1);
					}
		} 
		else if (imonth == 1 || imonth == 3 || imonth == 5 || imonth == 7 || imonth == 8 || imonth == 10 || imonth == 12 ) {
									i1= 0;
									for( ; i1 < 31; i1++) {
										selectDay.options[i1] = new Option(i1+1,i1+1);				
									}
		} 
		else if (imonth == 2) {
									i2 = 0;
									for( ; i2 < 28; i2++) {
										selectDay.options[i2] = new Option(i2+1,i2+1);				
									}
		}
		else if (imonth == 4 || imonth == 6 || imonth == 9 || imonth == 11) {
									i3 = 0;
									for( ; i3 < 30; i3++) {
										selectDay.options[i3] = new Option(i3+1,i3+1);				
									}
		}
	}			
  function radio_onclickDisable(Choice1, Choice2, Choice3) {
			 Choice1.disabled = true;		
		         Choice2.disabled = true;		
			 Choice3.disabled = true;		
  }
  function radio_onclickEnable(Choice1, Choice2, Choice3) {
			 Choice1.disabled = false;		
		         Choice2.disabled = false;		
			 Choice3.disabled = false;		
  }
//-->
</SCRIPT>
</head>

<body bgcolor="#FFFFFF">
<table width="700" border="1">
  <tr>
	    <td height="50">
		      <table width="100%" border="1" height="50">
		        <tr>
			          <td height="45" width="25%"><b><font size="5">OLALA TOUR</font></b></td>
			          <td height="45" width="75%"><font size="4">AIRLINE SEARCH</font></td>
		        </tr>
		      </table>
	    </td>
  </tr>
  <tr>
	    <td height="50">
		      <table width="100%" border="1" height="50">
		        <tr>
			          <td width="36%">
				            <form method="post" action="">Search
					              <input type="text" name="textfield">
						      <input type="submit" name="Submit" value="GO">
				            </form>
			          </td>
			          <td width="64%">
				            <table width="100%" border="1" height="100%">
				              <tr>
					                <td width="70%">
						                  <div align="right"></div>
					                </td>
					                <td width="16%">
						                  <div align="center">
									<img src="photocart2.jpg" width="26" height="19"><br>
							                    <a href="Cart.htm">ViewCart</a>
								  </div>
					                </td>
					                <td width="14%">
						                  <div align="center">
									<img src="home.gif" width="20" height="20"><br>
							                    <a href="olalatour.htm">Home </a>
								   </div>
					                </td>
				              </tr>
				            </table>
			          </td>
        </tr>
      </table>
    </td>
  </tr>

  <tr>
	  <td height="30">
		      <table width="100%" border="1" height="30">
			        <tr>
				          <td width="16%">Airline Booking</td>
				          <td width="13%">Bus Booking</td>
				          <td width="15%">Hotel Booking</td>
				          <td width="18%">Package Booking</td>
				          <td width="16%">LocationSearch </td>
				          <td colspan="2" width="22%">Place&amp;ActivitySearch</td>
			        </tr>
		      </table>
	    </td>
  </tr>

  <tr>
	  <td>
		      <table width="100%" border="1">
		        <tr>
			          <td width="30%"><b><font size="5">Weather<br> </font></b>
				            <table width="200" border="1">
				              <tr>
				                <td width="78%" height="15"><font size="2">London,UK 30-34.5F</font></td>
				                <td width="22%">
				                <div align="center">
							<b><font size="5">
							<img src="weather1.gif" width="32" height="24"></font></b>
						</div>
		                </td>
		      </tr>
	              <tr>
		                <td width="78%" height="15"><font size="3">Ban<font size="2">gkok,TH 21-25F</font></font></td>
		                <td width="22%" height="15">
					  <div align="center"><b><img src="weather2.gif" width="32" height="24"></b></div>
		                </td>
	              </tr>
		      <tr>
				<td width="78%" height="15">
					<font size="2">Tokyo,Ja 5-10F</font>
					<font size="5"></font><b>
					<font size="5"><br></font></b>
				</td>
		                <td width="22%" height="15">
					<div align="center">
						<img src="weather3.gif" width="32" height="24">
					</div>
		                </td>
		     </tr>
	            </table>
          </td>
          <td width="70%" rowspan="2"> 
			<font size="4"><b>One Way</b></font> |
	                <font size="4"><b><a href="AirlineSearchRoundTrip.htm">Round Trip</a></b></font>  |<br>

			<form method="get" name="form1">
		              <font size="5"><b>Fill Data For Airline Search</b></font>
			              <table width="100%" border="0">
			                <tr>
				               <td colspan="2"><b>How many of passengers?</b> *</td>
			                </tr>
			                <tr>
				               <td width="38%" height="23">
				                    <div align="right">Total number of travellers?</div>
				               </td>
				               <td width="62%" height="23">
					                  <!--SELECT NUMBER TRAVELLER -->
				                    <select name="selectNumberTraveller">
						              <option value="1" selected>1</option>
					                      <option value="2" >2</option>
					                      <option value="3" >3</option>
					                      <option value="4" >4</option>
					                      <option value="5" >5</option>
				                    </select>
				                  </td>
			                </tr>
			                <tr>
				                  <td width="38%">
					                    <div align="right">How many are aged 2-11?</div>
				                  </td>
				                  <td width="62%">
					                  <!--SELECT NUMBER CHILDREN  -->
				                    <select name="selectNumberChildren">
					                      <option value="1" selected>1</option>
					                      <option value="2" >2</option>
					                      <option value="3" >3</option>
					                      <option value="4" >4</option>
					                      <option value="5" >5</option>
				                    </select>
				                  </td>
			                </tr>
			              </table>  <b> </b>
			              <table width="100%" border="0">
				          <tr>
				                  <td colspan="3"><b>Where would you like to go?*</b></td>
				          </tr>
				          <tr>
				                  <td width="100">
					                    <div align="right">Leaving From</div>
				                  </td>
				                  <td width="163">
					                    <div align="center"><b>
						                    <!--TEXTFIELD START AIRPORT-->
						                      <input type="text" name="textfieldStartAirport" 
									value="<%=request.getParameter("strAirportID")%>"> </b>								
							    </div>
							    <%
									String strStartAirportName = "";
									strStartAirportName = request.getParameter("strAirportName");
							    %>
					          </td>
				                  <td width="220">
						                    <!--TEXTFIELD START AIRPORT ....LINK TO AIRPORTLIST.... -->
								   <input type="button" name="buttonStartAirport"
									value="Choose Airport" onclick="ShowAirportList(textfieldStartAirport.value)">
						  </td>	
			                </tr>
			                <tr>
				                  <td width="93">
					                    <div align="right">Going To </div>
				                  </td>
				                  <td width="163">
					                    <div align="center"><b>
						                    <!--TEXTFIELD STOP AIRPORT-->
						                     <input type="text" name="textfieldStopAirport"
										value="<%=request.getParameter("strAirportID")%>"> </b>
							    </div>
							    <%
									String strStopAirportName = "";
									strStopAirportName = request.getParameter("strAirportName");
							    %>
				                  </td>
				                  <td width="220">
					                    <!--TEXTFIELD STOP AIRPORT ....LINK TO AIRPORTLIST.... -->
 							    <input type="button" name="buttonStopAirport"
										value="Choose Airport" onclick="ShowAirportList(textfieldStopAirport.value)">                    
						  </td>																	
					</tr>
			            </table>              
	  <div align="center">
			You can fly on any day that lowest fare? If so,stop here<br>By clicking "Show me Airlines",
				    you indicate that you agree to the following <br>
  	  </div>
	<!--CLICK SHOW ME AIRLINE BUTTON TO LINK AIRLINESEARCHLIST -->   
		<div align="center">
			<table width="100%" border="0">
				<tr>
					<td width="95%">
					<div align="center"> 
						<!--BUTTON SHOW ME AIRLINE -->
	<input type="button" name="buttonShowAirlineList1" value="Show Me Airlines" 
		onclick="LinkToAirlineSearchList(selectNumberTraveller.value,selectNumberChildren.value,
			textfieldStartAirport.value,textfieldStopAirport.value,null,null,null,null,null,null,null,null)">          
			
	<!-- .....................................................................JSP............................................................................. -->
					</div>
					</td>
				</tr>
			</table>
		</div>
         </div>              
						
	<table width="100%" border="0" height="87">
                <tr>
				<td colspan="8" height="29"><b>When would you like to traval?</b></td>
                </tr>
                <tr>
                  		<td width="65" height="30">
			                <div align="right">
						Departing
					</div>
				</td>                 
				<td width="80" height="30">
			               <div align="center">
			                      <select name="selectMonth"  onChange="Month(selectYear.value,selectMonth.value,selectDay)">
				                        <option value="1" selected>January</option>
				                        <option value="2"         >Febuary</option>
				                        <option value="3"           >March</option>
				                        <option value="4"           >April</option>
				                        <option value="5"             >May</option>
				                        <option value="6"            >June</option>
				                        <option value="7"            >July</option>
				                        <option value="8"          >August</option>
				                        <option value="9"       >September</option>
				                        <option value="10"         >October</option>
				                        <option value="11"        >November</option>
				                        <option value="12"        >December</option>
			                      </select>
		                    </div>
			      </td>
		              <td width="241" height="30">
					<select name="selectYear" onChange="Year(selectYear.value,selectMonth.value,selectDay)">
				                      <option value="2001" selected>2001</option>
				                      <option value="2002">         2002</option>
				                      <option value="2003">         2003</option>
				                      <option value="2004">         2004</option>
		                       </select>
	                   </td>				   
		           <td colspan="5" height="30">
		                    <div align="center">
						 <select name="selectDay" >
						        <option value="1" selected>1</option>
						 </select>				  												             
		                    </div>
			  </td>
      </tr>
      <tr>
	                  <td colspan="8" height="30">
			            <div align="left">Time :
			                      <select name="selectTime" >
							<option selected>1:00 am</option>
				                        <option>2:00 am</option>
				                        <option>3:00 am</option>
				                        <option>4:00 am</option>
				                        <option>5:00 am</option>
				                        <option>6:00 am</option>
				                        <option>7:00 am</option>
				                        <option>8:00 am</option>
				                        <option>9:00 am</option>
				                        <option>10:00 am</option>
				                        <option>11:00 am</option>
				                        <option>12:00 am</option>
							<option>1:00 pm</option>                        
							<option>2:00 pm</option>                        
							<option>3:00 pm</option>                        
							<option>4:00 pm</option>                        
							<option>5:00 pm</option>                        
							<option>6:00 pm</option>                        
							<option>7:00 pm</option>                        
							<option>8:00 pm</option>                        
							<option>9:00 pm</option>                        
							<option>10:00 pm</option>                        
							<option>11:00 pm</option>                        
							<option>12:00 pm</option>                        
					      </select>
		                    </div>
			    </td>
	  </tr>
 </table>
 <table width="100%" border="0">
          <tr> 
                  <td colspan="2" height="30"><b> Passenger and Pricing Information</b></td>
          </tr>
          <tr> 
                  <td colspan="2"> 
	                    <div align="center">Airline Class : 
			              <select name="selectAirlineClass">
			                        <option value="ANY" selected>ANY</option>
			                        <option value="Business Class">Business Class</option>
			                        <option value="Economic Class">Economic Class</option>
		                      </select>
			    </div>
                 </td>
         </tr>
         <tr> 
                  <td height="54" colspan="2"> 
	                    <div align="center">
			              <input type="radio" name="radioNonStopFlight" value="NonStop"> 
					Show me non-stop flight first
		            </div>
                  </td>
        </tr>
</table>
<table width="490" border="0" height="81">
        <tr> 
                  <td colspan="2" height="22"><b>What airlines do you like prefer?</b></td>
        </tr>
        <tr> 
                  <td colspan="2" height="27">
		            <div align="center">Airlines Name : 
				      <select name="selectAirlineName"  id ="selectAirlineName" size="1">
			                        <option value="ThaiAirline">Thai Airline</option>
			                        <option value="CanadaAirline">Canada Airline</option>
			                        <option value="ANY">ANY</option>
		                      </select>
			    </div>
                 </td>
       </tr>
</table>
        					
<table width="100%" border="0">
       <tr>
                  <td><b>What seat position do you want?</b></td>
       </tr>
       <tr>
                  <td> 
	                    <div align="center">Seat Position : 
			              <select name="selectSeatPosition" id="selectSeatPosition" >
			                        <option selected>Near Windows</option>
			                        <option>Front</option>
			                        <option>Back</option>
		                      </select>
			    </div>
                  </td>
       </tr>
</table>
              <!--CLICK SHOW ME AIRLINE BUTTON TO LINK AIRLINESEARCHLIST --> 
              <div align="center">
					<table width="100%" border="0">
						<tr>
							<td width="95%">
								<div align="center"> 
								<!--BUTTON SHOW ME AIRLINE -->		
	<input type="button" name="buttonShowAirlineList2" value="Show Me Airlines"
	onclick="LinkToAirlineSearchList(selectNumberTraveller.value,selectNumberChildren.value,
				textfieldStartAirport.value,textfieldStopAirport.value,
				selectMonth.value,selectYear.value,selectDay.value,selectTime.value,
				selectAirlineClass.value,radioNonStopFlight.value,selectAirlineName.value,
				selectSeatPosition.value)">
								</div>
							</td>

							<td width="5%">
						             <div align="right"><a href="file:///C%7C/My%20Documents/Project/New%20Folder/olalatour2.html">
									 <img  src="file:///C%7C/My%20Documents/Project/New%20Folder/home.gif" width="20" height="20" border="0"></a>
							     </div>
						        </td>
						</tr>
					</table>
		</div>
            </div>           
            </form>

          </td>
        </tr>
        <tr>
          <td width="30%" valign="top"><b><font size="5">Calender<br>
            </font></b>
            <table width="200" border="1">
              <tr>
                <td height="15" colspan="7">
                  <form name="form2">
                    <div align="center"><font size="2"> </font>
                      <select name="selectCalenderMonth" onChange="MM_jumpMenu('parent',this,0)">
                        <option selected>January</option>
                        <option>February</option>
                        <option>March</option>
                        <option>April</option>
                      </select>
                      <select name="selectCalenderYear" onChange="MM_jumpMenu('parent',this,0)">
                        <option selected>2001</option>
                        <option>2002</option>
                        <option>2003</option>
                      </select>
                    </div>
                  </form>
                </td>
              </tr>
              <tr>
                <td>Su </td>
                <td>Mo</td>
                <td>Tu</td>
                <td>We</td>
                <td>Th</td>
                <td>Fr</td>
                <td>Sa</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>1</td>
                <td>2</td>
                <td>3</td>
                <td>4</td>
              </tr>
              <tr>
                <td>5</td>
                <td>6</td>
                <td>7</td>
                <td>8</td>
                <td>9</td>
                <td>10</td>
                <td>11</td>
              </tr>
              <tr>
                <td>12</td>
                <td>13</td>
                <td>14</td>
                <td>15</td>
                <td>16</td>
                <td>17</td>
                <td>18</td>
              </tr>
              <tr>
                <td>19</td>
                <td>20</td>
                <td>21</td>
                <td>22</td>
                <td>23</td>
                <td>24</td>
                <td>25</td>
              </tr>
              <tr>
                <td>26</td>
                <td>27</td>
                <td>28</td>
                <td>29</td>
                <td>30</td>
                <td>31</td>
                <td>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
