package hotelsystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
import java.util.Collection;
import java.sql.Date;
import java.util.Iterator;
import java.util.ArrayList;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class TestJsp1Bean {
    private String sample = "Start value";
    private HotelControllerHome hotelControllerHome = null;
    private HotelControllerRemote hotelControllerRemote = null;
    private Iterator iterator = null;
    private String id = null;
    private String name = null;
    /**Access sample property*/
    public String getSample() {
	return sample;
    }
    /**Access sample property*/
    public void setSample(String newValue) {
	if (newValue!=null) {
	    sample = newValue;
	}
    }
    public void hoho(String name, String description, String address, int star) {
	try {
	    //get naming context
	    Context ctx = new InitialContext();

	    //look up jndi name
	    Object ref = ctx.lookup("hotelsystem/HotelController");

	    //cast to Home interface
	    hotelControllerHome = (HotelControllerHome) PortableRemoteObject.narrow(ref, HotelControllerHome.class);
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	create();

	Collection hotels = null;
	try {
	    hotels = hotelControllerRemote.findHotel(name, description, address, star);
	}
	catch (RemoteException ex) {
	    ex.printStackTrace();
	}
	iterator = hotels.iterator();
    }
    public boolean next() {
	if(iterator.hasNext()) {
	    ShortHotelInformation info = (ShortHotelInformation)iterator.next();
	    id = info.getHotelID();
	    name = info.getHotelName();
	    return true;
	}
	else {
	    return false;
	}
    }
    public String getID() {
	return id;
    }
    public String getName() {
	return name;
    }
    public HotelControllerRemote create() {
	try {
	    hotelControllerRemote = hotelControllerHome.create();
	}
	catch(Exception e) {
	    e.printStackTrace();
	}
	return hotelControllerRemote;
    }
}