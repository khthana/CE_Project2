package busservice;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface SearchController extends EJBObject {
  public  ArrayList  SearchSeat( String SrcStationID, String DstStationID, int TotalSeat, java.sql.Date  DepartDate, int CompanyID, int ClassType, int SeatType)  throws RemoteException ;
  public  ArrayList  SearchCompany( String Keyword) throws RemoteException ;
  public  ArrayList  SearchStation( String keyword )throws RemoteException ;
  public  ArrayList  SearchBus(java.sql.Date  UsingDate ,String TotalUsingDay, boolean AirCond, boolean Toilet) throws RemoteException;
  public  ArrayList  SearchBusBooking(String BookingID) throws RemoteException;
  public  ArrayList  SearchSeatBooking(String BookingID) throws RemoteException;

}