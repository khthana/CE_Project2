package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Subbooking implements EntityBean {
    EntityContext entityContext;
    public Date bookCheckInTime;
    public Date bookCheckOutTime;
    public String roomNo;
    public String hotelId;
    public String bookingId;
    public SubbookingPK ejbCreate(Date bookCheckInTime, Date bookCheckOutTime, String roomNo, String hotelId, String bookingId) throws CreateException {
	this.bookCheckInTime = bookCheckInTime;
	this.bookCheckOutTime = bookCheckOutTime;
	this.roomNo = roomNo;
	this.hotelId = hotelId;
	this.bookingId = bookingId;
	return null;
    }
    public SubbookingPK ejbCreate(Date bookCheckInTime, String roomNo, String hotelId) throws CreateException {
	return ejbCreate(bookCheckInTime, null, roomNo, hotelId, null);
    }
    public void ejbPostCreate(Date bookCheckInTime, Date bookCheckOutTime, String roomNo, String hotelId, String bookingId) throws CreateException {
    }
    public void ejbPostCreate(Date bookCheckInTime, String roomNo, String hotelId) throws CreateException {
	ejbPostCreate(bookCheckInTime, null, roomNo, hotelId, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public Date getBookCheckInTime() {
	return bookCheckInTime;
    }
    public Date getBookCheckOutTime() {
	return bookCheckOutTime;
    }
    public void setBookCheckOutTime(Date bookCheckOutTime) {
	this.bookCheckOutTime = bookCheckOutTime;
    }
    public String getRoomNo() {
	return roomNo;
    }
    public String getHotelId() {
	return hotelId;
    }
    public String getBookingId() {
	return bookingId;
    }
    public void setBookingId(String bookingId) {
	this.bookingId = bookingId;
    }
}