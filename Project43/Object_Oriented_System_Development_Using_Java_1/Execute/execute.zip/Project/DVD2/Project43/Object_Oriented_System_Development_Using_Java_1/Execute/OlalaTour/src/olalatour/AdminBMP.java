package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class AdminBMP extends Admin {
    DataSource dataSource;
    public String ejbCreate(String adminId, String loginName, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String password) throws CreateException {
	super.ejbCreate(adminId, loginName, firstName, lastName, address, telephoneNo, emailAddress, gender, birthDate, religion, password);
	try {
	    //First see if the object already exists
	    ejbFindByPrimaryKey(adminId);
	    //If so, then we have to throw an exception
	    throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	    //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("INSERT INTO ADMIN (ADMIN_ID, LOGIN_NAME, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, PASSWORD) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	    statement.setString(1, adminId);
	    statement.setString(2, loginName);
	    statement.setString(3, firstName);
	    statement.setString(4, lastName);
	    statement.setString(5, address);
	    statement.setString(6, telephoneNo);
	    statement.setString(7, emailAddress);
	    statement.setInt(8, gender.intValue());
	    statement.setDate(9, birthDate);
	    statement.setString(10, religion);
	    statement.setString(11, password);
	    if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return adminId;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL INSERT INTO ADMIN (ADMIN_ID, LOGIN_NAME, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, PASSWORD) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbCreate(String adminId) throws CreateException {
	return ejbCreate(adminId, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("DELETE FROM ADMIN WHERE ADMIN_ID = ?");
	    statement.setString(1, adminId);
	    if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL DELETE FROM ADMIN WHERE ADMIN_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void ejbLoad() {
	adminId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT LOGIN_NAME, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, PASSWORD FROM ADMIN WHERE ADMIN_ID = ?");
	    statement.setString(1, adminId);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    loginName = resultSet.getString(1);
	    firstName = resultSet.getString(2);
	    lastName = resultSet.getString(3);
	    address = resultSet.getString(4);
	    telephoneNo = resultSet.getString(5);
	    emailAddress = resultSet.getString(6);
	    gender = new Integer(resultSet.getInt(7));
	    birthDate = resultSet.getDate(8);
	    religion = resultSet.getString(9);
	    password = resultSet.getString(10);
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT LOGIN_NAME, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, EMAIL_ADDRESS, GENDER, BIRTH_DATE, RELIGION, PASSWORD FROM ADMIN WHERE ADMIN_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
	super.ejbLoad();
    }
    public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("UPDATE ADMIN SET LOGIN_NAME = ?, FIRST_NAME = ?, LAST_NAME = ?, ADDRESS = ?, TELEPHONE_NO = ?, EMAIL_ADDRESS = ?, GENDER = ?, BIRTH_DATE = ?, RELIGION = ?, PASSWORD = ? WHERE ADMIN_ID = ?");
	    statement.setString(1, loginName);
	    statement.setString(2, firstName);
	    statement.setString(3, lastName);
	    statement.setString(4, address);
	    statement.setString(5, telephoneNo);
	    statement.setString(6, emailAddress);
	    statement.setInt(7, gender.intValue());
	    statement.setDate(8, birthDate);
	    statement.setString(9, religion);
	    statement.setString(10, password);
	    statement.setString(11, adminId);
	    if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL UPDATE ADMIN SET LOGIN_NAME = ?, FIRST_NAME = ?, LAST_NAME = ?, ADDRESS = ?, TELEPHONE_NO = ?, EMAIL_ADDRESS = ?, GENDER = ?, BIRTH_DATE = ?, RELIGION = ?, PASSWORD = ? WHERE ADMIN_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT ADMIN_ID FROM ADMIN WHERE ADMIN_ID = ?");
	    statement.setString(1, key);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return key;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT ADMIN_ID FROM ADMIN WHERE ADMIN_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT ADMIN_ID FROM ADMIN");
	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String adminId = resultSet.getString(1);
		keys.addElement(adminId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT ADMIN_ID FROM ADMIN: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	    javax.naming.Context context = new javax.naming.InitialContext();
	    dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	    throw new EJBException("Error looking up dataSource:" + e.toString());
	}
    }
}