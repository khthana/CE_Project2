package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface CategoryHome extends EJBHome {
    public CategoryRemote create(String categoryId, String categoryName, String description) throws RemoteException, CreateException;
    public CategoryRemote create(String categoryId) throws RemoteException, CreateException;
    public CategoryRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
    public Collection findByCategoryNameDetail(String categoryName, String detail) throws RemoteException, FinderException;
}