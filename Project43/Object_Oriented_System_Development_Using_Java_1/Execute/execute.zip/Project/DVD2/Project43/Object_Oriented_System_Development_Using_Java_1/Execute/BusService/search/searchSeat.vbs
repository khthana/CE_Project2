Public Function SearchSeat(ByVal SrcStationID As String, _
                                                      ByVal DstStationID As String, _
                                                      ByVal TotalSeat As Integer, _
                                                      Optional ByVal DepartDate As Date, _
                                                      Optional ByVal CompanyID As Integer = 0, _
                                                      Optional ByVal ClassType As Integer = BusClass.AllClass, _
                                                      Optional ByVal SeatType As Integer = BusSeat.AllSeat) _
                                                      As ADODB.Recordset
    Dim strCommand As String
    Dim strSelectedCompany As String
    Dim strSelectedClassType As String
    Dim strSelectedSeatType As String
    Dim rsSearchRoute As ADODB.Recordset
    
    Set rsSearchRoute = New ADODB.Recordset
    
    ' Checking company that user selected.
    If CompanyID = 0 Then
        strSelectedCompany = ""
    Else
        strSelectedCompany = " AND T7.CompanyID = " & CompanyID & " "
    End If
    
    ' Checking class that user selected.
    Select Case ClassType
        Case BusClass.AllClass
            strSelectedClassType = ""
        Case BusClass.Air1VIP
            strSelectedClassType = " AND T7.ClassID = 1 "
        Case BusClass.Air1
            strSelectedClassType = " AND T7.ClassID = 2 "
        Case BusClass.Air2
            strSelectedClassType = " AND T7.ClassID = 3 "
        Case Else
            strSelectedClassType = ""
    End Select
    
    ' Checking type of seat that user selected.
    Select Case SeatType
        Case BusSeat.AllSeat
            strSelectedSeatType = ""
        Case BusSeat.Aisle
            strSelectedSeatType = " AND T8.Window = 1 "
        Case BusSeat.Window
            strSelectedSeatType = " AND T8.Window = 0 "
        Case Else
            strSelectedSeatType = ""
    End Select
    
    
    ' Create SQL command for searching Route
    strCommand = "SELECT       T1.CompanyName, T2.ClassName, " & _
                                  "                        T3.DepartTime, T4.ArriveTime, " & _
                                  "                        T3.RouteID , T3.Idx, T4.Idx, (SUM(T12.Distance) * T2.PricePerKm) + T13.Fee " & _
                                  "FROM           BusCompany T1, " & _
                                  "                        BusClass T2, " & _
                                  "                        RouteSubRoute T3, RouteSubRoute T4, RouteSubRoute T11," & _
                                  "                        SubRoute T5, SubRoute T6, SubRoute T12," & _
                                  "                        Route T7, " & _
                                  "                        BusFee T13 "
    strCommand = strCommand & _
                                  "WHERE       T5.SrcStation = '" & SrcStationID & "'" & _
                                  "                         AND T6.DstStation = '" & DstStationID & "'" & _
                                  "                         AND T5.SubRouteID = T3.SubRouteID " & _
                                  "                         AND T6.SubRouteID = T4.SubRouteID " & _
                                  "                         AND T3.RouteID = T4.RouteID " & _
                                  "                         AND T11.RouteID = T3.RouteID " & _
                                  "                         AND T11.Idx BETWEEN T3.Idx AND T4.Idx " & _
                                  "                         AND T12.SubRouteID = T11.SubRouteID " & _
                                  "                         AND T3.Idx <= T4.Idx " & _
                                  "                         AND T7.RouteID = T3.RouteID " & _
                                  "                         AND T1.CompanyID = T7.CompanyID " & _
                                  "                         AND T2.ClassID = T7.ClassID " & _
                                  "                         AND T13.CompanyID = T1.CompanyID " & _
                                  "                         AND T13.ClassID = T2.ClassID " & _                 '@@@@@@@@@@@@@@@@@@@@@@
                                  strSelectedCompany & _
                                  strSelectedClassType & _
                                  "                         AND " & TotalSeat & " <= "
    strCommand = strCommand & _
                                  "(SELECT COUNT(DISTINCT T8.SeatNo) " & _
                                  "FROM      Seat T8 " & _
                                  "WHERE   T7.ModelID = T8.ModelID " & _
                                  strSelectedSeatType & _
                                  "                    AND T8.SeatNo NOT IN ( " & _
                                  "SELECT    DISTINCT T9.SeatNo " & _
                                  "FROM        SubRouteBooking T9, " & _
                                  "                     RouteSubRoute T10 " & _
                                  "WHERE    T9.DepartDate = '" & DepartDate & "'  " & _
                                  "                     AND T9.RouteID = T7.RouteID " & _
                                  "                     AND T9.RouteID = T10.RouteID " & _
                                  "                     AND T9.SubRouteID = T10.SubRouteID " & _
                                  "                     AND T10.Idx >= T3.Idx " & _
                                  "                     AND T10.Idx <=  T4.Idx )) "
    strCommand = strCommand & _
                                  "GROUP BY     T1.CompanyName, T2.ClassName, " & _
                                  "                            T3.DepartTime, T4.ArriveTime, " & _
                                  "                            T3.RouteID , T3.Idx, T4.Idx, T2.PricePerKm, T13.Fee "

    Debug.Print "Search Route Command" & vbCrLf & _
                     "- - - - - - - - - - - - - - - - - - - - - " & vbCrLf & _
                     strCommand & vbCrLf & _
                     "- - - - - - - - - - - - - - - - - - - - - " '################################
    MsgBox "Company : " & strSelectedCompany & vbCrLf & _
                     "Class : " & strSelectedClassType & vbCrLf & _
                     "Seat : " & strSelectedSeatType & vbCrLf

    If objSql.SqlExecute(strCommand, rsSearchRoute) Then
        Set SearchSeat = rsSearchRoute
    Else
        MsgBox "Error at [ BusService.ISearch : SearchSeat ] :: " & vbCrLf & _
                         "Can't execute command to seaching route.", vbExclamation  '##########################
        Set rsSearchRoute = Nothing
    End If
    Exit Function

Oops:
    ' Deallocate memory.
    Set rsSearchRoute = Nothing
    MsgBox "Error at [ BusService.ISearch : SearchRoute ] :: " & vbCrLf & Err.Description, vbExclamation   '###################
End Function