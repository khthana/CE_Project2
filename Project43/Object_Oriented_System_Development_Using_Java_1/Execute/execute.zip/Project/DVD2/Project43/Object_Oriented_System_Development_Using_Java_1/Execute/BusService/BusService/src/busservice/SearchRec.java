package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SearchRec implements java.io.Serializable {

                    String CompanyName ;
                    String ClassName ;
                    java.sql.Timestamp DepartTime ;
                    java.sql.Timestamp ArriveTime ;
                    int RouteID ;
                    int SrcIndex ;
                    int DstIndex ;
                    double Price ;


   public  SearchRec(String CompanyName, String ClassName, java.sql.Timestamp DepartTime, java.sql.Timestamp  ArriveTime, int RouteID, int SrcIndex, int DstIndex , double Price) {

      this.CompanyName = CompanyName;
      this.ClassName = ClassName;
      this.DepartTime = DepartTime;
      this.ArriveTime =  ArriveTime;
      this.RouteID = RouteID;
      this.SrcIndex  = SrcIndex ;
      this.DstIndex  = DstIndex ;
      this.Price = Price;

   }

   public String getCompanyName() {
      return CompanyName;
   }

   public String getClassName() {
      return ClassName;
   }

   public java.sql.Timestamp getDepartTime() {
      return DepartTime;
   }

   public java.sql.Timestamp getArriveTime() {
      return ArriveTime;
   }

   public int getRouteID() {
      return RouteID;
   }

  public int getSrcIndex() {
      return SrcIndex;
   }
  public int getDstIndex() {
      return DstIndex;
   }
  public double getPrice() {
      return Price;
   }

}
