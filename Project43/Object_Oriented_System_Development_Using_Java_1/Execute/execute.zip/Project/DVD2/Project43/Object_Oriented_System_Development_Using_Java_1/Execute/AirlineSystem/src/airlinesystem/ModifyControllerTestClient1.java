package airlinesystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.ArrayList;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ModifyControllerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private ModifyControllerHome modifyControllerHome = null;
  private ModifyControllerRemote modifyControllerRemote = null;

  /**Construct the EJB test client*/
  public ModifyControllerTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("ModifyController");

	  //cast to Home interface
	  modifyControllerHome = (ModifyControllerHome) PortableRemoteObject.narrow(ref, ModifyControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public ModifyControllerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  modifyControllerRemote = modifyControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + modifyControllerRemote + ".");
	}
	return modifyControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public boolean confirmBooking(String BookingID) {
	boolean returnValue = true;
	if (modifyControllerRemote == null) {
	  System.out.println("Error in confirmBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling confirmBooking(" + BookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = modifyControllerRemote.confirmBooking(BookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: confirmBooking(" + BookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: confirmBooking(" + BookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from confirmBooking(" + BookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public boolean CancelBooking(String BookingID) {
	boolean returnValue = true;
	if (modifyControllerRemote == null) {
	  System.out.println("Error in CancelBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling CancelBooking(" + BookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = modifyControllerRemote.CancelBooking(BookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: CancelBooking(" + BookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: CancelBooking(" + BookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from CancelBooking(" + BookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList modifyBooking(ArrayList newInfo, String BookingID) {
	ArrayList returnValue = null;
	if (modifyControllerRemote == null) {
	  System.out.println("Error in modifyBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling modifyBooking(" + newInfo + ", " + BookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = modifyControllerRemote.modifyBooking(newInfo, BookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: modifyBooking(" + newInfo + ", " + BookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: modifyBooking(" + newInfo + ", " + BookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from modifyBooking(" + newInfo + ", " + BookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	ModifyControllerTestClient1 client = new ModifyControllerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.

	 client.create();

	  client.CancelBooking("521DAE1E-FFFF-FFD3-0011-985E5AE57602");

//    client.confirmBooking("0A1C7C08-FFFF-FFD3-0078-00DBAD2EA492");

//      ArrayList newInfo = new ArrayList();
//       java.sql.Timestamp time = java.sql.Timestamp.valueOf("1899-30-12 6:30:00.000000000")   ;
//
//      BookSeatInfo bookSeatInfo = new BookSeatInfo("456789123","PANJA","SA-UI","KMITL","7390211","TG100",0,2,0,1,time,false,8000);
//      newInfo.add(0,bookSeatInfo);
//
//      ArrayList bookSeatResults = client.modifyBooking(newInfo,"2610439A-FFFF-FFD3-0078-BB148644201D");
//
//
//
//      ListIterator iterator = bookSeatResults.listIterator(0);
//         while (iterator.hasNext()) {
//         BookSeatResult item = (BookSeatResult)iterator.next();
//
//
//         System.out.println(item.getCustomerID() + " " +
//                            item.getBookingID() + " " +
//                            item.getSeatNo() + " " +
//                            item.getPrice() );
//			}




  }
}