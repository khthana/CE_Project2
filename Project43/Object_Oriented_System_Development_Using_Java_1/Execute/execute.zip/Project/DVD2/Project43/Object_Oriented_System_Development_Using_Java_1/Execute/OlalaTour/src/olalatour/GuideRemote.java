package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface GuideRemote extends EJBObject {
    String getGuideId() throws RemoteException;
    String getFirstName() throws RemoteException;
    void setFirstName(String firstName) throws RemoteException;
    String getLastName() throws RemoteException;
    void setLastName(String lastName) throws RemoteException;
    Integer getGender() throws RemoteException;
    void setGender(Integer gender) throws RemoteException;
    String getSpokenLanguage() throws RemoteException;
    void setSpokenLanguage(String spokenLanguage) throws RemoteException;
    String getOfficeAddress() throws RemoteException;
    void setOfficeAddress(String officeAddress) throws RemoteException;
}