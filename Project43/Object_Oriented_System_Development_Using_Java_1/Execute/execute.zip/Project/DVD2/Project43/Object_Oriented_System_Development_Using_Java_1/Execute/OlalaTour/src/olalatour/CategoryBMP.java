package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class CategoryBMP extends Category {
    DataSource dataSource;
    public String ejbCreate(String categoryId, String categoryName, String description) throws CreateException {
	super.ejbCreate(categoryId, categoryName, description);
	try {
	    //First see if the object already exists
	    ejbFindByPrimaryKey(categoryId);
	    //If so, then we have to throw an exception
	    throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	    //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("INSERT INTO CATEGORY (CATEGORY_ID, CATEGORY_NAME, DESCRIPTION) VALUES (?, ?, ?)");
	    statement.setString(1, categoryId);
	    statement.setString(2, categoryName);
	    statement.setString(3, description);
	    if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return categoryId;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL INSERT INTO CATEGORY (CATEGORY_ID, CATEGORY_NAME, DESCRIPTION) VALUES (?, ?, ?): " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbCreate(String categoryId) throws CreateException {
	return ejbCreate(categoryId, null, null);
    }
    public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("DELETE FROM CATEGORY WHERE CATEGORY_ID = ?");
	    statement.setString(1, categoryId);
	    if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL DELETE FROM CATEGORY WHERE CATEGORY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void ejbLoad() {
	categoryId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT CATEGORY_NAME, DESCRIPTION FROM CATEGORY WHERE CATEGORY_ID = ?");
	    statement.setString(1, categoryId);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    categoryName = resultSet.getString(1);
	    description = resultSet.getString(2);
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT CATEGORY_NAME, DESCRIPTION FROM CATEGORY WHERE CATEGORY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
	super.ejbLoad();
    }
    public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("UPDATE CATEGORY SET CATEGORY_NAME = ?, DESCRIPTION = ? WHERE CATEGORY_ID = ?");
	    statement.setString(1, categoryName);
	    statement.setString(2, description);
	    statement.setString(3, categoryId);
	    if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL UPDATE CATEGORY SET CATEGORY_NAME = ?, DESCRIPTION = ? WHERE CATEGORY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT CATEGORY_ID FROM CATEGORY WHERE CATEGORY_ID = ?");
	    statement.setString(1, key);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return key;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT CATEGORY_ID FROM CATEGORY WHERE CATEGORY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT CATEGORY_ID FROM CATEGORY");
	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String categoryId = resultSet.getString(1);
		keys.addElement(categoryId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT CATEGORY_ID FROM CATEGORY: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindByCategoryNameDetail(String categoryName, String detail) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT CATEGORY_ID FROM CATEGORY WHERE CATEGORY_NAME LIKE ? AND DESCRIPTION LIKE ? ");
	    statement.setString(1, "%" + categoryName + "%");
	    statement.setString(2, "%" + detail + "%");

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String categoryID = resultSet.getString(1);
		keys.addElement(categoryID);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }

    public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	    javax.naming.Context context = new javax.naming.InitialContext();
	    dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	    throw new EJBException("Error looking up dataSource:" + e.toString());
	}
    }
    public Collection getPlaces() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT DISTINCT PLACE_ID FROM PLACE_CATEGORY WHERE CATEGORY_ID = ? ");
	    statement.setString(1, categoryId);

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
}