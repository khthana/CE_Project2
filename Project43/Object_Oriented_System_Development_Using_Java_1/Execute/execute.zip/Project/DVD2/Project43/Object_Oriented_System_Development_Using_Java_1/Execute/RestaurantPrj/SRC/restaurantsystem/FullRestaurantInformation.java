package restaurantsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullRestaurantInformation implements Serializable {

  public FullRestaurantInformation(String restaurantID, String name, String description, int totalSeat, String address, int star) {
    this.restaurantID = restaurantID;
    this.name = name;
    this.description = description;
    this.totalSeat = totalSeat;
    this.address = address;
    this.star = star;
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  public String getRestaurantID() {
    return restaurantID;
  }
  public String getName() {
    return name;
  }
  public String getDescription() {
    return description;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public String getAddress() {
    return address;
  }
  public int getStar() {
    return star;
  }
  private String restaurantID;
  private String name;
  private String description;
  private int totalSeat;
  private String address;
  private int star;
}