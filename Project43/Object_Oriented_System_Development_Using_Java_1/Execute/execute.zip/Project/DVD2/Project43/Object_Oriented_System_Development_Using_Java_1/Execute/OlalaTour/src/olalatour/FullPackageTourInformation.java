package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullPackageTourInformation implements Serializable {
    /** @todo package */
    public FullPackageTourInformation(String packageID, String packageName, String description, java.util.Collection packagePlaces, java.util.Collection packageDepartTimeInformations, double totalPrice, int duration) {
	this.packageID = packageID;
	this.packageName = packageName;
	this.description = description;
	this.packagePlaces = packagePlaces;
	this.packageDepartTimeInformations = packageDepartTimeInformations;
	this.totalPrice = totalPrice;
	this.duration = duration;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPackageID() {
	return packageID;
    }
    public String getPackageName() {
	return packageName;
    }
    public String getDescription() {
	return description;
    }
    public double getTotalPrice() {
	return totalPrice;
    }
    public java.util.Collection getPackageDepartTimeInformations() {
	return packageDepartTimeInformations;
    }
    public java.util.Collection getPackagePlaces() {
	return packagePlaces;
    }
    public int getDuration() {
	return duration;
    }
    private String packageID;
    private String packageName;
    private String description;
    private java.util.Collection packagePlaces;
    //Collection of PackagePlace
    private java.util.Collection packageDepartTimeInformations;
    // Collection of olalatour.PackageDepartTimeInformation
    private double totalPrice;
    private int duration;
}