<%@ page import="java.sql.Timestamp" %>
<html>
<head>
<jsp:useBean id="viewerBean" scope="page" class="olalatour.ViewerBean" />
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--

//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>


<table width="750" border="1">
  <tr>
	<td> <b>DEPART FLIGHT</b> <b> </b></td>
  </tr>
  <tr>
	<td colspan="5">
	<%
	 String submit = request.getParameter("submit");
	if (submit != null) {
	if (submit.equals("airline")) {
		out.println("airline");
		String strCustomerID = request.getParameter("CustomerID");
		String strFlightID = request.getParameter("FlightID");
		String strSrcIdx = request.getParameter("SrcIdx");
		String strDstIdx = request.getParameter("DstIdx");
		String strSeatType = request.getParameter("SeatType");
		String strClassType = request.getParameter("ClassType");
		String strDepartDay = request.getParameter("DepartDay");
		String strDepartMonth = request.getParameter("DepartMonth");
		String strDepartYear = request.getParameter("DepartYear");
		String strDepartHour = request.getParameter("DepartHour");
		String strDepartMinute = request.getParameter("DepartMinute");
		String strCanSmoking = request.getParameter("CanSmoking");
		String strPrice = request.getParameter("Price");

		out.print("getParameter");

		if ((strCustomerID != null) && (strFlightID != null) && (strSrcIdx != null) && (strDstIdx != null)
		&& (strSeatType != null) && (strClassType != null) && (strDepartDay != null) && (strDepartMonth != null)
		&& (strDepartYear != null) && (strDepartHour != null) && (strDepartMinute != null)
		&& (strCanSmoking != null) && (strPrice != null)) {

		int srcIdx = Integer.parseInt(strSrcIdx);
		int dstIdx = Integer.parseInt(strDstIdx);
		int seatType = Integer.parseInt(strSeatType);
		int classType = Integer.parseInt(strClassType);
		java.sql.Timestamp departTime = java.sql.Timestamp.valueOf(strDepartYear + "-" + strDepartMonth + "-" + strDepartDay + " " + strDepartHour + ":" + strDepartMinute + ":" + "00" + "." + "00000000");
		boolean canSmoking = false;

		if (strCanSmoking.equals("on")) {
			canSmoking = true;
		}

		double price = Double.parseDouble(strPrice);

		out.print("call addAirlineItem");
		controllerBean.addAirlineItem(strCustomerID, null, null, null, null, strFlightID, srcIdx, dstIdx, seatType, classType, departTime, canSmoking, price);
		}
	}
	}








	String strNumberOfTraveller = request.getParameter("NumberOfTraveller");
	String strFromPlace = request.getParameter("FromPlace");
	String strToPlace = request.getParameter("ToPlace");
	String strSelectDay = request.getParameter("selectDay");
	String strSelectMonth = request.getParameter("selectMonth");
	String strSelectYear = request.getParameter("selectYear");
	String strSelectAirlineClass = request.getParameter("selectAirlineClass");
	String strAirline = request.getParameter("Airline");
	String strSelectSeatPosition = request.getParameter("selectSeatPosition");
	String strNonStop = request.getParameter("NonStop");
	String strCanSmoking = request.getParameter("CanSmoking");
	if (strNonStop == null) {
		strNonStop = "false";
	}
	if (strCanSmoking == null) {
		strCanSmoking = "false";
	}

	%>
	<%viewerBean.searchAirplaneSeat(strFromPlace, strToPlace, Integer.parseInt(strNumberOfTraveller), Integer.parseInt(strSelectDay), Integer.parseInt(strSelectMonth), Integer.parseInt(strSelectYear), Integer.parseInt(strAirline), Integer.parseInt(strSelectAirlineClass), Integer.parseInt(strSelectSeatPosition), Boolean.valueOf(strCanSmoking).booleanValue(), Boolean.valueOf(strNonStop).booleanValue(), 0);%>
	<%while (viewerBean.nextAirplaneSeat()) {%>
	  <table width="100%" border="1">
	<tr>
	  <td width="20%" rowspan="8">
		<div align="center">
		  <p><img src="images/LogoAirlineList.gif" width="55" height="55"><br>
		<%
		  String x = viewerBean.getClassName();
		  int classid = 0;
		  if (x.equals("FIRST CLASS")) {
			classid = 1;
		  }
		  else if (x.equals("BUSINESS CLASS")) {
			classid = 2;
		  }
		  else if (x.equals("ECONOMY CLASS")) {
			classid = 3;
		  }
		%>
		<a href="AirlineSearchList.jsp?<%=request.getQueryString()%>&CustomerID=&FlightID=<%=viewerBean.getFlightID()%>&SrcIdx=<%=viewerBean.getSrcIdx()%>&DstIdx=<%=viewerBean.getDstIdx()%>&SeatType=<%=strSelectSeatPosition%>&ClassType=<%=classid%>&DepartDay=<%=viewerBean.getDepartTime().getDate()%>&DepartMonth=<%=viewerBean.getDepartTime().getMonth()%>&DepartYear=<%="2001"%>&DepartHour=<%=viewerBean.getDepartTime().getHours()%>&DepartMinute=<%=viewerBean.getDepartTime().getMinutes()%>&CanSmoking=<%=strCanSmoking%>&Price=<%=viewerBean.getPrice()%>&submit=airline">add to cart</a></p>
		  </div>
	  </td>
	  <td width="80%"> <b>Flight:</b> <%=viewerBean.getFlightID()%> <b>AirlineName : <%=viewerBean.getAirlineName()%></b>
		<b>AircraftName :</b> <%=viewerBean.getAircraftName()%></td>
	</tr>
	<tr>
	  <td width="80%"> <b>From:</b> <%=strFromPlace%> : <%=viewerBean.getDepartTime()%></td>
	</tr>
	<tr>
	  <td width="80%"> <b>To: <%=strToPlace%></b>ToPlace : <%=viewerBean.getArriveTime()%></td>
	</tr>
	<tr>
		  <td width="80%"><b>ClassName :</b> <%=viewerBean.getClassName()%></td>
	</tr>
	<tr>
		  <td width="80%"><b>TotalDistance :</b> <%=viewerBean.getTotalDistance()%></td>
	</tr>
	<tr>
		  <td width="80%"><b>Description :</b> <%=viewerBean.getDescription()%></td>
	</tr>
	<tr>
	  <td width="80%"> <b>Price/Seat : </b> <%=viewerBean.getPrice()%> </td>
	</tr>
	  </table>
	<%}%>

	</td>
  </tr>
</table>

</body>
</html>
