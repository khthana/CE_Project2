package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.sql.*;
import hotelsystem.*;
import restaurantsystem.*;
import busservice.*;
import airlinesystem.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class OlalaAgencyViewer implements SessionBean {
	private SessionContext sessionContext;
	public void ejbCreate() {
	}
	public void ejbRemove() {
	}
	public void ejbActivate() {
	}
	public void ejbPassivate() {
	}
	public void setSessionContext(SessionContext context) {
	sessionContext = context;
	}
  public Collection findHotel(String name, String description, String address, int star) {
	System.out.println("findHotel in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("hotelsystem/HotelController");
	  System.out.println("lookup");

	  HotelControllerHome home = (HotelControllerHome)PortableRemoteObject.narrow(objref, HotelControllerHome.class);
	  System.out.println("narrow");

	  HotelControllerRemote remote = home.create();

	  Collection hotels = remote.findHotel(name, description, address, star);
	  System.out.println("end findHotel in OlalaAgencyViewer");
	  return hotels;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of ShortHotelInformation
  public Collection findRoom(String hotelID) {
	System.out.println("findRoom in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("hotelsystem/HotelController");
	  System.out.println("lookup");

	  HotelControllerHome home = (HotelControllerHome)PortableRemoteObject.narrow(objref, HotelControllerHome.class);
	  System.out.println("narrow");

	  HotelControllerRemote remote = home.create();

	  Collection roomss = remote.findRoom(hotelID);
	  System.out.println("end findRoom in OlalaAgencyViewer");
	  return roomss;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of FullRoomInformation
  public FullHotelInformation viewHotel(String hotelID) {
	System.out.println("viewHotel in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("hotelsystem/HotelController");
	  System.out.println("lookup");

	  HotelControllerHome home = (HotelControllerHome)PortableRemoteObject.narrow(objref, HotelControllerHome.class);
	  System.out.println("narrow");

	  HotelControllerRemote remote = home.create();

	  FullHotelInformation hotel = remote.viewHotel(hotelID);
	  System.out.println("end viewHotel in OlalaAgencyViewer");
	  return hotel;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public Collection findRestaurant(String name, String description, String address, int star) {
	System.out.println("findRestaurant in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("restaurantsystem/RestaurantController");
	  System.out.println("lookup");

	  RestaurantControllerHome home = (RestaurantControllerHome)PortableRemoteObject.narrow(objref, RestaurantControllerHome.class);
	  System.out.println("narrow");

	  RestaurantControllerRemote remote = home.create();

	  Collection restaurants = remote.findRestaurant(name, description, address, star);
	  System.out.println("end findRestaurant in OlalaAgencyViewer");
	  return restaurants;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullRestaurantInformation viewRestaurant(String restaurantID) {
	System.out.println("viewRestaurant in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("restaurantsystem/RestaurantController");
	  System.out.println("lookup");

	  RestaurantControllerHome home = (RestaurantControllerHome)PortableRemoteObject.narrow(objref, RestaurantControllerHome.class);
	  System.out.println("narrow");

	  RestaurantControllerRemote remote = home.create();

	  FullRestaurantInformation restaurant = remote.viewRestaurant(restaurantID);
	  System.out.println("end viewRestaurant in OlalaAgencyViewer");
	  return restaurant;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public Collection findPlace(String placeName, String country, String state, String province, String description) {
	System.out.println("findPlace in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Place");
	  System.out.println("lookup");
	  PlaceHome home = (PlaceHome)PortableRemoteObject.narrow(objref, PlaceHome.class);
	  System.out.println("narrow");
	  Collection places = home.findByPlaceNameCountryStateProvinceDescription(placeName, country, state, province, description);
	  ArrayList result = new ArrayList();
	  Iterator i = places.iterator();

	  while (i.hasNext()) {
		PlaceRemote place = (PlaceRemote)i.next();
		result.add(new ShortPlaceInformation(place.getPlaceId(), place.getPlaceName(), place.getPackageTours(), place.getImagefilePath()));
	  }
	  System.out.println("end findPlace in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of ShortPlaceInformation
  public Collection findPackageTour(Collection placeIDs, double price, java.sql.Date departTime, int duration) throws RemoteException {
	System.out.println("findPackageTour in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/PackageTour");
	  System.out.println("lookup");
	  PackageTourHome home = (PackageTourHome)PortableRemoteObject.narrow(objref, PackageTourHome.class);
	  System.out.println("narrow");
	  Collection packageTours = home.findByPlaceIDsPriceDepartTimeDuration(placeIDs, price, departTime, duration);
	  ArrayList result = new ArrayList();
	  Iterator i = packageTours.iterator();

	  while (i.hasNext()) {
		PackageTourRemote packageTour = (PackageTourRemote)i.next();
		result.add(new ShortPackageTourInformation(packageTour.getPackageName(), packageTour.getPackageId(), packageTour.getDescription(), packageTour.getTotalPrice().doubleValue()));
	  }
	  System.out.println("end findPackageTour in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of ShortPackageTourInformation
  public Collection findActivity(String activityName, String description) {
	System.out.println("findActivity in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Activity");
	  System.out.println("lookup");
	  ActivityHome home = (ActivityHome)PortableRemoteObject.narrow(objref, ActivityHome.class);
	  System.out.println("narrow");
	  Collection activities = home.findByActivityNameDetail(activityName, description);
	  ArrayList result = new ArrayList();
	  Iterator i = activities.iterator();

	  while (i.hasNext()) {
		ActivityRemote activity = (ActivityRemote)i.next();
		result.add(new ShortActivityInformation(activity.getActivityId(), activity.getActivityName()));
	  }
	  System.out.println("end findActivity in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of ShortActivityInformation
  public Collection findCategory(String categoryName, String description) {
	System.out.println("findCategory in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Category");
	  System.out.println("lookup");
	  CategoryHome home = (CategoryHome)PortableRemoteObject.narrow(objref, CategoryHome.class);
	  System.out.println("narrow");
	  Collection categories = home.findByCategoryNameDetail(categoryName, description);
	  ArrayList result = new ArrayList();
	  Iterator i = categories.iterator();

	  while (i.hasNext()) {
		CategoryRemote category = (CategoryRemote)i.next();
		result.add(new ShortCategoryInformation(category.getCategoryId(), category.getCategoryName()));
	  }
	  System.out.println("end findCategory in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Colleciton of ShortCategoryInformation
  public Collection findFestival(String festivalName, String description) {
	System.out.println("findFestival in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Festival");
	  System.out.println("lookup");
	  FestivalHome home = (FestivalHome)PortableRemoteObject.narrow(objref, FestivalHome.class);
	  System.out.println("narrow");
	  Collection festivals = home.findByFestivalNameDetail(festivalName, description);
	  ArrayList result = new ArrayList();
	  Iterator i = festivals.iterator();

	  while (i.hasNext()) {
		FestivalRemote festival = (FestivalRemote)i.next();
		result.add(new ShortFestivalInformation(festival.getFestivalId(), festival.getFestivalName()));
	  }
	  System.out.println("end findFestival in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of ShortFestivalInformation


  public FullPlaceInformation viewPlace(String placeID) {
	System.out.println("viewPlace in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Place");
	  System.out.println("lookup");

	  PlaceHome home = (PlaceHome)PortableRemoteObject.narrow(objref, PlaceHome.class);
	  System.out.println("narrow");

	  PlaceRemote remote = home.findByPrimaryKey(placeID);
	  FullPlaceInformation info = new FullPlaceInformation(remote.getPlaceId(), remote.getPlaceName(), remote.getCountry(), remote.getState(), remote.getProvince(), remote.getDescription(), remote.getImagefilePath(), remote.getCategories(), remote.getActivities(), remote.getFestivals(), remote.getPackageTours());

	  System.out.println("end viewPlace in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }

//  viewPackageTour(String packageTourID)... + return Collection of (placeID, departTime) + Collection of guideID

  public FullActivityInformation viewActivity(String activityID) {
	System.out.println("viewActivity in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Activity");
	  System.out.println("lookup");

	  ActivityHome home = (ActivityHome)PortableRemoteObject.narrow(objref, ActivityHome.class);
	  System.out.println("narrow");

	  ActivityRemote remote = home.findByPrimaryKey(activityID);
	  FullActivityInformation info = new FullActivityInformation(remote.getActivityId(), remote.getActivityName(), remote.getActivityDetail(), remote.getPlaces());

	  System.out.println("end viewActivity in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullCategoryInformation viewCategory(String categoryID) {
	System.out.println("viewCategory in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Category");
	  System.out.println("lookup");

	  CategoryHome home = (CategoryHome)PortableRemoteObject.narrow(objref, CategoryHome.class);
	  System.out.println("narrow");

	  CategoryRemote remote = home.findByPrimaryKey(categoryID);
	  FullCategoryInformation info = new FullCategoryInformation(remote.getCategoryId(), remote.getCategoryName(), remote.getDescription(), remote.getPlaces());

	  System.out.println("end viewCategory in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullFestivalInformation viewFestival(String festivalID) {
	System.out.println("viewFestival in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Festival");
	  System.out.println("lookup");

	  FestivalHome home = (FestivalHome)PortableRemoteObject.narrow(objref, FestivalHome.class);
	  System.out.println("narrow");

	  FestivalRemote remote = home.findByPrimaryKey(festivalID);
	  System.out.println("findByPrimaryKey");
	  FullFestivalInformation info = new FullFestivalInformation(remote.getFestivalId(), remote.getFestivalName(), remote.getDescription(), remote.getPlaces());

	  System.out.println("end viewFestival in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }

//  public FullBookingInformation viewBooking(String bookingID) throws RemoteException;

  public FullTravellerInformation viewTraveller(String travellerID) {
	System.out.println("viewTraveller in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Traveller");
	  System.out.println("lookup");

	  TravellerHome home = (TravellerHome)PortableRemoteObject.narrow(objref, TravellerHome.class);
	  System.out.println("narrow");

	  TravellerRemote remote = home.findByPrimaryKey(travellerID);
	  FullTravellerInformation info = new FullTravellerInformation(remote.getTravellerId(), remote.getFirstName(), remote.getLastName(), remote.getAddress(), remote.getTelephoneNo(), remote.getGender().intValue(), remote.getBirthDate(), remote.getReligion(), remote.getFoodTypeId(), remote.getEmailAddress());

	  System.out.println("end viewTraveller in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullMemberInformation viewMember(String memberID) {
	System.out.println("viewMember in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Member");
	  System.out.println("lookup");

	  MemberHome home = (MemberHome)PortableRemoteObject.narrow(objref, MemberHome.class);
	  System.out.println("narrow");

	  MemberRemote remote = home.findByPrimaryKey(memberID);
	  FullMemberInformation info = new FullMemberInformation(remote.getMemberId(), remote.getFirstName(), remote.getLastName(), remote.getAddress(), remote.getTelephoneNo(), remote.getEmailAddress(), remote.getGender().intValue(), remote.getBirthDate(), remote.getReligion(), remote.getTravellers());

	  System.out.println("end viewMember in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullGuideInformation viewGuide(String guideID) {
	System.out.println("viewGuide in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Guide");
	  System.out.println("lookup");

	  GuideHome home = (GuideHome)PortableRemoteObject.narrow(objref, GuideHome.class);
	  System.out.println("narrow");

	  GuideRemote remote = home.findByPrimaryKey(guideID);
	  FullGuideInformation info = new FullGuideInformation(remote.getGuideId(), remote.getFirstName(), remote.getLastName(), remote.getGender().intValue(), remote.getSpokenLanguage(), remote.getOfficeAddress());

	  System.out.println("end viewGuide in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public  Collection searchBusSeat( String SrcStationID, String DstStationID, int TotalSeat, java.sql.Date  DepartDate, int CompanyID, int ClassType, int SeatType) {
	System.out.println("searchBusSeat in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("busservice/SearchController");
	  System.out.println("lookup");

	  busservice.SearchControllerHome home = (busservice.SearchControllerHome)PortableRemoteObject.narrow(objref, busservice.SearchControllerHome.class);
	  System.out.println("narrow");

	  busservice.SearchController remote = home.create();
	  Collection result = remote.SearchSeat(SrcStationID, DstStationID, TotalSeat, DepartDate, CompanyID, ClassType, SeatType);

	  System.out.println("end searchBusSeat in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public  Collection  searchBusCompany(String Keyword) {
	System.out.println("searchBusCompany in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("busservice/SearchController");
	  System.out.println("lookup");

	  busservice.SearchControllerHome home = (busservice.SearchControllerHome)PortableRemoteObject.narrow(objref, busservice.SearchControllerHome.class);
	  System.out.println("narrow");

	  busservice.SearchController remote = home.create();
	  Collection result = remote.SearchCompany(Keyword);

	  System.out.println("end searchBusCompany in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public  Collection searchBusStation(String keyword) {
	System.out.println("searchBusStation in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("busservice/SearchController");
	  System.out.println("lookup");

	  busservice.SearchControllerHome home = (busservice.SearchControllerHome)PortableRemoteObject.narrow(objref, busservice.SearchControllerHome.class);
	  System.out.println("narrow");

	  busservice.SearchController remote = home.create();
	  Collection result = remote.SearchStation(keyword);

	  System.out.println("end searchBusStation in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public Collection searchAirline(String Keyword) {
	System.out.println("searchAirline in OlalaAgencyViewer.");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("airlinesystem/SearchController");
	  System.out.println("lookup");

	  airlinesystem.SearchControllerHome home = (airlinesystem.SearchControllerHome)PortableRemoteObject.narrow(objref, airlinesystem.SearchControllerHome.class);
	  System.out.println("narrow");

	  airlinesystem.SearchControllerRemote remote = home.create();
	  System.out.println("create");
	  Collection result = remote.SearchAirline(Keyword);

	  System.out.println("end searchAirline in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public Collection searchAirport(String Keyword) {
	System.out.println("searchAirport in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("airlinesystem/SearchController");
	  System.out.println("lookup");

	  airlinesystem.SearchControllerHome home = (airlinesystem.SearchControllerHome)PortableRemoteObject.narrow(objref, airlinesystem.SearchControllerHome.class);
	  System.out.println("narrow");

	  airlinesystem.SearchControllerRemote remote = home.create();
	  Collection result = remote.SearchAirport(Keyword);

	  System.out.println("end searchAirport in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public Collection searchAirplaneSeat(String strSrcAirportID ,String strDstStationID, int totalSeat, java.sql.Date departDate, int airlineID, int classType, int seatType, boolean canSmoking, boolean nonStop, int order) {
	System.out.println("searchAirplaneSeat in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("airlinesystem/SearchController");
	  System.out.println("lookup");

	  airlinesystem.SearchControllerHome home = (airlinesystem.SearchControllerHome)PortableRemoteObject.narrow(objref, airlinesystem.SearchControllerHome.class);
	  System.out.println("narrow");

	  airlinesystem.SearchControllerRemote remote = home.create();
	  Collection result = remote.SearchSeat(strSrcAirportID, strDstStationID, totalSeat, departDate, airlineID, classType, seatType, canSmoking, nonStop, order);

	  System.out.println("end searchAirplaneSeat in OlalaAgencyViewer");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullPackageTourInformation viewPackageTour(String packageTourID) {
	System.out.println("findPackageTour in OlalaAgencyViewer");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/PackageTour");
	  System.out.println("lookup");
	  PackageTourHome home = (PackageTourHome)PortableRemoteObject.narrow(objref, PackageTourHome.class);
	  System.out.println("narrow");
	  PackageTourRemote packageTour = home.findByPrimaryKey(packageTourID);

	  FullPackageTourInformation info = new FullPackageTourInformation(packageTourID, packageTour.getPackageName(), packageTour.getDescription(), packageTour.getPackagePlaces(), packageTour.getPackageTourDepartTimeInformations(new java.sql.Date(System.currentTimeMillis())), packageTour.getTotalPrice().doubleValue(), packageTour.getDuration().intValue());
	  System.out.println("end findPackageTour in OlalaAgencyViewer");
	  return info;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullBookingInformation viewBooking(String bookingID) {
	/** @todo ask another for view booking */
	return null;
  }

}