package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface FestivalRemote extends EJBObject {
    String getFestivalId() throws RemoteException;
    String getFestivalName() throws RemoteException;
    void setFestivalName(String festivalName) throws RemoteException;
    String getDescription() throws RemoteException;
    void setDescription(String description) throws RemoteException;
    Collection getPlaces() throws RemoteException;
}