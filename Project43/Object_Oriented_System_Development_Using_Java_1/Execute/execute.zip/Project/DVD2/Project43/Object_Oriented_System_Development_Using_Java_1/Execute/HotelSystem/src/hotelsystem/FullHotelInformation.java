package hotelsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullHotelInformation implements Serializable {

  public FullHotelInformation(String hotelID, String name, String description, String address, String telephoneNo, String accountID) {
	  this.hotelID = hotelID;
	  this.name = name;
	  this.description = description;
	  this.address = address;
	  this.telephoneNo = telephoneNo;
	  this.accountID = accountID;
	  this.star = star;
  }
  private String hotelID;
  private String name;
  private String description;
  private String address;
  private String telephoneNo;
  private String accountID;
  private int star;
  public String getHotelID() {
	return hotelID;
  }
  public String getName() {
	return name;
  }
  public String getDescription() {
	return description;
  }
  public String getAddress() {
	return address;
  }
  public int getStar() {
	return star;
  }
  public String getTelephoneNo() {
	return telephoneNo;
  }
  public String getAccountID() {
	return accountID;
  }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
}