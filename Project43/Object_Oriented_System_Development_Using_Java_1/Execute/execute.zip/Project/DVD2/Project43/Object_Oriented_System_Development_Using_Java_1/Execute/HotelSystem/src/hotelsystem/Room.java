package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Room implements EntityBean {
  EntityContext entityContext;
  public String roomNo;
  public String hotelID;
  public double pricePerDay;
  public String description;
  public int numberOfSingleBed;
  public int numberOfCoupleBed;
  public int numberOfMaximumGuest;
  public int roomClass;
  public int floor;
  public String telephoneNo;

  private Connection con;
  private String dbName = "java:comp/env/jdbc/HotelDB";


  public RoomPK ejbCreate(String roomNo, String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass, int floor) throws CreateException {
	  System.out.println("ejbCreate");

	  try {
		insertRow(roomNo, hotelID, pricePerDay, description, numberOfSingleBed, numberOfCoupleBed, numberOfMaximumGuest, roomClass, floor);
	  } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
		  ex.getMessage());
	  }

	  this.roomNo = roomNo;
	  this.hotelID = hotelID;
	  this.pricePerDay = pricePerDay;
	  this.description = description;
	  this.numberOfSingleBed = numberOfSingleBed;
	  this.numberOfCoupleBed = numberOfCoupleBed;
	  this.numberOfMaximumGuest = numberOfMaximumGuest;
	  this.roomClass = roomClass;
	  this.floor = floor;

	  System.out.println("end ejbCreate");

	  return new RoomPK(roomNo, hotelID);
  }
  public void ejbPostCreate(String roomNo, String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass, int floor) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
	System.out.println("ejbRomove");
	  try {
	 deleteRow(roomNo, hotelID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbRomove");
  }
  public RoomPK ejbFindByPrimaryKey(RoomPK primKey) throws FinderException {
	  System.out.println("ejbFindByPrimaryKey");

	  boolean result;

	  try {
	 result = selectByPrimaryKey(primKey);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
		  ex.getMessage());
	   }
	  if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
	  }
	  else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
		("Row for id " + primKey + " not found.");
	  }
  }
  public Collection ejbFindByHotel(String hotelID) throws FinderException {
	  System.out.println("ejbFindByHotel in Room");
	  Collection result;

	  try {
		result = selectByHotel(hotelID);
	  } catch (Exception ex) {
		throw new EJBException("ejbFindByHotel: " + ex.getMessage());
	  }
	  if (result.isEmpty()) {
		throw new ObjectNotFoundException("No rows found.");
	  }
	  else {
		System.out.println("end ejbFindByHotel : " + hotelID + " : " + result.size());
		return result;
	  }
  }
  public Collection ejbFindByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass(String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int roomClass) throws FinderException {
	  System.out.println("ejbFindByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass");
	  Collection result;

	  try {
		result = selectByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass(hotelID, pricePerDay, description, numberOfSingleBed, numberOfCoupleBed, roomClass);
	  } catch (Exception ex) {
		throw new EJBException("ejbFindByPrimaryKey: " + ex.getMessage());
	  }
	  if (result.isEmpty()) {
		throw new ObjectNotFoundException("No rows found.");
	  }
	  else {
		System.out.println("end ejbFindByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass");
		return result;
	  }
  }
  public void ejbActivate() {
	System.out.println("ejbActivate");
	roomNo = ((RoomPK)entityContext.getPrimaryKey()).getRoomNo();
	hotelID = ((RoomPK)entityContext.getPrimaryKey()).getHotelID();
	System.out.println("end ejbActivate");
  }
  public void ejbPassivate() {
	System.out.println("ejbPassivate");
	roomNo = null;
	hotelID = null;
	System.out.println("end ejbPassivate");
  }
  public void ejbLoad() {
	System.out.println("ejbLoad");
	  try {
	 loadRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
		  ex.getMessage());
	   }
	  System.out.println("end ejbLoad");
  }
  public void ejbStore() {
	System.out.println("ejbLoad");
	  try {
	 storeRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbLoad");
  }
  public void setEntityContext(EntityContext entityContext) {
	System.out.println("setEntityContext");
	this.entityContext = entityContext;
	  try {
	 makeConnection();
	  } catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
		 ex.getMessage());
	  }
	System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
	System.out.println("unsetEntityContext");
	entityContext = null;
	  try {
	 con.close();
	  } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
	  }
	System.out.println("end unsetEntityContext");
  }
  public String getRoomNo() {
	return roomNo;
  }
  public String getHotelID() {
	return hotelID;
  }
  public void setPricePerDay(double newPricePerDay) {
	pricePerDay = newPricePerDay;
  }
  public double getPricePerDay() {
	return pricePerDay;
  }
  public void setDescription(String newDescription) {
	description = newDescription;
  }
  public String getDescription() {
	return description;
  }
  public void setNumberOfSingleBed(int newNumberOfSingleBed) {
	numberOfSingleBed = newNumberOfSingleBed;
  }
  public int getNumberOfSingleBed() {
	return numberOfSingleBed;
  }
  public void setNumberOfCoupleBed(int newNumberOfCoupleBed) {
	numberOfCoupleBed = newNumberOfCoupleBed;
  }
  public int getNumberOfCoupleBed() {
	return numberOfCoupleBed;
  }
  public void setNumberOfMaximumGuest(int newNumberOfMaximumGuest) {
	numberOfMaximumGuest = newNumberOfMaximumGuest;
  }
  public int getNumberOfMaximumGuest() {
	return numberOfMaximumGuest;
  }
  public void setRoomClass(int newRoomClass) {
	roomClass = newRoomClass;
  }
  public int getRoomClass() {
	return roomClass;
  }
  public void setFloor(int newFloor) {
	floor = newFloor;
  }
  public int getFloor() {
	return floor;
  }
  public void setHotelID(String newHotelID) {
	hotelID = newHotelID;
  }
/*********************** Database Routines *************************/

   private void makeConnection() throws NamingException, SQLException {
	  System.out.println("makeConnection");
	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup(dbName);
	  con =  ds.getConnection();
	  System.out.println("end makeConnection");
   }

   private void insertRow (String roomNo, String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass, int floor) throws SQLException {
	  System.out.println("insertRow");
	  String insertStatement =
		"insert into ROOM(ROOM_NO, HOTEL_ID, PRICE_PER_DAY, DESCRIPTION, NUMBER_OF_SINGLE_BED, NUMBER_OF_COUPLE_BED, NUMBER_OF_MAXIMUM_GUEST, ROOM_CLASS, FLOOR) values ( ? , ? , ? , ? , ? , ? , ? , ? , ?)";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, roomNo);
	  prepStmt.setString(2, hotelID);
	  prepStmt.setDouble(3, pricePerDay);
	  prepStmt.setString(4, description);
	  prepStmt.setInt(5, numberOfSingleBed);
	  prepStmt.setInt(6, numberOfCoupleBed);
	  prepStmt.setInt(7, numberOfMaximumGuest);
	  prepStmt.setInt(8, roomClass);
	  prepStmt.setInt(9, floor);

	  prepStmt.executeUpdate();
	  prepStmt.close();
	  System.out.println("end insertRow");
   }

   private void deleteRow(String roomNo, String hotelID) throws SQLException {
	  System.out.println("deleteRow");
	  String deleteStatement =
		"delete from ROOM where ROOM_NO = ? AND HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(deleteStatement);

	  prepStmt.setString(1, roomNo);
	  prepStmt.setString(2, hotelID);

	  prepStmt.executeUpdate();
	  prepStmt.close();
	  System.out.println("end deleteRow");
   }

   private boolean selectByPrimaryKey(RoomPK primaryKey) throws SQLException {
	  System.out.println("selectByPrimaryKey");

	  String selectStatement =
		"select ROOM_NO, HOTEL_ID " +
		"from ROOM where ROOM_NO = ? AND HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);
	  prepStmt.setString(1, primaryKey.getRoomNo());
	  prepStmt.setString(2, primaryKey.getHotelID());

	  ResultSet rs = prepStmt.executeQuery();
	  boolean result = rs.next();
	  prepStmt.close();
	  System.out.println("end selectByPrimaryKey");
	  return result;
   }
   private Collection selectByHotel(String hotelID) throws SQLException {
	  System.out.println("selectByHotel : ..s" + hotelID);
	  String selectStatement =
		"select ROOM_NO, HOTEL_ID " +
		"from ROOM where HOTEL_ID = ? ";
	  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
	  System.out.println("prepare");
	  prepStmt.setString(1, hotelID);
	  System.out.println("setString");

	  ResultSet rs = prepStmt.executeQuery();
	  System.out.println("execute");

	  ArrayList a = new ArrayList();

	  while (rs.next()) {
		  String _roomNo = rs.getString(1);
		  String _hotelID = rs.getString(2);
		  a.add(new RoomPK(_roomNo, _hotelID));
	  }

	  prepStmt.close();
	  System.out.println("end selectByHotel : " + hotelID + " : " + a.size());
	  return a;
   }
   private void loadRow() throws SQLException {
	  System.out.println("loadRow");

	  String selectStatement =
		"select PRICE_PER_DAY, DESCRIPTION, NUMBER_OF_SINGLE_BED, NUMBER_OF_COUPLE_BED, NUMBER_OF_MAXIMUM_GUEST, ROOM_CLASS, FLOOR " +
		"from ROOM where ROOM_NO = ? AND HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, this.roomNo);
	  prepStmt.setString(2, this.hotelID);

	  ResultSet rs = prepStmt.executeQuery();

	  if (rs.next()) {
		this.pricePerDay = rs.getDouble(1);
		this.description = rs.getString(2);
		this.numberOfSingleBed = rs.getInt(3);
		this.numberOfCoupleBed = rs.getInt(4);
		this.numberOfMaximumGuest = rs.getInt(5);
		this.roomClass = rs.getInt(6);
		this.floor = rs.getInt(7);
		prepStmt.close();
	  }
	  else {
		prepStmt.close();
		throw new NoSuchEntityException("Row for id " + roomNo + " : " + hotelID +
		" not found in database.");
	  }
	  System.out.println("end loadRow");
   }

   private void storeRow() throws SQLException {
	  System.out.println("storeRow");
	  String updateStatement =
		"update ROOM set " +
		"PRICE_PER_DAY =  ? ," +
		"DESCRIPTION = ? ," +
		"NUMBER_OF_SINGLE_BED = ? ," +
		"NUMBER_OF_COUPLE_BED = ? ," +
		"NUMBER_OF_MAXIMUM_GUEST = ? ," +
		"ROOM_CLASS = ? ," +
		"FLOOR = ? " +
		"where ROOM_NO = ? AND HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(updateStatement);

	  prepStmt.setDouble(1, pricePerDay);
	  prepStmt.setString(2, description);
	  prepStmt.setInt(3, numberOfSingleBed);
	  prepStmt.setInt(4, numberOfCoupleBed);
	  prepStmt.setInt(5, numberOfMaximumGuest);
	  prepStmt.setInt(6, roomClass);
	  prepStmt.setInt(7, floor);

	  prepStmt.setString(8, roomNo);
	  prepStmt.setString(9, hotelID);

	  int rowCount = prepStmt.executeUpdate();
	  prepStmt.close();

	  if (rowCount == 0) {
		throw new EJBException("Storing row for id " + roomNo + " : " + hotelID + " failed.");
	  }
	  System.out.println("end storeRow");
   }
  public void setTelephoneNo(String newTelephoneNo) {
	telephoneNo = newTelephoneNo;
  }
  public String getTelephoneNo() {
	return telephoneNo;
  }
   private Collection selectByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass(String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int roomClass) throws SQLException {
	  System.out.println("selectByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass");
	  String selectStatement =
		"select ROOM_NO, HOTEL_ID " +
		"from ROOM where HOTEL_ID = ? AND PRICE_PER_DAY <= ? AND DESCRIPTION LIKE ? AND NUMBER_OF_SINGLE_BED <= ? AND NUMBER_OF_COUPLE_BED <= ? AND ROOM_CLASS <= ? ";
	  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
	  System.out.println("prepareStatement");
	  prepStmt.setString(1, hotelID);
	  prepStmt.setDouble(2, pricePerDay);
	  prepStmt.setString(3, "%" + description + "%");
	  prepStmt.setInt(4, numberOfSingleBed);
	  prepStmt.setInt(5, numberOfCoupleBed);
	  prepStmt.setInt(6, roomClass);
	  ResultSet rs = prepStmt.executeQuery();
	  System.out.println("executeQuery");

	  ArrayList a = new ArrayList();

	  while (rs.next()) {
		  String _roomNo = rs.getString(1);
		  String _hotelID = rs.getString(2);
		  a.add(new RoomPK(_roomNo, _hotelID));
	  }

	  prepStmt.close();
	  System.out.println("end selectByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass");
	  return a;
   }

}