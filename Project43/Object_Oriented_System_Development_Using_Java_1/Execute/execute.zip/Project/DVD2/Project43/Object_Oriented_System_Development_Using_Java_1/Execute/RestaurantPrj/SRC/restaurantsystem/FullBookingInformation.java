package restaurantsystem;

import java.io.*;
import java.sql.Date;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullBookingInformation implements Serializable {

  public FullBookingInformation(String bookingID, String restaurantID, int meal, Date dateTime, int confirmation, int noOfReserveSeat, String agencyID) {
    this.bookingID = bookingID;
    this.restaurantID = restaurantID;
    this.meal = meal;
    this.dateTime = dateTime;
    this.confirmation = confirmation;
    this.noOfReserveSeat = noOfReserveSeat;
    this.agencyID = agencyID;
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  public String getBookingID() {
    return bookingID;
  }
  public String getRestaurantID() {
    return restaurantID;
  }
  public int getMeal() {
    return meal;
  }
  public java.sql.Date getDateTime() {
    return dateTime;
  }
  public int getConfirmation() {
    return confirmation;
  }
  public int getNoOfReserveSeat() {
    return noOfReserveSeat;
  }
  public String getAgencyID() {
    return agencyID;
  }
  private String bookingID;
  private String restaurantID;
  private int meal;
  private int confirmation;
  private int noOfReserveSeat;
  private String agencyID;
    private java.sql.Date dateTime;
}