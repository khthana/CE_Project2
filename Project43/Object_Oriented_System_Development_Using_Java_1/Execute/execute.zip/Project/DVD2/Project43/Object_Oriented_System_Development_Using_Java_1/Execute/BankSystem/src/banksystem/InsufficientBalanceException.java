package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InsufficientBalanceException extends Exception {

   public InsufficientBalanceException() { }

   public InsufficientBalanceException(String msg) {
      super(msg);
   }
}