package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Festival implements EntityBean {
    EntityContext entityContext;
    public String festivalId;
    public String festivalName;
    public String description;
    public String ejbCreate(String festivalId, String festivalName, String description) throws CreateException {
	this.festivalId = festivalId;
	this.festivalName = festivalName;
	this.description = description;
	return null;
    }
    public String ejbCreate(String festivalId) throws CreateException {
	return ejbCreate(festivalId, null, null);
    }
    public void ejbPostCreate(String festivalId, String festivalName, String description) throws CreateException {
    }
    public void ejbPostCreate(String festivalId) throws CreateException {
	ejbPostCreate(festivalId, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getFestivalId() {
	return festivalId;
    }
    public String getFestivalName() {
	return festivalName;
    }
    public void setFestivalName(String festivalName) {
	this.festivalName = festivalName;
    }
    public String getDescription() {
	return description;
    }
    public void setDescription(String description) {
	this.description = description;
    }
}