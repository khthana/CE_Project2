package banksystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface UUIDGeneratorHome extends EJBHome {
  public UUIDGeneratorRemote create() throws RemoteException, CreateException;
}