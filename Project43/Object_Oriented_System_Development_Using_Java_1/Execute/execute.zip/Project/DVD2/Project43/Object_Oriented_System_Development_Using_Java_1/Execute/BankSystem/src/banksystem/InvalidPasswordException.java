package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidPasswordException extends Exception {

   public InvalidPasswordException() { }

   public InvalidPasswordException(String msg) {
      super(msg);
   }
}