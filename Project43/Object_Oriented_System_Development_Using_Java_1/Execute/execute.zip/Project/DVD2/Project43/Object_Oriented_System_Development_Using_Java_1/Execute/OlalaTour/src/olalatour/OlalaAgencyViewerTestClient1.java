package olalatour;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import hotelsystem.FullHotelInformation;
import restaurantsystem.FullRestaurantInformation;
import java.sql.Date;
import java.util.Iterator;
import restaurantsystem.*;
import hotelsystem.*;
import airlinesystem.*;
import java.util.Collection;
import java.util.ArrayList;
import java.util.ListIterator;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class OlalaAgencyViewerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 250;
  private boolean logging = true;
  private OlalaAgencyViewerHome olalaAgencyViewerHome = null;
  private OlalaAgencyViewerRemote olalaAgencyViewerRemote = null;

  /**Construct the EJB test client*/
  public OlalaAgencyViewerTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("olalatour/OlalaAgencyViewer");

	  //cast to Home interface
	  olalaAgencyViewerHome = (OlalaAgencyViewerHome) PortableRemoteObject.narrow(ref, OlalaAgencyViewerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public OlalaAgencyViewerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  olalaAgencyViewerRemote = olalaAgencyViewerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + olalaAgencyViewerRemote + ".");
	}
	return olalaAgencyViewerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public Collection findHotel(String name, String description, String address, int star) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findHotel(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findHotel(" + name + ", " + description + ", " + address + ", " + star + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findHotel(name, description, address, star);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findHotel(" + name + ", " + description + ", " + address + ", " + star + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findHotel(" + name + ", " + description + ", " + address + ", " + star + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findHotel(" + name + ", " + description + ", " + address + ", " + star + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findRoom(String hotelID) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findRoom(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findRoom(" + hotelID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findRoom(hotelID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findRoom(" + hotelID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findRoom(" + hotelID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findRoom(" + hotelID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullHotelInformation viewHotel(String hotelID) {
	FullHotelInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewHotel(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewHotel(" + hotelID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewHotel(hotelID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewHotel(" + hotelID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewHotel(" + hotelID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewHotel(" + hotelID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findRestaurant(String name, String description, String address, int star) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findRestaurant(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findRestaurant(" + name + ", " + description + ", " + address + ", " + star + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findRestaurant(name, description, address, star);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findRestaurant(" + name + ", " + description + ", " + address + ", " + star + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findRestaurant(" + name + ", " + description + ", " + address + ", " + star + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findRestaurant(" + name + ", " + description + ", " + address + ", " + star + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullRestaurantInformation viewRestaurant(String restaurantID) {
	FullRestaurantInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewRestaurant(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewRestaurant(" + restaurantID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewRestaurant(restaurantID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewRestaurant(" + restaurantID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewRestaurant(" + restaurantID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewRestaurant(" + restaurantID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection searchAirline(String Keyword) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in searchAirline(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling searchAirline(" + Keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.searchAirline(Keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: searchAirline(" + Keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: searchAirline(" + Keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from searchAirline(" + Keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection searchAirport(String Keyword) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in searchAirport(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling searchAirport(" + Keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.searchAirport(Keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: searchAirport(" + Keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: searchAirport(" + Keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from searchAirport(" + Keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection searchAirplaneSeat(String strSrcAirportID, String strDstStationID, int totalSeat, Date departDate, int airlineID, int classType, int seatType, boolean canSmoking, boolean nonStop, int order) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in searchAirplaneSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling searchAirplaneSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + totalSeat + ", " + departDate + ", " + airlineID + ", " + classType + ", " + seatType + ", " + canSmoking + ", " + nonStop + ", " + order + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.searchAirplaneSeat(strSrcAirportID, strDstStationID, totalSeat, departDate, airlineID, classType, seatType, canSmoking, nonStop, order);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: searchAirplaneSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + totalSeat + ", " + departDate + ", " + airlineID + ", " + classType + ", " + seatType + ", " + canSmoking + ", " + nonStop + ", " + order + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: searchAirplaneSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + totalSeat + ", " + departDate + ", " + airlineID + ", " + classType + ", " + seatType + ", " + canSmoking + ", " + nonStop + ", " + order + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from searchAirplaneSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + totalSeat + ", " + departDate + ", " + airlineID + ", " + classType + ", " + seatType + ", " + canSmoking + ", " + nonStop + ", " + order + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection searchBusSeat(String SrcStationID, String DstStationID, int TotalSeat, Date DepartDate, int CompanyID, int ClassType, int SeatType) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in searchBusSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling searchBusSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.searchBusSeat(SrcStationID, DstStationID, TotalSeat, DepartDate, CompanyID, ClassType, SeatType);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: searchBusSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: searchBusSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from searchBusSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection searchBusCompany(String Keyword) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in searchBusCompany(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling searchBusCompany(" + Keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.searchBusCompany(Keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: searchBusCompany(" + Keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: searchBusCompany(" + Keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from searchBusCompany(" + Keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection searchBusStation(String keyword) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in searchBusStation(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling searchBusStation(" + keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.searchBusStation(keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: searchBusStation(" + keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: searchBusStation(" + keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from searchBusStation(" + keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findPlace(String placeName, String country, String state, String province, String description) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findPlace(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findPlace(" + placeName + ", " + country + ", " + state + ", " + province + ", " + description + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findPlace(placeName, country, state, province, description);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findPlace(" + placeName + ", " + country + ", " + state + ", " + province + ", " + description + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findPlace(" + placeName + ", " + country + ", " + state + ", " + province + ", " + description + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findPlace(" + placeName + ", " + country + ", " + state + ", " + province + ", " + description + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findPackageTour(Collection placeIDs, double price, Date departTime, int duration) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findPackageTour(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findPackageTour(" + placeIDs + ", " + price + ", " + departTime + ", " + duration + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findPackageTour(placeIDs, price, departTime, duration);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findPackageTour(" + placeIDs + ", " + price + ", " + departTime + ", " + duration + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findPackageTour(" + placeIDs + ", " + price + ", " + departTime + ", " + duration + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findPackageTour(" + placeIDs + ", " + price + ", " + departTime + ", " + duration + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findActivity(String activityName, String description) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findActivity(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findActivity(" + activityName + ", " + description + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findActivity(activityName, description);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findActivity(" + activityName + ", " + description + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findActivity(" + activityName + ", " + description + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findActivity(" + activityName + ", " + description + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findCategory(String categoryName, String description) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findCategory(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findCategory(" + categoryName + ", " + description + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findCategory(categoryName, description);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findCategory(" + categoryName + ", " + description + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findCategory(" + categoryName + ", " + description + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findCategory(" + categoryName + ", " + description + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findFestival(String festivalName, String description) {
	Collection returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in findFestival(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findFestival(" + festivalName + ", " + description + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.findFestival(festivalName, description);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findFestival(" + festivalName + ", " + description + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findFestival(" + festivalName + ", " + description + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findFestival(" + festivalName + ", " + description + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullPlaceInformation viewPlace(String placeID) {
	FullPlaceInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewPlace(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewPlace(" + placeID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewPlace(placeID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewPlace(" + placeID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewPlace(" + placeID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewPlace(" + placeID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullPackageTourInformation viewPackageTour(String packageTourID) {
	FullPackageTourInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewPackageTour(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewPackageTour(" + packageTourID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewPackageTour(packageTourID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewPackageTour(" + packageTourID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewPackageTour(" + packageTourID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewPackageTour(" + packageTourID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullActivityInformation viewActivity(String activityID) {
	FullActivityInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewActivity(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewActivity(" + activityID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewActivity(activityID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewActivity(" + activityID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewActivity(" + activityID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewActivity(" + activityID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullCategoryInformation viewCategory(String categoryID) {
	FullCategoryInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewCategory(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewCategory(" + categoryID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewCategory(categoryID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewCategory(" + categoryID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewCategory(" + categoryID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewCategory(" + categoryID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullFestivalInformation viewFestival(String festivalID) {
	FullFestivalInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewFestival(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewFestival(" + festivalID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewFestival(festivalID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewFestival(" + festivalID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewFestival(" + festivalID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewFestival(" + festivalID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullBookingInformation viewBooking(String bookingID) {
	FullBookingInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewBooking(" + bookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewBooking(bookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewBooking(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewBooking(" + bookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewBooking(" + bookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullTravellerInformation viewTraveller(String travellerID) {
	FullTravellerInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewTraveller(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewTraveller(" + travellerID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewTraveller(travellerID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewTraveller(" + travellerID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewTraveller(" + travellerID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewTraveller(" + travellerID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullMemberInformation viewMember(String memberID) {
	FullMemberInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewMember(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewMember(" + memberID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewMember(memberID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewMember(" + memberID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewMember(" + memberID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewMember(" + memberID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullGuideInformation viewGuide(String guideID) {
	FullGuideInformation returnValue = null;
	if (olalaAgencyViewerRemote == null) {
	  System.out.println("Error in viewGuide(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewGuide(" + guideID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyViewerRemote.viewGuide(guideID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewGuide(" + guideID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewGuide(" + guideID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewGuide(" + guideID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	OlalaAgencyViewerTestClient1 client = new OlalaAgencyViewerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.

	client.create();
//--------------------------------OLALA-------------------------------
	// test findActivity >>>>>>>>>>>>> OK
//	Collection c = client.findActivity("", "");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  ShortActivityInformation info = (ShortActivityInformation)i.next();
//	  System.out.println("id : " + info.getActivityID() + " name : "  + info.getActivityName());
//	}

	// test findCategory >>>>>>>>>>>>>> OK
//	Collection c = client.findCategory("", "");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  ShortCategoryInformation info = (ShortCategoryInformation)i.next();
//	  System.out.println("id : " + info.getCategoryID() + " name : "  + info.getCategoryName());
//	}

	// test findFestival>>>>>>>>>>>>>>> OK
//	Collection c = client.findFestival("", "");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  ShortFestivalInformation info = (ShortFestivalInformation)i.next();
//	  System.out.println("id : " + info.getFestivalID() + " name : "  + info.getFestivalName());
//	}

	// test findPlace  >>>>>>>>>>>>>>>>>>>>>>>>>> OK
//	Collection c = client.findPlace("PLACE_NAME_1","COUNTRY_1","STATE_1","PROVINCE_1","DESCRIPTION_1");
//	Collection c = client.findPlace("","","","","");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  ShortPlaceInformation info = (ShortPlaceInformation)i.next();
//	  System.out.println("id : " + info.getPlaceID() + " name : "  + info.getPlaceName());
//	}
	// test findPackageTour  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	Collection x = new ArrayList();
//	x.add(new String("PLACE_ID_1"));
//	x.add(new String("PLACE_ID_2"));
//	Collection c = client.findPackageTour(x, 5000, new Date(500000), 5000);
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  ShortPackageTourInformation info = (ShortPackageTourInformation)i.next();
//	  System.out.println("id : " + info.getPackageID() + " name : "  + info.getPackageName());
//	}

	// test viewActivity  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	FullActivityInformation c = client.viewActivity("ACTIVITY_ID_1");
//	System.out.println("" + c.getActivityID() + "" + c.getActivityName());

	// test viewCategory  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	FullCategoryInformation c = client.viewCategory("CATEGORY_ID_1");
//	System.out.println("" + c.getCategoryID() + "" + c.getCategoryName());

	// test viewFestival  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	FullFestivalInformation c = client.viewFestival("FESTIVAL_ID_1");
//	System.out.println("" + c.getFestivalID() + "" + c.getFestivalID());

	// test viewGuide  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	FullGuideInformation c = client.viewGuide("GUIDE__ID_1");
//	System.out.println("" + c.getGuideID() + "" + c.getFirstName());

	// test viewTraveller  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	FullTravellerInformation c2 = client.viewTraveller("TRAVELLER_ID_1");
//	System.out.println("" + c2.getFirstName() + "" + c2.getTelephoneNo());

	// test viewMember  >>>>>>>>>>>>>>>>>>>>>>>>>> ok
//	FullMemberInformation c3 = client.viewMember("MEMBER_ID_1");
//	System.out.println("" + c3.getFirstName() + "" + c3.getLastName() );

//--------------------------------OLALA-------------------------------
//--------------------------------HOTEL--------------------------------
	// test findHotel
//	Collection c = client.findHotel("","","",991);  // >>>>>>>>>>>>>>>>> ok (rollbank means not found)
//	Collection c = client.findHotel("HOTEL_NAME1","HOTEL_DES1","ADDRESS1",51); //>>>> OK
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  hotelsystem.ShortHotelInformation info = (hotelsystem.ShortHotelInformation)i.next();
//	  System.out.println("id : " + info.getHotelID() + " name : "  + info.getHotelName());
//	}

	// test findRoom >>>>>>>>>>>>>>>>>>> ok
//	Collection c = client.findRoom("H0001");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  FullRoomInformation info = (FullRoomInformation)i.next();
//	  System.out.println("class : " + info.getRoomClass() + " name : "  + info.getDescription());
//	}

	// test viewHotel ok
//	hotelsystem.FullHotelInformation info = client.viewHotel("H0001");
//	System.out.println("id " + info.getHotelID() + " name " + info.getName());

//--------------------------------HOTEL--------------------------------

//--------------------------------RESTAURANT-----------------------------
	// test findRestaurant  >>>>>>>>>>>>>>>>>>>>>>>>>> NOT YET
//	Collection c = client.findRestaurant("","","",500);
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  ShortRestaurantInformation info = (ShortRestaurantInformation )i.next();
//	  System.out.println("id : " + info.getRestaurantID() + " name : "  + info.getName());
//	}
//--------------------------------RESTAURANT-----------------------------

//--------------------------------AIRLINE---------------------------------
	// test searchAirline // ok
//	Collection c = client.searchAirline("");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  AirlineRec info = (AirlineRec)i.next();
//	  System.out.println("class : " + info.getAirlineID() + " name : "  + info.getAirlineName());
//	}

	// test searchAirport ok
//	Collection c = client.searchAirport("");
//	Iterator i = c.iterator();
//	while (i.hasNext()) {
//	  AirportRec info = (AirportRec)i.next();
//	  System.out.println("class : " + info.getPlaceID() + " name : "  + info.getPlaceName());
//	}

	// test SearchSeat ok
		java.sql.Date date = java.sql.Date.valueOf("2001-05-09");
		Collection SeatRecs = client.searchAirplaneSeat("BKK","CNX",1,date,0,0,0,false,false,0);
		Iterator iterator = SeatRecs.iterator();
		while (iterator.hasNext()) {
		SeatRec item = (SeatRec)iterator.next();
		System.out.println(
			item.getAirlineName()+ " " +
			item.getFlightID() + " " +
			item.getAircraftName() + " " +
			item.getClassName() + " " +
			item.getDepartTime() + " " +
			item.getArriveTime() + " " +
			item.getSrcIdx() + " " +
			item.getDstIdx() + " " +
			item.getTotalDistance() + " " +
			item.getPrice() + " " +
			item.getDescription());
		}

//--------------------------------AIRLINE---------------------------------


//--------------------------------BUS---------------------------------

		//---- Test searchStation ok
//		 Collection stationRecs = client.searchBusStation("");
//		 Iterator iterator = stationRecs.iterator();
//		 while (iterator.hasNext()) {
//		 busservice.StationRec item = (busservice.StationRec)iterator.next();
//		 System.out.println(item.getPlaceID()+ " " +
//							item.getPlaceName());
//		}

// ----------ok
//		Collection companyRecs = client.searchBusCompany("");
//		 Iterator iterator2 = companyRecs.iterator();
//		 while (iterator2.hasNext()) {
//		 busservice.CompanyRec item = (busservice.CompanyRec)iterator2.next();
//		 System.out.println(item.getCompanyID()+ " " +
//							item.getCompanyName());
//		}

//-------------- Test search seat ????
//	  java.sql.Date date = java.sql.Date.valueOf("2001-4-17");
//	  Collection searchRecs = client.searchBusSeat("BANGKOK","LADKRABANG",1,date,1,1,1);
//	  Iterator iterator = searchRecs.iterator();
//		 while (iterator.hasNext()) {
//		 busservice.SearchRec item = (busservice.SearchRec)iterator.next();
//		 System.out.println(item.getCompanyName() + " " +
//							item.getClassName() + " " +
//							item.getDepartTime() + " " +
//							item.getArriveTime() + " " +
//							item.getRouteID() + " " +
//							item.getSrcIndex() + " " +
//							item.getDstIndex() + " " +
//							item.getPrice() );
//			}
//		System.out.println("*********** end call method **********");
//--------------------------------BUS---------------------------------
  }
}