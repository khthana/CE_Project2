package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface GuideHome extends EJBHome {
    public GuideRemote create(String guideId, String firstName, String lastName, Integer gender, String spokenLanguage, String officeAddress) throws RemoteException, CreateException;
    public GuideRemote create(String guideId) throws RemoteException, CreateException;
    public GuideRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
}