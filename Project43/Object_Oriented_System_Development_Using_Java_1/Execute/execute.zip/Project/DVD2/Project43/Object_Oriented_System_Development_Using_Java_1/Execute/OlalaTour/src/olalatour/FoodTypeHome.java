package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface FoodTypeHome extends EJBHome {
    public FoodTypeRemote create(String foodTypeId, String foodTypeName, String foodTypeDetail) throws RemoteException, CreateException;
    public FoodTypeRemote create(String foodTypeId) throws RemoteException, CreateException;
    public FoodTypeRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
}