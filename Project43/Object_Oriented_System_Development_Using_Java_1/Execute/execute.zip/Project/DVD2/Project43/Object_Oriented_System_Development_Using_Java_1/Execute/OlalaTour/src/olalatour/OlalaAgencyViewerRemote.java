package olalatour;

import java.rmi.*;
import javax.ejb.*;
import hotelsystem.*;
import restaurantsystem.*;
import java.util.Collection;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface OlalaAgencyViewerRemote extends EJBObject {
  // -------------------------- Hotel ---------------------------------------------
  public Collection findHotel(String name, String description, String address, int star) throws RemoteException;
  // return Collection of ShortHotelInformation
  public Collection findRoom(String hotelID) throws RemoteException;
  // return Collection of FullRoomInformation
  public FullHotelInformation viewHotel(String hotelID) throws RemoteException;
  // -------------------------- Hotel ---------------------------------------------

  // -------------------------- Restaurant ---------------------------------------------
  public Collection findRestaurant(String name, String description, String address, int star) throws RemoteException;
  // return Collection of ShortRestaurantInformation
  public FullRestaurantInformation viewRestaurant(String restaurantID) throws RemoteException;
  // -------------------------- Restaurant ---------------------------------------------

  // -------------------------- Airline ---------------------------------------------
  public Collection searchAirline(String Keyword) throws RemoteException;
  // return Collection of AirlineRec
  public Collection searchAirport(String Keyword) throws RemoteException;
  // return Collection of AirportRec
  public Collection searchAirplaneSeat(String strSrcAirportID ,String strDstStationID, int totalSeat, java.sql.Date departDate, int airlineID, int classType, int seatType, boolean canSmoking, boolean nonStop, int order) throws RemoteException;
  // return Collection of SeatRec

  // -------------------------- Airline ---------------------------------------------

  // -------------------------- Bus ---------------------------------------------
  public  Collection searchBusSeat( String SrcStationID, String DstStationID, int TotalSeat, java.sql.Date  DepartDate, int CompanyID, int ClassType, int SeatType)  throws RemoteException ;//3
	// return Collection of SearchRec
  public  Collection  searchBusCompany(String Keyword) throws RemoteException;//2
	// return Collection of CompanyRec
  public  Collection  searchBusStation(String keyword) throws RemoteException;//1
	// return Collection of StationRec
  // -------------------------- Bus ---------------------------------------------

  // -------------------------- OlalaTour ---------------------------------------------
  public Collection findPlace(String placeName, String country, String state, String province, String description) throws RemoteException;
  // return Collection of ShortPlaceInformation
  Collection findPackageTour(Collection placeIDs, double price, java.sql.Date departTime, int duration) throws RemoteException;
  // return Collection of ShortPackageTourInformation

  public Collection findActivity(String activityName, String description) throws RemoteException;
  // return Collection of ShortActivityInformation
  public Collection findCategory(String categoryName, String description) throws RemoteException;
  // return Colleciton of ShortCategoryInformation
  public Collection findFestival(String festivalName, String description) throws RemoteException;
  // return Collection of ShortFestivalInformation

  public FullPlaceInformation viewPlace(String placeID) throws RemoteException;
  public FullPackageTourInformation viewPackageTour(String packageTourID) throws RemoteException;
  public FullActivityInformation viewActivity(String activityID) throws RemoteException;
  public FullCategoryInformation viewCategory(String categoryID) throws RemoteException;
  public FullFestivalInformation viewFestival(String festivalID) throws RemoteException;
  public FullBookingInformation viewBooking(String bookingID) throws RemoteException;
  public FullTravellerInformation viewTraveller(String travellerID) throws RemoteException;
  public FullMemberInformation viewMember(String memberID) throws RemoteException;
  public FullGuideInformation viewGuide(String guideID) throws RemoteException;
  // -------------------------- OlalaTour ---------------------------------------------
}