package busservice;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.io.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;
import java.math.*;
import java.awt.*;



/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ReserveControllerBean implements SessionBean {
  private SessionContext sessionContext;
  Connection con ;
  PreparedStatement pstmt ;
  BookSeatResult bookSeatResult;
  private String dbName = "java:comp/env/jdbc/RestaurantDB";


  // ##### MAKE GUID
  protected String getNewBookingID() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("UUIDGenerator");

	  UUIDGeneratorHome home = (UUIDGeneratorHome)PortableRemoteObject.narrow(objref, UUIDGeneratorHome.class);
	  UUIDGeneratorRemote uuidGenerator = home.create();

	  return uuidGenerator.getUUID();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ BUSINESS METHOD @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

public String CreateCustomer( String strFirstName ,String strLastName,String  strAddress, String strTelephoneNo) throws CreateException ,RemoteException{

String strCommand;
String strCustomerID;
String sqlResult;

strCustomerID = getNewBookingID(); // make new customerID


                 strCommand = "INSERT INTO CUSTOMER VALUES ('" + strCustomerID + "', '" +
                                                  strFirstName + "', '" +
                                                  strLastName + "', '" +
                                                  strAddress + "','" +
                                                  strTelephoneNo + "')" ;

 System.out.println("**** Insert into Customer as new Customer  ****");

  try
  {
    pstmt = con.prepareStatement(strCommand);
    pstmt.executeUpdate();
    pstmt.close();
   System.out.println("**** Update success ****");

  }
  catch(java.sql.SQLException e)
  {
    throw new EJBException ("[BusService,Reserve]  Can not create Customer.\n" + "Command : "  + strCommand  + "\n" + e.getMessage());
  }

  return  strCustomerID;
}  // End method


//****************************************************************** BOOKSEAT METHOD *************************************************************************

public ArrayList BookSeat(ArrayList info) throws RemoteException,InvalidRouteIDException ,SeatNotAvailableException, ReserveErrorException, CustomerIDNotExistException  {

System.out.println("******* BookSeat Method call *******");

     String strCommand;
     String strCustomer = null;
     String strBooking;
     String strCustomerBooking = null;

     ArrayList result = new ArrayList();

     String strSeatNo;
     String strCustomerID;


     String strBookingID = null;
     strBookingID = getNewBookingID();  // *** Create new BookingID

     System.out.println("******strBookingID is :" + strBookingID +" *******");


    ListIterator iterator = info.listIterator(0);
    int index = 0;

while (iterator.hasNext()) {  // Loop for all customer booking,1 booingID
    BookSeatInfo bookSeatInfo = (BookSeatInfo)iterator.next();        // bookSeatInfo is one item in arrayList

// **************************************  Check for CustomerID ***************************************************

      String CustomerID = bookSeatInfo.getCustomerID() ;
      System.out.println(" CustomerID is :" + CustomerID +"*******");

     if (CustomerID == null || CustomerID.equals(""))
     {
       throw new CustomerIDNotExistException(" Do not have CustomerID : Try to creat new one ");
      }
      else { // customerID != null,Exit in bookSeatInfo
      strCustomerID = bookSeatInfo.getCustomerID();
      System.out.println("****"+ strCustomerID+" ****");
      }

//************************************** Finish Check For Customer *************************************************

//******************************* Start to Book in CustomerBooking *****************************************

                String strCustomerBookingID = getNewBookingID(); // make new customerBookingID

                int iRouteID;
                int iSrcIdx;
                int iDstIdx;
                java.sql.Timestamp dtDepartTime;
                String strSelectedSeatType;
                double curPrice;


                  if (bookSeatInfo.getRouteID() == 0)  { // 0 = null or not Exit
                  throw new ReserveErrorException("Some record not have RouteID");
                  }
                  else iRouteID = bookSeatInfo.getRouteID();
                  System.out.println("****"+ iRouteID+" ****");

                  if (bookSeatInfo.getSrcIdx() == 0)  {
                  throw new ReserveErrorException( "Some record not have Source Index");
                  }
                  else iSrcIdx = bookSeatInfo.getSrcIdx();
                   System.out.println("****"+ iSrcIdx+ "****");

                  if (bookSeatInfo.getDstIdx() == 0)  {
                  throw new ReserveErrorException("Some record not have Destination Index");
                  }
                  else iDstIdx = bookSeatInfo.getDstIdx();
                   System.out.println("****"+ iDstIdx+ "****");

                  if (bookSeatInfo.getDepartTime() == null)  {
                  throw new ReserveErrorException("Some record not have DepartTime");
                  }
                  else dtDepartTime = bookSeatInfo.getDepartTime();
                   System.out.println("****"+ dtDepartTime+" ****");

                  if (bookSeatInfo.getSeatType() < 0)  {
                  throw new ReserveErrorException("Some record not have Type of Seat");
                  }

                  else {
                   switch  (bookSeatInfo.getSeatType())  {
                    case (0) :
                    strSelectedSeatType = "";
                    break;
                    case (1) :
                    strSelectedSeatType = " AND T1.Window = 1 ";
                    break;
                    case (2) :
                    strSelectedSeatType = " AND T1.Window = 0 ";
                    break;
                    default :
                    strSelectedSeatType = "";
                    }
                  }// end else

                  if (bookSeatInfo.getPrice() == 0)  {
                  throw new ReserveErrorException("Some record not have Price");
                  }
                  else curPrice = bookSeatInfo.getPrice();
                   System.out.println("****"+ curPrice+ "****");

                System.out.println(strSelectedSeatType);

                String SeatNo = null;

                // generate command to select SeatNo
                strCommand = "  SELECT     T1.SeatNo  " +
                             "  FROM       Seat T1,  " +
                             "                    Route T2  " +
                             "  WHERE      T2.RouteID = " + iRouteID + " " +
                             "           AND T2.ModelID = T1.ModelID " +
                               strSelectedSeatType +
                             "           AND T1.SeatNo NOT IN ( " +
                             "  SELECT      DISTINCT T3.SeatNo " +
                             "  FROM        SubRouteBooking T3, " +
                             "            RouteSubRoute T4  " +
                             "  WHERE      T3.departDate = '"+ dtDepartTime + "'  " +
                             "            AND T3.RouteID = " + iRouteID + " " +
                             "            AND T3.RouteID = T4.RouteID " +
                             "            AND T3.SubRouteID = T4.SubRouteID " +
                             "            AND T4.Idx >= " + iSrcIdx + " " +
                             "            AND T4.Idx <= " + iDstIdx + " ) " +
                             "  ORDER BY T1.SeatNo ";

//T3.DepartDate is Timestamp
  System.out.println("**** Execute Select SeatNo ****");


 try
  {
    pstmt = con.prepareStatement(strCommand);
    System.out.println("**** prepareStatement  ****");
//    pstmt.setString(1,SeatNo);
    ResultSet rs = pstmt.executeQuery();
      System.out.println("**** Execute Query ****");


    int count = 0 ;
    if (rs.next() ){
        SeatNo = rs.getString(1);         // get SeatNo from select >> Stop need only one seat
        count++;                         // increase index of array
    } // close if

       pstmt.close();

  System.out.println("****"+ SeatNo+" ****");

    if ((count ==0) ||(SeatNo == null)) {
        throw new SeatNotAvailableException("Can not find seat that can book.");
    }
    else {
        // get the first seatNo that can find
        strSeatNo = SeatNo;
        // set in ArrayList to return from this booking (Reservation)

        System.out.println("*****" + strCustomerID+" " + strBookingID + " " + strSeatNo + " " +curPrice);
        BookSeatResult bookSeatResult = new BookSeatResult(strCustomerID, strBookingID,strSeatNo,curPrice );
        result.add(index,bookSeatResult);
        }

}// end try
catch(java.sql.SQLException e)
  {e.printStackTrace();
    throw new EJBException("Internal error : Can not execute sql command to find seat.");
  }

// ************************************** Start Book in subRouteBooking *****************************************

  System.out.println("**** Start Book in subRouteBooking ****");

                    // find all subRoute from source to destination
                   strCommand = "SELECT   T1.SubRouteID " +
                                "FROM     RouteSubRoute T1 " +
                                "WHERE    T1.RouteID = " + iRouteID +
                                "         AND T1.Idx >= " + iSrcIdx + "  AND T1.Idx <= " + iDstIdx;


  System.out.println("**** Select all subroute ****");

try  {
    pstmt = con.prepareStatement (strCommand);
    ResultSet rs = pstmt.executeQuery();

    int SubRouteID;
    int count = 0 ;
    int tempRouteID[] =new int[100];  // if nothing = 0

 while (  rs.next() ) {
        SubRouteID = rs.getInt(1);
        tempRouteID[count] = SubRouteID;

        System.out.println("******"+tempRouteID[count]+"************");

        count++;
        } // end while

        pstmt.close();

    if (count == 0) {
        throw new ReserveErrorException("No available subroute that can Book.");
      }
    else {  // ********* Loop for inSert in SubRouteBooking

      int iSubRouteID;
      int i = 0;

      while (i < count) {           // arraySize = count-1
        SubRouteID = tempRouteID[i];

        if  (SubRouteID == 0) {       // or = null , subRouteID have null value from search
            throw new InvalidRouteIDException("Internal operation error :  SubRouteID have null value from search availble SubRoute.");
            } // end if
        else iSubRouteID = SubRouteID;

         System.out.println("*****"+ dtDepartTime + " " + iRouteID + " " + iSubRouteID + " " + strSeatNo + " " + strCustomerBookingID);

          // Book all subRoute in SubRouteBooking
          strCommand = "INSERT INTO   SubRouteBooking " +
                       "VALUES              ( '" + dtDepartTime + "', " +
                                                 iRouteID + ", " +
                                                 iSubRouteID + ", " +
                                                 "'" + strSeatNo + "', " +
                                                 "'" + strCustomerBookingID + "' ) ";
        try {
            pstmt = con.prepareStatement (strCommand);

	    pstmt.executeUpdate();
	    pstmt.close();

          }// end try
        catch(java.sql.SQLException e)
            {
            throw new EJBException("Internal operation error : Fail to add information into SubRouteBooking table.");
            }

          i++;  // increase for get subRoute ID in the next array

        } // end else insert subroute

      } // end while

    }   // End Try

  catch(java.sql.SQLException e)
  {
  throw new RemoteException("Internal operation error : Can not execute sql command to search subroute.");
  }

//***************************** Finish Book in SubRouteBooking For 1 Seat(1 CustomerBooking) ************************************

//***************************** Start to Book in CustomerBooking ******************************************

             strCommand = "INSERT INTO   CustomerBooking  " +
                          "VALUES                ( '" + strCustomerBookingID + "', " +
                          "'" + strBookingID + "', " +
                          "'" + strCustomerID + "', " +
                                curPrice + " ) ";


            System.out.println("*****"+strCustomerBookingID+" " +strBookingID+" " +strCustomerID+" " + curPrice);
            try {
            pstmt = con.prepareStatement(strCommand);
	    pstmt.executeUpdate();
	    pstmt.close();
            }
            catch(java.sql.SQLException e)
            {
             throw new RemoteException("Internal Operaion error : Can not add information into CustomerBooking table.");
            }

            index++; // increase for number of index in array of result

} // End While Loop of get Object from bookSeatInfo ArrayList

/***************************************** Combine into 1 Booking **************************************************/
            String transactionID = getNewBookingID();
            java.sql.Timestamp txDate = new java.sql.Timestamp(System.currentTimeMillis());

            strCommand = "INSERT  INTO    Booking " +
                         "VALUES  ( '" + strBookingID + "', " + 0 + ", '" +  // 0 = not confirm
                         transactionID +"' , '" +                                 // NULL = no transactionID
                          txDate + "' )";

            try {
            pstmt = con.prepareStatement (strCommand);

	    pstmt.executeUpdate();
	    pstmt.close();
      }

      catch(java.sql.SQLException e)
      {
         throw new EJBException("Internal operation error : Can not add information into Booking table.");
      }

      return result;

} // End BookSeat Methods

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ REQUIRE METHOD @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  public void ejbCreate() {

  System.out.println("**** Create method ****");
  try {
         makeConnection();
      } catch (Exception ex) {
          throw new EJBException("Unable to connect to database. " +
             ex.getMessage());
      }

  System.out.println("**** End Create method ****");

  }

  public void ejbRemove() {
  try {
         con.close();
      } catch (SQLException ex) {
          throw new EJBException("ejbRemove: " + ex.getMessage());
      }
  }

  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext context) {
    sessionContext = context;
  }

//----------------------------------------- BEGIN MAKECONNECTION ---------------------------------------------
 private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();

   }
//----------------------------------------- END MAKECONNECTION ---------------------------------------------

}