<%@ page import="olalatour.AirlineSearchBean" %>
<jsp:useBean id="airlinesearchbean" scope="page" class="olalatour.AirlineSearchBean" />
<jsp:setProperty name="airlinesearchbean" property="*" />

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<SCRIPT LANGUAGE=javascript>
<!--
function LinkToAirlineSearchOneWay(airportID,airportName)  {  
       window.navigate("AirlineSearchOneWay.jsp?strAirportID="+airportID+ "&strAirportName=" +airportName);
}
//-->
</SCRIPT>
</head>

<body bgcolor="#FFFFFF">
<table width="700" border="1">
 <tr> 
	    <td height="50"> 
		      <table width="100%" border="1" height="50">
		        <tr> 
			          <td height="45" width="25%"><b><font size="5">OLALA TOUR</font></b></td>
			          <td height="45" width="75%"><font size="4">AIRPORT LIST</font></td>
		        </tr>
		      </table>
	    </td>
 </tr>
 <tr> 
	    <td height="80">
		      <table width="100%" border="1">
		        <tr>
			        <td>
					<b><font size="4">Search Airport Result 120 Airport </font></b>
				</td>
		        </tr>
		        <tr> 
			       <td> 
			            <div align="center">
				              <input type="text" name="textfield" 
							value="<%=request.getParameter("strAirport")%>">
				              <input type="submit" name="Submit" value="Airport Code Search">
			            </div>
		               </td>
		       </tr>
		       <tr> 
			       <td>
			            <table width="100%" border="1">
			              <tr> 
				                <td width="20%"><b>Airport Code</b> </td>
				                <td width="80%"><b>Airport Name</b></td>
			              </tr>
	<% 	
		String strAirport = ""; 
		strAirport = request.getParameter("strAirport");
		// Connect EJB
		airlinesearchbean.ConnectServer();
		// Search Airport
		airlinesearchbean.ReturnAirport(strAirport);		
		while (airlinesearchbean.nextAirport()) { 			
	%>
	              <tr> 
		                <td width="20%">				
					       <%
							String airportID	=airlinesearchbean.getAirportID();
						        String airportName=airlinesearchbean.getAirportName();
					       %>
						<input type="button"  value="<%=airportID%>"
						onclick = "LinkToAirlineSearchOneWay(<%=airportID%>,<%=airportName%>)">							
				</td>
		                <td width="80%"> 
						<%=airportName%>
				</td>
		     </tr>
		<% } %>			
		
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
