package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Admin implements EntityBean {
    EntityContext entityContext;
    public String adminId;
    public String loginName;
    public String firstName;
    public String lastName;
    public String address;
    public String telephoneNo;
    public String emailAddress;
    public Integer gender;
    public Date birthDate;
    public String religion;
    public String password;
    public String ejbCreate(String adminId, String loginName, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String password) throws CreateException {
	this.adminId = adminId;
	this.loginName = loginName;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.telephoneNo = telephoneNo;
	this.emailAddress = emailAddress;
	this.gender = gender;
	this.birthDate = birthDate;
	this.religion = religion;
	this.password = password;
	return null;
    }
    public String ejbCreate(String adminId) throws CreateException {
	return ejbCreate(adminId, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbPostCreate(String adminId, String loginName, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String password) throws CreateException {
    }
    public void ejbPostCreate(String adminId) throws CreateException {
	ejbPostCreate(adminId, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getAdminId() {
	return adminId;
    }
    public String getLoginName() {
	return loginName;
    }
    public void setLoginName(String loginName) {
	this.loginName = loginName;
    }
    public String getFirstName() {
	return firstName;
    }
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }
    public String getAddress() {
	return address;
    }
    public void setAddress(String address) {
	this.address = address;
    }
    public String getTelephoneNo() {
	return telephoneNo;
    }
    public void setTelephoneNo(String telephoneNo) {
	this.telephoneNo = telephoneNo;
    }
    public String getEmailAddress() {
	return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
    }
    public Integer getGender() {
	return gender;
    }
    public void setGender(Integer gender) {
	this.gender = gender;
    }
    public Date getBirthDate() {
	return birthDate;
    }
    public void setBirthDate(Date birthDate) {
	this.birthDate = birthDate;
    }
    public String getReligion() {
	return religion;
    }
    public void setReligion(String religion) {
	this.religion = religion;
    }
    public String getPassword() {
	return password;
    }
    public void setPassword(String password) {
	this.password = password;
    }
}