package airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */


public interface ModifyControllerRemote extends EJBObject {
public boolean confirmBooking(String BookingID ) throws RemoteException ;
public boolean CancelBooking( String BookingID) throws  RemoteException  ;
public ArrayList modifyBooking(ArrayList newInfo, String BookingID)throws ReservationErrorException,RemoteException;
}