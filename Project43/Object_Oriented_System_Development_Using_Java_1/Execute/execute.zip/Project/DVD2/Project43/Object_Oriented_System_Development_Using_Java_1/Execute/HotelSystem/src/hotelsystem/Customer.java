package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Customer implements EntityBean {
  EntityContext entityContext;
  public String customerID;
  public String firstname;
  public String lastname;
  public String address;
  public String telephoneNo;
  public int gender;

  private Connection con;
  private String dbName = "java:comp/env/jdbc/HotelDB";

  public String ejbCreate(String customerID, String firstname, String lastname, String address, String telephoneNo, int gender) throws CreateException {
      System.out.println("ejbCreate");

      try {
		insertRow(customerID, firstname, lastname, address, telephoneNo, gender);
      } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
	      ex.getMessage());
      }

      this.customerID = customerID;
      this.firstname = firstname;
      this.lastname = lastname;
      this.address = address;
      this.telephoneNo = telephoneNo;
      this.gender = gender;

      System.out.println("end ejbCreate");

      return customerID;
  }
  public void ejbPostCreate(String customerID, String firstname, String lastname, String address, String telephoneNo, int gender) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
    System.out.println("ejbRomove");
      try {
	 deleteRow(customerID);
       } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
	      ex.getMessage());
       }
    System.out.println("end ejbRomove");
  }
  public String ejbFindByPrimaryKey(String primKey) throws FinderException {
      System.out.println("ejbFindByPrimaryKey");

      boolean result;

      try {
	 result = selectByPrimaryKey(primKey);
       } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
	      ex.getMessage());
       }
      if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
      }
      else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
	    ("Row for id " + primKey + " not found.");
      }
  }
  public void ejbActivate() {
    System.out.println("ejbActivate");
    customerID = (String)entityContext.getPrimaryKey();
    System.out.println("end ejbActivate");
  }
  public void ejbPassivate() {
    System.out.println("ejbPassivate");
    customerID = null;
    System.out.println("end ejbPassivate");
  }
  public void ejbLoad() {
    System.out.println("ejbLoad");
      try {
	 loadRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
      System.out.println("end ejbLoad");
  }
  public void ejbStore() {
    System.out.println("ejbLoad");
      try {
	 storeRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
    System.out.println("end ejbLoad");
  }
  public void setEntityContext(EntityContext entityContext) {
    System.out.println("setEntityContext");
    this.entityContext = entityContext;
      try {
	 makeConnection();
      } catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
	     ex.getMessage());
      }
    System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
    System.out.println("unsetEntityContext");
    entityContext = null;
      try {
	 con.close();
      } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
      }
    System.out.println("end unsetEntityContext");
  }
  public String getCustomerID() {
    return customerID;
  }
  public void setFirstname(String newFirstname) {
    firstname = newFirstname;
  }
  public String getFirstname() {
    return firstname;
  }
  public void setLastname(String newLastname) {
    lastname = newLastname;
  }
  public String getLastname() {
    return lastname;
  }
  public void setAddress(String newAddress) {
    address = newAddress;
  }
  public String getAddress() {
    return address;
  }
  public void setTelephoneNo(String newTelephoneNo) {
    telephoneNo = newTelephoneNo;
  }
  public String getTelephoneNo() {
    return telephoneNo;
  }
  public void setGender(int newGender) {
    gender = newGender;
  }
  public int getGender() {
    return gender;
  }
/*********************** Database Routines *************************/

   private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();
   }

   private void insertRow (String customerID, String firstname, String lastname, String address, String telephoneNo, int gender) throws SQLException {

	  String insertStatement =
		"insert into CUSTOMER(CUSTOMER_ID, FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, GENDER) values ( ? , ? , ? , ? , ? , ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, customerID);
	  prepStmt.setString(2, firstname);
	  prepStmt.setString(3, lastname);
	  prepStmt.setString(4, address);
	  prepStmt.setString(5, telephoneNo);
	  prepStmt.setInt(6, gender);

	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String customerID) throws SQLException {

      String deleteStatement =
	    "delete from CUSTOMER where CUSTOMER_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(deleteStatement);

      prepStmt.setString(1, customerID);

      prepStmt.executeUpdate();
      prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
      throws SQLException {

      String selectStatement =
	    "select CUSTOMER_ID " +
	    "from CUSTOMER where CUSTOMER_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);
      prepStmt.setString(1, primaryKey);

      ResultSet rs = prepStmt.executeQuery();
      boolean result = rs.next();
      prepStmt.close();
      return result;
   }

   private void loadRow() throws SQLException {

      String selectStatement =
	    "select FIRST_NAME, LAST_NAME, ADDRESS, TELEPHONE_NO, GENGER " +
	    "from CUSTOMER where CUSTOMER_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);

      prepStmt.setString(1, this.customerID);


      ResultSet rs = prepStmt.executeQuery();

      if (rs.next()) {
	 this.firstname = rs.getString(1);
	 this.lastname = rs.getString(2);
	 this.address = rs.getString(3);
	 this.telephoneNo = rs.getString(4);
	 this.gender = rs.getInt(5);
	 prepStmt.close();
      }
      else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + customerID +
	    " not found in database.");
      }
   }

   private void storeRow() throws SQLException {

      String updateStatement =
	    "update CUSTOMER set " +
	    "FIRST_NAME =  ? ," +
	    "LAST_NAME = ? ," +
	    "ADDRESS = ? ," +
	    "TELEPHONE_NO = ? ," +
	    "GENDER = ? " +
	    "where CUSTOMER_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(updateStatement);

      prepStmt.setString(1, firstname);
      prepStmt.setString(2, lastname);
      prepStmt.setString(3, address);
      prepStmt.setString(4, telephoneNo);
      prepStmt.setInt(5, gender);

      prepStmt.setString(6, customerID);

      int rowCount = prepStmt.executeUpdate();
      prepStmt.close();

      if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + customerID + " failed.");
      }
   }
}