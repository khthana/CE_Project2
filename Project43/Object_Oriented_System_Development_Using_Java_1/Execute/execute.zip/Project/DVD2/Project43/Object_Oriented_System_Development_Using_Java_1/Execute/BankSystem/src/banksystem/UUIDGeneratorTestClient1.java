package banksystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class UUIDGeneratorTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private UUIDGeneratorHome uUIDGeneratorHome = null;
  private UUIDGeneratorRemote uUIDGeneratorRemote = null;

  /**Construct the EJB test client*/
  public UUIDGeneratorTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("banksystem/UUIDGenerator");

	  //cast to Home interface
	  uUIDGeneratorHome = (UUIDGeneratorHome) PortableRemoteObject.narrow(ref, UUIDGeneratorHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public UUIDGeneratorRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  uUIDGeneratorRemote = uUIDGeneratorHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + uUIDGeneratorRemote + ".");
	}
	return uUIDGeneratorRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getUUID() {
	String returnValue = "";
	if (uUIDGeneratorRemote == null) {
	  System.out.println("Error in getUUID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getUUID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = uUIDGeneratorRemote.getUUID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getUUID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getUUID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getUUID(): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	UUIDGeneratorTestClient1 client = new UUIDGeneratorTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.
	client.create();
	client.getUUID();
  }
}