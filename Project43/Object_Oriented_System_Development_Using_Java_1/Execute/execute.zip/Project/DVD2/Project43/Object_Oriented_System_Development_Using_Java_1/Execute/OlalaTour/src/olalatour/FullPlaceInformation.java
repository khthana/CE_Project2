package olalatour;

import java.io.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullPlaceInformation implements Serializable {

    public FullPlaceInformation(String placeID, String placeName, String country, String state, String province, String description, String imageFilePath, Collection categories, Collection activities, Collection festivals, Collection packageTours) {
	this.placeID = placeID;
	this.placeName = placeName;
	this.country = country;
	this.state = state;
	this.province = province;
	this.description = description;
	this.imageFilePath = imageFilePath;
	this.categories = categories;
	this.activities = activities;
	this.festivals = festivals;
	this.packageTours = packageTours;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getPlaceID() {
	return placeID;
    }
    public String getPlaceName() {
	return placeName;
    }
    public String getCountry() {
	return country;
    }
    public String getState() {
	return state;
    }
    public String getProvince() {
	return province;
    }
    public String getDescription() {
	return description;
    }
    public String getImageFilePath() {
	return imageFilePath;
    }
    public java.util.Collection getCategories() {
	return categories;
    }
    public java.util.Collection getActivities() {
	return activities;
    }
    public java.util.Collection getFestivals() {
	return festivals;
    }
    public java.util.Collection getPackageTours() {
	return packageTours;
    }
    private String placeID;
    private String placeName;
    private String country;
    private String state;
    private String province;
    private String description;
    private String imageFilePath;
    private java.util.Collection categories;
    private java.util.Collection activities;
    private java.util.Collection festivals;
    private java.util.Collection packageTours;
}