package banksystem;



import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.lang.Exception;
import java.lang.*;

public class BankController implements SessionBean {
  private SessionContext sessionContext;
  String transactionID;


  protected String getNewBookingID() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("banksystem/UUIDGenerator");

	  UUIDGeneratorHome home = (UUIDGeneratorHome)PortableRemoteObject.narrow(objref, UUIDGeneratorHome.class);
	  UUIDGeneratorRemote uuidGenerator = home.create();

	  return uuidGenerator.getUUID();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Business Method @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  // **** pay By debitCardID ********
 public String payByDebitCardID(String debitCardID, String relateAccountID, double amount) throws  RemoteException, InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException , InvalidAmountException{
		System.out.println("********* payByDebitCardID Method  **********");

		Context initial = null;
	Object objref = null;
	AccountHome home = null;
		String accountIDSource = "";

		System.out.println("********* Find Account Home  **********");
	try {
	  initial = new InitialContext();
	  objref = initial.lookup("banksystem/Account");
	  home = (AccountHome)PortableRemoteObject.narrow(objref, AccountHome.class);
		  }
		catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
		}

		System.out.println("********* Find by debitCardID  **********");

	  try {
		  Collection acc =   home.findByDebitCardID(debitCardID);
		  Iterator i = acc.iterator();

		  AccountRemote accountRemoteDb=null;

		  if (i.hasNext()) {
		  accountRemoteDb = (AccountRemote)i.next();  // assume >> have only one returnAccount debirCard is unique
		  }

		  accountIDSource  = accountRemoteDb.getAccountID();

	// Withdraw
	  AccountRemote accountRemote =  home.findByPrimaryKey(accountIDSource);
	  double balance =  accountRemote.getBalance();
	  accountRemote.withdraw(amount);

	// Deposit
	  AccountRemote accountRemote2 = home.findByPrimaryKey(relateAccountID);
	  double balance2 =  accountRemote2.getBalance();
	  accountRemote2.deposit(amount);
	}

	catch (FinderException ex) {
		throw new InvalidAccountException();
	}

	Bank_TransactionHome homeBB = null;
	Bank_TransactionRemote bankTx = null;

		System.out.println("********* Find BankTransactionHome  **********");
	try {
	  initial = new InitialContext();
	  objref = initial.lookup("banksystem/Bank_Transaction");
	  homeBB = (Bank_TransactionHome)PortableRemoteObject.narrow(objref, Bank_TransactionHome.class);
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}

	  // make new Bank_Transaction Object
	  transactionID = getNewBookingID();
	  Bank_TransactionRemote bankTransactionRemote = null;
	  java.sql.Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());


	   try {
		bankTx = homeBB.create(transactionID,accountIDSource,relateAccountID ,1 ,amount ,date);
		System.out.println("after create bankTransaction");
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (CreateException ex) {
	  throw new EJBException(ex.getMessage());
	}

	System.out.println(transactionID +" " + accountIDSource+" " +  relateAccountID);
  return transactionID;

  }

//********************************************* PAY BY CRADITCARDID ****************************************

  public String payByCreditCardID(String creditCardID, String relateAccountID, double amount) throws  RemoteException, InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException , InvalidAmountException{

	System.out.println("***payByCreditCardID Method**");
	Context initial = null;
	Object objref = null;
	AccountHome home = null;
	String accountIDSource;

	try {
	  initial = new InitialContext();
	  System.out.println("initial");
	  objref = initial.lookup("banksystem/Account");
	  System.out.println("lookup banksystem/Account");
	  home = (AccountHome)PortableRemoteObject.narrow(objref, AccountHome.class);
	  System.out.println("narrow");
	  }
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}

		  System.out.println("********* Find by creditCardID  **********");

	  try {
		   Collection acc2  = home.findByCreditCardID(creditCardID);
		   Iterator i = acc2.iterator();

		   AccountRemote accountRemoteCd =null;

		  if (i.hasNext()) {
		   accountRemoteCd = (AccountRemote)i.next();  // assume >> have only one returnAccount debirCard is unique
		   }

		  accountIDSource  = accountRemoteCd.getAccountID();

		   // Withdraw
	  AccountRemote accountRemote =  home.findByPrimaryKey(accountIDSource);
		  double credit = accountRemote.getCredit();
	  accountRemote.withdrawBycredit(amount);

		  System.out.println("AccountID of CreditCard"+creditCardID + " : " +accountIDSource);
		  System.out.println("***Credit of this AccountID :  " + credit);

		 //*** deposit to relateAccountId
		  AccountRemote accountRemoteDes =  home.findByPrimaryKey(relateAccountID);
		  double balanceD =  accountRemoteDes.getBalance();
		  accountRemoteDes.deposit(amount);

		  }
	  catch (FinderException ex) {
		throw new InvalidAccountException();
	  }

	  Bank_TransactionHome homeB = null;
	  Bank_TransactionRemote bankTx = null;

		  System.out.println("********* Find BankTransactionHome  **********");

		try {
	  initial = new InitialContext();
	  objref = initial.lookup("banksystem/Bank_Transaction");
	  homeB = (Bank_TransactionHome)PortableRemoteObject.narrow(objref, Bank_TransactionHome.class);
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}

		 // new Bank_TransactionRemote
			String transactionID = getNewBookingID();
			Bank_TransactionRemote bankTransactionRemote = null;
			java.sql.Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());

	try {
		bankTx = homeB.create(transactionID,accountIDSource,relateAccountID ,2 ,amount ,date);
		System.out.println("after create bankTransaction");
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (CreateException ex) {
	  throw new EJBException(ex.getMessage());
	}
		System.out.println(transactionID +" " + accountIDSource+" " +  relateAccountID);

	return transactionID;
  }

// ******************************************* TRANSFER METHOD ********************************************

  public String transfer(String accountIDSource,String relateAccountID,double amount,String password)  throws InvalidPasswordException, InvalidAccountException,  AccountNotExistException , InsufficientBalanceException , BankControllerException , InvalidAmountException{

	System.out.println("Transfer method");
	Context initial = null;
	Object objref = null;
	AccountHome home = null;

	try {
	  initial = new InitialContext();
	  System.out.println("initial");
	  objref = initial.lookup("banksystem/Account");
	  System.out.println("lookup");
	  home = (AccountHome)PortableRemoteObject.narrow(objref, AccountHome.class);
	  System.out.println("narrow");
	  }
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}


	try {

	// Withdraw
	  AccountRemote accountRemote =  home.findByPrimaryKey(accountIDSource);
	  System.out.println("findByPrimaryKey");

	  // Check Password of AccountIDSource
	  String passwordAcc = accountRemote.getPassword();
	  System.out.println("getPassword");
	  if (passwordAcc.equals(password)) {
		System.out.println("equal");
		double balance =  accountRemote.getBalance();
		System.out.println("getBalance");
		accountRemote.withdraw(amount);
		System.out.println("withdraw");
	  }
	  else {
		InvalidPasswordException ex;
		ex = new InvalidPasswordException("Password is not match");
		throw (ex);

	  }


	// Deposit
	  AccountRemote accountRemote2 = home.findByPrimaryKey(relateAccountID);
	  double balance2 =  accountRemote2.getBalance();
	  accountRemote2.deposit(amount);
	}
	catch (FinderException ex) {
		throw new InvalidAccountException();
	}
	catch (RemoteException ex) {
		throw new EJBException();
	}

	Bank_TransactionHome homeBB = null;
	Bank_TransactionRemote bankTx = null;

	try {
	  initial = new InitialContext();
	  objref = initial.lookup("banksystem/Bank_Transaction");
	  homeBB = (Bank_TransactionHome)PortableRemoteObject.narrow(objref, Bank_TransactionHome.class);
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}

	  // make new Bank_Transaction Object
	  String transactionID = getNewBookingID();
	  Bank_TransactionRemote bankTransactionRemote = null;
	  java.sql.Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());

	   try {
		bankTx = homeBB.create(transactionID,accountIDSource,relateAccountID ,0 ,amount ,date);
		System.out.println("after create bankTransaction");
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (CreateException ex) {
	  throw new EJBException(ex.getMessage());
	}

	System.out.println(transactionID +" " + accountIDSource+" " +  relateAccountID);
  return transactionID;
  }

  // ******* CHECK TRANSFER METHOD *********
  public void checkTransfer(String relateAccountID, String transactionID, double amount ) throws InvalidPasswordException, InvalidAmountException,  AccountNotExistException , TransactionNotExistException ,InvalidAccountException {

	System.out.println("******* Check transfer method  ***********");
	Context initial = null;
	Object objref = null;
	Bank_TransactionHome home = null;
	Bank_TransactionRemote bankTx = null;

	try {
	  initial = new InitialContext();
	  objref = initial.lookup("banksystem/Bank_Transaction");
	  home = (Bank_TransactionHome)PortableRemoteObject.narrow(objref, Bank_TransactionHome.class);
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}

	System.out.println("********* find remote object **********");
	try {
		Bank_TransactionRemote bankTransactionRemote = home.findByPrimaryKey(transactionID);
		System.out.println("after find bankTransactionRemote");

		if (!relateAccountID.equals(bankTransactionRemote.getRelateAccountID())) {
		System.out.println("******* relate account not match ***********" + relateAccountID + " != " + bankTransactionRemote.getRelateAccountID());
		InvalidAccountException e;
		e = new InvalidAccountException("Destination AccountID Not Match");
		throw(e);
		}

		System.out.println("******* relate account is match ***********");

		if (amount != bankTransactionRemote.getMoney()) {
		System.out.println("******* amount not match ***********");
		InvalidAmountException e;
		e = new InvalidAmountException("Amount Not Match");
		throw(e);
		}

		System.out.println("******* amount match ***********");


			if (bankTransactionRemote.getTransactionType() == 0) {
		System.out.println(" The transaction type : pay by transfer method ");
			  }
			else {
				  if (bankTransactionRemote.getTransactionType() == 1) {
				  System.out.println(" The transaction type : pay by creditCard ");
				  }
				  else {
					if (bankTransactionRemote.getTransactionType() == 2) {
					System.out.println(" The transaction type : pay by creditCard ");
					}
					else {
					System.out.println(" Can not check transfermation in this transaction");
				}
				  }
			}

	}
	catch (RemoteException ex) {
		throw new EJBException(ex.getMessage());
	}
	catch (FinderException ex) {
		throw new AccountNotExistException();
	}
  }

// @@@@@@@@@@@@@@@@@@ require method @@@@@@@@@@@@@@@@@@@@@

  public void ejbCreate() {
  }
  public void ejbRemove() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext context) {
	System.out.println("setSessioncontext in BankController");
	sessionContext = context;
	System.out.println("end setSessionContext in BankController");
  }
}

