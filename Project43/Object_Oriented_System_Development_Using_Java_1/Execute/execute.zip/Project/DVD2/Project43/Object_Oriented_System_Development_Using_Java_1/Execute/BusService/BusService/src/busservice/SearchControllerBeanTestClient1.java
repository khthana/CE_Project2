package busservice;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.ArrayList;
import java.sql.Date;
import java.util.*;

public class SearchControllerBeanTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private SearchControllerHome searchControllerHome = null;
  private SearchController searchController = null;

  /**Construct the EJB test client*/
  public SearchControllerBeanTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("SearchController");

	  //cast to Home interface
	  searchControllerHome = (SearchControllerHome) PortableRemoteObject.narrow(ref, SearchControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public SearchController create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  searchController = searchControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + searchController + ".");
	}
	return searchController;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public ArrayList SearchSeat(String SrcStationID, String DstStationID, int TotalSeat, Date DepartDate, int CompanyID, int ClassType, int SeatType) {
	ArrayList returnValue = null;
	if (searchController == null) {
	  System.out.println("Error in SearchSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchController.SearchSeat(SrcStationID, DstStationID, TotalSeat, DepartDate, CompanyID, ClassType, SeatType);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchSeat(" + SrcStationID + ", " + DstStationID + ", " + TotalSeat + ", " + DepartDate + ", " + CompanyID + ", " + ClassType + ", " + SeatType + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchCompany(String Keyword) {
	ArrayList returnValue = null;
	if (searchController == null) {
	  System.out.println("Error in SearchCompany(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchCompany(" + Keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchController.SearchCompany(Keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchCompany(" + Keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchCompany(" + Keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchCompany(" + Keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchStation(String keyword) {
	ArrayList returnValue = null;
	if (searchController == null) {
	  System.out.println("Error in SearchStation(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchStation(" + keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchController.SearchStation(keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchStation(" + keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchStation(" + keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchStation(" + keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchBus(Date UsingDate, String TotalUsingDay, boolean AirCond, boolean Toilet) {
	ArrayList returnValue = null;
	if (searchController == null) {
	  System.out.println("Error in SearchBus(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchBus(" + UsingDate + ", " + TotalUsingDay + ", " + AirCond + ", " + Toilet + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchController.SearchBus(UsingDate, TotalUsingDay, AirCond, Toilet);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchBus(" + UsingDate + ", " + TotalUsingDay + ", " + AirCond + ", " + Toilet + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchBus(" + UsingDate + ", " + TotalUsingDay + ", " + AirCond + ", " + Toilet + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchBus(" + UsingDate + ", " + TotalUsingDay + ", " + AirCond + ", " + Toilet + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchBusBooking(String BookingID) {
	ArrayList returnValue = null;
	if (searchController == null) {
	  System.out.println("Error in SearchBusBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchBusBooking(" + BookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchController.SearchBusBooking(BookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchBusBooking(" + BookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchBusBooking(" + BookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchBusBooking(" + BookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchSeatBooking(String BookingID) {
	ArrayList returnValue = null;
	if (searchController == null) {
	  System.out.println("Error in SearchSeatBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchSeatBooking(" + BookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchController.SearchSeatBooking(BookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchSeatBooking(" + BookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchSeatBooking(" + BookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchSeatBooking(" + BookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	SearchControllerBeanTestClient1 client = new SearchControllerBeanTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.


		 client.create();

		//---- Test searchStation ok
//		 ArrayList stationRecs = client.SearchStation("");
//		 ListIterator iterator = stationRecs.listIterator(0);
//		 while (iterator.hasNext()) {
//		 StationRec item = (StationRec)iterator.next();
//		 System.out.println(item.getPlaceID()+ " " +
//							item.getPlaceName());
//		}

	  // -- test company
//		 ArrayList companyRecs = client.SearchCompany("");
//		 ListIterator iterator = companyRecs.listIterator(0);
//		 while (iterator.hasNext()) {
//		 CompanyRec item = (CompanyRec)iterator.next();
//		 System.out.println(item.getCompanyID()+ " " +
//							item.getCompanyName());
//		}




//-------------- Test search seat
	  java.sql.Date date = java.sql.Date.valueOf("2002-4-17");
	  ArrayList searchRecs = client.SearchSeat("MCHT","BNPH",1,date,1,1,1);
		 ListIterator iterator = searchRecs.listIterator(0);
		 while (iterator.hasNext()) {
		 SearchRec item = (SearchRec)iterator.next();
		 System.out.println(item.getCompanyName() + " " +
							item.getClassName() + " " +
							item.getDepartTime() + " " +
							item.getArriveTime() + " " +
							item.getRouteID() + " " +
							item.getSrcIndex() + " " +
							item.getDstIndex() + " " +
							item.getPrice() );
			}
		System.out.println("*********** end call method **********");




  }
}