package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface RestaurantHome extends EJBHome {
  public RestaurantRemote create(String restaurantID, String restaurantName, String description,
      int totalSeat, String address, int star, String telephoneNo) throws RemoteException, CreateException;
  public RestaurantRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
  public Collection findByNameDescriptionAddressStar(String name, String description, String address, int star) throws RemoteException, FinderException;
}