package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */



public class ReserveErrorException extends Exception {

   public ReserveErrorException() { }

   public ReserveErrorException(String msg) {
      super(msg);
   }
}
