package hotelsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortHotelInformation implements Serializable{

  public ShortHotelInformation(String hotelID, String hotelName, String hotelLogo, int noOfRooms, int star) {
	this.hotelID = hotelID;
	this.hotelName = hotelName;
	this.hotelLogo = hotelLogo;
	this.noOfRooms = noOfRooms;
	this.star = star;
  }
  private String hotelID;
  private String hotelName;
  private String hotelLogo;
  private int noOfRooms;
  private int star;
  public String getHotelID() {
	return hotelID;
  }
  public String getHotelName() {
	return hotelName;
  }
  public String getHotelLogo() {
	return hotelLogo;
  }
  public int getNoOfRooms() {
	return noOfRooms;
  }
  public int getStar() {
	return star;
  }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
}