package busservice;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.ArrayList;
import java.util.*;

public class ReserveControllerBeanTestClient2 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private ReserveControllerHome reserveControllerHome = null;
  private ReserveController reserveController = null;

  /**Construct the EJB test client*/
  public ReserveControllerBeanTestClient2() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("ReserveController");

	  //cast to Home interface
	  reserveControllerHome = (ReserveControllerHome) PortableRemoteObject.narrow(ref, ReserveControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public ReserveController create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  reserveController = reserveControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + reserveController + ".");
	}
	return reserveController;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public ArrayList BookSeat(ArrayList info) {
	ArrayList returnValue = null;
	if (reserveController == null) {
	  System.out.println("Error in BookSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling BookSeat(" + info + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = reserveController.BookSeat(info);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: BookSeat(" + info + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: BookSeat(" + info + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from BookSeat(" + info + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	ReserveControllerBeanTestClient2 client = new ReserveControllerBeanTestClient2();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.



//    BookSeatInfo bookSeatInfo = new BookSeatInfo("","MONTICHA","KONGTHAWEE","KMITL","032-401625",1,1,1,1,time,210);
//    info.add(0,bookSeatInfo);





	client.create();
//BUS COMPANY A AIRCONDITION 1 VIP null null 1 0 4 405.0
//	  java.sql.Date date = java.sql.Date.valueOf("2001-4-17");


	ArrayList info = new ArrayList();
	java.sql.Timestamp time = java.sql.Timestamp.valueOf("2001-05-30 12:00:00.000000000")   ;
	// string in format of yyyy-mm-dd hh:mm:ss.fff

//	BookSeatInfo(String CustomerID, String FirstName, String LastName,String Address,String TelephoneNo,  int RouteID,int SrcIdx, int DstIdx, int SeatType,java.sql.Timestamp DepartTime,double Price) {
	BookSeatInfo bookSeatInfo = new BookSeatInfo("{4B7FF6A1-33A6-451A-B7FF-814DA4BB7824}","","","","",1,2,3,0,time,600);
	info.add(0,bookSeatInfo);

	BookSeatInfo bookSeatInfo2 = new BookSeatInfo("{68B9B663-D857-4D68-82BF-FC054829B4D5}","","","","",2,2,3,0,time,1000);
	info.add(1,bookSeatInfo2);

	ArrayList bookSeatResults = client.BookSeat(info);

//	ListIterator iterator = bookSeatResults.listIterator(0);
//		 while (iterator.hasNext()) {
//		 BookSeatInfo item = (BookSeatInfo)iterator.next();
//
//		 System.out.println(item.getCustomerID() + " " +
//							item.getFirstName() + " " +
//							item.getLastName() + " " +
//							item.getTelephoneNo() + " " +
//							item.getRouteID() + " " +
//							item.getSrcIdx() + " " +
//							item.getDstIdx() + " " +
//							item.getSeatType()+ " " +
//							item.getDepartTime()+ " " +
//							item.getPrice() );
//			}




  }
}