package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Category implements EntityBean {
    EntityContext entityContext;
    public String categoryId;
    public String categoryName;
    public String description;
    public String ejbCreate(String categoryId, String categoryName, String description) throws CreateException {
	this.categoryId = categoryId;
	this.categoryName = categoryName;
	this.description = description;
	return null;
    }
    public String ejbCreate(String categoryId) throws CreateException {
	return ejbCreate(categoryId, null, null);
    }
    public void ejbPostCreate(String categoryId, String categoryName, String description) throws CreateException {
    }
    public void ejbPostCreate(String categoryId) throws CreateException {
	ejbPostCreate(categoryId, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getCategoryId() {
	return categoryId;
    }
    public String getCategoryName() {
	return categoryName;
    }
    public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
    }
    public String getDescription() {
	return description;
    }
    public void setDescription(String description) {
	this.description = description;
    }
}