package airlinesystem;


import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.io.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;
import java.math.*;
import java.awt.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ModifyController implements SessionBean {
  private SessionContext sessionContext;
  Connection con ;
  PreparedStatement pstmt ;

  private String dbName = "java:comp/env/jdbc/AirlineDB";

  int confirmation; // 0 = not confirm, 1= confirm already , 2 = cancel
  boolean CheckValidation;
  boolean ConfirmBooking;
  boolean CancelBooking;
  int DateExpire = 3 ;

//******************************* MODIFY BOOKING ******************************************************
public ArrayList modifyBooking(ArrayList newInfo, String BookingID) throws ReservationErrorException  {

System.out.println("******* ModifyBookSeat Method call *******");

//********************** BEGIN DELETE OLD DATA  ******************
// check for newInfo that contain customerID and any Information to modify booking
// modify in customerBooking ,subrouteBooking
// find all customerBooking and all SubrouteBooking to delete and then modify it by call bookSeat in reserveController

String deleteStatement;

// find Booking to delete from bookingID
try{
      deleteStatement = "delete from BOOKING  " +
                                "where BOOKINGID = '"+ BookingID +"'" ;
      pstmt = con.prepareStatement(deleteStatement);
      pstmt.executeUpdate();
      pstmt.close();
      System.out.println("** Delete from Booking is success" );
}
catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}



   ListIterator iterator = newInfo.listIterator(0); // info is an ArrayList input

while (iterator.hasNext()) {  // Loop for all customer booking,1 booingID
         BookSeatInfo bookSeatInfo = (BookSeatInfo)iterator.next();

         String CustomerID = bookSeatInfo.getCustomerID() ;
         System.out.println("** CustomerID is : "+ CustomerID );


// find all customerBooking by customerID
try {

      String selectStatement =    "select CUSTOMERBOOKINGID " +
                                  "from CUSTOMERBOOKING where CustomerID = '" +CustomerID +"'" ;

      PreparedStatement pstmt =	 con.prepareStatement(selectStatement);
//      con.setAutoCommit(false);
      ResultSet rs = pstmt.executeQuery();

                // ArrayList a = new ArrayList();


      if (rs.next()) {
      String customerBookingID = rs.getString(1);
      System.out.println("** CustomerBookingID is : "+ customerBookingID );
      pstmt.close();
// receive all customerBookingID >> Delete all row

     deleteStatement = "delete from CUSTOMERBOOKING  " +
                                "where CUSTOMERBOOKINGID = '"+ customerBookingID +"'" ;
      pstmt = con.prepareStatement(deleteStatement);
      pstmt.executeUpdate();
      pstmt.close();
      System.out.println("** Delete from customerBooking is success" );

// find all subRouteBooking by customerBookingID return in Collection
      deleteStatement =  "delete from SUBROUTEBOOKING  " +
                                "where CUSTOMERBOOKINGID = '"+ customerBookingID +"'" ;
      pstmt = con.prepareStatement(deleteStatement);
      pstmt.executeUpdate();
      pstmt.close();
      System.out.println("** Delete from subRouteBooking is success" );
      } // end While


  }  // End try

  catch (Exception ex) {
    throw new EJBException("find customerBooking by customerID " +
    ex.getMessage());
  }

} // END if

 //**************** Finish DELETE OLD DATA  AND CALL BOOKSEAT ******************
          System.out.println("** Call BookSeat Method **" );

try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("ReserveController");

	  ReserveControllerHome home = (ReserveControllerHome)PortableRemoteObject.narrow(objref, ReserveControllerHome.class);
	  ReserveControllerRemote reserveControllerRemote = home.create();

	  return reserveControllerRemote.BookSeat(newInfo); // return ArrayList of BookSeatResult = result
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
}


//****************************** Confirm Booking ********************************************************
public boolean confirmBooking(String BookingID ) throws RemoteException {

    String strCommand ;

    System.out.println("*** Call method Check Validation ****");
    boolean check =  CheckValidation(BookingID);


    if (check==true){
        System.out.println(" Update field confirmation in table to 1 ");

        strCommand = "UPDATE Booking " +
                     "SET    Confirmation = 1  " +  // set 1 = confirm already
                     "WHERE  BookingID = '" + BookingID + "'" ;
        try {
            pstmt = con.prepareStatement (strCommand);
	    pstmt.executeUpdate();
	    pstmt.close();
        }// end try
        catch(java.sql.SQLException e){
            throw new EJBException("ConfirmBooking : Can not execute sql command to comfirm booking , Confirm Abort");
        }
       ConfirmBooking = true;
       System.out.println(" *** Confirmation  completed *** ");
       return true;
      }

    else {
        System.out.println("Confirmation  Error  : Do not allow to confirm or cancel ");
        ConfirmBooking = false;
        return false;
        }
//return ConfirmBooking;
}
//***************************************** CANCEL BOOKING ********************************************

public boolean CancelBooking( String BookingID) throws  RemoteException {

    String strCommand ;

 boolean check2 =  CheckValidation(BookingID);
    if (check2== true ) {

        System.out.println(" update field confirmation to 2 = cancel ");

        strCommand = "UPDATE  Booking  " +
                     "SET     Confirmation = 2  " +
                     "WHERE  BookingID = '" + BookingID + "'" ;

       try {
            pstmt = con.prepareStatement (strCommand);
	    pstmt.executeUpdate();
	    pstmt.close();
          }// end try
        catch(java.sql.SQLException e){
            CancelBooking = false;
            throw new EJBException("ConfirmBooking : Can not execute sql command to comfirm booking , Confirm Abort");
            }
            CancelBooking = true;
            return true;
        }
     else {
        System.out.println("  *** CancelBooking Operation Error *** ");
        CancelBooking = false;
        return false;
        }
// return CancelBooking;
}

// *********************************** INTERNAL METHOD : CHECK VALIDATION ********************************************

private boolean CheckValidation(String BookingID) throws RemoteException {

    java.sql.Timestamp dtBookingDate;  // or Date ????????????????
    String strCommand ;

// Find DateValueNow
       java.util.Date today = new java.util.Date();
        int year = today.getYear();  // =1900 +year
            year = 1900+year;
        int month = today.getMonth(); //=1 + month
            month = month + 1;
        int day =  today.getDate();

        String strYear = String.valueOf(year);
        String strMonth = String.valueOf(month);
        String strDay = String.valueOf(day);

// Today date in String
        String strDateToday = (strYear+"-"+strMonth+"-"+strDay);  // format of String yyyy-mm-dd

// Today date in date format
        java.sql.Date DateValueNow = java.sql.Date.valueOf(strDateToday);
        System.out.println(" Date in today is : " + DateValueNow);


    strCommand = "SELECT Confirmation " +
                 "FROM Booking " +
                 "WHERE BookingID = '" + BookingID + "'" ;

try  {
      pstmt = con.prepareStatement (strCommand);
      System.out.println(" ***** After prepareStatement of select confirmation field ****");
      ResultSet rs = pstmt.executeQuery();
      System.out.println(" *** Execute is successful****");

        if (rs.next()){  //**********************************  5
        int confirmation = rs.getInt(1);
        System.out.println("****Confirmation in this field : " +confirmation);
        pstmt.close();

            if (confirmation == 0){  // 0 = not Confirm   **************** 4

            System.out.println(" Confirmation = 0 >> Not confirm .. so try to check date that can comfirm ");

            strCommand = "SELECT     MIN(T2.DepartDate) "  +
                         "FROM       CustomerBooking T1, " +
                         "           SubRouteBooking T2 " +
                         "WHERE      T1.BookingID = '" + BookingID + "' " +
                         "           AND T2.CustomerBookingID = T1.CustomerBookingID " ;

                  try  {
                     pstmt = con.prepareStatement(strCommand);
                     System.out.println(" ***** After prepareStatement of select MIN departDate field ****");
                     ResultSet rs2 = pstmt.executeQuery();
                     System.out.println(" *** Execute command to find minimum DepartDate successful****");


                        if (rs2.next()) {  // ********************************************* 2
                        System.out.println("** before get Date ***");
                        dtBookingDate = rs2.getTimestamp(1); // getDate
                        pstmt.close();
                        System.out.println("** After get Date : " + dtBookingDate +" ***");

//                        int yearNow = DateValueNow.getYear();
//                        int monthNow = DateValueNow.getMonth();
//                        int dayNow = DateValueNow.getDate();
//
//                        int yearBook = dtBookingDate.getYear();
//                        int monthBook = dtBookingDate.getMonth();
//                        int dayBook = dtBookingDate.getDate();
//
//                        if ((yearBook >= yearNow) & (monthBook >= monthNow) & (dayBook - dayNow >= 3)) {

                        if (dtBookingDate== null ) {
                           CheckValidation = false;
                           System.out.println("No information about minimum DepartDate of Booking : "+ BookingID);
                           return false;
                              }

                        if (dtBookingDate.after(DateValueNow)) {
                        System.out.println("Found Valid date : Can confirm ");
                        CheckValidation = true;
                        return true;
                        }

                            else{
                               CheckValidation = false;
                               System.out.println("Date expire to confirm, cancel or modify booking.");
//                               throw new ModifyControllerException("Date expire to confirm, cancel or modify booking.");

                                return false;

                                } //**********************************************************************1
                          }

                        else {  // can not find minimum date
                           CheckValidation = false;
                           System.out.println("No information about minimum DepartDate of Booking : "+ BookingID);
//                           throw new ModifyControllerException("No information about minimum DepartDate of Booking : "+ BookingID);
                           return false;
                              }

                    } // end try

                   catch(java.sql.SQLException e){
                   CheckValidation = false;
                   System.out.println("Can not execute sql command to find minimun DepartDate of Booking ");
//                   throw new EJBException("Can not execute sql command to find minimun DepartDate of Booking ");
                   return false;
                   }
                }// ************************************************************ 2

            else{  //************ 4
                  CheckValidation = false;
                  System.out.println("This BookingID has already confirm or cancel.");
//                  throw new ModifyControllerException("This BookingID has already confirm or cancel.");
                  return false;
                }
             }

          else {
                 CheckValidation = false;
                 System.out.println("No information about this BookingID.");
//                 throw new ModifyControllerException("No information about this BookingID.");
                  return false;

                } // *********** 5
     } // end try
      catch(java.sql.SQLException e){
      CheckValidation = false;
      throw new EJBException("Can not execute sql command to find BookingID. ");
    }
//  return CheckValidation;
}

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ REQUIRE METHOD @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

  public void ejbCreate() {

  System.out.println("**** Create method ****");
  try {
         makeConnection();
      } catch (Exception ex) {
          throw new EJBException("Unable to connect to database. " +
             ex.getMessage());
      }

  System.out.println("**** End Create method ****");

  }

  public void ejbRemove() {
  try {
         con.close();
      } catch (SQLException ex) {
          throw new EJBException("ejbRemove: " + ex.getMessage());
      }
  }

  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext context) {
    sessionContext = context;
  }

//----------------------------------------- BEGIN MAKECONNECTION ---------------------------------------------
 private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();
   }
//----------------------------------------- END MAKECONNECTION ---------------------------------------------

}