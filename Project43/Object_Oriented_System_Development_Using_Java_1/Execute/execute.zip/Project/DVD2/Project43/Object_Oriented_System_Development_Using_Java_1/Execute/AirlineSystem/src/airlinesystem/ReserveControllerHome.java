package airlinesystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2001
 * Company:      
 * @author 
 * @version 1.0
 */

public interface ReserveControllerHome extends EJBHome {
  public ReserveControllerRemote create() throws RemoteException, CreateException;
}