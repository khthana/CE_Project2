package olalatour;

import airlinesystem.*;
import busservice.*;
import hotelsystem.*;
import olalatour.*;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Jsp1Bean {
    private String sample = "Start value";
    private FullBookingInformation fullBookingInformation = new FullBookingInformation(new ArrayList(), new ArrayList(), new ArrayList(), new ArrayList(), null);
    private java.util.Iterator busBookingInformations = null;
    // Collection of busservice.BookSeatInfo
    private java.util.Iterator hotelBookingInformations = null;
    // Collection of hotelsystem.ReserveHotelInformation
    private java.util.Iterator airlineBookingInformation = null;
    // Collection of airlinesystem.BookSeatInfo
    private java.util.Iterator packageBookingInformation = null;
    // Collection of olalatour.PackageBookingInformation
    private String memberID = null;
//------------------------- AIRLINE ----------------------------------
  private String CustomerID = null;
  private String FirstName = null;
  private String LastName= null;
  private String Address = null;
  private String TelephoneNo= null ;
  private String FlightID  ;
  private int SrcIdx ;
  private int DstIdx;
  private int SeatType;
  private int ClassType;
  private java.sql.Timestamp DepartTime;
  private boolean CanSmoking;
  private double Price;
//------------------------- AIRLINE ----------------------------------
//----------------------------bus------------------------------------
  private int RouteID;
//-----------------------------bus------------------------------------


    /**Access sample property*/
    public String getSample() {
	return sample;
    }
    /**Access sample property*/
    public void setSample(String newValue) {
	if (newValue!=null) {
	    sample = newValue;
	}
    }
    public void addAirlineItem(String CustomerID, String FirstName, String LastName,String Address,String TelephoneNo, String FlightID,int SrcIdx, int DstIdx, int SeatType,int ClassType,java.sql.Timestamp DepartTime, boolean CanSmoking, double Price) {
	System.out.println("addAirlineItem");
	Collection collection = fullBookingInformation.getAirlineBookingInformation();
	collection.add(new airlinesystem.BookSeatInfo(CustomerID, null, null, null, null, FlightID, SrcIdx, DstIdx, SeatType, ClassType, DepartTime, CanSmoking, Price));
	System.out.println("end addAirlineItem");
    }
    public void addBusItem(String CustomerID, String FirstName, String LastName,String Address,String TelephoneNo,  int RouteID,int SrcIdx, int DstIdx, int SeatType,java.sql.Timestamp DepartTime,double Price) {
	System.out.println("addBusItem");
	Collection collection = fullBookingInformation.getBusBookingInformations();
	collection.add(new busservice.BookSeatInfo(CustomerID, null, null, null, null, RouteID, SrcIdx, DstIdx, SeatType, DepartTime, Price));
	System.out.println("end addBusItem");
    }
//-----------------------------------AIRLINE---------------------------------
  public boolean nextAirlineItem() {
    System.out.println("nextAirlineItem");
	if (airlineBookingInformation == null) {
	    airlineBookingInformation = fullBookingInformation.getAirlineBookingInformation().iterator();
	}
	if (airlineBookingInformation.hasNext()) {
	    airlinesystem.BookSeatInfo info = (airlinesystem.BookSeatInfo)airlineBookingInformation.next();
	    this.CustomerID = info.getCustomerID();
	    this.FlightID = info.getFlightID();
	    this.SrcIdx = info.getSrcIdx();
	    this.DstIdx = info.getDstIdx();
	    this.SeatType = info.getSeatType();
	    this.ClassType= info.getClassType();
	    this.DepartTime = info.getDepartTime();
	    this.CanSmoking= info.getCanSmoking();
	    this.Price = info.getPrice();
	    System.out.println("end nextAirlineItem");
	    return true;
	}
	else {
	    airlineBookingInformation = null;
	    System.out.println("end nextAirlineItem");
	    return false;
	}
    }
  public String getCustomerID() {
    return CustomerID;
  }

  public String getFirstName() {
    return FirstName;
  }

  public String getLastName() {
    return LastName;
  }

  public String getAddress() {
    return Address;
  }

  public String getTelephoneNo() {
    return TelephoneNo;
  }

  public String getFlightID() {
    return FlightID;
  }


  public int getSrcIdx() {
    return SrcIdx;
  }

  public int getDstIdx () {
    return DstIdx ;
  }

 public int getClassType () {
    return ClassType;
  }

  public int getSeatType() {
    return SeatType;
  }

  public java.sql.Timestamp getDepartTime() {
    return DepartTime;
  }

  public boolean getCanSmoking() {
   return CanSmoking;
   }

  public double getPrice() {
    return Price;
  }
//-----------------------------------AIRLINE---------------------------------
//-----------------------------------BUS--------------------------------------
  public boolean nextBusItem() {
    System.out.println("nextBusItem");
	if (busBookingInformations == null) {
	    busBookingInformations = fullBookingInformation.getBusBookingInformations().iterator();
	}
	if (busBookingInformations.hasNext()) {
	    busservice.BookSeatInfo info = (busservice.BookSeatInfo)busBookingInformations.next();
	    this.CustomerID = info.getCustomerID();
	    this.RouteID = info.getRouteID();
	    this.SrcIdx = info.getSrcIdx();
	    this.DstIdx = info.getDstIdx();
	    this.SeatType = info.getSeatType();
	    this.DepartTime = info.getDepartTime();
	    this.Price = info.getPrice();
	    System.out.println("end nextBusItem");
	    return true;
	}
	else {
	    busBookingInformations = null;
	    System.out.println("end nextBusItem");
	    return false;
	}
    }
  public int getRouteID() {
    return RouteID;
  }
//-----------------------------------BUS--------------------------------------
}