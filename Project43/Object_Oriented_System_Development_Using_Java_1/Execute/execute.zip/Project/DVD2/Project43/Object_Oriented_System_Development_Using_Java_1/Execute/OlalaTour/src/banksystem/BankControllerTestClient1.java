package banksystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;

public class BankControllerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 250;
  private boolean logging = true;
  private BankControllerHome bankControllerHome = null;
  private BankControllerRemote bankControllerRemote = null;

  /**Construct the EJB test client*/
  public BankControllerTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("BankController");

      //cast to Home interface
      bankControllerHome = (BankControllerHome) PortableRemoteObject.narrow(ref, BankControllerHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public BankControllerRemote create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      bankControllerRemote = bankControllerHome.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + bankControllerRemote + ".");
    }
    return bankControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String payByDebitCardID(String debitCardID, String relateAccountID, double amount) {
    String returnValue = "";
    if (bankControllerRemote == null) {
      System.out.println("Error in payByDebitCardID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling payByDebitCardID(" + debitCardID + ", " + relateAccountID + ", " + amount + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bankControllerRemote.payByDebitCardID(debitCardID, relateAccountID, amount);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: payByDebitCardID(" + debitCardID + ", " + relateAccountID + ", " + amount + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: payByDebitCardID(" + debitCardID + ", " + relateAccountID + ", " + amount + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from payByDebitCardID(" + debitCardID + ", " + relateAccountID + ", " + amount + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public String payByCreditCardID(String creditCardID, String relateAccountID, double amount) {
    String returnValue = "";
    if (bankControllerRemote == null) {
      System.out.println("Error in payByCreditCardID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling payByCreditCardID(" + creditCardID + ", " + relateAccountID + ", " + amount + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bankControllerRemote.payByCreditCardID(creditCardID, relateAccountID, amount);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: payByCreditCardID(" + creditCardID + ", " + relateAccountID + ", " + amount + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: payByCreditCardID(" + creditCardID + ", " + relateAccountID + ", " + amount + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from payByCreditCardID(" + creditCardID + ", " + relateAccountID + ", " + amount + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public void checkTransfer(String relateAccountID, String transactionID, double amount) {
    if (bankControllerRemote == null) {
      System.out.println("Error in checkTransfer(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling checkTransfer(" + relateAccountID + ", " + transactionID + ", " + amount + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      bankControllerRemote.checkTransfer(relateAccountID, transactionID, amount);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: checkTransfer(" + relateAccountID + ", " + transactionID + ", " + amount + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: checkTransfer(" + relateAccountID + ", " + transactionID + ", " + amount + ")");
      }
      e.printStackTrace();
    }
  }

  public String transfer(String accountIDSource, String relateAccountID, double amount) {
    String returnValue = "";
    if (bankControllerRemote == null) {
      System.out.println("Error in transfer(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling transfer(" + accountIDSource + ", " + relateAccountID + ", " + amount + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bankControllerRemote.transfer(accountIDSource, relateAccountID, amount);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: transfer(" + accountIDSource + ", " + relateAccountID + ", " + amount + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: transfer(" + accountIDSource + ", " + relateAccountID + ", " + amount + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from transfer(" + accountIDSource + ", " + relateAccountID + ", " + amount + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    BankControllerTestClient1 client = new BankControllerTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    client.create();
//    client.checkTransfer("NOTE486","123456789",999);
//    client.transfer("A0001","A0002",500) ;
//    client.payByCreditCardID("C0001","C0002",1000);
//    client.payByCreditCardID("C0001","A0002",1000);
//      client.payByDebitCardID("D0002","A0001",1000);
      client.checkTransfer("A0001","0E80FFE4-FFFF-FFD3-0061-4DE0AFCAFF22",1000);

  }
}