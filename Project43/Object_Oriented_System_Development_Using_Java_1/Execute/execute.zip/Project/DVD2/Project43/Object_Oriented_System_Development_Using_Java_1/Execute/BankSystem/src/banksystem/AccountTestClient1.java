package banksystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;

public class AccountTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private AccountHome accountHome = null;
  private AccountRemote accountRemote = null;

  /**Construct the EJB test client*/
  public AccountTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("banksystem/Account");

	  //cast to Home interface
	  accountHome = (AccountHome) PortableRemoteObject.narrow(ref, AccountHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public AccountRemote create(String accoutID, String accountName, double credit, double balance, String password, String creditCardID, String debitCardID) {
	long startTime = 0;
	if (logging) {
	  log("Calling create(" + accoutID + ", " + accountName + ", " + credit + ", " + balance + ", " + password + ", " + creditCardID + ", " + debitCardID + ")");
	  startTime = System.currentTimeMillis();
	}
	try {
	  accountRemote = accountHome.create(accoutID, accountName, credit, balance, password, creditCardID, debitCardID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create(" + accoutID + ", " + accountName + ", " + credit + ", " + balance + ", " + password + ", " + creditCardID + ", " + debitCardID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create(" + accoutID + ", " + accountName + ", " + credit + ", " + balance + ", " + password + ", " + creditCardID + ", " + debitCardID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(" + accoutID + ", " + accountName + ", " + credit + ", " + balance + ", " + password + ", " + creditCardID + ", " + debitCardID + "): " + accountRemote + ".");
	}
	return accountRemote;
  }

  public AccountRemote findByPrimaryKey(String primKey) {
	long startTime = 0;
	if (logging) {
	  log("Calling findByPrimaryKey(" + primKey + ")");
	  startTime = System.currentTimeMillis();
	}
	try {
	  accountRemote = accountHome.findByPrimaryKey(primKey);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findByPrimaryKey(" + primKey + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findByPrimaryKey(" + primKey + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findByPrimaryKey(" + primKey + "): " + accountRemote + ".");
	}
	return accountRemote;
  }

  public Collection findByCreditCardID(String creditCardID) {
	Collection returnValue = null;
	long startTime = 0;
	if (logging) {
	  log("Calling findByCreditCardID(" + creditCardID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountHome.findByCreditCardID(creditCardID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findByCreditCardID(" + creditCardID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findByCreditCardID(" + creditCardID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findByCreditCardID(" + creditCardID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findByDebitCardID(String debitCardID) {
	Collection returnValue = null;
	long startTime = 0;
	if (logging) {
	  log("Calling findByDebitCardID(" + debitCardID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountHome.findByDebitCardID(debitCardID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findByDebitCardID(" + debitCardID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findByDebitCardID(" + debitCardID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findByDebitCardID(" + debitCardID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public double getCredit() {
	double returnValue = 0f;
	if (accountRemote == null) {
	  System.out.println("Error in getCredit(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getCredit()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getCredit();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getCredit()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getCredit()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getCredit(): " + returnValue + ".");
	}
	return returnValue;
  }

  public String getAccountID() {
	String returnValue = "";
	if (accountRemote == null) {
	  System.out.println("Error in getAccountID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getAccountID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getAccountID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getAccountID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getAccountID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getAccountID(): " + returnValue + ".");
	}
	return returnValue;
  }

  public double getBalance() {
	double returnValue = 0f;
	if (accountRemote == null) {
	  System.out.println("Error in getBalance(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getBalance()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getBalance();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getBalance()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getBalance()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getBalance(): " + returnValue + ".");
	}
	return returnValue;
  }

  public String getAccountName() {
	String returnValue = "";
	if (accountRemote == null) {
	  System.out.println("Error in getAccountName(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getAccountName()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getAccountName();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getAccountName()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getAccountName()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getAccountName(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setAccountName(String newAccountName) {
	if (accountRemote == null) {
	  System.out.println("Error in setAccountName(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setAccountName(" + newAccountName + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  accountRemote.setAccountName(newAccountName);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setAccountName(" + newAccountName + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setAccountName(" + newAccountName + ")");
	  }
	  e.printStackTrace();
	}
  }

  public void setPassword(String oldPassword, String newPassword) {
	if (accountRemote == null) {
	  System.out.println("Error in setPassword(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setPassword(" + oldPassword + ", " + newPassword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  accountRemote.setPassword(oldPassword, newPassword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setPassword(" + oldPassword + ", " + newPassword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setPassword(" + oldPassword + ", " + newPassword + ")");
	  }
	  e.printStackTrace();
	}
  }

  public void withdraw(double amount) {
	if (accountRemote == null) {
	  System.out.println("Error in withdraw(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling withdraw(" + amount + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  accountRemote.withdraw(amount);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: withdraw(" + amount + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: withdraw(" + amount + ")");
	  }
	  e.printStackTrace();
	}
  }

  public void deposit(double amount) {
	if (accountRemote == null) {
	  System.out.println("Error in deposit(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling deposit(" + amount + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  accountRemote.deposit(amount);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: deposit(" + amount + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: deposit(" + amount + ")");
	  }
	  e.printStackTrace();
	}
  }

  public void withdrawBycredit(double amount) {
	if (accountRemote == null) {
	  System.out.println("Error in withdrawBycredit(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling withdrawBycredit(" + amount + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  accountRemote.withdrawBycredit(amount);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: withdrawBycredit(" + amount + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: withdrawBycredit(" + amount + ")");
	  }
	  e.printStackTrace();
	}
  }

  public String getPassword() {
	String returnValue = "";
	if (accountRemote == null) {
	  System.out.println("Error in getPassword(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getPassword()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getPassword();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getPassword()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getPassword()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getPassword(): " + returnValue + ".");
	}
	return returnValue;
  }

  public String getCreditCardID() {
	String returnValue = "";
	if (accountRemote == null) {
	  System.out.println("Error in getCreditCardID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getCreditCardID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getCreditCardID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getCreditCardID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getCreditCardID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getCreditCardID(): " + returnValue + ".");
	}
	return returnValue;
  }

  public String getDebitCardID() {
	String returnValue = "";
	if (accountRemote == null) {
	  System.out.println("Error in getDebitCardID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getDebitCardID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = accountRemote.getDebitCardID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getDebitCardID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getDebitCardID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getDebitCardID(): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	AccountTestClient1 client = new AccountTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.
	client.create("4455556666","kkkkkkkkk",4000,4000,"aaaaaaa","pppppp","ttttt");
  }
}