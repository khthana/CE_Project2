<html>
<head>
<jsp:useBean id="viewerBean" scope="page" class="olalatour.ViewerBean" />
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--


//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<table width="750" border="1">
  <tr>
    <td width="70%" rowspan="2">
      <form name="form1" method="get" action="BusSearchList.jsp">
	<font size="5"><b>Fill Data For Bus Search</b></font>
	<table width="100%" border="1">
	  <tr>
	    <td colspan="2"><b>How many of passengers?</b> *</td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">Total number of travellers?</div>
	    </td>
	    <td width="43%">
	          <select name="NumberOfTraveller">
                <option value="1" selected>1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9">9</option>

	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td width="57%"><b>Where would you like to go?(Internal Country) *
	      </b></td>
	    <td width="43%">&nbsp;</td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">From :</div>
	    </td>
	    <td width="43%"><b>
	          <select name="ToPlace">
                <%viewerBean.searchBusStation("");%> <% while (viewerBean.nextBusStation()) { %> 
                <option value="<%out.print(viewerBean.getPlaceID());%>"><%out.print(viewerBean.getPlaceID());%> <%out.print(viewerBean.getPlaceName());%></option>
		<% } %>
	      </select>
	      </b></td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">To : </div>
	    </td>
	    <td width="43%"><b>
	          <select name="FromPlace">
                <%viewerBean.searchBusStation("");%> <% while (viewerBean.nextBusStation()) { %> 
                <option value="<%out.print(viewerBean.getPlaceID());%>"><%out.print(viewerBean.getPlaceID());%> <%out.print(viewerBean.getPlaceName());%></option>
		<% } %>
	      </select>
	      </b></td>
	  </tr>
	  <tr>
	    <td colspan="2">
	      <div align="center">You can go on any day that lowest fare? If so,stop
		here<br>
		By clicking "Show me Buses", you indicate that you agree to the
		following <br>
		<input type="submit" name="buttonShowMeBus1" value="ShowMeBus">
	      </div>
	    </td>
	  </tr>
	  <tr>
	    <td width="57%"><b>When would you like to go?</b></td>
	    <td width="43%">&nbsp;</td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">Departing :</div>
	    </td>
	    <td width="43%">
	      <select name="selectDay">
		  <option value="1">1</option>
		  <option value="2">2</option>
		  <option value="3">3</option>
		  <option value="4">4</option>
		  <option value="5">5</option>
		  <option value="6">6</option>
		  <option value="7">7</option>
		  <option value="8">8</option>
		  <option value="9" selected>9</option>
		  <option value="10">10</option>
		  <option value="11">11</option>
		  <option value="12">12</option>
		  <option value="13">13</option>
		  <option value="14">14</option>
		  <option value="15">15</option>
		  <option value="16">16</option>
		  <option value="17">17</option>
		  <option value="18">18</option>
		  <option value="19">19</option>
		  <option value="20">20</option>
		  <option value="21">21</option>
		  <option value="22">22</option>
		  <option value="23">23</option>
		  <option value="24">24</option>
		  <option value="25">25</option>
		  <option value="26">26</option>
		  <option value="27">27</option>
		  <option value="28">28</option>
		  <option value="29">29</option>
		  <option value="30">30</option>
		  <option value="31">31</option>

	      </select>
	      <select name="selectMonth">
		<option value="1">January</option>
		<option value="2"> Febuary</option>
		<option value="3"> March</option>
		<option value="4"> April</option>
		<option value="5" selected> May</option>
		<option value="6"> June</option>
		<option value="7"> July</option>
		<option value="8"> August</option>
		<option value="9"> September</option>
		<option value="10"> October</option>
		<option value="11"> November</option>
		<option value="12"> December</option>
	      </select>
	      <select name="selectYear">
		<option value="2001"selected>2001</option>
		<option value="2002"> 2002</option>
		<option value="2003"> 2003</option>
		<option value="2004"> 2004</option>
	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td width="57%"><b>What bus company do you like prefer?</b></td>
	    <td width="43%">&nbsp;</td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">company :</div>
	    </td>
	    <td width="43%">
	      <select name="selectBusCompany"  size="1">
		<option value="0" selected>ANY</option>
		<option value="1">Surachai Bus</option>
	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td width="57%"><b>Optional</b></td>
	    <td width="43%">&nbsp;</td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">Bus Type : </div>
	    </td>
	    <td width="43%">
	      <select name="selectBusType">
		<option value="0" selected>ANY</option>
		<option value="1">P1 VIP </option>
		<option value="2">P1</option>
		<option value="3">P2</option>
	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td width="57%">
	      <div align="right">Seat Position </div>
	    </td>
	    <td width="43%">
	      <select name="selectSeatPosition">
		<option value="0" selected>Any Position</option>
		<option value="1">Near Window</option>
		<option value="2">Aisel</option>
	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td colspan="2">
	      <div align="center">
		<input type="submit" name="buttonShowMeBus2" value="ShowMeBus">
	      </div>
	    </td>
	  </tr>
	</table>

      </form>
    </td>
  </tr>

</table>
</body>
</html>
