package restaurantsystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class RestaurantTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private RestaurantHome restaurantHome = null;
  private RestaurantRemote restaurantRemote = null;


  /**Construct the EJB test client*/
  public RestaurantTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("Restaurant");

      //cast to Home interface
      restaurantHome = (RestaurantHome) PortableRemoteObject.narrow(ref, RestaurantHome.class);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded initializing bean access.");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public RestaurantRemote create(String restaurantID, String restaurantName, String description, int totalSeat, String address, int star, String telephoneNo) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + restaurantID + ", " + restaurantName + ", " + description + ", " + totalSeat + ", " + address + ", " + star + ", " + telephoneNo + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      restaurantRemote = restaurantHome.create(restaurantID, restaurantName, description, totalSeat, address, star, telephoneNo);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: create(" + restaurantID + ", " + restaurantName + ", " + description + ", " + totalSeat + ", " + address + ", " + star + ", " + telephoneNo + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: create(" + restaurantID + ", " + restaurantName + ", " + description + ", " + totalSeat + ", " + address + ", " + star + ", " + telephoneNo + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + restaurantID + ", " + restaurantName + ", " + description + ", " + totalSeat + ", " + address + ", " + star + ", " + telephoneNo + "): " + restaurantRemote + ".");
    }
    return restaurantRemote;
  }

  public RestaurantRemote findByPrimaryKey(String primKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      restaurantRemote = restaurantHome.findByPrimaryKey(primKey);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: findByPrimaryKey(" + primKey + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: findByPrimaryKey(" + primKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primKey + "): " + restaurantRemote + ".");
    }
    return restaurantRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public int getStar() {
    int returnValue = 0;
    if (restaurantRemote == null) {
      System.out.println("Error in getStar(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getStar()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = restaurantRemote.getStar();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getStar()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getStar()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getStar(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setStar(int newStar) {
    if (restaurantRemote == null) {
      System.out.println("Error in setStar(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setStar(" + newStar + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      restaurantRemote.setStar(newStar);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setStar(" + newStar + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setStar(" + newStar + ")");
      }
      e.printStackTrace();
    }
  }

  public String getAddress() {
    String returnValue = "";
    if (restaurantRemote == null) {
      System.out.println("Error in getAddress(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAddress()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = restaurantRemote.getAddress();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getAddress()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getAddress()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAddress(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAddress(String newAddress) {
    if (restaurantRemote == null) {
      System.out.println("Error in setAddress(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAddress(" + newAddress + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      restaurantRemote.setAddress(newAddress);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setAddress(" + newAddress + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setAddress(" + newAddress + ")");
      }
      e.printStackTrace();
    }
  }

  public int getTotalSeat() {
    int returnValue = 0;
    if (restaurantRemote == null) {
      System.out.println("Error in getTotalSeat(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getTotalSeat()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = restaurantRemote.getTotalSeat();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getTotalSeat()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getTotalSeat()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getTotalSeat(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setTotalSeat(int newTotalSeat) {
    if (restaurantRemote == null) {
      System.out.println("Error in setTotalSeat(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setTotalSeat(" + newTotalSeat + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      restaurantRemote.setTotalSeat(newTotalSeat);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setTotalSeat(" + newTotalSeat + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setTotalSeat(" + newTotalSeat + ")");
      }
      e.printStackTrace();
    }
  }

  public String getDescription() {
    String returnValue = "";
    if (restaurantRemote == null) {
      System.out.println("Error in getDescription(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getDescription()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = restaurantRemote.getDescription();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getDescription()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getDescription()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getDescription(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setDescription(String newDescription) {
    if (restaurantRemote == null) {
      System.out.println("Error in setDescription(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setDescription(" + newDescription + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      restaurantRemote.setDescription(newDescription);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setDescription(" + newDescription + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setDescription(" + newDescription + ")");
      }
      e.printStackTrace();
    }
  }

  public String getRestaurantID() {
    String returnValue = "";
    if (restaurantRemote == null) {
      System.out.println("Error in getRestaurantID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getRestaurantID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = restaurantRemote.getRestaurantID();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getRestaurantID()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getRestaurantID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getRestaurantID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getRestaurantName() {
    String returnValue = "";
    if (restaurantRemote == null) {
      System.out.println("Error in getRestaurantName(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getRestaurantName()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = restaurantRemote.getRestaurantName();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getRestaurantName()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getRestaurantName()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getRestaurantName(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setRestaurantName(String newRestaurantName) {
    if (restaurantRemote == null) {
      System.out.println("Error in setRestaurantName(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setRestaurantName(" + newRestaurantName + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      restaurantRemote.setRestaurantName(newRestaurantName);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setRestaurantName(" + newRestaurantName + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setRestaurantName(" + newRestaurantName + ")");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    RestaurantTestClient1 client = new RestaurantTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
    client.findByPrimaryKey("hoho2");
    System.out.println(client.getAddress());
  }
  private void jbInit() throws Exception {
  }
}