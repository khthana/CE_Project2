package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class PackageBooking implements EntityBean {
  EntityContext entityContext;
  public String travellerId;
  public String packageId;
  public Timestamp departTime;
  public String bookingId;
  public PackageBookingPK ejbCreate(String travellerId, String packageId, Timestamp departTime, String bookingId) throws CreateException {
	this.travellerId = travellerId;
	this.packageId = packageId;
	this.departTime = departTime;
	this.bookingId = bookingId;
	return null;
  }
  public void ejbPostCreate(String travellerId, String packageId, Timestamp departTime, String bookingId) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
  }
  public void unsetEntityContext() {
	entityContext = null;
  }
  public String getTravellerId() {
	return travellerId;
  }
  public String getPackageId() {
	return packageId;
  }
  public Timestamp getDepartTime() {
	return departTime;
  }
  public String getBookingId() {
	return bookingId;
  }
}