package banksystem;


import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public interface AccountHome extends EJBHome {
  public AccountRemote create(String accoutID, String accountName,double credit,double balance, String password, String creditCardID, String debitCardID) throws RemoteException, CreateException;
  public AccountRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
  public Collection findByCreditCardID(String creditCardID) throws  RemoteException, FinderException;
  public Collection findByDebitCardID(String debitCardID) throws  RemoteException, FinderException;

}
