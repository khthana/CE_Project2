package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingRemote extends EJBObject {
  String getBookingId() throws RemoteException;
  Double getTotalPrice() throws RemoteException;
  void setTotalPrice(Double totalPrice) throws RemoteException;
  Timestamp getBookingTime() throws RemoteException;
  void setBookingTime(Timestamp bookingTime) throws RemoteException;
  Integer getConfirmed() throws RemoteException;
  void setConfirmed(Integer confirmed) throws RemoteException;
  Date getDeadline() throws RemoteException;
  void setDeadline(Date deadline) throws RemoteException;
  String getMemberId() throws RemoteException;
  void setMemberId(String memberId) throws RemoteException;
  String getBusGroupBooking() throws RemoteException;
  void setBusGroupBooking(String busGroupBooking) throws RemoteException;
  String getAircraftGroupBooking() throws RemoteException;
  void setAircraftGroupBooking(String aircraftGroupBooking) throws RemoteException;
  String getHotelGroupBookingId() throws RemoteException;
  void setHotelGroupBookingId(String hotelGroupBookingId) throws RemoteException;
	public boolean confirm() throws RemoteException;
	public boolean cancel() throws RemoteException;}