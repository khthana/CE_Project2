package hotelsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface CustomerRemote extends EJBObject {
  public int getGender() throws RemoteException;
  public void setGender(int newGender) throws RemoteException;
  public void setTelephoneNo(java.lang.String newTelephoneNo) throws RemoteException;
  public java.lang.String getTelephoneNo() throws RemoteException;
  public java.lang.String getAddress() throws RemoteException;
  public void setAddress(java.lang.String newAddress) throws RemoteException;
  public java.lang.String getLastname() throws RemoteException;
  public void setLastname(java.lang.String newLastname) throws RemoteException;
  public java.lang.String getFirstname() throws RemoteException;
  public void setFirstname(java.lang.String newFirstname) throws RemoteException;
  public java.lang.String getCustomerID() throws RemoteException;
}