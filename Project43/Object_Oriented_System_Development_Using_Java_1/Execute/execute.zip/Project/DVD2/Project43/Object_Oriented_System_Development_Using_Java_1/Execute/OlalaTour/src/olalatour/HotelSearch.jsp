<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--

//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<table width="750" border="1">
  <tr>
	<td rowspan="2">
	  <form name="form1" action="HotelSearchList.jsp">
	<font size="5"><b>Fill Data For Hotel Search</b></font> <br>
	<table width="100%" border="1">
	  <tr>
		<td width="50%"> Search for hotel by address and by hotel name </td>
		<td width="50%">&nbsp;</td>
	  </tr>
	  <tr>
		<td width="50%">
		  <div align="right">Hotel Name :</div>
		</td>
		<td width="50%"><b>
		  <input type="text" name="hotelName">
		  </b></td>
	  </tr>
	  <tr>
		<td width="50%">
		  <div align="right">description : </div>
		</td>
		<td width="50%">
		  <input type="text" name="description">
		</td>
	  </tr>
	  <tr>
		<td width="50%">
		  <div align="right">address :</div>
		</td>
		<td width="50%">
		  <input type="text" name="address">
		</td>
	  </tr>
	  <tr>
		<td width="50%">
		  <div align="right">star : </div>
		</td>
		<td width="50%">
		  <select name="star">
		<option value="500" selected>ANY</option>
		<option value="5">5</option>
		<option value="4">4</option>
		<option value="3">3</option>
		<option value="2">2</option>
		<option value="1">1</option>
		  </select>
		</td>
	  </tr>
	  <tr>
		<td width="50%">
		  <div align="right">BookCheckInDate :</div>
		</td>
		<td width="50%">
		  <select name="BookCheckInDateDay" >
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9" selected>9</option>
		<option value="10">10</option>
		<option value="11">11</option>
		<option value="12">12</option>
		<option value="13">13</option>
		<option value="14">14</option>
		<option value="15">15</option>
		<option value="16">16</option>
		<option value="17">17</option>
		<option value="18">18</option>
		<option value="19">19</option>
		<option value="20">20</option>
		<option value="21">21</option>
		<option value="22">22</option>
		<option value="23">23</option>
		<option value="24">24</option>
		<option value="25">25</option>
		<option value="26">26</option>
		<option value="27">27</option>
		<option value="28">28</option>
		<option value="29">29</option>
		<option value="30">30</option>
		<option value="31">31</option>
		  </select>
		  <select name="BookCheckInDateMonth">
		<option value="1">January</option>
		<option value="2"         >Febuary</option>
		<option value="3"           >March</option>
		<option value="4"           >April</option>
		<option value="5" selected             >May</option>
		<option value="6"            >June</option>
		<option value="7"            >July</option>
		<option value="8"          >August</option>
		<option value="9"       >September</option>
		<option value="10"         >October</option>
		<option value="11"        >November</option>
		<option value="12"        >December</option>
		  </select>
		  <select name="BookCheckInDateYear">
		<option value="2001" selected>2001</option>
		<option value="2002"> 2002</option>
		<option value="2003"> 2003</option>
		<option value="2004"> 2004</option>
		  </select>
		</td>
	  </tr>
	  <tr>
		<td width="50%">
		  <div align="right">BookCheckOutDate :</div>
		</td>
		<td width="50%">
		  <select name="BookCheckOutDateDay" >
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9" selected>9</option>
		<option value="10">10</option>
		<option value="11">11</option>
		<option value="12">12</option>
		<option value="13">13</option>
		<option value="14">14</option>
		<option value="15">15</option>
		<option value="16">16</option>
		<option value="17">17</option>
		<option value="18">18</option>
		<option value="19">19</option>
		<option value="20">20</option>
		<option value="21">21</option>
		<option value="22">22</option>
		<option value="23">23</option>
		<option value="24">24</option>
		<option value="25">25</option>
		<option value="26">26</option>
		<option value="27">27</option>
		<option value="28">28</option>
		<option value="29">29</option>
		<option value="30">30</option>
		<option value="31">31</option>
		  </select>
		  <select name="BookCheckOutDateMonth">
		<option value="1">January</option>
		<option value="2"         >Febuary</option>
		<option value="3"           >March</option>
		<option value="4"           >April</option>
		<option value="5" selected             >May</option>
		<option value="6"            >June</option>
		<option value="7"            >July</option>
		<option value="8"          >August</option>
		<option value="9"       >September</option>
		<option value="10"         >October</option>
		<option value="11"        >November</option>
		<option value="12"        >December</option>
		  </select>
		  <select name="BookCheckOutDateYear">
		<option value="2001" selected>2001</option>
		<option value="2002"> 2002</option>
		<option value="2003"> 2003</option>
		<option value="2004"> 2004</option>
		  </select>
		</td>
	  </tr>
	</table>
	<b> </b>
	<div align="center"> </div>
	<div align="center">
	  <input type="submit" name="Submit" value="SearchHotel">
	</div>
	  </form>
	</td>
  </tr>
  <tr> </tr>
</table>
</body>
</html>
