package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FestivalBMP extends Festival {
	DataSource dataSource;
	public String ejbCreate(String festivalId, String festivalName, String description) throws CreateException {
	super.ejbCreate(festivalId, festivalName, description);
	try {
		//First see if the object already exists
		ejbFindByPrimaryKey(festivalId);
		//If so, then we have to throw an exception
		throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
		//Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("INSERT INTO FESTIVAL (FESTIVAL_ID, FESTIVAL_NAME, DESCRIPTION) VALUES (?, ?, ?)");
		statement.setString(1, festivalId);
		statement.setString(2, festivalName);
		statement.setString(3, description);
		if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return festivalId;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL INSERT INTO FESTIVAL (FESTIVAL_ID, FESTIVAL_NAME, DESCRIPTION) VALUES (?, ?, ?): " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public String ejbCreate(String festivalId) throws CreateException {
	return ejbCreate(festivalId, null, null);
	}
	public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("DELETE FROM FESTIVAL WHERE FESTIVAL_ID = ?");
		statement.setString(1, festivalId);
		if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL DELETE FROM FESTIVAL WHERE FESTIVAL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void ejbLoad() {
	festivalId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT FESTIVAL_NAME, DESCRIPTION FROM FESTIVAL WHERE FESTIVAL_ID = ?");
		statement.setString(1, festivalId);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
		}
		festivalName = resultSet.getString(1);
		description = resultSet.getString(2);
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT FESTIVAL_NAME, DESCRIPTION FROM FESTIVAL WHERE FESTIVAL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	super.ejbLoad();
	}
	public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("UPDATE FESTIVAL SET FESTIVAL_NAME = ?, DESCRIPTION = ? WHERE FESTIVAL_ID = ?");
		statement.setString(1, festivalName);
		statement.setString(2, description);
		statement.setString(3, festivalId);
		if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL UPDATE FESTIVAL SET FESTIVAL_NAME = ?, DESCRIPTION = ? WHERE FESTIVAL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT FESTIVAL_ID FROM FESTIVAL WHERE FESTIVAL_ID = ?");
		statement.setString(1, key);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return key;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT FESTIVAL_ID FROM FESTIVAL WHERE FESTIVAL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT FESTIVAL_ID FROM FESTIVAL");
		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		String festivalId = resultSet.getString(1);
		keys.addElement(festivalId);
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT FESTIVAL_ID FROM FESTIVAL: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindByFestivalNameDetail(String festivalName, String detail) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT FESTIVAL_ID FROM FESTIVAL WHERE FESTIVAL_NAME LIKE ? AND DESCRIPTION LIKE ? ");
		statement.setString(1, "%" + festivalName + "%");
		statement.setString(2, "%" + detail + "%");

		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}

	public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
		javax.naming.Context context = new javax.naming.InitialContext();
		dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
		throw new EJBException("Error looking up dataSource:" + e.toString());
	}
	}
	public Collection getPlaces() {
	  System.out.println("getPlaces");
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT DISTINCT PLACE_ID FROM PLACE_FESTIVAL WHERE FESTIVAL_ID = ? ");
		statement.setString(1, festivalId);

		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	  System.out.println("end getPlaces");
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}

}