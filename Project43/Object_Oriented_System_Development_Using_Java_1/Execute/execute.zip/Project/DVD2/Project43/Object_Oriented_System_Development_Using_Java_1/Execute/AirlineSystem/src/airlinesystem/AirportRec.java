package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */


public class AirportRec implements java.io.Serializable {
  String PlaceID;
  String PlaceName ;

  public  AirportRec(String PlaceID, String PlaceName) {

      this.PlaceID = PlaceID;
      this.PlaceName = PlaceName;
   }

   public String getPlaceID() {
      return PlaceID;
   }

   public String getPlaceName() {
     return PlaceName;
   }

}