package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Restaurant implements EntityBean {
  EntityContext entityContext;
  public String restaurantID;
  public String restaurantName;
  public String description;
  public int totalSeat;
  public String address;
  public int star;
  private Connection con;
  private String dbName = "java:comp/env/jdbc/RestaurantDB";
  public String telephoneNo;

  public String ejbCreate(String restaurantID, String restaurantName, String description,
	int totalSeat, String address, int star, String telephoneNo) throws CreateException {

      System.out.println("ejbCreate");

      try {
		insertRow(restaurantID, restaurantName, description, totalSeat, address, star, telephoneNo);
      } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
	      ex.getMessage());
      }

      this.restaurantID = restaurantID;
      this.restaurantName = restaurantName;
      this.description = description;
      this.totalSeat = totalSeat;
      this.address = address;
      this.star = star;
      this.telephoneNo = telephoneNo;

      System.out.println("end ejbCreate");

      return restaurantID;
  }
  public void ejbPostCreate(String restaurantID, String restaurantName, String description,
      int totalSeat, String address, int star, String telephoneNo) throws CreateException {
//      System.out.println("ejbPostCreate");

  }
  public void ejbRemove() throws RemoveException {
    System.out.println("ejbRomove");
      try {
	 deleteRow(restaurantID);
       } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
	      ex.getMessage());
       }
    System.out.println("end ejbRomove");
  }
  public String ejbFindByPrimaryKey(String primKey) throws FinderException {
      System.out.println("ejbFindByPrimaryKey");

      boolean result;

      try {
	 result = selectByPrimaryKey(primKey);
       } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
	      ex.getMessage());
       }
      if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
      }
      else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
	    ("Row for id " + primKey + " not found.");
      }
  }

  public Collection ejbFindByNameDescriptionAddressStar(String name, String description, String address, int star) throws FinderException {
    System.out.println("ejbFindByNameDescriptionAddressStar in Restaurant");
      Collection result;

      try {
	 result = selectByNameDescriptionAddressStar(name, description, address, star);
       } catch (Exception ex) {
	   throw new EJBException("ejbFindByNameDescriptionAddressStar " +
	      ex.getMessage());
       }

      if (result.isEmpty()) {
	 throw new ObjectNotFoundException("No rows found.");
      }
      else {
	 return result;
      }
  }

  public void ejbActivate() {
    System.out.println("ejbActivate");
    restaurantID = (String)entityContext.getPrimaryKey();
    System.out.println("end ejbActivate");
  }
  public void ejbPassivate() {
    System.out.println("ejbPassivate");
    restaurantID = null;
    System.out.println("end ejbPassivate");
  }
  public void ejbLoad() {
    System.out.println("ejbLoad");
      try {
	 loadRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
      System.out.println("end ejbLoad");
  }
  public void ejbStore() {
    System.out.println("ejbLoad");
      try {
	 storeRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
    System.out.println("end ejbLoad");
  }
  public void setEntityContext(EntityContext entityContext) {
    System.out.println("setEntityContext");
    this.entityContext = entityContext;
      try {
	 makeConnection();
      } catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
	     ex.getMessage());
      }
    System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
    System.out.println("unsetEntityContext");
    entityContext = null;
      try {
	 con.close();
      } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
      }
    System.out.println("end unsetEntityContext");
  }
  public String getRestaurantID() {
    return restaurantID;
  }
  public void setRestaurantName(String newRestaurantName) {
    restaurantName = newRestaurantName;
  }
  public String getRestaurantName() {
    return restaurantName;
  }
  public void setDescription(String newDescription) {
    description = newDescription;
  }
  public String getDescription() {
    return description;
  }
  public void setTotalSeat(int newTotalSeat) {
    totalSeat = newTotalSeat;
  }
  public int getTotalSeat() {
    return totalSeat;
  }
  public void setAddress(String newAddress) {
    address = newAddress;
  }
  public String getAddress() {
    return address;
  }
  public void setStar(int newStar) {
    star = newStar;
  }
  public int getStar() {
    return star;
  }
/*********************** Database Routines *************************/

   private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();
   }

   private void insertRow (String restaurantID, String restaurantName, String description,
      int totalSeat, String address, int star, String telephoneNo) throws SQLException {

	  String insertStatement =
		"insert into RESTAURANT values ( ? , ? , ? , ? , ? , ? , ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, restaurantID);
	  prepStmt.setString(2, restaurantName);
	  prepStmt.setString(3, description);
	  prepStmt.setInt( 4, totalSeat);
	  prepStmt.setString(5, address);
	  prepStmt.setInt(6, star);
	  prepStmt.setString(7, telephoneNo);

	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String id) throws SQLException {

      String deleteStatement =
	    "delete from RESTAURANT where RESTAURANT_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(deleteStatement);

      prepStmt.setString(1, id);
      prepStmt.executeUpdate();
      prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
      throws SQLException {

      String selectStatement =
	    "select RESTAURANT_ID " +
	    "from RESTAURANT where RESTAURANT_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);
      prepStmt.setString(1, primaryKey);

      ResultSet rs = prepStmt.executeQuery();
      boolean result = rs.next();
      prepStmt.close();
      return result;
   }
   private Collection selectByNameDescriptionAddressStar(String name, String description, String address, int star) throws SQLException {

//      String selectStatement =
//	    "select RESTAURANT_ID " +
//	    "from RESTAURANT where RESTAURANT_NAME LIKE '%?%' AND DESCRIPTION LIKE '%?%' AND ADDRESS LIKE '%?%' AND STAR <= ? ";
      String selectStatement =
	    "select RESTAURANT_ID " +
	    "from RESTAURANT where RESTAURANT_NAME LIKE ? AND DESCRIPTION LIKE ? AND ADDRESS LIKE ? AND STAR <= ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);
      prepStmt.setString(1, "%" + name + "%");
      prepStmt.setString(2, "%" + description + "%");
      prepStmt.setString(3, "%" + address + "%");
      prepStmt.setInt(4, star);
      System.out.println("SQL in selectByNameDescriptionAddressStar : " + prepStmt.toString());
      ResultSet rs = prepStmt.executeQuery();

      ArrayList a = new ArrayList();

      while (rs.next()) {
	 String id = rs.getString(1);
	 a.add(id);
      }

      prepStmt.close();
      return a;
   }

   private void loadRow() throws SQLException {

      String selectStatement =
	    "select RESTAURANT_NAME, DESCRIPTION, TOTAL_SEAT, ADDRESS, STAR, TELEPHONE_NO " +
	    "from RESTAURANT where RESTAURANT_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);

      prepStmt.setString(1, this.restaurantID);

      ResultSet rs = prepStmt.executeQuery();

      if (rs.next()) {
	 this.restaurantName = rs.getString(1);
	 this.description = rs.getString(2);
	 this.totalSeat = rs.getInt(3);
	 this.address = rs.getString(4);
	 this.star = rs.getInt(5);
	 this.telephoneNo = rs.getString(6);
	 prepStmt.close();
      }
      else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + restaurantID +
	    " not found in database.");
      }
   }

   private void storeRow() throws SQLException {

      String updateStatement =
	    "update RESTAURANT set " +
	    "RESTAURANT_NAME =  ? ," +
	    "DESCRIPTION = ? ," +
	    "TOTAL_SEAT = ? ," +
	    "ADDRESS = ? ," +
	    "STAR = ? ," +
	    "TELEPHONE_NO = ? " +
	    "where RESTAURANT_ID = ?";
      PreparedStatement prepStmt =
	    con.prepareStatement(updateStatement);

      prepStmt.setString(1, restaurantName);
      prepStmt.setString(2, description);
      prepStmt.setInt(3, totalSeat);
      prepStmt.setString(4, address);
      prepStmt.setInt(5, star);
      prepStmt.setString(6, telephoneNo);

      prepStmt.setString(7, restaurantID);

      int rowCount = prepStmt.executeUpdate();
      prepStmt.close();

      if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + restaurantID + " failed.");
      }
   }
  public void setTelephoneNo(String newTelephoneNo) {
    telephoneNo = newTelephoneNo;
  }
  public String getTelephoneNo() {
    return telephoneNo;
  }

}