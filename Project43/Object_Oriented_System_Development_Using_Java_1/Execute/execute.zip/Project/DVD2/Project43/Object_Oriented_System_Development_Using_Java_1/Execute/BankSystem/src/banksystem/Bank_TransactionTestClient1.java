package banksystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.sql.Timestamp;
import java.util.Collection;

public class Bank_TransactionTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private Bank_TransactionHome bank_TransactionHome = null;
  private Bank_TransactionRemote bank_TransactionRemote = null;

  /**Construct the EJB test client*/
  public Bank_TransactionTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("banksystem/Bank_Transaction");

	  //cast to Home interface
	  bank_TransactionHome = (Bank_TransactionHome) PortableRemoteObject.narrow(ref, Bank_TransactionHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public Bank_TransactionRemote create(String transactionID, String accountID, String relateAccountID, int transactionType, double money, Timestamp txDate) {
	long startTime = 0;
	if (logging) {
	  log("Calling create(" + transactionID + ", " + accountID + ", " + relateAccountID + ", " + transactionType + ", " + money + ", " + txDate + ")");
	  startTime = System.currentTimeMillis();
	}
	try {
	  bank_TransactionRemote = bank_TransactionHome.create(transactionID, accountID, relateAccountID, transactionType, money, txDate);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create(" + transactionID + ", " + accountID + ", " + relateAccountID + ", " + transactionType + ", " + money + ", " + txDate + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create(" + transactionID + ", " + accountID + ", " + relateAccountID + ", " + transactionType + ", " + money + ", " + txDate + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(" + transactionID + ", " + accountID + ", " + relateAccountID + ", " + transactionType + ", " + money + ", " + txDate + "): " + bank_TransactionRemote + ".");
	}
	return bank_TransactionRemote;
  }

  public Bank_TransactionRemote findByPrimaryKey(String primKey) {
	long startTime = 0;
	if (logging) {
	  log("Calling findByPrimaryKey(" + primKey + ")");
	  startTime = System.currentTimeMillis();
	}
	try {
	  bank_TransactionRemote = bank_TransactionHome.findByPrimaryKey(primKey);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findByPrimaryKey(" + primKey + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findByPrimaryKey(" + primKey + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findByPrimaryKey(" + primKey + "): " + bank_TransactionRemote + ".");
	}
	return bank_TransactionRemote;
  }

  public Collection findByAccountID(String accountID) {
	Collection returnValue = null;
	long startTime = 0;
	if (logging) {
	  log("Calling findByAccountID(" + accountID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionHome.findByAccountID(accountID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findByAccountID(" + accountID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findByAccountID(" + accountID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findByAccountID(" + accountID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public Timestamp getTxDate() {
	Timestamp returnValue = null;
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in getTxDate(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getTxDate()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionRemote.getTxDate();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getTxDate()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getTxDate()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getTxDate(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setTxDate(Timestamp newTxDate) {
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in setTxDate(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setTxDate(" + newTxDate + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  bank_TransactionRemote.setTxDate(newTxDate);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setTxDate(" + newTxDate + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setTxDate(" + newTxDate + ")");
	  }
	  e.printStackTrace();
	}
  }

  public double getMoney() {
	double returnValue = 0f;
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in getMoney(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getMoney()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionRemote.getMoney();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getMoney()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getMoney()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getMoney(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setMoney(double newMoney) {
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in setMoney(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setMoney(" + newMoney + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  bank_TransactionRemote.setMoney(newMoney);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setMoney(" + newMoney + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setMoney(" + newMoney + ")");
	  }
	  e.printStackTrace();
	}
  }

  public int getTransactionType() {
	int returnValue = 0;
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in getTransactionType(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getTransactionType()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionRemote.getTransactionType();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getTransactionType()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getTransactionType()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getTransactionType(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setTransactionType(int newTransactionType) {
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in setTransactionType(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setTransactionType(" + newTransactionType + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  bank_TransactionRemote.setTransactionType(newTransactionType);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setTransactionType(" + newTransactionType + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setTransactionType(" + newTransactionType + ")");
	  }
	  e.printStackTrace();
	}
  }

  public String getRelateAccountID() {
	String returnValue = "";
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in getRelateAccountID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getRelateAccountID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionRemote.getRelateAccountID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getRelateAccountID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getRelateAccountID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getRelateAccountID(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setRelateAccountID(String newRalateAccountID) {
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in setRelateAccountID(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setRelateAccountID(" + newRalateAccountID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  bank_TransactionRemote.setRelateAccountID(newRalateAccountID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setRelateAccountID(" + newRalateAccountID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setRelateAccountID(" + newRalateAccountID + ")");
	  }
	  e.printStackTrace();
	}
  }

  public String getAccountID() {
	String returnValue = "";
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in getAccountID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getAccountID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionRemote.getAccountID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getAccountID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getAccountID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getAccountID(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setAccountID(String newAccountID) {
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in setAccountID(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setAccountID(" + newAccountID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  bank_TransactionRemote.setAccountID(newAccountID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setAccountID(" + newAccountID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setAccountID(" + newAccountID + ")");
	  }
	  e.printStackTrace();
	}
  }

  public String getTransactionID() {
	String returnValue = "";
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in getTransactionID(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling getTransactionID()");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = bank_TransactionRemote.getTransactionID();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: getTransactionID()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: getTransactionID()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from getTransactionID(): " + returnValue + ".");
	}
	return returnValue;
  }

  public void setTransactionID(String newTransactionID) {
	if (bank_TransactionRemote == null) {
	  System.out.println("Error in setTransactionID(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling setTransactionID(" + newTransactionID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  bank_TransactionRemote.setTransactionID(newTransactionID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: setTransactionID(" + newTransactionID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: setTransactionID(" + newTransactionID + ")");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	Bank_TransactionTestClient1 client = new Bank_TransactionTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.
	java.sql.Timestamp date = java.sql.Timestamp.valueOf("2001-04-30 10:30:30.000000000");
	client.create("abcdefg","MON583","NOTE486",1,999,date);
	client.findByAccountID("MON583");

  }
}