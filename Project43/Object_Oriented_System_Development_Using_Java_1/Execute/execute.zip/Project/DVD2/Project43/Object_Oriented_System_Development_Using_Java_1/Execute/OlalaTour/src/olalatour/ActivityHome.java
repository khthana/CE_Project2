package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface ActivityHome extends EJBHome {
    public ActivityRemote create(String activityId, String activityName, String activityDetail) throws RemoteException, CreateException;
    public ActivityRemote create(String activityId) throws RemoteException, CreateException;
    public ActivityRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
    public Collection findByActivityNameDetail(String activityName, String detail) throws RemoteException, FinderException;
}