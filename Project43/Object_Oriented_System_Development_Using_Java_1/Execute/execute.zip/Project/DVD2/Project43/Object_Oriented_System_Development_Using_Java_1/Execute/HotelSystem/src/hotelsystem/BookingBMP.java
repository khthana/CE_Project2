package hotelsystem;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class BookingBMP extends Booking {
	DataSource dataSource;
	public String ejbCreate(String bookingId, Timestamp bookingTime, Integer confirm, Double price, String transactionId, String customerId) throws CreateException {
	System.out.println("begin ejbCreate..");
	super.ejbCreate(bookingId, bookingTime, confirm, price, transactionId, customerId);
	try {
		//First see if the object already exists
		ejbFindByPrimaryKey(bookingId);
		//If so, then we have to throw an exception
		throw new DuplicateKeyException("Primary key already exists");
	}
	catch(FinderException e) {
		//Otherwise we can go ahead and create it...
	}
	System.out.println("Primary key's not already exists");
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("INSERT INTO BOOKING (BOOKING_ID, BOOKING_TIME, CONFIRM, PRICE, TRANSACTION_ID, CUSTOMER_ID) VALUES (?, ?, ?, ?, ?, ?)");
		System.out.println("prepareStatement");
		statement.setString(1, bookingId);
		statement.setTimestamp(2, bookingTime);
		statement.setInt(3, confirm.intValue());
		statement.setDouble(4, price.doubleValue());
		statement.setString(5, transactionId);
		statement.setString(6, customerId);
		if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
		}
		System.out.println("executeUpdate");
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		System.out.println("end ejbCreate");
		return bookingId;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL INSERT INTO BOOKING (BOOKING_ID, BOOKING_TIME, CONFIRM, PRICE, TRANSACTION_ID, CUSTOMER_ID) VALUES (?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void ejbPostCreate(String bookingId, Timestamp bookingTime, Integer confirm, Double price, String transactionId, String customerId) throws CreateException {
	}
	public String ejbCreate(String bookingId) throws CreateException {
	return ejbCreate(bookingId, null, null, null, null, null);
	}
	public void ejbPostCreate(String bookingId) throws CreateException {
	ejbPostCreate(bookingId, null, null, null, null, null);
	}
	public String ejbCreate(String bookingId, String customerId) throws CreateException {
	System.out.println("create in BookingBMP");
	return ejbCreate(bookingId, new Timestamp(System.currentTimeMillis()), new Integer(0), new Double(0), null, customerId);
	}
	public void ejbPostCreate(String bookingId, String customerId) throws CreateException {
	ejbPostCreate(bookingId, null, null, null, null, customerId);
	}
	public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("DELETE FROM BOOKING WHERE BOOKING_ID = ?");
		statement.setString(1, bookingId);
		if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL DELETE FROM BOOKING WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void ejbLoad() {
	bookingId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOKING_TIME, CONFIRM, PRICE, TRANSACTION_ID, CUSTOMER_ID FROM BOOKING WHERE BOOKING_ID = ?");
		statement.setString(1, bookingId);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
		}
		bookingTime = resultSet.getTimestamp(1);
		confirm = new Integer(resultSet.getInt(2));
		price = new Double(resultSet.getDouble(3));
		transactionId = resultSet.getString(4);
		customerId = resultSet.getString(5);
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOKING_TIME, CONFIRM, PRICE, TRANSACTION_ID, CUSTOMER_ID FROM BOOKING WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	super.ejbLoad();
	}
	public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("UPDATE BOOKING SET BOOKING_TIME = ?, CONFIRM = ?, PRICE = ?, TRANSACTION_ID = ?, CUSTOMER_ID = ? WHERE BOOKING_ID = ?");
		statement.setTimestamp(1, bookingTime);
		statement.setInt(2, confirm.intValue());
		statement.setDouble(3, price.doubleValue());
		statement.setString(4, transactionId);
		statement.setString(5, customerId);
		statement.setString(6, bookingId);
		if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL UPDATE BOOKING SET BOOKING_TIME = ?, CONFIRM = ?, PRICE = ?, TRANSACTION_ID = ?, CUSTOMER_ID = ? WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public String ejbFindByPrimaryKey(String key) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOKING_ID FROM BOOKING WHERE BOOKING_ID = ?");
		statement.setString(1, key);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return key;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOKING_ID FROM BOOKING WHERE BOOKING_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindAll() throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOKING_ID FROM BOOKING");
		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		String bookingId = resultSet.getString(1);
		keys.addElement(bookingId);
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOKING_ID FROM BOOKING: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
		javax.naming.Context context = new javax.naming.InitialContext();
		dataSource = (DataSource) context.lookup("java:comp/env/jdbc/HotelDB");
	}
	catch(Exception e) {
		throw new EJBException("Error looking up dataSource:" + e.toString());
	}
	}
}