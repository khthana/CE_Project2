ArrayList searchRecs = client.SearchSeat("MCHT","RNST",2,"17/4/2001",0,0,0);
     System.out.println("*********** 100 **********");

      ListIterator iterator = searchRecs.listIterator(0);
         while (iterator.hasNext()) {
         SearchRec item = (SearchRec)iterator.next();

         System.out.println(item.getCompanyName() + " " +
                            item.getClassName() + " " +
                            item.getDepartTime() + " " +
                            item.getArriveTime() + " " +
                            item.getRouteID() + " " +
                            item.getSrcIndex() + " " +
                            item.getPrice() );
			}