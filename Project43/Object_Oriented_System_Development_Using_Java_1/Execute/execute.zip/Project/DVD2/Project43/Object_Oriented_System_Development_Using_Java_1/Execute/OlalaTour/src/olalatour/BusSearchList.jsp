<%@ page import="java.sql.Timestamp" %>
<html>
<head>
<jsp:useBean id="viewerBean" scope="page" class="olalatour.ViewerBean" />
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
//-->
</script>
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<table width="750" border="1">
      <tr>
	<td colspan="5"><b><font size="4">result of bus search</font></b></td>
      </tr>
      <tr>
	<td colspan="5">
    <%

    String submit = request.getParameter("submit");
    out.print(submit);
    if (submit != null) {
	if (submit.equals("bus")) {
	    out.println("bus");
	    String strCustomerID = request.getParameter("CustomerID");
	    String strRouteID = request.getParameter("RouteID");
	    String strSrcIdx = request.getParameter("SrcIdx");
	    String strDstIdx = request.getParameter("DstIdx");
	    String strSeatType = request.getParameter("SeatType");
	    String strDepartDay = request.getParameter("DepartDay");
	    String strDepartMonth = request.getParameter("DepartMonth");
	    String strDepartYear = request.getParameter("DepartYear");
	    String strDepartHour = request.getParameter("DepartHour");
	    String strDepartMinute = request.getParameter("DepartMinute");
	    String strPrice = request.getParameter("Price");

	    out.print("getParameter");

	    if ((strCustomerID != null) && (strRouteID != null) && (strSrcIdx != null) && (strDstIdx != null)
		&& (strSeatType != null) && (strDepartDay != null) && (strDepartMonth != null)
		&& (strDepartYear != null) && (strDepartHour != null) && (strDepartMinute != null)
		&& (strPrice != null)) {

		int routeID = Integer.parseInt(strRouteID);
		int srcIdx = Integer.parseInt(strSrcIdx);
		int dstIdx = Integer.parseInt(strDstIdx);
		int seatType = Integer.parseInt(strSeatType);
		java.sql.Timestamp departTime = java.sql.Timestamp.valueOf(strDepartYear + "-" + strDepartMonth + "-" + strDepartDay + " " + strDepartHour + ":" + strDepartMinute + ":" + "00" + "." + "00000000");

		double price = Double.parseDouble(strPrice);

		out.print("call addBusItem");
		controllerBean.addBusItem(strCustomerID, null, null, null, null, routeID, srcIdx, dstIdx, seatType, departTime, price);
	    }
	}
    }




	String strNumberOfTraveller = request.getParameter("NumberOfTraveller");
	String strFromPlace = request.getParameter("FromPlace");
	String strToPlace = request.getParameter("ToPlace");
	String strSelectDay = request.getParameter("selectDay");
	String strSelectMonth = request.getParameter("selectMonth");
	String strSelectYear = request.getParameter("selectYear");
	String strBusCompany = request.getParameter("selectBusCompany");
	String strBusType = request.getParameter("selectBusType");
	String strSeatPosition = request.getParameter("selectSeatPosition");
    %>
    <%viewerBean.searchBusSeat(strFromPlace, strToPlace, Integer.parseInt(strNumberOfTraveller), Integer.parseInt(strSelectDay), Integer.parseInt(strSelectMonth), Integer.parseInt(strSelectYear), Integer.parseInt(strBusCompany), Integer.parseInt(strBusType), Integer.parseInt(strSeatPosition));%>
    <%while (viewerBean.nextBusSeat()) {%>
	  <table width="100%" border="1">
	    <tr>
	      <td width="20%" rowspan="5">
		    <div align="center"> <a href="BusSearchList.jsp?<%=request.getQueryString()%>&CustomerID=&RouteID=<%=viewerBean.getRouteID()%>&SrcIdx=<%=viewerBean.getSrcIdx()%>&DstIdx=<%=viewerBean.getDstIdx()%>&SeatType=<%=strSeatPosition%>&DepartDay=<%=viewerBean.getDepartTime().getDate()%>&DepartMonth=<%=viewerBean.getDepartTime().getMonth()%>&DepartYear=<%=viewerBean.getDepartTime().getYear()%>&DepartHour=<%=viewerBean.getDepartTime().getHours()%>&DepartMinute=<%=viewerBean.getDepartTime().getMinutes()%>&Price=<%=viewerBean.getPrice()%>&submit=bus"><img src="images/LogoBusList.jpg" width="55" height="55"><br>
	      AddToCart</a> </div>
	      </td>
	      <td width="80%"> <b>Route:</b> <%=viewerBean.getRouteID()%> company : <%=viewerBean.getCompanyName()%> </td>
	    </tr>
	    <tr>
	      <td width="80%"> <b>From:</b> <%=strFromPlace%> departtime : <%=viewerBean.getDepartTime()%></td>
	    </tr>
	    <tr>
	      <td width="80%"> <b>To:</b> <%=strToPlace%> arrivetime : <%=viewerBean.getArriveTime()%></td>
	    </tr>
	    <tr>
	      <td width="80%">class : <%=viewerBean.getClassName()%></td>
	    </tr>
	    <tr>
	      <td width="80%"><b>Price/Seat : </b><%=viewerBean.getPrice()%></td>
	    </tr>
	  </table>
	<%}%>
	</td>
      </tr>
    </table>

</body>
</html>
