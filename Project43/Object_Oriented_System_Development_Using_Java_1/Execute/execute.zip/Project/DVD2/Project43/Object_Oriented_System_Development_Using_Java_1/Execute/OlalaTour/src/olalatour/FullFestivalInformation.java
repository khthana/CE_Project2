package olalatour;

import java.io.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullFestivalInformation implements Serializable {

    public FullFestivalInformation(String festivalID, String festivalName, String description, Collection places) {
	this.festivalID = festivalID;
	this.festivalName = festivalName;
	this.description = description;
	this.places = places;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getFestivalID() {
	return festivalID;
    }
    public String getFestivalName() {
	return festivalName;
    }
    public String getDescription() {
	return description;
    }
    public java.util.Collection getPlaces() {
	return places;
    }
    private String festivalID;
    private String festivalName;
    private String description;
    private java.util.Collection places;
}