package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface AgencyRemote extends EJBObject {
  public java.lang.String getTelephoneNo() throws RemoteException;
  public void setTelephoneNo(java.lang.String newTelephoneNo) throws RemoteException;
  public java.lang.String getAddress() throws RemoteException;
  public void setAddress(java.lang.String newAddress) throws RemoteException;
  public java.lang.String getAgencyID() throws RemoteException;
  public java.lang.String getAgencyName() throws RemoteException;
  public void setAgencyName(java.lang.String newAgencyName) throws RemoteException;
}