Public Function SearchCompany(ByVal Keyword As String, _
                                                                  ByRef strResult As String) _
                                                                  As ADODB.Recordset
On Error GoTo Oops:
    Dim strCommand As String
    Dim rsResult As ADODB.Recordset
    
    Set rsResult = New ADODB.Recordset
    strCommand = "SELECT    CompanyID, CompanyName " & _
                                 "FROM         BusCompany "
    
    If Keyword <> "" Then
        strCommand = strCommand & "WHERE Description LIKE '%" & Keyword & "%'"
    End If
    
    If oSql.SqlExecute(strCommand, rsResult) Then
        If rsResult.EOF And rsResult.BOF Then
            strResult = "Not Found"
        Else
            Set SearchCompany = rsResult
            strResult = "Found"
        End If
    Else
        strResult = "[BusService.dll,BusService.ISearch,SearchCompany]Can not search company." & vbCrLf & _
                             "Command : " " " & strCommand & """"
        oContext.SetAbort
    End If
    Exit Function

Oops:
    strResult = "[BusService.dll,BusService.ISearch,SearchCompany]" & Err.Description
    oContext.SetAbort
End Function