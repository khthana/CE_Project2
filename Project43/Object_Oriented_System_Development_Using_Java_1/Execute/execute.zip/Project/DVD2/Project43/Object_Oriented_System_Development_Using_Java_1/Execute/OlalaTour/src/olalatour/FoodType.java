package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FoodType implements EntityBean {
    EntityContext entityContext;
    public String foodTypeId;
    public String foodTypeName;
    public String foodTypeDetail;
    public String ejbCreate(String foodTypeId, String foodTypeName, String foodTypeDetail) throws CreateException {
	this.foodTypeId = foodTypeId;
	this.foodTypeName = foodTypeName;
	this.foodTypeDetail = foodTypeDetail;
	return null;
    }
    public String ejbCreate(String foodTypeId) throws CreateException {
	return ejbCreate(foodTypeId, null, null);
    }
    public void ejbPostCreate(String foodTypeId, String foodTypeName, String foodTypeDetail) throws CreateException {
    }
    public void ejbPostCreate(String foodTypeId) throws CreateException {
	ejbPostCreate(foodTypeId, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getFoodTypeId() {
	return foodTypeId;
    }
    public String getFoodTypeName() {
	return foodTypeName;
    }
    public void setFoodTypeName(String foodTypeName) {
	this.foodTypeName = foodTypeName;
    }
    public String getFoodTypeDetail() {
	return foodTypeDetail;
    }
    public void setFoodTypeDetail(String foodTypeDetail) {
	this.foodTypeDetail = foodTypeDetail;
    }
}