package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.sql.*;
import javax.sql.DataSource;

public class HotelController implements SessionBean {
  private SessionContext sessionContext;
  public void ejbCreate() {
  }
  public void ejbRemove() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext context) {
	sessionContext = context;
  }
  public Collection findHotel(String name, String description, String address, int star) {
	System.out.println("findHotel");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("hotelsystem/Hotel");
	  System.out.println("lookup");

	  HotelHome home = (HotelHome)PortableRemoteObject.narrow(objref, HotelHome.class);
	  System.out.println("narrow");

	  Collection hotels = home.findByNameDescriptionAddressStar(name, description, address, star);
	  ArrayList result = new ArrayList();

	  Iterator i = hotels.iterator();

	  while (i.hasNext()) {
		HotelRemote hotel = (HotelRemote)i.next();
		result.add(new ShortHotelInformation(hotel.getHotelID(), hotel.getHotelName(), hotel.getLogo(), hotel.getNoOfRooms(), hotel.getStar()));
	  }
	  System.out.println("end findHotel");
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of ShortHotelInformation
  public Collection findRoom(String hotelID) {
	try {
	  System.out.println("makeConnection");
	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup("java:comp/env/jdbc/HotelDB");
	  Connection con =  ds.getConnection();
	  System.out.println("end makeConnection");


	  System.out.println("findRoom in HotelController");
	  String selectStatement =
		"select distinct PRICE_PER_DAY, DESCRIPTION, NUMBER_OF_SINGLE_BED, NUMBER_OF_COUPLE_BED, NUMBER_OF_MAXIMUM_GUEST, ROOM_CLASS " +
		"from ROOM where HOTEL_ID = ? ";
	  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
	  System.out.println("prepareStatement");
	  prepStmt.setString(1, hotelID);
	  ResultSet rs = prepStmt.executeQuery();
	  System.out.println("executeQuery");

	  ArrayList a = new ArrayList();

	  while (rs.next()) {
		  double _pricePerDay = rs.getDouble(1);
		  String _description = rs.getString(2);
		  int _numberOfSingleBed = rs.getInt(3);
		  int _numberOfCoupleBed = rs.getInt(4);
		  int _numberOfMaximumGuest = rs.getInt(5);
		  int _roomClass = rs.getInt(6);
		  a.add(new FullRoomInformation(_pricePerDay, _description, _numberOfSingleBed, _numberOfCoupleBed, _numberOfMaximumGuest, _roomClass));
	  }

	  prepStmt.close();
	  System.out.println("end findRoom in HotelController");
	  return a;
	}
	catch (Exception ex) {
	throw new EJBException(ex.getMessage());
	}
  }
  // return Collection of FullRoomInformation
  public FullHotelInformation viewHotel(String hotelID) {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("hotelsystem/Hotel");

	  HotelHome home = (HotelHome)PortableRemoteObject.narrow(objref, HotelHome.class);
	  HotelRemote hotel = home.findByPrimaryKey(hotelID);

	  return new FullHotelInformation(hotel.getHotelID(), hotel.getHotelName(), hotel.getDescription(), hotel.getAddress(), hotel.getTelephoneNo(), hotel.getAccountId());
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public Collection viewBooking(String bookingID) {
//	try {
//	  Context initial = new InitialContext();
//	  Object objref = initial.lookup("hotelsystem/Booking");
//
//	  BookingHome home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
//	  BookingRemote booking = home.findByPrimaryKey(bookingID);
//
//	  Collection subbookings = booking.getSubbookings();
//	  ArrayList result = new ArrayList();
//
//	  Iterator i = subbookings.iterator();
//
//	  while (i.hasNext()) {
//	    SubbookingRemote subbooking = (SubbookingRemote)i.next();
//	    result.add(new ReserveHotelInformation(subbooking.getBookCheckInTime(), subbooking.getBookCheckOutTime(), subbooking.getRoomNo(), subbooking.getHotelID(), subbooking.geCustomerID()));
//	  }
//	  return result;
//	}
//	catch (Exception ex) {
//	  throw new EJBException(ex.getMessage());
//	}
	return null;
  }
  // return Collection of ReserveHotelInformation
  public ReserveResult reserve(String customerID, Collection reserveHotelInformations) throws InvalidBookingTimeException, InvalidHotelException, InvalidCustomerException, RoomNotAvailableException {
	Context initial = null;
	Object objref = null;
	BookingHome bookingHome = null;
	BookingRemote bookingRemote = null;
	SubbookingHome subbookingHome = null;
	SubbookingRemote subbookingRemote = null;
	RoomHome roomHome = null;
	RoomRemote roomRemote = null;
	double price = 0;

	String bookingID = null;

	try {
	  initial = new InitialContext();
	  objref = initial.lookup("hotelsystem/Booking");
	  bookingHome = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	  objref = initial.lookup("hotelsystem/Subbooking");
	  subbookingHome = (SubbookingHome)PortableRemoteObject.narrow(objref, SubbookingHome.class);
	  objref = initial.lookup("hotelsystem/Room");
	  roomHome = (RoomHome)PortableRemoteObject.narrow(objref, RoomHome.class);
	  System.out.println("all lookup");
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}
	bookingID = getNewBookingID();
	System.out.println(bookingID);

	try {
	  System.out.println("before create booking");
	  bookingRemote = bookingHome.create(bookingID, customerID);
	  System.out.println("after create booking");

	  Iterator i = reserveHotelInformations.iterator();

	  while (i.hasNext()) {
		ReserveHotelInformation reserveHotelInformation = (ReserveHotelInformation)i.next();

		Collection rooms = roomHome.findByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass(reserveHotelInformation.getHotelID(), reserveHotelInformation.getPricePerDay(), reserveHotelInformation.getDescription(), reserveHotelInformation.getNumberOfSingleBed(), reserveHotelInformation.getNumberOfCoupleBed(), reserveHotelInformation.getRoomClass());
		System.out.println("has called findByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass return : " + rooms.size());
		Iterator roomsIterator = rooms.iterator();

		int numberOfRoom = reserveHotelInformation.getNumberOfRoom();
		int bookedRoom = 0;

		while (bookedRoom < numberOfRoom) {
		  if (!roomsIterator.hasNext()) {
			  throw new RoomNotAvailableException();
		  }
		  System.out.println("bookedRoom = " + bookedRoom);
		  RoomRemote room = (RoomRemote)roomsIterator.next();
		  price += room.getPricePerDay();
		  try {
			  System.out.println("before create Subbooking");
			  subbookingRemote = subbookingHome.create(reserveHotelInformation.getBookCheckInTime(), reserveHotelInformation.getBookCheckOutTime(), room.getRoomNo(), reserveHotelInformation.getHotelID(), bookingID);
			  System.out.println("after create Subbooking");
		  }
		  catch (Exception ex) {
			  continue;
		  }
			bookedRoom++;
		  }
	  }
	  bookingRemote.setPrice(new Double(price));
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (CreateException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (FinderException ex) {
	  throw new EJBException(ex.getMessage());
	}
	return new ReserveResult(bookingID, price);
  }
  // return bookingID, recieve Collection of ReserveHotelInformation
  public void confirm(String bookingID) throws AlreadyCancelException, DuplicateTransactionIDException, InvalidTransactionIDException {
	Context initial = null;
	Object objref = null;
	BookingHome home = null;
	BookingRemote booking = null;
	try {
	  initial = new InitialContext();
	  objref = initial.lookup("hotelsystem/Booking");
	  home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	  booking = home.findByPrimaryKey(bookingID);
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	try {
	  booking.confirm();
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public void cancel(String bookingID) throws AlreadyConfirmException {
	Context initial = null;
	Object objref = null;
	BookingHome home = null;
	BookingRemote booking = null;
	try {
	  initial = new InitialContext();
	  objref = initial.lookup("hotelsystem/Booking");
	  home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	  booking = home.findByPrimaryKey(bookingID);
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	try {
	  booking.cancel();
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public void modify(String bookingID, Collection reserveHotelInformations) throws InvalidBookingTimeException, InvalidRoomException, InvalidHotelException, InvalidCustomerException {
//	Context initial = null;
//	Object objref = null;
//	BookingHome bookingHome = null;
//	BookingRemote bookingRemote = null;
//	SubbookingHome subbookingHome = null;
//	SubbookingRemote subbookingRemote = null;
//
//	try {
//	  initial = new InitialContext();
//	  objref = initial.lookup("hotelsystem/Booking");
//	  bookingHome = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
//	  objref = initial.lookup("hotelsystem/Subbooking");
//	  subbookingHome = (SubbookingHome)PortableRemoteObject.narrow(objref, SubbookingHome.class);
//	}
//	catch (NamingException ex) {
//	  throw new EJBException(ex.getMessage());
//	}
//
//	try {
//	  bookingRemote = bookingHome.findByPrimaryKey(bookingID);
//	  Collection oldSubbookings = bookingRemote.getSubbookings();
//	  Iterator oldIterator = oldSubbookings.iterator();
//
//	  while (oldIterator.hasNext()) {
//	    SubbookingRemote oldSubbooking = (SubbookingRemote)oldIterator.next();
//	    oldSubbooking.remove();
//	  }
//	  Iterator newIterator = reserveHotelInformations.iterator();
//
//	  while (newIterator.hasNext()) {
//	    /** @todo or call method in Booking */
//	    ReserveHotelInformation reserveHotelInformation = (ReserveHotelInformation)newIterator.next();
//	    subbookingRemote = subbookingHome.create(reserveHotelInformation.getRoomNo(), reserveHotelInformation.getHotelID(), reserveHotelInformation.getCustomerID(), reserveHotelInformation.getBookCheckInTime(), reserveHotelInformation.getBookCheckOutTime(), bookingID);
//	  }
//	}
//	catch (RemoteException ex) {
//	  throw new EJBException(ex.getMessage());
//	}
//	catch (CreateException ex) {
//	  throw new EJBException(ex.getMessage());
//	}
//	catch (FinderException ex) {
//	  throw new EJBException(ex.getMessage());
//	}
//	catch (RemoveException ex) {
//	  throw new EJBException(ex.getMessage());
//	}
  }
  // recieve Collection of ReserveHotelInformation
  public String createCustomer(String firstName, String lastName, String address, String telephoneNo, int gender) throws BlankFieldException, InvalidGenderException {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("hotelsystem/Customer");

	  CustomerHome home = (CustomerHome)PortableRemoteObject.narrow(objref, CustomerHome.class);

	  String customerID = getNewBookingID();

	  home.create(customerID, firstName, lastName, address, telephoneNo, gender);

	  return customerID;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  // return CustomerID
  protected String getNewBookingID() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("hotelsystem/UUIDGenerator");

	  UUIDGeneratorHome home = (UUIDGeneratorHome)PortableRemoteObject.narrow(objref, UUIDGeneratorHome.class);
	  UUIDGeneratorRemote uuidGenerator = home.create();

	  return uuidGenerator.getUUID();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}

  }
}