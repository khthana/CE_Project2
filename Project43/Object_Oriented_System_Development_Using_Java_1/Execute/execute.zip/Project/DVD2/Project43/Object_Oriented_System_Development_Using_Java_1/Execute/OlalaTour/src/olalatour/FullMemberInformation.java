package olalatour;

import java.io.*;
import java.sql.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullMemberInformation implements Serializable {

    public FullMemberInformation(String memberID, String firstName, String lastName, String address, String telephoneNo, String emailAddress, int gender, Date birthDate, String religion, Collection travellers) {
	this.memberID = memberID;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.telephoneNo = telephoneNo;
	this.emailAddress = emailAddress;
	this.gender = gender;
	this.birthDate = birthDate;
	this.religion = religion;
	this.travellers = travellers;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getMemberID() {
	return memberID;
    }
    public String getFirstName() {
	return firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public String getAddress() {
	return address;
    }
    public String getTelephoneNo() {
	return telephoneNo;
    }
    public int getGender() {
	return gender;
    }
    public java.sql.Date getBirthDate() {
	return birthDate;
    }
    public String getReligion() {
	return religion;
    }
    public String getEmailAddress() {
	return emailAddress;
    }
    public java.util.Collection getTravellers() {
	return travellers;
    }
    private String memberID;
    private String firstName;
    private String lastName;
    private String address;
    private String telephoneNo;
    private int gender;
    private java.sql.Date birthDate;
    private String religion;
    private String emailAddress;
    private java.util.Collection travellers;
    // Collection of travellerID
}