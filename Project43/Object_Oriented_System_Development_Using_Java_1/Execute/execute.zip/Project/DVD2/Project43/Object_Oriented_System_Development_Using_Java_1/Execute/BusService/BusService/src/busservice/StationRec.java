package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class StationRec implements java.io.Serializable {
  String PlaceID;
  String PlaceName ;

  public  StationRec(String PlaceID, String PlaceName) {

      this.PlaceID = PlaceID;
      this.PlaceName = PlaceName;
   }

   public String getPlaceID() {
      return PlaceID;
   }

   public String getPlaceName() {
     return PlaceName;
   }

}