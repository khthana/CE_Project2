package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullBookingInformation implements Serializable {

    public FullBookingInformation(java.util.Collection busBookingInformations, java.util.Collection hotelBookingInformations, java.util.Collection airlineBookingInformation, java.util.Collection packageBookingInformation, String memberID) {
	this.busBookingInformations = busBookingInformations;
	this.hotelBookingInformations = hotelBookingInformations;
	this.airlineBookingInformation = airlineBookingInformation;
	this.packageBookingInformation = packageBookingInformation;
	this.memberID = memberID;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public java.util.Collection getBusBookingInformations() {
	return busBookingInformations;
    }
    public java.util.Collection getHotelBookingInformations() {
	return hotelBookingInformations;
    }
    public java.util.Collection getAirlineBookingInformation() {
	return airlineBookingInformation;
    }
    public java.util.Collection getPackageBookingInformation() {
	return packageBookingInformation;
    }
    public String getMemberID() {
	return memberID;
    }
    public void setMemberID(String newMemberID) {
	memberID = newMemberID;
    }
    private java.util.Collection busBookingInformations;
    // Collection of busservice.BookSeatInfo
    private java.util.Collection hotelBookingInformations;
    // Collection of hotelsystem.ReserveHotelInformation
    private java.util.Collection airlineBookingInformation;
    // Collection of airlinesystem.BookSeatInfo
    private java.util.Collection packageBookingInformation;
    // Collection of olalatour.PackageBookingInformation
    private String memberID;

}