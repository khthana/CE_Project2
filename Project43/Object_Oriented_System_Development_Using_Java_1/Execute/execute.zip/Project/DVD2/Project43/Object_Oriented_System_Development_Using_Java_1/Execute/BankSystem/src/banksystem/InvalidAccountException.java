package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidAccountException extends Exception {

   public InvalidAccountException() { }

   public InvalidAccountException(String msg) {
      super(msg);
   }
}