package busservice;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface ModifyControllerRemote extends EJBObject {
public boolean confirmBooking(String BookingID ) throws RemoteException ,ModifyControllerException ;
public boolean CancelBooking( String BookingID) throws  RemoteException ,ModifyControllerException ;
}