package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface SubbookingRemote extends EJBObject {
    Date getBookCheckInTime() throws RemoteException;
    Date getBookCheckOutTime() throws RemoteException;
    void setBookCheckOutTime(Date bookCheckOutTime) throws RemoteException;
    String getRoomNo() throws RemoteException;
    String getHotelId() throws RemoteException;
    String getBookingId() throws RemoteException;
    void setBookingId(String bookingId) throws RemoteException;
}