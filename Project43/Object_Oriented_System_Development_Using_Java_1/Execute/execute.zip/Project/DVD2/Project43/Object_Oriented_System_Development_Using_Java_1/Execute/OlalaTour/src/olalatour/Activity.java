package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Activity implements EntityBean {
    EntityContext entityContext;
    public String activityId;
    public String activityName;
    public String activityDetail;
    public String ejbCreate(String activityId, String activityName, String activityDetail) throws CreateException {
	this.activityId = activityId;
	this.activityName = activityName;
	this.activityDetail = activityDetail;
	return null;
    }
    public String ejbCreate(String activityId) throws CreateException {
	return ejbCreate(activityId, null, null);
    }
    public void ejbPostCreate(String activityId, String activityName, String activityDetail) throws CreateException {
    }
    public void ejbPostCreate(String activityId) throws CreateException {
	ejbPostCreate(activityId, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getActivityId() {
	return activityId;
    }
    public String getActivityName() {
	return activityName;
    }
    public void setActivityName(String activityName) {
	this.activityName = activityName;
    }
    public String getActivityDetail() {
	return activityDetail;
    }
    public void setActivityDetail(String activityDetail) {
	this.activityDetail = activityDetail;
    }
}