package busservice;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface SearchControllerHome extends EJBHome {
  public SearchController create() throws RemoteException, CreateException;
}