package airlinesystem;


import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface UUIDGeneratorRemote extends EJBObject {
  public String getUUID() throws RemoteException;
}