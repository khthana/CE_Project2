package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface HotelHome extends EJBHome {
  public HotelRemote create(String hotelID, String hotelName, String description, String address, int star, String telephoneNo, String accountID, String password, String logo, String hotelPicture) throws RemoteException, CreateException;
  public HotelRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
  public Collection findByNameDescriptionAddressStar(String name, String description, String address, int star) throws RemoteException, FinderException;
}