package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface OlalaAgencyControllerHome extends EJBHome {
	public OlalaAgencyControllerRemote create() throws RemoteException, CreateException;
}