package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface CategoryRemote extends EJBObject {
    String getCategoryId() throws RemoteException;
    String getCategoryName() throws RemoteException;
    void setCategoryName(String categoryName) throws RemoteException;
    String getDescription() throws RemoteException;
    void setDescription(String description) throws RemoteException;
    Collection getPlaces() throws RemoteException;
}