package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Guide implements EntityBean {
    EntityContext entityContext;
    public String guideId;
    public String firstName;
    public String lastName;
    public Integer gender;
    public String spokenLanguage;
    public String officeAddress;
    public String ejbCreate(String guideId, String firstName, String lastName, Integer gender, String spokenLanguage, String officeAddress) throws CreateException {
	this.guideId = guideId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.gender = gender;
	this.spokenLanguage = spokenLanguage;
	this.officeAddress = officeAddress;
	return null;
    }
    public String ejbCreate(String guideId) throws CreateException {
	return ejbCreate(guideId, null, null, null, null, null);
    }
    public void ejbPostCreate(String guideId, String firstName, String lastName, Integer gender, String spokenLanguage, String officeAddress) throws CreateException {
    }
    public void ejbPostCreate(String guideId) throws CreateException {
	ejbPostCreate(guideId, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getGuideId() {
	return guideId;
    }
    public String getFirstName() {
	return firstName;
    }
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }
    public Integer getGender() {
	return gender;
    }
    public void setGender(Integer gender) {
	this.gender = gender;
    }
    public String getSpokenLanguage() {
	return spokenLanguage;
    }
    public void setSpokenLanguage(String spokenLanguage) {
	this.spokenLanguage = spokenLanguage;
    }
    public String getOfficeAddress() {
	return officeAddress;
    }
    public void setOfficeAddress(String officeAddress) {
	this.officeAddress = officeAddress;
    }
}