package busservice;

import java.io.*;
import java.sql.Date;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

 /***** BookSeatResult File to manage this field
   /* With rsBookSeatResult.Fields
        .Append "CustomerID", adVarChar, 50, adFldUpdatable
        .Append "BookingID", adVarChar, 50, adFldUpdatable
        .Append "SeatNo", adVarChar, 10, adFldUpdatable
        .Append "Price", adCurrency, , adFldUpdatable
    End With

  } */
public class BookSeatResult implements java.io.Serializable {

  private String CustomerID;
  private String BookingID;
  private String SeatNo;
  private double Price;



  public BookSeatResult(String CustomerID, String BookingID, String SeatNo,double Price) {

    this.CustomerID = CustomerID;
    this.BookingID= BookingID;
    this.SeatNo= SeatNo;
    this.Price = Price;
  }



  public String getCustomerID() {
    return CustomerID;
  }

  public String getBookingID() {
    return BookingID;
  }

  public String getSeatNo() {
    return SeatNo;
  }

  public double getPrice() {
    return Price;
  }


}

