package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface FestivalHome extends EJBHome {
    public FestivalRemote create(String festivalId, String festivalName, String description) throws RemoteException, CreateException;
    public FestivalRemote create(String festivalId) throws RemoteException, CreateException;
    public FestivalRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
    public Collection findByFestivalNameDetail(String festivalName, String detail) throws RemoteException, FinderException;
}