package hotelsystem;

import java.io.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public class SubbookingPK implements Serializable {

    public Date bookCheckInTime;
    public String roomNo;
    public String hotelId;

    public SubbookingPK() {
    }

    public SubbookingPK(Date bookCheckInTime, String roomNo, String hotelId) {
        this.bookCheckInTime = bookCheckInTime;
        this.roomNo = roomNo;
        this.hotelId = hotelId;
    }
    public boolean equals(Object obj) {
        if (this.getClass().equals(obj.getClass())) {
            SubbookingPK that = (SubbookingPK) obj;
            return this.bookCheckInTime.equals(that.bookCheckInTime) && this.roomNo.equals(that.roomNo) && this.hotelId.equals(that.hotelId);
        }
        return false;
    }
    public int hashCode() {
        return (bookCheckInTime + roomNo + hotelId).hashCode();
    }
}