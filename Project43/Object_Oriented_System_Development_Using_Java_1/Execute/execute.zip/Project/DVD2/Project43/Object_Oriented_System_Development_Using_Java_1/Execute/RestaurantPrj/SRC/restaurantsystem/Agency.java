package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Agency implements EntityBean {
  EntityContext entityContext;
  public String agencyID;
  public String agencyName;
  public String address;
  public String telephoneNo;

  private Connection con;
  private String dbName = "java:comp/env/jdbc/RestaurantDB";


  public String ejbCreate(String agencyID, String agencyName, String address, String telephoneNo) throws CreateException {
      System.out.println("ejbCreate");

      try {
		insertRow(agencyID, agencyName, address, telephoneNo);
      } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
	      ex.getMessage());
      }

      this.agencyID = agencyID;
      this.agencyName = agencyName;
      this.address = address;
      this.telephoneNo = telephoneNo;

      System.out.println("end ejbCreate");

      return agencyID;
  }
  public void ejbPostCreate(String agencyID, String agencyName, String address, String telephoneNo) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
    System.out.println("ejbRomove");
      try {
	 deleteRow(agencyID);
       } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
	      ex.getMessage());
       }
    System.out.println("end ejbRomove");
  }
  public String ejbFindByPrimaryKey(String primKey) throws FinderException {
      System.out.println("ejbFindByPrimaryKey");

      boolean result;

      try {
	 result = selectByPrimaryKey(primKey);
       } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
	      ex.getMessage());
       }
      if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
      }
      else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
	    ("Row for id " + primKey + " not found.");
      }

  }
  public Collection ejbFindByNameAddress(String name, String address) throws RemoteException, FinderException {
      Collection result;

      try {
	 result = selectByNameAddress(name, address);
       } catch (Exception ex) {
	   throw new EJBException("ejbFindByNameAddress " +
	      ex.getMessage());
       }

      if (result.isEmpty()) {
	 throw new ObjectNotFoundException("No rows found.");
      }
      else {
	 return result;
      }
  }

  public void ejbActivate() {
    System.out.println("ejbActivate");
    agencyID = (String)entityContext.getPrimaryKey();
    System.out.println("end ejbActivate");
  }
  public void ejbPassivate() {
    System.out.println("ejbPassivate");
    agencyID = null;
    System.out.println("end ejbPassivate");
  }
  public void ejbLoad() {
    System.out.println("ejbLoad");
      try {
	 loadRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
      System.out.println("end ejbLoad");
  }
  public void ejbStore() {
    System.out.println("ejbLoad");
      try {
	 storeRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
    System.out.println("end ejbLoad");
  }
  public void setEntityContext(EntityContext entityContext) {
    System.out.println("setEntityContext");
    this.entityContext = entityContext;
      try {
	 makeConnection();
      } catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
	     ex.getMessage());
      }
    System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
    System.out.println("unsetEntityContext");
    entityContext = null;
      try {
	 con.close();
      } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
      }
    System.out.println("end unsetEntityContext");
  }
  public String getAgencyID() {
    return agencyID;
  }
  public void setAgencyName(String newAgencyName) {
    agencyName = newAgencyName;
  }
  public String getAgencyName() {
    return agencyName;
  }
  public void setAddress(String newAddress) {
    address = newAddress;
  }
  public String getAddress() {
    return address;
  }
  public void setTelephoneNo(String newTelephoneNo) {
    telephoneNo = newTelephoneNo;
  }
  public String getTelephoneNo() {
    return telephoneNo;
  }
/*********************** Database Routines *************************/

   private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();
   }

   private void insertRow (String agencyID, String agencyName, String address, String telephoneNo) throws SQLException {

	  String insertStatement =
		"insert into AGENCY values ( ? , ? , ? , ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, agencyID);
	  prepStmt.setString(2, agencyName);
	  prepStmt.setString(3, address);
	  prepStmt.setString(4, telephoneNo);

	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String id) throws SQLException {

      String deleteStatement =
	    "delete from AGENCY where AGENCY_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(deleteStatement);

      prepStmt.setString(1, id);
      prepStmt.executeUpdate();
      prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
      throws SQLException {
      String selectStatement =
	    "select AGENCY_ID " +
	    "from AGENCY where AGENCY_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);
      prepStmt.setString(1, primaryKey);

      ResultSet rs = prepStmt.executeQuery();
      boolean result = rs.next();
      prepStmt.close();
      return result;
   }


   private Collection selectByNameAddress(String name, String address)
      throws SQLException {

      String selectStatement =
	    "select AGENCY_ID " +
	    "from AGENCY where AGENCY_NAME = '%?%' AND ADDRSS = '%?%' ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);

      prepStmt.setString(1, name);
      prepStmt.setString(2, address);

      ResultSet rs = prepStmt.executeQuery();
      ArrayList a = new ArrayList();

      while (rs.next()) {
	 String id = rs.getString(1);
	 a.add(id);
      }

      prepStmt.close();
      return a;
   }

   private void loadRow() throws SQLException {

      String selectStatement =
	    "select AGENCY_NAME, ADDRESS, TELEPHONE_NO " +
	    "from RESTAURANT where RESTAURANT_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);

      prepStmt.setString(1, this.agencyID);

      ResultSet rs = prepStmt.executeQuery();

      if (rs.next()) {
	 this.agencyName = rs.getString(1);
	 this.address = rs.getString(2);
	 this.telephoneNo = rs.getString(3);
	 prepStmt.close();
      }
      else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + agencyID +
	    " not found in database.");
      }
   }


   private void storeRow() throws SQLException {

      String updateStatement =
	    "update AGENCY set " +
	    "AGENCY_NAME =  ? ," +
	    "ADDRESS = ? ," +
	    "TELEPHONE_NO = ? " +
	    "where AGENCY_ID = ?";
      PreparedStatement prepStmt =
	    con.prepareStatement(updateStatement);

      prepStmt.setString(1, agencyName);
      prepStmt.setString(2, address);
      prepStmt.setString(3, telephoneNo);

      prepStmt.setString(4, agencyID);

      int rowCount = prepStmt.executeUpdate();
      prepStmt.close();

      if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + agencyID + " failed.");
      }
   }

}