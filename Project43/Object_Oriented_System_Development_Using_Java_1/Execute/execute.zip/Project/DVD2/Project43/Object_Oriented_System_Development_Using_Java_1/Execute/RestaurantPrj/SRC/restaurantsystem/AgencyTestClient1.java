package restaurantsystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;



/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class AgencyTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private AgencyHome agencyHome = null;
  private AgencyRemote agencyRemote = null;

  /**Construct the EJB test client*/
  public AgencyTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = new InitialContext();

      //look up jndi name
      Object ref = ctx.lookup("Agency");

      //cast to Home interface
      agencyHome = (AgencyHome) PortableRemoteObject.narrow(ref, AgencyHome.class);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded initializing bean access.");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public AgencyRemote create(String agencyID, String name, String address, String telephoneNo) {
    long startTime = 0;
    if (logging) {
      log("Calling create(" + agencyID + ", " + name + ", " + address + ", " + telephoneNo + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      agencyRemote = agencyHome.create(agencyID, name, address, telephoneNo);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: create(" + agencyID + ", " + name + ", " + address + ", " + telephoneNo + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: create(" + agencyID + ", " + name + ", " + address + ", " + telephoneNo + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(" + agencyID + ", " + name + ", " + address + ", " + telephoneNo + "): " + agencyRemote + ".");
    }
    return agencyRemote;
  }

  public AgencyRemote findByPrimaryKey(String primKey) {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + primKey + ")");
      startTime = System.currentTimeMillis();
    }
    try {
      agencyRemote = agencyHome.findByPrimaryKey(primKey);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: findByPrimaryKey(" + primKey + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: findByPrimaryKey(" + primKey + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + primKey + "): " + agencyRemote + ".");
    }
    return agencyRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String getTelephoneNo() {
    String returnValue = "";
    if (agencyRemote == null) {
      System.out.println("Error in getTelephoneNo(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getTelephoneNo()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = agencyRemote.getTelephoneNo();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getTelephoneNo()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getTelephoneNo()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getTelephoneNo(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setTelephoneNo(String newTelephoneNo) {
    if (agencyRemote == null) {
      System.out.println("Error in setTelephoneNo(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setTelephoneNo(" + newTelephoneNo + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      agencyRemote.setTelephoneNo(newTelephoneNo);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setTelephoneNo(" + newTelephoneNo + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setTelephoneNo(" + newTelephoneNo + ")");
      }
      e.printStackTrace();
    }
  }

  public String getAddress() {
    String returnValue = "";
    if (agencyRemote == null) {
      System.out.println("Error in getAddress(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAddress()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = agencyRemote.getAddress();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getAddress()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getAddress()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAddress(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAddress(String newAddress) {
    if (agencyRemote == null) {
      System.out.println("Error in setAddress(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAddress(" + newAddress + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      agencyRemote.setAddress(newAddress);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setAddress(" + newAddress + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setAddress(" + newAddress + ")");
      }
      e.printStackTrace();
    }
  }

  public String getAgencyID() {
    String returnValue = "";
    if (agencyRemote == null) {
      System.out.println("Error in getAgencyID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAgencyID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = agencyRemote.getAgencyID();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getAgencyID()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getAgencyID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAgencyID(): " + returnValue + ".");
    }
    return returnValue;
  }

  public String getAgencyName() {
    String returnValue = "";
    if (agencyRemote == null) {
      System.out.println("Error in getAgencyName(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling getAgencyName()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = agencyRemote.getAgencyName();
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: getAgencyName()");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: getAgencyName()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from getAgencyName(): " + returnValue + ".");
    }
    return returnValue;
  }

  public void setAgencyName(String newAgencyName) {
    if (agencyRemote == null) {
      System.out.println("Error in setAgencyName(): " + ERROR_NULL_REMOTE);
      return ;
    }
    long startTime = 0;
    if (logging) {
      log("Calling setAgencyName(" + newAgencyName + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      agencyRemote.setAgencyName(newAgencyName);
      if (logging) {
	long endTime = System.currentTimeMillis();
	log("Succeeded: setAgencyName(" + newAgencyName + ")");
	log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
	log("Failed: setAgencyName(" + newAgencyName + ")");
      }
      e.printStackTrace();
    }
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  /**Main method*/

  public static void main(String[] args) {
    AgencyTestClient1 client = new AgencyTestClient1();
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
  }
}