package src.banksystem;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fsrc_0002fbanksystem_0002fBankSystemErrorPage_0002ejspBankSystemErrorPage_jsp_0 extends HttpJspBase {


    static {
    }
    public _0002fsrc_0002fbanksystem_0002fBankSystemErrorPage_0002ejspBankSystemErrorPage_jsp_0( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        Throwable exception = (Throwable) request.getAttribute("javax.servlet.jsp.jspException");
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="D:\\src\\banksystem\\BankSystemErrorPage.jsp";from=(0,30);to=(6,52)]
                out.write("\r\n<HTML>\r\n<BODY>\r\n\r\n<H1>Error page Jsp2</H1>\r\n\r\n<BR>An error occured in the bean. Error Message is: ");
            // end
            // begin [file="D:\\src\\banksystem\\BankSystemErrorPage.jsp";from=(6,55);to=(6,79)]
                out.print( exception.getMessage() );
            // end
            // HTML // begin [file="D:\\src\\banksystem\\BankSystemErrorPage.jsp";from=(6,81);to=(7,40)]
                out.write("<BR>\r\nStack Trace is : <PRE><FONT COLOR=\"RED\">");
            // end
            // begin [file="D:\\src\\banksystem\\BankSystemErrorPage.jsp";from=(7,42);to=(12,1)]
                
                 java.io.CharArrayWriter cw = new java.io.CharArrayWriter();
                 java.io.PrintWriter pw = new java.io.PrintWriter(cw,true);
                 exception.printStackTrace(pw);
                 out.println(cw.toString());
                 
            // end
            // HTML // begin [file="D:\\src\\banksystem\\BankSystemErrorPage.jsp";from=(12,3);to=(15,0)]
                out.write("</FONT></PRE>\r\n<BR></BODY>\r\n</HTML>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
