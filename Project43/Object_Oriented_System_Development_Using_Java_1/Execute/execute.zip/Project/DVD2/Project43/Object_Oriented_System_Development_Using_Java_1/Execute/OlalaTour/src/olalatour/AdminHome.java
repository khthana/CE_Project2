package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface AdminHome extends EJBHome {
    public AdminRemote create(String adminId, String loginName, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String password) throws RemoteException, CreateException;
    public AdminRemote create(String adminId) throws RemoteException, CreateException;
    public AdminRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
}