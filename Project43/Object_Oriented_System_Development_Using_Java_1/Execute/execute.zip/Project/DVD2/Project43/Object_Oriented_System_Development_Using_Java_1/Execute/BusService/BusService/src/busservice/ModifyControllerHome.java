package busservice;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface ModifyControllerHome extends EJBHome {
  public ModifyControllerRemote create() throws RemoteException, CreateException;
}