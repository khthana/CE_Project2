package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class RestaurantController implements SessionBean {
  private SessionContext sessionContext;
  public void ejbCreate() {
  }
  public void ejbRemove() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext context) {
	sessionContext = context;
  }
  public Collection findRestaurant(String name, String description, String address, int star) {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("Restaurant");

	  RestaurantHome home = (RestaurantHome)PortableRemoteObject.narrow(objref, RestaurantHome.class);

	  Collection restaurants = home.findByNameDescriptionAddressStar(name, description, address, star);
	  ArrayList result = new ArrayList();

	  Iterator i = restaurants.iterator();

	  while (i.hasNext()) {
	    RestaurantRemote restaurant = (RestaurantRemote)i.next();
	    result.add(new ShortRestaurantInformation(restaurant.getRestaurantID(), restaurant.getRestaurantName()));
	  }
	  return result;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullRestaurantInformation viewRestaurant(String restaurantID) {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("Restaurant");

	  RestaurantHome home = (RestaurantHome)PortableRemoteObject.narrow(objref, RestaurantHome.class);
	  RestaurantRemote restaurant = home.findByPrimaryKey(restaurantID);

	  return new FullRestaurantInformation(restaurant.getRestaurantID(), restaurant.getRestaurantName(), restaurant.getDescription(), restaurant.getTotalSeat(), restaurant.getAddress(), restaurant.getStar());
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public FullBookingInformation viewBooking(String bookingID) {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("Booking");

	  BookingHome home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	  BookingRemote booking = home.findByPrimaryKey(bookingID);

	  return new FullBookingInformation(booking.getBookingID(), booking.getRestaurantID(), booking.getMeal(), booking.getDateTime(), booking.getConfirmation(), booking.getNoOfReserveSeat(), booking.getAgencyID());
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public String reserve(String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, String agencyID) throws InvalidRestaurantException, InvalidMealException,
	  SeatNotAvailableException, InvalidAgentException {

	Context initial = null;
	Object objref = null;
	BookingHome home = null;
	BookingRemote booking = null;
	String bookingID = null;

	try {
	  initial = new InitialContext();
	  objref = initial.lookup("Booking");
	  home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}

	bookingID = getNewBookingID();

	System.out.println("got new bookingID : " + bookingID);

	/** @todo maybe remove bookingID let booking generate its own*/
	try {
	    booking = home.create(bookingID, restaurantID, meal, dateTime, noOfReserveSeat, agencyID);
	    System.out.println("after create booking");
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (CreateException ex) {
	  throw new EJBException(ex.getMessage());
	}

	return bookingID;
  }
  public void confirm(String bookingID) throws AlreadyCancelException {
	Context initial = null;
	Object objref = null;
	BookingHome home = null;
	BookingRemote booking = null;
	try {
	  initial = new InitialContext();
	  objref = initial.lookup("Booking");
	  home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	  booking = home.findByPrimaryKey(bookingID);
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	try {
	  booking.confirm();
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public void cancel(String bookingID) throws AlreadyConfirmException {
	Context initial = null;
	Object objref = null;
	BookingHome home = null;
	BookingRemote booking = null;
	try {
	  initial = new InitialContext();
	  objref = initial.lookup("Booking");
	  home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	  booking = home.findByPrimaryKey(bookingID);
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	try {
	  booking.cancel();
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  public void modify(String bookingID, String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, String agencyID) throws InvalidRestaurantException, InvalidMealException,
	  SeatNotAvailableException, InvalidAgentException, AlreadyCancelException, AlreadyConfirmException {
	Context initial = null;
	Object objref = null;
	BookingHome home = null;
	BookingRemote booking = null;

	try {
	  initial = new InitialContext();
	  objref = initial.lookup("Booking");
	  home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
	}
	catch (NamingException ex) {
	  throw new EJBException(ex.getMessage());
	}
	try {
	  booking = home.findByPrimaryKey(bookingID);
	  booking.modify(restaurantID, meal, dateTime, noOfReserveSeat, agencyID);
	}
	catch (RemoteException ex) {
	  throw new EJBException(ex.getMessage());
	}
	catch (FinderException ex) {
	  throw new EJBException(ex.getMessage());
	}
  }
  protected String getNewBookingID() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("UUIDGenerator");

	  UUIDGeneratorHome home = (UUIDGeneratorHome)PortableRemoteObject.narrow(objref, UUIDGeneratorHome.class);
	  UUIDGeneratorRemote uuidGenerator = home.create();

	  return uuidGenerator.getUUID();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}

  }
}