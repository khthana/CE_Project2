package airlinesystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.ArrayList;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ReserveControllerTestClient2 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private ReserveControllerHome reserveControllerHome = null;
  private ReserveControllerRemote reserveControllerRemote = null;

  /**Construct the EJB test client*/
  public ReserveControllerTestClient2() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("ReserveController");

	  //cast to Home interface
	  reserveControllerHome = (ReserveControllerHome) PortableRemoteObject.narrow(ref, ReserveControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public ReserveControllerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  reserveControllerRemote = reserveControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + reserveControllerRemote + ".");
	}
	return reserveControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public ArrayList BookSeat(ArrayList info) {
	ArrayList returnValue = null;
	if (reserveControllerRemote == null) {
	  System.out.println("Error in BookSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling BookSeat(" + info + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = reserveControllerRemote.BookSeat(info);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: BookSeat(" + info + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: BookSeat(" + info + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from BookSeat(" + info + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public String CreateCustomer(String strFirstName, String strLastName, String strAddress, String strTelephoneNo) {
	String returnValue = "";
	if (reserveControllerRemote == null) {
	  System.out.println("Error in CreateCustomer(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling CreateCustomer(" + strFirstName + ", " + strLastName + ", " + strAddress + ", " + strTelephoneNo + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = reserveControllerRemote.CreateCustomer(strFirstName, strLastName, strAddress, strTelephoneNo);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: CreateCustomer(" + strFirstName + ", " + strLastName + ", " + strAddress + ", " + strTelephoneNo + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: CreateCustomer(" + strFirstName + ", " + strLastName + ", " + strAddress + ", " + strTelephoneNo + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from CreateCustomer(" + strFirstName + ", " + strLastName + ", " + strAddress + ", " + strTelephoneNo + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList viewBooking(String BookingID) {
	ArrayList returnValue = null;
	if (reserveControllerRemote == null) {
	  System.out.println("Error in viewBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewBooking(" + BookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = reserveControllerRemote.viewBooking(BookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewBooking(" + BookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewBooking(" + BookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewBooking(" + BookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	ReserveControllerTestClient2 client = new ReserveControllerTestClient2();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.


	client.create();
	ArrayList viewBook = client.viewBooking("2D6735D6-FFFF-FFD3-003B-CBC85B98BFE2");

	ListIterator iterator = viewBook.listIterator(0);
		 while (iterator.hasNext()) {
		 ViewBookSeatInfo item = (ViewBookSeatInfo)iterator.next();


		 System.out.println(item.getCustomerID() + ", " +
							item.getFirstName() + ", " +
							item.getLastName() + ", " +
							item.getFlightID() + ", " +
							item.getDepartTime()+ ", " +
							item.getSeatNo()+ ", " +
							item.getPrice() );



			}
  }
}