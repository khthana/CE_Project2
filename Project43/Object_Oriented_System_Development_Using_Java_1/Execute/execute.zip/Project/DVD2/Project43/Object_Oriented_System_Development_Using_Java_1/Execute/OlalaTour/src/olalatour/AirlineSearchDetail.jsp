<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<table width="700" border="1">
  <tr>
    <td height="50"> 
      <table width="100%" border="1" height="50">
        <tr> 
          <td height="45" width="25%"><b><font size="5">OLALA TOUR</font></b></td>
          <td height="45" width="75%"><font size="4">AIRLINE DETAIL</font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="50">
      <table width="100%" border="1" height="50">
        <tr> 
          <td width="36%"> 
            <form method="post" action="">
              Search 
              <input type="text" name="textfield">
              <input type="submit" name="Submit" value="GO">
            </form>
          </td>
          <td width="64%"> 
            <table width="100%" border="1" height="100%">
              <tr> 
                <td width="70%"> 
                  <div align="right"></div>
                </td>
                <td width="16%"> 
                  <div align="center"><img src="photocart2.jpg" width="26" height="19"><br>
                    <a href="Cart.htm">ViewCart</a> </div>
                </td>
                <td width="14%"> 
                  <div align="center"><img src="home.gif" width="20" height="20"><br>
                    <a href="olalatour.htm">Home </a></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="30"> 
      <table width="100%" border="1" height="30">
        <tr> 
          <td width="16%">Airline Booking</td>
          <td width="13%">Bus Booking</td>
          <td width="15%">Hotel Booking</td>
          <td width="18%">Package Booking</td>
          <td width="16%">LocationSearch </td>
          <td colspan="2" width="22%">Place&amp;ActivitySearch</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="1">
        <tr> 
          <td colspan="3"> 
            <div align="center"><img src="TGAward-logo2.jpg" width="49" height="50"></div>
          </td>
        </tr>
        <tr> 
		  <td><b>FLIGHT :</b> </td>
	          <td colspan="2">
			  <%=request.getParameter("strFlight")%>
		  </td>
        </tr>
        <tr> 
	          <td><b>AIRCRAFT </b>: </td>
		  <td colspan="2">
			<%=request.getParameter("strAircraftName")%>
		  </td>
        </tr>
        <tr> 
	          <td><b>DEPART :</b> </td>
		  <td><%=request.getParameter("strStartAirportName")%></td>
	          <td><%=request.getParameter("tDepartTime")%> </td>
        </tr>
        <tr> 
	          <td><b>ARRIVE :</b> </td>
		  <td><%=request.getParameter("strStopAirportName")%></td>
	          <td><%=request.getParameter("tArriveTime")%></td>
        </tr>
        <tr> 
	          <td><b>MILEAGE :</b></td>
		  <td colspan="2">
			<%=request.getParameter("dDistance")%>
		  </td>
        </tr>
        <tr> 
          <td colspan="3">--Layover time in Hong Kong, Hong Kong is 30 minutes</td>
        </tr>
        <tr> 
          <td><b>EQUIPMENT : </b></td>
          <td colspan="2">Airbus 311 Jet</td>
        </tr>
        <tr> 
          <td><b>DEPART :</b> </td>
          <td>Hong Kong, Hong Kong (HKG) </td>
          <td>at 8:30 am Sunday, Mar 11 </td>
        </tr>
        <tr> 
          <td><b>ARRIVE :</b> </td>
          <td>Cleveland, OH (CLE) </td>
          <td>at 10:00 am Sunday, Mar 11 </td>
        </tr>
        <tr> 
          <td><b>MILEAGE :</b></td>
          <td colspan="2">50</td>
        </tr>
        <tr> 
          <td colspan="3"> 
            <div align="center"></div>
            <div align="center"><a href="Cart.htm">Add To Cart </a></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
