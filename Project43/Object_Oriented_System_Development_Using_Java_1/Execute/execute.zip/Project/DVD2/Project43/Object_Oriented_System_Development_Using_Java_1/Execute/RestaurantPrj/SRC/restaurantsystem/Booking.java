package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Booking implements EntityBean {
  EntityContext entityContext;
  public String bookingID;
  public int meal;
  public int confirmation;
  public int noOfReserveSeat;
  public String agencyID;
  private Connection con;
  private String dbName = "java:comp/env/jdbc/RestaurantDB";
  public String restaurantID;
    private java.sql.Date dateTime;

  public String ejbCreate(String bookingID, String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, String agencyID)
      throws CreateException, InvalidRestaurantException, InvalidMealException, SeatNotAvailableException, InvalidAgentException {

      /** @todo and maybe remove bookingID */

      System.out.println("ejbCreate");

      checkBookable(restaurantID, meal, dateTime, confirmation, noOfReserveSeat, agencyID);

      try {
		insertRow(bookingID, restaurantID, meal, dateTime, confirmation, noOfReserveSeat, agencyID);
      } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
	      ex.getMessage());
      }

      this.bookingID = bookingID;
      this.restaurantID = restaurantID;
      this.meal = meal;
      this.dateTime = dateTime;
      this.confirmation = confirmation;
      this.noOfReserveSeat = noOfReserveSeat;
      this.agencyID = agencyID;

      System.out.println("end ejbCreate");

      return bookingID;
  }
  public void ejbPostCreate(String bookingID, String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, String agencyID) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
    System.out.println("ejbRomove");
      try {
	 deleteRow(restaurantID);
       } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
	      ex.getMessage());
       }
    System.out.println("end ejbRomove");
  }
  public String ejbFindByPrimaryKey(String primKey) throws FinderException {
      System.out.println("ejbFindByPrimaryKey");

      boolean result;

      try {
	 result = selectByPrimaryKey(primKey);
       } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
	      ex.getMessage());
       }
      if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
      }
      else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
	    ("Row for id " + primKey + " not found.");
      }
  }
  public void ejbActivate() {
    System.out.println("ejbActivate");
    bookingID = (String)entityContext.getPrimaryKey();
    System.out.println("end ejbActivate");
  }
  public void ejbPassivate() {
    System.out.println("ejbPassivate");
    bookingID = null;
    System.out.println("end ejbPassivate");
  }
  public void ejbLoad() {
    System.out.println("ejbLoad");
      try {
	 loadRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
      System.out.println("end ejbLoad");
  }
  public void ejbStore() {
    System.out.println("ejbLoad");
      try {
	 storeRow();
       } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
	      ex.getMessage());
       }
    System.out.println("end ejbLoad");
  }
  public void setEntityContext(EntityContext entityContext) {
    System.out.println("setEntityContext");
    this.entityContext = entityContext;
      try {
	 makeConnection();
      } catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
	     ex.getMessage());
      }
    System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
    System.out.println("unsetEntityContext");
    entityContext = null;
      try {
	 con.close();
      } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
      }
    System.out.println("end unsetEntityContext");
  }
  public String getBookingID() {
    return bookingID;
  }
  public int getMeal() {
    return meal;
  }
  public java.sql.Date getDateTime() {
    return dateTime;
  }
  public int getConfirmation() {
    return confirmation;
  }
  public int getNoOfReserveSeat() {
    return noOfReserveSeat;
  }
  public String getAgencyID() {
    return agencyID;
  }
/*********************** Database Routines *************************/

   private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();
   }

   private void insertRow (String bookingID, String restaurantID, int meal, java.sql.Date dateTime, int confirmation, int noOfReserveSeat, String agencyID) throws SQLException {

	  String insertStatement =
		"insert into BOOKING (BOOKING_ID, RESTAURANT_ID, MEAL, RESERVE_DATE, CONFIRMATION, NO_OF_RESERVESEAT, AGENCY_ID) values ( ? , ? , ? , ? , ? , ? , ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);
	  prepStmt.setString(1, bookingID);
	  prepStmt.setString(2, restaurantID);
	  prepStmt.setInt(3, meal);
	  prepStmt.setDate( 4, dateTime);
	  prepStmt.setInt(5, confirmation);
	  prepStmt.setInt(6, noOfReserveSeat);
	  prepStmt.setString(7, agencyID);

	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String id) throws SQLException {

      String deleteStatement =
	    "delete from BOOKING where BOOKING_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(deleteStatement);

      prepStmt.setString(1, id);
      prepStmt.executeUpdate();
      prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
      throws SQLException {

      String selectStatement =
	    "select BOOKING_ID " +
	    "from BOOKING where BOOKING_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);
      prepStmt.setString(1, primaryKey);

      ResultSet rs = prepStmt.executeQuery();
      boolean result = rs.next();
      prepStmt.close();
      return result;
   }

   private void loadRow() throws SQLException {

      String selectStatement =
	    "select RESTAURANT_ID, MEAL, RESERVE_DATE, CONFIRMATION, NO_OF_RESERVESEAT, AGENCY_ID " +
	    "from BOOKING where BOOKING_ID = ? ";
      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);

      prepStmt.setString(1, this.bookingID);

      ResultSet rs = prepStmt.executeQuery();

      if (rs.next()) {
	 this.restaurantID = rs.getString(1);
	 this.meal = rs.getInt(2);
	 this.dateTime = rs.getDate(3);
	 this.confirmation = rs.getInt(4);
	 this.noOfReserveSeat = rs.getInt(5);
	 this.agencyID = rs.getString(6);

	 prepStmt.close();
      }
      else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + restaurantID +
	    " not found in database.");
      }
   }


   private void storeRow() throws SQLException {

      String updateStatement =
	    "update BOOKING set " +
	    "RESTAURANT_ID =  ? ," +
	    "MEAL = ? ," +
	    "RESERVE_DATE = ? ," +
	    "CONFIRMATION = ? ," +
	    "NO_OF_RESERVESEAT = ? ," +
	    "AGENCY_ID = ? " +
	    "where BOOKING_ID = ?";
      PreparedStatement prepStmt =
	    con.prepareStatement(updateStatement);

      prepStmt.setString(1, restaurantID);
      prepStmt.setInt(2, meal);
      prepStmt.setDate(3, dateTime);
      prepStmt.setInt(4, confirmation);
      prepStmt.setInt(5, noOfReserveSeat);
      prepStmt.setString(6, agencyID);

      prepStmt.setString(7, bookingID);

      int rowCount = prepStmt.executeUpdate();
      prepStmt.close();

      if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + restaurantID + " failed.");
      }
   }
  public String getRestaurantID() {
    return restaurantID;
  }
  public void confirm() throws AlreadyCancelException {
    if (confirmation == 2) {
      throw new AlreadyCancelException();
    }
    else {
      confirmation = 1;
    }
  }
  public void cancel() throws AlreadyConfirmException {
    if (confirmation == 1) {
      throw new AlreadyConfirmException();
    }
    else {
      confirmation = 2;
    }
  }
  public void modify(String restaurantID, int meal, java.sql.Date dateTime, int noOfReserveSeat, String agencyID)
      throws RemoteException, InvalidRestaurantException, InvalidMealException, SeatNotAvailableException, InvalidAgentException, AlreadyConfirmException, AlreadyCancelException {

      checkBookable(restaurantID, meal, dateTime, confirmation, noOfReserveSeat, agencyID);

      this.restaurantID = restaurantID;
      this.meal = meal;
      this.dateTime = dateTime;
      this.confirmation = 0;
      this.noOfReserveSeat = noOfReserveSeat;
      this.agencyID = agencyID;
  }
  protected void checkBookable(String restaurantID, int meal, java.sql.Date dateTime,int confirmation, int noOfReserveSeat, String agencyID)
      throws InvalidRestaurantException, InvalidMealException, SeatNotAvailableException, InvalidAgentException {

	/** @todo checkbookable */


  }
}