package busservice;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;
import java.math.*;
import java.io.*;
import java.awt.*;


public class SearchControllerBean implements SessionBean {
  private SessionContext sessionContext;
  Connection con ;
  PreparedStatement pstmt ;
   private String dbName = "java:comp/env/jdbc/RestaurantDB";

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ BUSINESS METHOD @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

//--------------------------------------#####    SEARCH COMPAMY    #####----------------------------------------

public ArrayList SearchCompany( String keyword) throws RemoteException {
System.out.println("****SearchCompany method ****");
	String strCommand ;
	ArrayList companyRecs = new ArrayList() ;

	strCommand = "SELECT CompanyID, CompanyName " +
				 "FROM  BusCompany " +
				 "WHERE Description  LIKE ? " ;


try
{
		PreparedStatement pstmt = con.prepareStatement(strCommand);

		pstmt.setString(1,"%"+ keyword +"%");
		ResultSet rs = pstmt.executeQuery();


	int count = 0 ;
	while (  rs.next() ) {
					int  companyID = rs.getInt(1);
					String companyName = rs.getString(2);

	/********** Add to array **************/
	CompanyRec lineItem =  new CompanyRec(companyID, companyName);
	companyRecs.add(count,lineItem);
	count++;
	} /* close while loop */

	pstmt.close();

	if (count ==0) {
		System.out.println("Notfound");
	}
	else
		System.out.println("Found");

}  /*** Close Try ****/

catch(java.sql.SQLException e)
{
	throw new EJBException ("Can not search company. " + e.getMessage());
}
System.out.println(" Return  ");
return companyRecs;

} /******* End Search Company *********/

//------------------------------------#####    SEARCH STATION    #####----------------------------------------------------------------------

public ArrayList SearchStation( String keyword )throws RemoteException {
	System.out.println("** SearchStation ** ");
	String strCommand ;
	ArrayList stationRecs = new ArrayList() ;

	strCommand = "SELECT  PlaceID, PlaceName " +
				 "FROM    Place " +
				 "WHERE Description  LIKE ? " ;


try
{
	PreparedStatement pstmt = con.prepareStatement (strCommand);
	System.out.println("*******  1 **********");

	pstmt.setString(1,"%"+ keyword +"%");

	ResultSet rs = pstmt.executeQuery();
	System.out.println("********* 2 ************");

	int count = 0 ;
	while (  rs.next() ) {

	 System.out.println("*******  3 **********");
					String PlaceID = rs.getString(1);
					String PlaceName = rs.getString(2);

	  /********** Add to array **************/
	  StationRec lineItem =  new StationRec(PlaceID, PlaceName);
	  stationRecs.add(count,lineItem);
	  count++;

	} /* close while loop */

	pstmt.close();

	if (count ==0) {
	  System.out.println("Notfound");
	}
	else
	  System.out.println("Found");

}  /*** Close Try ****/

catch(java.sql.SQLException e)
{
  System.out.println("[BusService,SearchStation]Can not search station.\n" + "Command : "  + strCommand  + "\n" + e.getMessage());
}

return stationRecs;

} /******* End Search Station *********/

// ------------------------------------#####    SEARCH SEAT    #####----------------------------------------------------------------------

public  ArrayList  SearchSeat ( String SrcStationID, String DstStationID, int TotalSeat, java.sql.Date DepartDate, int CompanyID, int ClassType, int SeatType)  throws RemoteException {

	System.out.println(" ****** Search Seat Method **********");
	String strCommand ;
	String strSelectedCompany ;
	String strSelectedClassType;
	String strSelectedSeatType ;

// ********************* DATE ***************


// Change Date input to Timestamp
	int idate = DepartDate.getDate();
	int imonth = DepartDate.getMonth();
		imonth = imonth + 1;
	int iyear = DepartDate.getYear();
		iyear = iyear + 1900;
	String str2Date = String.valueOf(idate);
	String str2Month = String.valueOf(imonth);
	String str2Year = String.valueOf(iyear);
	String strDepartDate = str2Year + "-" + str2Month + "-" + str2Date + " 00:00:00.000000000";

	java.sql.Timestamp NewDepartDate = java.sql.Timestamp.valueOf(strDepartDate); // get timestamp to searchSeat


  // Checking company that user selected.
		if (CompanyID == 0) {  // user not select >> can use all type of seat

		System.out.println("*******  companyID = 0 **********");
			strSelectedCompany = "";
		}
		else {

		System.out.println("*******  company != 0 **********");
			strSelectedCompany = ( " AND T7.CompanyID = " + CompanyID +" " );
		}
  // Check ClassType
		switch  (ClassType)  {

		case (0) :   // 0 = all class
			strSelectedClassType = "";
			break;
		case (1) :
			System.out.println("*******  classType = 1 **********");

			strSelectedClassType = " AND T7.ClassID = 1 ";
			break;
		case (2) :
			strSelectedClassType = " AND T7.ClassID = 2 ";
			break;
		case (3) :
			strSelectedClassType = " AND T7.ClassID = 3 ";
			break;
		default :
			strSelectedClassType = "";
		}

  // Checking type of seat that user selected.
	switch (SeatType) {
		case (0) :  // 0 = all Type
			strSelectedSeatType = "";
			break;
		case (1) :

		System.out.println("*******  SeatType = 1 **********");
			strSelectedSeatType = "  AND T8.Window = 1  ";
			break;
		case (2) :
			strSelectedSeatType = "   AND T8.Window = 0  ";
			break;
		default :
			strSelectedSeatType = "";

			}

System.out.println(" ****** Generate sql command **********");
  // Create SQL command for searching Route

strCommand =  " SELECT       T1.CompanyName, T2.ClassName, " +
								  "                        T3.DepartTime, T4.ArriveTime, " +
								  "                        T3.RouteID , T3.Idx, T4.Idx, (SUM(T12.Distance) * T2.PricePerKm) + T13.Fee  " +
								  "   FROM           BusCompany T1,  " +
								  "                        BusClass T2, " +
								  "                        RouteSubRoute T3, RouteSubRoute T4, RouteSubRoute T11," +
								  "                        SubRoute T5, SubRoute T6, SubRoute T12," +
								  "                        Route T7, " +
								  "                        BusFee T13 " ;

strCommand = strCommand +
								  "   WHERE       T5.SrcStation = '" + SrcStationID +"'" +
								  "                         AND T6.DstStation = '" + DstStationID +"'"+
								  "                         AND T5.SubRouteID = T3.SubRouteID " +
								  "                         AND T6.SubRouteID = T4.SubRouteID " +
								  "                         AND T3.RouteID = T4.RouteID " +
								  "                         AND T11.RouteID = T3.RouteID " +
								  "                         AND T11.Idx BETWEEN T3.Idx AND T4.Idx " +
								  "                         AND T12.SubRouteID = T11.SubRouteID " +
								  "                         AND T3.Idx <= T4.Idx " +
								  "                         AND T7.RouteID = T3.RouteID " +
								  "                         AND T1.CompanyID = T7.CompanyID " +
								  "                         AND T2.ClassID = T7.ClassID " +
								  "                         AND T13.CompanyID = T1.CompanyID " +
								  "                         AND T13.ClassID = T2.ClassID  " + strSelectedCompany  +  strSelectedClassType +
								   "                        AND " +  TotalSeat + " <=  " ;


	strCommand = strCommand +
								  "  (SELECT COUNT(DISTINCT T8.SeatNo)  " +
								  "   FROM      Seat T8  " +
								  "   WHERE   T7.ModelID = T8.ModelID  " +
								  strSelectedSeatType +
								  "                    AND T8.SeatNo NOT IN  ( " +
								  "   SELECT    DISTINCT T9.SeatNo  " +
								  "   FROM        SubRouteBooking T9, " +
								  "                     RouteSubRoute T10  " +
								  "   WHERE    T9.DepartDate = '" + NewDepartDate +"' "  +
								  "                     AND T9.RouteID = T7.RouteID " +
								  "                     AND T9.RouteID = T10.RouteID " +
								  "                     AND T9.SubRouteID = T10.SubRouteID "+
								  "                     AND T10.Idx >= T3.Idx " +
								  "                     AND T10.Idx <=  T4.Idx ))  " ;

	strCommand = strCommand +
								  "   GROUP BY     T1.CompanyName, T2.ClassName, " +
								  "                            T3.DepartTime, T4.ArriveTime, " +
								  "                            T3.RouteID , T3.Idx, T4.Idx, T2.PricePerKm, T13.Fee ";


//T9.departDate is Timestamp but DepartDate is Date



ArrayList searchRecs = new ArrayList() ;

try
{


	PreparedStatement pstmt = con.prepareStatement(strCommand);

	System.out.println("********** PreparedStatement pstmt = con.prepareStatement (strCommand) *****************");


	ResultSet rs = pstmt.executeQuery();                    // pstmt.executeQuery();

	System.out.println("***********ResultSet rs = pstmt.executeQuery()*****************");

	int count = 0 ;

	while (  rs.next() ) {
	 System.out.println("**************** In while loop ********");

					String CompanyName = rs.getString(1);
					String ClassName = rs.getString(2);
					java.sql.Timestamp DepartTime = rs.getTimestamp(3);
					java.sql.Timestamp ArriveTime = rs.getTimestamp(4);
					int RouteID = rs.getInt(5);
					int SrcIndex = rs.getInt(6);
					int DstIndex = rs.getInt(7);
					double Price = rs.getDouble(8);

// @@@@@@@@@@@@@@@@@@ Add to array @@@@@@@@@@@@@@@@@@@@@
	SearchRec lineItem =  new SearchRec(CompanyName, ClassName, DepartTime, ArriveTime, RouteID, SrcIndex, DstIndex, Price);
	searchRecs.add(count,lineItem);
	count++;
	}      // close while loop



	pstmt.close();
	if (count ==0) {
	System.out.println("No match row in database");
	}

}  // close try

catch(java.sql.SQLException e)
{
throw new EJBException ("DB Query Fail[BusDB]\n"+e.getMessage());
}


  try
  {
	if(pstmt!=null)
	{
	pstmt.close();
	con.close();
	}
  }catch(java.sql.SQLException e)
  {

  throw  new EJBException ("DB Close Error" + e.getMessage() );
  }

return searchRecs;

}  // close SearchSeat


//-------------------------------------------- SEARCH BUS -------------------------------------------------------
public ArrayList SearchBus(java.sql.Date  UsingDate ,String TotalUsingDay, boolean AirCond, boolean Toilet) throws RemoteException  {
  return null;
}
//----------------------------------------- SEARCH BUSBOOKING --------------------------------------------
public ArrayList SearchBusBooking(String BookingID) throws RemoteException  {
  return null;
}
//----------------------------------------- SEARCH SEATBOOKING --------------------------------------------
public ArrayList SearchSeatBooking(String BookingID) throws RemoteException  {
  return null;
}

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Require Method @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

 public void ejbCreate() throws RemoteException  {
 System.out.println("**** Create method ****");
  try {
		 makeConnection();
	  } catch (Exception ex) {
		  throw new EJBException("Unable to connect to database. " +
			 ex.getMessage());
	  }


  System.out.println("**** End Create method ****");
}

  public void ejbRemove() {
	 try {
		 con.close();
	  } catch (SQLException ex) {
		  throw new EJBException("ejbRemove: " + ex.getMessage());
	  }
  }

  public void ejbActivate() {
  }

  public void ejbPassivate() {
  }

  public void setSessionContext(SessionContext context) {
	sessionContext = context;
  }

//----------------------------------------- BEGIN MAKECONNECTION ---------------------------------------------
 private void makeConnection() throws NamingException, SQLException {

	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup(dbName);
	  con =  ds.getConnection();
   }
//----------------------------------------- END MAKECONNECTION ---------------------------------------------

}

