package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */



public class SeatNotAvailableException extends Exception {

   public SeatNotAvailableException() { }

   public SeatNotAvailableException(String msg) {
      super(msg);
   }
}
