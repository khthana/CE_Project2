package hotelsystem;

import java.rmi.*;
import javax.ejb.*;

public interface HotelControllerHome extends EJBHome {
  public HotelControllerRemote create() throws RemoteException, CreateException;
}