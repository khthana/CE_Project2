package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class Booking implements EntityBean {
  EntityContext entityContext;
  public String bookingId;
  public Double totalPrice;
  public Timestamp bookingTime;
  public Integer confirmed;
  public Date deadline;
  public String memberId;
  public String busGroupBooking;
  public String aircraftGroupBooking;
  public String hotelGroupBookingId;
  public String ejbCreate(String bookingId, Double totalPrice, Timestamp bookingTime, Integer confirmed, Date deadline, String memberId, String busGroupBooking, String aircraftGroupBooking, String hotelGroupBookingId) throws CreateException {
	this.bookingId = bookingId;
	this.totalPrice = totalPrice;
	this.bookingTime = bookingTime;
	this.confirmed = confirmed;
	this.deadline = deadline;
	this.memberId = memberId;
	this.busGroupBooking = busGroupBooking;
	this.aircraftGroupBooking = aircraftGroupBooking;
	this.hotelGroupBookingId = hotelGroupBookingId;
	return null;
  }
  public String ejbCreate(String bookingId) throws CreateException {
	return ejbCreate(bookingId, null, null, null, null, null, null, null, null);
  }
  public void ejbPostCreate(String bookingId, Double totalPrice, Timestamp bookingTime, Integer confirmed, Date deadline, String memberId, String busGroupBooking, String aircraftGroupBooking, String hotelGroupBookingId) throws CreateException {
  }
  public void ejbPostCreate(String bookingId) throws CreateException {
	ejbPostCreate(bookingId, null, null, null, null, null, null, null, null);
  }
  public void ejbRemove() throws RemoveException {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
  }
  public void unsetEntityContext() {
	entityContext = null;
  }
  public String getBookingId() {
	return bookingId;
  }
  public Double getTotalPrice() {
	return totalPrice;
  }
  public void setTotalPrice(Double totalPrice) {
	this.totalPrice = totalPrice;
  }
  public Timestamp getBookingTime() {
	return bookingTime;
  }
  public void setBookingTime(Timestamp bookingTime) {
	this.bookingTime = bookingTime;
  }
  public Integer getConfirmed() {
	return confirmed;
  }
  public void setConfirmed(Integer confirmed) {
	this.confirmed = confirmed;
  }
  public Date getDeadline() {
	return deadline;
  }
  public void setDeadline(Date deadline) {
	this.deadline = deadline;
  }
  public String getMemberId() {
	return memberId;
  }
  public void setMemberId(String memberId) {
	this.memberId = memberId;
  }
  public String getBusGroupBooking() {
	return busGroupBooking;
  }
  public void setBusGroupBooking(String busGroupBooking) {
	this.busGroupBooking = busGroupBooking;
  }
  public String getAircraftGroupBooking() {
	return aircraftGroupBooking;
  }
  public void setAircraftGroupBooking(String aircraftGroupBooking) {
	this.aircraftGroupBooking = aircraftGroupBooking;
  }
  public String getHotelGroupBookingId() {
	return hotelGroupBookingId;
  }
  public void setHotelGroupBookingId(String hotelGroupBookingId) {
	this.hotelGroupBookingId = hotelGroupBookingId;
  }
}