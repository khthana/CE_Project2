<HTML>
<HEAD>
<jsp:useBean id="TestJsp1BeanId" scope="session" class="hotelsystem.TestJsp1Bean" />
<jsp:setProperty name="TestJsp1BeanId" property="*" />
<%--<jsp:useBean id="bean0" scope="session" class="hotelsystem.HotelControllerTestClient1" />
<jsp:setProperty name="bean0" property="*" />--%>
<TITLE>
TestJsp1
</TITLE>
</HEAD>
<BODY>
<H1>
JBuilder Generated JSP
</H1>
<FORM method="get">
<BR>Enter new value   :  <INPUT NAME="sample"><BR>
<BR><BR>
<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit">
<INPUT TYPE="RESET" VALUE="Reset">
<BR>
Value of Bean property is :<jsp:getProperty name="TestJsp1BeanId" property="sample" />
<HR>bean0<BR>
<HR>
<%TestJsp1BeanId.hoho("", "", "", 500);%>
<table>
<%while (TestJsp1BeanId.next()) {%>
    <tr>
	<td><%=TestJsp1BeanId.getID()%></td>
	<td><%=TestJsp1BeanId.getName()%></td>
    </tr>
<%}%>
</table>
<BR>
</FORM>
</BODY>
</HTML>
