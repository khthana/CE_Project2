package airlinesystem;


import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;
import java.math.*;
import java.io.*;
import java.awt.*;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class SearchController implements SessionBean {
  private SessionContext sessionContext;

  Connection con ;
  PreparedStatement pstmt ;
  private String dbName = "java:comp/env/jdbc/AirlineDB";

/***************************************** SEARCH AIRLINE (AirlineRec) *****************************************************/

public ArrayList SearchAirline(String keyword) throws RemoteException {

     System.out.println("****SearchAirline method ****");
     String strCommand ;
     ArrayList airlineRecs = new ArrayList();

     strCommand =  "SELECT AirlineID, AirlineName " +
                   "FROM   Airline  ";


    if (keyword.equals("")) {
        strCommand = strCommand;
        }
        else
        strCommand = strCommand + "WHERE Description  LIKE ? " ;

try
{
    PreparedStatement pstmt = con.prepareStatement(strCommand);
        System.out.println("*** 1 *****************");

    if (keyword.equals("")==false) {
    pstmt.setString(1,"%"+ keyword +"%");
    }
    ResultSet rs = pstmt.executeQuery();
    System.out.println("2*****************");

    int count = 0 ;
    while (rs.next()) {
                    int AirlineID = rs.getInt(1);
                    String AirlineName = rs.getString(2);

   System.out.println("*** 3 *****************");
    /********** Add to array **************/
    AirlineRec lineItem =  new AirlineRec(AirlineID, AirlineName);
    airlineRecs.add(count,lineItem);
    count++;
    } /* close while loop */

    pstmt.close();

    if (count ==0) {
        System.out.println("Notfound");
    }
    else
        System.out.println("Found");

} /*end try*/

catch(java.sql.SQLException e)
    {
  throw new EJBException("Can not execute command to search airline " + e.getMessage()) ;
  }

return airlineRecs;

} /******* End Search Airline *********/


/***************************************** SEARCH AIRPORT (AirportRec) **************************************************/

public ArrayList SearchAirport(String keyword ) throws RemoteException {
    System.out.println("** SearchAirport ** ");

    String strCommand ;

    ArrayList airportRecs = new ArrayList();

    strCommand = "SELECT  PlaceID, PlaceName  " +
                 "FROM       Place  " ;
        if (keyword.equals("")) {
        strCommand = strCommand;
        }
        else
        strCommand = strCommand + "WHERE Description  LIKE ? " ;


try
{
    PreparedStatement pstmt = con.prepareStatement (strCommand);
    System.out.println("*******  1 **********");

    if (keyword.equals("")==false) {
    pstmt.setString(1,"%"+ keyword +"%");
    }

    ResultSet rs = pstmt.executeQuery();
    System.out.println("********* 2 ************");

    int count = 0 ;
    while (  rs.next() ) {

     System.out.println("*******  3 **********");
                    String PlaceID = rs.getString(1);
                    String PlaceName = rs.getString(2);

    /********** Add to array **************/
    AirportRec lineItem =  new AirportRec(PlaceID, PlaceName);
    airportRecs.add(count,lineItem);
    count++;
    } /* close while loop */


    pstmt.close();

    if (count ==0) {
        System.out.println("Notfound");
    }
    else
        System.out.println("Found");

} /*end try*/

catch(java.sql.SQLException e)
    {
    throw new EJBException("Can not execute sql command to search airport." + e.getMessage()) ;
    }

return airportRecs;
}

/************************************************ SEARCH SEAT (SeatRec) ************************************************/

public ArrayList SearchSeat(String strSrcAirportID ,String strDstStationID, int iTotalSeat, java.sql.Date Date,int iAirlineID, int iClassType,
  int iSeatType, boolean blCanSmoking, boolean blNonStop,int iOrder) throws RemoteException,SearchErrorException {

  System.out.println(" Search Seat method " );

    String strCommand ;
    String strSqlResult;
    String strAirlineID;
    String strClassType;
    String strSeatType;
    String strCanSmoking;
    String strOrdering ;
    String strNonStop;
    ArrayList SeatRecs = new ArrayList();


// Find value of TodayDate
        java.util.Date today = new java.util.Date();
        int year = today.getYear();  // =1900 +year
            year = 1900+year;
        int month = today.getMonth(); //=1 + month
            month = month + 1;
        int day =  today.getDate();

        String strYear = String.valueOf(year);
        String strMonth = String.valueOf(month);
        String strDay = String.valueOf(day);

// Today date in String
      String strDateToday = (strYear+"-"+strMonth+"-"+strDay);  // format of String yyyy-mm-dd
      System.out.println("Time Today In String  is : " + strDateToday );

// Today date in java.sql.Date
      java.sql.Date DateToday = java.sql.Date.valueOf(strDateToday); // todayDate in format Date
      System.out.println(" Time Today In Date format is : " + DateToday );


        System.out.println(" Check for Date " );

//        if (strDate.equals("") ) { // check date to search
            if (Date == null){
            System.out.println(" Date input is null :Default date is today :" + DateToday );
            Date = DateToday; // date in today
         }
        else {
               if ( Date.before(DateToday)){
                     System.out.println(" Date input is Expire" );
                     ArrayList empty = null;
                     return  empty;
//               throw new SearchErrorException("Date is Expire");

	      }
    } // end else

    System.out.println(" Date is :  " + Date );
    java.sql.Date dateTime = Date ; // java.sql.Date.valueOf(strDate); // change strDate to find in database

// Change to Timestamp ***********
    int idate = Date.getDate();
    int imonth = Date.getMonth();
        imonth = imonth + 1;
    int iyear = Date.getYear();
        iyear = iyear + 1900;
    String str2Date = String.valueOf(idate);
    String str2Month = String.valueOf(imonth);
    String str2Year = String.valueOf(iyear);
    String strDepartDate = str2Year+"-"+str2Month+"-"+str2Date+ " 00:00:00.000000000";

    java.sql.Timestamp newDateTime = java.sql.Timestamp.valueOf(strDepartDate); // get timestamp to searchSeat

// Check for total seat to search
    System.out.println(" Check for TotalSeat " );
    if (iTotalSeat <= 0) {
        iTotalSeat = 1;
    }
    System.out.println(" Total Seat is : " + iTotalSeat );


    System.out.println(" Check for AirlineID" );
    if (iAirlineID == 0){ // check airlineID if null = 0 OR no input in this field >> then defind strAirlineID = ""
        strAirlineID = "";
    }
    else strAirlineID = " AND T1.AirlineID = " + iAirlineID + " ";
    System.out.println(" AirlineID is :  " + strAirlineID );


    System.out.println(" Check for ClassType " );
    if ( iClassType == 0 ) { // Check classType
        strClassType = "";
    }
    else  strClassType = " AND T2.ClassID = " + iClassType + " " ;
    System.out.println(" strClassType is : " + strClassType );


    // Check for Airline SeatType
    System.out.println(" Check for Airline seatType " );
    switch (iSeatType) {
        case (0) : // 0 = All Seat
            strSeatType = "";
            break;
        case (1) : // 1 = Window
            strSeatType = " AND T15.Window = 0 ";
            break;
        case (2) : // 2 = Aisle
            strSeatType = "  AND T15.Aisle = 0  ";
            break;
        default :
            strSeatType = "";
            }
    System.out.println(" strSeatType is : "  + strSeatType);



    // Check for smoking ?
    System.out.println(" Check for CanSmoke ? " );
    if (blCanSmoking) {
        strCanSmoking = " AND T15.Smoking = 0  ";  // Show seat that can smoke
    } else strCanSmoking = "" ; // Show all seat

    // Check for Order
    System.out.println(" Check for order to  display " );
    switch (iOrder) {
        case (0) : // 0 = Default
            strOrdering = " ORDER BY    T1.AirlineName, T11.FlightID ";
            break;
        case (1) : // 1 = AirlineName
            strOrdering = " ORDER BY    T1.AirlineName, T11.FlightID ";
            break;
        case (2) : // 2 = LowestPrice
            strOrdering = "  ORDER BY    ( SUM(DISTINCT T10.Distance) * T12.PricePerKm ) + T11.Fee + T12.Fee, " +
                          "  T1.AirlineName, T11.FlightID " ;
            break;
        case (3) : // ShortestPath
            strOrdering = " ORDER BY    SUM(DISTINCT T10.Distance) ";
            break;

        case (4) : // DepartTime
            strOrdering = " ORDER BY    T5.DepartTime ";
            break;
        case (5) : // ArriveTime
            strOrdering = " ORDER BY    T6.ArriveTime ";
            break;
        default :
            strOrdering = " ORDER BY    T1.AirlineName, T11.FlightID ";
            }

    // Check for nonStop flight
    System.out.println(" Check for nonStop flight " );
    if (blNonStop) {
        strNonStop = " HAVING  COUNT(DISTINCT T10.SubRouteID) = 1 "; // for non stop
    } else strNonStop = "" ; // for any thing


//*************************  SQL COMMAND FOR SEARCH SEAT *********
    strCommand = "SELECT     T1.AirlineName, T11.FlightID, T3.AircraftName, " +
                                  "                      T2.ClassName,  " +
                                  "                      T5.DepartTime, T6.ArriveTime, " +
                                  "                      T5.Idx, T6.Idx, " +
                                  "                      SUM(T10.Distance)," +
                                  "                      ( SUM( DISTINCT T10.Distance) * T12.PricePerKm ) + T11.Fee + T12.Fee," +
                                  "                      T11.Description "+
                                  "FROM         Airline T1, " +
                                  "                      AircraftClass T2," +
                                  "                      AircraftType T3, " +
                                  "                      ClassType T4, " +
                                  "                      FlightSubRoute T5, FlightSubRoute T6, FlightSubRoute T7, " +
                                  "                      SubRoute T8, SubRoute T9, SubRoute T10, " +
                                  "                      Flight T11, " +
                                  "                      ClassFee T12 "+
                                  "WHERE     T8.SrcAirport = '" + strSrcAirportID + "'" +
                                  "                      AND T9.DstAirport = '" + strDstStationID + "'" +
                                  "                      AND T8.SubRouteID = T5.SubRouteID " +
                                  "                      AND T9.SubRouteID = T6.SubRouteID " +
                                  "                      AND T5.FlightID = T6.FlightID " +
                                  "                      AND T5.Idx <= T6.Idx " +
                                  "                      AND T11.FlightID = T5.FlightID " +
                                  "                      AND T1.AirlineID = T11.AirlineID " +
                                  "                      AND T3.AircraftID = T11.AircraftID " +
                                  "                      AND T4.AircraftID = T3.AircraftID " +
                                  "                      AND T2.ClassID = T4.ClassID " +
                                  "                      AND T12.AirlineID = T1.AirlineID " +
                                  "                      AND  T12.ClassID =  T2.ClassID ";

    strCommand = strCommand +  strAirlineID + strClassType +
                                  "                      AND T7.FlightID = T11.FlightID " +
                                  "                      AND T7.Idx BETWEEN T5.Idx AND T6.Idx " +
                                  "                      AND T10.SubRouteID = T7.SubRouteID " +
                                  "                      AND  " + iTotalSeat + " <= " ;
    strCommand = strCommand +
                                  " ( SELECT        COUNT( DISTINCT T15.SeatNo) " +
                                  "    FROM            Seat T15 " +
                                  "    WHERE        T15.AircraftID = T11.AircraftID " +
                                  strSeatType + strCanSmoking +
                                  "                             AND T15.ClassID = T2.ClassID " +
                                  "                             AND T15.SeatNo NOT IN " +
                                  " ( SELECT           DISTINCT T16.SeatNo " +
                                  "    FROM            SubRouteBooking T16, " +
                                  "                             FlightSubRoute T17 " +
                                  "    WHERE        T16.DepartDate = '" + newDateTime + "' " +
                                  "                             AND T16.FlightID = T11.FlightID " +
                                  "                             AND T16.FlightID = T17.FlightID " +
                                  "                             AND T16.SubRouteID = T17.SubRouteID " +
                                  "                             AND T17.Idx BETWEEN T5.Idx AND T6.Idx " +
                                  " ) ) " ;
    strCommand = strCommand +
                                  "GROUP BY    T1.AirlineName, T11.FlightID, T3.AircraftName, " +
                                  "                           T2.ClassName, " +
                                  "                           T5.DepartTime, T6.ArriveTime, " +
                                  "                           T5.Idx, T6.Idx, " +
                                  "                           T11.Fee, " +
                                  "                           T12.PricePerKm, T12.Fee, T11.Description " +
                                  strNonStop + strOrdering ;

System.out.println(" Check for Execute command " );
try
{
    pstmt = con.prepareStatement(strCommand);
    System.out.println("After con.prepareStatement(strCommand) " );
    ResultSet rs = pstmt.executeQuery();
    System.out.println(" After executeQuery " );

    int count = 0 ;
    while (  rs.next() ) {
                    String AirlineName = rs.getString(1);
                    String FlightID = rs.getString(2);
                    String AircraftName= rs.getString(3);
                    String ClassName = rs.getString(4);
                    java.sql.Timestamp DepartTime = rs.getTimestamp(5);
                    java.sql.Timestamp ArriveTime = rs.getTimestamp(6);
                    int SrcIdx = rs.getInt(7);
                    int DstIdx = rs.getInt(8);
                    int TotalDistance = rs.getInt(9);
                    double Price = rs.getDouble(10);
                    String Description = rs.getString(11);

    System.out.println(" Add result to SeatRecs to return " );
    /********** Add to array **************/
    SeatRec lineItem =  new SeatRec(AirlineName, FlightID, AircraftName,ClassName, DepartTime, ArriveTime,SrcIdx, DstIdx, TotalDistance,Price, Description);
    SeatRecs.add(count,lineItem);
    count++;
    } /* close while loop */

    System.out.println(" End While loop " );
    pstmt.close();

    if (count ==0) {
        System.out.println("Notfound");
    }
    else
        System.out.println("Found");

} /*end try*/

catch(java.sql.SQLException e)
    {
    throw new EJBException( "Can not execute sql command to search seat.");
    }
return SeatRecs;

} /* end method SearchSeat */

/************************************************* REQUIRE METHOD ***********************************************************/

 public void ejbCreate() throws RemoteException  {
 System.out.println("**** Create method ****");
  try {
         makeConnection();
      } catch (Exception ex) {
          throw new EJBException("Unable to connect to database. " +
             ex.getMessage());
      }
  System.out.println("**** End Create method ****");
}

  public void ejbRemove() {
     try {
         con.close();
      } catch (SQLException ex) {
          throw new EJBException("ejbRemove: " + ex.getMessage());
      }
  }

  public void ejbActivate() {
  }

  public void ejbPassivate() {
  }

  public void setSessionContext(SessionContext context) {
    sessionContext = context;
  }

//----------------------------------------- BEGIN MAKECONNECTION ---------------------------------------------
 private void makeConnection() throws NamingException, SQLException {

      InitialContext ic = new InitialContext();
      DataSource ds = (DataSource) ic.lookup(dbName);
      con =  ds.getConnection();
   }
//----------------------------------------- END MAKECONNECTION ---------------------------------------------

}