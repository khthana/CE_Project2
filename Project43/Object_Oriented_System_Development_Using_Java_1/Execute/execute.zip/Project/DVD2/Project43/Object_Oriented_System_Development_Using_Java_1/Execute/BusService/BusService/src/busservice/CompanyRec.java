package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CompanyRec implements java.io.Serializable {
  int companyID;
  String companyName ;

  public  CompanyRec(int companyID, String companyName) {

	  this.companyID = companyID;
	  this.companyName = companyName;
   }

   public int getCompanyID() {
	  return companyID;
   }

   public String getCompanyName() {
	 return companyName;
   }

}