package olalatour;

import java.io.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullCategoryInformation implements Serializable {

    public FullCategoryInformation(String categoryID, String categoryName, String description, Collection places) {
	this.categoryID = categoryID;
	this.categoryName = categoryName;
	this.description = description;
	this.places = places;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getCategoryID() {
	return categoryID;
    }
    public String getCategoryName() {
	return categoryName;
    }
    public String getDescription() {
	return description;
    }
    public java.util.Collection getPlaces() {
	return places;
    }
    private String categoryID;
    private String categoryName;
    private String description;
    private java.util.Collection places;
}