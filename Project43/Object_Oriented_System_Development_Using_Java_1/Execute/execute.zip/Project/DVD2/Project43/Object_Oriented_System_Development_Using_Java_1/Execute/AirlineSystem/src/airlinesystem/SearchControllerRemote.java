package airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */


public interface SearchControllerRemote extends EJBObject {
public ArrayList SearchAirline(String Keyword) throws RemoteException ;
public ArrayList SearchAirport(String Keyword ) throws RemoteException;
public ArrayList SearchSeat(String strSrcAirportID ,String strDstStationID, int iTotalSeat, java.sql.Date Date,int iAirlineID, int iClassType,int iSeatType, boolean blCanSmoking, boolean blNonStop,int iOrder) throws RemoteException,SearchErrorException ;

}