package olalatour;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.sql.Date;
import java.util.Collection;
import java.util.ArrayList;
import java.sql.Timestamp;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class OlalaAgencyControllerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 250;
  private boolean logging = true;
  private OlalaAgencyControllerHome olalaAgencyControllerHome = null;
  private OlalaAgencyControllerRemote olalaAgencyControllerRemote = null;

  /**Construct the EJB test client*/
  public OlalaAgencyControllerTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("olalatour/OlalaAgencyController");

	  //cast to Home interface
	  olalaAgencyControllerHome = (OlalaAgencyControllerHome) PortableRemoteObject.narrow(ref, OlalaAgencyControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public OlalaAgencyControllerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  olalaAgencyControllerRemote = olalaAgencyControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + olalaAgencyControllerRemote + ".");
	}
	return olalaAgencyControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public void modify(String bookingID, FullBookingInformation fullBookingInformation) {
	if (olalaAgencyControllerRemote == null) {
	  System.out.println("Error in modify(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling modify(" + bookingID + ", " + fullBookingInformation + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  olalaAgencyControllerRemote.modify(bookingID, fullBookingInformation);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: modify(" + bookingID + ", " + fullBookingInformation + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: modify(" + bookingID + ", " + fullBookingInformation + ")");
	  }
	  e.printStackTrace();
	}
  }

  public String reserve(FullBookingInformation fullBookingInformation) {
	String returnValue = "";
	if (olalaAgencyControllerRemote == null) {
	  System.out.println("Error in reserve(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling reserve(" + fullBookingInformation + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyControllerRemote.reserve(fullBookingInformation);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: reserve(" + fullBookingInformation + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: reserve(" + fullBookingInformation + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from reserve(" + fullBookingInformation + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public String createTraveller(String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String foodTypeId) {
	String returnValue = "";
	if (olalaAgencyControllerRemote == null) {
	  System.out.println("Error in createTraveller(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling createTraveller(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + foodTypeId + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyControllerRemote.createTraveller(firstName, lastName, address, telephoneNo, emailAddress, gender, birthDate, religion, foodTypeId);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: createTraveller(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + foodTypeId + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: createTraveller(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + foodTypeId + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from createTraveller(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + foodTypeId + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public String createMember(String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String password) {
	String returnValue = "";
	if (olalaAgencyControllerRemote == null) {
	  System.out.println("Error in createMember(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling createMember(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + password + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyControllerRemote.createMember(firstName, lastName, address, telephoneNo, emailAddress, gender, birthDate, religion, password);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: createMember(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + password + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: createMember(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + password + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from createMember(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + emailAddress + ", " + gender + ", " + birthDate + ", " + religion + ", " + password + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public boolean confirm(String bookingID, String transactionID) {
	boolean returnValue = false;
	if (olalaAgencyControllerRemote == null) {
	  System.out.println("Error in confirm(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling confirm(" + bookingID + ", " + transactionID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyControllerRemote.confirm(bookingID, transactionID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: confirm(" + bookingID + ", " + transactionID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: confirm(" + bookingID + ", " + transactionID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from confirm(" + bookingID + ", " + transactionID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public boolean cancel(String bookingID) {
	boolean returnValue = false;
	if (olalaAgencyControllerRemote == null) {
	  System.out.println("Error in cancel(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling cancel(" + bookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = olalaAgencyControllerRemote.cancel(bookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: cancel(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: cancel(" + bookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from cancel(" + bookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	OlalaAgencyControllerTestClient1 client = new OlalaAgencyControllerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.

	client.create();

//	System.out.println("memberid : " + client.createMember("FNAME1", "LNAMEl", "ADDRESS1", "TEL1", "EMAIL1", new Integer(1), new Date(2001, 10, 5), "BUDHA", "PASS1"));
//
//	System.out.println("travellerid : " + client.createTraveller("FNAME1", "LNAMEl", "ADDRESS1", "TEL1", "EMAIL1", new Integer(1), new Date(2001, 1, 15), "CHRIST", "FOOD1"));

//	cancel, confirm and reserve

	// test reserve
	Collection air = new ArrayList();
	Collection bus = new ArrayList();
	Collection hotel = new ArrayList();
	Collection packagetour = new ArrayList();
	//------------------------------air----------------------------------------------
	java.sql.Timestamp time = java.sql.Timestamp.valueOf("1899-30-12 6:30:00.000000000")   ;
	airlinesystem.BookSeatInfo bookSeatInfo = new airlinesystem.BookSeatInfo("2a4bf7a6-ffff-ffd3-0032-32749f92b2b4","MANEE","JAIDEE","KMITL","401625","TG100",0,2,0,1,time,false,4500);
	air.add(bookSeatInfo);
	java.sql.Timestamp time2 = java.sql.Timestamp.valueOf("1899-30-12 3:15:00.000000000")   ;
	airlinesystem.BookSeatInfo bookSeatInfo2 = new airlinesystem.BookSeatInfo("2b2b5338-ffff-ffd3-0072-21f635d183a2","SUTASINEE","LIEOPIROG","KMITL","3912724","TG100",0,2,0,1,time,false,4500);
	air.add(bookSeatInfo2);
//----------------------------air-----------------------------------------------------

//-----------------------------hotel--------------------------------------------------
	hotel.add(new hotelsystem.ReserveHotelInformation(new Date(1999, 10, 15), new Date(1999, 10, 18), "H0001", 201, "ROOM_DES1", 61, 71, 81, 91, 2));
	hotel.add(new hotelsystem.ReserveHotelInformation(new Date(1999, 10, 17), new Date(1999, 10, 18), "H0001", 202, "ROOM_DES2", 62, 72, 82, 92, 1));

//-----------------------------hotel--------------------------------------------------
//-----------------------------package--------------------------------------------
	packagetour.add(new PackageBookingInformation("PACKAGE_ID_1", Timestamp.valueOf("200-5-4 00:00:00.000000000"), "TRAVELLER_ID_1"));
	packagetour.add(new PackageBookingInformation("PACKAGE_ID_1", Timestamp.valueOf("200-5-4 00:00:00.000000000"), "TRAVELLER_ID_2"));



//-----------------------------package--------------------------------------------
//----------------------------bus-----------------------------------------------
//	ArrayList info = new ArrayList();
//	java.sql.Timestamp time = java.sql.Timestamp.valueOf("2001-04-17 12:00:00.000000000")   ;
//	// string in format of yyyy-mm-dd hh:mm:ss.fff
//	busservice.BookSeatInfo bookSeatInfo = new busservice.BookSeatInfo("","UTHAIRAT","DOGURAP","KMITL","7373000",1,1,1,1,time,600);
//	info.add(0,bookSeatInfo);
//	busservice.BookSeatInfo bookSeatInfo2 = new busservice.BookSeatInfo("","SUTASINEE","LIEOPIROG","KMITL","3912724",1,1,1,1,time,500);
//	info.add(1,bookSeatInfo2);
//
//	ArrayList bookSeatResults = client.BookSeat(info);
//
//	ListIterator iterator = bookSeatResults.listIterator(0);
//		 while (iterator.hasNext()) {
//		 BookSeatInfo item = (BookSeatInfo)iterator.next();
//
//		 System.out.println(item.getCustomerID() + " " +
//							item.getFirstName() + " " +
//							item.getLastName() + " " +
//							item.getTelephoneNo() + " " +
//							item.getRouteID() + " " +
//							item.getSrcIdx() + " " +
//							item.getDstIdx() + " " +
//							item.getSeatType()+ " " +
//							item.getDepartTime()+ " " +
//							item.getPrice() );
//			}
//-------------------------------bus------------------------------------------
//--------------------------------all-------------------------------------------------
//	FullBookingInformation info = new FullBookingInformation(bus, hotel, air, packagetour, "MEMBER_ID_1");
//	client.reserve(info);
//--------------------------------all-------------------------------------------------

	// TEST Cancel
	client.cancel("2d66fa6c-ffff-ffd3-006e-145b79b8175c");











  }
}