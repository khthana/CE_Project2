package olalatour;

import java.io.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullActivityInformation implements Serializable {

    public FullActivityInformation(String activityID, String activityName, String description, Collection places) {
	this.activityID = activityID;
	this.activityName = activityName;
	this.description = description;
	this.places = places;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getActivityID() {
	return activityID;
    }
    public String getActivityName() {
	return activityName;
    }
    public String getDescription() {
	return description;
    }
    public java.util.Collection getPlaces() {
	return places;
    }
    private String activityID;
    private String activityName;
    private String description;
    private java.util.Collection places;
}