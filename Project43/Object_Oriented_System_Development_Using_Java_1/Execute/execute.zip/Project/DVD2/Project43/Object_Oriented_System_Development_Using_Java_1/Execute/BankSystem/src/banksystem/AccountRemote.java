package banksystem;

import java.rmi.*;
import javax.ejb.*;

public interface AccountRemote extends EJBObject {

  public double getCredit() throws RemoteException;
  public String getAccountID()throws RemoteException;
  public double getBalance() throws RemoteException;
  public java.lang.String getAccountName() throws RemoteException;
  public void setAccountName(java.lang.String newAccountName) throws RemoteException;
  public void setPassword(java.lang.String oldPassword, java.lang.String newPassword) throws RemoteException;

  public void withdraw(double amount) throws  RemoteException;
  public void deposit(double amount ) throws  RemoteException;
  public void withdrawBycredit (double amount) throws  RemoteException;

  public java.lang.String getPassword() throws RemoteException;
  public java.lang.String getCreditCardID() throws RemoteException;
  public java.lang.String getDebitCardID() throws RemoteException;

}