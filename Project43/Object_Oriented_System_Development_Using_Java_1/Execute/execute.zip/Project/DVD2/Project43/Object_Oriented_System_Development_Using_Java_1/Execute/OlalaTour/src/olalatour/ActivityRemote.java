package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface ActivityRemote extends EJBObject {
    String getActivityId() throws RemoteException;
    String getActivityName() throws RemoteException;
    void setActivityName(String activityName) throws RemoteException;
    String getActivityDetail() throws RemoteException;
    void setActivityDetail(String activityDetail) throws RemoteException;
    Collection getPlaces() throws RemoteException;
}