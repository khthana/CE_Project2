package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface OlalaAgencyControllerRemote extends EJBObject {

	/** @todo modify */
	void modify(String bookingID, FullBookingInformation fullBookingInformation) throws RemoteException;

	/** @todo must be throws anything */
	String reserve(FullBookingInformation fullBookingInformation) throws RemoteException;
	// bookingID

	String createTraveller(String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String foodTypeId) throws RemoteException;
	// return travellerID
	String createMember(String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String password) throws RemoteException;
	// return memberID

	boolean confirm(String bookingID, String transactionID) throws RemoteException;
	boolean cancel(String bookingID) throws RemoteException;
}