package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface RoomHome extends EJBHome {
  public RoomRemote create(String roomNo, String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass, int floor) throws RemoteException, CreateException;
  public RoomRemote findByPrimaryKey(RoomPK primKey) throws RemoteException, FinderException;
  public Collection findByHotel(String hotelID) throws RemoteException, FinderException;
  public Collection findByHotelPricePerDayDescriptionNumberOfSingleBedNumberOfCoupleBedRoomClass(String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int roomClass) throws RemoteException, FinderException;
}