package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Member implements EntityBean {
    EntityContext entityContext;
    public String memberId;
    public String firstName;
    public String lastName;
    public String address;
    public String telephoneNo;
    public String emailAddress;
    public Integer gender;
    public Date birthDate;
    public String religion;
    public String password;
    public String hotelCustomerId;
    public String ejbCreate(String memberId, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String password, String hotelCustomerId) throws CreateException {
	this.memberId = memberId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.telephoneNo = telephoneNo;
	this.emailAddress = emailAddress;
	this.gender = gender;
	this.birthDate = birthDate;
	this.religion = religion;
	this.password = password;
	this.hotelCustomerId = hotelCustomerId;
	return null;
    }
    public String ejbCreate(String memberId) throws CreateException {
	return ejbCreate(memberId, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbPostCreate(String memberId, String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, Date birthDate, String religion, String password, String hotelCustomerId) throws CreateException {
    }
    public void ejbPostCreate(String memberId) throws CreateException {
	ejbPostCreate(memberId, null, null, null, null, null, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getMemberId() {
	return memberId;
    }
    public String getFirstName() {
	return firstName;
    }
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }
    public String getAddress() {
	return address;
    }
    public void setAddress(String address) {
	this.address = address;
    }
    public String getTelephoneNo() {
	return telephoneNo;
    }
    public void setTelephoneNo(String telephoneNo) {
	this.telephoneNo = telephoneNo;
    }
    public String getEmailAddress() {
	return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
    }
    public Integer getGender() {
	return gender;
    }
    public void setGender(Integer gender) {
	this.gender = gender;
    }
    public Date getBirthDate() {
	return birthDate;
    }
    public void setBirthDate(Date birthDate) {
	this.birthDate = birthDate;
    }
    public String getReligion() {
	return religion;
    }
    public void setReligion(String religion) {
	this.religion = religion;
    }
    public String getPassword() {
	return password;
    }
    public void setPassword(String password) {
	this.password = password;
    }
    public String getHotelCustomerId() {
	return hotelCustomerId;
    }
    public void setHotelCustomerId(String hotelCustomerId) {
	this.hotelCustomerId = hotelCustomerId;
    }
}