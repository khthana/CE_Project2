package busservice;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidIndexException extends Exception {

    public InvalidIndexException() {
    }
}