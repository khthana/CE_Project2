package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */


public class SeatRec implements java.io.Serializable {

                    String AirlineName;
                    String FlightID;
                    String AircraftName;
                    String ClassName;
                    java.sql.Timestamp DepartTime ;
                    java.sql.Timestamp ArriveTime;
                    int SrcIdx;
                    int DstIdx ;
                    int TotalDistance;
                    double Price;
                    String Description;


   public  SeatRec(String AirlineName, String FlightID, String AircraftName,String ClassName,java.sql.Timestamp DepartTime, java.sql.Timestamp  ArriveTime, int SrcIdx, int DstIdx, int TotalDistance, double Price, String Description) {

      this.AirlineName = AirlineName;
      this.FlightID = FlightID;
      this.AircraftName = AircraftName;
      this.ClassName = ClassName;
      this.DepartTime = DepartTime;
      this.ArriveTime =  ArriveTime;
      this.SrcIdx  = SrcIdx ;
      this.DstIdx  = DstIdx ;
      this.TotalDistance = TotalDistance;
      this.Price = Price;
      this.Description = Description;

   }

   public String getAirlineName() {
      return AirlineName;
   }

   public String getFlightID() {
      return FlightID;
   }
  public String getAircraftName() {
      return AircraftName;
   }
  public String getClassName() {
      return ClassName;
   }

   public java.sql.Timestamp getDepartTime() {
      return DepartTime;
   }

   public java.sql.Timestamp getArriveTime() {
      return ArriveTime;
   }

   public int getTotalDistance() {
      return TotalDistance;
   }

  public int getSrcIdx() {
      return SrcIdx;
   }
  public int getDstIdx() {
      return DstIdx;
   }
  public double getPrice() {
      return Price;
   }
 public String getDescription() {
      return Description;
   }

}
