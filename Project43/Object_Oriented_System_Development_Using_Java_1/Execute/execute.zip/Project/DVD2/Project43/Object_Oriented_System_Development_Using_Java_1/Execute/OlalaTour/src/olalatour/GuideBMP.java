package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class GuideBMP extends Guide {
    DataSource dataSource;
    public String ejbCreate(String guideId, String firstName, String lastName, Integer gender, String spokenLanguage, String officeAddress) throws CreateException {
	super.ejbCreate(guideId, firstName, lastName, gender, spokenLanguage, officeAddress);
	try {
	    //First see if the object already exists
	    ejbFindByPrimaryKey(guideId);
	    //If so, then we have to throw an exception
	    throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	    //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("INSERT INTO GUIDE (GUIDE_ID, FIRST_NAME, LAST_NAME, GENDER, SPOKEN_LANGUAGE, OFFICE_ADDRESS) VALUES (?, ?, ?, ?, ?, ?)");
	    statement.setString(1, guideId);
	    statement.setString(2, firstName);
	    statement.setString(3, lastName);
	    statement.setInt(4, gender.intValue());
	    statement.setString(5, spokenLanguage);
	    statement.setString(6, officeAddress);
	    if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return guideId;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL INSERT INTO GUIDE (GUIDE_ID, FIRST_NAME, LAST_NAME, GENDER, SPOKEN_LANGUAGE, OFFICE_ADDRESS) VALUES (?, ?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbCreate(String guideId) throws CreateException {
	return ejbCreate(guideId, null, null, null, null, null);
    }
    public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("DELETE FROM GUIDE WHERE GUIDE_ID = ?");
	    statement.setString(1, guideId);
	    if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL DELETE FROM GUIDE WHERE GUIDE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void ejbLoad() {
	guideId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT FIRST_NAME, LAST_NAME, GENDER, SPOKEN_LANGUAGE, OFFICE_ADDRESS FROM GUIDE WHERE GUIDE_ID = ?");
	    statement.setString(1, guideId);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    firstName = resultSet.getString(1);
	    lastName = resultSet.getString(2);
	    gender = new Integer(resultSet.getInt(3));
	    spokenLanguage = resultSet.getString(4);
	    officeAddress = resultSet.getString(5);
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT FIRST_NAME, LAST_NAME, GENDER, SPOKEN_LANGUAGE, OFFICE_ADDRESS FROM GUIDE WHERE GUIDE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
	super.ejbLoad();
    }
    public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("UPDATE GUIDE SET FIRST_NAME = ?, LAST_NAME = ?, GENDER = ?, SPOKEN_LANGUAGE = ?, OFFICE_ADDRESS = ? WHERE GUIDE_ID = ?");
	    statement.setString(1, firstName);
	    statement.setString(2, lastName);
	    statement.setInt(3, gender.intValue());
	    statement.setString(4, spokenLanguage);
	    statement.setString(5, officeAddress);
	    statement.setString(6, guideId);
	    if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL UPDATE GUIDE SET FIRST_NAME = ?, LAST_NAME = ?, GENDER = ?, SPOKEN_LANGUAGE = ?, OFFICE_ADDRESS = ? WHERE GUIDE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT GUIDE_ID FROM GUIDE WHERE GUIDE_ID = ?");
	    statement.setString(1, key);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return key;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT GUIDE_ID FROM GUIDE WHERE GUIDE_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT GUIDE_ID FROM GUIDE");
	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String guideId = resultSet.getString(1);
		keys.addElement(guideId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT GUIDE_ID FROM GUIDE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	    javax.naming.Context context = new javax.naming.InitialContext();
	    dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	    throw new EJBException("Error looking up dataSource:" + e.toString());
	}
    }
}