package hotelsystem;

import java.sql.Date;
import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ReserveHotelInformation implements Serializable {

  public ReserveHotelInformation(java.sql.Date bookCheckInTime, java.sql.Date bookCheckOutTime, String hotelID, double pricePerDay, String description, int numberOfSingleBed, int numberOfCoupleBed, int numberOfMaximumGuest, int roomClass, int numberOfRoom) {
	this.bookCheckInTime = bookCheckInTime;
	this.bookCheckOutTime = bookCheckOutTime;
	this.hotelID = hotelID;
	this.pricePerDay = pricePerDay;
	this.description = description;
	this.numberOfSingleBed = numberOfSingleBed;
	this.numberOfCoupleBed = numberOfCoupleBed;
	this.numberOfMaximumGuest = numberOfMaximumGuest;
	this.roomClass = roomClass;
	this.numberOfRoom = numberOfRoom;
  }
  private java.sql.Date bookCheckInTime;
  private java.sql.Date bookCheckOutTime;
  private String hotelID;
  private double pricePerDay;
  private String description;
  private int numberOfSingleBed;
  private int numberOfCoupleBed;
  private int numberOfMaximumGuest;
  private int roomClass;
  private int numberOfRoom;
  public java.sql.Date getBookCheckInTime() {
	return bookCheckInTime;
  }
  public java.sql.Date getBookCheckOutTime() {
	return bookCheckOutTime;
  }
  public String getHotelID() {
	return hotelID;
  }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    public double getPricePerDay() {
	return pricePerDay;
    }
    public String getDescription() {
	return description;
    }
    public int getNumberOfSingleBed() {
	return numberOfSingleBed;
    }
    public int getNumberOfCoupleBed() {
	return numberOfCoupleBed;
    }
    public int getNumberOfMaximumGuest() {
	return numberOfMaximumGuest;
    }
    public int getRoomClass() {
	return roomClass;
    }
    public int getNumberOfRoom() {
	return numberOfRoom;
    }
}