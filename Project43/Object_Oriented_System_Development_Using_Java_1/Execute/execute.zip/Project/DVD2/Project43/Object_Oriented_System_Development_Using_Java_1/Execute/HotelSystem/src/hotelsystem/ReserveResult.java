package hotelsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ReserveResult implements Serializable {

    public ReserveResult(String bookingID, double price) {
	this.bookingID = bookingID;
	this.price = price;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getBookingID() {
	return bookingID;
    }
    public double getPrice() {
	return price;
    }
    private String bookingID;
    private double price;
}