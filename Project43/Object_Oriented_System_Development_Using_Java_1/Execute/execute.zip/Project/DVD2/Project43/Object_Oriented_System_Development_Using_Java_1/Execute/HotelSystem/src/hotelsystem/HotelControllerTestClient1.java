package hotelsystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.sql.Date;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class HotelControllerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 250;
  private boolean logging = true;
  private HotelControllerHome hotelControllerHome = null;
  private HotelControllerRemote hotelControllerRemote = null;

  /**Construct the EJB test client*/
  public HotelControllerTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("hotelsystem/HotelController");

	  //cast to Home interface
	  hotelControllerHome = (HotelControllerHome) PortableRemoteObject.narrow(ref, HotelControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public HotelControllerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  hotelControllerRemote = hotelControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + hotelControllerRemote + ".");
	}
	return hotelControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public Collection findHotel(String name, String description, String address, int star) {
	Collection returnValue = null;
	if (hotelControllerRemote == null) {
	  System.out.println("Error in findHotel(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findHotel(" + name + ", " + description + ", " + address + ", " + star + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = hotelControllerRemote.findHotel(name, description, address, star);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findHotel(" + name + ", " + description + ", " + address + ", " + star + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findHotel(" + name + ", " + description + ", " + address + ", " + star + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findHotel(" + name + ", " + description + ", " + address + ", " + star + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection findRoom(String hotelID) {
	Collection returnValue = null;
	if (hotelControllerRemote == null) {
	  System.out.println("Error in findRoom(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling findRoom(" + hotelID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = hotelControllerRemote.findRoom(hotelID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: findRoom(" + hotelID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: findRoom(" + hotelID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from findRoom(" + hotelID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public FullHotelInformation viewHotel(String hotelID) {
	FullHotelInformation returnValue = null;
	if (hotelControllerRemote == null) {
	  System.out.println("Error in viewHotel(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewHotel(" + hotelID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = hotelControllerRemote.viewHotel(hotelID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewHotel(" + hotelID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewHotel(" + hotelID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewHotel(" + hotelID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public Collection viewBooking(String bookingID) {
	Collection returnValue = null;
	if (hotelControllerRemote == null) {
	  System.out.println("Error in viewBooking(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling viewBooking(" + bookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = hotelControllerRemote.viewBooking(bookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: viewBooking(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: viewBooking(" + bookingID + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from viewBooking(" + bookingID + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ReserveResult reserve(String customerID, Collection reserveHotelInformations) {
	ReserveResult returnValue = null;
	if (hotelControllerRemote == null) {
	  System.out.println("Error in reserve(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling reserve(" + customerID + ", " + reserveHotelInformations + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = hotelControllerRemote.reserve(customerID, reserveHotelInformations);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: reserve(" + customerID + ", " + reserveHotelInformations + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: reserve(" + customerID + ", " + reserveHotelInformations + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from reserve(" + customerID + ", " + reserveHotelInformations + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public void confirm(String bookingID) {
	if (hotelControllerRemote == null) {
	  System.out.println("Error in confirm(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling confirm(" + bookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  hotelControllerRemote.confirm(bookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: confirm(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: confirm(" + bookingID + ")");
	  }
	  e.printStackTrace();
	}
  }

  public void cancel(String bookingID) {
	if (hotelControllerRemote == null) {
	  System.out.println("Error in cancel(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling cancel(" + bookingID + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  hotelControllerRemote.cancel(bookingID);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: cancel(" + bookingID + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: cancel(" + bookingID + ")");
	  }
	  e.printStackTrace();
	}
  }

  public void modify(String bookingID, Collection reserveHotelInformations) {
	if (hotelControllerRemote == null) {
	  System.out.println("Error in modify(): " + ERROR_NULL_REMOTE);
	  return ;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling modify(" + bookingID + ", " + reserveHotelInformations + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  hotelControllerRemote.modify(bookingID, reserveHotelInformations);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: modify(" + bookingID + ", " + reserveHotelInformations + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: modify(" + bookingID + ", " + reserveHotelInformations + ")");
	  }
	  e.printStackTrace();
	}
  }

  public String createCustomer(String firstName, String lastName, String address, String telephoneNo, int gender) {
	String returnValue = "";
	if (hotelControllerRemote == null) {
	  System.out.println("Error in createCustomer(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling createCustomer(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + gender + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = hotelControllerRemote.createCustomer(firstName, lastName, address, telephoneNo, gender);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: createCustomer(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + gender + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: createCustomer(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + gender + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from createCustomer(" + firstName + ", " + lastName + ", " + address + ", " + telephoneNo + ", " + gender + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	HotelControllerTestClient1 client = new HotelControllerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.
	client.create();

	// test findHotel ok
//	Collection info = client.findHotel("", "", "", 51);
//	Iterator i = info.iterator();
//	while (i.hasNext()) {
//		ShortHotelInformation s = (ShortHotelInformation)i.next();
//		System.out.println("id : " + s.getHotelID() + " name : " + s.getHotelName());
//	}

	// test findRoom ok
//	Collection info2 = client.findRoom("H0001");
//	Iterator i2 = info2.iterator();
//	while (i2.hasNext()) {
//		FullRoomInformation s = (FullRoomInformation)i2.next();
//		System.out.println("couple : " + s.getNumberOfCoupleBed() + " des : " + s.getDescription());
//	}

	// test viewHotel
//	FullHotelInformation info3 = client.viewHotel("H0001");
//	System.out.println("" + info3.getHotelID() + "" + info3.getName());

	// test createCustomer
//	System.out.println(client.createCustomer("cname1", "clname1", "caddress1", "tel1", 1));

	// test reserve
	Collection reserveInfo = new ArrayList();
	reserveInfo.add(new ReserveHotelInformation(new Date(1999, 10, 15), new Date(1999, 10, 18), "H0001", 201, "ROOM_DES1", 61, 71, 81, 91, 2));
	reserveInfo.add(new ReserveHotelInformation(new Date(1999, 10, 17), new Date(1999, 10, 18), "H0001", 202, "ROOM_DES2", 62, 72, 82, 92, 1));
	ReserveResult info = client.reserve("29190afe-ffff-ffd3-006a-3cdf8f5facde", reserveInfo);
	System.out.println("id : " + info.getBookingID() + " price : " + info.getPrice());

	// test confirm
//	client.confirm("292ff1e2-ffff-ffd3-004e-229e3a03e475");

	// test cancel
//	client.cancel(info.getBookingID());


  }
}