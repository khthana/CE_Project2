package busservice;

import java.io.*;
import java.sql.Date;
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BookSeatInfo implements java.io.Serializable {

  private String CustomerID = null;
  private String FirstName = null;
  private String LastName= null;
  private String Address = null;
  private String TelephoneNo= null ;
  private int RouteID  ;
  private int SrcIdx ;
  private int DstIdx;
  private int SeatType;
  private java.sql.Timestamp DepartTime;
  private double Price;


  public BookSeatInfo(String CustomerID, String FirstName, String LastName,String Address,String TelephoneNo,  int RouteID,int SrcIdx, int DstIdx, int SeatType,java.sql.Timestamp DepartTime,double Price) {

	this.CustomerID = CustomerID;
	this.FirstName= FirstName;
	this.LastName= LastName;
	this.Address = Address;
	this.TelephoneNo = TelephoneNo;
	this.RouteID = RouteID;
	this.SrcIdx = SrcIdx;
	this.DstIdx = DstIdx;
	this.SeatType = SeatType;
	this.DepartTime = DepartTime;
	this.Price = Price;

  }


  public String getCustomerID() {
	return CustomerID;
  }

  public String getFirstName() {
	return FirstName;
  }

  public String getLastName() {
	return LastName;
  }

  public String getAddress() {
	return Address;
  }

  public String getTelephoneNo() {
	return TelephoneNo;
  }

  public int getRouteID() {
	return RouteID;
  }


  public int getSrcIdx() {
	return SrcIdx;
  }

  public int getDstIdx () {
	return DstIdx ;
  }

  public int getSeatType() {
	return SeatType;
  }

  public java.sql.Timestamp getDepartTime() {
	return DepartTime;
  }

  public double getPrice() {
	return Price;
  }
  public void setCustomerID(String newCustomerID) {
	CustomerID = newCustomerID;
  }


}