package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;
import java.sql.Date;

public interface HotelControllerRemote extends EJBObject {
  public Collection findHotel(String name, String description, String address, int star) throws RemoteException;
  // return Collection of ShortHotelInformation
  public Collection findRoom(String hotelID) throws RemoteException;
  // return Collection of FullRoomInformation
  public FullHotelInformation viewHotel(String hotelID) throws RemoteException;
  public Collection viewBooking(String bookingID) throws RemoteException;
  // return Collection of ReserveHotelInformation
  public ReserveResult reserve(String customerID, Collection reserveHotelInformations) throws RemoteException, InvalidBookingTimeException, InvalidHotelException, InvalidCustomerException, RoomNotAvailableException;
  // return bookingID, recieve Collection of ReserveHotelInformation
  public void confirm(String bookingID) throws RemoteException, AlreadyCancelException, DuplicateTransactionIDException, InvalidTransactionIDException;
  public void cancel(String bookingID) throws RemoteException, AlreadyConfirmException;
  public void modify(String bookingID, Collection reserveHotelInformations) throws RemoteException, InvalidBookingTimeException, InvalidRoomException, InvalidHotelException, InvalidCustomerException;
  // recieve Collection of ReserveHotelInformation
  public String createCustomer(String firstName, String lastName, String address, String telephoneNo, int gender) throws RemoteException, BlankFieldException, InvalidGenderException;
  // return CustomerID
}