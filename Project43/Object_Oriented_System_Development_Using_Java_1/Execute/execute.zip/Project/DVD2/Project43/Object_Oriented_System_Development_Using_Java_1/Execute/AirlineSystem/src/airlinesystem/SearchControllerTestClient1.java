package airlinesystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.ArrayList;
import java.util.*;

public class SearchControllerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 500;
  private boolean logging = true;
  private SearchControllerHome searchControllerHome = null;
  private SearchControllerRemote searchControllerRemote = null;

  /**Construct the EJB test client*/
  public SearchControllerTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("SearchController");

	  //cast to Home interface
	  searchControllerHome = (SearchControllerHome) PortableRemoteObject.narrow(ref, SearchControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public SearchControllerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  searchControllerRemote = searchControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + searchControllerRemote + ".");
	}
	return searchControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public ArrayList SearchAirline(String Keyword) {
	ArrayList returnValue = null;
	if (searchControllerRemote == null) {
	  System.out.println("Error in SearchAirline(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchAirline(" + Keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchControllerRemote.SearchAirline(Keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchAirline(" + Keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchAirline(" + Keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchAirline(" + Keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchAirport(String Keyword) {
	ArrayList returnValue = null;
	if (searchControllerRemote == null) {
	  System.out.println("Error in SearchAirport(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchAirport(" + Keyword + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchControllerRemote.SearchAirport(Keyword);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchAirport(" + Keyword + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchAirport(" + Keyword + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchAirport(" + Keyword + "): " + returnValue + ".");
	}
	return returnValue;
  }

  public ArrayList SearchSeat(String strSrcAirportID, String strDstStationID, int iTotalSeat, java.sql.Date  Date, int iAirlineID, int iClassType, int iSeatType, boolean blCanSmoking, boolean blNonStop, int iOrder) {
	ArrayList returnValue = null;
	if (searchControllerRemote == null) {
	  System.out.println("Error in SearchSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling SearchSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + iTotalSeat + ", " + Date + ", " + iAirlineID + ", " + iClassType + ", " + iSeatType + ", " + blCanSmoking + ", " + blNonStop + ", " + iOrder + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = searchControllerRemote.SearchSeat(strSrcAirportID, strDstStationID, iTotalSeat, Date, iAirlineID, iClassType, iSeatType, blCanSmoking, blNonStop, iOrder);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: SearchSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + iTotalSeat + ", " + Date + ", " + iAirlineID + ", " + iClassType + ", " + iSeatType + ", " + blCanSmoking + ", " + blNonStop + ", " + iOrder + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: SearchSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + iTotalSeat + ", " + Date + ", " + iAirlineID + ", " + iClassType + ", " + iSeatType + ", " + blCanSmoking + ", " + blNonStop + ", " + iOrder + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from SearchSeat(" + strSrcAirportID + ", " + strDstStationID + ", " + iTotalSeat + ", " + Date + ", " + iAirlineID + ", " + iClassType + ", " + iSeatType + ", " + blCanSmoking + ", " + blNonStop + ", " + iOrder + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	SearchControllerTestClient1 client = new SearchControllerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.

	client.create();

//    ----- Check search airport
//	ArrayList result = client.SearchAirport("");
//	 ListIterator iterator = result.listIterator(0);
//		 while (iterator.hasNext()) {
//		 AirportRec item = (AirportRec)iterator.next();
//		 System.out.println(item.getPlaceName() + " " +
//							item.getPlaceID() );
//			}



//-----Check search Airline
//	 ArrayList result = client.SearchAirline("");
//	 ListIterator iterator = result.listIterator(0);
//		 while (iterator.hasNext()) {
//		 AirlineRec item = (AirlineRec)iterator.next();
//		 System.out.println(item.getAirlineID() + " " +
//							item.getAirlineName() );
//			}


//----- Check search Seat

		java.sql.Date date = java.sql.Date.valueOf("2001-05-30");
		ArrayList SeatRecs = client.SearchSeat("BKK","CNX",3,date,0,0,0,false,false,0);

		 ListIterator iterator = SeatRecs.listIterator(0);
		 while (iterator.hasNext()) {
		 SeatRec item = (SeatRec)iterator.next();
		 System.out.println(
							item.getAirlineName()+ " " +
							item.getFlightID() + " " +
							item.getAircraftName() + " " +
							item.getClassName() + " " +
							item.getDepartTime() + " " +
							item.getArriveTime() + " " +
							item.getSrcIdx() + " " +
							item.getDstIdx() + " " +
							item.getTotalDistance() + " " +
							item.getPrice() + " " +
							item.getDescription());
			}
  }
}