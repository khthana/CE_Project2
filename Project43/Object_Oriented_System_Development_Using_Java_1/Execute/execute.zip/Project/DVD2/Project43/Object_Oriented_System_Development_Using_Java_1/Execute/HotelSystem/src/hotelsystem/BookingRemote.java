package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingRemote extends EJBObject {
    String getBookingId() throws RemoteException;
    Timestamp getBookingTime() throws RemoteException;
    void setBookingTime(Timestamp bookingTime) throws RemoteException;
    Integer getConfirm() throws RemoteException;
    void setConfirm(Integer confirm) throws RemoteException;
    Double getPrice() throws RemoteException;
    void setPrice(Double price) throws RemoteException;
    String getTransactionId() throws RemoteException;
    void setTransactionId(String transactionId) throws RemoteException;
    String getCustomerId() throws RemoteException;
    void setCustomerId(String customerId) throws RemoteException;
    public void confirm() throws RemoteException, InvalidTransactionIDException,
	DuplicateTransactionIDException, AlreadyCancelException;
    public void cancel() throws RemoteException, AlreadyConfirmException;
    public Collection getSubbookings() throws RemoteException;

}