<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<table width="750" border="1">
  <tr> 
    <td colspan="5"> 
      <font size="5"><b>HotPackage! </b></font></td>
  </tr>
  <tr> 
    <td colspan="5"> 
      <table width="100%" border="1">
        <tr> 
          <td width="115"> 
            <div align="center"><img src="images/Package01.jpg" width="110" height="75"></div>
          </td>
          <td width="370"><b><a href="PackageSearch.jsp">CLASSIC GOLDEN TRIANGLE 
            TOUR</a></b><br>
            Enjoy six days in the spectacular regions of North Thailand. Experience 
            all the highlights around Chiang Mai, then proceed further north to 
            Chiang Rai. From there visit the famous "Golden Triangle" and different 
            hill tribes Price <b>Range: starting at Thai Baht 11,950.- per person</b></td>
        </tr>
        <tr> 
          <td width="115"> 
            <div align="center"><img src="images/Package02.jpg" width="110" height="72"></div>
          </td>
          <td width="370"><b><a href="PackageSearch.jsp">15 DAYS AUSTRALIA AND 
            NEW ZEALAND ISLAND</a></b><br>
            This two week adventure features natural and cultural highlights of 
            Australia and New Zealand. Australia is a country of contrasts: the 
            British heritage, evident at the Parliament House and the Queen Victoria 
            Gardens, is a world away from the Aboriginal traditions and history 
            that you will experience at the Tjapukai Cultural Park<br>
            <b>$1,699.00</b></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<div align="right"></div>
</body>
</html>
