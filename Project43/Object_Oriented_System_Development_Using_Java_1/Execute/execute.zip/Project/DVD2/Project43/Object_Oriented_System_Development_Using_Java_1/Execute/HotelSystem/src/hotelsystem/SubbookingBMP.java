package hotelsystem;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class SubbookingBMP extends Subbooking {
	DataSource dataSource;
	public SubbookingPK ejbCreate(java.sql.Date bookCheckInTime, java.sql.Date bookCheckOutTime, String roomNo, String hotelId, String bookingId) throws CreateException {
	System.out.println("ejbCreate in SubbookingBMP");
	super.ejbCreate(bookCheckInTime, bookCheckOutTime, roomNo, hotelId, bookingId);
	try {
		//First see if the object already exists
		ejbFindByPrimaryKey(new hotelsystem.SubbookingPK(bookCheckInTime, roomNo, hotelId));
		//If so, then we have to throw an exception
		throw new DuplicateKeyException("Primary key already exists");
	}
	catch(FinderException e) {
		//Otherwise we can go ahead and create it...
	}
	System.out.println("Primary key's not already exists");

	if (!isBookable(bookCheckInTime, bookCheckOutTime, roomNo, hotelId)) {
		throw new CreateException("Room not availabel !!");
	}
	System.out.println("room available");

	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("INSERT INTO SUBBOOKING (BOOK_CHECK_IN_TIME, BOOK_CHECK_OUT_TIME, ROOM_NO, HOTEL_ID, BOOKING_ID) VALUES (?, ?, ?, ?, ?)");
		statement.setDate(1, bookCheckInTime);
		statement.setDate(2, bookCheckOutTime);
		statement.setString(3, roomNo);
		statement.setString(4, hotelId);
		statement.setString(5, bookingId);
		if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		System.out.println("end ejbCreate in SubbookingBMP");
		return new SubbookingPK(bookCheckInTime, roomNo, hotelId);
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL INSERT INTO SUBBOOKING (BOOK_CHECK_IN_TIME, BOOK_CHECK_OUT_TIME, ROOM_NO, HOTEL_ID, BOOKING_ID) VALUES (?, ?, ?, ?, ?): " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public SubbookingPK ejbCreate(java.sql.Date bookCheckInTime, String roomNo, String hotelId) throws CreateException {
	return ejbCreate(bookCheckInTime, null, roomNo, hotelId, null);
	}
	public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("DELETE FROM SUBBOOKING WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?");
		statement.setDate(1, bookCheckInTime);
		statement.setString(2, roomNo);
		statement.setString(3, hotelId);
		if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL DELETE FROM SUBBOOKING WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void ejbLoad() {
	SubbookingPK key = (SubbookingPK) entityContext.getPrimaryKey();
	bookCheckInTime = key.bookCheckInTime;
	roomNo = key.roomNo;
	hotelId = key.hotelId;
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOK_CHECK_OUT_TIME, BOOKING_ID FROM SUBBOOKING WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?");
		statement.setDate(1, bookCheckInTime);
		statement.setString(2, roomNo);
		statement.setString(3, hotelId);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
		}
		bookCheckOutTime = resultSet.getDate(1);
		bookingId = resultSet.getString(2);
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOK_CHECK_OUT_TIME, BOOKING_ID FROM SUBBOOKING WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	super.ejbLoad();
	}
	public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("UPDATE SUBBOOKING SET BOOK_CHECK_OUT_TIME = ?, BOOKING_ID = ? WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?");
		statement.setDate(1, bookCheckOutTime);
		statement.setString(2, bookingId);
		statement.setDate(3, bookCheckInTime);
		statement.setString(4, roomNo);
		statement.setString(5, hotelId);
		if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL UPDATE SUBBOOKING SET BOOK_CHECK_OUT_TIME = ?, BOOKING_ID = ? WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public SubbookingPK ejbFindByPrimaryKey(SubbookingPK key) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOK_CHECK_IN_TIME FROM SUBBOOKING WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?");
		statement.setDate(1, key.bookCheckInTime);
		statement.setString(2, key.roomNo);
		statement.setString(3, key.hotelId);
		ResultSet resultSet = statement.executeQuery();
		if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return key;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOK_CHECK_IN_TIME FROM SUBBOOKING WHERE BOOK_CHECK_IN_TIME = ? AND ROOM_NO = ? AND HOTEL_ID = ?: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindAll() throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOK_CHECK_IN_TIME, ROOM_NO, HOTEL_ID FROM SUBBOOKING");
		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		java.sql.Date bookCheckInTime = resultSet.getDate(1);
		String roomNo = resultSet.getString(2);
		String hotelId = resultSet.getString(3);
		keys.addElement(new SubbookingPK(bookCheckInTime, roomNo, hotelId));
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOK_CHECK_IN_TIME, ROOM_NO, HOTEL_ID FROM SUBBOOKING: " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public Collection ejbFindByBooking(String bookingID) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOK_CHECK_IN_TIME, ROOM_NO, HOTEL_ID FROM SUBBOOKING WHERE HOTEL_ID = ? ");
		statement.setString(1, bookingID);
		ResultSet resultSet = statement.executeQuery();
		Vector keys = new Vector();
		while (resultSet.next()) {
		java.sql.Date bookCheckInTime = resultSet.getDate(1);
		String roomNo = resultSet.getString(2);
		String hotelId = resultSet.getString(3);
		keys.addElement(new SubbookingPK(bookCheckInTime, roomNo, hotelId));
		}
		statement.close();
		statement = null;
		connection.close();
		connection = null;
		return keys;
	}
	catch(SQLException e) {
		throw new EJBException("Error executing SQL SELECT BOOK_CHECK_IN_TIME, ROOM_NO, HOTEL_ID FROM SUBBOOKING where booking = ? : " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
	public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
		javax.naming.Context context = new javax.naming.InitialContext();
		dataSource = (DataSource) context.lookup("java:comp/env/jdbc/HotelDB");
	}
	catch(Exception e) {
		throw new EJBException("Error looking up dataSource:" + e.toString());
	}
	}
	protected boolean isBookable(java.sql.Date bookCheckInTime, java.sql.Date bookCheckOutTime, String roomNo, String hotelId) {
	System.out.println("begin isBookable");
	Connection connection = null;
	PreparedStatement statement = null;
	try {
		connection = dataSource.getConnection();
		statement = connection.prepareStatement("SELECT BOOK_CHECK_IN_TIME, ROOM_NO, HOTEL_ID FROM SUBBOOKING where ROOM_NO = ? AND HOTEL_ID = ? AND ((BOOK_CHECK_IN_TIME < ? AND BOOK_CHECK_OUT_TIME > ? )OR(BOOK_CHECK_IN_TIME < ? AND BOOK_CHECK_OUT_TIME > ? ))");
		System.out.println("prepare");
		statement.setString(1, roomNo);
		statement.setString(2, hotelId);
		statement.setDate(3, bookCheckInTime);
		statement.setDate(4, bookCheckInTime);
		statement.setDate(5, bookCheckOutTime);
		statement.setDate(6, bookCheckOutTime);

		ResultSet resultSet = statement.executeQuery();
		System.out.println("execute");
		boolean result = resultSet.next();
		System.out.println("next : " + result);
		statement.close();
		System.out.println("close");
		statement = null;
		System.out.println("stmt null");
		connection.close();
		System.out.println("con close");
		connection = null;
		System.out.println("con null");

		if (result) {
		System.out.println("end isBookable cannot book");
		return false;
		}
		else {
		System.out.println("end isBookable can book");
		return true;
		}
	}
	catch(SQLException e) {
		throw new EJBException("SELECT BOOK_CHECK_IN_TIME, ROOM_NO, HOTEL_ID FROM SUBBOOKING where ROOM_NO = ? AND HOTEL_ID = ? AND ((BOOK_CHECK_IN_TIME < ? AND BOOK_CHECK_OUT_TIME > ? )OR(BOOK_CHECK_IN_TIME < ? AND BOOK_CHECK_OUT_TIME > ? )OR(BOOK_CHECK_IN_TIME < ? AND BOOK_CHECK_OUT_TIME > ?  " + e.toString());
	}
	finally {
		try {
		if (statement != null) {
			statement.close();
		}
		}
		catch(SQLException e) {
		}
		try {
		if (connection != null) {
			connection.close();
		}
		}
		catch(SQLException e) {
		}
	}
	}
}