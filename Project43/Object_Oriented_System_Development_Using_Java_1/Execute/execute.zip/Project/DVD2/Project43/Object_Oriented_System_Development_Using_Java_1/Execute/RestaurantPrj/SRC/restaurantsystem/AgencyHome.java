package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface AgencyHome extends EJBHome {
  public AgencyRemote create(String agencyID, String name, String address, String telephoneNo) throws RemoteException, CreateException;
  public AgencyRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
  public Collection findByNameAddress(String name, String address) throws RemoteException, FinderException;
}