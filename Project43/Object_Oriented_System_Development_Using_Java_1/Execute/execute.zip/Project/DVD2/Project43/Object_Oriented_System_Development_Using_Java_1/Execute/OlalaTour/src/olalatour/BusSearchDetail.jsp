<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF">
<table width="700" border="1">
  <tr>
    <td height="50"> 
      <table width="100%" border="1" height="50">
        <tr> 
          <td height="45" width="25%"><b><font size="5">OLALA TOUR</font></b></td>
          <td height="45" width="75%"><font size="4">BUS DETAIL</font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="50">
      <table width="500%" border="1" height="50">
        <tr> 
          <td width="36%"> 
            <form method="post" action="">
              Search 
              <input type="text" name="textfield">
              <input type="submit" name="Submit" value="GO">
            </form>
          </td>
          <td width="64%">
            <table width="100%" border="1" height="100%">
              <tr> 
                <td width="70%"> 
                  <div align="right"></div>
                </td>
                <td width="16%"> 
                  <div align="center"><img src="photocart2.jpg" width="26" height="19"><br>
                    <a href="Cart.htm">ViewCart</a> </div>
                </td>
                <td width="14%"> 
                  <div align="center"><img src="home.gif" width="20" height="20"><br>
                    <a href="olalatour.htm">Home </a></div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="30"> 
      <table width="100%" border="1" height="30">
        <tr> 
          <td width="16%">Airline Booking</td>
          <td width="13%">Bus Booking</td>
          <td width="15%">Hotel Booking</td>
          <td width="18%">Package Booking</td>
          <td width="16%">LocationSearch </td>
          <td colspan="2" width="22%">Place&amp;ActivitySearch</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>
      <table width="100%" border="1">
        <tr> 
          <td colspan="3"> 
            <div align="center"><img src="logowebring.jpg" width="55" height="54"></div>
          </td>
        </tr>
        <tr> 
          <td><b>ROUTE:</b> </td>
          <td colspan="2">					
			<%=request.getParameter("strRouteID")%> 
	 </td>
        </tr>
        <tr> 
          <td><b>BUS CLASS :</b></td>
          <td colspan="2">
			<%=request.getParameter("strBusClass")%> 
  	  </td>
        </tr>
        <tr> 
          <td><b>DEPART :</b> </td>
          <td>	 <%=request.getParameter("strSource")%></td>
          <td>	<%=request.getParameter("strDepartTime")%> </td>
        </tr>
        <tr> 
          <td><b>ARRIVE :</b> </td>
          <td>	 <%=request.getParameter("strDescinate")%></td>
          <td>	<%=request.getParameter("strArriveTime")%> </td>
        </tr>
        <tr> 
          <td><b>TRAVEL TIME :</b></td>
          <td colspan="2">
	  </td>
        </tr>
        <tr> 
          <td><b>COMPANY :</b></td>
          <td colspan="2">
		 <%=request.getParameter("strCompanyName")%>
	   </td>
        </tr>		
        <tr> 
          <td> 
            <div align="left"><b>PRICE/SEAT :</b></div>
          </td>
  	  <td colspan="2">
		<%=request.getParameter(" strPrice")%>
	  </td>
        </tr>
        <tr> 
          <td colspan="3"> 
            <div align="center"><a href="Cart.htm">Add To Cart </a></div>
            </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
