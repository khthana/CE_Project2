package airlinesystem;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.util.ArrayList;
import java.util.*;

public class ReserveControllerTestClient1 {
  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 50;
  private boolean logging = true;
  private ReserveControllerHome reserveControllerHome = null;
  private ReserveControllerRemote reserveControllerRemote = null;

  /**Construct the EJB test client*/
  public ReserveControllerTestClient1() {
	long startTime = 0;
	if (logging) {
	  log("Initializing bean access.");
	  startTime = System.currentTimeMillis();
	}

	try {
	  //get naming context
	  Context ctx = new InitialContext();

	  //look up jndi name
	  Object ref = ctx.lookup("ReserveController");

	  //cast to Home interface
	  reserveControllerHome = (ReserveControllerHome) PortableRemoteObject.narrow(ref, ReserveControllerHome.class);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded initializing bean access.");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed initializing bean access.");
	  }
	  e.printStackTrace();
	}
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public ReserveControllerRemote create() {
	long startTime = 0;
	if (logging) {
	  log("Calling create()");
	  startTime = System.currentTimeMillis();
	}
	try {
	  reserveControllerRemote = reserveControllerHome.create();
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: create()");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: create()");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from create(): " + reserveControllerRemote + ".");
	}
	return reserveControllerRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public ArrayList BookSeat(ArrayList info) {
	ArrayList returnValue = null;
	if (reserveControllerRemote == null) {
	  System.out.println("Error in BookSeat(): " + ERROR_NULL_REMOTE);
	  return returnValue;
	}
	long startTime = 0;
	if (logging) {
	  log("Calling BookSeat(" + info + ")");
	  startTime = System.currentTimeMillis();
	}

	try {
	  returnValue = reserveControllerRemote.BookSeat(info);
	  if (logging) {
		long endTime = System.currentTimeMillis();
		log("Succeeded: BookSeat(" + info + ")");
		log("Execution time: " + (endTime - startTime) + " ms.");
	  }
	}
	catch(Exception e) {
	  if (logging) {
		log("Failed: BookSeat(" + info + ")");
	  }
	  e.printStackTrace();
	}

	if (logging) {
	  log("Return value from BookSeat(" + info + "): " + returnValue + ".");
	}
	return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
	if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
	  System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
	}
	else {
	  System.out.println("-- " + message);
	}
  }
  /**Main method*/

  public static void main(String[] args) {
	ReserveControllerTestClient1 client = new ReserveControllerTestClient1();
	// Use the client object to call one of the Home interface wrappers
	// above, to create a Remote interface reference to the bean.
	// If the return value is of the Remote interface type, you can use it
	// to access the remote interface methods.  You can also just use the
	// client object to call the Remote interface wrappers.
	client.create();


//Thai Airways International TG100 BOING 737 FIRST CLASS 1899-12-30 06:30:00.0 1899-12-30 07:40:00.0 1 1 750 4250.0 null
//Thai Airways International TG114 BOING 737 FIRST CLASS 1899-12-30 15:15:00.0 1899-12-30 16:25:00.0 1 1 750 4250.0 null




	ArrayList info = new ArrayList();
	java.sql.Timestamp time = java.sql.Timestamp.valueOf("1899-30-12 6:30:00.000000000")   ;

	BookSeatInfo bookSeatInfo = new BookSeatInfo("{4B7FF6A1-33A6-451A-B7FF-814DA4BB7824}","","","","","TG100",1,1,0,0,time,false,4250);
	info.add(0,bookSeatInfo);
	java.sql.Timestamp time2 = java.sql.Timestamp.valueOf("1899-30-12 3:15:00.000000000")   ;
	BookSeatInfo bookSeatInfo2 = new BookSeatInfo("{68B9B663-D857-4D68-82BF-FC054829B4D5}","","","","","TG114",1,1,0,0,time,false,4250);
	info.add(1,bookSeatInfo2);

	ArrayList bookSeatResults = client.BookSeat(info);

	ListIterator iterator = bookSeatResults.listIterator(0);
		 while (iterator.hasNext()) {
		 BookSeatResult item = (BookSeatResult)iterator.next();


		 System.out.println(item.getCustomerID() + " " +
							item.getBookingID() + " " +
							item.getSeatNo() + " " +
							item.getPrice() );
			}

//    ArrayList bookResult = client.BookSeat(info);

  }
}