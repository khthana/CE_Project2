package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AirlineRec implements java.io.Serializable {
  int AirlineID;
  String AirlineName ;

  public  AirlineRec(int AirlineID, String AirlineName) {

      this.AirlineID = AirlineID;
      this.AirlineName = AirlineName;
   }

   public int getAirlineID() {
      return AirlineID;
   }

   public String getAirlineName() {
     return AirlineName;
   }

}