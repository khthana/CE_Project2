package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface AdminRemote extends EJBObject {
    String getAdminId() throws RemoteException;
    String getLoginName() throws RemoteException;
    void setLoginName(String loginName) throws RemoteException;
    String getFirstName() throws RemoteException;
    void setFirstName(String firstName) throws RemoteException;
    String getLastName() throws RemoteException;
    void setLastName(String lastName) throws RemoteException;
    String getAddress() throws RemoteException;
    void setAddress(String address) throws RemoteException;
    String getTelephoneNo() throws RemoteException;
    void setTelephoneNo(String telephoneNo) throws RemoteException;
    String getEmailAddress() throws RemoteException;
    void setEmailAddress(String emailAddress) throws RemoteException;
    Integer getGender() throws RemoteException;
    void setGender(Integer gender) throws RemoteException;
    Date getBirthDate() throws RemoteException;
    void setBirthDate(Date birthDate) throws RemoteException;
    String getReligion() throws RemoteException;
    void setReligion(String religion) throws RemoteException;
    String getPassword() throws RemoteException;
    void setPassword(String password) throws RemoteException;
}