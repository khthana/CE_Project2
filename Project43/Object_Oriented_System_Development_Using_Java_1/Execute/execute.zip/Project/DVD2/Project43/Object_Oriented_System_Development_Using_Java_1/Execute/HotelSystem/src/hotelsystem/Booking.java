package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.sql.*;
import javax.sql.DataSource;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Booking implements EntityBean {
    EntityContext entityContext;
    public String bookingId;
    public Timestamp bookingTime;
    public Integer confirm;
    public Double price;
    public String transactionId;
    public String customerId;
    public String ejbCreate(String bookingId, Timestamp bookingTime, Integer confirm, Double price, String transactionId, String customerId) throws CreateException {
	this.bookingId = bookingId;
	this.bookingTime = bookingTime;
	this.confirm = confirm;
	this.price = price;
	this.transactionId = transactionId;
	this.customerId = customerId;
	return null;
    }
    public void ejbPostCreate(String bookingId, Timestamp bookingTime, Integer confirm, Double price, String transactionId, String customerId) throws CreateException {
    }
    public String ejbCreate(String bookingId) throws CreateException {
	return ejbCreate(bookingId, null, null, null, null, null);
    }
    public void ejbPostCreate(String bookingId) throws CreateException {
	ejbPostCreate(bookingId, null, null, null, null, null);
    }
    public String ejbCreate(String bookingId, String customerId) throws CreateException {
	System.out.println("create in booking11");
	return ejbCreate(bookingId, null, null, null, null, customerId);
    }
    public void ejbPostCreate(String bookingId, String customerId) throws CreateException {
	ejbPostCreate(bookingId, null, null, null, null, customerId);
    }
    public void ejbRemove() throws RemoveException {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void ejbLoad() {
    }
    public void ejbStore() {
    }
    public void setEntityContext(EntityContext entityContext) {
	this.entityContext = entityContext;
    }
    public void unsetEntityContext() {
	entityContext = null;
    }
    public String getBookingId() {
	return bookingId;
    }
    public Timestamp getBookingTime() {
	return bookingTime;
    }
    public void setBookingTime(Timestamp bookingTime) {
	this.bookingTime = bookingTime;
    }
    public Integer getConfirm() {
	return confirm;
    }
    public void setConfirm(Integer confirm) {
	this.confirm = confirm;
    }
    public Double getPrice() {
	return price;
    }
    public void setPrice(Double price) {
	this.price = price;
    }
    public String getTransactionId() {
	return transactionId;
    }
    public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
    }
    public String getCustomerId() {
	return customerId;
    }
    public void setCustomerId(String customerId) {
	this.customerId = customerId;
    }
  public void confirm() throws InvalidTransactionIDException, DuplicateTransactionIDException, AlreadyCancelException {
    if (confirm.intValue() == 2) {
      throw new AlreadyCancelException();
    }
    else {
      confirm = new Integer(1);
    }
  }
  public void cancel() throws AlreadyConfirmException {
    if (confirm.intValue() == 1) {
      throw new AlreadyConfirmException();
    }
    else {
      confirm = new Integer(2);
    }
  }
  public Collection getSubbookings() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("hotelsystem/Subbooking");

	  SubbookingHome home = (SubbookingHome)PortableRemoteObject.narrow(objref, SubbookingHome.class);

	  Collection subbookings = home.findByBooking(bookingId);

	  return subbookings;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }

}