package hotelsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class RoomPK implements Serializable {

  public RoomPK(String roomNo, String hotelID) {
    this.roomNo = roomNo;
    this.hotelID = hotelID;
  }
  public String roomNo;
  public String hotelID;

  public String getRoomNo() {
    return roomNo;
  }
  public String getHotelID() {
    return hotelID;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
  public boolean equals(Object other) {
    if (other instanceof RoomPK) {
	return (roomNo.equals(((RoomPK)other).roomNo) && hotelID.equals(((RoomPK)other).hotelID));
    }
    return false;
  }
  public int hashCode() {
    return roomNo.hashCode() + hotelID.hashCode();
  }
}