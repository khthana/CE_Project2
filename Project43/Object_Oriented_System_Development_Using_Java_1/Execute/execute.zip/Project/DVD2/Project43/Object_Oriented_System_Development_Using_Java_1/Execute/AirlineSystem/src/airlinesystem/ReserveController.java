package airlinesystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.io.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.*;
import java.math.*;
import java.awt.*;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ReserveController implements SessionBean {
  private SessionContext sessionContext;
  public ArrayList BookSeatResultRecord;
  Connection con ;
  PreparedStatement pstmt ;
  BookSeatResult bookSeatResult;
  private String dbName = "java:comp/env/jdbc/AirlineDB";


// ##### MAKE GUID
  protected String getNewBookingID() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("airlinesystem/UUIDGenerator");

	  UUIDGeneratorHome home = (UUIDGeneratorHome)PortableRemoteObject.narrow(objref, UUIDGeneratorHome.class);
	  UUIDGeneratorRemote uuidGenerator = home.create();

	  return uuidGenerator.getUUID();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
  }

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@   BUSINESS METHOD   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

public String CreateCustomer( String strFirstName ,String strLastName,String  strAddress, String strTelephoneNo) throws CreateException, RemoteException {

String strCommand;
String strCustomerID;
String sqlResult;

strCustomerID = getNewBookingID(); // make new customerID


				 strCommand = "INSERT INTO CUSTOMER VALUES ('" + strCustomerID + "', '" +
												  strFirstName + "', '" +
												  strLastName + "', '" +
												  strAddress + "','" +
												  strTelephoneNo + "')" ;

 System.out.println("**** Insert into Customer as new Customer  ****");

  try
  {
	pstmt = con.prepareStatement(strCommand);
	pstmt.executeUpdate();
	pstmt.close();
   System.out.println("**** Update success ****");

  }
  catch(java.sql.SQLException e)
  {
	throw new EJBException ("[AirlineService,Reserve]  Can not create Customer.\n" + "Command : "  + strCommand  + "\n" + e.getMessage());
  }

  return  strCustomerID;
}  // End method


//***************************************************************   BOOK SEAT METHOD *******************************************************************
public ArrayList BookSeat(ArrayList info) throws RemoteException , ReservationErrorException ,SeatNotAvailableException, InvalidRouteIDException  , CustomerIDNotExistException {

System.out.println("******* BookSeat Method call *******");

	String strSqlResult;
	String strCommand ;
	String strCustomerID;
	String strCustomerBooking;
	ArrayList result = new ArrayList();

	 String strSeatNo;
	 String strBookingID = null;

	 strBookingID = getNewBookingID();  // *** Create new BookingID
	 System.out.println("***** Create BookingID is :" + strBookingID +" *******");


   System.out.println(" While loop to check for all detail in each seat reservation and insert into table");

   ListIterator iterator = info.listIterator(0); // info is an ArrayList input
   int index = 0;

   while (iterator.hasNext()) {  // Loop for all customer booking,1 booingID
		 BookSeatInfo bookSeatInfo = (BookSeatInfo)iterator.next();

		 String CustomerID = bookSeatInfo.getCustomerID() ;
		 System.out.println(" CustomerID is :" + CustomerID +"*******");

		 if (CustomerID == null || CustomerID.equals(""))
		 {
				 throw new CustomerIDNotExistException(" Do not have CustomerID : Try to creat new one ");
		 }
		else {     // customerID != null,Exit in bookSeatInfo
		strCustomerID = bookSeatInfo.getCustomerID();
		System.out.println("**** CustomerID not null : "+ strCustomerID+" ****");
		}

 //************************************** Finish Book Customer *************************************************

//******************************* Start to Book in CustomerBooking *****************************************

				String strCustomerBookingID = getNewBookingID(); // make new customerBookingID
				System.out.println(" Create new CustomerBookingID : " +strCustomerBookingID);

				int iRouteID;
				int iSrcIdx;
				int iDstIdx;
				String strFlightID;
				String strSelectedSeatType;

				java.sql.Timestamp dtDepartTime; // String strDepartDate ;
				String strSelectedClassType;
				String strCanBeSmoked;
				double curPrice ;


				  if (bookSeatInfo.getFlightID().equals(""))  { // 0 = null or not Exit
				  throw new ReservationErrorException("Some record not have RouteID");
				  }
				  else strFlightID = bookSeatInfo.getFlightID();
				  System.out.println("**** FlightID : "+ strFlightID +" ****");

				  if (bookSeatInfo.getSrcIdx() < 0)  { // if not have set to 0
				  throw new ReservationErrorException( "Some record  have Incvalid Source Index");
				  }
				  else iSrcIdx = bookSeatInfo.getSrcIdx();
				   System.out.println("**** source index : "+ iSrcIdx+ "****");

				  if (bookSeatInfo.getDstIdx() < 0)  { // if not have >> set to 0
				  throw new ReservationErrorException("Some record  have Invalid Destination Index");
				  }
				  else iDstIdx = bookSeatInfo.getDstIdx();
				   System.out.println("**** destination index : "+ iDstIdx+ "****");

				  if (bookSeatInfo.getDepartTime() == null)  {
				  throw new ReservationErrorException("Some record not have DepartTime");
				  }
				  else dtDepartTime = bookSeatInfo.getDepartTime();
				   System.out.println("****depart time : "+ dtDepartTime+" ****");

				  if (bookSeatInfo.getSeatType() < 0)  { // if user do not input in this field >> set
				  throw new ReservationErrorException("Some record not have Type of Seat");
				  }
				  else {
				   switch  (bookSeatInfo.getSeatType())  {
					case (0) :
					strSelectedSeatType = "";
					break;
					case (1) :
					strSelectedSeatType = " AND T1.Aisle = 0 ";
					break;
					case (2) :
					strSelectedSeatType = " AND T1.Window = 0 ";
					break;
					default :
					strSelectedSeatType = "";
					}
				  }// end else

				  if (bookSeatInfo.getPrice() <= 0)  {
				  throw new ReservationErrorException("Some record not have Price or Invalid Price");
				  }
				  else curPrice = bookSeatInfo.getPrice();
				   System.out.println("**** price : "+ curPrice+ "****");


				  if (bookSeatInfo.getClassType() < 0)  { // if not fill >> set = 0
				  throw new ReservationErrorException("Some record not have class of aircraft");
				  }
				  else {

					switch  (bookSeatInfo.getClassType())  {
					case (1) :  // First Class
					strSelectedClassType = " AND T1.ClassID =  1 ";
					break;
					case (2) :  // Business Class
				   strSelectedClassType = " AND T1.ClassID =  2  ";
					break;
					case (3) :  // Economic Class
					strSelectedClassType = " AND T1.ClassID =  3 ";
					break;

					default :
					strSelectedClassType = "";
					}
				  }// end else

//                  if (bookSeatInfo.getCanSmoking() == null)  {
//                  throw new RemoteException("Some record not have information about select smoking seat.");
//                  }
//                  else {
					if (bookSeatInfo.getCanSmoking() == true){
						strCanBeSmoked = " AND T1.Smoking = 0 "; // sit in  smoke area
					}
					else strCanBeSmoked = "" ; // can sit in any position
//                    }

				String SeatNo = null;

				System.out.println(" Generate sql command to find SeatNo");

				strCommand = "SELECT     T1.SeatNo " +
											  "FROM       Seat T1, " +
											  "           Flight T2 " +
											  "WHERE      T2.FlightID = '" + strFlightID + "' " +
											  "           AND T2.AircraftID = T1.AircraftID " +
											  strSelectedSeatType +
											  strSelectedClassType +
											  strCanBeSmoked +
											  "           AND T1.SeatNo NOT IN ( " +
											  "SELECT     DISTINCT T3.SeatNo " +
											  "FROM       SubRouteBooking T3, " +
											  "           FlightSubRoute T4 " +
											  "WHERE      T3.DepartDate = '" + dtDepartTime + "' " +
											  "                       AND T3.FlightID = '" + strFlightID + "' " +
											  "                       AND T3.FlightID = T4.FlightID " +
											  "                       AND T3.SubRouteID = T4.SubRouteID "  +
											  "                       AND T4.Idx >= " + iSrcIdx + " " +
											  "                       AND T4.Idx <= " + iDstIdx + " ) " +
											  "ORDER BY T1.SeatNo " ;




  //T3.DepartDate is change to Timestamp (strDepartDate = original) but in table is java.sql.Date
  System.out.println("**** Execute Select SeatNo ****");

 try
  {
	pstmt = con.prepareStatement(strCommand);
	System.out.println("**** After prepareStatement  ****");

	ResultSet rs = pstmt.executeQuery();
	  System.out.println("**** After Execute Query ****");

	int count = 0 ;
	if (rs.next() ){
		SeatNo = rs.getString(1);         // get SeatNo from select >> Stop need only one seat
		count++;                         // increase index of array
	} // close if

	   pstmt.close();

	 System.out.println("**** Get the first seatNo that return  : "+  SeatNo +  " ****");

	if ((count ==0) ||(SeatNo == null)) {
		throw new SeatNotAvailableException("Can not find seat that can book.");
	}
	else {
		// get the first seatNo that can find
		strSeatNo = SeatNo;
		// set in ArrayList to return from this booking (Reservation)

		System.out.println("***** BookSeatResult is " + strCustomerID+" " + strBookingID + " " + strSeatNo + " " +curPrice);
		BookSeatResult bookSeatResult = new BookSeatResult(strCustomerID, strBookingID,strSeatNo,curPrice );
		result.add(index,bookSeatResult);
		}

}// end try
catch(java.sql.SQLException e)
  {e.printStackTrace();
	throw new EJBException("Internal error : Can not execute sql command to find seat.");
  }

// ************************************** Start Book in subRouteBooking *****************************************

				System.out.println("**** Start Book in subRouteBooking : Generate sql command to find all subroute****");



				strCommand = "SELECT    T1.SubRouteID " +
											  "FROM     FlightSubRoute T1 " +
											  "WHERE    T1.FlightID = '" + strFlightID + "' " +
											  "         AND T1.Idx >=  " + iSrcIdx +
											  "         AND T1.Idx <= " + iDstIdx ;


			   System.out.println("**** Select all subroute ****");

try  {
	pstmt = con.prepareStatement (strCommand);
	System.out.println(" ***** After prepareStatement of find subRoute****");
	ResultSet rs = pstmt.executeQuery();
	System.out.println(" *** Execute is successful****");

	int SubRouteID;
	int count = 0 ;
	int tempRouteID[] =new int[100];  // if nothing = 0

 while (  rs.next() ) {
		SubRouteID = rs.getInt(1);
		tempRouteID[count] = SubRouteID;

		System.out.println("****** SubrouteID in array :  "+tempRouteID[count]+"************");

		count++;
		} // end while

		pstmt.close();

	if (count == 0) {
		throw new ReservationErrorException("No available subroute that can Book.");
	  }
	else {  // ********* Loop for inSert in SubRouteBooking

	System.out.println(" ** Count !=0 >> insert data to subRouteBooking**");

	  int iSubRouteID;
	  int i = 0;

	  while (i < count) {           // arraySize = count-1
		SubRouteID = tempRouteID[i];

		if  (SubRouteID == 0) {       // or = null
			throw new InvalidRouteIDException("Internal operation error :  SubRouteID have null value from search availble SubRoute.");
			} // end if
		else iSubRouteID = SubRouteID;

		 System.out.println("***** Field in SubRouteBooking :"+ dtDepartTime + " " + strFlightID + " " + iSubRouteID + " " + strSeatNo + " " + strCustomerBookingID);

		  // Book all subRoute in SubRouteBooking
		  // Change strDepartDate to dtDepartDate
						strCommand = "INSERT INTO   SubRouteBooking " +
													  "VALUES  ( '" + dtDepartTime + "', " +
													  "'" + strFlightID + "', " +
													  iSubRouteID + ", " +
													  "'" + strSeatNo + "', " +
													  "'" + strCustomerBookingID + "' ) " ;

		try {
			pstmt = con.prepareStatement(strCommand);

		pstmt.executeUpdate();
		pstmt.close();
			System.out.println(" Insert into subRouteBooking is successful");

		  }// end try
		catch(java.sql.SQLException e)
			{
			throw new EJBException("Internal operation error : Fail to add information into SubRouteBooking table.");
			}

		  i++;  // increase for get subRoute ID in the next array

		} // end else insert subroute

	  } // end while

	}   // End Try

  catch(java.sql.SQLException e)
  {
  throw new EJBException("Internal operation error : Can not execute sql command to search subroute.");
  }

//***************************** Finish Book in SubRouteBooking For 1 Seat(1 CustomerBooking) ************************************

//***************************** Start to Book in CustomerBooking ******************************************

			System.out.println(" ** Generate command to insert to CustomerBooking**");
			 strCommand = "INSERT INTO   CustomerBooking  " +
						  "VALUES                ( '" + strCustomerBookingID + "', " +
						  "'" + strBookingID + "', " +
						  "'" + strCustomerID + "', " +
								curPrice + " ) ";


			System.out.println("***** Field in CustomerBooking : "+strCustomerBookingID+" " +strBookingID+" " +strCustomerID+" " + curPrice);
			try {
			pstmt = con.prepareStatement(strCommand);

		pstmt.executeUpdate();
		pstmt.close();
			System.out.println(" ** Insert into successful ***");
			}
			catch(java.sql.SQLException e)
			{
			 throw new EJBException("Internal Operaion error : Can not add information into CustomerBooking table.");
			}

			index++; // increase for number of index in array of result
			System.out.println(" Increase index of array and back to while loop ");

} // End While Loop of get Object from bookSeatInfo ArrayList

/***************************************** Combine into 1 Booking **************************************************/

			String transactionID = getNewBookingID();
			java.sql.Timestamp txDate = new java.sql.Timestamp(System.currentTimeMillis());
			System.out.println(" ** The last try to insert into Booking : **");

			strCommand = "INSERT  INTO    Booking " +
						 "VALUES  ( '" + strBookingID + "', " + 0 + ", '" +  // 0 = not confirm
						 txDate +"' , '" +                                 // NULL = no transactionID
						  transactionID + "' )";

			try {
			pstmt = con.prepareStatement (strCommand);

		pstmt.executeUpdate();
		pstmt.close();
			System.out.println(" Field in booking : " +strBookingID+ " , "+ transactionID +" , " + txDate );
			System.out.println(" *** Insert into Booking is successful ***");
	  }

	  catch(java.sql.SQLException e)
	  {
		 throw new EJBException("Internal operation error : Can not add information into Booking table.");
	  }

	  return result;

} // End BookSeat Methods

// ******************************************************   VIEW BOOKING  METHOD  *************************************************************
public ArrayList viewBooking(String BookingID)  throws CreateException {

//  find booking by bookingID
	  ArrayList viewBook = new ArrayList();
	  int index;
	  String selectStatement ;
	  PreparedStatement pstmt ;
	  ResultSet rs;
		  String customerBookingID;

	  selectStatement =    "select CUSTOMERBOOKINGID  " +
								"from CUSTOMERBOOKING where BookingID = '" +BookingID +"'" ;

	  try {
	   pstmt = con.prepareStatement(selectStatement);
	   rs = pstmt.executeQuery();
			ArrayList a = new ArrayList();

			while (rs.next()) {
			customerBookingID = rs.getString(1);  //******** get customerBookingID
			System.out.println("***  CustomerBookingID : " + customerBookingID);
			a.add(customerBookingID );
			}
			pstmt.close();

			Iterator i = a.iterator();
		index = 0;
	  while (i.hasNext()) {
		  customerBookingID = (String)i.next();
		 // find CustomerID and price from this customerBookingID
		  System.out.println("*** Find customerID, Price ***");

	  selectStatement = "select CUSTOMERID,PRICE  " +
							"from CUSTOMERBOOKING where CUSTOMERBOOKINGID = '" +customerBookingID +"'" ;

		pstmt = con.prepareStatement(selectStatement);
		rs = pstmt.executeQuery();

		String customerID = rs.getString(1);        //********* get customerID
		double price = rs.getDouble(2);             // ******** get price
				System.out.println("** CustomerID : " + customerID);
				System.out.println("*** price : " + price);
				pstmt.close();

				System.out.println("*** Find FirstName and LastName ***");
		selectStatement = "select FirstName, LastName  " +
								  "from CUSTOMER where CUSTOMERID = '" +customerID +"'" ;

		pstmt = con.prepareStatement(selectStatement);
		rs = pstmt.executeQuery();
		String firstName = rs.getString(1);  //******* get FirstName
		String lastName = rs.getString(2);   // ****** get LastName
				pstmt.close();

				System.out.println("*** Find DepartDate, FlightID , SeatNo***");
		selectStatement = "select DepartDate, FlightID, SeatNo  " +
								  "from SubRouteBooking where CUSTOMERBOOKINGID = '" +customerBookingID +"'" ;

		pstmt = con.prepareStatement(selectStatement);
		rs = pstmt.executeQuery();
		java.sql.Timestamp departTime = rs.getTimestamp(1); //****** get departTime
		String flightID = rs.getString(2);                  //****** get flightID
		String seatNo = rs.getString(3);                    //****** get seatNo
				pstmt.close();

		ViewBookSeatInfo viewBookSeatInfo = new ViewBookSeatInfo(customerID, firstName, lastName, flightID, departTime, seatNo, price);
		viewBook.add(index,viewBookSeatInfo );
		index++;

		} // end while


		 } // end try
	   catch(java.sql.SQLException e)
	  {
		 throw new EJBException("View Booking Error ");
	  }

return viewBook;
}


// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ REQUIRE METHOD @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


  public void ejbCreate() {

  System.out.println("**** Create method ****");
  try {
		 makeConnection();
	  } catch (Exception ex) {
		  throw new EJBException("Unable to connect to database. " +
			 ex.getMessage());
	  }

  System.out.println("**** End Create method ****");

  }
  public void ejbRemove() {

  try {
		 con.close();
	  } catch (SQLException ex) {
		  throw new EJBException("ejbRemove: " + ex.getMessage());
	  }

  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext context) {
	sessionContext = context;
  }

//----------------------------------------- BEGIN MAKECONNECTION ---------------------------------------------
 private void makeConnection() throws NamingException, SQLException {

	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup(dbName);
	  con =  ds.getConnection();

   }
//----------------------------------------- END MAKECONNECTION ---------------------------------------------

}