package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.Date;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingHome extends EJBHome {
  public BookingRemote create(String bookingID, String restaurantID, int meal, java.sql.Date dateTime,
	  int noOfReserveSeat, String agencyID)
	  throws RemoteException, CreateException, InvalidRestaurantException, InvalidMealException,
	  SeatNotAvailableException, InvalidAgentException;
  public BookingRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
}