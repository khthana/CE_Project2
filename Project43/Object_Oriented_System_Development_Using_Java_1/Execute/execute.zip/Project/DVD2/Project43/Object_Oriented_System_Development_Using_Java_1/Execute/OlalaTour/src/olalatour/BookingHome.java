package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingHome extends EJBHome {
  public BookingRemote create(String bookingId, Double totalPrice, Timestamp bookingTime, Integer confirmed, java.sql.Date deadline, String memberId, String busGroupBooking, String aircraftGroupBooking, String hotelGroupBookingId) throws RemoteException, CreateException;
  public BookingRemote create(String bookingId) throws RemoteException, CreateException;
  public BookingRemote findByPrimaryKey(String primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}