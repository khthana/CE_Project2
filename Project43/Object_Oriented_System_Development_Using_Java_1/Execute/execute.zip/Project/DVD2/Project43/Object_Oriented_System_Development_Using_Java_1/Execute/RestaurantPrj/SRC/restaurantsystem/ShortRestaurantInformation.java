package restaurantsystem;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ShortRestaurantInformation implements Serializable {

  public ShortRestaurantInformation(String restaurantID, String name) {
    this.restaurantID = restaurantID;
    this.name = name;
  }
  private String restaurantID;
  private String name;
  public String getRestaurantID() {
    return restaurantID;
  }
  public String getName() {
    return name;
  }
  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}