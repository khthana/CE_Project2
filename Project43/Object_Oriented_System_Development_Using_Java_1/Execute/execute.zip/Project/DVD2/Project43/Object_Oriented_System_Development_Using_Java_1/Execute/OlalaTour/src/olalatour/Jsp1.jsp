<%@ page errorPage="Jsp1ErrorPage.jsp" %>
<HTML>
<HEAD>
<jsp:useBean id="controllerBean" scope="session" class="olalatour.ControllerBean" />
<jsp:setProperty name="controllerBean" property="*" />
<TITLE> New Document </TITLE>
<script language="JavaScript">
<!--
//-->
</script>
</HEAD>
<%
    String submit = request.getParameter("submit");
    out.print(submit);
    if (submit != null) {
	if (submit.equals("airline")) {
	    out.println("airline");
	    String strCustomerID = request.getParameter("CustomerID");
	    String strFlightID = request.getParameter("FlightID");
	    String strSrcIdx = request.getParameter("SrcIdx");
	    String strDstIdx = request.getParameter("DstIdx");
	    String strSeatType = request.getParameter("SeatType");
	    String strClassType = request.getParameter("ClassType");
	    String strDepartDay = request.getParameter("DepartDay");
	    String strDepartMonth = request.getParameter("DepartMonth");
	    String strDepartYear = request.getParameter("DepartYear");
	    String strDepartHour = request.getParameter("DepartHour");
	    String strDepartMinute = request.getParameter("DepartMinute");
	    String strCanSmoking = request.getParameter("CanSmoking");
	    String strPrice = request.getParameter("Price");

	    out.print("getParameter");

	    if ((strCustomerID != null) && (strFlightID != null) && (strSrcIdx != null) && (strDstIdx != null)
		&& (strSeatType != null) && (strClassType != null) && (strDepartDay != null) && (strDepartMonth != null)
		&& (strDepartYear != null) && (strDepartHour != null) && (strDepartMinute != null)
		&& (strCanSmoking != null) && (strPrice != null)) {

		int srcIdx = Integer.parseInt(strSrcIdx);
		int dstIdx = Integer.parseInt(strDstIdx);
		int seatType = Integer.parseInt(strSeatType);
		int classType = Integer.parseInt(strClassType);
		java.sql.Timestamp departTime = java.sql.Timestamp.valueOf(strDepartYear + "-" + strDepartMonth + "-" + strDepartDay + " " + strDepartHour + ":" + strDepartMinute + ":" + "00" + "." + "00000000");
		boolean canSmoking = false;

		if (strCanSmoking.equals("on")) {
		    canSmoking = true;
		}

		double price = Double.parseDouble(strPrice);

		out.print("call addAirlineItem");
		controllerBean.addAirlineItem(strCustomerID, null, null, null, null, strFlightID, srcIdx, dstIdx, seatType, classType, departTime, canSmoking, price);
	    }
	}
	else if (submit.equals("bus")) {
	    out.println("bus");
	    String strCustomerID = request.getParameter("CustomerID");
	    String strRouteID = request.getParameter("RouteID");
	    String strSrcIdx = request.getParameter("SrcIdx");
	    String strDstIdx = request.getParameter("DstIdx");
	    String strSeatType = request.getParameter("SeatType");
	    String strDepartDay = request.getParameter("DepartDay");
	    String strDepartMonth = request.getParameter("DepartMonth");
	    String strDepartYear = request.getParameter("DepartYear");
	    String strDepartHour = request.getParameter("DepartHour");
	    String strDepartMinute = request.getParameter("DepartMinute");
	    String strPrice = request.getParameter("Price");

	    out.print("getParameter");

	    if ((strCustomerID != null) && (strRouteID != null) && (strSrcIdx != null) && (strDstIdx != null)
		&& (strSeatType != null) && (strDepartDay != null) && (strDepartMonth != null)
		&& (strDepartYear != null) && (strDepartHour != null) && (strDepartMinute != null)
		&& (strPrice != null)) {

		int routeID = Integer.parseInt(strRouteID);
		int srcIdx = Integer.parseInt(strSrcIdx);
		int dstIdx = Integer.parseInt(strDstIdx);
		int seatType = Integer.parseInt(strSeatType);
		java.sql.Timestamp departTime = java.sql.Timestamp.valueOf(strDepartYear + "-" + strDepartMonth + "-" + strDepartDay + " " + strDepartHour + ":" + strDepartMinute + ":" + "00" + "." + "00000000");

		double price = Double.parseDouble(strPrice);

		out.print("call addBusItem");
		controllerBean.addBusItem(strCustomerID, null, null, null, null, routeID, srcIdx, dstIdx, seatType, departTime, price);
	    }
	}
	else if (submit.equals("package")) {
	  out.print("package");
	  String strPackageID = request.getParameter("PackageID");
	  String strDepartTimeDay = request.getParameter("DepartTimeDay");
	  String strDepartTimeMonth = request.getParameter("DepartTimeMonth");
	  String strDepartTimeYear = request.getParameter("DepartTimeYear");
	  String strDepartTimeHour = request.getParameter("DepartTimeHour");
	  String strDepartTimeMinute = request.getParameter("DepartTimeMinute");
	  String strTravellerID = request.getParameter("TravellerID");

	  out.print("call addPackageItem");
	  java.sql.Timestamp DepartTime = new java.sql.Timestamp(Integer.parseInt(strDepartTimeYear), Integer.parseInt(strDepartTimeMinute), Integer.parseInt(strDepartTimeDay), Integer.parseInt(strDepartTimeHour), Integer.parseInt(strDepartTimeMinute), 0, 0);
	  controllerBean.addPackageItem(strPackageID, DepartTime, strTravellerID);
	}
	else if (submit.equals("hotel")) {
	  out.print("hotel");
	    String strBookCheckInTimeDay = request.getParameter("BookCheckInTimeDay");
	    String strBookCheckInTimeMonth = request.getParameter("BookCheckInTimeMonth");
	    String strBookCheckInTimeYear = request.getParameter("BookCheckInTimeYear");
	    String strBookCheckOutTimeDay = request.getParameter("BookCheckOutTimeDay");
	    String strBookCheckOutTimeMonth = request.getParameter("BookCheckOutTimeMonth");
	    String strBookCheckOutTimeYear = request.getParameter("BookCheckOutTimeYear");
	    String strHotelID = request.getParameter("HotelID");
	    String strPricePerDay = request.getParameter("PricePerDay");
	    String strDescription = request.getParameter("Description");
	    String strNumberOfSingleBed = request.getParameter("NumberOfSingleBed");
	    String strNumberOfCoupleBed = request.getParameter("NumberOfCoupleBed");
	    String strNumberOfMaximumGuest = request.getParameter("NumberOfMaximumGuest");
	    String strRoomClass = request.getParameter("RoomClass");
	    String strNumberOfRoom = request.getParameter("NumberOfRoom");

	    out.print("getParameter");
	    java.sql.Date BookCheckInTime = new java.sql.Date(Integer.parseInt(strBookCheckInTimeYear), Integer.parseInt(strBookCheckInTimeMonth), Integer.parseInt(strBookCheckInTimeDay));
	    java.sql.Date BookCheckOutTime = new java.sql.Date(Integer.parseInt(strBookCheckOutTimeYear), Integer.parseInt(strBookCheckOutTimeDay), Integer.parseInt(strBookCheckOutTimeDay));

	    out.print("call addHotelItem");
	    controllerBean.addHotelItem(BookCheckInTime, BookCheckOutTime, strHotelID, Double.parseDouble(strPricePerDay), strDescription, Integer.parseInt(strNumberOfSingleBed), Integer.parseInt(strNumberOfCoupleBed), Integer.parseInt(strNumberOfMaximumGuest), Integer.parseInt(strRoomClass), Integer.parseInt(strNumberOfRoom));
	}
    }
%>
<BODY BGCOLOR="#ffffff">
<a href="ViewCart.jsp">ViewCart</a>
Airline : <br>
<FORM METHOD=get>
CustomerID : <INPUT TYPE="text" NAME="CustomerID"><br>
FlightID : <INPUT TYPE="text" NAME="FlightID"><br>
SrcIdx : <INPUT TYPE="text" NAME="SrcIdx"><br>
DstIdx : <INPUT TYPE="text" NAME="DstIdx"><br>
SeatType : <INPUT TYPE="text" NAME="SeatType"><br>
ClassType : <INPUT TYPE="text" NAME="ClassType"><br>
DepartTime :	Day/Month/Year Hour:Minute
				<INPUT TYPE="text" NAME="DepartDay">/
				<INPUT TYPE="text" NAME="DepartMonth">/
				<INPUT TYPE="text" NAME="DepartYear"><br>
				<INPUT TYPE="text" NAME="DepartHour">:
				<INPUT TYPE="text" NAME="DepartMinute">
				<br>
CanSmoking : <INPUT TYPE="checkbox" NAME="CanSmoking"><br>
Price : <INPUT TYPE="text" NAME="Price"><br>
<INPUT TYPE="submit" name="submit" value="airline">
</FORM>
<hr>
bus : <br>
<FORM METHOD=get>
CustomerID : <INPUT TYPE="text" NAME="CustomerID"><br>
RouteID : <INPUT TYPE="text" NAME="RouteID"><br>
SrcIdx : <INPUT TYPE="text" NAME="SrcIdx"><br>
DstIdx : <INPUT TYPE="text" NAME="DstIdx"><br>
SeatType : <INPUT TYPE="text" NAME="SeatType"><br>
DepartTime :	Day/Month/Year Hour:Minute
				<INPUT TYPE="text" NAME="DepartDay">/
				<INPUT TYPE="text" NAME="DepartMonth">/
				<INPUT TYPE="text" NAME="DepartYear"><br>
				<INPUT TYPE="text" NAME="DepartHour">:
				<INPUT TYPE="text" NAME="DepartMinute">
				<br>
Price : <INPUT TYPE="text" NAME="Price"><br>
<INPUT TYPE="submit" name="submit" value="bus">
</FORM>
<hr>
hotel :<br>
<br>
<form name="form1" >
  <p>BookCheckInTime : Day/Month/Year
    <input type="text" name="BookCheckInTimeDay">
    /
    <input type="text" name="BookCheckInTimeMonth">
    /
    <input type="text" name="BookCheckInTimeYear">
    <br>
    BookCheckOutTime : Day/Month/Year
    <input type="text" name="BookCheckOutTimeDay">
    /
    <input type="text" name="BookCheckOutTimeMonth">
    /
    <input type="text" name="BookCheckOutTimeYear">
    <br>
    HotelID :
    <input type="text" name="HotelID">
    <br>
    PricePerDay :
    <input type="text" name="PricePerDay">
    <br>
    Description :
    <input type="text" name="Description">
    <br>
    NumberOfSingleBed :
    <select name="NumberOfSingleBed">
      <option value="0">0</option>
      <option value="1" selected>1</option>
      <option value="2">2</option>
      <option value="3">3</option>
    </select>
    <br>
    NumberOfCoupleBed :
    <select name="NumberOfCoupleBed">
      <option value="0" selected>0</option>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
    </select>
    <br>
    NumberOfMaximumGuest :
    <select name="NumberOfMaximumGuest">
      <option value="1" selected>1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
      <option value="7">7</option>
      <option value="8">8</option>
      <option value="9">9</option>
      <option value="10">10</option>
    </select>
    <br>
    RoomClass :
    <select name="RoomClass">
      <option value="500" selected>ANY</option>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
    </select>
    <br>
    NumberOfRoom :
    <select name="NumberOfRoom">
      <option value="1" selected>1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
      <option value="7">7</option>
      <option value="8">8</option>
      <option value="9">9</option>
      <option value="10">10</option>
    </select>
    <br>
    <input type="submit" name="submit" value="hotel">
    <br>
  </p>
  </form>
<hr>
<p><br>
  package :<br>
  <br>
</p>
<form name="form2" >
  PackageID :
  <input type="text" name="PackageID">
  <br>
  DepartTime : Day/Month/Year Hour : Minute
  <input type="text" name="DepartTimeDay">
  /
  <input type="text" name="DepartTimeMonth">
  /
  <input type="text" name="DepartTimeYear">
  <br>
  <input type="text" name="DepartTimeHour">
  :
  <input type="text" name="DepartTimeMinute">
  <br>
  TravellerID :
  <input type="text" name="TravellerID">
  <br>
  <input type="submit" name="submit" value="package">
  <br>
  <br>
</form>
<p> <br>
  <br>
</p>
</BODY>
</HTML>