package hotelsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface CustomerHome extends EJBHome {
  public CustomerRemote create(String customerID, String firstname, String lastname, String address, String telephoneNo, int gender) throws RemoteException, CreateException;
  public CustomerRemote findByPrimaryKey(String primKey) throws RemoteException, FinderException;
}