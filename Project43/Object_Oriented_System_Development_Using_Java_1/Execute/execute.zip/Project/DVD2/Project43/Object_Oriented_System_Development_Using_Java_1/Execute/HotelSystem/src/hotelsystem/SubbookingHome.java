package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface SubbookingHome extends EJBHome {
    public SubbookingRemote create(java.sql.Date bookCheckInTime, java.sql.Date bookCheckOutTime, String roomNo, String hotelId, String bookingId) throws RemoteException, CreateException;
    public SubbookingRemote create(java.sql.Date bookCheckInTime, String roomNo, String hotelId) throws RemoteException, CreateException;
    public SubbookingRemote findByPrimaryKey(SubbookingPK primaryKey) throws RemoteException, FinderException;
    public Collection findAll() throws RemoteException, FinderException;
    public Collection findByBooking(String bookingID) throws RemoteException, FinderException;
}