package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class TransactionNotExistException extends Exception {

   public TransactionNotExistException() { }

   public TransactionNotExistException(String msg) {
      super(msg);
   }
}