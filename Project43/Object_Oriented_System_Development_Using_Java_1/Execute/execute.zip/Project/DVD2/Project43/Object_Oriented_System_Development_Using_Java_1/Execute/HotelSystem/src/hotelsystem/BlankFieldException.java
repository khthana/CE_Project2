package hotelsystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class BlankFieldException extends Exception {

  public BlankFieldException() {
  }
}