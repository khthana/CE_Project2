package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:        
 * Description:  
 * Copyright:    Copyright (c) 2000
 * Company:      
 * @author 
 * @version 1.0
 */

public interface RestaurantControllerHome extends EJBHome {
  public RestaurantControllerRemote create() throws RemoteException, CreateException;
}