package olalatour;

import java.io.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class FullTravellerInformation implements Serializable {

    public FullTravellerInformation(String travellerID, String firstName, String lastName, String address, String telephoneNo, int gender, java.sql.Date birthDate, String religion, String foodTypeID, String emailAddress) {
	this.travellerID=travellerID;
	this.firstName=firstName;
	this.lastName=lastName;
	this.address=address;
	this.telephoneNo=telephoneNo;
	this.gender=gender;
	this.birthDate=birthDate;
	this.religion=religion;
	this.foodTypeID=foodTypeID;
	this.emailAddress=emailAddress;
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
	ois.defaultReadObject();
    }
    private void writeObject(ObjectOutputStream oos) throws IOException {
	oos.defaultWriteObject();
    }
    public String getTravellerID() {
	return travellerID;
    }
    public String getFirstName() {
	return firstName;
    }
    public String getLastName() {
	return lastName;
    }
    public String getAddress() {
	return address;
    }
    public String getTelephoneNo() {
	return telephoneNo;
    }
    public int getGender() {
	return gender;
    }
    public java.sql.Date getBirthDate() {
	return birthDate;
    }
    public String getReligion() {
	return religion;
    }
    public String getFoodTypeID() {
	return foodTypeID;
    }
    public String getEmailAddress() {
	return emailAddress;
    }
    private String travellerID;
    private String firstName;
    private String lastName;
    private String address;
    private String telephoneNo;
    private int gender;
    private java.sql.Date birthDate;
    private String religion;
    private String foodTypeID;
    private String emailAddress;
}