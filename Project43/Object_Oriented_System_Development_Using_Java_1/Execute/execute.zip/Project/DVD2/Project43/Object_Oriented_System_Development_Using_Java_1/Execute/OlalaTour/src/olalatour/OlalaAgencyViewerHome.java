package olalatour;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface OlalaAgencyViewerHome extends EJBHome {
	public OlalaAgencyViewerRemote create() throws RemoteException, CreateException;
}