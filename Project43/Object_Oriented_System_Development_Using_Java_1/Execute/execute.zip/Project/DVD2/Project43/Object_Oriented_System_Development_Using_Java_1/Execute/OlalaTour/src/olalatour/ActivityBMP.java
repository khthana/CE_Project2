package olalatour;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import java.util.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class ActivityBMP extends Activity {
    DataSource dataSource;
    public String ejbCreate(String activityId, String activityName, String activityDetail) throws CreateException {
	super.ejbCreate(activityId, activityName, activityDetail);
	try {
	    //First see if the object already exists
	    ejbFindByPrimaryKey(activityId);
	    //If so, then we have to throw an exception
	    throw new DuplicateKeyException("Primary key already exists");
	}
	catch(ObjectNotFoundException e) {
	    //Otherwise we can go ahead and create it...
	}
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("INSERT INTO ACTIVITY (ACTIVITY_ID, ACTIVITY_NAME, ACTIVITY_DETAIL) VALUES (?, ?, ?)");
	    statement.setString(1, activityId);
	    statement.setString(2, activityName);
	    statement.setString(3, activityDetail);
	    if (statement.executeUpdate() != 1) {
		throw new CreateException("Error adding row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return activityId;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL INSERT INTO ACTIVITY (ACTIVITY_ID, ACTIVITY_NAME, ACTIVITY_DETAIL) VALUES (?, ?, ?): " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbCreate(String activityId) throws CreateException {
	return ejbCreate(activityId, null, null);
    }
    public void ejbRemove() throws RemoveException {
	super.ejbRemove();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("DELETE FROM ACTIVITY WHERE ACTIVITY_ID = ?");
	    statement.setString(1, activityId);
	    if (statement.executeUpdate() < 1) {
		throw new RemoveException("Error deleting row");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL DELETE FROM ACTIVITY WHERE ACTIVITY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public void ejbLoad() {
	activityId = (String) entityContext.getPrimaryKey();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT ACTIVITY_NAME, ACTIVITY_DETAIL FROM ACTIVITY WHERE ACTIVITY_ID = ?");
	    statement.setString(1, activityId);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    activityName = resultSet.getString(1);
	    activityDetail = resultSet.getString(2);
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT ACTIVITY_NAME, ACTIVITY_DETAIL FROM ACTIVITY WHERE ACTIVITY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
	super.ejbLoad();
    }
    public void ejbStore() {
	super.ejbStore();
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("UPDATE ACTIVITY SET ACTIVITY_NAME = ?, ACTIVITY_DETAIL = ? WHERE ACTIVITY_ID = ?");
	    statement.setString(1, activityName);
	    statement.setString(2, activityDetail);
	    statement.setString(3, activityId);
	    if (statement.executeUpdate() < 1) {
		throw new NoSuchEntityException("Row does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL UPDATE ACTIVITY SET ACTIVITY_NAME = ?, ACTIVITY_DETAIL = ? WHERE ACTIVITY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public String ejbFindByPrimaryKey(String key) throws ObjectNotFoundException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT ACTIVITY_ID FROM ACTIVITY WHERE ACTIVITY_ID = ?");
	    statement.setString(1, key);
	    ResultSet resultSet = statement.executeQuery();
	    if (!resultSet.next()) {
		throw new ObjectNotFoundException("Primary key does not exist");
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return key;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT ACTIVITY_ID FROM ACTIVITY WHERE ACTIVITY_ID = ?: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindAll() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT ACTIVITY_ID FROM ACTIVITY");
	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String activityId = resultSet.getString(1);
		keys.addElement(activityId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT ACTIVITY_ID FROM ACTIVITY: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
    public Collection ejbFindByActivityNameDetail(String activityName, String detail) throws FinderException {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT ACTIVITY_ID FROM ACTIVITY WHERE ACTIVITY_NAME LIKE ? AND ACTIVITY_DETAIL LIKE ? ");
	    statement.setString(1, "%" + activityName + "%");
	    statement.setString(2, "%" + detail + "%");

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }

    public void setEntityContext(EntityContext entityContext) {
	super.setEntityContext(entityContext);
	try {
	    javax.naming.Context context = new javax.naming.InitialContext();
	    dataSource = (DataSource) context.lookup("java:comp/env/jdbc/OlalaDB");
	}
	catch(Exception e) {
	    throw new EJBException("Error looking up dataSource:" + e.toString());
	}
    }
    public Collection getPlaces() {
	Connection connection = null;
	PreparedStatement statement = null;
	try {
	    connection = dataSource.getConnection();
	    statement = connection.prepareStatement("SELECT DISTINCT PLACE_ID FROM PLACE_ACTIVITY WHERE ACTIVITY_ID = ? ");
	    statement.setString(1, activityId);

	    ResultSet resultSet = statement.executeQuery();
	    Vector keys = new Vector();
	    while (resultSet.next()) {
		String placeId = resultSet.getString(1);
		keys.addElement(placeId);
	    }
	    statement.close();
	    statement = null;
	    connection.close();
	    connection = null;
	    return keys;
	}
	catch(SQLException e) {
	    throw new EJBException("Error executing SQL SELECT PLACE_ID FROM PLACE: " + e.toString());
	}
	finally {
	    try {
		if (statement != null) {
		    statement.close();
		}
	    }
	    catch(SQLException e) {
	    }
	    try {
		if (connection != null) {
		    connection.close();
		}
	    }
	    catch(SQLException e) {
	    }
	}
    }
}