<html>
<head>
<jsp:useBean id="viewerBean" scope="page" class="olalatour.ViewerBean" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<body bgcolor="#FFFFFF">
<%@ include file="header.jsp" %>
<table width="750" border="1">
  <tr>
    <td width="71%" rowspan="2">

      <form method="get" name="form1" action="AirlineSearchList.jsp">
	<font size="5"><b>Fill Data For Airline Search</b></font> <b> </b>
	<table width="100%" border="1">
	  <tr>
	    <td colspan=3><b>How many of passengers?</b> *</td>
	  </tr>
	  <tr>
	    <td width="375">
	      <div align="right">Total number of travellers?</div>
	    </td>
	    <td width="349">
	      <select name="NumberOfTraveller">
		<option value="1" selected>1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9">9</option>
	      </select>
	    </td>
	  </tr>
	  <tr>
	    <td colspan="3"><b>Where would you like to go?*</b></td>
	  </tr>
	  <tr>
	    <td width="375">
	      <div align="right">Leaving From</div>
	    </td>
	    <td colspan="2" width="349">
	      <div align="left">
		<select name="FromPlace">
		<%viewerBean.searchAirport("");%>
		<% while (viewerBean.nextAirport()) { %>
		  <option value="<%out.print(viewerBean.getPlaceID());%>"><%out.print(viewerBean.getPlaceID());%> <%out.print(viewerBean.getPlaceName());%></option>
		<% } %>
		</select>
	      </div>
	    </td>
	  </tr>
	  <tr>
	    <td width="375">
	      <div align="right">Going To </div>
	    </td>
	    <td colspan="2" width="349">
	      <div align="left">
		<select name="ToPlace">
		<%viewerBean.searchAirport("");%>
		<% while (viewerBean.nextAirport()) { %>
		  <option value="<%out.print(viewerBean.getPlaceID());%>"><%out.print(viewerBean.getPlaceID());%> <%out.print(viewerBean.getPlaceName());%></option>
		<% } %>
		</select>
	      </div>
	    </td>
	  </tr>
	  <tr>
	    <td colspan="3">
	      <div align="center">You can fly on any day that lowest fare? If
		so,stop here<br>
		By clicking "Show me Airlines", you indicate that you agree to
		the following </div>
	      <div align="center">
		<input type="submit" name="buttonShowAirSeatList1" value="ShowMeAirSeat">
	      </div>
	    </td>
	  </tr>
	</table>

	<table width="100%" border="1">
	  <tr>
	    <td colspan="8" height="29"><b>When would you like to traval?</b></td>
	  </tr>
	  <tr>
	        <td width="353"> 
              <div align="right"> Departing </div>
	    </td>
	        <td colspan="2" height="30" width="371"> 
              <div align="left"> 
                <select name="selectDay" >
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                  <option value="6">6</option>
                  <option value="7">7</option>
                  <option value="8">8</option>
                  <option value="9" selected>9</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
                  <option value="13">13</option>
                  <option value="14">14</option>
                  <option value="15">15</option>
                  <option value="16">16</option>
                  <option value="17">17</option>
                  <option value="18">18</option>
                  <option value="19">19</option>
                  <option value="20">20</option>
                  <option value="21">21</option>
                  <option value="22">22</option>
                  <option value="23">23</option>
                  <option value="24">24</option>
                  <option value="25">25</option>
                  <option value="26">26</option>
                  <option value="27">27</option>
                  <option value="28">28</option>
                  <option value="29">29</option>
                  <option value="30">30</option>
                  <option value="31">31</option>
                </select>
                <select name="selectMonth">
                  <option value="1">January</option>
                  <option value="2"         >Febuary</option>
                  <option value="3"           >March</option>
                  <option value="4"           >April</option>
                  <option value="5" selected             >May</option>
                  <option value="6"            >June</option>
                  <option value="7"            >July</option>
                  <option value="8"          >August</option>
                  <option value="9"       >September</option>
                  <option value="10"         >October</option>
                  <option value="11"        >November</option>
                  <option value="12"        >December</option>
                </select>
                <select name="selectYear">
		  <option value="2001" selected>2001</option>
		  <option value="2002"> 2002</option>
		  <option value="2003"> 2003</option>
		  <option value="2004"> 2004</option>
		</select>
	      </div>
	    </td>

	  </tr>
	</table>
	<table width="100%" border="0">
	  <tr>
	    <td colspan="2" height="30"><b> Passenger and Pricing Information</b></td>
	  </tr>
	  <tr>
	    <td colspan="2">
	      <div align="center">Airline Class :
		<select name="selectAirlineClass">
                  <option value="0" selected>ANY</option>
                  <option value="1">Business Class</option>
                  <option value="2">Economic Class</option>
                </select>
	      </div>
	    </td>
	  </tr>
	  <tr>
	    <td colspan="2">
	      <div align="center">
		<input type="checkbox" name="NonStop" value="true">
		Show me non-stop flight first <br>
		        <input type="checkbox" name="CanSmoking" value="true">
		can smoking</div>
	    </td>
	  </tr>
	</table>
	<table width="100%" border="0">
	  <tr>
	    <td colspan="2"><b>What airlines do you like prefer?</b></td>
	  </tr>
	  <tr>
	    <td colspan="2">
	      <div align="center">Airlines Name :
		<select name="Airline"  id ="selectAirlineName" size="1">
                  <option value="0" selected>ANY</option>
                  <option value="1">Thai Airways International</option>
                  <option value="2">China Airlines</option>
                  <option value="3">Air Canada</option>
                </select>
	      </div>
	    </td>
	  </tr>
	</table>
	<table width="100%" border="0">
	  <tr>
	    <td><b>What seat position do you want?</b></td>
	  </tr>
	  <tr>
	    <td>
	      <div align="center">Seat Position :
		<select name="selectSeatPosition" id="selectSeatPosition" >
		  <option value="0" selected>ANY</option>
		  <option value="1">near windows</option>
		  <option value="2">near way</option>
		</select>
	      </div>
	    </td>
	  </tr>
	</table>
	<div align="center">
	  <input type="submit" name="buttonShowAirSeatList2" value="ShowMeAirSeat">
	</div>
      </form>
    </td>
  </tr>
  <tr> </tr>
</table>
</body>
</html>
