package src.banksystem;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.Vector;
import org.apache.jasper.runtime.*;
import java.beans.*;
import org.apache.jasper.JasperException;


public class _0002fsrc_0002fbanksystem_0002fBankSystem_0002ejspBankSystem_jsp_19 extends HttpJspBase {

    // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(1,0);to=(1,84)]
    // end

    static {
    }
    public _0002fsrc_0002fbanksystem_0002fBankSystem_0002ejspBankSystem_jsp_19( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws JasperException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                _jspx_init();
                _jspx_inited = true;
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=8859_1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
			"BankSystemErrorPage.jsp", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(0,47);to=(1,0)]
                out.write("\r\n");
            // end
            // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(1,0);to=(1,84)]
                banksystem.BankSystemBean bankSystemBean = null;
                boolean _jspx_specialbankSystemBean  = false;
                 synchronized (session) {
                    bankSystemBean= (banksystem.BankSystemBean)
                    pageContext.getAttribute("bankSystemBean",PageContext.SESSION_SCOPE);
                    if ( bankSystemBean == null ) {
                        _jspx_specialbankSystemBean = true;
                        try {
                            bankSystemBean = (banksystem.BankSystemBean) Beans.instantiate(getClassLoader(), "banksystem.BankSystemBean");
                        } catch (Exception exc) {
                             throw new ServletException (" Cannot create bean of class "+"banksystem.BankSystemBean");
                        }
                        pageContext.setAttribute("bankSystemBean", bankSystemBean, PageContext.SESSION_SCOPE);
                    }
                 } 
                if(_jspx_specialbankSystemBean == true) {
            // end
            // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(1,0);to=(1,84)]
                }
            // end
            // HTML // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(1,84);to=(71,0)]
                out.write("\r\n<head>\r\n<title>Untitled Document</title>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ms-874\">\r\n</head>\r\n\r\n<body bgcolor=\"#FFFFFF\">\r\n<p><font size=\"+3\">Pay by Credit card :</font><br>\r\n</p>\r\n<form name=\"form1\" >\r\n  <table width=\"500\" border=\"1\">\r\n\t<tr>\r\n\t  <td>credit card id :\r\n\t\t<input type=\"text\" name=\"textfield\">\r\n\t  </td>\r\n\t  <td>destination account :\r\n\t\t<input type=\"text\" name=\"textfield2\">\r\n\t  </td>\r\n\t  <td>amount :\r\n\t\t<input type=\"text\" name=\"textfield3\">\r\n\t  </td>\r\n\t  <td>\r\n\t\t<input type=\"submit\" name=\"Submit\" value=\"Submit\">\r\n\t  </td>\r\n\t</tr>\r\n  </table>\r\n  </form>\r\n<hr>\r\n<p><font size=\"+3\"> Pay by Debit card :<br>\r\n  </font> </p>\r\n<form name=\"form2\" >\r\n  <table width=\"500\" border=\"1\">\r\n\t<tr>\r\n\t  <td>debit card id :\r\n\t\t<input type=\"text\" name=\"textfield4\">\r\n\t  </td>\r\n\t  <td>destination account :\r\n\t\t<input type=\"text\" name=\"textfield5\">\r\n\t  </td>\r\n\t  <td>amount :\r\n\t\t<input type=\"text\" name=\"textfield6\">\r\n\t  </td>\r\n\t  <td>\r\n\t\t<input type=\"submit\" name=\"Submit2\" value=\"Submit\">\r\n\t  </td>\r\n\t</tr>\r\n  </table>\r\n  </form>\r\n<hr>\r\n<p> <font size=\"+3\">Transfer :</font></p>\r\n<form name=\"form3\" >\r\n  <table width=\"500\" border=\"1\">\r\n\t<tr>\r\n\t  <td>source account id :\r\n\t\t<input type=\"text\" name=\"textfield7\">\r\n\t  </td>\r\n\t  <td>destination id :\r\n\t\t<input type=\"text\" name=\"textfield8\">\r\n\t  </td>\r\n\t  <td>amount :\r\n\t\t<input type=\"text\" name=\"textfield9\">\r\n\t  </td>\r\n\t  <td>\r\n\t\t<input type=\"submit\" name=\"Submit3\" value=\"Submit\">\r\n\t  </td>\r\n\t</tr>\r\n  </table>\r\n  </form>\r\n<hr>\r\n\r\n");
            // end
            // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(71,2);to=(120,0)]
                
                  out.print("procession1");
                  String submit = request.getParameter("Submit");
                  String submit2 = request.getParameter("Submit2");
                  String submit3 = request.getParameter("Submit3");
                  String transactionID = null;
                  out.print("procession2");
                
                  bankSystemBean.init();
                  out.print("procession3");
                
                  if (submit == null)
                	submit = "";
                  if (submit2 == null)
                	submit2 = "";
                  if (submit3 == null)
                	submit3 = "";
                
                  out.print("processing...");
                  if (submit.equals("Submit")) {
                	out.print("credit");
                	try {
                	  transactionID = bankSystemBean.payByCreditCardID(request.getParameter("textfield"), request.getParameter("textfield2"), Double.parseDouble(request.getParameter("textfield3")));
                	}
                	catch (Exception ex) {
                	  out.print(ex.getMessage());
                	}
                	out.print("pay by credit success. TransactionID is : " + transactionID);
                  }
                  else if (submit2.equals("Submit")) {
                	out.print("debit");
                	try {
                	  transactionID = bankSystemBean.payByDebitCardID(request.getParameter("textfield4"), request.getParameter("textfield5"), Double.parseDouble(request.getParameter("textfield6")));
                	}
                	catch (Exception ex) {
                	  out.print(ex.getMessage());
                	}
                	out.print("pay by debit success. TransactionID is : " + transactionID);
                  }
                  else if (submit3.equals("Submit")) {
                	out.print("transfer");
                	try {
                	  transactionID = bankSystemBean.transfer(request.getParameter("textfield7"), request.getParameter("textfield8"), Double.parseDouble(request.getParameter("textfield9")));
                	}
                	catch (Exception ex) {
                	  out.print(ex.getMessage());
                	}
                	out.print("transfer success. TransactionID is : " + transactionID);
                  }
            // end
            // HTML // begin [file="D:\\src\\banksystem\\BankSystem.jsp";from=(120,2);to=(126,0)]
                out.write("\r\n\r\n\r\n<p><font size=\"+3\">result :</font></p>\r\n</body>\r\n</html>\r\n");
            // end

        } catch (Exception ex) {
            if (out.getBufferSize() != 0)
                out.clearBuffer();
            pageContext.handlePageException(ex);
        } finally {
            out.flush();
            _jspxFactory.releasePageContext(pageContext);
        }
    }
}
