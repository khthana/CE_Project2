package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.security.*;
import java.net.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class UUIDGenerator implements SessionBean {
    private SessionContext sessionContext;
    // class variables used to cache some of the data
    private int timeLow; //32 bits
    private int node; // 32 bits
    private String hexInetAddress; //32 bits
    private String thisHashCode; // 32 bits
    private String midValue;
    private SecureRandom seeder;

    private String ALGORITHM = "SHA1PRNG";
    private String PROVIDER = "SUN";

    public void ejbCreate() {
	try {
		StringBuffer tmpBuffer = new StringBuffer();
		// initalise the secure random instance
		seeder = SecureRandom.getInstance(ALGORITHM, PROVIDER);
		seeder.setSeed(System.currentTimeMillis());

		// get the inet address
		InetAddress inet = InetAddress.getLocalHost();
		byte [] bytes = inet.getAddress();

//		System.out.println("address : " + getInt(bytes)[0] + getInt(bytes)[1] + getInt(bytes)[2] + getInt(bytes)[3]);

		hexInetAddress = hexFormat(getInt(bytes),8);
		System.out.println("hexInetAddress : " + hexInetAddress);
		// get the hashcode

		thisHashCode = hexFormat(System.identityHashCode(this),8);
		/* set up a cached midValue as this is the same per method
		/ call as is object specific and is the
		/ ...-xxxx-xxxx-xxxx-xxxx.. mid part of the sequence
		*/
		tmpBuffer.append("-");
		tmpBuffer.append(hexInetAddress.substring(0,4));
		tmpBuffer.append("-");
		tmpBuffer.append(hexInetAddress.substring(4));
		tmpBuffer.append("-");
		tmpBuffer.append(thisHashCode.substring(0,4));
		tmpBuffer.append("-");
		tmpBuffer.append(thisHashCode.substring(4));
		midValue = tmpBuffer.toString();

		// load up the randomizer first value
		int node = seeder.nextInt();
	    } catch (Exception e) {
			System.out.println("error :" + e.getMessage());
	    }
    }
    public void ejbRemove() {
    }
    public void ejbActivate() {
    }
    public void ejbPassivate() {
    }
    public void setSessionContext(SessionContext context) {
	sessionContext = context;
    }
    private int[] getInt(byte[] bytes) {
	    int[] result = new int[bytes.length];
	    for (int i = 0; i < bytes.length; i++) {
		result[i] = Integer.parseInt(Byte.toString(bytes[i]));
	    }
//	    System.out.println("getInt");
	    return result;
	}
	private String hexFormat(int[] numbers, int digit) {
	    StringBuffer temp = new StringBuffer(12);
	    for (int i = 0; i < numbers.length; i++) {
		temp.append(Integer.toHexString(numbers[i]));
	    }
	    if (temp.length() < digit) {
		StringBuffer zero = new StringBuffer();
		for (int i = 0; i < (digit-temp.length()); i++) {
		    zero.append("0");
		}
//		System.out.println("hexFormat array : " + zero.toString()+temp + " : " + digit);
		return (zero.toString()+temp);
	    }
	    else {
//		System.out.println("hexFormat array 1:" + temp);
//		System.out.println("hexFormat array 2: " + temp.substring(temp.length()-digit, temp.length()) + " : " + digit);
		return temp.substring(temp.length()-digit, temp.length());
	    }
	}
	private String hexFormat(int number, int digit) {
	    StringBuffer temp = new StringBuffer(12);
	    temp.append(Integer.toHexString(number));

	    if (temp.length() < digit) {
		StringBuffer zero = new StringBuffer();
		for (int i = 0; i < (digit-temp.length()); i++) {
		    zero.append("0");
		}
//		System.out.println("hexFormat : " + zero.toString()+temp + " : " + digit);
		return (zero.toString()+temp);
	    }
	    else {
//		System.out.println("hexFormat 1: " + temp);
//		System.out.println("hexFormat 2: " + temp.substring(temp.length()-digit, temp.length()) + " : " + digit);
		return temp.substring(temp.length()-digit, temp.length());
	    }
	}

    public String getUUID() {
	    long timeNow = System.currentTimeMillis();
	    timeLow = (int) timeNow & 0xFFFFFFFF;
	    int node = seeder.nextInt();

	    return (hexFormat(timeLow, 8) + midValue + hexFormat(node, 8));
    }
}