package hotelsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.*;
import javax.sql.*;
import java.util.*;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class Hotel implements EntityBean {
  EntityContext entityContext;
  public String hotelID;
  public String hotelName;
  public String description;
  public int star;
  public String telephoneNo;
  public String accountId;
  public String password;
  public String logo;
  public String hotelPicture;

  private Connection con;
  private String dbName = "java:comp/env/jdbc/HotelDB";
  public String address;

  public String ejbCreate(String hotelID, String hotelName, String description, String address, int star, String telephoneNo, String accountID, String password, String logo, String hotelPicture) throws CreateException {

	  System.out.println("ejbCreate");

	  try {
		insertRow(hotelID, hotelName, description, address, star, telephoneNo, accountID, password, logo, hotelPicture);
	  } catch (Exception ex) {
	   throw new EJBException("ejbCreate: " +
		  ex.getMessage());
	  }

	  this.hotelID = hotelID;
	  this.hotelName = hotelName;
	  this.description = description;
	  this.address = address;
	  this.star = star;
	  this.telephoneNo = telephoneNo;
	  this.accountId = accountID;
	  this.password = password;
	  this.logo = logo;
	  this.hotelPicture = hotelPicture;

	  System.out.println("end ejbCreate");

	  return hotelID;
  }
  public void ejbPostCreate(String hotelID, String hotelName, String description, String address, int star, String telephoneNo, String accountID, String password, String logo, String hotelPicture) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
	System.out.println("ejbRomove");
	  try {
	 deleteRow(hotelID);
	   } catch (Exception ex) {
	   throw new EJBException("ejbRemove: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbRomove");
  }
  public String ejbFindByPrimaryKey(String primKey) throws FinderException {
	  System.out.println("ejbFindByPrimaryKey");

	  boolean result;

	  try {
	 result = selectByPrimaryKey(primKey);
	   } catch (Exception ex) {
	   throw new EJBException("ejbFindByPrimaryKey: " +
		  ex.getMessage());
	   }
	  if (result) {
	System.out.println("end ejbFindByPrimaryKey");
	return primKey;
	  }
	  else {
	System.out.println("end ejbFindByPrimaryKey");
	throw new ObjectNotFoundException
		("Row for id " + primKey + " not found.");
	  }
  }
  public Collection ejbFindByNameDescriptionAddressStar(String name, String description, String address, int star) throws FinderException {
    System.out.println("ejbFindByNameDescriptionAddressStar");
	  Collection result;

	  try {
		  result = selectByNameDescriptionAddressStar(name, description, address, star);
	  } catch (Exception ex) {
	  throw new EJBException("ejbFindByNameDescriptionAddressStar " +
		  ex.getMessage());
	  }

	  if (result.isEmpty()) {
		throw new ObjectNotFoundException("No rows found.");
	  }
	  else {
    System.out.println("end ejbFindByNameDescriptionAddressStar");
		return result;
	  }
  }

  public void ejbActivate() {
	System.out.println("ejbActivate");
	hotelID = (String)entityContext.getPrimaryKey();
	System.out.println("end ejbActivate");
  }
  public void ejbPassivate() {
	System.out.println("ejbPassivate");
	hotelID = null;
	System.out.println("end ejbPassivate");
  }
  public void ejbLoad() {
	System.out.println("ejbLoad");
	  try {
	 loadRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbLoad: " +
		  ex.getMessage());
	   }
	  System.out.println("end ejbLoad");
  }
  public void ejbStore() {
	System.out.println("ejbStore");
	  try {
	 storeRow();
	   } catch (Exception ex) {
	   throw new EJBException("ejbStore: " +
		  ex.getMessage());
	   }
	System.out.println("end ejbStore");
  }
  public void setEntityContext(EntityContext entityContext) {
	System.out.println("setEntityContext");
	this.entityContext = entityContext;
	  try {
	 makeConnection();
	  } catch (Exception ex) {
	  throw new EJBException("Unable to connect to database. " +
		 ex.getMessage());
	  }
	System.out.println("end setEntityContext");
  }
  public void unsetEntityContext() {
	System.out.println("unsetEntityContext");
	entityContext = null;
	  try {
	 con.close();
	  } catch (SQLException ex) {
	  throw new EJBException("unsetEntityContext: " + ex.getMessage());
	  }
	System.out.println("end unsetEntityContext");
  }
  public String getHotelID() {
	return hotelID;
  }
  public String getHotelName() {
	return hotelName;
  }
  public String getDescription() {
	return description;
  }
  public int getStar() {
	return star;
  }
  public void setTelephoneNo(String newTelephoneNo) {
	telephoneNo = newTelephoneNo;
  }
  public String getTelephoneNo() {
	return telephoneNo;
  }
  public void setAccountId(String newAccountId) {
	accountId = newAccountId;
  }
  public String getAccountId() {
	return accountId;
  }
  public void setPassword(String newPassword) {
	password = newPassword;
  }
  public String getPassword() {
	return password;
  }
  public void setLogo(String newLogo) {
	logo = newLogo;
  }
  public String getLogo() {
	return logo;
  }
  public void setHotelPicture(String newHotelPicture) {
	hotelPicture = newHotelPicture;
  }
  public String getHotelPicture() {
	return hotelPicture;
  }
  public void setHotelName(String newHotelName) {
	hotelName = newHotelName;
  }
  public void setStar(int newStar) {
	star = newStar;
  }
  public void setDescription(String newDescription) {
	description = newDescription;
  }
  public int getNoOfRooms() {
    System.out.println("getNoOfRooms");
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("hotelsystem/Room");

	  RoomHome home = (RoomHome)PortableRemoteObject.narrow(objref, RoomHome.class);

	  Collection rooms = home.findByHotel(hotelID);

    System.out.println("end getNoOfRooms : " + rooms.size());
	  return rooms.size();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}

    // from Room
//    try {
//	  System.out.println("selectByHotel : " + hotelID);
//
//	  String selectStatement =
//		"select COUNT(*) " +
//		"from ROOM where HOTEL_ID = ? ";
//	  PreparedStatement prepStmt = con.prepareStatement(selectStatement);
//	  prepStmt.setString(1, hotelID);
//
//	  ResultSet rs = prepStmt.executeQuery();
//	  System.out.println("executeQuery");
//	  if (rs.next()) {
//	    int result = rs.getInt(1);
//	    prepStmt.close();
//
//	    System.out.println("end selectByHotel : " + hotelID );
//	    return result;
//	  }
//	  else {
//	    prepStmt.close();
//	    throw new NoSuchEntityException("Row for id " + hotelID + " not found in database.");
//	  }
//
//    }
//    catch (SQLException ex) {
//	System.out.println("SQL error in Hotel.getNoOfRooms()");
//	return -1;
//    }
  }
/*********************** Database Routines *************************/

   private void makeConnection() throws NamingException, SQLException {

	  InitialContext ic = new InitialContext();
	  DataSource ds = (DataSource) ic.lookup(dbName);
	  con =  ds.getConnection();
   }

   private void insertRow (String hotelID, String hotelName, String description, String address, int star, String telephoneNo, String accountID, String password, String logo, String hotelPicture) throws SQLException {

	  String insertStatement =
		"insert into HOTEL(HOTEL_ID, HOTEL_NAME, DESCRIPTION, ADDRESS, STAR, TELEPHONE_NO, ACCOUNT_ID, PASSWORD, LOGO, HOTEL_PICTURE) values ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? )";
	  PreparedStatement prepStmt =
		con.prepareStatement(insertStatement);

	  prepStmt.setString(1, hotelID);
	  prepStmt.setString(2, hotelName);
	  prepStmt.setString(3, description);
	  prepStmt.setString(4, address);
	  prepStmt.setInt( 5, star);
	  prepStmt.setString(6, telephoneNo);
	  prepStmt.setString(7, accountID);
	  prepStmt.setString(8, password);
	  prepStmt.setString(9, logo);
	  prepStmt.setString(10, hotelPicture);

	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private void deleteRow(String id) throws SQLException {

	  String deleteStatement =
		"delete from HOTEL where HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(deleteStatement);

	  prepStmt.setString(1, id);
	  prepStmt.executeUpdate();
	  prepStmt.close();
   }

   private boolean selectByPrimaryKey(String primaryKey)
	  throws SQLException {

	  String selectStatement =
		"select HOTEL_ID " +
		"from HOTEL where HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);
	  prepStmt.setString(1, primaryKey);

	  ResultSet rs = prepStmt.executeQuery();
	  boolean result = rs.next();
	  prepStmt.close();
	  return result;
   }
   private Collection selectByNameDescriptionAddressStar(String name, String description, String address, int star) throws SQLException {
      System.out.println("selectByNameDescriptionAddressStar in Hotel");
      String selectStatement =
	    "select HOTEL_ID " +
	    "from HOTEL where HOTEL_NAME LIKE ? AND DESCRIPTION LIKE ? AND ADDRESS LIKE ? AND STAR <= ? ";

      PreparedStatement prepStmt =
	    con.prepareStatement(selectStatement);

      prepStmt.setString(1, "%" + name + "%");
      prepStmt.setString(2, "%" + description + "%");
      prepStmt.setString(3, "%" + address + "%");
      prepStmt.setInt(4, star);
      System.out.println("SQL in selectByNameDescriptionAddressStar: " + prepStmt.toString());
      ResultSet rs = prepStmt.executeQuery();

      ArrayList a = new ArrayList();

      while (rs.next()) {
	 String id = rs.getString(1);
	 a.add(id);
      }

      prepStmt.close();
      System.out.println("end selectByNameDescriptionAddressStar in Hotel");
      return a;
   }

   private void loadRow() throws SQLException {
      System.out.println("loadRow in Hotel");

	  String selectStatement =
		"select HOTEL_NAME, DESCRIPTION, ADDRESS, STAR, TELEPHONE_NO, ACCOUNT_ID, PASSWORD, LOGO, HOTEL_PICTURE " +
		"from HOTEL where HOTEL_ID = ? ";
	  PreparedStatement prepStmt =
		con.prepareStatement(selectStatement);

	  prepStmt.setString(1, this.hotelID);

	  ResultSet rs = prepStmt.executeQuery();

	  if (rs.next()) {
	 this.hotelName = rs.getString(1);
	 this.description = rs.getString(2);
	 this.address = rs.getString(3);
	 this.star = rs.getInt(4);
	 this.telephoneNo = rs.getString(5);
	 this.accountId = rs.getString(6);
	 this.password = rs.getString(7);
	 this.logo = rs.getString(8);
	 this.hotelPicture = rs.getString(9);

	 prepStmt.close();
	  }
	  else {
	 prepStmt.close();
	 throw new NoSuchEntityException("Row for id " + hotelID +
		" not found in database.");
	  }
      System.out.println("end loadRow in Hotel");
   }

   private void storeRow() throws SQLException {
      System.out.println("storeRow in Hotel");

	  String updateStatement =
		"update HOTEL set " +
		"HOTEL_NAME =  ? ," +
		"DESCRIPTION = ? ," +
		"ADDRESS = ? ," +
		"STAR = ? ," +
		"TELEPHONE_NO = ? ," +
		"ACCOUNT_ID = ? ," +
		"PASSWORD = ? ," +
		"LOGO = ? ," +
		"HOTEL_PICTURE = ? " +
		"where HOTEL_ID = ?";
	  PreparedStatement prepStmt =
		con.prepareStatement(updateStatement);

	  prepStmt.setString(1, hotelName);
	  prepStmt.setString(2, description);
	  prepStmt.setString(3, address);
	  prepStmt.setInt(4, star);
	  prepStmt.setString(5, telephoneNo);
	  prepStmt.setString(6, accountId);
	  prepStmt.setString(7, password);
	  prepStmt.setString(8, logo);
	  prepStmt.setString(9, hotelPicture);

	  prepStmt.setString(10, hotelID);

	  int rowCount = prepStmt.executeUpdate();
	  prepStmt.close();

	  if (rowCount == 0) {
	 throw new EJBException("Storing row for id " + hotelID + " failed.");
	  }
      System.out.println("end storeRow in Hotel");
   }
  public void setAddress(String newAddress) {
	address = newAddress;
  }
  public String getAddress() {
	return address;
  }

}