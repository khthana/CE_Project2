package olalatour;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;
import java.sql.Timestamp;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import java.sql.*;
import hotelsystem.*;
import restaurantsystem.*;
import busservice.*;
import airlinesystem.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class OlalaAgencyController implements SessionBean {
	static final String DEFAULT_BUS_CUSTOMER_ID = "";
	static final String DEFAULT_AIRLINE_CUSTOMER_ID = "";
	static final String DEFAULT_HOTEL_CUSTOMER_ID = "";

	private SessionContext sessionContext;
	public void ejbCreate() {
	}
	public void ejbRemove() {
	}
	public void ejbActivate() {
	}
	public void ejbPassivate() {
	}
	public void setSessionContext(SessionContext context) {
	sessionContext = context;
	}
	public String createTraveller(String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String foodTypeId) {
	System.out.println("createTraveller in OlalaAgencyController");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Traveller");
	  System.out.println("lookup");

	  TravellerHome home = (TravellerHome)PortableRemoteObject.narrow(objref, TravellerHome.class);
	  System.out.println("narrow");

	  String travellerID = getNewBookingID();
	  TravellerRemote remote = home.create(travellerID, firstName, lastName, address, telephoneNo, emailAddress, gender, birthDate, religion, DEFAULT_BUS_CUSTOMER_ID, DEFAULT_AIRLINE_CUSTOMER_ID, foodTypeId);

	  System.out.println("createTraveller in OlalaAgencyController");
	  return travellerID;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	}
	public String createMember(String firstName, String lastName, String address, String telephoneNo, String emailAddress, Integer gender, java.sql.Date birthDate, String religion, String password) {
	System.out.println("createMember in OlalaAgencyController");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Member");
	  System.out.println("lookup");

	  MemberHome home = (MemberHome)PortableRemoteObject.narrow(objref, MemberHome.class);
	  System.out.println("narrow");

	  String memberID = getNewBookingID();
	  MemberRemote remote = home.create(memberID, firstName, lastName, address, telephoneNo, emailAddress, gender, birthDate, religion, password, DEFAULT_HOTEL_CUSTOMER_ID);

	  System.out.println("createMember in OlalaAgencyController");
	  return memberID;
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	}
	protected String getNewBookingID() {
	try {
	  Context initial = new InitialContext();
	  Object objref = initial.lookup("olalatour/UUIDGenerator");

	  UUIDGeneratorHome home = (UUIDGeneratorHome)PortableRemoteObject.narrow(objref, UUIDGeneratorHome.class);
	  UUIDGeneratorRemote uuidGenerator = home.create();

	  return uuidGenerator.getUUID();
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	}
	public String reserve(FullBookingInformation fullBookingInformation) {
	  /** @todo cast all travellerID to customerID if doesn't have create it and store */
	  String bookingID = getNewBookingID();
	  double totalPrice = 0 ;
	  Timestamp bookingTime = new Timestamp(System.currentTimeMillis());
	  int confirmed = 0;
	  java.sql.Date deadline = null;
	  String memberID = fullBookingInformation.getMemberID();
	  String busGroupBooking = null;
	  String aircraftGroupBooking = null;
	  String hotelGroupBookingID = null;

	  if (fullBookingInformation.getHotelBookingInformations().size() != 0) {
		  hotelsystem.ReserveResult result = reserveHotel(bookingID, fullBookingInformation.getMemberID(), fullBookingInformation.getHotelBookingInformations());
		  hotelGroupBookingID = result.getBookingID();
		  totalPrice += result.getPrice();
		  System.out.println("finished hotel");
	  }
	  if (fullBookingInformation.getAirlineBookingInformation().size() != 0) {
		  Collection c = reserveAirline(bookingID, fullBookingInformation.getAirlineBookingInformation());
		  Iterator i = c.iterator();
		  airlinesystem.BookSeatResult result = null;
		  while (i.hasNext()) {
		  result = (airlinesystem.BookSeatResult)i.next();
		  totalPrice += result.getPrice();
		  }
		  aircraftGroupBooking = result.getBookingID();
		  System.out.println("finished air");
	  }
	  if (fullBookingInformation.getBusBookingInformations().size() != 0) {
		  Collection c = reserveBus(bookingID, fullBookingInformation.getBusBookingInformations());
		  Iterator i = c.iterator();
		  busservice.BookSeatResult result = null;
		  while (i.hasNext()) {
		  result = (busservice.BookSeatResult)i.next();
		  totalPrice += result.getPrice();
		  }
		  busGroupBooking = result.getBookingID();
		  System.out.println("finished bus");
	  }
	  if (fullBookingInformation.getPackageBookingInformation().size() != 0) {
		  totalPrice += reservePackage(bookingID, fullBookingInformation.getPackageBookingInformation());
		  System.out.println("finished package");
	  }
	  try {
		Context initial = new InitialContext();
		System.out.println("initialContext");
		Object objref = initial.lookup("olalatour/Booking");
		System.out.println("lookup");
		BookingHome home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
		System.out.println("narrow");
		BookingRemote remote = home.create(bookingID, new Double(totalPrice), bookingTime, new Integer(confirmed), deadline, memberID, busGroupBooking, aircraftGroupBooking, hotelGroupBookingID);
		return bookingID;
	  }
	  catch (Exception ex) {
		throw new EJBException(ex.getMessage());
	  }

	}
	protected hotelsystem.ReserveResult reserveHotel(String bookingID, String memberID, Collection hotelBookingInformations) {
	try {
		System.out.println("reserveHotel in OlalaAgencyController");
		String hotelCustomerID = getHotelCustomerID(memberID);

		// ----------------------------------------------------------------------------- //
		Context initial = new InitialContext();
		System.out.println("initialContext");
		Object objref = initial.lookup("hotelsystem/HotelController");
		System.out.println("lookup");

		HotelControllerHome home = (HotelControllerHome)PortableRemoteObject.narrow(objref, HotelControllerHome.class);
		System.out.println("narrow");
		HotelControllerRemote remote = home.create();
		return remote.reserve(hotelCustomerID, hotelBookingInformations);
	}
	catch(Exception ex) {
		throw new EJBException(ex.getMessage());
	}
	}
	protected String getHotelCustomerID(String memberID) {
	System.out.println("getHotelCustomerID in OlalaAgencyController");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Member");
	  System.out.println("lookup");

	  MemberHome home = (MemberHome)PortableRemoteObject.narrow(objref, MemberHome.class);
	  System.out.println("narrow");

	  MemberRemote remote = home.findByPrimaryKey(memberID);

	  if (remote.getHotelCustomerId().equals(DEFAULT_HOTEL_CUSTOMER_ID)) {
		  Object hotelref = initial.lookup("hotelsystem/HotelController");
		  System.out.println("lookup");

		  HotelControllerHome hotelhome = (HotelControllerHome)PortableRemoteObject.narrow(hotelref, HotelControllerHome.class);
		  System.out.println("narrow");

		  HotelControllerRemote hotelremote = hotelhome.create();
		  String newHotelCustomerID = hotelremote.createCustomer(remote.getFirstName(), remote.getLastName(), remote.getAddress(), remote.getTelephoneNo(), remote.getGender().intValue());
		  remote.setHotelCustomerId(newHotelCustomerID);
		  return newHotelCustomerID;
	  }
	  else {
		System.out.println("end getHotelCustomerID in OlalaAgencyController");
		return remote.getHotelCustomerId();
	  }
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	}
	protected Collection reserveAirline(String bookingID, Collection airlineBookingInformations) {
	try {
		System.out.println("reserveAirline in OlalaAgencyController");
		Collection castedAirlineBookingInformations = new ArrayList();
		Iterator iterator = airlineBookingInformations.iterator();

		// ---------------------------cast------------------------------------------------- //
		while (iterator.hasNext()) {
		airlinesystem.BookSeatInfo originalInfo = (airlinesystem.BookSeatInfo)iterator.next();
		airlinesystem.BookSeatInfo castedInfo = new airlinesystem.BookSeatInfo(getAirlineCustomerID(originalInfo.getCustomerID()), originalInfo.getFirstName(), originalInfo.getLastName(), originalInfo.getAddress(), originalInfo.getTelephoneNo(), originalInfo.getFlightID(), originalInfo.getSrcIdx(), originalInfo.getDstIdx(), originalInfo.getSeatType(), originalInfo.getClassType(), originalInfo.getDepartTime(), originalInfo.getCanSmoking(), originalInfo.getPrice());
		castedAirlineBookingInformations.add(castedInfo);
		}
		// ---------------------------book---------------------------------------------- //
		Context initial = new InitialContext();
		System.out.println("initialContext");
		Object objref = initial.lookup("airlinesystem/ReserveController");
		System.out.println("lookup");

		airlinesystem.ReserveControllerHome home = (airlinesystem.ReserveControllerHome)PortableRemoteObject.narrow(objref, airlinesystem.ReserveControllerHome.class);
		System.out.println("narrow");
		airlinesystem.ReserveControllerRemote remote = home.create();
		ArrayList a = new ArrayList(castedAirlineBookingInformations);
		Collection bookSeatInfos = remote.BookSeat(a);

		// -------------------------------recordss-------------------------------------------------- //
		Object objref2 = initial.lookup("olalatour/PersonalBooking");
		System.out.println("lookup");
		PersonalBookingHome home2 = (PersonalBookingHome)PortableRemoteObject.narrow(objref2, PersonalBookingHome.class);
		System.out.println("narrow");

		Iterator iterator2 = airlineBookingInformations.iterator();
		System.out.println("iterator");
		/** @todo keep personalBooking */
//		while (iterator2.hasNext()) {
//		  airlinesystem.BookSeatInfo originalInfo = (airlinesystem.BookSeatInfo)iterator2.next();
//		  try {
//			PersonalBookingRemote remote2 = home2.findByPrimaryKey(new PersonalBookingPK(bookingID, originalInfo.getCustomerID()));
//			System.out.println("findByPrimaryKey");
//			remote2.setHasBookAirSeat(new Boolean(true));
//		  }
//		  catch (FinderException ex) {
//			System.out.println("create new personal booking");
//			home2.create(bookingID, originalInfo.getCustomerID(), new Boolean(false), new Boolean(true));
//		  }
//		}
		System.out.println("end reserveAirline in OlalaAgencyController");
		return bookSeatInfos;
	}
	catch(Exception ex) {
		throw new EJBException(ex.getMessage());
	}
	}
	protected String getAirlineCustomerID(String travellerID) {
	System.out.println("getAirlineCustomerID in OlalaAgencyController");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Traveller");
	  System.out.println("lookup");

	  TravellerHome home = (TravellerHome)PortableRemoteObject.narrow(objref, TravellerHome.class);
	  System.out.println("narrow");

	  TravellerRemote remote = home.findByPrimaryKey(travellerID);

	  if (remote.getAirlineCustomerId().equals(DEFAULT_AIRLINE_CUSTOMER_ID)) {
		  Object hotelref = initial.lookup("airlinesystem/ReserveController");
		  System.out.println("lookup");

		  airlinesystem.ReserveControllerHome hotelhome = (airlinesystem.ReserveControllerHome)PortableRemoteObject.narrow(hotelref, airlinesystem.ReserveControllerHome.class);
		  System.out.println("narrow");

		  airlinesystem.ReserveControllerRemote hotelremote = hotelhome.create();
		  String newHotelCustomerID = hotelremote.CreateCustomer(remote.getFirstName(), remote.getLastName(), remote.getAddress(), remote.getTelephoneNo());
		  remote.setAirlineCustomerId(newHotelCustomerID);
		  System.out.println("end getAirlineCustomerID in OlalaAgencyController");
		  return newHotelCustomerID;
	  }
	  else {
		System.out.println("end getAirlineCustomerID in OlalaAgencyController");
		return remote.getAirlineCustomerId();
	  }
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	}
	protected Collection reserveBus(String bookingID, Collection busBookingInformations) {
	try {
		System.out.println("reserveBus in OlalaAgencyController");
		Collection castedBusBookingInformations = new ArrayList();
		Iterator iterator = busBookingInformations.iterator();

		// ---------------------- CAST ------------------------------------------------------ //
		while (iterator.hasNext()) {
		busservice.BookSeatInfo originalInfo = (busservice.BookSeatInfo)iterator.next();
		busservice.BookSeatInfo castedInfo = new busservice.BookSeatInfo(getBusCustomerID(originalInfo.getCustomerID()), originalInfo.getFirstName(), originalInfo.getLastName(), originalInfo.getAddress(), originalInfo.getTelephoneNo(), originalInfo.getRouteID(), originalInfo.getSrcIdx(), originalInfo.getDstIdx(), originalInfo.getSeatType(), originalInfo.getDepartTime(), originalInfo.getPrice());
		castedBusBookingInformations.add(castedInfo);
		}
		// -----------------------BOOK---------------------------------------------------------- //
		Context initial = new InitialContext();
		System.out.println("initialContext");
		Object objref = initial.lookup("busservice/ReserveController");
		System.out.println("lookup");

		busservice.ReserveControllerHome home = (busservice.ReserveControllerHome)PortableRemoteObject.narrow(objref, busservice.ReserveControllerHome.class);
		System.out.println("narrow");
		busservice.ReserveController remote = home.create();
		ArrayList a = new ArrayList(castedBusBookingInformations);
		Collection bookSeatInfos = remote.BookSeat(a);

		// -----------------------record---------------------------------------------------------- //
		Object objref2 = initial.lookup("olalatour/PersonalBooking");
		System.out.println("lookup");
		PersonalBookingHome home2 = (PersonalBookingHome)PortableRemoteObject.narrow(objref2, PersonalBookingHome.class);
		System.out.println("narrow");

//		Iterator iterator2 = busBookingInformations.iterator();
//		while (iterator2.hasNext()) {
//		  busservice.BookSeatInfo originalInfo = (busservice.BookSeatInfo)iterator2.next();
//		  try {
//			PersonalBookingRemote remote2 = home2.findByPrimaryKey(new PersonalBookingPK(bookingID, originalInfo.getCustomerID()));
//			remote2.setHasBookBusSeat(new Boolean(true));
//		  }
//		  catch (FinderException ex) {
//			home2.create(bookingID, originalInfo.getCustomerID(), new Boolean(true), new Boolean(false));
//		  }
//		}
		return bookSeatInfos;
	}
	catch(Exception ex) {
		throw new EJBException(ex.getMessage());
	}
	}
	protected String getBusCustomerID(String travellerID) {
	System.out.println("getBusCustomerID in OlalaAgencyController");
	try {
	  Context initial = new InitialContext();
	  System.out.println("initialContext");
	  Object objref = initial.lookup("olalatour/Member");
	  System.out.println("lookup");

	  TravellerHome home = (TravellerHome)PortableRemoteObject.narrow(objref, TravellerHome.class);
	  System.out.println("narrow");

	  TravellerRemote remote = home.findByPrimaryKey(travellerID);

	  if (remote.getBusCompanyCustomerId().equals(DEFAULT_BUS_CUSTOMER_ID)) {
		  Object hotelref = initial.lookup("busservice/ReserveController");
		  System.out.println("lookup");

		  busservice.ReserveControllerHome hotelhome = (busservice.ReserveControllerHome)PortableRemoteObject.narrow(hotelref, airlinesystem.ReserveControllerHome.class);
		  System.out.println("narrow");

		  busservice.ReserveController hotelremote = hotelhome.create();
		  String newHotelCustomerID = hotelremote.CreateCustomer(remote.getFirstName(), remote.getLastName(), remote.getAddress(), remote.getTelephoneNo());
		  remote.setBusCompanyCustomerId(newHotelCustomerID);
		  return newHotelCustomerID;
	  }
	  else {
		System.out.println("end getBusCustomerID in OlalaAgencyController");
		return remote.getBusCompanyCustomerId();
	  }
	}
	catch (Exception ex) {
	  throw new EJBException(ex.getMessage());
	}
	}
	protected double reservePackage(String bookingID, Collection packageBookingInformations) {
		/** @todo  */
		double totalPrice = 0;
		System.out.println("reservePackage in OlalaAgencyController");
		try {
		  Iterator iterator = packageBookingInformations.iterator();
		  Context initial = new InitialContext();
		  System.out.println("initialContext");
		  Object objref = initial.lookup("olalatour/PackageBooking");
		  System.out.println("lookup");
		  PackageBookingHome home = (PackageBookingHome)PortableRemoteObject.narrow(objref, PackageBookingHome.class);
		  System.out.println("narrow");
		  Object objref2 = initial.lookup("olalatour/PackageTour");
		  System.out.println("lookup");
		  PackageTourHome home2 = (PackageTourHome)PortableRemoteObject.narrow(objref2, PackageTourHome.class);
		  System.out.println("narrow");

		  // ---------------------- CAST ------------------------------------------------------ //
		  while (iterator.hasNext()) {
			PackageBookingInformation info = (PackageBookingInformation)iterator.next();
			home.create(info.getTravellerID(), info.getPackageID(), info.getDepartTIme(), bookingID);
			PackageTourRemote remote = home2.findByPrimaryKey(info.getPackageID());
			totalPrice += remote.getTotalPrice().doubleValue();
		  }
		  return totalPrice;
		}
		catch (Exception ex) {
		  throw new EJBException(ex.getMessage());
		}
	}
	public void modify(String bookingID, FullBookingInformation fullBookingInformation) {
	/** @todo search bookingID and cast all travellerID to customerID if doesn't have create it and store */

	}
	public boolean confirm(String bookingID, String transactionID) {
	  try {
		Context initial = new InitialContext();
		System.out.println("initialContext");
		Object objref = initial.lookup("olalatour/Booking");
		System.out.println("lookup");
		BookingHome home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
		System.out.println("narrow");
		BookingRemote remote = home.findByPrimaryKey(bookingID);
		if (!remote.confirm()) {
		  return false;
		}
		//-----------------------check txID-------------------------------
		if (transactionID == null) {
		  return false;
		}
		Object bankobjref = initial.lookup("banksystem/BankController");
		System.out.println("lookup");
		banksystem.BankControllerHome bankhome = (banksystem.BankControllerHome)PortableRemoteObject.narrow(bankobjref, banksystem.BankControllerHome.class);
		System.out.println("narrow");
		banksystem.BankControllerRemote bankremote = bankhome.create();
		try {
		  bankremote.checkTransfer("OLALATOUR_ACCOUNT_ID", transactionID, remote.getTotalPrice().doubleValue());
		}
		catch (Exception ex) {
		  return false;
		}


		// ----------------------check txID-------------------------------
		String aircraftGroupBookingID = remote.getAircraftGroupBooking();
		String busGroupBookingID = remote.getBusGroupBooking();
		String hotelGroupBookingID = remote.getHotelGroupBookingId();

		//---------------------bus-------------------------------
		if (busGroupBookingID != "") {
		  Object objref2 = initial.lookup("busservice/ModifyController");
		  System.out.println("lookup");

		  busservice.ModifyControllerHome home2 = (busservice.ModifyControllerHome)PortableRemoteObject.narrow(objref2, busservice.ModifyControllerHome.class);
		  System.out.println("narrow");
		  busservice.ModifyControllerRemote remote2 = home2.create();
		  if (!remote2.confirmBooking(busGroupBookingID)) {
			return false;
		  }
		}
		//-------------------------------------------------------------
		//---------------------air-------------------------------
		if (aircraftGroupBookingID != "") {
		  Object objref3 = initial.lookup("airlinesystem/ModifyController");
		  System.out.println("lookup");

		  airlinesystem.ModifyControllerHome home3 = (airlinesystem.ModifyControllerHome)PortableRemoteObject.narrow(objref3, airlinesystem.ModifyControllerHome.class);
		  System.out.println("narrow");
		  airlinesystem.ModifyControllerRemote remote3 = home3.create();
		  if (!remote3.confirmBooking(aircraftGroupBookingID)) {
			return false;
		  }
		}
		//-------------------------------------------------------------
		//---------------------hotel-------------------------------
		if (hotelGroupBookingID != "") {
		  Object objref4 = initial.lookup("hotelsystem/HotelController");
		  System.out.println("lookup");

		  hotelsystem.HotelControllerHome home4 = (hotelsystem.HotelControllerHome)PortableRemoteObject.narrow(objref4, hotelsystem.HotelControllerHome.class);
		  System.out.println("narrow");
		  hotelsystem.HotelControllerRemote remote4 = home4.create();
		  try {
			remote4.confirm(hotelGroupBookingID);
		  }
		  catch (Exception ex) {
			return false;
		  }
		}
		//-------------------------------------------------------------
		return true;
	  }
	  catch (Exception ex) {
		throw new EJBException(ex.getMessage());
	  }
	}
	public boolean cancel(String bookingID) {
	  try {
		Context initial = new InitialContext();
		System.out.println("initialContext");
		Object objref = initial.lookup("olalatour/Booking");
		System.out.println("lookup");
		BookingHome home = (BookingHome)PortableRemoteObject.narrow(objref, BookingHome.class);
		System.out.println("narrow");
		BookingRemote remote = home.findByPrimaryKey(bookingID);
		if (!remote.cancel()) {
		  return false;
		}

		String aircraftGroupBookingID = remote.getAircraftGroupBooking();
		String busGroupBookingID = remote.getBusGroupBooking();
		String hotelGroupBookingID = remote.getHotelGroupBookingId();

		//---------------------bus-------------------------------
		Object objref2 = initial.lookup("busservice/ModifyController");
		System.out.println("lookup");

		busservice.ModifyControllerHome home2 = (busservice.ModifyControllerHome)PortableRemoteObject.narrow(objref2, busservice.ModifyControllerHome.class);
		System.out.println("narrow");
		busservice.ModifyControllerRemote remote2 = home2.create();
		if (!remote2.CancelBooking(busGroupBookingID)) {
		  return false;
		}
		//-------------------------------------------------------------
		//---------------------air-------------------------------
		Object objref3 = initial.lookup("airlinesystem/ModifyController");
		System.out.println("lookup");

		airlinesystem.ModifyControllerHome home3 = (airlinesystem.ModifyControllerHome)PortableRemoteObject.narrow(objref3, airlinesystem.ModifyControllerHome.class);
		System.out.println("narrow");
		airlinesystem.ModifyControllerRemote remote3 = home3.create();
		if (!remote3.CancelBooking(aircraftGroupBookingID)) {
		  return false;
		}
		//-------------------------------------------------------------
		//---------------------hotel-------------------------------
		Object objref4 = initial.lookup("hotelsystem/HotelController");
		System.out.println("lookup");

		hotelsystem.HotelControllerHome home4 = (hotelsystem.HotelControllerHome)PortableRemoteObject.narrow(objref4, hotelsystem.HotelControllerHome.class);
		System.out.println("narrow");
		hotelsystem.HotelControllerRemote remote4 = home4.create();
		try {
		  remote4.cancel(hotelGroupBookingID);
		}
		catch (Exception ex) {
		  return false;
		}
		//-------------------------------------------------------------
		return true;
	  }
	  catch (Exception ex) {
		throw new EJBException(ex.getMessage());
	  }
	}
}