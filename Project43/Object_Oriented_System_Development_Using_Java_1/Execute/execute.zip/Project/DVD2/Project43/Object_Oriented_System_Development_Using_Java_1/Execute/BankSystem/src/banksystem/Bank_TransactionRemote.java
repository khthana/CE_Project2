package banksystem;

import java.rmi.*;
import javax.ejb.*;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */
public interface Bank_TransactionRemote extends EJBObject {

  public java.sql.Timestamp getTxDate() throws RemoteException;
  public void setTxDate(java.sql.Timestamp newTxDate) throws RemoteException;
  public double getMoney() throws RemoteException;
  public void setMoney(double newMoney) throws RemoteException;
  public int getTransactionType() throws RemoteException;
  public void setTransactionType(int newTransactionType) throws RemoteException;
  public java.lang.String getRelateAccountID() throws RemoteException;
  public void setRelateAccountID(java.lang.String newRalateAccountID) throws RemoteException;
  public java.lang.String getAccountID() throws RemoteException;
  public void setAccountID(java.lang.String newAccountID) throws RemoteException;
  public java.lang.String getTransactionID() throws RemoteException;
  public void setTransactionID(java.lang.String newTransactionID) throws RemoteException;
}