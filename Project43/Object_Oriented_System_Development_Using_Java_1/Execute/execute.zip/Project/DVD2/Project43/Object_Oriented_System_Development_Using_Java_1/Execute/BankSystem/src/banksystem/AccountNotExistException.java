package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class AccountNotExistException extends Exception {

   public AccountNotExistException() { }

   public AccountNotExistException(String msg) {
      super(msg);
   }
}