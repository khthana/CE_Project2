package restaurantsystem;

import java.rmi.*;
import javax.ejb.*;
import java.sql.Date;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public interface BookingRemote extends EJBObject {
  public java.lang.String getAgencyID() throws RemoteException;
  public int getNoOfReserveSeat() throws RemoteException;
  public int getConfirmation() throws RemoteException;
  public java.lang.String getBookingID() throws RemoteException;
  public int getMeal() throws RemoteException;
  public java.lang.String getRestaurantID() throws RemoteException;
  public void confirm() throws RemoteException, AlreadyCancelException;
  public void cancel() throws RemoteException, AlreadyConfirmException;
  public void modify(String restaurantID, int meal, java.sql.Date dateTime,
      int noOfReserveSeat, String agencyID)
	throws RemoteException, InvalidRestaurantException, InvalidMealException,
	  SeatNotAvailableException, InvalidAgentException, AlreadyCancelException, AlreadyConfirmException;
    public java.sql.Date getDateTime() throws RemoteException;
}