package banksystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class BankControllerException extends Exception {

  public BankControllerException() {
  super();
  }
  public BankControllerException(Exception e) {
  super (e.toString());
  }
  public BankControllerException(String s) {
  super(s);
  }
}