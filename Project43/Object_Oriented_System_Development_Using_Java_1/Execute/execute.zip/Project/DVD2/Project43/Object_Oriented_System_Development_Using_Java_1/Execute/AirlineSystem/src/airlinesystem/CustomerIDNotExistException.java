package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class CustomerIDNotExistException extends Exception {

  public CustomerIDNotExistException() {}

  public CustomerIDNotExistException( String msg) {
    super(msg);
  }
}
