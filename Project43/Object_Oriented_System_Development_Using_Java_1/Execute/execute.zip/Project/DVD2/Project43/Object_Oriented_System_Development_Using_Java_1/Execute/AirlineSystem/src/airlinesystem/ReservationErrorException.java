package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class ReservationErrorException extends Exception {

   public ReservationErrorException () { }

   public ReservationErrorException(String msg) {
      super(msg);
   }
}