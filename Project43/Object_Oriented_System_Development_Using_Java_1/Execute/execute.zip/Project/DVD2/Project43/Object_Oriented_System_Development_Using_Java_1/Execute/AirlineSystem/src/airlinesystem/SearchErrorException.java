package airlinesystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */


public class SearchErrorException extends Exception {

   public SearchErrorException () { }

   public SearchErrorException(String msg) {
      super(msg);
   }
}