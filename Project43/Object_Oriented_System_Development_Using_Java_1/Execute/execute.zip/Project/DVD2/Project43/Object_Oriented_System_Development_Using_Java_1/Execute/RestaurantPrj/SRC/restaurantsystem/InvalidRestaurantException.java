package restaurantsystem;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:
 * @author
 * @version 1.0
 */

public class InvalidRestaurantException extends Exception {

  public InvalidRestaurantException() {
  }
}