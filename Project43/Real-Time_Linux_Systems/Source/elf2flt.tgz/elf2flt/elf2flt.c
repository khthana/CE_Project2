/* elf2flt.c: Convert ELF (or any BFD format) to FLAT binary format
 *
 * (c) 1999, Greg Ungerer <gerg@moreton.com.au>
 * (c) 1999, Phil Blundell, Nexus Electronics Ltd <pb@nexus.co.uk>
 *
 * Hacked this about badly to fully support relocating binaries.
 *
 * Originally obj-res.c
 *
 * (c) 1998, Kenneth Albanowski <kjahds@kjahds.com>
 * (c) 1998, D. Jeff Dionne
 * (c) 1998, The Silver Hammer Group Ltd.
 * (c) 1996, 1997 Dionne & Associates
 * jeff@ryeham.ee.ryerson.ca
 *
 * This is Free Software, under the GNU Public Licence v2 or greater.
 *
 * Relocation added March 1997, Kresten Krab Thorup 
 * krab@california.daimi.aau.dk
 */
 
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <getopt.h>
#include <stdarg.h>
#include <bfd.h>
#include "arm.h"
#include <string.h>
#include "flat.h"

#ifndef PARAMS
#define PARAMS(x) x
#endif

int verbose = 0;
int dsyms = 0;

#ifdef __CYGWIN32__
#define O_PLATFORM O_BINARY
#else
#define O_PLATFORM 0
#endif

#define MAX_SECTIONS 16

typedef struct _segment_info
{
  const char *name;
  bfd_vma low_mark;
  bfd_vma high_mark;
  size_t size;
  void *contents;
  asection *subsect[MAX_SECTIONS];
  int nsubsects;
} segment_info;

const char *progname, *filename;
int lineno;

int nerrors = 0;
int nwarnings = 0;

asymbol**
get_symbols (bfd *abfd, long *num)
{
  long storage_needed;
  asymbol **symbol_table;
  long number_of_symbols;

  if (dsyms)
	  storage_needed = bfd_get_dynamic_symtab_upper_bound (abfd);
  else
	  storage_needed = bfd_get_symtab_upper_bound (abfd);
	  
  if (storage_needed < 0)
    abort ();
      
  if (storage_needed == 0)
    return NULL;

  symbol_table = (asymbol **) malloc (storage_needed);

  if (dsyms)
	  number_of_symbols = bfd_canonicalize_dynamic_symtab (abfd, symbol_table);
  else
	  number_of_symbols = bfd_canonicalize_symtab (abfd, symbol_table);
  if (number_of_symbols < 0) 
    abort ();

  *num = number_of_symbols;
  return symbol_table;
}

struct flat_reloc *
output_relocs (bfd *input_bfd, asymbol **symbols, int number_of_symbols, unsigned long *n_relocs, segment_info *text, segment_info *data, segment_info *bss)
{
  struct flat_reloc	*flat_relocs;
  asection		*sym_section;
  arelent		**relpp, **p, *q;
  const char		*sym_name, *section_name;
  long			section_vma;
  int			relsize, relcount;
  int			reltype, flat_reloc_count;
  int			rc;
  bfd_vma		v, addend;
  segment_info		*relseg, *addseg;
  unsigned long		seg_offset;

  *n_relocs = 0;
  flat_relocs = NULL;
  flat_reloc_count = 0;
  rc = 0;


  relsize = bfd_get_dynamic_reloc_upper_bound(input_bfd);
  if (relsize <= 0) {
    if (verbose)
      printf("no relocation entries\n");
    return 0;
  }

  relpp = (arelent **) malloc(relsize);
  relcount = bfd_canonicalize_dynamic_reloc(input_bfd, relpp, symbols);
  if (relcount <= 0) {
    if (verbose)
      printf("no relocation entries\n");
    *n_relocs = 0;
    return NULL;
  }

  for (p = relpp; (relcount && (*p != NULL)); p++, relcount--) {
    q = *p;
    if (q->sym_ptr_ptr && *q->sym_ptr_ptr) {
      sym_name = (*(q->sym_ptr_ptr))->name;
      sym_section = (*(q->sym_ptr_ptr))->section;
      section_name=(*(q->sym_ptr_ptr))->section->name;
      if (verbose)
	printf("reloc address %08x type %s\n", q->address, q->howto->name);
      switch (q->howto->type)
	{
	case R_ARM_RELATIVE:
	  /* This reloc describes an offset from the "program base".
	     We need to figure out which segment it actually refers to,
	     fiddle the addend and output an appropriate FLAT reloc
	     to be resolved at run time.  */
	  /* XXX In an ideal world, the linker would output different
	     relocs for the different sections, so we wouldn't need to
	     grub around in the memory map quite so much.  */
	  v = q->address;
	  reltype = -1;
	  relseg = addseg = NULL;
	  if (v >= text->low_mark && v <= text->high_mark)
	    {
	      /* The existing FLAT binary format only allows relocs to be in
		 the .data segment.  Relocating in .text would be bad practice
		 anyway so this is no great loss. */
#if 0
	      printf ("ERROR: Illegal RELATIVE reloc in text segment.\n");
	      rc = -1;
#else
	      /* XXX */
              static i_was_there = 0;
              if(!i_was_there)
              {
                i_was_there = 1;
	        printf ("WARNING: Illegal RELATIVE reloc(s) in text segment -- ignored.\n");
              }
	      // printf ("at 0x%06x\n", v);
#endif
	      continue;
	    }
	  else if (v >= data->low_mark && v <= data->high_mark)
	    relseg = data;
	  
	  if (! relseg)
	    {
	      /* This reloc isn't in the text or data segment.  Probably
		 it refers to debug information and we can just ignore it.  */
	      if (verbose)
		fprintf(stderr, "WARNING: ignoring reloc at %08x\n", v);
	      continue;
	    }

	  /* Locate the reloc in the appropriate segment and extract the
	     existing addend.  */
	  seg_offset = v - relseg->low_mark;
	  addend = *((bfd_vma *)(relseg->contents + seg_offset));

	  if (verbose)
	    printf("RELATIVE reloc at (%s+%x) addend %08x ", relseg->name,
		   seg_offset, addend);

	  /* Locate the address referred to by the addend.  */
	  if (addend >= text->low_mark && addend <= text->high_mark)
	    {
	      reltype = FLAT_RELOC_TYPE_TEXT;
	      addseg = text;
	    }
	  else if (addend >= data->low_mark && addend <= data->high_mark)
	    {
	      reltype = FLAT_RELOC_TYPE_DATA;
	    addseg = data;
	    }
	  else if (addend >= bss->low_mark && addend <= bss->high_mark)
	    {
	      reltype = FLAT_RELOC_TYPE_BSS;
	      addseg = bss;
	    }

	  if (! addseg)
	    {
	      /* The addend isn't within any of the segments we know about.
		 This might mean it was in a section we threw away.  In any case,
	         there is nothing we can do about it now.  */
	      if (verbose)
		printf ("(unknown)\n");
	      else
#if 0
		printf ("ERROR: reloc at (%s+%x) has out of range addend %08x\n",
			relseg->name, seg_offset, addend);
	      rc = -1;
#else
		printf ("WARNING: reloc at (%s+%x) has out of range addend %08x -- ignored\n",
			relseg->name, seg_offset, addend);
#endif
	      continue;
	    }
	  
	  /* Factor out the starting VMA of the segment, adjust the addend
	     in core and output a new reloc.  */
	  addend -= addseg->low_mark;
	  if (verbose)
	    printf("(%s+%x)\n", addseg->name, addend);
	  *((bfd_vma *)(relseg->contents + seg_offset))	= addend;
	  
	  flat_relocs = realloc(flat_relocs, (flat_reloc_count + 1) 
				* sizeof(struct flat_reloc));
	  flat_relocs[flat_reloc_count].type = reltype;
	  flat_relocs[flat_reloc_count].offset = seg_offset;
	  flat_reloc_count++;
	  break;

	case R_ARM_PC24:
	case R_ARM_GLOB_DAT:
	  /* Because we linked with -Bsymbolic, the linker will
	     already have resolved all function calls apart from those
	     to undefined symbols.  So long as this is a weak
	     reference, we do nothing and the reloc will be incomplete
	     - it is up to the application to avoid executing such
	     branches.  Global data relocs are also OK to leave
	     unresolved since they will yield zero by default.  If we
	     encounter an unresolved strong reference we punt; the
	     linker should have trapped this case already so this is a
	     "can't happen" situation.  */
	  if (! ((*q->sym_ptr_ptr)->flags & BSF_WEAK))
	    {
	      printf ("ERROR: undefined symbolic reference to %s\n",
		      (*q->sym_ptr_ptr)->name);
	      rc = -1;
	    }
	  break;

	default:
	  printf("ERROR: unknown reloc type %s\n", q->howto->name);
	  rc = -1;
	  break;
	}
    } else {
      printf("ERROR: undefined relocation entry\n");
      rc = -1;
      continue;
    }
  }

  if (rc < 0)
    return(NULL);
  
  *n_relocs = flat_reloc_count;
  return flat_relocs;
}

static char * program;
static void usage(void)
{  
    fprintf(stderr, "Usage: %s [-v] [-d] [-l] [-s stacksize] [-o output.file] bfd.file\n", program);
    exit(2);
}

/* Return 1 if this is a section that we want to throw away but can only
   identify by name.   Normally, any section with appropriate-looking flags
   will get copied into the output file.  */
static int
is_unwanted_section(asection *s)
{
  if (!strcmp(s->name, ".hash"))
    return 1;
  if (!strcmp(s->name, ".dynstr") || !strcmp(s->name, ".dynsym"))
    return 1;
  if (s->flags & SEC_DEBUGGING)
    return 1;
  return 0;
}

static void dump_elf_section(asection* s)
{
	printf("SECTION: %s  at: 0x%08x size: 0x%08x(%d) till: 0x%08x flags: 0x%08x \n", s->name, s->vma, s->_cooked_size,s->_cooked_size,
		  s->vma + s->_cooked_size, s->flags);
}


/* Return 1 if this is a section containing reloc information.  */
static int
is_reloc_section(asection *s)
{
  if (!strncmp(s->name, ".rel", 4))
    return 1;
  return 0;
}

/* Mark this section for inclusion in some segment.  */
static void
register_section(asection *s, segment_info *inf)
{
  if (inf->low_mark > s->vma)
    inf->low_mark = s->vma;
  if (inf->high_mark < (s->vma + s->_cooked_size))
    inf->high_mark = s->vma + s->_cooked_size;
  inf->subsect[inf->nsubsects++] = s;
}

/* Print out the sections that make up this segment for debugging.  */
static void
dump_sections(segment_info *inf)
{
  int i;
  printf("      [ ");
  for (i = 0; i < inf->nsubsects; i++)
    printf("%s ", inf->subsect[i]->name);
  printf("]\n");
}

/* Pull the sections that make up this segment in off disk.  */
static void
load_sections(bfd *bfd, segment_info *inf)
{
  int i;
  void *ptr;
  if (! inf->size)
    return;		/* Nothing to do */
  inf->contents = malloc(inf->size);
  if (! inf->contents)
    {
      fprintf(stderr, "Out of memory.\n");
      exit(1);
    }
  ptr = inf->contents;
  for (i = 0; i < inf->nsubsects; i++)
    {
      if (! bfd_get_section_contents (bfd, inf->subsect[i], ptr,
				0, inf->subsect[i]->_cooked_size))
	{
	  fprintf(stderr, "Failed to read section contents.\n");
	  exit(1);
	}
      ptr += inf->subsect[i]->_cooked_size;
    }
}


asection* remove_section(bfd* bf, const char* name, asection** prevsection)
{
	asection* prev = NULL, *sec;

	sec = bf->sections;

	while(sec)
	{
		if (!strcmp(sec->name, name))
		{
			bf->section_count--;
			
			if (prev)
			{
				prev->next = sec->next;
				if (prevsection)
					*prevsection = prev;
				return sec;
			}
			if (prevsection)
				*prevsection = NULL;
			bf->sections = sec->next;
			return;
		}

		prev = sec;
		sec = sec->next;
	}
}

	
remove_stab_relocs(bfd* bf)
{
	remove_section(bf, ".rel.stab", NULL);
}

	
int 
main(int argc, char *argv[])
{
  int fd;
  bfd *bf;
  asection *s;
  char *ofile=0;
  char *fname = argv[argc - 1];
  int opt;
  int i;
  int stack;
  segment_info text, data, bss;

  asymbol **symbol_table;
  long number_of_symbols;

  unsigned long reloc_len;
  unsigned long *reloc;
  
  struct flat_hdr hdr;


  program = argv[0];
  progname = argv[0];

  if (argc < 2 || argc > 8 )
  	usage();
  
  stack = 4000;

  while ((opt = getopt(argc, argv, "vs:o:")) != -1) {
    switch (opt) {

	case 'd':
		dsyms++;
		break;
    case 'v':
      verbose++;
      break;
    case 'o':
      ofile = optarg;
      break;
    case 's':
      stack = atoi(optarg);
      break;
    default:
      fprintf(stderr, "%s Unknown option\n", argv[0]);
      usage();
      break;
    }
  }
  
  filename = argv[argc-1];

  if (!(bf = bfd_openr(argv[argc -1],0))) {
    fprintf (stderr,"Can't open %s\n",argv[argc -1]);
    exit(1);
  }
  
  if (bfd_check_format (bf, bfd_object) == 0) {
    printf("File is not an object file\n");
    exit(2);
  }
  
  symbol_table = get_symbols(bf, &number_of_symbols);
  
  /* Walk the list of sections, figuring out where each one goes and
     how much storage it requires.  */
  text.low_mark = data.low_mark = bss.low_mark = -1;
  text.high_mark = data.high_mark = bss.high_mark = 0;
  text.contents = data.contents = bss.contents = NULL;
  text.size = data.size = bss.size = 0;
  text.nsubsects = data.nsubsects = bss.nsubsects = 0;
  text.name = "text"; data.name = "data"; bss.name = "bss";

  for (s = bf->sections; s != NULL; s = s->next)
    {
	  dump_elf_section(s);
	  
      if (is_unwanted_section (s))
	continue;
      if (is_reloc_section (s))
	continue;		/* We aren't interested in the relocs yet. */
      if (s->flags == SEC_ALLOC)
	{
	  if (verbose)
	    printf ("section %s is ALLOC only\n", s->name);
	  register_section (s, &bss);
	  continue;
	}
      if ((s->flags & SEC_READONLY) && (s->flags & SEC_ALLOC))
	{
	  if (verbose)
	    printf ("section %s is CODE\n", s->name);
	  register_section (s, &text);
	  continue;
	}
      if (s->flags & SEC_DATA)
	{
	  if (verbose)
	    printf ("section %s is DATA\n", s->name);
	  register_section (s, &data);
	  continue;
	}
      if (verbose)
	printf ("WARNING: ignoring section %s\n", s->name);
    }
  
  if (text.low_mark == -1)
    text.low_mark = 0;
  if (data.low_mark == -1)
    data.low_mark = 0;
  if (bss.low_mark == -1)
    bss.low_mark = 0;

  text.size = text.high_mark - text.low_mark;
  data.size = data.high_mark - data.low_mark;
  bss.size = bss.high_mark - bss.low_mark;
  
  if (verbose)
    {
      printf ("text: %08x->%08x (%x)\n", text.low_mark, text.high_mark, text.size);
      dump_sections (&text);
      printf ("data: %08x->%08x (%x)\n", data.low_mark, data.high_mark, data.size);
      dump_sections (&data);
      printf ("bss:  %08x->%08x (%x)\n", bss.low_mark, bss.high_mark, bss.size);
      dump_sections (&bss);
    }

  /* Slurp the section contents in.  No need to load BSS since we know
     it isn't initialised. */
  load_sections (bf, &text);
  load_sections (bf, &data);

  remove_stab_relocs(bf);
  

  reloc = (unsigned long *) output_relocs (bf, symbol_table, number_of_symbols,
	&reloc_len, &text, &data, &bss);

  /* Fill in the binflt_flat header */
  memcpy(hdr.magic,"bFLT",4);
  hdr.rev         = htonl(2);
  hdr.entry       = htonl(16 * 4);     /* FIXME */
  hdr.data_start  = htonl(16 * 4 + text.size);
  hdr.data_end    = htonl(16 * 4 + text.size + data.size);
  hdr.bss_end     = htonl(16 * 4 + text.size + data.size + bss.size);
  hdr.stack_size  = htonl(stack); /* FIXME */
  hdr.reloc_start = htonl(16 * 4 + text.size + data.size);
  hdr.reloc_count = htonl(reloc_len);
  hdr.flags       = htonl(FLAT_FLAG_RAM);
  bzero(hdr.filler, sizeof(hdr.filler));

  for (i=0; i<reloc_len; i++) reloc[i] = htonl(reloc[i]);

  if (verbose && reloc)
      printf("reloc size=0x%04x\n", reloc_len);
  
  if (!ofile) {
    ofile = malloc(strlen(fname) + 5); /* 5 to add suffix */
    strcpy(ofile, fname);
    strcat(ofile, ".bflt");
  }

  if ((fd = open (ofile, O_WRONLY | O_PLATFORM | O_CREAT | O_TRUNC, 0744)) < 0) {
    fprintf (stderr, "Can't open output file %s\n", ofile);
    exit(4);
  }

  write(fd, &hdr, sizeof(hdr));
  write(fd, text.contents, text.size);
  write(fd, data.contents, data.size);

  if (reloc)
    write(fd, reloc, reloc_len*4);

  close(fd);

  exit(0);
}
