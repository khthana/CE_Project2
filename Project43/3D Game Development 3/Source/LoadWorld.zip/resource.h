//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LoadWorld.rc
//
#define IDM_MENU                        101
#define IDM_EXIT                        111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
