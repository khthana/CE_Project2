#include "resource.h"
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include "mrft_api.h"
#include <objbase.h>
#include "dinput.h"


LRESULT CALLBACK WindowFunc (HWND, UINT, WPARAM, LPARAM);

char szWinName[] = "KMITL Tournament";


HRESULT MouseInit( HWND hwnd );
HRESULT ReadMouse( HWND hwnd );
HRESULT ReadMouseBuffer( HWND hwnd );
HRESULT KeyboardInit( HWND hwnd );
HRESULT ReadKeyboard( HWND hwnd );

VOID    FreeMouse();
VOID	FreeKeyboard();


void write_text_and_draw(HDC dc_handle); // write DC on screen
int	init_player(void);//init player
int init_enemy(void);//init enemy
void set_enemy(void);//set location of enemy
void enemy_fire(void);//when in range, it fires !!
void set_vector(double vector[3], double x, double y, double z);
void get_intersection_with_terrain(double location[3], double intersection[3]); 


#define INITGUID
#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }
#define SAMPLE_BUFFER_SIZE 16  // arbitrary number of buffer elements

LPDIRECTINPUT8       g_pDI    = NULL;
LPDIRECTINPUTDEVICE8 g_pMouse = NULL;
LPDIRECTINPUTDEVICE8 g_pKeyboard = NULL;

int gl_PlayerSpeed = 20; //speed of player
DWORD gl_player, gl_camera;
DWORD gl_walk, gl_stand, gl_fire, gl_reload;
DWORD gl_anim3D;
double gl_player_height;
double gl_offset[3] = {-450, 25, 60};
BOOL g_bEndLoop = FALSE;
BOOL g_bEndFrame = FALSE; //check for sequence that must finish before do anything
int gl_playerHP = 100; // Player HP

//init de weapon 1 for init and pass value to normal var only
DWORD gl_player1;
DWORD gl_walk1, gl_stand1, gl_fire1, gl_reload1;
DWORD gl_anim3D1;
double gl_player_height1;

//init ump45 weapon 2 for init and pass value to normal var only
DWORD gl_player2;
DWORD gl_walk2, gl_stand2, gl_fire2, gl_reload2;
DWORD gl_anim3D2;
double gl_player_height2;

//init enemy
int gl_EnemySpeed = 20;
DWORD gl_me;
DWORD gl_enemy;
DWORD gl_ewalk, gl_estand, gl_efire, gl_ereload, gl_epain, gl_edeath, gl_edeath2;
DWORD gl_eanim3D;
int gl_number_of_edeath_frame;
double gl_enemy_height;
int gl_eHP = 100; // enemy HP



// <<<<<<< Init SOUND >>>>>>>>>>
//Init background sound
DWORD menu_sound = Morfit_sound_load("sound//menu.mp3", NULL,SOUND_DISTANCE_DEFAULT);
DWORD playing_sound = Morfit_sound_load("sound//playing.mp3", NULL,SOUND_DISTANCE_DEFAULT);

//Init player sound
DWORD ps_pain = Morfit_sound_load("sound//ps_pain.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD ps_death = Morfit_sound_load("sound//ps_death.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD ps_win = Morfit_sound_load("sound//ps_win.wav", gl_player,SOUND_DISTANCE_DEFAULT);

//Init de sound
DWORD de_fire = Morfit_sound_load("sound//deagle-2.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD de_reload1 = Morfit_sound_load("sound//de_clipout.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD de_reload2 = Morfit_sound_load("sound//de_clipin.wav", gl_player,SOUND_DISTANCE_DEFAULT);

DWORD ric1 = Morfit_sound_load("sound//ric1.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD ric2 = Morfit_sound_load("sound//ric2.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD ric3 = Morfit_sound_load("sound//ric3.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD no_ammo = Morfit_sound_load("sound//no_ammo.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD pl_step = Morfit_sound_load("sound//pl_step.wav", gl_player,SOUND_DISTANCE_DEFAULT);

//Init ump45 sound
DWORD um_fire = Morfit_sound_load("sound//Ump45-1.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD um_reload1 = Morfit_sound_load("sound//UMP45_CLIPOUT.wav", gl_player,SOUND_DISTANCE_DEFAULT);
DWORD um_reload2 = Morfit_sound_load("sound//UMP45_CLIPIN.wav", gl_player,SOUND_DISTANCE_DEFAULT);

//init enemy weapon
DWORD awp_fire = Morfit_sound_load("sound//awp1.wav", gl_enemy,SOUND_DISTANCE_DEFAULT);
DWORD awp_clipout = Morfit_sound_load("sound//awp_clipout.wav", gl_enemy,SOUND_DISTANCE_DEFAULT);
DWORD awp_clipin = Morfit_sound_load("sound//awp_clipin.wav", gl_enemy,SOUND_DISTANCE_DEFAULT);



//bullet mask
DWORD bullet;
int gun1_ammo = 7;
int gun2_ammo = 15;

//var for check who shoot
DWORD gl_who = gl_player;
int gl_gun = 1;
int gl_range = 0;
void CheckHit(DWORD gl_who, int gl_range);
int gl_rangeP = 0;//range of current player's weapon
int i = 0;//number of bullet
void Fire(void);

//init effect
void MoveEffect(void);
DWORD de_flame,de_dummief,de_flame2,de_blood,de_blacklight,de_lighting;

DWORD gun_light,enemy_light,light1;

double front_player[3] = {-100,20,40};//offset
double front_player2[3] = {-100,0,20};//ump45

//init another world
DWORD gl_kmitl;

//init route
double x[5] = {2020, 2020, -1080, -1080, -1500};
double y[5] = {-400,  -20,   -20,   700,   700};
double z[5] = { 120,  120,   120,   120,   120};
int gl_i = 0,gl_j = 0,gl_k = 0;



HBITMAP rdc,hp,enemytext;
HBITMAP num[10];
HBITMAP openbm,level_select,pointer;

void menu_open(void);


void move_enemy(void);



   int WINAPI WinMain (HINSTANCE hThisInst,
   					   HINSTANCE hPrevInst,
                       LPSTR lpszArgs,
                       int nWinMode)
   {
   	  HWND hwnd;
      MSG msg;
      WNDCLASS wcl;
      HACCEL hAccel;

      wcl.hInstance = hThisInst;
      wcl.lpszClassName = szWinName;
      wcl.lpfnWndProc = WindowFunc;
      wcl.style = 0;
      wcl.hIcon = LoadIcon(NULL,IDI_APPLICATION);
      wcl.hCursor = LoadCursor(NULL,IDC_ARROW);
	  wcl.lpszMenuName = NULL;
      wcl.cbClsExtra = 0;
      wcl.cbWndExtra = 0;
      wcl.hbrBackground = (HBRUSH)GetStockObject (WHITE_BRUSH);

      if( !RegisterClass(&wcl) )
      	return 0;


	  if(OK != Morfit_engine_load_world("total.wld",
							 "",
							 "bitmaps",
							 USER_DEFINED_BEHAVIOR|MIPMAP_RESOLUTION))
				return -1;

	  if(init_player()==VR_ERROR)
		{
		  return -1;
		}

      if(init_enemy()==VR_ERROR)
		{
		  return -1;
		}
 
//				<<<<<<< Load Bitmap >>>>>>>
	    rdc = Morfit_utilities_load_bitmap_from_file("rdc\\status2.bmp");
		hp  = Morfit_utilities_load_bitmap_from_file("rdc\\hp.bmp");
		enemytext = Morfit_utilities_load_bitmap_from_file("rdc\\enemy.bmp");
		num[10] = Morfit_utilities_load_bitmap_from_file("rdc\\0.jpg");
		num[1] = Morfit_utilities_load_bitmap_from_file("rdc\\1.jpg");
		num[2] = Morfit_utilities_load_bitmap_from_file("rdc\\2.jpg");
		num[3] = Morfit_utilities_load_bitmap_from_file("rdc\\3.jpg");
		num[4] = Morfit_utilities_load_bitmap_from_file("rdc\\4.jpg");
		num[5] = Morfit_utilities_load_bitmap_from_file("rdc\\5.jpg");
		num[6] = Morfit_utilities_load_bitmap_from_file("rdc\\6.jpg");
		num[7] = Morfit_utilities_load_bitmap_from_file("rdc\\7.jpg");
		num[8] = Morfit_utilities_load_bitmap_from_file("rdc\\8.jpg");
		num[9] = Morfit_utilities_load_bitmap_from_file("rdc\\9.jpg");
		openbm = Morfit_utilities_load_bitmap_from_file("rdc\\open.bmp");
		level_select = Morfit_utilities_load_bitmap_from_file("rdc\\menu.jpg");
		pointer = Morfit_utilities_load_bitmap_from_file("rdc\\pointer.bmp");




		//get bullet handle
		DWORD temp_handle = Morfit_bitmap_load("model//bullet.bmp",-1);
		int w_index = Morfit_bitmap_rgb_color_to_index(temp_handle, 255, 255, 255);
		bullet = Morfit_bitmap_load("model//bullet.bmp",w_index);
		Morfit_bitmap_unload(temp_handle);

		//get effect handle
		de_flame = Morfit_object_get_object_using_name("effect");
		de_flame2 = Morfit_object_get_object_using_name("effect2");
		de_blood  = Morfit_object_get_object_using_name("blood");

		int red,green,blue;

		
//			<<<<<<<  Set Rendering Parameter >>>>>>>>
		Morfit_engine_get_background_color(&red, &green, &blue);
		Morfit_engine_set_atmospheric_effect(red, green, blue);
		Morfit_engine_set_picture_quality(200000);
		Morfit_engine_set_culling_depth(16);
		Morfit_engine_set_far_objects_color_accuracy(1);
		Morfit_engine_set_atmospheric_effect_intensity(0.1);
		Morfit_engine_set_maximum_rendering_time(1000000);
		Morfit_engine_set_perspective_correction_accuracy(0.1);
		Morfit_camera_set_zoom(gl_camera, 90);
		Morfit_camera_set_distance_from_eye(gl_camera, 6);
		Morfit_3D_card_use_detailed(CARD3D_NORMAL,NO,1024,768,16,NO);
		Morfit_engine_hide_log_window();
		Morfit_engine_maximize_default_rendering_window();
		hwnd = Morfit_engine_get_default_rendering_window_hwnd();




	    hAccel = LoadAccelerators(hThisInst,MAKEINTRESOURCE(IDM_MENU));
		InvalidateRect(hwnd,NULL,false);

		// create light effect 
		double position[3] = {-48,37,200};
		double direction[3] = {0,0,-1};
		light1 = Morfit_light_create("light1",position);
		Morfit_light_set_direction(light1,direction);
		Morfit_light_set_type_of_light(light1, LIGHT_DEFAULT);
		Morfit_light_set_entity_to_light(light1, NULL);
		gun_light = Morfit_light_create("gun_light",position);
		Morfit_light_set_type_of_light(gun_light, LIGHT_DEFAULT); 
		enemy_light = Morfit_light_create("enemy_light",position);
		Morfit_light_set_type_of_light(enemy_light, LIGHT_DEFAULT);       


		//disable all effect
		Morfit_object_disable(de_flame);
		Morfit_object_disable(de_flame2);
		Morfit_object_disable(de_blood);


		MouseInit(hwnd);  // init mouse
		KeyboardInit(hwnd); // init keyboard


		menu_open(); //  Main Menu

		Morfit_sound_play(playing_sound,SOUND_LOOP_NORMAL); // play background sound
		Morfit_engine_set_speaker_mode(NO); // turn off pc speaker


		double x,y,z;
		double dx,dy,dz;
		double p[3];//player location
		double e[3];//enemy location

		Morfit_light_activate(light1,LIGHT_SET);
		
		while (!g_bEndLoop)
		{
			Morfit_engine_clear_morfit_log_files(); 
			HDC  dc_handle = Morfit_engine_render_on_dc(NULL,NULL);

			 if (gl_playerHP > 0) {ReadMouse(hwnd);}
			 Fire();  
			 
			 //disable playerflame when not fire
			 if ((Morfit_object_get_3D_sequence(gl_player) != gl_fire)&&(Morfit_object_is_enabled(de_flame)))
			 {
				 Morfit_object_disable(de_flame);
				 if(Morfit_background_get_current_background() == Morfit_background_get_handle("Night" ))
					Morfit_light_activate(light1,LIGHT_SET);
			 }	
			 //disable enemy flame when not fire
			 if ((Morfit_object_get_3D_sequence(gl_enemy) != gl_efire)&&(Morfit_object_is_enabled(de_flame2)))
			 {
				 Morfit_object_disable(de_flame2);
				 if(Morfit_background_get_current_background() == Morfit_background_get_handle("Night" ))
					Morfit_light_activate(light1,LIGHT_SET);
			 }
			 //disable blood effect when not use
			 if ((Morfit_sound_is_sound_playing(ps_pain) == NO)&&(Morfit_object_is_enabled(de_blood)) && (gl_playerHP > 0))
			 {
				 Morfit_object_disable(de_blood);
			 }


			 
			 ReadKeyboard(hwnd);
			 	 
			 
			 //check if player in range to fire
			 Morfit_object_get_location(gl_player, &p[0], &p[1], &p[2]);
			 Morfit_object_get_location(gl_enemy, &e[0], &e[1], &e[2]);
			 if (Morfit_object_get_3D_sequence(gl_enemy) != (gl_edeath))
				Morfit_object_set_direction(gl_enemy, p[0] - e[0], p[1] - e[1], 0);
			 if ((Morfit_math_get_distance(e, p) < 1000)&&(gl_eHP > 0))
			 {
				 Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_estand, 0);

			 	 enemy_fire(); // if in range enemy fire
			 }
			 else
				 if ((Morfit_object_get_3D_sequence(gl_enemy) != (gl_epain|gl_edeath|gl_edeath2|gl_efire))&&(gl_eHP > 0))
				 move_enemy(); // if not in range enemy move


			 Morfit_camera_get_location(gl_camera,&x,&y,&z);
			 Morfit_camera_get_direction(gl_camera,&dx,&dy,&dz);

			 Morfit_object_set_direction(gl_player,dx,dy,dz);
			 //set dz so me don't fly or dive in terrain
			 dz = 0;
			 Morfit_object_set_direction(gl_me,dx,dy,dz);

			 Morfit_object_set_location(gl_player,x,y,z);
			 Morfit_object_set_location(gl_me,x,y+30,z);


			 if (gl_player == gl_player1)
			 {
				 Morfit_object_move(gl_player,OBJECT_SPACE,-75,-20,-60);
			 }

			 if (gl_player == gl_player2)
			 {
				 Morfit_object_move(gl_player,OBJECT_SPACE,-50,0,-40);
			 }
			 
			 write_text_and_draw(dc_handle); // write DC
			 MoveEffect(); // move all effect

			 Morfit_engine_copy_image_from_dc_to_screen(); // render 

			}

		
//		<<<<  QUIT >>>>
			FreeMouse();    
			FreeKeyboard();
			Morfit_engine_close();
			PostQuitMessage (0);


      while ( GetMessage (&msg, NULL, 0, 0) )

      {
         	if(!TranslateAccelerator(hwnd,hAccel,&msg))
	      	{
   	      		TranslateMessage (&msg);
	   			DispatchMessage (&msg);
         	}
      }

      return msg.wParam;

   }


   LRESULT CALLBACK WindowFunc (HWND hwnd, UINT message,
   									  WPARAM wParam, LPARAM lParam)

   {

   	switch ( message )
      {
         
       	case WM_DESTROY:
			Morfit_engine_close();
         	PostQuitMessage (0);
         break;
         default:
         	return DefWindowProc (hwnd, message, wParam, lParam);
      }
      return 0;

   }


//-----------------------------------------------------------------------------
// Name: MouseInit()
// Desc: Setups a the mouse device using the flags from the dialog.
//-----------------------------------------------------------------------------
HRESULT MouseInit( HWND hwnd )
{
    HRESULT hr;
    DWORD   dwCoopFlags;

    // Cleanup any previous call first
    KillTimer( hwnd, 0 );
    FreeMouse();

    // Detrimine where the buffer would like to be allocated

        dwCoopFlags = DISCL_EXCLUSIVE | DISCL_FOREGROUND;

    // Create a DInput object
    if( FAILED( hr = DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION,
                                         IID_IDirectInput8, (VOID**)&g_pDI, NULL ) ) )
        return hr;

    // Obtain an interface to the system mouse device.
    if( FAILED( hr = g_pDI->CreateDevice( GUID_SysMouse, &g_pMouse, NULL ) ) )
        return hr;

    // Set the data format to "mouse format" - a predefined data format
    //
    // A data format specifies which controls on a device we
    // are interested in, and how they should be reported.
    //
    // This tells DirectInput that we will be passing a
    // DIMOUSESTATE2 structure to IDirectInputDevice::GetDeviceState.
    if( FAILED( hr = g_pMouse->SetDataFormat( &c_dfDIMouse2 ) ) )
        return hr;

    // Set the cooperativity level to let DirectInput know how
    // this device should interact with the system and with other
    // DirectInput applications.
    hr = g_pMouse->SetCooperativeLevel( hwnd, dwCoopFlags );

    if( FAILED(hr) )
        return hr;

    // IMPORTANT STEP TO USE BUFFERED DEVICE DATA!
    //
    // DirectInput uses unbuffered I/O (buffer size = 0) by default.
    // If you want to read buffered data, you need to set a nonzero
    // buffer size.
    //
    // Set the buffer size to SAMPLE_BUFFER_SIZE (defined above) elements.
    //
    // The buffer size is a DWORD property associated with the device.
        DIPROPDWORD dipdw;
        dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
        dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
        dipdw.diph.dwObj        = 0;
        dipdw.diph.dwHow        = DIPH_DEVICE;
        dipdw.dwData            = SAMPLE_BUFFER_SIZE; // Arbitary buffer size

        if( FAILED( hr = g_pMouse->SetProperty( DIPROP_BUFFERSIZE, &dipdw.diph ) ) )
            return hr;


    // Acquire the newly created device
    g_pMouse->Acquire();

    // Set a timer to go off 12 times a second, to read input
    // Note: Typically an application would poll the mouse
    //       much faster than this, but this slow rate is simply
    //       for the purposes of demonstration
    SetTimer( hwnd, 0, 1000 / 1000, NULL );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ReadMouse()
// Desc: Read the input device's state when in immediate mode and display it.
//-----------------------------------------------------------------------------
HRESULT ReadMouse( HWND hwnd )
{
    HRESULT       hr;
    //TCHAR         strNewText[256] = TEXT("");
    DIMOUSESTATE2 dims2;      // DirectInput mouse state structure

    if( NULL == g_pMouse )
        return S_OK;

    // Get the input's device state, and put the state in dims
    ZeroMemory( &dims2, sizeof(dims2) );
    hr = g_pMouse->GetDeviceState( sizeof(DIMOUSESTATE2), &dims2 );
    if( FAILED(hr) )
    {
        // DirectInput may be telling us that the input stream has been
        // interrupted.  We aren't tracking any state between polls, so
        // we don't have any special reset that needs to be done.
        // We just re-acquire and try again.

        // If input is lost then acquire and keep trying
        hr = g_pMouse->Acquire();
        while( hr == DIERR_INPUTLOST )
            hr = g_pMouse->Acquire();


        // hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
        // may occur when the app is minimized or in the process of
        // switching, so just try again later
        return S_OK;
    }

		if ((dims2.lY > 3) | (dims2.lY < -3))
		{
			Morfit_camera_modify_tilt(gl_camera,-0.1*dims2.lY);  // rotate camera up-down
		}
		if ((dims2.lX > 3) | (dims2.lX < -3))
		{
			Morfit_camera_modify_head_angle(gl_camera,-0.1*dims2.lX); // rotate camera left-right
		}

		//fire
		if (dims2.rgbButtons[0])
		{
			if (((gl_gun == 1) && (gun1_ammo <= 0))||((gl_gun == 2)&&(gun2_ammo <= 0)))
				Morfit_sound_play(no_ammo, SOUND_NO_LOOP);
			else
			{
			if (gl_player == gl_player1)
			{
				if (Morfit_object_get_3D_sequence(gl_player) == gl_stand)
					{
						if (i < 7) i++;
					}
			}

			if (gl_player == gl_player2)
			{
					{
						Morfit_sound_play(um_fire, SOUND_NO_LOOP);
						gl_who = gl_player;
						gl_rangeP = 10000;//range of de gun, use case for other weapon
						gl_range = gl_rangeP;
						CheckHit(gl_who, gl_range);
						Morfit_object_set_3D_sequence(gl_player, gl_fire, 0);
						Morfit_object_replace_3D_sequence_when_finished(gl_player, gl_stand, 0);
				
					}
			}
				
			}
		}


	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: FreeMouse()
// Desc: Initialize the DirectInput variables.
//-----------------------------------------------------------------------------
VOID FreeMouse()
{
    // Unacquire the device one last time just in case
    // the app tried to exit while the device is still acquired.
    if( g_pMouse )
        g_pMouse->Unacquire();

    // Release any DirectInput objects.
    SAFE_RELEASE( g_pMouse );
    SAFE_RELEASE( g_pDI );
}

//-----------------------------------------------------------------------------
// Name: KeyboardInit()
// Desc: Setups a the keyboard device using the flags from the dialog.
//-----------------------------------------------------------------------------
HRESULT KeyboardInit( HWND hwnd )
{
    HRESULT hr;
    DWORD   dwCoopFlags;

    // Cleanup any previous call first
    KillTimer( hwnd, 0 );
    FreeKeyboard();


    dwCoopFlags = DISCL_EXCLUSIVE | DISCL_FOREGROUND;

    // Create a DInput object
    if( FAILED( hr = DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION,
                                         IID_IDirectInput8, (VOID**)&g_pDI, NULL ) ) )
        return hr;

    // Obtain an interface to the system keyboard device.
    if( FAILED( hr = g_pDI->CreateDevice( GUID_SysKeyboard, &g_pKeyboard, NULL ) ) )
        return hr;

    // Set the data format to "keyboard format" - a predefined data format
    //
    // A data format specifies which controls on a device we
    // are interested in, and how they should be reported.
    //
    // This tells DirectInput that we will be passing an array
    // of 256 bytes to IDirectInputDevice::GetDeviceState.
    if( FAILED( hr = g_pKeyboard->SetDataFormat( &c_dfDIKeyboard ) ) )
        return hr;

    // Set the cooperativity level to let DirectInput know how
    // this device should interact with the system and with other
    // DirectInput applications.
    hr = g_pKeyboard->SetCooperativeLevel( hwnd, dwCoopFlags );

    if( FAILED(hr) )
        return hr;

    /*if( !bImmediate )
    {
        // IMPORTANT STEP TO USE BUFFERED DEVICE DATA!
        //
        // DirectInput uses unbuffered I/O (buffer size = 0) by default.
        // If you want to read buffered data, you need to set a nonzero
        // buffer size.
        //
        // Set the buffer size to DINPUT_BUFFERSIZE (defined above) elements.
        //
        // The buffer size is a DWORD property associated with the device.
        DIPROPDWORD dipdw;

        dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
        dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
        dipdw.diph.dwObj        = 0;
        dipdw.diph.dwHow        = DIPH_DEVICE;
        dipdw.dwData            = SAMPLE_BUFFER_SIZE; // Arbitary buffer size

        if( FAILED( hr = g_pKeyboard->SetProperty( DIPROP_BUFFERSIZE, &dipdw.diph ) ) )
            return hr;
    }*/

    // Acquire the newly created device
    g_pKeyboard->Acquire();

    // Set a timer to go off 12 times a second, to read input
    // Note: Typically an application would poll the keyboard
    //       much faster than this, but this slow rate is simply
    //       for the purposes of demonstration
    SetTimer( hwnd, 0, 1000 / 1000, NULL );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ReadKeyboard()
// Desc: Read the input device's state when in immediate mode and display it.
//-----------------------------------------------------------------------------
HRESULT ReadKeyboard( HWND hwnd )
{
    HRESULT hr;
    BYTE    diks[256];   // DirectInput keyboard state buffer


    double save_location[3];
	//Save the location in case we will want to go back ...
	Morfit_camera_get_location(gl_camera, &save_location[0], &save_location[1], &save_location[2]);


	if( NULL == g_pKeyboard )
        return S_OK;

    // Get the input's device state, and put the state in dims
    ZeroMemory( &diks, sizeof(diks) );
    hr = g_pKeyboard->GetDeviceState( sizeof(diks), &diks );
    if( FAILED(hr) )
    {
        // DirectInput may be telling us that the input stream has been
        // interrupted.  We aren't tracking any state between polls, so
        // we don't have any special reset that needs to be done.
        // We just re-acquire and try again.

        // If input is lost then acquire and keep trying
        hr = g_pKeyboard->Acquire();
        while( hr == DIERR_INPUTLOST )
            hr = g_pKeyboard->Acquire();

        return S_OK;
    }


	//not die yet
	if (gl_playerHP > 0)
	{
	
	//foreward
	if ((diks[DIK_UP] && 0x80) | (diks[DIK_W] && 0x80))
	{
		Morfit_camera_move(gl_camera,CAMERA_SPACE, -gl_PlayerSpeed, 0, 0);
		if (Morfit_sound_is_sound_playing (pl_step) == NO)
		Morfit_sound_play(pl_step, SOUND_NO_LOOP);
	}
    //backward
	if ((diks[DIK_DOWN] && 0x80) | (diks[DIK_S] && 0x80))
	{
		Morfit_camera_move(gl_camera,CAMERA_SPACE, gl_PlayerSpeed, 0, 0);
		if (Morfit_sound_is_sound_playing (pl_step) == NO)
		Morfit_sound_play(pl_step, SOUND_NO_LOOP);
	}
	//right
	if ((diks[DIK_RIGHT] && 0x80) | (diks[DIK_D] && 0x80))
	{
		Morfit_camera_move(gl_camera,CAMERA_SPACE, 0, gl_PlayerSpeed, 0);
		if (Morfit_sound_is_sound_playing (pl_step) == NO)
		Morfit_sound_play(pl_step, SOUND_NO_LOOP);
	}

	
	if ((diks[DIK_DELETE] && 0x80))
	{
		Morfit_engine_decrease_atmospheric_effect_intensity(); // decrease fog
	
	}

	if ((diks[DIK_INSERT] && 0x80))
	{
		Morfit_engine_increase_atmospheric_effect_intensity(); // increase fog
		if(Morfit_engine_get_atmospheric_effect_intensity() > 0.3)
			Morfit_background_use(NULL);
	}

	
	// switch Day & Night
	if ((diks[DIK_N] && 0x80))
	{
		DWORD day = Morfit_background_get_handle("Day");
		DWORD night = Morfit_background_get_handle("Night");
		if(Morfit_background_get_current_background() ==  day)
		{
			Morfit_background_use(night); // set background to night
			Morfit_light_set_distance_reach(light1,1000);
			Morfit_light_activate(light1,LIGHT_SET); // set light to night
		}
		else
		{
			Morfit_background_use(day); // set background to day
			Morfit_light_set_distance_reach(light1,30000);
			Morfit_light_activate(light1,LIGHT_ADD); // set light to day 
		}
	}

	//left
	if ((diks[DIK_LEFT] && 0x80) | (diks[DIK_A] && 0x80))
	{
		Morfit_camera_move(gl_camera,CAMERA_SPACE, 0, -gl_PlayerSpeed, 0);
		if (Morfit_sound_is_sound_playing (pl_step) == NO)
		Morfit_sound_play(pl_step, SOUND_NO_LOOP);
	}
	//reload
	if (diks[DIK_R])
	{
		Morfit_object_set_3D_sequence(gl_player, gl_reload, 0);
		Morfit_object_replace_3D_sequence_when_finished(gl_player, gl_stand, 0);
		//de
		if (gl_player == gl_player1)
		{
			gun1_ammo = 7;
			Morfit_sound_play(de_reload1, SOUND_NO_LOOP);
			Morfit_sound_play(de_reload2, SOUND_NO_LOOP);
		}
		//ump45
		if (gl_player == gl_player2)
		{
			gun2_ammo = 15;
			Morfit_sound_play(um_reload1, SOUND_NO_LOOP);
			Morfit_sound_play(um_reload2, SOUND_NO_LOOP);
		}
	}
	//change to de
	if ((diks[DIK_1])&&(gl_player == gl_player2))
	{
		double x, y, z;
		Morfit_object_get_location(gl_player, &x, &y, &z);
		Morfit_object_disable(gl_player2);
		Morfit_object_set_location(gl_player1, x, y, z);
		Morfit_object_enable(gl_player1);
		gl_player = gl_player1;
		gl_gun = 1;

	
		gl_anim3D = gl_anim3D1;
		gl_walk = gl_walk1;
		gl_stand = gl_stand1;
		gl_fire = gl_fire1;
		gl_reload = gl_reload1;
	}
	//change to ump45
	if ((diks[DIK_2])&&(gl_player == gl_player1))
	{
		double x, y, z;
		Morfit_object_get_location(gl_player, &x, &y, &z);
		Morfit_object_disable(gl_player1);
		Morfit_object_set_location(gl_player2, x, y, z);
		Morfit_object_enable(gl_player2);
		gl_player = gl_player2;
		gl_gun = 2;

	
		gl_anim3D = gl_anim3D2;
		gl_walk = gl_walk2;
		gl_stand = gl_stand2;
		gl_fire = gl_fire2;
		gl_reload = gl_reload2;
	}
	//new enemy set it's status
	if ((diks[DIK_M])&&(gl_eHP <= 0))
	{
		gl_eHP = 100;
		Morfit_object_set_3D_sequence(gl_enemy, gl_estand, 0);
		Morfit_object_enable(gl_enemy);
	}
	else //check if it in some "must finished before stand" sequence
		Morfit_object_replace_3D_sequence_when_finished(gl_player, gl_stand, 200);
	}

	if ((diks[DIK_P])&&(gl_playerHP <= 0))
	{
		gl_playerHP = 100;
		Morfit_object_enable(gl_player);
		Morfit_object_disable(de_blood);
	}




	//All that is left to do is to make sure that we are walking on the terrain
	//(and not below it or in the sky). Another thing that we check is whether
	//we went into an obstacle that is too high for us to jump on it.
	double location[3];
	Morfit_camera_get_location(gl_camera, &location[0], &location[1], &location[2]);
	double intersection[3];
	get_intersection_with_terrain(location, intersection);

	//The new height of the center of the object
	//should be the ground height (the intersection point)
	//plus the length of the body from it center to the bottom (gl_player_height/2)
	double new_altitude = intersection[2] + 130;

	//If the obstacle is bigger then one third of the player height then
	//we cant climb it !
	if(new_altitude > save_location[2] + 50)
	{
		Morfit_camera_set_location(gl_camera, save_location[0], save_location[1], save_location[2]);
	}
	else
	{
		Morfit_camera_set_location(gl_camera, location[0], location[1], new_altitude);
	}

	if (diks[DIK_ESCAPE])
	{
		Morfit_sound_stop(playing_sound);
		menu_open();
		Morfit_sound_play(playing_sound,SOUND_LOOP_NORMAL);
	}

	
	if ((diks[DIK_F] && 0x80))
	{
		Morfit_camera_set_location(gl_camera,12092,11684,10500);
		Morfit_object_set_location(gl_enemy,10216,9489,10100);
	}


    return S_OK;
}
//-----------------------------------------------------------------------------
// Name: FreeKeyboard()
// Desc: Initialize the DirectInput variables.
//-----------------------------------------------------------------------------
VOID FreeKeyboard()
{
    // Unacquire the device one last time just in case
    // the app tried to exit while the device is still acquired.
    if( g_pKeyboard )
        g_pKeyboard->Unacquire();

    // Release any DirectInput objects.
    SAFE_RELEASE( g_pKeyboard );
    SAFE_RELEASE( g_pDI );
}



//Returns OK or VR_ERROR
int init_player(void)
{
	//de
	gl_player1 = Morfit_object_create_from_file("model//tris.md2");
	if(gl_player1 == NULL)
		return(VR_ERROR);

	//ump45
	gl_player2 = Morfit_object_create_from_file("model//ump45.md2");
	if(gl_player2 == NULL)
		return(VR_ERROR);

	//Set the skin de
	DWORD skin1 = Morfit_bitmap_load("model//skin.bmp",-1);
	Morfit_object_set_bitmap(gl_player1, skin1);

	//Set the skin ump45
	DWORD skin2 = Morfit_bitmap_load("model//ump45.bmp",-1);
	Morfit_object_set_bitmap(gl_player2, skin2);

	//scale de
	double scale1[3] = {2.5,2.5,2.5};
	Morfit_object_set_scale(gl_player1, scale1);

	//scale ump45
	double scale2[3] = {1.3,1.3,1.3};
	Morfit_object_set_scale(gl_player2, scale2);

	//calculate the player height de
	double box1[2][3];
	Morfit_object_get_bounding_box(gl_player1, box1);
	//The differences between the max and the min Z values
	//gl_player_height = box[1][2] - box[0][2];
	gl_player_height1 = 180;

	//calculate the player height ump45
	double box2[2][3];
	Morfit_object_get_bounding_box(gl_player2, box2);
	//The differences between the max and the min Z values
	//gl_player_height = box[1][2] - box[0][2];
	gl_player_height2 = 180;

	//Just so that it starts in a better looking place.
	//The Z==10000 is just in case that the location of the object is under the terrain
	//Later the object will be dropped nicely on the terrain (If you didnt get it , it is not important at all ...)
	gl_player = gl_player1; //init as de
	Morfit_object_move(gl_player,OBJECT_SPACE, -1000,0,10000);
	//move ump45
	Morfit_object_move(gl_player2,OBJECT_SPACE, -1000,0,10000);

	gl_camera = Morfit_camera_get_default_camera();
	double x,y,z;
	Morfit_camera_get_direction(gl_camera, &x, &y, &z);
	Morfit_camera_set_direction(gl_camera, -x, y, z);
	Morfit_camera_set_location(gl_camera, -1600, 680, 800);


	//Since we call Morfit_camera_advance_all() on our own
	//we dont want the engine to call it every render
	Morfit_engine_advance_cameras_automatically(NO);


	//set gl_walk_sequence and gl_stand_sequence de
	gl_anim3D1 = Morfit_object_get_3D_animation(gl_player1);
	if(gl_anim3D1 == NULL)
		return(VR_ERROR);

	gl_walk1 = Morfit_3D_sequence_get_using_name(gl_anim3D1, "idle");
	gl_stand1 = Morfit_3D_sequence_get_using_name(gl_anim3D1, "idle");
	gl_fire1 = Morfit_3D_sequence_get_using_name(gl_anim3D1, "fire");
	gl_reload1 = Morfit_3D_sequence_get_using_name(gl_anim3D1, "reload");

	//set gl_walk_sequence and gl_stand_sequence ump45
	gl_anim3D2 = Morfit_object_get_3D_animation(gl_player2);
	if(gl_anim3D2 == NULL)
		return(VR_ERROR);

	gl_walk2 = Morfit_3D_sequence_get_using_name(gl_anim3D2, "idle");
	gl_stand2 = Morfit_3D_sequence_get_using_name(gl_anim3D2, "idle");
	gl_fire2	= Morfit_3D_sequence_get_using_name(gl_anim3D2, "fire");
	gl_reload2 = Morfit_3D_sequence_get_using_name(gl_anim3D2, "reload");


	//Important, set global var to default de weapon and disable other weapon
	//before go to main loop
	gl_anim3D = gl_anim3D1;
	gl_walk = gl_walk1;
	gl_stand = gl_stand1;
	gl_fire = gl_fire1;
	gl_reload = gl_reload1;


	return(OK);
}

//A utility function just to make the code look a bit cleaner.
void set_vector(double vector[3], double x, double y, double z)
{
	vector[0]=x;
	vector[1]=y;
	vector[2]=z;
}


//The function returns the intersection point with the terrain
//according to the given x,y coordinates
//Note that this function should be improved in order to
//walk under bridges etc (right now if we will walk under a bridge it
//will return the top of the bridge and not a point on the ground below the bridge)
//Here is what we do:
//We take a point high up above the given location (up_location)
//and a point down below . To find the point on the ground that
//our player should step on, we find the intersection point between the line
// [up_location - down_location] and the world's terrain.
void get_intersection_with_terrain(double location[3], double intersection[3])
{
	double up_location[3], down_location[3] ,climb_location[3] ,intersection1[3] ,intersection2[3];
	set_vector(up_location,    location[0], location[1], 1000000);
	set_vector(down_location,  location[0], location[1], -1000000);
	set_vector(climb_location, location[0], location[1], location[2] + 30 );
	DWORD terrain_poly, blocking_object;

	Morfit_object_make_non_collisional(gl_player);
	int flag1 = Morfit_object_is_movement_possible(gl_me, climb_location, down_location, &terrain_poly, intersection1, &blocking_object);
    int flag2 = Morfit_object_is_movement_possible(gl_me, climb_location, up_location, &terrain_poly, intersection2, &blocking_object);

	if((flag1 == NO) && (flag2 == YES))
	{
		intersection[2] = intersection1[2];

	}
	if ((flag1 == NO) && (flag2 == NO))
	{
		if (intersection2[2] > location[2] + 50)
			intersection[2] = intersection1[2];
		else
			intersection[2] = intersection2[2];
	}
	if ((flag1 == YES) && (flag2 == NO))
		intersection[2] = intersection2[2];
	if ((flag1 == YES) && (flag2 == YES))
		intersection[2] = 1000000;
}

void Fire(void)
{
	if ((i <= 7)&&(i > 0))
	{
	
		if (Morfit_object_get_3D_sequence(gl_player) == gl_stand)
			{
				Morfit_sound_play(de_fire, SOUND_NO_LOOP);
				gl_who = gl_player;
				gl_rangeP = 10000;//range of de gun, use case for other weapon
				gl_range = gl_rangeP;
				CheckHit(gl_who, gl_range);
				Morfit_object_set_3D_sequence(gl_player, gl_fire, 0);
				Morfit_object_replace_3D_sequence_when_finished(gl_player, gl_stand, 0);
				i--;
			
			}
	}
	return;
}

void CheckHit(DWORD gl_who, int gl_range)
{
					if (gl_gun == 1)
					gun1_ammo-- ;
					if (gl_gun == 2)
					gun2_ammo-- ;
	
	
	
	double box[2][3];
	Morfit_object_get_bounding_box(gl_who, box);
	double half_who = (box[1][0]-box[0][0])/2;
	double x,y,z;
	double dir_x, dir_y, dir_z;
	double front_who[3];
	double ahead_who[3];
	Morfit_camera_get_location(gl_camera, &x, &y, &z);
	Morfit_camera_get_direction(gl_camera, &dir_x, &dir_y, &dir_z);
	front_who[0] = x+half_who*dir_x;
	front_who[1] = y+half_who*dir_y;
	front_who[2] = z+half_who*dir_z;
	ahead_who[0] = front_who[0]+gl_range*dir_x;
	ahead_who[1] = front_who[1]+gl_range*dir_y;
	ahead_who[2] = front_who[2]+gl_range*dir_z;
	DWORD intersect_polygon;
	DWORD intersect_object;
	double intersect_point[3];
	double radius = 10;//radius of patch
	double direction[3] = {0, 0, 0};
	int rgb[3] = {0, 0, 0};//color of patch. in this case it's black

	//enable flame effect
  	Morfit_object_enable(de_flame);

	if(Morfit_background_get_current_background() == Morfit_background_get_handle("Night" ))
		Morfit_light_activate(gun_light,LIGHT_SET);

	if (!(Morfit_object_is_movement_possible(gl_who, front_who, ahead_who, &intersect_polygon,
		intersect_point, &intersect_object)))
	{
		//hit with static object
		if (intersect_object == NULL)
		{
			DWORD patch=Morfit_polygon_add_patch_easy(intersect_polygon, intersect_point, radius, direction, bullet, rgb);
			int ran = rand();
			div_t div_result;
			div_result = div(ran, 4);
			if (div_result.rem >  0)
				{
				if (div_result.rem == 1 )
				Morfit_sound_play(ric1, SOUND_NO_LOOP);
				if (div_result.rem == 2 )
				Morfit_sound_play(ric2, SOUND_NO_LOOP);
				if (div_result.rem == 3)
			  	Morfit_sound_play(ric3, SOUND_NO_LOOP);
				}

		}
		//hit with dynamic object fill here
		
		if (gl_eHP > 0 )
		{
		if ((intersect_object == gl_enemy)&&(gl_gun == 1))
		{
			{
				gl_eHP = gl_eHP - 10;
				//hit but not die
				if (gl_eHP > 0)
				{
						Morfit_object_set_3D_sequence(gl_enemy, gl_epain, 0);
						Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_estand, 0);
				}
				//hit and die
				if (gl_eHP <= 0)
				{
					Morfit_object_set_3D_sequence(gl_enemy, gl_edeath, 0);
					Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_edeath2, 0);
					Morfit_sound_play(ps_win, SOUND_NO_LOOP);
				}
			}
		}

		if ((intersect_object == gl_enemy)&&(gl_gun == 2))
		{
			{
				gl_eHP = gl_eHP - 5;
				//hit but not die
				if (gl_eHP > 0)
				{
						Morfit_object_set_3D_sequence(gl_enemy, gl_epain, 0);
						Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_estand, 0);
				}
				//hit and die
				if (gl_eHP <= 0)
				{
					Morfit_object_set_3D_sequence(gl_enemy, gl_edeath, 0);
					Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_edeath2, 0);
					Morfit_sound_play(ps_win, SOUND_NO_LOOP);
				}
			}
		}
		}
	}

}


void write_text_and_draw(HDC dc_handle)
{
	//Get the dimension of the device context
	DWORD camera=Morfit_camera_get_default_camera();
	int width=Morfit_camera_get_width(camera);
	int height=Morfit_camera_get_height(camera);

	//Get the center point
	int center_x=width/2;
	int center_y=height/2;

	//Draw a circle
	SelectObject(dc_handle, GetStockObject(HOLLOW_BRUSH));
	Ellipse(dc_handle, center_x-50, center_y-50, center_x+50, center_y+50);
	//Do the crosshair
	//The horizontal line
	MoveToEx(dc_handle, center_x-60, center_y, NULL);
	LineTo(dc_handle, center_x+60, center_y);
	//The vertical line
	MoveToEx(dc_handle, center_x, center_y-60, NULL);
	LineTo(dc_handle, center_x, center_y+60);

	//draw a bitmap on top of the rendered image
	Morfit_utilities_copy_bitmap_on_dc(dc_handle, rdc, 0, 630, -1,-1);
	if (gl_eHP > 0)
	Morfit_utilities_copy_bitmap_on_dc(dc_handle, hp, 400, 50, (gl_eHP * 2),-1);

	if (gun1_ammo > 0)
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[gun1_ammo], 120, 720, -1,-1);
	else 
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[10], 120, 720, -1,-1);

	if (gun2_ammo >= 10)
	{
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[1], 250, 720, -1,-1);
		if (gun2_ammo != 10)
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[gun2_ammo - 10], 270, 720, -1,-1);
		else
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[10], 270, 720, -1,-1);
	}
	else
		if (gun2_ammo > 0)
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[gun2_ammo], 270, 720, -1,-1);
		else
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[10], 270, 720, -1,-1);
		

	div_t  div_result;
	div_result = div(gl_playerHP,10);
	if (gl_playerHP == 100)
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[1], 440, 680, -1,-1);
	{
		if (div_result.quot == 0)
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[10], 470, 680, -1,-1);
		else
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[div_result.quot], 470, 680, -1,-1);
	
		if (div_result.rem == 0)
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[10], 500, 680, -1,-1);
		else
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, num[div_result.rem], 500, 680, -1,-1);
	}


	//get location to draw
	double x,y,z;
	Morfit_camera_get_location(gl_camera,&x,&y,&z);
	
	//write some text
    char str[1000], stx[10] , sty[10] , stz[10];
	strcpy(str,"");
	_gcvt(x, 10, stx);
	_gcvt(y, 10, sty);
	_gcvt(z, 10, stz);

    strcat(str, stx );
	strcat(str , " ");
	strcat(str, sty );
	strcat(str , " ");
	strcat(str, stz );
	SetTextColor( dc_handle, RGB(255,128,0) ); //orange color
    SetBkMode( dc_handle, TRANSPARENT );
	//TextOut(dc_handle, 0,200, str,strlen(str));
	TextOut(dc_handle, 300, 50, "Enemy",5);


}

int init_enemy(void)
{
	gl_enemy = Morfit_object_create_from_file("model//enemy.md2");

	gl_me    = Morfit_object_create_from_file("model//enemy.md2");

	if(gl_enemy == NULL)
		return(VR_ERROR);


	DWORD eskin = Morfit_bitmap_load("model//esblue.bmp",-1);
	DWORD me = Morfit_bitmap_load("model//me.bmp",0);
	//Set the skin
	Morfit_object_set_bitmap(gl_enemy, eskin);

	Morfit_object_set_bitmap(gl_me , me);

	double scale[3] = {5,5,5};
	Morfit_object_set_scale(gl_enemy, scale);

	Morfit_object_set_scale(gl_me, scale);

	//calculate the player height
	double box[2][3];
	Morfit_object_get_bounding_box(gl_enemy, box);
	//The differences between the max and the min Z values
	gl_enemy_height = box[1][2] - box[0][2];
	//gl_player_height = 200;

	//Just so that it starts in a better looking place.
	//The Z==10000 is just in case that the location of the object is under the terrain
	//Later the object will be dropped nicely on the terrain (If you didnt get it , it is not important at all ...)
	Morfit_object_set_direction(gl_enemy, 0,1,0);
	Morfit_object_set_location(gl_enemy,2263,800, -130);


	//set gl_walk_sequence and gl_stand_sequence
	gl_eanim3D = Morfit_object_get_3D_animation(gl_enemy);
	if(gl_eanim3D == NULL)
		return(VR_ERROR);

	gl_ewalk = Morfit_3D_sequence_get_using_name(gl_eanim3D, "wrun");
	gl_estand = Morfit_3D_sequence_get_using_name(gl_eanim3D, "wstnd");
	gl_efire	= Morfit_3D_sequence_get_using_name(gl_eanim3D, "wattak");
	gl_epain = Morfit_3D_sequence_get_using_name(gl_eanim3D, "wpain");
	gl_edeath = Morfit_3D_sequence_get_using_name(gl_eanim3D, "wdeath");



	if (gl_edeath != NULL)
	{
		gl_number_of_edeath_frame = Morfit_3D_sequence_get_number_of_frames(gl_edeath);
	}

	gl_edeath2 = Morfit_3D_sequence_get_using_name(gl_eanim3D, "dfin");//temp for check finished

	return(OK);
}

void set_enemy(void)
{
	//check intersection here
}

void enemy_fire(void)
{
			{
				//random fire
				int ran = rand();
				div_t div_result;

				div_result = div(ran ,21);
				double ranx = (div_result.rem -10) * 0.05; //enemy skill

				ran = rand();
				div_result = div(ran ,20);
				double rany = (div_result.rem -10) * 0.05; //enemy skill



				double box[2][3];
				Morfit_object_get_bounding_box(gl_enemy, box);
				double half_enemy = (box[1][0]-box[0][0])/2;
				double x,y,z;
				double dir_x, dir_y, dir_z;
				double front_enemy[3];
				double ahead_enemy[3];
				Morfit_object_get_location(gl_enemy, &x, &y, &z);
				Morfit_object_get_direction(gl_enemy, &dir_x, &dir_y, &dir_z);
				front_enemy[0] = x+half_enemy*dir_x;
				front_enemy[1] = y+half_enemy*dir_y;
				front_enemy[2] = z+half_enemy*dir_z;
				ahead_enemy[0] = front_enemy[0]+1000*(dir_x + ranx);
				ahead_enemy[1] = front_enemy[1]+1000*(dir_y + rany);
				ahead_enemy[2] = front_enemy[2]+1000*dir_z;
				DWORD intersect_polygon;
				DWORD intersect_object;
				double intersect_point[3];
				double radius = 10;//radius of patch
				double direction[3] = {0, 0, 0};
				int rgb[3] = {0, 0, 0};//color of patch. in this case it's black

				//enable flame effect
				//	Morfit_object_enable(de_flame2);

				if (!(Morfit_object_is_movement_possible(gl_enemy, front_enemy, ahead_enemy, &intersect_polygon,
					intersect_point, &intersect_object)))
					{
						//hit with static object
						if ((intersect_object == NULL)&&(Morfit_object_get_3D_sequence(gl_enemy) != gl_efire) )
							{
								DWORD patch=Morfit_polygon_add_patch_easy(intersect_polygon, intersect_point, radius, direction, bullet, rgb);
								int ran = rand();
								div_t div_result;
								div_result = div(ran, 4);
								Morfit_object_set_3D_sequence(gl_enemy, gl_efire, 0);
								//enable flame effect
								Morfit_object_enable(de_flame2);
								if(Morfit_background_get_current_background() == Morfit_background_get_handle("Night" ))
									Morfit_light_activate(enemy_light,LIGHT_SET);

								Morfit_sound_play(awp_fire, SOUND_NO_LOOP);
								Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_estand, 0);
								if (div_result.rem >  0)
								{
									if (div_result.rem == 1 )
										Morfit_sound_play(ric1, SOUND_NO_LOOP);
									if (div_result.rem == 2 )
										Morfit_sound_play(ric2, SOUND_NO_LOOP);
									if (div_result.rem == 3)
									  	Morfit_sound_play(ric3, SOUND_NO_LOOP);
								}

							}
						//hit with dynamic object fill here
						if (((intersect_object == gl_me)&&(gl_playerHP > 0))&&(Morfit_object_get_3D_sequence(gl_enemy) != gl_efire))
							{
								if ((gl_playerHP - 25) >= 0)
								{
									gl_playerHP = gl_playerHP - 25;
									Morfit_object_set_3D_sequence(gl_enemy, gl_efire, 0);
									//enable flame effect
									Morfit_object_enable(de_flame2);
									Morfit_sound_play(awp_fire, SOUND_NO_LOOP);
									Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_estand, 0);

									//hit but not die
									if (gl_playerHP > 0)
										{

											Morfit_object_enable(de_blood);
											Morfit_sound_play(ps_pain, SOUND_NO_LOOP);
										}
									//hit and die
									if (gl_playerHP <= 0)
										{
											Morfit_sound_play(ps_death, SOUND_NO_LOOP);
											Morfit_object_enable(de_blood);
											Morfit_object_disable(gl_player);

										}
								}
							}


					}

			}
}

void move_enemy(void)
{
	double ex,  ey,  ez;
	double edx, edy, edz;
	Morfit_object_get_location(gl_enemy, &ex, &ey, &ez);
	Morfit_object_get_direction(gl_enemy, &edx, &edy, &edz);
	if ((ex != x[gl_i+1])|(ey != y[gl_k+1]))
	{

		//let's move it
		if (Morfit_object_get_3D_sequence(gl_enemy) != (gl_epain|gl_edeath|gl_edeath2|gl_efire))
		{
			Morfit_object_replace_3D_sequence_when_finished(gl_enemy, gl_ewalk, 0);
			Morfit_object_move(gl_enemy, OBJECT_SPACE, -gl_EnemySpeed, 0, 0);

		//All that is left to do is to make sure that we are walking on the terrain
		//(and not below it or in the sky). Another thing that we check is whether
		//we went into an obstacle that is too high for us to jump on it.
			double location[3];
			Morfit_object_get_location(gl_enemy, &location[0], &location[1], &location[2]);
			double intersection[3];
			get_intersection_with_terrain(location, intersection);

		//The new height of the center of the object
		//should be the ground height (the intersection point)
		//plus the length of the body from it center to the bottom (gl_player_height/2)
			double new_altitude = intersection[2] + (gl_enemy_height/2 );

		//If the obstacle is bigger then one third of the player height then
		//we cant climb it !
			if(new_altitude > ez + 30)
			{
				Morfit_object_set_location(gl_enemy, ex, ey, ez);
			}
			else
			{
				Morfit_object_set_location(gl_enemy, location[0], location[1], new_altitude);
			}
		}
	}
	else if (gl_i < 5) { gl_i++;gl_k++;gl_k++;}

}

void MoveEffect(void)
{
	double x,y,z;
	double point[3];
	double direction[3];
	double dir_x,dir_y,dir_z;

	Morfit_camera_get_location(gl_camera,&x,&y,&z);
	Morfit_camera_get_direction(gl_camera, &dir_x, &dir_y, &dir_z);

	Morfit_object_set_location(de_blood, x, y, z);
	Morfit_object_set_direction(de_blood,  dir_x,  dir_y ,  dir_z);
	Morfit_object_move(de_blood,OBJECT_SPACE, -10 , 0 , 0);

	point[0] = x;
	point[1] = y;
	point[2] = z;
	direction[0] = dir_x;
	direction[1] = dir_y;
	direction[2] = dir_z;
	Morfit_light_set_location(gun_light, point);
	Morfit_light_set_direction(gun_light, direction);

	Morfit_object_set_location(de_flame, x, y, z);
	Morfit_object_set_direction(de_flame, dir_x, dir_y , dir_z);
	Morfit_object_move(de_flame,OBJECT_SPACE, -150 , 0, -20);


	Morfit_object_get_location(gl_enemy,&x,&y,&z);
	Morfit_object_get_direction(gl_enemy, &dir_x, &dir_y, &dir_z);

	Morfit_object_set_location(de_flame2, x, y-60, z+20);
	Morfit_object_set_direction(de_flame2, -dir_x, -dir_y , -dir_z);
	Morfit_object_move(de_flame2,OBJECT_SPACE, 70 , -30 , -20);


	point[0] = x;
	point[1] = y;
	point[2] = z;
	direction[0] = dir_x;
	direction[1] = dir_y;
	direction[2] = dir_z;
	Morfit_light_set_location(enemy_light, point);
	Morfit_light_set_direction(enemy_light, direction);
	


}



void menu_open(void)
{	
	int pstat = 1;
	int menu = 1;
	BOOL endloop = FALSE;

	Morfit_sound_play(menu_sound,SOUND_LOOP_NORMAL);
	
	while (!(endloop))
	{
	HDC  dc_handle = Morfit_engine_render_on_dc(NULL,NULL);

	if (menu == 1)
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, openbm, 0, 0, -1,-1);
	else
		Morfit_utilities_copy_bitmap_on_dc(dc_handle, level_select, 0, 0, -1,-1);
   
	
	
	HRESULT hr;
    //TCHAR   strNewText[256*5 + 1] = TEXT("");
    //TCHAR   strElement[10];
    BYTE    diks[256];   // DirectInput keyboard state buffer

//	if( NULL == g_pKeyboard )
//        return S_OK;

    // Get the input's device state, and put the state in dims
    ZeroMemory( &diks, sizeof(diks) );
    hr = g_pKeyboard->GetDeviceState( sizeof(diks), &diks );
    if( FAILED(hr) )
    {
        // DirectInput may be telling us that the input stream has been
        // interrupted.  We aren't tracking any state between polls, so
        // we don't have any special reset that needs to be done.
        // We just re-acquire and try again.

        // If input is lost then acquire and keep trying
        hr = g_pKeyboard->Acquire();
        while( hr == DIERR_INPUTLOST )
            hr = g_pKeyboard->Acquire();

        // Update the dialog text
        /*if( hr == DIERR_OTHERAPPHASPRIO || hr == DIERR_NOTACQUIRED )
            SetDlgItemText( hDlg, IDC_DATA, "Unacquired" );*/

        // hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
        // may occur when the app is minimized or in the process of
        // switching, so just try again later
//        return S_OK;
    }


	if (diks[DIK_LEFT] && 0x80)
	{
		pstat = 1;
	}
	if (diks[DIK_RIGHT] && 0x80)
	{
		pstat = 2;
	}
	if (diks[DIK_UP] && 0x80)
	{
		pstat = 1;
	}
	if (diks[DIK_DOWN] && 0x80)
	{
		pstat = 2;
	}
	if (diks[DIK_RETURN] && 0x80)
	{
		Morfit_sound_play(de_fire,SOUND_NO_LOOP);
		if(menu == 2)
		{
			if(pstat ==1)
			{
				gun1_ammo = 7;
				gun2_ammo = 15;
				double position[3] = {-48,37,200};
				Morfit_light_set_location(light1,position);
				Morfit_sound_stop(menu_sound);				
				Morfit_camera_set_location(gl_camera,-1600,680,800);
				Morfit_object_set_location(gl_enemy, 2263,800,-130);
				gl_playerHP = 100;
				gl_eHP = 100;
				endloop = TRUE;
				Morfit_light_activate(light1 , LIGHT_ADD);
			}
			else
			{
				gun1_ammo = 7;
				gun2_ammo = 15;
				Morfit_sound_stop(menu_sound);
				double position[3] = {9979,11336,10004};
				Morfit_light_set_location(light1,position);
				Morfit_camera_set_location(gl_camera,12092,11684,10100);
				Morfit_object_set_location(gl_enemy,10216,9489,10100);
				gl_playerHP = 100;
				gl_eHP = 100;
				endloop = TRUE;
				Morfit_light_activate(light1 , LIGHT_ADD);
			}
		}
		
		
		if (menu == 1)
		{
			if (pstat == 1)
			{
				menu = 2;
			}
			else
			{	
				Morfit_sound_stop(menu_sound);
				g_bEndLoop = TRUE;
				endloop = TRUE;
			}
		}

	

	}

	if (menu == 1)
	{
		if (pstat == 1)
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, pointer, 300, 190, -1,-1);
		else
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, pointer, 300, 270, -1,-1);
	}

	if (menu == 2)
	{
		if ((pstat == 1)&&(menu ==2))
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, pointer, 65, 260, -1,-1);
		else
			Morfit_utilities_copy_bitmap_on_dc(dc_handle, pointer, 465, 260, -1,-1);
	}
	
	Morfit_engine_copy_image_from_dc_to_screen();

	}
}