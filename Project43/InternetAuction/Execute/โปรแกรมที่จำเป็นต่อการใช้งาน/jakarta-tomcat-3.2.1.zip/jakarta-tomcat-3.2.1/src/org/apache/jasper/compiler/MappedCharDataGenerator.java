/*
 * $Header: /home/cvs/jakarta-tomcat/src/share/org/apache/jasper/compiler/MappedCharDataGenerator.java,v 1.2 2000/03/06 00:33:51 mandar Exp $
 * $Revision: 1.2 $
 * $Date: 2000/03/06 00:33:51 $
 *
 * ====================================================================
 * 
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 1999 The Apache Software Foundation.  All rights 
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:  
 *       "This product includes software developed by the 
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "The Jakarta Project", "Tomcat", and "Apache Software
 *    Foundation" must not be used to endorse or promote products derived
 *    from this software without prior written permission. For written 
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache"
 *    nor may "Apache" appear in their names without prior written
 *    permission of the Apache Group.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 *
 */ 

package org.apache.jasper.compiler;

/**
 * CharDataGenerator generates the character data present in the JSP
 * file. Typically this is HTML which lands up as strings in
 * out.println(...).
 * 
 * This generator will print the HTML line-by-line. This is a
 * feature desired by lots of tool vendors.
 *
 * @author Mandar Raje
 */
public class MappedCharDataGenerator extends CharDataGenerator {
    
    public MappedCharDataGenerator(char[] chars) {
	super(chars);
    }

    public void generate(ServletWriter writer, Class phase) {
	writer.indent();
	writer.print("out.write(\"");
	// Generate the char data:
	int limit       = chars.length;
	StringBuffer sb = new StringBuffer();
	for (int i = 0 ; i < limit ; i++) {
	    int ch = chars[i];
	    switch(ch) {
	    case '"':
		sb.append("\\\"");
		break;
	    case '\\':
		sb.append("\\\\");
		break;
	    case '\r':
		continue;
		/*
		  case '\'':
		  sb.append('\\');
		  sb.append('\'');
		  break;
		*/
	    case '\n':
		sb.append("\\r\\n");
		writer.print(sb.toString());
		writer.print("\");\n");
		sb = new StringBuffer();
		writer.indent();
		writer.print("out.write(\"");
		break;
	    case '\t':
		sb.append("\\t");
		break;
	    default:
		sb.append((char) ch);
	    }
	}
	writer.print(sb.toString());
	writer.print("\");\n");
    }
}
