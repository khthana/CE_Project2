/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1997 The Ohio State University
 *	GDB
 *
 *	$Id: do_main.c,v 6.3 1999/06/12 17:11:27 kmeyer1 Exp $
 * 
 *	Function:	- datalink output proprietor
 */

#include <kreq.h>
#include <priority.h>
#include <terror.h>

extern void		(*(dlo_inet()))();
extern void		(*(do_init()))();
extern void		(*(do_loadlinks()))();


int
main(argc, argv)

int			argc;
char			*argv[];

{
/*
 * Attach to kernel.
 */
	if (kinit(PRDLO)) lampanic("dlo_inet (kinit)");
/*
 * Initialize.
 */
	do_init();
	do_loadlinks();
/*
 * server loop
 */
	for (;;) {

		if (!dlo_inet()) {
			kexit(1);
			break;
		}
	}

	return(0);
}
