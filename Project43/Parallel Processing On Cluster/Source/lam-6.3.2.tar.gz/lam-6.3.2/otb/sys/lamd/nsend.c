/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1997 The Ohio State University
 *	GDB
 *
 *	$Id: nsend.c,v 6.3 1999/06/12 17:11:36 kmeyer1 Exp $
 * 
 *	Function:	- sends a network message
 */

#include <events.h>
#include <net.h>
#include <rreq.h>
#include <typical.h>

int
nsend(nhead)

struct nmsg		*nhead;		/* network message header */

{
/*
 * Get the routing information.
 */
	if ((nhead->nh_flags & NOBUF) ||
			((nhead->nh_node != LOCAL) &&
			(nhead->nh_node != getnodeid()))) {

		if (getroute(nhead)) {
			return(ERROR);
		}
	} else {
		nhead->nh_dl_event = EVBUFFERD;
	}
/*
 * If this send is for a multireel, nh_data[6] contains the packet number.
 */
	if (nhead->nh_flags & NREEL) {
		nhead->nh_data[6] = 0;
	}

	return(dsend(nhead));
}
