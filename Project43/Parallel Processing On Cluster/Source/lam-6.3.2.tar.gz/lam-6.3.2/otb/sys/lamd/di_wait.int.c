/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1995 The Ohio State University
 *	GDB
 *
 *	$Log: di_wait.int.c,v $
 *	Revision 6.2  1999/06/12 17:11:35  kmeyer1
 *	added copyright
 *	
 *	Revision 6.1  1996/11/23 18:45:11  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:32:10  gdburns
 * Ohio Release
 * 
 * Revision 5.2.1.1  96/02/26  20:58:38  gdburns
 * Don't check return value of void kio_intr().
 * 
 * Revision 5.2  94/08/22  13:51:13  gdburns
 * Ohio Release
 * 
 * Revision 5.1.1.1  94/08/18  11:11:41  gdburns
 * overhaul for new kernel
 * 
 * Revision 5.1  94/05/18  10:42:45  gdburns
 * Ohio Release
 * 
 * Revision 2.3  94/04/22  12:28:00  gdburns
 * Ohio Release
 * 
 *	Function:	- waits for network frame message
 *			- registers interrupt function and returns
 *			  to kernel in an 'R' state
 *	Accepts:	- Trollius interrupt number
 *			- socket descriptor
 */

#include <typical.h>

/*
 * external functions
 */
extern int		kio_intr();
extern void		di_forward();

void
di_wait(sockd)

int			sockd;

{
	kio_intr(sockd, di_forward, TRUE);
}
