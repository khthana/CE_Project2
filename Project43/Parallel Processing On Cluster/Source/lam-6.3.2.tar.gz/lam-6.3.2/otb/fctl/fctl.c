/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1997 The Ohio State University
 *	GDB
 *
 *	$Id: fctl.c,v 6.5 1999/06/12 17:11:14 kmeyer1 Exp $
 *
 *	Function:	- command to control certain filed functions
 *	Accepts:	- see the "usage" variable
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/param.h>
#include <sys/types.h>
#include <unistd.h>

#include <args.h>
#include <freq.h>
#include <net.h>
#include <priority.h>
#include <terror.h>
#include <typical.h>

#ifndef MAXPATHLEN
#define MAXPATHLEN	1024
#endif

/*
 * local functions
 */
static void		help();

/*
 * local variables
 */
static char		*usage =
		"fctl [-hS] [-s <descno>] [<directory>] <nodes>\n";
static char		pwd[MAXPATHLEN];


int
main(argc, argv)

int   			argc;    
char   			*argv[];

{
	int		n_index;		/* index of node entry */
	int		nodeid;			/* value of node entry */
	int		n_flags;		/* extra node entry info */
	int		tfd;			/* filed descriptor # */

	/* Ensure that we are not root */

	if (getuid() == 0 || geteuid() == 0) {
	  show_help(NULL, "deny-root", NULL);
	  exit(EACCES);
	}

/*
 * Parse the command line.
 */
	validopts("Ssh");
	followed("s");
	exclusive("Ss");

	if (do_args(&argc, argv)) {
		fprintf(stderr, usage);
		exit(errno);
	}
/*
 * Check for help request.
 */
	if (opt_taken('h')) {
		help();
		exit(0);
	}
/*
 * Attach to kernel.
 */
	if (kinit(PRCMD)) {
		terror("fctl (kinit)");
		exit(errno);
	}

	if ((nid_parse(&argc, argv)) || (errno = (argc <= 2) ? 0 : EUSAGE)) {
		fprintf(stderr, usage);
		kexit(errno);
	}
/*
 * Loop through all specified nodes.
 */
	nid_get(&n_index, &nodeid, &n_flags);

	if (n_index < 0) {
		fprintf(stderr, usage);
		kexit(EUSAGE);
	}

	do {
/*
 * Clean up file descriptors in filed.
 */
		if (opt_taken('S')) {
			if (lam_rfrmfd(nodeid, NOTFD)) lamfail("fctl (rfrmfd)");
		} else if (opt_taken('s')) {
		 	intparam('s', &tfd);
			if (lam_rfrmfd(nodeid, tfd)) lamfail("fctl (rfrmfd)");
		}
/*
 * Print the current working directory.
 */
		else if (argc == 1) {
			if (lam_rfgetwd(nodeid, pwd) == 0)
					lamfail("fctl (rfgetwd)");
			printf("%s: %s\n", nid_fmt(nodeid), pwd);
		}
/*
 * Change current working directory.
 */
		else if (argc == 2) {
			if (lam_rfchdir(nodeid, argv[1]))
					lamfail("fctl (rfchdir)");
		}

		nid_get(&n_index, &nodeid, &n_flags);
	} while (n_index);

	kexit(0);
	return(0);
}

/*
 *	  help
 *
 *	  Function:	- prints helpful information on the fctl command
 */
static void
help()

{
	printf("\nSynopsis:	fctl [options] <nodes> [<dir>]\n");
	printf("\nDescription:	Control file daemon operations.\n");
	printf("\nOptions:	-h	Print this help message.\n");
	printf("\t\t-S	Blow away all open descriptors.\n");
	printf("\t\t-s <#>	Blow away one specific descriptor.\n");
	printf("\t\t<dir>	Change to new working directory.\n");
	printf("\t\tnone	Print current working directory.\n");
	mnusage();
	printf("\t\th (local), o (origin), N (all)\n");
	printf("\nExample:	fctl h -S\n");
	printf("\t\t\t\"Clean up (reset) the file daemon.\"\n");
}
