#!/bin/sh -f

VERSIONFILE=share/h/patchlevel.h

cat $VERSIONFILE | grep LAM_VERSION | cut -d\" -f2 > ver.$$
ver="`cat ver.$$`"
rm -f ver.$$

# rpm names don't like extra dashes
shortver=`echo $ver | sed -e 's/-//g'`

for transport in tcp sysv usysv; do
    rpm --rcfile ./config/lamrpmrc --addsign lam-$shortver-$transport.1.i386.rpm
done
