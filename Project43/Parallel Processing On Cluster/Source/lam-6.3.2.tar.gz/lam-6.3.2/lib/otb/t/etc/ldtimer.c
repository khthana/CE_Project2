/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	OSU Research Computing					Trillium
 *	Copyright 1991 The Ohio State University
 *	GDB
 *
 *	$Log: ldtimer.c,v $
 *	Revision 6.2  1999/06/12 18:04:32  kmeyer1
 *	added copyright
 *	
 *	Revision 6.1  1996/11/23 19:41:33  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:07:13  gdburns
 * Ohio Release
 * 
 * Revision 5.2  94/08/22  13:35:00  gdburns
 * Ohio Release
 * 
 * Revision 5.1  94/05/18  10:35:28  gdburns
 * Ohio Release
 * 
 * Revision 2.3  94/04/22  12:08:24  gdburns
 * Ohio Release
 * 
 * Revision 2.2  92/04/30  11:54:56  trillium
 * Ohio Release
 * 
 * Revision 2.1  91/10/09  15:35:22  gdburns
 * initial revision
 * 
 *
 *	Function:	- loads current value of local node's timer
 *			- just a stub now, to match ITB ldtimer()
 */

#include <portable.h>

int4
ldtimer()

{
	return(INT4_NIL);
}
