/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1995 The Ohio State University
 *	RBD
 *
 *	$Log: nmsgconv.c,v $
 *	Revision 6.2  1999/05/24 16:56:51  kmeyer1
 *	added $copyright$
 *	
 *	Revision 6.1  1996/11/23 19:58:11  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:48:21  gdburns
 * Ohio Release
 * 
 * Revision 5.2.1.1  95/12/20  12:09:03  gdburns
 * Add DINT2MSG conversion.
 * 
 * Revision 5.2  94/08/22  13:57:06  gdburns
 * Ohio Release
 * 
 * Revision 5.1  94/05/18  10:56:59  gdburns
 * Ohio Release
 * 
 * Revision 2.3  94/04/22  12:35:04  gdburns
 * Ohio Release
 * 
 *	Function:	- Trollius message byte order conversion routines
 *
 *			- _ltot_sysnmsg: ltot() system part of message
 *			- _ttol_sysnmsg: ttol() system part of message
 *			- _ltot_usrnmsg: ltot() user part of message
 *			- _ttol_usrnmsg: ttol() user part of message
 */

#include <portable.h>
#include <net.h>
#include <t_types.h>

/*
 *	_ltot_sysnmsg
 *
 *	Function:	- convert system part of msg to Trollius byte order
 *			- the data pouch is excluded
 *	Accepts:	- ptr to network message descriptor
 */
void
_ltot_sysnmsg(nhead)

struct nmsg		*nhead;

{
	ltoti4(&(nhead->nh_dl_event), &(nhead->nh_dl_event));
	ltoti4(&(nhead->nh_dl_link), &(nhead->nh_dl_link));
	ltoti4(&(nhead->nh_node), &(nhead->nh_node));
	ltoti4(&(nhead->nh_event), &(nhead->nh_event));
	ltoti4(&(nhead->nh_type), &(nhead->nh_type));
	ltoti4(&(nhead->nh_length), &(nhead->nh_length));
	ltoti4(&(nhead->nh_flags), &(nhead->nh_flags));
}

/*
 *	_ttol_sysnmsg
 *
 *	Function:	- convert system part of msg to local byte order
 *			- the data pouch is excluded
 *	Accepts:	- ptr to network message descriptor
 */
void
_ttol_sysnmsg(nhead)

struct nmsg		*nhead;

{
	ttoli4(&(nhead->nh_dl_event), &(nhead->nh_dl_event));
	ttoli4(&(nhead->nh_dl_link), &(nhead->nh_dl_link));
	ttoli4(&(nhead->nh_node), &(nhead->nh_node));
	ttoli4(&(nhead->nh_event), &(nhead->nh_event));
	ttoli4(&(nhead->nh_type), &(nhead->nh_type));
	ttoli4(&(nhead->nh_length), &(nhead->nh_length));
	ttoli4(&(nhead->nh_flags), &(nhead->nh_flags));
}

/*
 *	_ltot_usrnmsg
 *
 *	Function:	- convert message and data pouch to Trollius byte order
 *			- system part of message assumed in local byte order
 *	Accepts:	- ptr to network message descriptor
 */
void
_ltot_usrnmsg(nhead)

struct nmsg		*nhead;

{
/*
 * Convert the data pouch.
 */
	switch(nhead->nh_flags & DMSKDATA) {

		case 0:
		case DINT4DATA:
		mltoti4((void *) nhead->nh_data, NHDSIZE);
		break;

		case DFLT4DATA:
		mltotf4((void *) nhead->nh_data, NHDSIZE);
		break;

		case DFLT8DATA:
		mltotf8((void *) nhead->nh_data, NHDSIZE / 2);
		break;
	}
/*
 * Convert the message.
 */
	if (nhead->nh_length <= 0) {
		return;
	}

	switch(nhead->nh_flags & DMSKMSG) {

		case DINT4MSG:
		mltoti4(nhead->nh_msg, nhead->nh_length / sizeof(int4));
		break;

		case DFLT4MSG:
		mltotf4(nhead->nh_msg, nhead->nh_length / sizeof(float4));
		break;

		case DFLT8MSG:
		mltotf8(nhead->nh_msg, nhead->nh_length / sizeof(float8));
		break;

		case DINT2MSG:
		mltoti2(nhead->nh_msg, nhead->nh_length / sizeof(int2));
		break;
	}
}

/*
 *	_ttol_usrnmsg
 *
 *	Function:	- convert message and data pouch to local byte order
 *			- system part of message assumed in local byte order
 *	Accepts:	- ptr to network message descriptor
 */
void
_ttol_usrnmsg(nhead)

struct nmsg		*nhead;

{
/*
 * Convert the data pouch.
 */
	switch(nhead->nh_flags & DMSKDATA) {

		case 0:
		case DINT4DATA:
		mttoli4((void *) nhead->nh_data, NHDSIZE);
		break;

		case DFLT4DATA:
		mttolf4((void *) nhead->nh_data, NHDSIZE);
		break;

		case DFLT8DATA:
		mttolf8((void *) nhead->nh_data, NHDSIZE / 2);
		break;
	}
/*
 * Convert the message.
 */
	if (nhead->nh_length <= 0) {
		return;
	}

	switch(nhead->nh_flags & DMSKMSG) {

		case DINT4MSG:
		mttoli4(nhead->nh_msg, nhead->nh_length / sizeof(int4));
		break;

		case DFLT4MSG:
		mttolf4(nhead->nh_msg, nhead->nh_length / sizeof(float4));
		break;

		case DFLT8MSG:
		mttolf8(nhead->nh_msg, nhead->nh_length / sizeof(float8));
		break;

		case DINT2MSG:
		mttoli2(nhead->nh_msg, nhead->nh_length / sizeof(int2));
		break;
	}
}
