/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *
 *	Copyright 1995 The Ohio State University
 *	$Log: nodespin.c,v $
 *	Revision 6.2  1999/05/24 16:56:51  kmeyer1
 *	added $copyright$
 *	
 *	Revision 6.1  1996/11/23 19:58:12  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:48:22  gdburns
 * Ohio Release
 * 
 *
 *	Function:	- pretty prints successive node ID messages
 */

#include <stdio.h>

#include <args.h>
#include <portable.h>

/*
 *	nodespin_init
 *
 *	Function:	- prints initial message
 *	Accepts:	- message
 */
void
nodespin_init(msg)

char			*msg;

{
	printf("%s           ", msg);
}

/*
 *	nodespin_next
 *
 *	Function:	- prints next node ID
 *	Accepts:	- node ID
 */
void
nodespin_next(node)

int4			node;

{
	char		buf[16];

	sprintf(buf, "%s...", mnemonic(node));
	printf("%-10.10s", buf);
	fflush(stdout);
}

/*
 *	nodespin_end
 *
 *	Function:	- completes node message
 */
void
nodespin_end()

{
	printf("%-10.10s\n", "done");
}
