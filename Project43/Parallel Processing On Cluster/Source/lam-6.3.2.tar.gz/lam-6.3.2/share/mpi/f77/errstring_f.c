/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1997 The Ohio	State University
 *	RBD/NJN
 *
 *	$Id: errstring_f.c,v 6.4 1999/09/02 01:34:12 prijks Exp $
 *
 *	Function:	- MPI_Error_string F77 wrapper
 */

#include <lam_config.h>

#include <blktype.h>
#include <mpi.h>
#include <MPISYSF.h>
#include <mpisys.h>

void 
mpi_error_string_(err, str, l, ierr, ns)

int	*err;
char	*str;
int	*l, *ierr;
int	ns;

{
	char errstring[MPI_MAX_ERROR_STRING + 1];

	if (ns < MPI_MAX_ERROR_STRING) {
		lam_setfunc(BLKMPIERRSTRING);
		*ierr = lam_errfunc(MPI_COMM_WORLD, BLKMPIERRSTRING,
					lam_mkerr(MPI_ERR_ARG, 0));
		return;
	}

	*ierr =	MPI_Error_string(*err, errstring, l);

	if (*ierr == MPI_SUCCESS) {
		lam_C2F_string(errstring, str, ns);
	}
}
