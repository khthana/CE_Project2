/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1996 The Ohio State University
 *	RBD/NJN
 *
 *	$Id: cfree.c,v 6.5 1999/08/26 20:11:20 jsquyres Exp $
 *
 *	Function:	- free a communicator
 *	Accepts:	- communicator (inout)
 *	Returns:	- MPI_SUCCESS or error code
 */

#include <blktype.h>
#include <mpi.h>
#include <mpisys.h>

/*
 * external functions
 */
extern int		lam_comm_free();


int
MPI_Comm_free(comm)

MPI_Comm		*comm;

{
	int		err;

	lam_initerr();
	lam_setfunc(BLKMPICOMMFREE);
/*
 * Check the arguments.
 */
	if (comm == 0) {
		return(lam_errfunc(MPI_COMM_WORLD,
			BLKMPICOMMFREE, lam_mkerr(MPI_ERR_COMM, 0)));
	}

	if (*comm == MPI_COMM_NULL || ((*comm)->c_flags & LAM_PREDEF)) {
		return(lam_errfunc(MPI_COMM_WORLD,
			BLKMPICOMMFREE, lam_mkerr(MPI_ERR_COMM, 0)));
	}
/*
 * Delete the communicator if it has no pending requests.
 */
	if (--((*comm)->c_refcount) == 0) {

#if LAM_WANT_IMPI
	  if (LAM_IS_IMPI(*comm))
	    MPI_Comm_free(&(*comm)->c_shadow);
#endif
		err = lam_comm_free(*comm);
		*comm = MPI_COMM_NULL;

		if (err != MPI_SUCCESS) {
			return(lam_errfunc(MPI_COMM_WORLD,
						BLKMPICOMMFREE, err));
		}
	} else {
		*comm = MPI_COMM_NULL;
	}
	
	lam_resetfunc(BLKMPICOMMFREE);
	return(MPI_SUCCESS);
}
