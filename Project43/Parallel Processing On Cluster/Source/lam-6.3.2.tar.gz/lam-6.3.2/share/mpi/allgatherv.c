/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1996 The Ohio State University
 *	JRV/RBD
 *
 *	$Id: allgatherv.c,v 6.3 1999/08/04 21:43:48 kmeyer1 Exp $
 *
 *	Function:	- gather varying length buffers at all process ranks
 *	Accepts:	- send buffer
 *			- send count
 *			- send datatype
 *			- recv buffer
 *			- recv counts
 *			- displacements
 *			- recv datatype
 *			- communicator
 *	Returns:	- MPI_SUCCESS or an MPI error code
 */

#include <blktype.h>
#include <mpi.h>
#include <mpisys.h>
#include <lam_config.h>

int
MPI_Allgatherv(sbuf, scount, sdtype,
			rbuf, rcounts, disps, rdtype, comm)

void			*sbuf;
int			scount;
MPI_Datatype		sdtype;
void			*rbuf;
int			*rcounts;
int			*disps;
MPI_Datatype		rdtype;
MPI_Comm		comm;

{
	int		i;			/* favourite index */
	int		size;			/* group size */
	int		err;			/* error code */

	lam_initerr();
	lam_setfunc(BLKMPIALLGATHERV);
/*
 * Check for invalid arguments.
 */
	if ((comm == MPI_COMM_NULL) || LAM_IS_INTER(comm)) {
		return(lam_errfunc(comm, BLKMPIALLGATHERV,
				lam_mkerr(MPI_ERR_COMM, 0)));
	}

	if ((sdtype == MPI_DATATYPE_NULL) || (rdtype == MPI_DATATYPE_NULL)) {
		return(lam_errfunc(comm, BLKMPIALLGATHERV,
				lam_mkerr(MPI_ERR_TYPE, 0)));
	}

	if (disps == 0) {
		return(lam_errfunc(comm, BLKMPIALLGATHERV,
				lam_mkerr(MPI_ERR_ARG, 0)));
	}

	if ((scount < 0) || (rcounts == 0)) {
		return(lam_errfunc(comm, BLKMPIALLGATHERV,
				lam_mkerr(MPI_ERR_COUNT, 0)));
	}

#if LAM_WANT_IMPI

	/* Remove this when IMPI collectives are implemented */

        if (LAM_IS_IMPI(comm)) {
	  return lam_err_comm(comm, MPI_ERR_COMM, 0, 
			      "Collectives not yet implemented on IMPI communicators");
	}
#endif

	LAM_TRACE(lam_tr_cffstart(BLKMPIALLGATHERV));
/*
 * Collect all values at each process, one at a time.
 */
	MPI_Comm_size(comm, &size);

	for (i = 0; i < size; ++i) {

		err = MPI_Gatherv(sbuf, scount, sdtype, rbuf,
					rcounts, disps, rdtype, i, comm);
		if (err != MPI_SUCCESS) {
			return(lam_errfunc(comm, BLKMPIALLGATHERV, err));
		}
	}

	LAM_TRACE(lam_tr_cffend(BLKMPIALLGATHERV, -1, comm, sdtype, scount));

	lam_resetfunc(BLKMPIALLGATHERV);
	return(MPI_SUCCESS);
}
