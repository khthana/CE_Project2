/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1996 The Ohio State University
 *	JRV/RBD
 *
 *	$Id: allreduce.c,v 6.3 1999/08/04 21:43:48 kmeyer1 Exp $
 *
 *	Function:	- reduce and return data to all processes
 *	Accepts:	- send buffer
 *			- receive buffer
 *			- count of elements
 *			- type of elements
 *			- operation to perform
 *			- communicator
 *	Returns:	- MPI_SUCCESS or error code
 */

#include <lam_config.h>
#include <blktype.h>
#include <mpi.h>
#include <mpisys.h>

int
MPI_Allreduce(sbuf, rbuf, count, dtype, op, comm)

void			*sbuf;
void			*rbuf;
int			count;
MPI_Datatype		dtype;
MPI_Op			op;
MPI_Comm		comm;

{
	int		err;			/* error code */

	lam_initerr();
	lam_setfunc(BLKMPIALLREDUCE);
/*
 * Check for invalid arguments.
 */
	if ((comm == MPI_COMM_NULL) || LAM_IS_INTER(comm)) {
		return (lam_errfunc(comm, BLKMPIALLREDUCE,
				lam_mkerr(MPI_ERR_COMM, 0)));
	}

	if (dtype == MPI_DATATYPE_NULL) {
		return(lam_errfunc(comm, BLKMPIALLREDUCE,
				lam_mkerr(MPI_ERR_TYPE, 0)));
	}


#if LAM_WANT_IMPI

	/* Remove this when IMPI collectives are implemented */

        if (LAM_IS_IMPI(comm)) {
	  return lam_err_comm(comm, MPI_ERR_COMM, 0, 
			      "Collectives not yet implemented on IMPI communicators");
	}
#endif

	LAM_TRACE(lam_tr_cffstart(BLKMPIALLREDUCE));
/*
 * Reduce to 0 and broadcast.
 */
	err = MPI_Reduce(sbuf, rbuf, count, dtype, op, 0, comm);
	if (err != MPI_SUCCESS) {
		return (lam_errfunc(comm, BLKMPIALLREDUCE, err));
	}

	err = MPI_Bcast(rbuf, count, dtype, 0, comm);
	if (err != MPI_SUCCESS) {
		return (lam_errfunc(comm, BLKMPIALLREDUCE, err));
	}

	LAM_TRACE(lam_tr_cffend(BLKMPIALLREDUCE, -1, comm, dtype, count));

	lam_resetfunc(BLKMPIALLREDUCE);
	return(MPI_SUCCESS);
}
