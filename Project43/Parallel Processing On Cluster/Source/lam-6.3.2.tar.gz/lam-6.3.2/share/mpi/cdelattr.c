/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1997 The Ohio State University
 *	RBD/NJN
 *
 *	$Id: cdelattr.c,v 1.0 1999/07/21 19:00:09 jsquyres Exp $
 *
 *	Function:	- delete attribute
 *			- detach attribute from communicator
 *	Accepts:	- communicator
 *			- attribute key
 *	Returns:	- MPI_SUCCESS or error code
 */

#include <errno.h>

#include <blktype.h>
#include <mpi.h>
#include <mpisys.h>


int
MPI_Comm_delete_attr(comm, key)

MPI_Comm		comm;
int			key;

{
	struct _attrkey	*p;
	struct _attr	*pk;
	int		err;

	lam_initerr_m();
	lam_setfunc_m(BLKMPICOMMDELETEATTR);
/*
 * Check the arguments.
 */
	if (comm == MPI_COMM_NULL) {
		return(lam_err_comm(MPI_COMM_WORLD,
				MPI_ERR_COMM, 0, "null handle"));
	}

	p = lam_getattr(key);
	if (p == 0) {
		return(lam_err_comm(comm, MPI_ERR_KEYVAL, 0, ""));
	}
/*
 * Check if the key is attached to the communicator.
 */
	pk = lam_getkey(comm->c_keys, key);
	if (pk == 0) {
		return(lam_err_comm(comm, MPI_ERR_KEYVAL, 0,
			"not on communicator"));
	}
/*
 * Delete the attribute via the callback function.
 */
	if (((MPI_Comm_delete_attr_function *) (p->ak_del))
			!= MPI_COMM_NULL_DELETE_FN) {

		if (p->ak_flags & LAM_LANGF77) {
			(*((MPI_F_delete_function *) (p->ak_del)))
				(&comm->c_f77handle, &key,
				(int *) &(pk->a_value),
				(int *) &(p->ak_extra), &err);
		} else {
			err = (*((MPI_Comm_delete_attr_function *) (p->ak_del)))
				(comm, key, pk->a_value, p->ak_extra);
		}

		if (err != MPI_SUCCESS) {
			return(lam_err_comm(comm, err, 0,
					"deleting attribute"));
		}
	}
/*
 * Detach the key from the communicator.
 */
	if (lam_delkey(comm->c_keys, key)) {
		return(lam_err_comm(comm, MPI_ERR_INTERN, errno,
			"detaching key"));
	}

	lam_resetfunc_m(BLKMPICOMMDELETEATTR);
	return(MPI_SUCCESS);
}
