/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1997 The Ohio State University
 *	GDB
 *
 *	$Id: rfopen.c,v 6.3 1999/05/25 17:44:43 kmeyer1 Exp $
 *
 *	Function:	- opens a file using remote filed
 *			- server nodeid may be specified by prefixing
 *			  filename with <nodeid>: as in 100:temp
 *	Accepts:	- file name
 *			- open flags
 *			- mode for newly created files
 *	Returns:	- remote file descriptor
 */

#include <errno.h>
#include <string.h>
#include <unistd.h>

#include <events.h>
#include <freq.h>
#include <ksignal.h>
#include <net.h>
#include <portable.h>
#include <typical.h>

/*
 * external variables
 */
extern struct fclient	_ufd[FUMAX];	/* client file descriptor table */

/*
 * external functions
 */
extern char		*_fnparse();	/* parse nodeid from file name */

int
lam_rfopen(name, flags, mode)

CONST char		*name;
int4			flags;
int4			mode;

{
	struct nmsg	nhead;		/* network message desc. */
	struct freq	*request;	/* filed request */
	struct freply	*reply;		/* filed reply */
	int		mask;		/* signal mask */
	int		fd;		/* new file descriptor (ufd) */
/*
 * Find slot in client fd table.
 */
	for (fd = 3; (fd < FUMAX) && (_ufd[fd].fu_tflags != 0); ++fd);

	if (fd >= FUMAX) {
		errno = ENFILE;
		return(LAMERROR);
	}
/*
 * Determine server node ID.
 */
	name = _fnparse(name, &nhead.nh_node);
		
	request = (struct freq *) nhead.nh_data;
	reply = (struct freply *) nhead.nh_data;

	request->fq_src_node = getnodeid();
	request->fq_src_event = -getpid();
	request->fq_req = FQOPEN;
	request->fq_mode = mode;
	request->fq_flags = flags;

	nhead.nh_event = EVFILED;
	nhead.nh_type = 0;
	nhead.nh_flags = 0;
	nhead.nh_length = strlen(name) + 1;

	if (nhead.nh_length > MAXNMSGLEN) {
		errno = ENAMETOOLONG;
		return(LAMERROR);
	}

	nhead.nh_msg = (char *) name;
	mask = ksigblock(sigmask(SIGUDIE) | sigmask(SIGARREST));

	if (nsend(&nhead)) {
		ksigsetmask(mask);
		return(LAMERROR);
	}

	nhead.nh_event = -getpid();
	nhead.nh_length = 0;
	nhead.nh_msg = 0;

	if (nrecv(&nhead)) {
		ksigsetmask(mask);
		return(LAMERROR);
	}

	ksigsetmask(mask);

	if (reply->fr_errno != 0) {
		errno = reply->fr_errno;
		return(LAMERROR);
	}

	else {
		_ufd[fd].fu_tflags = flags;
		_ufd[fd].fu_node = nhead.nh_node;
		_ufd[fd].fu_tfd = reply->fr_ret;
		return(fd);
	}
}

/*
 * backwards compatibility
 */
int rfopen(name, flags, mode) CONST char *name; int4 flags, mode;
	{ return(lam_rfopen(name, flags, mode)); }
