/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *
 *	$Id: events.h,v 6.3 1999/07/26 00:12:53 kmeyer1 Exp $
 *
 *	Function:	- system events
 */

#ifndef _EVENTS
#define _EVENTS

#ifndef	NOTEVENT
#define	NOTEVENT	0x80000001
#endif

/*
 * core server events
 */
#define EVROUTER	-1
#define EVBOOTD		-2
#define EVMALLOCD	-3
#define EVDLOINIT	-4
#define EVDLI		-5
#define EVCASTD		-6
#define EVFILED		-7
#define EVLOADD		-9
#define EVBFORWARD	-10
#define EVKENYAD	-11
#define EVIOD		-12
#define EVECHOD		-13
#define EVBUFFERD	-14
#define EVFLATD		-15

/*
 * special local layer events
 */
#define EVPAUSE		-17
#define EVSTOP		-18

#define EVDL0		-25
#define EVDL1		-26
#define EVDL2		-27
#define EVDL3		-28

/*
 * optional server events
 */
#define EVLEDD		-33
#define EVSPEAKD	-34
#define EVI860D		-35
#define EVTRACED	-37
#define EVMTVD		-38
#define EVMEMD		-39
#define EVBRENDAD	-40
#define EVGROUPD	-41

/*
 * optional tools
 */
#define EVIPCDIAG	-0x31
#define EVXMPI		-0x32
#define EVIMPID		-0x33
#define EVIMPID_REPLY   -0x34

#endif
