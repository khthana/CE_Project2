/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *
 *	Revision 6.1  1996/11/23 21:55:44  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:54:09  gdburns
 * Ohio Release
 * 
 * Revision 5.2  94/08/22  14:00:50  gdburns
 * Ohio Release
 * 
 * Revision 5.1  94/05/18  12:44:46  gdburns
 * Ohio Release
 * 
 * Revision 2.3  94/04/22  12:49:11  gdburns
 * Ohio Release
 * 
 * Revision 2.2  93/10/14  18:28:53  raja
 * pre-release to 2.3
 * 
 *	Function:	- virtual circuits templates and constants
 */

#ifndef _VCTABLE
#define _VCTABLE

#include <portable.h>

/*
 * constants
 */
#define VCMAX		67		/* VC table size (prime #) */

/*
 * hashing macro
 */
#define _vchash(n,e,t)	(abs((n) + (e) + (t)) % VCMAX)

/*
 * templates
 */
struct vcdesc {
	int4		vc_node;	/* node identifier */
	int4		vc_event;	/* message event */
	int4		vc_type;	/* event type */
	int4		vc_path;	/* VC path */
};

#endif
