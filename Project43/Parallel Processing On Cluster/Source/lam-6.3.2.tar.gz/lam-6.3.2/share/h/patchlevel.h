/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *
 *	$Id: patchlevel.h,v 6.35 1999/11/16 07:35:07 jsquyres Exp $
 *
 *	Function:	- patch level
 */

#ifndef _PATCHLEVEL_H
#define _PATCHLEVEL_H



/*****************************************************************
 *****************************************************************
 ** Be sure to update/change these in share/h/mpif.h as well!!! **
 **        (#$%#@%#% language interoperability...)              **
 *****************************************************************
 *****************************************************************/


/* LAM version numbers.  We don't currently use the integer values
   anywhere, but we might someday, so it doesn't hurt to define them
   here. */

#define LAM_VERSION		"6.3.2"
#define LAM_MAJOR_VERSION 6
#define LAM_MINOR_VERSION 3
#define LAM_RELEASE_VERSION 2
#define LAM_ALPHA_VERSION 0
#define LAM_BETA_VERSION 0


#endif
