/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *
 *	Function:	- defines constants for the software signal package
 *
 *			- based on Trollius 2.0 Copyright 1990
 *			  The Ohio State University and Cornell
 *			  Research Foundation
 */

#ifndef _KSIGNAL_H
#define _KSIGNAL_H

#include <signal.h>

#include <lam_config.h>
#include <portable.h>

#define LAM_KSIG_DFL	((void (*)()) 0)
#define LAM_KSIG_IGN	((void (*)()) 1)
#define lam_ksigmask(s)	(1 << ((s) - 1))

#ifndef SIG_DFL
#define SIG_DFL		((void (*)()) 0)
#endif

#ifndef SIG_IGN
#define SIG_IGN		((void (*)()) 1)
#endif

#ifndef sigmask
#define sigmask(s)	(1 << ((s) - 1))
#endif

#ifndef BADSIG
#define BADSIG		((void (*)()) -1)
#endif

/*
 * signals
 */
#define TNSIG		10			/* number of signals */
#define SIGTRACE	1			/* unload trace data */
#define SIGC		2			/* user defined */
#define SIGARECV	3			/* async receive */
#define SIGUDIE		4			/* death */
#define SIGARREST	5			/* stop */
#define SIGRELEASE	6			/* continue stopped process */
#define SIGA		7			/* user defined */
#define SIGB		8			/* user defined */
#define SIGFUSE		9			/* local node about to die */
#define SIGSHRINK	10			/* multicomputer has shrunk */
#define SIG_PRIV	(0)			/* signals which cannot be
						   affected by the user */

#define LAM_SIGTRACE	1			/* unload trace data */
#define LAM_SIGC	2			/* user defined */
#define LAM_SIGARECV	3			/* async receive */
#define LAM_SIGUDIE	4			/* death */
#define LAM_SIGARREST	5			/* stop */
#define LAM_SIGRELEASE	6			/* continue stopped process */
#define LAM_SIGA	7			/* user defined */
#define LAM_SIGB	8			/* user defined */
#define LAM_SIGFUSE	9			/* local node about to die */
#define LAM_SIGSHRINK	10			/* multicomputer has shrunk */

#ifdef __cplusplus
extern "C" {
#endif

extern int		kdoom __ARGS((int pid, int sig));
extern int		kpause __ARGS((void));
extern int4		ksigblock __ARGS((int4 mask));
extern int4		ksigretry __ARGS((int flags));
extern int4		ksigsetmask __ARGS((int4 mask));
extern int4		ksigsetretry __ARGS((int flags));
extern void		(*(ksignal __ARGS((int sig, void (*sigfunc)())))) ();

extern int		lam_kpause __ARGS((void));
extern int4		lam_ksigblock __ARGS((int4 mask));
extern int4		lam_ksigretry __ARGS((int flags));
extern int4		lam_ksigsetmask __ARGS((int4 mask));
extern int4		lam_ksigsetretry __ARGS((int flags));
extern void		(*(lam_ksignal __ARGS((int sig,
					void (*sigfunc)())))) ();

#ifdef __cplusplus
}
#endif

#endif	/* _KSIGNAL_H */
