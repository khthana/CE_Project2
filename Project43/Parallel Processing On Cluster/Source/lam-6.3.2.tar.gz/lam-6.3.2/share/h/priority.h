/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *
 *	$Id: priority.h,v 6.3 1999/06/09 23:10:09 jsquyres Exp $
 *
 *	Function:	- priorities for Trollius system processes
 */

#ifndef _PRIORITY
#define _PRIORITY

/*
 * These priorities ensure message ordering.
 */
#define	PRMAX		1500
#define	PRROUTER	1400
#define	PRBUFFERD	1100
#define	PRDLO		1090
#define	PRDLI		1087

#define	PRECHOD		1085
#define	PRLOADD		1085
#define	PRFILED		1085
#define	PRBFORWARD	1085
#define	PRDAEMON	1085
#define PRDIED		1084

#define	PRCMD		1095
#define	PRDOOM		1095

#endif
