/* 
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Revision 6.2  1999/03/17 14:19:37  jsquyres
 *
 *	Revision 6.1  1996/11/23 21:54:35  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:52:54  gdburns
 * Ohio Release
 * 
 * Revision 5.2.1.1  95/07/16  04:23:23  raja
 * Support ah_setcmp() and ah_*_elm() functions.
 * 
 * Revision 5.2  94/08/22  14:00:21  gdburns
 * Ohio Release
 * 
 * Revision 5.1  94/05/18  12:44:12  gdburns
 * Ohio Release
 * 
 *	Function:	- generic hash table templates and constants
 *			- for both the static and dynamic versions
 */

#ifndef _ALLHASH
#define _ALLHASH

#include <lam_config.h>
#include <portable.h>

/*
 * flags defining the modes of operation
 */
#define AHLRU		((int4) 1)	/* LRU counters are used */
#define AHNOINIT	((int4) 2)	/* hash table not initialized */

/* 
 * structure definitions
 */
struct ah_desc {			/* hash table descriptor */
	int4		ah_maxnelem;	/* maximum nbr. elements */
	int4		ah_nelem;	/* current nbr. elements */
	int4		ah_elemsize;	/* size of element */
	int4		ah_nullkey;	/* null hash key value */
	int4		ah_mode;	/* mode of operation */
	int4		*ah_lru;	/* table of LRU counters */
	void		*ah_table;	/* ptr to the hash table */
	int		(*ah_cmp)();	/* comparison function */
};

/*
 * type definitions
 */
typedef struct ah_desc	HASH;
typedef struct ah_desc	SHASH;

/*
 * prototypes
 */

#ifdef __cplusplus
extern "C" {
#endif

extern HASH		*ah_init __ARGS((int4 size, int4 elemsize,
				int4 nullkey, int4 mode));
extern SHASH		*ahs_init __ARGS((int4 size, int4 esize,
				int4 nullkey, int4 mode, void *htbl,
				int4 *lru, SHASH *ahsd));
extern int		ah_delete __ARGS((HASH *ahd, int4 key));
extern int		ah_delete_elm __ARGS((HASH *ahd, void *elem));
extern int		ah_expand __ARGS((HASH *ahd, int4 newsize));
extern int		ah_insert __ARGS((HASH *ahd, void *elem));
extern int		ah_kick __ARGS((HASH *ahd, void *elem));
extern void		ah_free __ARGS((HASH *ahd));
extern void		ah_setcmp __ARGS((HASH *ahd, int (*cmp)()));
extern void		*ah_find __ARGS((HASH *ahd, int4 key));
extern void		*ah_find_elm __ARGS((HASH *ahd, void *elem));
extern void		*ah_next __ARGS((HASH *ahd, void *elem));

#ifdef __cplusplus
}
#endif

/*
 * function macros
 */
#define ah_count(ahd)		((ahd)->ah_nelem)
#define ah_size(ahd)		((ahd)->ah_maxnelem)
#define ah_top(ahd)		(ah_next(ahd, (void *) 0))

#define ahs_find(ahd, x)	ah_find(ahd, x)
#define ahs_find_elm(ahd, x)	ah_find_elm(ahd, x)
#define ahs_delete(ahd, x)	ah_delete(ahd, x)
#define ahs_delete_elm(ahd, x)	ah_delete_elm(ahd, x)
#define ahs_insert(ahd, x)	ah_insert(ahd, x)
#define ahs_kick(ahd, x)	ah_kick(ahd, x)
#define ahs_setcmp(ahd, x)	ah_setcmp(ahd, x)
#define ahs_count(ahd)		ah_count(ahd)
#define ahs_size(ahd)		ah_size(ahd)
#define ahs_top(ahd)		ah_top(ahd)
#define ahs_next(ahd, x)	ah_next(ahd, x)

#endif
