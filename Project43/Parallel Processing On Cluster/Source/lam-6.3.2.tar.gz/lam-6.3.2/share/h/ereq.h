/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *
 *	Revision 6.2  1999/03/17 14:19:39  jsquyres
 *	
 *	Revision 6.1  1996/11/23 21:54:52  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:53:21  gdburns
 * Ohio Release
 * 
 * Revision 5.2  94/08/22  14:00:30  gdburns
 * Ohio Release
 * 
 * Revision 5.1  94/05/18  12:44:20  gdburns
 * Ohio Release
 * 
 * Revision 2.3  94/04/22  12:48:49  gdburns
 * Ohio Release
 * 
 * Revision 2.2.1.2  93/12/11  17:54:35  raja
 * Use const in prototypes.
 * 
 * Revision 2.2.1.1  93/09/15  14:54:01  raja
 * Declare ANSI C and C++ function prototypes.
 * 
 * Revision 2.2  92/04/30  14:45:13  trillium
 * Ohio Release
 * 
 * Revision 2.1  91/03/20  11:34:46  gdburns
 * Ohio Release
 * 
 *	Function:	- defines constants and structures for use
 *			  with the echo daemon
 *			- based on Trollius 2.0 Copyright 1990
 *			  The Ohio State University and Cornell Research
 *			  Foundation
 */

#ifndef _EREQ
#define _EREQ

#include <lam_config.h>
#include <portable.h>
#include <net.h>

struct ereq {
	int4		eq_node;	/* source node */
	int4		eq_event;	/* source event */
};

#ifdef __cplusplus
extern "C" {
#endif

extern int4		recho __ARGS((int4 node, const char *sm,
						char *dm, int4 len));

#ifdef __cplusplus
}
#endif

#endif
