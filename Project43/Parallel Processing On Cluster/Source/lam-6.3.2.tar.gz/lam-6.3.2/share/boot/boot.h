/*
 *
 * Copyright 1998-1999, University of Notre Dame.
 * Authors: Jeffrey M. Squyres, Kinis L. Meyer with M. D. McNally 
 *          and Andrew Lumsdaine
 *
 * This file is part of the Notre Dame LAM implementation of MPI.
 *
 * You should have received a copy of the License Agreement for the
 * Notre Dame LAM implementation of MPI along with the software; see
 * the file LICENSE.  If not, contact Office of Research, University
 * of Notre Dame, Notre Dame, IN 46556.
 *
 * Permission to modify the code and to distribute modified code is
 * granted, provided the text of this NOTICE is retained, a notice that
 * the code was modified is included with the above COPYRIGHT NOTICE and
 * with the COPYRIGHT NOTICE in the LICENSE file, and that the LICENSE
 * file is distributed with the modified code.
 *
 * LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED.
 * By way of example, but not limitation, Licensor MAKES NO
 * REPRESENTATIONS OR WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY
 * PARTICULAR PURPOSE OR THAT THE USE OF THE LICENSED SOFTWARE COMPONENTS
 * OR DOCUMENTATION WILL NOT INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS
 * OR OTHER RIGHTS.  
 *
 * Additional copyrights may follow.
 *
 *	Ohio Trollius
 *	Copyright 1995 The Ohio State University
 *	GDB
 *
 *	$Log: boot.h,v $
 *	Revision 6.2  1999/05/23 19:28:24  kmeyer1
 *	added copyrights
 *	
 *	Revision 6.1  1996/11/24 00:44:52  nevin
 *	Ohio Release
 *	
 * Revision 6.0  96/02/29  13:40:56  gdburns
 * Ohio Release
 * 
 * Revision 5.2.1.1  96/02/28  18:32:59  gdburns
 * Chop down to bare necessities.
 * 
 * Revision 5.2  94/08/22  13:55:20  gdburns
 * Ohio Release
 * 
 * Revision 5.1  94/05/18  10:44:54  gdburns
 * Ohio Release
 * 
 * Revision 2.3  94/04/22  12:32:24  gdburns
 * Ohio Release
 * 
 *	Function:	- constants associated with booting
 */

#ifndef _BOOT
#define _BOOT

/*
 * default search paths
 */
#ifndef DEFP
#define DEFP		"/usr/local/lam"
#endif
#ifndef DEFPSCHEMA
#define DEFPSCHEMA	"/usr/local/lam/boot"
#endif

/*
 * default configuration files
 */
#define DEFFCONFIGH	"conf.otb"

/*
 * default tools
 */
#define DEFTRESETH	"tkill"

#endif
