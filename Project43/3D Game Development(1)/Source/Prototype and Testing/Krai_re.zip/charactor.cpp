// charactor.cpp: implementation of the charactor class.
//
//////////////////////////////////////////////////////////////////////

#include "charactor.h"
#include "mrft_api.h"
#include "attack_data.h"
#define		TIME_TO_CLEAR_QUEUE									100
#define		CENTER												0
#define		UP													1
#define		UP_FORWARD											2
#define		FORWARD												3
#define		DOWN_FORWARD										4
#define		DOWN												5
#define		DOWN_BACKWARD										6
#define		BACKWARD											7
#define		UP_BACKWARD											8

#define		STAND												0
#define		WALK_FORWARD										1
#define		WALK_BACKWARD										2
#define		RUN_FORWARD											3

#define		CROUCH												10
#define		CROUCH_BACKWARD										11

#define		JUMP_CENTER											20
#define		JUMP_FORWARD										21
#define		JUMP_BACKWARD										22

#define		STAND_GUARD											30
#define		CROUCH_GUARD										31
#define		LOW_STAGGER											40
#define		HIGH_STAGGER										41
#define		FALL_STAGGER										42


#define		LOW_PUNCH											10
#define		LOW_KICK											11
#define		HIGH_PUNCH											12
#define		HIGH_KICK											13
#define		SPECIAL_ATTACK_1									50
#define		SPECIAL_ATTACK_2									51
#define		SPECIAL_ATTACK_3									52
#define		SPECIAL_ATTACK_4									53
#define		EX_SPECIAL_ATTACK_1									60
#define		EX_SPECIAL_ATTACK_2									61
#define		NOT_ATTACK											0

#define		ENEMY_WAS_ATTACKED_BY_STAND_ATTACKING				40
#define		ENEMY_WAS_ATTACKED_BY_CROUCH_ATTACKING				41
#define		ENEMY_WAS_ATTACKED_BY_JUMP_ATTACKING				42

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

charactor::charactor()
{
	
	clear_direction_queue();
	//set timer to clear queue
}

charactor::~charactor()
{

}

charactor::clear_direction_queue()
{
	for (temp_int = 0; temp_int < 39 ; temp_int++)
	{
		direction_queue[temp_int] = 0;
	}
	current_position_in_queue = 0;
	
}

charactor::update_queue(int Direction)
{
	if (current_position_in_queue = 0) 
	{
		//Update Direction Queue
		direction_queue[current_position_in_queue] = Direction;
		current_position_in_queue++;
	} 
	else if (current_position_in_queue < 39)
	{
		//Update Direction Queue
		if (direction_queue[current_position_in_queue-1] != Direction)
		{
			direction_queue[current_position_in_queue] = Direction;
			current_position_in_queue++;
		}//if direction is same as last direction not update
		else 
		{
			queue_reset_timer++;
			if (queue_reset_timer > TIME_TO_CLEAR_QUEUE) 
			{
				clear_direction_queue();
			}

		}


	} else if (current_position_in_queue >= 39)
	{
		clear_direction_queue();
		update_queue(Direction);

	}
}

charactor::initialize(int charactor_no,int texture_no)
{
	
	switch (charactor_no)
	{
	//
	case 1:
		{
			handle_charactor = Morfit_object_create_from_file(".//model//ann2.md2");

			//set characteristic
			walk_speed		= 7;
			running_speed	= 12;
			jumping_power	= 100;
			
			//assign attack data
			/*stand_low_kick_data.initialize();
			stand_low_punch_data.initialize();
			stand_high_punch_data.initialize();
			stand_high_kick_data.initialize(); 

			crouch_low_punch_data.initialize();
			crouch_high_punch_data.initialize();
			crouch_low_kick_data.initialize();
			crouch_high_kick_data.initialize(); 

			jump_low_punch_data.initialize();
			jump_high_punch_data.initialize();
			jump_low_kick_data.initialize();
			jump_high_kick_data.initialize(); 

			special_move1_data.initialize();
			special_move2_data.initialize();
			special_move3_data.initialize();
			special_move4_data.initialize(); 

			ex_special_move1_data.initialize();
			ex_special_move2_data.initialize();*/

		}
		break;
	//
	case 0:
		{
			handle_charactor = Morfit_object_create_from_file(".//model//ann.md2");
			//set characteristic
			walk_speed		= 5;
			running_speed	= 11;
			jumping_power	= 80;
			
			//assign attack data
			/*stand_low_kick_data.initialize();
			stand_low_punch_data.initialize();
			stand_high_punch_data.initialize();
			stand_high_kick_data.initialize(); 

			crouch_low_punch_data.initialize();
			crouch_high_punch_data.initialize();
			crouch_low_kick_data.initialize();
			crouch_high_kick_data.initialize(); 

			jump_low_punch_data.initialize();
			jump_high_punch_data.initialize();
			jump_low_kick_data.initialize();
			jump_high_kick_data.initialize(); 

			special_move1_data.initialize();
			special_move2_data.initialize();
			special_move3_data.initialize();
			special_move4_data.initialize(); 

			ex_special_move1_data.initialize();
			ex_special_move2_data.initialize();*/

		}
		break;
	default:
		{break;}
	}

	//get skin file name
	switch (texture_no)
	{
	//
	case 1:
		{
			handle_skin = Morfit_bitmap_load(".//skin//1.bmp",-1);
		}
		break;
	//
	case 0:
		{
			handle_skin = Morfit_bitmap_load(".//skin//0.bmp",-1);		
		}
		break;
	default:{break;}
	}
	

	
	
	
	Morfit_object_get_bounding_box(handle_charactor ,bounding_box_of_charactor );
	Morfit_object_set_bitmap(handle_charactor ,handle_skin);
	
	//Load Animation
	handle_animation = Morfit_object_get_3D_animation(handle_charactor);

	if(handle_animation == NULL) return(VR_ERROR);
	handle_animation_stand				= Morfit_3D_sequence_get_using_name(handle_animation ,"stand");
	handle_animation_crouch				= Morfit_3D_sequence_get_using_name(handle_animation ,"crouch");

	//handle_animation_run				= Morfit_3D_sequence_get_using_name(handle_animation ,"run");

	handle_animation_walk				= Morfit_3D_sequence_get_using_name(handle_animation ,"walk");
	handle_animation_side_step			= Morfit_3D_sequence_get_using_name(handle_animation ,"side_step");
	
	
	handle_animation_stand_guard		= Morfit_3D_sequence_get_using_name(handle_animation ,"sg");
	handle_animation_crouch_guard		= Morfit_3D_sequence_get_using_name(handle_animation ,"cg");

	handle_animation_crouch_low_punch	= Morfit_3D_sequence_get_using_name(handle_animation ,"clp");
	handle_animation_crouch_high_punch	= Morfit_3D_sequence_get_using_name(handle_animation ,"chp");
	handle_animation_crouch_low_kick	= Morfit_3D_sequence_get_using_name(handle_animation ,"clk");
	handle_animation_crouch_high_kick	= Morfit_3D_sequence_get_using_name(handle_animation ,"chk");
	
	handle_animation_stand_low_punch	= Morfit_3D_sequence_get_using_name(handle_animation ,"slp");
	handle_animation_stand_high_punch	= Morfit_3D_sequence_get_using_name(handle_animation ,"shp");
	handle_animation_stand_low_kick		= Morfit_3D_sequence_get_using_name(handle_animation ,"slk");
	handle_animation_stand_high_kick	= Morfit_3D_sequence_get_using_name(handle_animation ,"shk");

	/*handle_animation_jump_low_punch		= Morfit_3D_sequence_get_using_name(handle_animation ,"jlp");
	handle_animation_jump_high_punch	= Morfit_3D_sequence_get_using_name(handle_animation ,"jhp");
	handle_animation_jump_low_kick		= Morfit_3D_sequence_get_using_name(handle_animation ,"jlk");
	handle_animation_jump_high_kick		= Morfit_3D_sequence_get_using_name(handle_animation ,"jhk");

	handle_animation_ex_special_move_1	= Morfit_3D_sequence_get_using_name(handle_animation ,"ex1");
	handle_animation_ex_special_move_2	= Morfit_3D_sequence_get_using_name(handle_animation ,"ex2");

	handle_animation_special_move_1		= Morfit_3D_sequence_get_using_name(handle_animation ,"sp1");
	handle_animation_special_move_2		= Morfit_3D_sequence_get_using_name(handle_animation ,"sp2");
	handle_animation_special_move_3		= Morfit_3D_sequence_get_using_name(handle_animation ,"sp3");
	handle_animation_special_move_4		= Morfit_3D_sequence_get_using_name(handle_animation ,"sp4");*/


	if (handle_animation_stand				== NULL ||
		handle_animation_crouch				== NULL ||

		
		handle_animation_side_step			== NULL ||

		handle_animation_walk				== NULL ||
		
		
		handle_animation_stand_guard		== NULL ||
		handle_animation_crouch_guard		== NULL ||
		

		handle_animation_crouch_low_punch	== NULL ||
		handle_animation_crouch_high_punch	== NULL ||
		handle_animation_crouch_low_kick	== NULL ||
		handle_animation_crouch_high_kick	== NULL ||

		handle_animation_stand_low_punch	== NULL ||
		handle_animation_stand_high_punch	== NULL ||
		handle_animation_stand_low_kick		== NULL ||
		handle_animation_stand_high_kick	== NULL 
		//||

		//handle_animation_jump_low_punch		== NULL ||	
		//handle_animation_jump_high_punch	== NULL ||
		//handle_animation_jump_low_kick		== NULL ||
		//handle_animation_jump				== NULL ||
		//handle_animation_run				== NULL ||
		//handle_animation_jump_high_kick		== NULL 
		)	return(VR_ERROR);

	//initial start value
	current_in_action = STAND;
	current_is_attack = NOT_ATTACK;
//set scale
	double scale[3] = {0.5,0.5,0.5};
	Morfit_object_set_scale(handle_charactor,scale);
//calculate the player height
	
	Morfit_object_get_bounding_box(handle_charactor,bounding_box_of_charactor);
	hight = bounding_box_of_charactor[1][2]-bounding_box_of_charactor[0][2];
	Morfit_object_move(handle_charactor,OBJECT_SPACE,0,0,hight/2+20);
	Morfit_object_get_location(handle_charactor,&location[0],&location[1],&location[2]);
}

charactor::process_input()
{

	// if any direction key pressed let's update direction_queue
	if (left_key_pressed || right_key_pressed || up_key_pressed || down_key_pressed)
	{
		//if left key was pressed only
		if (left_key_pressed || (!right_key_pressed) || (!up_key_pressed) || (!down_key_pressed))
		{
			//at left side pressed left mean Backward
			if (at_left) update_queue(BACKWARD);
			//at Right side pressed left mean Forward
			else update_queue(FORWARD);
		}

		//if right key was pressed only
		if (!(left_key_pressed) || right_key_pressed || (!up_key_pressed) || (!down_key_pressed))
		{
			//at left side pressed right mean Forward
			if (at_left) update_queue(FORWARD);
			//at right side pressed right mean Backward
			else update_queue(BACKWARD);
		}

		//if up key was pressed only
		if (!(left_key_pressed) || (!right_key_pressed) || up_key_pressed || (!down_key_pressed))
		{
			//Up
			update_queue(UP);
		}

		//if down key was pressed only
		if (!(left_key_pressed) || (!right_key_pressed) || (!up_key_pressed) || down_key_pressed)
		{
			//Down
			update_queue(DOWN);
		}

		//if left-down key was pressed
		if (left_key_pressed || (!right_key_pressed) || (!up_key_pressed) || down_key_pressed)
		{
			//at left side pressed left-down mean Down-Backward
			if (at_left) update_queue(DOWN_BACKWARD);
			//at right side pressed left-down mean Down-Forward
			else update_queue(DOWN_FORWARD);
		}

		//if right-down key was pressed
		if (!(left_key_pressed) || right_key_pressed || (!up_key_pressed) || down_key_pressed)
		{
			//at left side pressed right-down mean Down-Forward
			if (at_left) update_queue(DOWN_FORWARD);
			//at right side pressed right-down mean Down-Backward
			else update_queue(DOWN_BACKWARD);


		}

		//if left-up key was pressed
		if (left_key_pressed || (!right_key_pressed) || up_key_pressed || (!down_key_pressed))
		{
			//at left side pressed left-up mean Up-Backward
			if (at_left) update_queue(UP_BACKWARD);
			//at right side pressed left-up mean Up-Forward
			else update_queue(UP_FORWARD);

		}

		//if right-up key was pressed
		if (!(left_key_pressed) || (!right_key_pressed) || (!up_key_pressed) || (!down_key_pressed))
		{
			//at left side pressed right-up mean Up-Forward
			if (at_left) update_queue(UP_FORWARD);
			//at right side pressed right-up mean Up-Backward
			else update_queue(UP_BACKWARD);

		}


	} 
	//if all direction key is not pressed
	else
	{
		//all direction key is not pressed mean Center
		update_queue(CENTER);
	}
	change_animation();
}

charactor::change_animation()
{
	//get current animation
	if (current_in_action == STAND)
	{
		Morfit_object_replace_3D_sequence_when_finished (handle_charactor,handle_animation_stand , 0);
		current_is_attack = NOT_ATTACK;

	}

	if ((current_in_action == CROUCH) || (current_in_action == CROUCH_BACKWARD))
	{
		Morfit_object_replace_3D_sequence_when_finished (handle_charactor,handle_animation_crouch , 0);
		current_is_attack = NOT_ATTACK;

	}

	if (current_in_action < JUMP_CENTER)
	{
		switch (direction_queue[current_position_in_queue])
		{
			case UP_BACKWARD:
			case BACKWARD:
				{
					current_in_action = WALK_BACKWARD;
					break;
				}
			case DOWN_BACKWARD:
				{
					current_in_action = CROUCH_BACKWARD;
					break;
				}
			case DOWN:
				{
					current_in_action = CROUCH;
					break;
				}
			case DOWN_FORWARD:
				{
					current_in_action = CROUCH;
					break;
				}
			case FORWARD:
				{
					current_in_action = WALK_FORWARD;
					break;
				}
			case UP_FORWARD:
			case UP:
			case CENTER:
				{
					current_in_action = STAND;
					break;
				}
			default:
				{
					current_in_action = STAND;
					break;
				}

		}


	}


	
	if (!(	low_punch_pressed	||
			high_punch_pressed	||
			low_kick_pressed	||
			high_kick_pressed) && (current_is_attack == NOT_ATTACK) && (current_in_action < JUMP_CENTER))
	{
		//if press forward forward change animation to run
		if ((direction_queue[current_position_in_queue-2]	  == FORWARD)	&&
			(direction_queue[current_position_in_queue-1] == CENTER) &&
			(direction_queue[current_position_in_queue] == FORWARD) &&
			(current_position_in_queue >=2)		) 
		{
			if ((current_in_action == STAND)	||
				(current_in_action == WALK_FORWARD))
			{
				/*current_in_action = RUN_FORWARD;
				/Morfit_object_set_3D_sequence(handle_charactor,	handle_animation_run,0);*/
			}

		}
		//if not press forward forward change animation by using current_position_in_queue
		else if (current_in_action < JUMP_CENTER)
		{
			switch(direction_queue[current_position_in_queue])
			{
				case UP_BACKWARD:
					{	
						current_in_action = JUMP_BACKWARD;
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump,0);
						break;
					}
				case BACKWARD:
					{
						if (current_in_action != WALK_BACKWARD)
						{
							current_in_action = WALK_BACKWARD;
							Morfit_object_set_3D_sequence(handle_charactor,handle_animation_walk,0);
							Morfit_3D_sequence_backwards_play(handle_animation_walk,YES);
						}	
						break;
					}

				case DOWN_BACKWARD:
					{
						if (current_in_action != CROUCH_BACKWARD)
						{
							current_in_action = CROUCH_BACKWARD;
							Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch,0);
						}	
						break;
					}
				case DOWN:
					{
						if (current_in_action != CROUCH)
						{
							current_in_action = CROUCH;
							Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch,0);
						}	
						break;
					}

				case DOWN_FORWARD:
					{
						if (current_in_action != CROUCH)
						{
							current_in_action = CROUCH;
							Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch,0);
						}	
						break;
					}
				
				case FORWARD:
					{
						if (current_in_action != WALK_FORWARD)
						{
							current_in_action = WALK_FORWARD;
							Morfit_object_set_3D_sequence(handle_charactor,handle_animation_walk,0);
							Morfit_3D_sequence_backwards_play(handle_animation_walk,NO);
						}	
						break;
					}
				
				case UP_FORWARD:
					{	
						current_in_action = JUMP_FORWARD;
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump,0);
						break;
					}

				case UP:
					{	
						current_in_action = JUMP_CENTER;
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump,0);
						break;
					}
				
				case CENTER:
					{
						if (current_in_action != STAND)
						{
							current_in_action = STAND;
							Morfit_object_set_3D_sequence(handle_charactor,handle_animation_stand,0);
						}	
						break;
					}
				default:
					{	
						break;
					}
				
			}
		}
	}
	//if attack key was press check direction in queue first. 
	//check for EX-Special attack first
	else if (current_in_action  < JUMP_CENTER)
	{
		if (	(direction_queue[current_position_in_queue-5]	   == DOWN) &&
				(direction_queue[current_position_in_queue-4]	   == DOWN_FORWARD) &&
				(direction_queue[current_position_in_queue-3]	   == FORWARD) &&
				(direction_queue[current_position_in_queue-2]	   == DOWN) &&
				(direction_queue[current_position_in_queue-1]	   == DOWN_FORWARD) &&
				(direction_queue[current_position_in_queue]			== FORWARD) &&
				(current_position_in_queue >=5)		&&  (current_is_attack < EX_SPECIAL_ATTACK_1))
			{
				if (ex_special_move1_data.kick_or_punch && (high_kick_pressed || low_kick_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_ex_special_move_1,0);
					current_is_attack = EX_SPECIAL_ATTACK_1;
					current_in_action = STAND;
				}	else if ((!ex_special_move1_data.kick_or_punch) && (high_punch_pressed || low_punch_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_ex_special_move_1,0);
					current_is_attack = EX_SPECIAL_ATTACK_1;
					current_in_action = STAND;
				} else	current_in_action = WALK_FORWARD;
			}
		else	if (	(direction_queue[current_position_in_queue-5]	   == DOWN) &&
				(direction_queue[current_position_in_queue-4]	   == DOWN_BACKWARD) &&
				(direction_queue[current_position_in_queue-3]	   == BACKWARD) &&
				(direction_queue[current_position_in_queue-2]	   == DOWN) &&
				(direction_queue[current_position_in_queue-1]	   == DOWN_BACKWARD) &&
				(direction_queue[current_position_in_queue]			== BACKWARD) &&
				(current_position_in_queue >=5)			&&  (current_is_attack < EX_SPECIAL_ATTACK_1))
			{
				if (ex_special_move2_data.kick_or_punch && (high_kick_pressed || low_kick_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_ex_special_move_2,0);
					current_is_attack = EX_SPECIAL_ATTACK_2;
					current_in_action = STAND;
				}	else if ((!ex_special_move2_data.kick_or_punch) && (high_punch_pressed || low_punch_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_ex_special_move_2,0);
					current_is_attack = EX_SPECIAL_ATTACK_2;
					current_in_action = STAND;
				} else	current_in_action = WALK_BACKWARD;
			}
	} //if not EX-Special then check for special attack
	else if (current_in_action < JUMP_CENTER)
		{
		//press Direction Down,Down-Forward,Forward
		if (	(direction_queue[current_position_in_queue-2]	   == DOWN) &&
				(direction_queue[current_position_in_queue-1]	   == DOWN_FORWARD) &&
				(direction_queue[current_position_in_queue]			== FORWARD) &&
				(current_position_in_queue >=2)		&&  (current_is_attack < SPECIAL_ATTACK_1))
			{
				if (special_move1_data.kick_or_punch && (high_kick_pressed || low_kick_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_1,0);
					current_is_attack = SPECIAL_ATTACK_1;
					current_in_action = STAND;

				}	else if ((!special_move1_data.kick_or_punch) && (high_punch_pressed || low_punch_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_1,0);
					current_is_attack = SPECIAL_ATTACK_1;
					current_in_action = STAND;
				} else	current_in_action = WALK_FORWARD;
			}

	//press Direction Down, Down-Backward, Backward
	else if (	(direction_queue[current_position_in_queue-2]	 == DOWN) &&
				(direction_queue[current_position_in_queue-1]		== DOWN_BACKWARD) &&
				(direction_queue[current_position_in_queue]			  == BACKWARD) &&
				(current_position_in_queue >=2)		&&  (current_is_attack < SPECIAL_ATTACK_1))
			{
				if (special_move2_data.kick_or_punch && (high_kick_pressed || low_kick_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_2,0);
					current_is_attack = SPECIAL_ATTACK_2;
					current_in_action = STAND;
				}	else if ((!special_move2_data.kick_or_punch) && (high_punch_pressed || low_punch_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_2,0);
					current_is_attack = SPECIAL_ATTACK_2;
					current_in_action = STAND;
				} else	current_in_action = WALK_BACKWARD;
			}

	//press Direction Down,Down
	else if (	(direction_queue[current_position_in_queue-2]	== DOWN) &&
				(direction_queue[current_position_in_queue-1]	== CENTER) &&
				(direction_queue[current_position_in_queue]		== DOWN) &&
				(current_position_in_queue >=2)		&&  (current_is_attack < SPECIAL_ATTACK_1))
			{
				if (special_move3_data.kick_or_punch && (high_kick_pressed || low_kick_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_3,0);
					current_is_attack = SPECIAL_ATTACK_3;
					current_in_action = STAND;
				}	else if ((!special_move3_data.kick_or_punch) && (high_punch_pressed || low_punch_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_3,0);
					current_is_attack = SPECIAL_ATTACK_3;
					current_in_action = STAND;
				} else	current_in_action = CROUCH;
			}
	//press Direction Back, Forward
	else if (	(direction_queue[current_position_in_queue-2]	== BACKWARD) &&
				(direction_queue[current_position_in_queue-1]	== CENTER) &&
				(direction_queue[current_position_in_queue]		== FORWARD) &&
				(current_position_in_queue >=2)		&&  (current_is_attack < SPECIAL_ATTACK_1))
			{
				if (special_move4_data.kick_or_punch && (high_kick_pressed || low_kick_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_4,0);
					current_is_attack = SPECIAL_ATTACK_4;
					current_in_action = STAND;
				}	else if ((!special_move4_data.kick_or_punch) && (high_punch_pressed || low_punch_pressed ))
				{
					Morfit_object_set_3D_sequence(handle_charactor,handle_animation_special_move_4,0);
					current_is_attack = SPECIAL_ATTACK_4;
					current_in_action = STAND;
				} else	current_in_action = WALK_FORWARD;
			}
	}//if not Special and EX-Special Attack, Let attack normally
	else if ((current_is_attack < LOW_PUNCH) && (current_in_action != STAND_GUARD) || (current_in_action != CROUCH_GUARD))
	{
		switch (current_in_action)
		{
		case STAND:
		case WALK_FORWARD:
		case WALK_BACKWARD:
			{
				//user intend to puch low
				if (low_punch_pressed && !low_kick_pressed && !high_kick_pressed) 
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_stand_low_punch,0);
						current_is_attack = LOW_PUNCH;
						current_in_action = STAND;

				}
				//user intend to puch high
				if (!low_punch_pressed && high_punch_pressed && !low_kick_pressed && !high_kick_pressed)
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_stand_high_punch,0);
						current_is_attack = HIGH_PUNCH;
						current_in_action = STAND;
				}

				//user intend to kick low
				if (low_kick_pressed && !low_punch_pressed && !high_punch_pressed) 
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_stand_low_kick,0);
						current_is_attack = LOW_KICK;
						current_in_action = STAND;
				}
				//user intend to kick high
				if (!low_kick_pressed && high_kick_pressed && !low_punch_pressed && !high_punch_pressed)
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_stand_high_kick,0);
						current_is_attack = HIGH_KICK;
						current_in_action = STAND;
				}
				break;
			}
		case CROUCH:
		case CROUCH_BACKWARD:
			{
				//user intend to puch low
				if (low_punch_pressed && !low_kick_pressed && !high_kick_pressed) 
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch_low_punch,0);
						current_is_attack = LOW_PUNCH;
						current_in_action = CROUCH;
				}
				//user intend to puch high
				if (!low_punch_pressed && high_punch_pressed && !low_kick_pressed && !high_kick_pressed)
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch_high_punch,0);
						current_is_attack = HIGH_PUNCH;
						current_in_action = CROUCH;
				}

				//user intend to kick low
				if (low_kick_pressed && !low_punch_pressed && !high_punch_pressed) 
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch_low_kick,0);
						current_is_attack = LOW_KICK;
						current_in_action = CROUCH;
				}
				//user intend to kick high
				if (!low_kick_pressed && high_kick_pressed && !low_punch_pressed && !high_punch_pressed)
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_crouch_high_kick,0);
						current_is_attack = HIGH_KICK;
						current_in_action = CROUCH;
				}
				break;
			}
		case JUMP_CENTER:
		case JUMP_FORWARD:
		case JUMP_BACKWARD:
			{
				//user intend to puch low
				if (low_punch_pressed && !low_kick_pressed && !high_kick_pressed) 
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump_low_punch,0);
						current_is_attack = LOW_PUNCH;
				}
				//user intend to puch high
				if (!low_punch_pressed && high_punch_pressed && !low_kick_pressed && !high_kick_pressed)
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump_high_punch,0);
						current_is_attack = HIGH_PUNCH;
				}

				//user intend to kick low
				if (low_kick_pressed && !low_punch_pressed && !high_punch_pressed) 
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump_low_kick,0);
						current_is_attack = LOW_KICK;
				}
				//user intend to kick high
				if (!low_kick_pressed && high_kick_pressed && !low_punch_pressed && !high_punch_pressed)
				{
						Morfit_object_set_3D_sequence(handle_charactor,handle_animation_jump_high_kick,0);
						current_is_attack = HIGH_KICK;
				}
				break;
			}
		default:
			break;
		}
	}

}



charactor::move(double enemy_location[])
{
	
	//set vector of player point at enemy
	direction[0] = enemy_location[0] - location[0];
	direction[1] = enemy_location[1] - location[1];
	direction[2] = enemy_location[2] - location[2];
	Morfit_object_set_direction(handle_charactor,direction[0],direction[1],direction[2]);
	
	switch(current_in_action)
	{
	case STAND:
		  {
				break;
		  }
	case WALK_FORWARD:
		  {
				//walk forward
				Morfit_object_move(handle_charactor,OBJECT_SPACE,-walk_speed*1.2,0,0);
				break;
		  }
	case WALK_BACKWARD:
		  {
				//walk backward
				Morfit_object_move(handle_charactor,OBJECT_SPACE,walk_speed*1.2,0,0);
				break;
		  }
	case RUN_FORWARD:
		  {
				//run forward
				Morfit_object_move(handle_charactor,OBJECT_SPACE,-running_speed*1.2,0,0);
				break;
		  }
	case CROUCH:
		  {
				break;
		  }
	case CROUCH_BACKWARD:
		  {
				break;
		  }
	case JUMP_CENTER:
		  {
				break;
		  }
	case JUMP_FORWARD:
		  {
				break;
		  }
	case JUMP_BACKWARD:
		  {
				break;
		  }
	default:
		  {
				break;
		  }
	}

	//Update Location
	update_location();
}

charactor::update_location()
{
	Morfit_object_get_location(handle_charactor,&location[0],&location[1],&location[2]);
}
