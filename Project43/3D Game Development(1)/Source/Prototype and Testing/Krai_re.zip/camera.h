// camera.h: interface for the camera class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAMERA_H__64DC8C62_10B8_11D5_BDF2_00E029663C62__INCLUDED_)
#define AFX_CAMERA_H__64DC8C62_10B8_11D5_BDF2_00E029663C62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "mrft_api.h"

class camera  
{
public:
	bool first_charactor_is_at_left(double first_charactor_location[], double second_charactor_location[]);
	double camera_space_player2_location[3];
	double camera_space_player1_location[3];
	camera();
	virtual ~camera();
	initialize(double distance_from_player_factor);
	set_location_and_direction(double location_of_left_player[3],double location_of_right_player[3]);
	double distance_from_O_point_factor;
	DWORD handle;

private:

	double abs_of_Vector_P1P2,abs_of_Vector_CO,abs_of_Vector_DP1;
	double 	O_point[3],
		unit_vector_DP1[3],
		camera_position[3];


};

#endif // !defined(AFX_CAMERA_H__64DC8C62_10B8_11D5_BDF2_00E029663C62__INCLUDED_)
