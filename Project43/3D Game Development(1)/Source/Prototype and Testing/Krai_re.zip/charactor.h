// charactor.h: interface for the charactor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHARACTOR_H__64DC8C61_10B8_11D5_BDF2_00E029663C62__INCLUDED_)
#define AFX_CHARACTOR_H__64DC8C61_10B8_11D5_BDF2_00E029663C62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "mrft_api.h"
#include "attack_data.h"

class charactor  
{
public:
	update_location();
	double location[3];
	move(double enemy_location[3]);
	//direction key down 
	bool	up_key_pressed,
			down_key_pressed,
			left_key_pressed,
			right_key_pressed;
	//position reference by camera
	bool	at_left;
	//attacked key down
	bool	low_punch_pressed,
			high_punch_pressed,
			low_kick_pressed,
			high_kick_pressed;
	int charactor_no,skin_no;	
	charactor();
	virtual ~charactor();
	initialize(int charactor_no,int texture_no);

	process_input();
	clear_direction_queue();
	

	double bounding_box_of_charactor[2][3];
	double hight;
	DWORD handle_charactor;

private:
	double direction[3];
	int direction_queue[40];
	int queue_reset_timer;
	int temp_int;
	int current_position_in_queue;

	int walk_speed,
		running_speed,
		jumping_power,
		current_in_action,
		current_is_attack,
		attacking_flag;

	DWORD handle_skin;

	DWORD handle_animation,
		
		handle_animation_stand,
		handle_animation_crouch,

		handle_animation_run,
		handle_animation_jump,
		
		handle_animation_walk,
		handle_animation_side_step,
		
		handle_animation_stand_guard,
		handle_animation_crouch_guard,

		handle_animation_stand_low_punch,
		handle_animation_stand_high_punch,
		handle_animation_stand_low_kick,
		handle_animation_stand_high_kick,
		handle_animation_crouch_low_punch,
		handle_animation_crouch_high_punch,
		handle_animation_crouch_low_kick,
		handle_animation_crouch_high_kick,
		handle_animation_jump_low_punch,
		handle_animation_jump_high_punch,
		handle_animation_jump_low_kick,
		handle_animation_jump_high_kick,
		
		handle_animation_special_move_1,
		handle_animation_special_move_2,
		handle_animation_special_move_3,
		handle_animation_special_move_4,
		
		handle_animation_ex_special_move_1,
		handle_animation_ex_special_move_2;

		attack_data		stand_low_punch_data,
					stand_high_punch_data,
					stand_low_kick_data,
					stand_high_kick_data,

					crouch_low_punch_data,
					crouch_high_punch_data,
					crouch_low_kick_data,
					crouch_high_kick_data,

					jump_low_punch_data,
					jump_high_punch_data,
					jump_low_kick_data,
					jump_high_kick_data,

					special_move1_data,
					special_move2_data,
					special_move3_data,
					special_move4_data,

					ex_special_move1_data,
					ex_special_move2_data;
	
		update_queue(int);
		change_animation();
};

#endif // !defined(AFX_CHARACTOR_H__64DC8C61_10B8_11D5_BDF2_00E029663C62__INCLUDED_)
