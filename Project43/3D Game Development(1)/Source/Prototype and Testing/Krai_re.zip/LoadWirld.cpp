#include "resource.h"
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <basetsd.h>
#include <dinput.h>
#include "camera.h"
#include "charactor.h"



#include "mrft_api.h"


HBITMAP Status_bar;
camera g_camera;
charactor player1,player2;
int CameraSpeed = 6 ;
DWORD light;

//Define, constant and Global variables

#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

LPDIRECTINPUT8       g_pDI              = NULL;         
LPDIRECTINPUTDEVICE8 g_pJoystick        = NULL;     
DIDEVCAPS            g_diDevCaps;



//Function-Prototypes
//

VOID FreeDirectInput();
HRESULT UpdateInputState( HWND hDlg );
BOOL CALLBACK EnumAxesCallback( const DIDEVICEOBJECTINSTANCE* pdidoi,VOID* pContext);
BOOL CALLBACK EnumJoysticksCallback( const DIDEVICEINSTANCE* pdidInstance,VOID* pContext);
HRESULT InitDirectInput(HWND hDlg);
LRESULT CALLBACK WindowFunc (HWND hwnd, UINT message,WPARAM wParam, LPARAM lParam);
int Init_character(void);
VOID write_text_and_draw(HDC dc_handle, HBITMAP hbm);

//Program code


   	char szWinName[] = "�� Project";
    

   int WINAPI WinMain (HINSTANCE hThisInst,
   					   HINSTANCE hPrevInst,
                       LPSTR lpszArgs,
                       int nWinMode)
   {
   	  HWND hwnd;
      MSG msg;
      WNDCLASS wcl;
      HACCEL hAccel;
//Initialization
//
      wcl.hInstance = hThisInst;
      wcl.lpszClassName = szWinName;
      wcl.lpfnWndProc = WindowFunc;
      wcl.style = 0;

      //wcl.hIcon = LoadIcon(hThisInst,MAKEINTRESOURCE(IDM_MENU));

      wcl.hCursor = LoadCursor(NULL,IDC_ARROW);
      //wcl.lpszMenuName = MAKEINTRESOURCE(IDM_MENU);

      wcl.cbClsExtra = 0;
      wcl.cbWndExtra = 0;

      wcl.hbrBackground = (HBRUSH)GetStockObject (WHITE_BRUSH);

      if( !RegisterClass(&wcl) )
      	return 0;

      /*hwnd = CreateWindow (szWinName,"�� ",
      	WS_OVERLAPPEDWINDOW,
         CW_USEDEFAULT,
         CW_USEDEFAULT,
         CW_USEDEFAULT,
         CW_USEDEFAULT,
         HWND_DESKTOP,
         NULL,
         hThisInst,
         NULL);*/
	 

      hAccel = LoadAccelerators(hThisInst,MAKEINTRESOURCE(IDM_MENU));

	//Loads World into the engine
	  if(OK != Morfit_engine_load_world("b_arena.wld",
							 "..\\World",
							 "..\\World\\bitmaps",
							 USER_DEFINED_BEHAVIOR))
				return -1;
	  
	  g_camera.initialize(0.5);
	  //Morfit_3D_card_use_detailed(CARD3D_NORMAL,YES,800,600,16,NO);
	  hwnd = Morfit_engine_get_default_rendering_window_hwnd();
	  Morfit_engine_set_picture_quality(0);
//Load bitmap
	  Status_bar=Morfit_utilities_load_bitmap_from_file("Power_Guage.bmp");
//Init Player
	  if(Init_character() == VR_ERROR)
		  return -1;

	  Morfit_engine_set_atmospheric_effect(0,0,0); //set the background to black
	  ShowCursor(FALSE);

//Init DirectInput
//
		if( FAILED( InitDirectInput( hwnd ) ) )
            {
                MessageBox( NULL, "Error Initializing DirectInput", 
                            "DirectInput Sample", MB_ICONERROR | MB_OK );
				return -1;
            }
// Set a timer to go off 30 times a second. At every timer message
// the input device will be read
        // SetTimer( hwnd, 0, 1000 / 30, NULL );



		ShowWindow (hwnd, nWinMode);
		UpdateWindow (hwnd);

		while (GetAsyncKeyState(VK_ESCAPE) == 0) 
		{
			
			Morfit_light_activate(light, LIGHT_SET);	

			HDC dc_handle = Morfit_engine_render_on_dc(NULL,g_camera.handle);
			write_text_and_draw(dc_handle,Status_bar);
			Morfit_engine_copy_image_from_dc_to_screen();

			UpdateInputState( hwnd );

		}
			
			FreeDirectInput();
			Morfit_engine_close();
			PostQuitMessage (0);




	 
		InvalidateRect(hwnd,NULL,false);

				
	
		while ( GetMessage (&msg, NULL, 0, 0) )

		{
         	if(!TranslateAccelerator(hwnd,hAccel,&msg))
	     	{
   	      		TranslateMessage (&msg);
	   			DispatchMessage (&msg);
			}
		}

		return msg.wParam;
	
	}


   LRESULT CALLBACK WindowFunc (HWND hwnd, UINT message,
   									  WPARAM wParam, LPARAM lParam)

   {
     
    	switch ( message )
      {
        
       	case WM_DESTROY:
			
            FreeDirectInput();   
			Morfit_engine_close();
         	PostQuitMessage (0);
         break;
         default:
         	return DefWindowProc (hwnd, message, wParam, lParam);
      }
      return 0;

   }

int Init_character()
{
	
	player1.initialize(0,0);
	Morfit_object_set_location(player1.handle_charactor,300,0,player1.hight/2+20);
	player2.initialize(1,0);
	Morfit_object_set_location(player2.handle_charactor,-300,0,player2.hight/2+20);

	player1.at_left=true;
	player2.at_left=false;

	player1.up_key_pressed = false;
	player1.down_key_pressed = false;				
	player1.right_key_pressed = false;
	player1.left_key_pressed = false;

	player2.up_key_pressed = false;
	player2.down_key_pressed = false;				
	player2.right_key_pressed = false;
	player2.left_key_pressed = false;

	player1.update_location();
	player2.update_location();


////Load player
//	gl_player = Morfit_object_create_from_file("..\\Player\\annt.md2");
//	if(gl_player == NULL) return (VR_ERROR);
////set scale
//	double scale[3] = {0.5,0.5,0.5};
//	Morfit_object_set_scale(gl_player,scale);
////set skin
//	gl_skin = Morfit_bitmap_load("..\\Player\\Anntex.bmp",-1);
//	Morfit_object_set_bitmap(gl_player,gl_skin);
////calculate the player height
//	double box[2][3];
//	Morfit_object_get_bounding_box(gl_player,box);
//	gl_player_height = box[1][2] - box[0][2];

/*	double center[3];
	center[0]=0.5*(box[0][0]+box[1][0]);
	center[1]=0.5*(box[0][1]+box[1][1]);
	center[2]=0.5*(box[0][2]+box[1][2]);

	double distance=1.5*(box[1][2]-box[0][2]);// must be  ==1.5*10
	double c_location[3];
	c_location[0]=center[0]+distance;
	c_location[1]=center[1];
	c_location[2]=center[2];*/

	double c_location[3];
	c_location[0]=-120.51;
	c_location[1]=-51.25;
	c_location[2]=400.57;
	
	light=Morfit_light_create("my_light",c_location);
	 Morfit_light_set_entity_to_light(light, NULL);

////get animation sequence
//	DWORD anim3d = Morfit_object_get_3D_animation(gl_player);

//	sq_stand_idle = Morfit_3D_sequence_get_using_name(anim3d,"stand_idle");
//	sq_sidestep = Morfit_3D_sequence_get_using_name(anim3d,"side_step");
//	sq_walk = Morfit_3D_sequence_get_using_name(anim3d,"walk");
//	if(sq_stand_idle == NULL || sq_sidestep == NULL || sq_walk == NULL ) return (VR_ERROR);
	

	return(OK);
}

VOID write_text_and_draw(HDC dc_handle, HBITMAP hbm)
{
	Morfit_utilities_copy_bitmap_on_dc(dc_handle, hbm, 0, 0, -1,-1);
}

//-----------------------------------------------------------------------------
// Name: InitDirectInput()
// Desc: Initialize the DirectInput variables.
//-----------------------------------------------------------------------------
HRESULT InitDirectInput(HWND hDlg)
{
	HRESULT hr;

    // Register with the DirectInput subsystem and get a pointer
    // to a IDirectInput interface we can use.
    // Create a DInput object
    if( FAILED( hr = DirectInput8Create( GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
                                         IID_IDirectInput8, (VOID**)&g_pDI, NULL ) ) )
        return hr;

    // Look for a simple joystick we can use for this sample program.
    if( FAILED( hr = g_pDI->EnumDevices( DI8DEVCLASS_GAMECTRL, 
                                         EnumJoysticksCallback,
                                         NULL, DIEDFL_ATTACHEDONLY ) ) )
        return hr;

    // Make sure we got a joystick
    if( NULL == g_pJoystick )
    {
        MessageBox( NULL, "Joystick not found. The sample will now exit.", 
                    "DirectInput Sample", 
                    MB_ICONERROR | MB_OK );
        Morfit_engine_close();
		PostQuitMessage(0);
        return S_OK;
    }

    // Set the data format to "simple joystick" - a predefined data format 
    //
    // A data format specifies which controls on a device we are interested in,
    // and how they should be reported. This tells DInput that we will be
    // passing a DIJOYSTATE2 structure to IDirectInputDevice::GetDeviceState().
    if( FAILED( hr = g_pJoystick->SetDataFormat( &c_dfDIJoystick2 ) ) )
        return hr;

    // Set the cooperative level to let DInput know how this device should
    // interact with the system and with other DInput applications.
    if( FAILED( hr = g_pJoystick->SetCooperativeLevel( hDlg, DISCL_EXCLUSIVE | 
                                                             DISCL_FOREGROUND ) ) )
        return hr;

    // Determine how many axis the joystick has (so we don't error out setting
    // properties for unavailable axis)
    g_diDevCaps.dwSize = sizeof(DIDEVCAPS);
    if ( FAILED( hr = g_pJoystick->GetCapabilities(&g_diDevCaps) ) )
        return hr;

    // Enumerate the axes of the joyctick and set the range of each axis. Note:
    // we could just use the defaults, but we're just trying to show an example
    // of enumerating device objects (axes, buttons, etc.).
    if ( FAILED( hr = g_pJoystick->EnumObjects( EnumAxesCallback, 
                                                (VOID*)hDlg, DIDFT_AXIS ) ) )
        return hr;

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: EnumJoysticksCallback()
// Desc: Called once for each enumerated joystick. If we find one, create a
//       device interface on it so we can play with it.
//-----------------------------------------------------------------------------
BOOL CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE *pdidInstance, VOID *pContext)
{
	HRESULT hr;

    // Obtain an interface to the enumerated joystick.
    hr = g_pDI->CreateDevice( pdidInstance->guidInstance, &g_pJoystick, NULL );

    // If it failed, then we can't use this joystick. (Maybe the user unplugged
    // it while we were in the middle of enumerating it.)
    if( FAILED(hr) ) 
        return DIENUM_CONTINUE;

    // Stop enumeration. Note: we're just taking the first joystick we get. You
    // could store all the enumerated joysticks and let the user pick.
    return DIENUM_STOP;
}

//-----------------------------------------------------------------------------
// Name: EnumAxesCallback()
// Desc: Callback function for enumerating the axes on a joystick
//-----------------------------------------------------------------------------
BOOL CALLBACK EnumAxesCallback(const DIDEVICEOBJECTINSTANCE *pdidoi, VOID *pContext)
{
	HWND hDlg = (HWND)pContext;

    DIPROPRANGE diprg; 
    diprg.diph.dwSize       = sizeof(DIPROPRANGE); 
    diprg.diph.dwHeaderSize = sizeof(DIPROPHEADER); 
    diprg.diph.dwHow        = DIPH_BYID; 
    diprg.diph.dwObj        = pdidoi->dwType; // Specify the enumerated axis
    diprg.lMin              = -1000; 
    diprg.lMax              = +1000; 
    
	// Set the range for the axis
	if( FAILED( g_pJoystick->SetProperty( DIPROP_RANGE, &diprg.diph ) ) )
		return DIENUM_STOP;

    // Set the UI to reflect what axes the joystick supports
	if (pdidoi->guidType == GUID_XAxis)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_X_AXIS ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_X_AXIS_TEXT ), TRUE );
	}
	if (pdidoi->guidType == GUID_YAxis)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_Y_AXIS ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_Y_AXIS_TEXT ), TRUE );
	}
	if (pdidoi->guidType == GUID_ZAxis)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_Z_AXIS ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_Z_AXIS_TEXT ), TRUE );
	}
	if (pdidoi->guidType == GUID_RxAxis)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_X_ROT ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_X_ROT_TEXT ), TRUE );
	}
	if (pdidoi->guidType == GUID_RyAxis)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_Y_ROT ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_Y_ROT_TEXT ), TRUE );
	}
	if (pdidoi->guidType == GUID_RzAxis)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_Z_ROT ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_Z_ROT_TEXT ), TRUE );
	}
	if (pdidoi->guidType == GUID_Slider)
	{
        EnableWindow( GetDlgItem( hDlg, IDC_SLIDER0 ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_SLIDER0_TEXT ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_SLIDER1 ), TRUE );
        EnableWindow( GetDlgItem( hDlg, IDC_SLIDER1_TEXT ), TRUE );
    }

    return DIENUM_CONTINUE;
}

//-----------------------------------------------------------------------------
// Name: UpdateInputState()
// Desc: Get the input device's state and display it.
//-----------------------------------------------------------------------------
HRESULT UpdateInputState(HWND hDlg)
{
	HRESULT     hr;   
    DIJOYSTATE2 js;           // DInput joystick state 

	double save_location[3];
	//Save the locationin case we will want to go back
//	Morfit_object_get_location(gl_player,&save_location[0],&save_location[1],&save_location[2]);

    if( NULL == g_pJoystick ) 
        return S_OK;

    // Poll the device to read the current state
    hr = g_pJoystick->Poll(); 
    if( FAILED(hr) )  
    {
        // DInput is telling us that the input stream has been
        // interrupted. We aren't tracking any state between polls, so
        // we don't have any special reset that needs to be done. We
        // just re-acquire and try again.
        hr = g_pJoystick->Acquire();
        while( hr == DIERR_INPUTLOST ) 
            hr = g_pJoystick->Acquire();

        // hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
        // may occur when the app is minimized or in the process of 
        // switching, so just try again later 
        return S_OK; 
    }

    // Get the input's device state
    if( FAILED( hr = g_pJoystick->GetDeviceState( sizeof(DIJOYSTATE2), &js ) ) )
        return hr; // The device should have been acquired during the Poll()

	if (js.lX && 0x80 || js.lY && 0x80)
	{
		if(js.lX && 0x80)	   
		{
			//Morfit_object_move(gl_player,OBJECT_SPACE ,0 ,0.010*js.lX, 0);
			//Morfit_object_set_3D_sequence(gl_player,sq_walk,0);
			if (js.lX > 0)
			{
				player1.right_key_pressed = true;
				player1.left_key_pressed = false;
				
				//Morfit_3D_sequence_backwards_play(sq_walk,YES);
			}
			else
			{
				player1.right_key_pressed = false;
				player1.left_key_pressed = true;

				//Morfit_3D_sequence_backwards_play(sq_walk,NO);
			}
		}
		if(js.lY && 0x80)
		{
			//Morfit_object_move(gl_player, OBJECT_SPACE, js.lY*0.010 ,0, 0);
			//Morfit_object_set_3D_sequence(gl_player,sq_sidestep,0);
			if (js.lY > 0)
			{
				player1.up_key_pressed = false;
				player1.down_key_pressed = true;
				//Morfit_3D_sequence_backwards_play(sq_sidestep,YES);

			}
			else
			{
				player1.up_key_pressed = true;
				player1.down_key_pressed = false;				
				//Morfit_3D_sequence_backwards_play(sq_sidestep,NO);
			}
		}

	}
	else if (!(js.lY && 0x80) || (js.lX && 0x80))
	{
		player1.up_key_pressed = false;
		player1.down_key_pressed = false;				
		player1.right_key_pressed = false;
		player1.left_key_pressed = false;
	}
	
	player1.process_input();
	player2.process_input();
	
	player1.move(player2.location);
	player2.move(player1.location);

	player1.at_left = g_camera.first_charactor_is_at_left(player1.location,player2.location);
	player2.at_left = !player1.at_left;


	if (player1.at_left)
	{
		g_camera.set_location_and_direction(player1.location,player2.location);
	}
	else if (player2.at_left)
	{
		g_camera.set_location_and_direction(player2.location,player1.location);
	}
		
		//Morfit_object_set_3D_sequence(gl_player,sq_stand_idle,0);


//All that is left to do is make sure that we are walking on the terrain
//(and not below it or in the sky). Another thing that we check is whether
//we went into an obstaclethat is too high for us to jump on it.
 /*  double location[3];
   Morfit_object_get_location(gl_player,&location[0],&location[1],&location[2]);
   double intersection[3];
   get_intersection_with_terrain(location,intersection);
	
   double new_altitude = intersection[2]+gl_player_height/2;

   if(new_altitude>save_location[2]+gl_player_height/3)
   {
	   Morfit_object_set_location(gl_player,save_location[0],save_location[1],save_location[2]);
   }
   else
   {
	   Morfit_object_set_location(gl_player,location[0],location[1],new_altitude);
   }*/

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FreeDirectInput()
// Desc: Initialize the DirectInput variables.
//-----------------------------------------------------------------------------
VOID FreeDirectInput()
{
	 // Unacquire the device one last time just in case 
    // the app tried to exit while the device is still acquired.
    if( g_pJoystick ) 
        g_pJoystick->Unacquire();
    
    // Release any DirectInput objects.
    SAFE_RELEASE( g_pJoystick );
    SAFE_RELEASE( g_pDI );
}

	