// camera.cpp: implementation of the camera class.
//
//////////////////////////////////////////////////////////////////////

#include "camera.h"
#include "mrft_api.h"
#include <math.h>
#define MIN_CAMERA_DISTANCE		100
#define MIN_CAMERA_HIGH				50
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

camera::camera()
{

}

camera::~camera()
{
	Morfit_camera_delete(handle);
}

camera::initialize(double distance_from_player_factor)
{
	handle = Morfit_camera_create("internal_camera");
	distance_from_O_point_factor =  distance_from_player_factor;
}
camera::set_location_and_direction(double location_of_left_player[],double location_of_right_player[])
{
	O_point[0] = (location_of_left_player[0]+location_of_right_player[0])/2;
	O_point[1] = (location_of_left_player[1]+location_of_right_player[1])/2;
	O_point[2] = (location_of_left_player[2]+location_of_right_player[2])/2;
	abs_of_Vector_P1P2 = sqrt((location_of_left_player[0]-location_of_right_player[0])*(location_of_left_player[0]-location_of_right_player[0])+ (location_of_left_player[1]-location_of_right_player[1])*(location_of_left_player[1]-location_of_right_player[1])) ;
	abs_of_Vector_CO = abs_of_Vector_P1P2 * distance_from_O_point_factor + MIN_CAMERA_DISTANCE;
	abs_of_Vector_DP1 = abs_of_Vector_P1P2 / 2;

	unit_vector_DP1[0] = (location_of_left_player[0] - O_point[0])/abs_of_Vector_DP1;
	unit_vector_DP1[1] = (location_of_left_player[1] - O_point[1])/abs_of_Vector_DP1;
	unit_vector_DP1[2] = (location_of_left_player[2] - O_point[2])/abs_of_Vector_DP1;

	camera_position[0] = (   (1-unit_vector_DP1[0]*unit_vector_DP1[0])*abs_of_Vector_CO/unit_vector_DP1[1]		) + O_point[0] ;
	camera_position[1] =   (   (unit_vector_DP1[1]*(camera_position[0]-O_point[0]) ) - 1/abs_of_Vector_CO) + O_point[1];
	camera_position[2] = O_point[2] + MIN_CAMERA_HIGH;
	Morfit_camera_point_at(handle,O_point[0],O_point[1],O_point[2]);
}



bool camera::first_charactor_is_at_left(double first_charactor_location[], double second_charactor_location[])
{
	Morfit_camera_convert_point_to_camera_space(handle,first_charactor_location,camera_space_player1_location);
	Morfit_camera_convert_point_to_camera_space(handle,second_charactor_location,camera_space_player2_location);

	//if at left of camera y of player1 < 0 < y of player2 (if camera point to center between 2 player)
	if (camera_space_player1_location[1]<=camera_space_player2_location[1])
	{
		return(true);	
	} else
	{
		return(false);
	}

}
