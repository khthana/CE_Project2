// attack_data.cpp: implementation of the attack_data class.
//
//////////////////////////////////////////////////////////////////////

#include "attack_data.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

attack_data::attack_data()
{

}

attack_data::~attack_data()
{

}

attack_data::initialize
						(double radian_in_cosine,
						double renge_distance_min,
						double renge_distance_max, 
						double renge_in_axis_z_min,
						double renge_in_axis_z_max,
						bool block_with_crouch_guard, 
						bool block_with_stand_guard,
						int damage,
						int attackable_frame,
						int stagger_type,
						bool if_special_attack_booton_is_kick_ro_punch)
{
	attack_radian_in_cosine		= radian_in_cosine;
	attack_renge_distance[0]	= renge_distance_min;
	attack_renge_distance[1]	= renge_distance_max;
	attack_renge_in_axis_z[0]	= renge_in_axis_z_min;
	attack_renge_in_axis_z[1]	= renge_in_axis_z_max;
	can_block_with_crouch_guard = block_with_crouch_guard;
	can_block_with_stand_guard	= block_with_stand_guard;
	attack_damage				= damage;
	target_stagger_type			= stagger_type;
	attack_frame				= attackable_frame;

}
