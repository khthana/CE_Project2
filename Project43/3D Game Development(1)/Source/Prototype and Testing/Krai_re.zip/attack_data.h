// attack_data.h: interface for the attack_data class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ATTACK_DATA_H__64DC8C63_10B8_11D5_BDF2_00E029663C62__INCLUDED_)
#define AFX_ATTACK_DATA_H__64DC8C63_10B8_11D5_BDF2_00E029663C62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class attack_data  
{
public:
	attack_data();
	virtual ~attack_data();
	
	initialize(double radian_in_cosine,
						double renge_distance_min,
						double renge_distance_max, 
						double renge_in_axis_z_min,
						double renge_in_axis_z_max,
						bool block_with_crouch_guard, 
						bool block_with_stand_guard,
						int damage,
						int attackable_frame,
						int stagger_type,
						bool if_special_attack_booton_is_kick_ro_punch);

	double	attack_radian_in_cosine,
			attack_renge_in_axis_z[2],
			attack_renge_distance[2];
	
	int		attack_damage,target_stagger_type;
	
	bool	can_block_with_crouch_guard,
			can_block_with_stand_guard,
			kick_or_punch;
	int		attack_frame;


};

#endif // !defined(AFX_ATTACK_DATA_H__64DC8C63_10B8_11D5_BDF2_00E029663C62__INCLUDED_)
