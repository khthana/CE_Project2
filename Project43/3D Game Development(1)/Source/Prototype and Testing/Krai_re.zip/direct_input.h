// direct_input.h: interface for the direct_input class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIRECT_INPUT_H__A7323A42_10A6_11D5_BDF2_00E029663C62__INCLUDED_)
#define AFX_DIRECT_INPUT_H__A7323A42_10A6_11D5_BDF2_00E029663C62__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <dinput.h>
#include "mrft_api.h"




class direct_input  
{
public:
	direct_input();
	virtual ~direct_input();
	
};

#endif // !defined(AFX_DIRECT_INPUT_H__A7323A42_10A6_11D5_BDF2_00E029663C62__INCLUDED_)
