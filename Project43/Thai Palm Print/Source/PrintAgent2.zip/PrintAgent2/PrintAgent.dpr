program PrintAgent;

uses
  Forms,
  InvisibleForm in 'InvisibleForm.pas' {Invisible},
  Unit2 in 'Unit2.pas' {SettingForm},
  about in 'about.pas' {about_form};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TInvisible, main);
  Application.CreateForm(TSettingForm, SettingForm);
  Application.CreateForm(Tabout_form, about_form);
  Application.Run;
end.
