object about_form: Tabout_form
  Left = 598
  Top = 211
  BorderIcons = []
  BorderStyle = bsDialog
  Caption = 'Thai Palm Print'
  ClientHeight = 231
  ClientWidth = 288
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Icon.Data = {
    0000010001001010100000000000280100001600000028000000100000002000
    00000100040000000000C0000000000000000000000000000000000000000000
    0000000080000080000000808000800000008000800080800000C0C0C0008080
    80000000FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF007777
    70000007777777700000000007777700000000000077700FFFFFFFFFF007700F
    00FFFFFFF007000FFFFFFFFFF00000000000000000000000FFFFFFFF00000000
    FF0F0FFF00000000FF0F0FFF00000000FF0F0FFF00007000F0000F0000077000
    FFFFFF0000077700000000000077777000000000077777777000000777770000
    0000000000000000000000000000000000000000000000000000000000000000
    000000000000000000000000000000000000000000000000000000000000}
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 80
    Top = 8
    Width = 126
    Height = 24
    Alignment = taCenter
    Caption = 'Thai Palm Print'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 96
    Top = 40
    Width = 92
    Height = 24
    Caption = 'Print Agent'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Button1: TButton
    Left = 104
    Top = 192
    Width = 75
    Height = 25
    Caption = 'Close'
    Default = True
    TabOrder = 0
    OnClick = Button1Click
  end
  object Memo1: TMemo
    Left = 16
    Top = 72
    Width = 257
    Height = 113
    Alignment = taCenter
    BiDiMode = bdLeftToRight
    Lines.Strings = (
      #13'Thai Palm Print'#39's Print Agent'#10
      ''
      'Author by Piya Plicharoenpon'
      '(krabee@yahoo.com)'
      'http://www.krabee.com'
      ''
      'This program is a part of project '
      '"Thai Palm Print"'
      #13'Computer Engineering,KMITL')
    OEMConvert = True
    ParentBiDiMode = False
    ReadOnly = True
    TabOrder = 1
  end
end
