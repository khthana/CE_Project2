unit InvisibleForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Menus, CPDrv, TrayIcon , registry, StdCtrls, ComCtrls, ExtCtrls,About;

type
  TInvisible = class(TForm)
    TrayIcon1: TTrayIcon;
    ComPort: TCommPortDriver;
    Main: TPopupMenu;
    Exit1: TMenuItem;
    N1: TMenuItem;
    Setting1: TMenuItem;
    About1: TMenuItem;
    RichEdit1: TRichEdit;
    PrintDialog1: TPrintDialog;
    PortSetting1: TMenuItem;
    Label1: TLabel;
    Button1: TButton;
    Label2: TLabel;
    Memo1: TMemo;
    procedure FormCreate(Sender: TObject);
    procedure Exit1Click(Sender: TObject);
    procedure Setting1Click(Sender: TObject);
    procedure ComPortReceiveData(Sender: TObject; DataPtr: Pointer;
      DataSize: Cardinal);
    procedure PortSetting1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure About1Click(Sender: TObject);
  private
    { Private declarations }
  public
     Port,Speed : integer;
     Temp_file : TEXTfile;
     Temp_dir ,Temp_filename: array [0..255]of char;
//     end_rtf : boolean;
     { Public declarations }
  end;

var
  Main: TInvisible;

implementation

uses Unit2;

{$R *.DFM}

procedure TInvisible.FormCreate(Sender: TObject);
var
  Reg: TRegistry;
  Port_str : string[8];

begin

  Reg:=TRegistry.Create;
  Port:=0;
  Speed:=115200;

  Reg.RootKey:=HKEY_CURRENT_USER;
  Reg.OpenKey('\SOFTWARE\KMITL\TPP\',false);
  if Reg.ValueExists('Port') then Port :=Reg.ReadInteger('Port');
  if Reg.ValueExists('Speed') then Speed :=Reg.ReadInteger('Speed');

  Reg.Free;

  case Port of
        0 : Port_Str:='\\.\COM1';
        1 : Port_str:='\\.\COM2';
        2 : Port_Str:='\\.\COM3';
        3 : Port_Str:='\\.\COM4';
  end;

  ComPort.BaudRateValue:=Speed;
  ComPort.PortName:=Port_str;
{
  if Not ComPort.Connect () then
  begin
        MessageDlg('Cannot connect To '+Port_str, mtError,[mbOk], 0);;
        halt;
  end;
 }
  Randomize;


  ShowWindow(Application.Handle, SW_HIDE);

  SetWindowLong(Application.Handle, GWL_EXSTYLE,
          GetWindowLong(Application.Handle, GWL_EXSTYLE) or WS_EX_TOOLWINDOW);

  ShowWindow(Application.Handle, SW_SHOW);

  ShowWindowAsync( Handle, SW_HIDE );

  if Not ComPort.Connect () then
  begin
        MessageDlg('Cannot connect To '+ComPort.PortName, mtError,[mbOk], 0);
        exit;
  end;
end;

procedure TInvisible.Exit1Click(Sender: TObject);
var Reg : TRegistry;
begin
//  CloseFile(Temp_file);

  Reg := TRegistry.Create;
  try
    Reg.RootKey := HKEY_CURRENT_USER;
    if Reg.OpenKey('\SOFTWARE\KMITL\TPP\', True) then
    Begin
        Reg.WriteInteger('Port',Port);
        Reg.WriteInteger('Speed',Speed);
    End;
finally
    Reg.CloseKey;
    Reg.Free;
    inherited;
end;
halt;
end;

procedure TInvisible.Setting1Click(Sender: TObject);
begin
SettingForm.Show;
end;

procedure TInvisible.ComPortReceiveData(Sender: TObject; DataPtr: Pointer;
  DataSize: Cardinal);
var
  s,ser_buffer : string;
  temp_char : char;
//  LineStatus : TLineStatusSet;
begin
//  LineStatus:=ComPort.GetLineStatus();

  s := StringOfChar( ' ', DataSize );
  move( DataPtr^, pchar(s)^, DataSize );

  ser_buffer:=s;

  ComPort.FlushBuffers(True,False);
  ComPort.PausePolling;

  while (ComPort.ReadChar(temp_char)) do
  begin
        ser_buffer:=ser_buffer+temp_char;
//        write(Temp_file,temp_char);
  end;


//  RichEdit1.Lines.Add(s);

  GetTempPath(255, @Temp_dir);
  GetTempFileName(@Temp_dir,PChar('TPP'),$464,@Temp_filename);

  AssignFile(Temp_file,Temp_filename);
  rewrite(Temp_file);

  write(Temp_File,ser_buffer);


  closefile(Temp_File);
  ComPort.ContinuePolling;
  RichEdit1.Lines.LoadFromFile(Temp_filename);
  RichEdit1.Print('Thai Palm Print');

//
//  RichEdit1.Print ('Test');

//  MessageDlg('Data Recieve',mtInformation,[mbOK],0);
//  if not (lsCD in LineStatus) then
// begin
//        closefile(Temp_File);
//  end;
end;

procedure TInvisible.PortSetting1Click(Sender: TObject);
begin
ComPort.disconnect;
PrintDialog1.Execute;
end;

procedure TInvisible.Button1Click(Sender: TObject);
begin
self.hide;
end;

procedure TInvisible.About1Click(Sender: TObject);
begin
About_form.show;
end;

end.
