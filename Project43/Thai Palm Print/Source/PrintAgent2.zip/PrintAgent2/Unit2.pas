unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, ComCtrls,InvisibleForm, printers;

type
  TSettingForm = class(TForm)
    Button1: TButton;
    Button2: TButton;
    PortDropdown: TComboBox;
    SpeedDropdown: TComboBox;
    Label2: TLabel;
    Label1: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private
    { Private declarations }
  public

    { Public declarations }
  end;

var
  SettingForm: TSettingForm;
  Printer : Tprinter;
implementation

{$R *.DFM}

procedure TSettingForm.Button1Click(Sender: TObject);
var Error:boolean;
    Port_Str:string;
begin
        Error:=false;

        if SpeedDropdown.ItemIndex >=0 then
        begin
        case (SpeedDropdown.ItemIndex) of
                0 : Main.Speed:=115200;
                1 : Main.Speed:=57600;
                2 : Main.Speed:=38400;
                3 : Main.Speed:=28000;
                4 : Main.Speed:=19200;
                5 : Main.Speed:=14400;
                6 : Main.Speed:=9600;
                7 : Main.Speed:=4800;
                8 : Main.Speed:=1200;
{                -1 : Begin
                        MessageDlg('Invalid speed!!!', mtError,[mbOk], 0);
                        Error:=true;
                     End;}
        end;
        Main.ComPort.BaudRateValue:=Main.Speed;
        end;

        if (PortDropdown.ItemIndex >=0) then
        begin
        Main.Port:=PortDropdown.ItemIndex;

        case Main.Port of
        0 : Port_Str:='\\.\COM1';
        1 : Port_str:='\\.\COM2';
        2 : Port_Str:='\\.\COM3';
        3 : Port_Str:='\\.\COM4';
        end;
        Main.ComPort.PortName:=Port_str;
        end;


        if Not Error then
        begin
                SettingForm.visible:=false;
                if Not Main.ComPort.Connect () then
                        MessageDlg('Cannot connect To '+Main.ComPort.Portname, mtError,[mbOk], 0);
        end;
end;

procedure TSettingForm.FormShow(Sender: TObject);
begin
        SpeedDropdown.Text :=IntToStr(Main.Speed);
        case Main.Port of
                0 : PortDropdown.Text:='COM1';
                1 : PortDropdown.Text:='COM2';
                2 : PortDropdown.Text:='COM3';
                3 : PortDropdown.Text:='COM4';
        end;
end;

procedure TSettingForm.Button2Click(Sender: TObject);
begin
SettingForm.Visible := false;
if Not Main.ComPort.Connect () then
        MessageDlg('Cannot connect To '+Main.ComPort.Portname, mtError,[mbOk], 0);
end;

end.
