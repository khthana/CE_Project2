object SettingForm: TSettingForm
  Left = 442
  Top = 396
  BorderIcons = [biMinimize]
  BorderStyle = bsDialog
  Caption = 'Setting...'
  ClientHeight = 95
  ClientWidth = 285
  Color = clBtnFace
  DragMode = dmAutomatic
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 22
    Top = 52
    Width = 67
    Height = 13
    Caption = 'Speed           :'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label1: TLabel
    Left = 22
    Top = 22
    Width = 63
    Height = 13
    Caption = 'Connect via :'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Button1: TButton
    Left = 196
    Top = 21
    Width = 70
    Height = 23
    Caption = '&Ok'
    Default = True
    TabOrder = 0
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 196
    Top = 50
    Width = 70
    Height = 24
    Cancel = True
    Caption = '&Cancel'
    TabOrder = 1
    OnClick = Button2Click
  end
  object PortDropdown: TComboBox
    Left = 97
    Top = 22
    Width = 82
    Height = 21
    ItemHeight = 13
    TabOrder = 2
    Items.Strings = (
      'COM1'
      'COM2'
      'COM3'
      'COM4')
  end
  object SpeedDropdown: TComboBox
    Left = 97
    Top = 52
    Width = 82
    Height = 21
    ItemHeight = 13
    TabOrder = 3
    Items.Strings = (
      '115200'
      '57600'
      '38400'
      '28800'
      '19200'
      '14400'
      '9600'
      '4800'
      '2400'
      '1200')
  end
end
