object Invisible: TInvisible
  Left = 283
  Top = 464
  BorderIcons = []
  BorderStyle = bsDialog
  Caption = 'Thai Palm Print'
  ClientHeight = 173
  ClientWidth = 289
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 80
    Top = 8
    Width = 126
    Height = 24
    Alignment = taCenter
    Caption = 'Thai Palm Print'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 96
    Top = 40
    Width = 92
    Height = 24
    Caption = 'Print Agent'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object RichEdit1: TRichEdit
    Left = 137
    Top = 8
    Width = 0
    Height = 1
    Lines.Strings = (
      'R'
      'i'
      'c'
      'h'
      'E'
      'd'
      'i'
      't'
      '1')
    TabOrder = 0
  end
  object Button1: TButton
    Left = 104
    Top = 136
    Width = 75
    Height = 25
    Caption = 'Close'
    Default = True
    TabOrder = 1
    OnClick = Button1Click
  end
  object Memo1: TMemo
    Left = 16
    Top = 72
    Width = 257
    Height = 57
    Alignment = taCenter
    BiDiMode = bdLeftToRight
    Lines.Strings = (
      'Thai Palm Print Print Agent'
      'Cannot connect to serial port.'
      'Make sure hotsync manager is close')
    OEMConvert = True
    ParentBiDiMode = False
    ReadOnly = True
    TabOrder = 2
  end
  object TrayIcon1: TTrayIcon
    Active = True
    Animate = False
    ShowDesigning = False
    Icon.Data = {
      0000010001001010100000000000280100001600000028000000100000002000
      00000100040000000000C0000000000000000000000000000000000000000000
      0000000080000080000000808000800000008000800080800000C0C0C0008080
      80000000FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF007777
      70000007777777700000000007777700000000000077700FFFFFFFFFF007700F
      00FFFFFFF007000FFFFFFFFFF00000000000000000000000FFFFFFFF00000000
      FF0F0FFF00000000FF0F0FFF00000000FF0F0FFF00007000F0000F0000077000
      FFFFFF0000077700000000000077777000000000077777777000000777770000
      0000000000000000000000000000000000000000000000000000000000000000
      000000000000000000000000000000000000000000000000000000000000}
    PopupMenu = Main
    Left = 72
    Top = 136
  end
  object ComPort: TCommPortDriver
    Port = pnCustom
    PortName = '\\.\COM2'
    BaudRate = brCustom
    HwFlow = hfRTSCTS
    InBufSize = 4096
    CheckLineStatus = True
    OnReceiveData = ComPortReceiveData
    Left = 248
    Top = 136
  end
  object Main: TPopupMenu
    Left = 184
    Top = 136
    object PortSetting1: TMenuItem
      Caption = 'Printer setting'
      OnClick = PortSetting1Click
    end
    object Setting1: TMenuItem
      Caption = 'Port setting'
      OnClick = Setting1Click
    end
    object About1: TMenuItem
      Caption = 'About'
      OnClick = About1Click
    end
    object N1: TMenuItem
      Caption = '-'
    end
    object Exit1: TMenuItem
      Caption = 'Exit'
      OnClick = Exit1Click
    end
  end
  object PrintDialog1: TPrintDialog
    Left = 216
    Top = 136
  end
end
