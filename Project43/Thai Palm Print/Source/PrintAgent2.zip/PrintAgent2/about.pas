unit about;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  Tabout_form = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Button1: TButton;
    Memo1: TMemo;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  about_form: Tabout_form;

implementation

{$R *.DFM}

procedure Tabout_form.Button1Click(Sender: TObject);
begin
about_form.hide;
end;

end.
