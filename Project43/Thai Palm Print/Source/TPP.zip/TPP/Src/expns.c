#include "expns.h"
#include <DataMgr.h>
#include <PalmOS.h>
#include <PalmCompatibility.h>
#include "rtf.h"

/************************************************************
 *
 *  FUNCTION: ExpenseUnpack
 *
 *  DESCRIPTION: Fills in the ExpensePackedRecord structure
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the record unpacked
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/21/96	Initial Revision
 *
 *************************************************************/

void ExpenseUnpack (ExpensePackedRecordPtr src, ExpenseRecordPtr dest)
{
	Char * p;

	
	dest->date = src->date;
	dest->type = src->type;
	dest->paymentType = src->paymentType;
	dest->currency = src->currency;


	p = (Char *)src + sizeof(ExpensePackedRecord);
	
	// Get the amount.
	dest->amount = p;
	p += StrLen(p) + 1;

	// Get the vendor
	dest->vendor = p;
	p += StrLen(p) + 1;

	// Get the city
	dest->city = p;
	p += StrLen(p) + 1;

	// Get the attendees
	dest->attendees = p;
	p += StrLen(p) + 1;

	// Get the note
	dest->note = p;
}


/************************************************************
 *
 *  FUNCTION: ExpenseGetRecord
 *
 *  DESCRIPTION: Get a record from a Appointment Database
 *
 *  PARAMETERS: dbP     - database pointer
 *				    index   - database index
 *				    r       - database record
 *              handleP - returned: handled of record
 *              
 *
 *  RETURNS: 	errorcode, 0 if successful
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/21/96	Initial Revision
 *
 *************************************************************/
Err ExpenseGetRecord (DmOpenRef dbP, UInt16 index, ExpenseRecordPtr r, 
	MemHandle * handleP)
{
	MemHandle MemHandle;
	ExpensePackedRecordPtr src;
	

	MemHandle = DmQueryRecord (dbP, index);
	ErrFatalDisplayIf(DmGetLastErr(), "Error Querying record");
	
	src = MemHandleLock (MemHandle);

	if (DmGetLastErr())
		{
		*handleP = 0;
		return DmGetLastErr();
		}
	
	ExpenseUnpack (src, r);
	
	*handleP = MemHandle;
	return 0;
}



void render_expns_db(){
	UInt				mode;
	DmOpenRef 			expnsDB;
   	MemHandle			recordH,Date_strHandle;
   	UInt16				index;
	ExpenseRecordPtr	expnsRecPtr;
	
	UInt16				numRecords,n,m;
	
	MemPtr				Date_str;
	
	index=0;
	mode = dmModeReadOnly;
	expnsDB = DmOpenDatabaseByTypeCreator(DBType, expnsAppType,mode);

	numRecords = DmNumRecordsInCategory(expnsDB,dmAllCategories);
	
	recordH = MemHandleNew(sizeof(ExpenseRecordType));
	write_rtf_header();
	
	set_fontsize("32");
	set_fonttype("18");
	append_string("Expense");
	
	rtf_newline();
	set_fontsize("20");
	set_fonttype("18");

	for(n=0;n<numRecords;n++) {
		ExpenseGetRecord (expnsDB,n, expnsRecPtr, &recordH);
		recordH = DmGetRecord(expnsDB, n);


		Date_strHandle=MemHandleNew(Date_str_len);
		Date_str=MemHandleLock(Date_strHandle);
		DateToAscii ((expnsRecPtr->date).month,(expnsRecPtr->date).day,(expnsRecPtr->date).year+1904,
			dfMDYLongWithComma,Date_str);
		append_string(Date_str);
		MemHandleUnlock(Date_strHandle);

		append_string(" : ");
			
		switch (expnsRecPtr->type) {
			case 0 : append_string("Airfare"); break;
			case 1 : append_string("Breakfast"); break;
			case 2 : append_string("Bus"); break;
			case 3 : append_string("Business Meals"); break;
			case 4 : append_string("Car Rental"); break;
			case 5 : append_string("Dinner"); break;
			case 6 : append_string("Entertainment"); break;
			case 7 : append_string("Fax"); break;
			case 8 : append_string("Gas"); break;
			case 9 : append_string("Gifts"); break;
			case 10 : append_string("Hotel"); break;
			case 11 : append_string("Incidentals"); break;
			case 12 : append_string("Laundry"); break;
			case 13 : append_string("Limo"); break;
			case 14 : append_string("Lodging"); break;
			case 15 : append_string("Lunch"); break;
			case 16 : append_string("Mileage"); break;
			case 17 : append_string("Other"); break;
			case 18 : append_string("Parking"); break;
			case 19 : append_string("Postage"); break;
			case 20 : append_string("Snack"); break;
			case 21 : append_string("Subway"); break;
			case 22 : append_string("Supplies"); break;
			case 23 : append_string("Taxi"); break;
			case 24 : append_string("Telephone"); break;
			case 25 : append_string("Tips"); break;
			case 26 : append_string("Tolls"); break;
			case 27 : append_string("Trains"); break;
			
		}
		
		append_string(" : ");
		append_string(expnsRecPtr->amount);
		
		append_string(" ");
		switch (expnsRecPtr->currency) {
			case 31 : append_string("Baht"); break;
		}
		
		rtf_newline();
		
		MemHandleUnlock(recordH);
		DmReleaseRecord(expnsDB,n, false);
	}
	write_rtf_end();

}
