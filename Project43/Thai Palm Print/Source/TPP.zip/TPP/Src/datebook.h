#include <datetime.h>

#define datebookAppType 'date'
#define DBType			'DATA'

typedef struct {
	TimeType			startTime;			// Time the appointment starts
	TimeType			endTime;				// Time the appointment ends
	DateType			date;					// date of appointment
} ApptDateTimeType;

typedef struct {
	unsigned when			:1;			// set if when info changed (ApptChangeRecord)
	unsigned alarm			:1;			// set if record contains alarm info
	unsigned repeat		:1;			// set if record contains repeat info
	unsigned note			:1;			// set if record contains a note
	unsigned exceptions	:1;			// set if record contains exceptions list
	unsigned description	:1;			
} ApptDBRecordFlags;

typedef struct {
	ApptDateTimeType 	when;
	ApptDBRecordFlags	flags;	// A flag set for each  datum present
	char				firstField;
	UInt8				reserved;
} ApptPackedDBRecordType;

typedef ApptPackedDBRecordType * ApptPackedDBRecordPtr;

typedef enum alarmTypes {aauMinutes, aauHours, aauDays} AlarmUnitType;

typedef struct {
	Int8					advance;			// Alarm advance (-1 = no alarm)
	AlarmUnitType		advanceUnit;	// minutes, hours, days
} AlarmInfoType;

enum repeatTypes {
	repeatNone, 
	repeatDaily, 
	repeatWeekly, 
	repeatMonthlyByDay, 
	repeatMonthlyByDate,
	repeatYearly
};
typedef enum repeatTypes RepeatType;

typedef struct {
	RepeatType		repeatType;			// daily, weekly, monthlyByDay, etc.
	UInt8				reserved1;
	DateType			repeatEndDate;		// minus one if forever
	UInt8	repeatFrequency;	// i.e. every 2 days if repeatType daily
	UInt8	repeatOn;			// monthlyByDay and repeatWeekly only	
	UInt8  repeatStartOfWeek;// repeatWeekly only
	UInt8				reserved2;
} RepeatInfoType;

typedef struct {
	UInt16    	numExceptions;
	DateType	exception;
} ExceptionsListType;

typedef struct {
	ApptDateTimeType *	when;
	AlarmInfoType *		alarm;
	RepeatInfoType *		repeat;
	ExceptionsListType *	exceptions;
	Char *					description;
	Char *					note;
} ApptDBRecordType;

typedef ApptDBRecordType * ApptDBRecordPtr;

