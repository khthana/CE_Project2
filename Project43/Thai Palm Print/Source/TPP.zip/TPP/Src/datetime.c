#include <DateTime.h>

/******************************************************
 *
 *	Return True if Date1 beyond date2
 *
 *
 ******************************************************/

Boolean DateBeyond(DateType date1,DateType date2){
if (date1.year > date2.year) return(true);
else if (date1.year<date2.year) return(false);

else if(date1.month > date2.month) return(true); // Year equal
else if(date1.month < date2.month) return(false);

else if(date1.day >= date2.day) return(true);    //month equal
else return false;
}