#include <PalmOS.h>
#include <PalmCompatibility.h>

#define RTF_HEADER "{\\rtf\\ansi\\ansicpg874\\deff0{\\fonttbl{\\f15\\fswiss\\fcharset222\\fprq2 Angsana UPC;}{\\f16\\fswiss\\fcharset222\\fprq2 Cordia New;}{\\f18\\fswiss\\fcharset222\\fprq2 MS Sans Serif;}}\\pard\\plain "

VoidHand	rtfData=0;
UInt32	rtfDataSize;

int write_rtf_header(){
	MemPtr rtfDataPtr;
	
	rtfData=MemHandleNew(sizeof(RTF_HEADER));
	rtfDataPtr=MemHandleLock(rtfData);

	StrVPrintF (rtfDataPtr,RTF_HEADER,NULL);
	rtfDataSize=sizeof(RTF_HEADER);
	MemHandleUnlock(rtfData);
	
	return(true);
}

int append_char(CharPtr x){
		Err		MemHandleErr;
		MemPtr StrPtr=0;
		Char	AChar;

		rtfDataSize++;
		MemHandleErr=MemHandleResize(rtfData,rtfDataSize);
		ErrFatalDisplayIf(MemHandleErr, "Could not grow choices for list.");
			
		StrPtr=MemHandleLock(rtfData);

		AChar=(Char )*x;
		MemMove((MemPtr)((UInt32)StrPtr+rtfDataSize-2),x,1);
		
		MemHandleUnlock(rtfData);
		return(true);
}


int rtf_newline(){
		Err		MemHandleErr;
		MemPtr StrPtr=0;

		rtfDataSize+=5;
		MemHandleErr=MemHandleResize(rtfData,rtfDataSize);
		ErrFatalDisplayIf(MemHandleErr, "Could not grow choices for list.");
			
		StrPtr=MemHandleLock(rtfData);

		StrVPrintF((MemPtr)((UInt32)StrPtr+rtfDataSize-6),"\\par ",0);
		
		MemHandleUnlock(rtfData);
		return(true);
}


void append_string(CharPtr x){
		
	while (*x!='\0') {
	
		// Case memoText is newline
		if (*x=='\n') rtf_newline();
		else append_char(x);
		
		x++;
		
	}
}

int write_rtf_end(){
/*		Err		MemHandleErr;
		MemPtr StrPtr=0;

		rtfDataSize+=1;
		MemHandleErr=MemHandleResize(rtfData,rtfDataSize);
		ErrFatalDisplayIf(MemHandleErr, "Could not grow choices for list.");
			
		StrPtr=MemHandleLock(rtfData);


		StrVPrintF((MemPtr)((UInt32)StrPtr+rtfDataSize-2),"}","");
		
		MemHandleUnlock(rtfData);
*/
		append_string("}");
		return(true);
}


void set_fontsize(CharPtr size){

	append_string("\\fs");
	append_string(size);
	append_string(" ");
}

void set_fonttype(CharPtr type){
	append_string("\\f");
	append_string(type);
	append_string(" ");
}