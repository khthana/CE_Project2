#include <PalmOS.h>
#include "addressDB.h"
#include "address.h"
#include "StarterRsc.h"
#include "rtf.h"
#include <PalmCompatibility.h>

/*********************************************************
 *
 *		Predefine
 *
 *
 *********************************************************/

#define BitAtPosition(pos)                  ((UInt32)1 << (pos))
#define GetBitMacro(bitfield, index)      ((bitfield) & BitAtPosition(index))

#define addressAppType  'addr'
#define DBType 			'DATA'
#define noRecordSelected	-1

/*********************************************************
 *
 *		Type definition
 *
 *
 *********************************************************/

typedef struct {
      AddrOptionsType      options;        // Display by company or by name
      AddrDBRecordFlags    flags;
      UInt8        			companyFieldOffset;   // Offset from firstField
      char                 firstField;
} AddrPackedDBRecord;

extern Word LastView,CurrentView;

Boolean SelectAddressFormHandleEvent(EventPtr eventP);

void AddrUnpack(AddrPackedDBRecord *src, AddrDBRecordPtr dest)
{
   Int16   index;
   UInt32 flags;
   char *p;

   
   dest->options = src->options;
   flags = src->flags.allBits;
   p = &src->firstField;

         
   for (index = firstAddressField; index < addressFieldsCount; index++)
      {
      // If the flag is set point to the string else NULL
      if (GetBitMacro(flags, index) != 0)
         {
         dest->fields[index] = p;
         p += StrLen(p) + 1;
         }
      else
         dest->fields[index] = NULL;
      }
}


Err AddrGetRecord(DmOpenRef dbP, UInt16 index, AddrDBRecordPtr recordP,MemHandle *recordH)
{
   AddrPackedDBRecord *src;

   *recordH = DmQueryRecord(dbP, index);
   src = (AddrPackedDBRecord *) MemHandleLock(*recordH);
   if (src == NULL)
      return dmErrIndexOutOfRange;
   
   AddrUnpack(src, recordP);
   
   return 0;
}

void write_phone_lable(UInt x) {
	switch (x){
		case 0 : append_string("Work   : "); break;
		case 1 : append_string("Home   : "); break;
		case 2 : append_string("Fax    : "); break;
		case 3 : append_string("Other  : "); break;
		case 4 : append_string("Email  : "); break;
		case 5 : append_string("Main   : "); break;
		case 6 : append_string("Pager  : "); break;
		case 7 : append_string("Mobile : "); break;
	}
}

int AddressPrintRec(AddrDBRecordType record){
	UInt16 field_index;

	set_fontsize("32");
	set_fonttype("18");

	if (record.fields[firstName] != NULL) { 
		append_string(record.fields[firstName]);
		append_string("   ");
	}
	if (record.fields[name] != NULL) append_string(record.fields[name]);
	   	   
	rtf_newline();

	if (record.fields[company] != NULL) append_string(record.fields[company]);	
	rtf_newline();	
	rtf_newline();	
    for (field_index = firstPhoneField; field_index < addressFieldsCount; field_index++)
    {
      // If the flag is set point to the string else NULL
      if (record.fields[field_index] != NULL) {
      
      		set_fontsize("32");
      		set_fonttype("18");
			switch (field_index) {
				case phone1 : write_phone_lable(record.options.phones.phone1); break;
				case phone2 : write_phone_lable(record.options.phones.phone2); break;
				case phone3 : write_phone_lable(record.options.phones.phone3); break;
				case phone4 : write_phone_lable(record.options.phones.phone4); break;
				case phone5 : write_phone_lable(record.options.phones.phone5); break;
				case address : append_string("Address     : "); break;
				case city    : append_string("City        : "); break;
				case state   : append_string("State       : "); break;
				case zipCode   : append_string("Zipcode   : "); break;				
				case country   : append_string("Country   : "); break;
				case title     : append_string("Title     : "); break;
				case custom1   : append_string("Custom1   : "); break;
				case custom2   : append_string("Custom2   : "); break;
				case custom3   : append_string("Custom3   : "); break;
				case custom4   : append_string("Custom4   : "); break;
				case note      : append_string("note : \\par"); break;
			}
			
      		set_fontsize("20");
      		set_fonttype("18");

         	append_string(record.fields[field_index]);
         	rtf_newline();
      }
    }

}

int render_address_db(UInt32 index,Boolean PrintAll){
	UInt				mode;
	DmOpenRef 			addressDB;
   	AddrDBRecordType	record;
   	MemHandle			recordH;
   	UInt32				numRecords;
	
	mode = dmModeReadOnly;
	addressDB = DmOpenDatabaseByTypeCreator(DBType, addressAppType,mode);

	write_rtf_header();	
	if (!PrintAll) {
		AddrGetRecord(addressDB,index,&record,&recordH);
		AddressPrintRec(record);
		DmReleaseRecord(addressDB, index, false);

	}
	else {
		numRecords = DmNumRecordsInCategory(addressDB,dmAllCategories);

		for(index=0;index<numRecords;index++) {
			AddrGetRecord(addressDB,index,&record,&recordH);
			AddressPrintRec(record);
			append_string("\\par **************** \\par ");

			DmReleaseRecord(addressDB, index, false);
		}
	}


	write_rtf_end();
	return(true);
}


void SelectAddressFormInit(FormPtr frm)
{
	CharPtr			choices,temp_strPtr;
	ListPtr			lst;
	Handle			recHandle,temp_strHandle;
	RectangleType	lstRect;
	Int				itemIndex,textLen, lstWidth, choicesOffset = 0, i;
	UInt				numRecords;
	Err				error;
	Boolean			fits;
   	AddrDBRecordType	record;
	
	UInt			mode;
	VoidHand 		ChoicesHandle = 0, ChoicesPtrsHandle;
	
	MemPtr			AddressDB;
	UInt16			CurrentRecord,n;


	mode = dmModeReadOnly;
	AddressDB = DmOpenDatabaseByTypeCreator(DBType, addressAppType, mode);

	CurrentRecord = noRecordSelected;

//	frm = FrmGetActiveForm();
	
	numRecords = DmNumRecordsInCategory(AddressDB,dmAllCategories);
	if (numRecords)
		{

		itemIndex = FrmGetObjectIndex(frm, SelectAddressMemoListList);
		lst = FrmGetObjectPtr(frm,itemIndex);
	
		// Get the usable width of the list rectangle.
		FrmGetObjectBounds (frm, itemIndex, &lstRect);
		lstWidth = lstRect.extent.x - 2;
		
		// Allocate an initial block for the list choices.
		ChoicesHandle = MemHandleNew(sizeof(char));
		recHandle = MemHandleNew(lstWidth);
		
		// Lock down the block and set it's initial value to an empty string.
		choices = MemHandleLock(ChoicesHandle);
		*choices = 0;
		
		// Build up the choices.  
		// A sequence of strings packed one after another, one for each record.
		for (itemIndex = 0; itemIndex < numRecords; itemIndex++)
			{ 
			// Retrieve the record from the database and lock it down.
			
			AddrGetRecord(AddressDB,itemIndex,&record,&recHandle);
			
//			recHandle = DmGetRecord(AddressDB, itemIndex);

			if(recHandle != NULL) {
			

//			recText = MemHandleLock(recHandle);
			temp_strHandle=MemHandleNew(lstWidth+1);
			temp_strPtr = MemHandleLock(temp_strHandle);
			
			if ((record.fields[firstName]!=NULL) && (record.fields[name]!=NULL))
				StrPrintF(temp_strPtr,"%s %s",record.fields[firstName],record.fields[name]);
			else if ((record.fields[firstName]==NULL) && (record.fields[name]!=NULL))
				StrPrintF(temp_strPtr,"%s",record.fields[name]);
			else if ((record.fields[firstName]!=NULL) && (record.fields[name]==NULL))
				StrPrintF(temp_strPtr,"%s",record.fields[firstName]);
			// Determine the length of text that will fit within the list bounds.
			i = lstWidth;
			textLen = StrLen(temp_strPtr);
			FntCharsInWidth(temp_strPtr, &i, &textLen, &fits);
			
			// Grow the choices buffer to accomodate the new string. We must unlock
			// the chunk so that the Memory Manager can move the chunk if neccessary to
			// grow it.
			MemHandleUnlock(ChoicesHandle);
			error = MemHandleResize(ChoicesHandle, textLen + choicesOffset + sizeof('\0'));
			choices = MemHandleLock(ChoicesHandle);
			
			// Check for fatal error.
			ErrFatalDisplayIf(error, "Could not grow choices for list.");
		
			// Copy the text from the record to the choices buffer.
			for (i = 0; i < textLen; i++)
				choices[choicesOffset + i] = temp_strPtr[i];
	
			// Update the end of choices offset and set a zero terminator 
			// on the string in the choices buffer.
			choicesOffset += textLen;
			choices[choicesOffset++] = 0;
	
			// Unlock the handle to the record.
			MemHandleUnlock(recHandle);
			MemHandleUnlock(temp_strHandle);
			}
			// Release the record, not dirty.
			DmReleaseRecord(AddressDB, itemIndex, false);
			}
		
		// Create an array of pointers from the choices strings.
		ChoicesPtrsHandle = SysFormPointerArrayToStrings(choices, numRecords);
		
		// Set the list choices from the array of pointers.
		LstSetListChoices(lst, MemHandleLock(ChoicesPtrsHandle), numRecords);
		}
	
	// Draw the form.
	FrmDrawForm(frm);
}


Boolean SelectAddressFormHandleEvent(EventPtr eventP)
{
   Boolean handled = false;
   FormPtr frmP;
   UInt32	CurrentRecord;

	switch (eventP->eType) 
		{
	case frmOpenEvent:
			frmP = FrmGetActiveForm();
			SelectAddressFormInit( frmP);
			FrmDrawForm ( frmP);
			handled = true;
			break;
	case frmCloseEvent :
//			SelectAddressFormDeInit();
			break;
   	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// If the done button is pressed, go back to the main form.
	   	if (eventP->data.ctlEnter.controlID == SelectAddressAboutButton)
	  		 	{
	  		 	LastView=CurrentView;
				CurrentView=AboutForm;
				FrmGotoForm(CurrentView);
				handled = true;
				}
				
	   	if (eventP->data.ctlEnter.controlID == SelectAddressBackButton)
	  		 	{
				CurrentView=SelectDOCForm;
				FrmGotoForm(CurrentView);
				handled = true;
				}
				

	   	if (eventP->data.ctlEnter.controlID == SelectAddressNextButton)
	  		 	{
				frmP = FrmGetActiveForm();
				CurrentRecord = LstGetSelection(FrmGetObjectPtr(frmP,
				 FrmGetObjectIndex(frmP, SelectAddressMemoListList)));

				render_address_db(CurrentRecord,CtlGetValue(FrmGetObjectPtr(frmP,
				 	FrmGetObjectIndex(frmP, SelectAddressPrintAllCheckbox))));
	  		 	LastView=CurrentView;
	  		 	CurrentView=SerialConfigForm;
				FrmGotoForm(CurrentView);

				handled = true;
	  		 	}

			break;
		
		default:
			break;
		
		}
	
	return handled;
}




