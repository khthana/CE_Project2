#include <DateTime.h>

#define DBType	'DATA'
#define expnsAppType 	'exps'
#define Date_str_len 13

typedef struct {
	DateType 			date;
	UInt8			 		type;
	UInt8			 		paymentType;
	UInt8					currency;
	UInt8					reserved;
	Char *				amount;
	Char *				vendor;
	Char *				city;
	Char *				attendees;
	Char *				note;
} ExpenseRecordType;

typedef ExpenseRecordType * ExpenseRecordPtr;

typedef struct {
	DateType				date;
	UInt8					type;
	UInt8 					paymentType;
	UInt8					currency;
	UInt8					reserved;
} ExpensePackedRecord;

typedef ExpensePackedRecord * ExpensePackedRecordPtr;
