#include <PalmOS.h>
#include <PalmCompatibility.h>
#include "StarterRsc.h"
#include "rtf.h"

#define DBType 'DATA'
#define memoPadAppType 'memo'
#define noRecordSelected	-1

extern Word CurrentView,LastView;
void SelectMemoFormInit(FormPtr /*frm*/)
{
	DmOpenRef		MemoPadDB;

	Word			CurrentRecord;

	CharPtr			choices, recText;
	FormPtr			frm;
	ListPtr			lst;
	Handle			recHandle;
	RectangleType	lstRect;
	Int				textLen, lstWidth, choicesOffset = 0, i;
	UInt16			itemIndex;
	UInt			numRecords;
	Err				error;
	Boolean			fits;
	
	UInt			mode;
	VoidHand 		ChoicesHandle = 0, ChoicesPtrsHandle;


	mode = dmModeReadOnly;
	MemoPadDB = DmOpenDatabaseByTypeCreator(DBType, memoPadAppType, mode);

	CurrentRecord = noRecordSelected;

	frm = FrmGetActiveForm();
	
	numRecords = DmNumRecordsInCategory(MemoPadDB,dmAllCategories);
	if (numRecords)
		{

		itemIndex = FrmGetObjectIndex(frm, SelectMemoMemoListList);
		lst = FrmGetObjectPtr(frm,itemIndex);
	
		// Get the usable width of the list rectangle.
		FrmGetObjectBounds (frm, itemIndex, &lstRect);
		lstWidth = lstRect.extent.x - 2;
		
		// Allocate an initial block for the list choices.
		ChoicesHandle = MemHandleNew(sizeof(char));
	
		// Lock down the block and set it's initial value to an empty string.
		choices = MemHandleLock(ChoicesHandle);
		*choices = 0;
		
		// Build up the choices.  
		// A sequence of strings packed one after another, one for each record.
		for (itemIndex = 0; itemIndex < numRecords; itemIndex++)
			{ 
			// Retrieve the record from the database and lock it down.
			recHandle = DmQueryNextInCategory(MemoPadDB, &itemIndex,dmAllCategories);
			if(recHandle != NULL) {
			recText = MemHandleLock(recHandle);
			
			// Determine the length of text that will fit within the list bounds.
			i = lstWidth;
			textLen = StrLen(recText);
			FntCharsInWidth(recText, &i, &textLen, &fits);
			
			// Grow the choices buffer to accomodate the new string. We must unlock
			// the chunk so that the Memory Manager can move the chunk if neccessary to
			// grow it.
			MemHandleUnlock(ChoicesHandle);
			error = MemHandleResize(ChoicesHandle, textLen + choicesOffset + sizeof('\0'));
			choices = MemHandleLock(ChoicesHandle);
			
			// Check for fatal error.
			ErrFatalDisplayIf(error, "Could not grow choices for list.");
		
			// Copy the text from the record to the choices buffer.
			for (i = 0; i < textLen; i++)
				choices[choicesOffset + i] = recText[i];
	
			// Update the end of choices offset and set a zero terminator 
			// on the string in the choices buffer.
			choicesOffset += textLen;
			choices[choicesOffset++] = 0;
	
			// Unlock the handle to the record.
			MemHandleUnlock(recHandle);
			} else {
				error=DmGetLastErr();
			}
			// Release the record, not dirty.
			error=DmReleaseRecord(MemoPadDB, itemIndex, false);
			}
		// Create an array of pointers from the choices strings.
		ChoicesPtrsHandle = SysFormPointerArrayToStrings(choices, numRecords);
		
		// Set the list choices from the array of pointers.
		LstSetListChoices(lst, MemHandleLock(ChoicesPtrsHandle), numRecords);
			MemHandleUnlock(ChoicesHandle);
			MemHandleUnlock(ChoicesPtrsHandle);
		}
	
	// Draw the form.
	FrmDrawForm(frm);
}

void SelectMemoFormDeInit(FormPtr /*frm*/){
}

int render_memo_db(UInt16 index,Boolean print_all){

	CharPtr			memoText;
	Handle			memoHandle;
	
	DmOpenRef		MemoPadDB;
	UInt			numRecords;
	UInt			mode;
	VoidHand 		ChoicesHandle = 0;
	
	UInt32			BufferSize=1024;
	Err				error;


	
	mode = dmModeReadOnly;
	MemoPadDB = DmOpenDatabaseByTypeCreator(DBType, memoPadAppType,mode);

	write_rtf_header();

	if (! print_all) {
	// Retrieve the record from the database and lock it down.
	memoHandle = DmQueryNextInCategory(MemoPadDB, &index,dmAllCategories);
	if(memoHandle != NULL) {	

		memoText = MemHandleLock(memoHandle);
	
		append_string(memoText);

		MemHandleUnlock(memoHandle);
		error=DmReleaseRecord(MemoPadDB, index, false);

		write_rtf_end();
	}
	} else {
	numRecords = DmNumRecordsInCategory(MemoPadDB,dmAllCategories);
	for (index=0;index<numRecords;index++) {
		if(memoHandle != NULL) {
				memoHandle = DmQueryRecord(MemoPadDB, index);
			
				memoText = MemHandleLock(memoHandle);
	

		// Release the record, not dirty.
		error=DmReleaseRecord(MemoPadDB, index, false);
	
			append_string(memoText);

			MemHandleUnlock(memoHandle);
		
			append_string("\\par **************** \\par ");
			}
		}	
	}
	write_rtf_end();

	return(true);
}

Boolean SelectMemoFormHandleEvent(EventPtr eventP)
{
   Boolean handled = false;
   FormPtr frmP;
   Word		CurrentRecord;
//   ControlType CheckBox_control;

	switch (eventP->eType) {
	case frmOpenEvent:
			frmP = FrmGetActiveForm();
			SelectMemoFormInit( frmP);
			FrmDrawForm ( frmP);
			handled = true;
			break;
			
	case frmCloseEvent:
			frmP = FrmGetActiveForm();
			SelectMemoFormDeInit(frmP);
			handled = true;
			break;

   	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// If the done button is pressed, go back to the main form.
	   	if (eventP->data.ctlEnter.controlID == SelectMemoAboutButton)
	  		 	{
	  		 	LastView=CurrentView;
				CurrentView=AboutForm;
				FrmGotoForm(CurrentView);
				handled = true;
				}
				
	   	if (eventP->data.ctlEnter.controlID == SelectMemoBackButton)
	  		 	{
				CurrentView=SelectDOCForm;
				FrmGotoForm(CurrentView);
				handled = true;
				}
				

	   	if (eventP->data.ctlEnter.controlID == SelectMemoNextButton)
	  		 	{
				frmP = FrmGetActiveForm();
				CurrentRecord = LstGetSelection(FrmGetObjectPtr(frmP,
				 FrmGetObjectIndex(frmP, SelectMemoMemoListList)));

				render_memo_db(CurrentRecord,CtlGetValue(FrmGetObjectPtr(frmP,
				 	FrmGetObjectIndex(frmP, SelectMemoPrintAllCheckbox))));
	  		 	LastView=CurrentView;
	  		 	CurrentView=SerialConfigForm;
				FrmGotoForm(CurrentView);

				handled = true;
	  		 	}

			break;
		
		default:
			break;
		
		}
	
	return handled;
}


