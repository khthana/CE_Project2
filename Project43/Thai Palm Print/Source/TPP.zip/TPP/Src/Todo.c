#include <PalmOS.h>
#include "todoDB.h"
#include "todo.h"
#include "StarterRsc.h"
#include "rtf.h"
#include <PalmCompatibility.h>


#define DBType 'DATA'
#define todoAppType 'todo'

//typedef ToDoDBRecord	ToDoDBRecordType;
//typedef ToDoDBRecord*	ToDoDBRecordPtr;

extern Word LastView,CurrentView;

/*************************************************************
 *
 *	Prototype definition
 *
 *************************************************************/


/***********************************************************************
 *
 * FUNCTION:     ToDoGetDatabase
 *
 * DESCRIPTION:  Get the application's database.  Open the database if it
 * exists, create it if neccessary.
 *
 * PARAMETERS:   *dbPP - pointer to a database ref (DmOpenRef) to be set
 *					  mode - how to open the database (dmModeReadWrite)
 *
 * RETURNED:     Err - zero if no error, else the error
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			jmp		10/04/99	Initial Revision
 *
 ***********************************************************************/
Err ToDoGetDatabase (DmOpenRef *dbPP, UInt16 mode)
{

	DmOpenRef dbP;

	*dbPP = NULL;
  
  // Find the application's data file.  If it doesn't exist create it.
	dbP = DmOpenDatabaseByTypeCreator (toDoDBType, sysFileCToDo, mode);
	*dbPP = dbP;
	return 0;
}

void render_todo_db(){
	UInt				mode;
	DmOpenRef 			todoDB;
   	MemHandle			recordH,todo_descriptionHandle,Date_strHandle;
   	UInt32				index;
	ToDoDBRecordPtr		todoRecPtr;
	
	UInt16				numRecords,n,m;
	
	MemPtr				todo_description,Date_str;
	
	index=0;
	mode = dmModeReadOnly;
	todoDB = DmOpenDatabaseByTypeCreator(DBType, todoAppType,mode);

	numRecords = DmNumRecordsInCategory(todoDB,dmAllCategories);
	
	write_rtf_header();
	
	set_fontsize("32");
	set_fonttype("18");
	append_string("Todo List");
	rtf_newline();
	
	set_fontsize("20");
	set_fonttype("18");
	todo_descriptionHandle = MemHandleNew(20);
	for(n=0;n<numRecords;n++) {
		recordH = DmGetRecord(todoDB, n);
		todoRecPtr = MemHandleLock(recordH);

		if(todoRecPtr->priority<128) {
			m=StrLen((char *)&(todoRecPtr->description));
			MemHandleResize(todo_descriptionHandle,m+1);
			todo_description=MemHandleLock(todo_descriptionHandle);

			StrPrintF(todo_description,"     - %d - ",(todoRecPtr->priority&0x8f));
			append_string(todo_description);
		
			MemMove(todo_description,&((todoRecPtr->description)),m+1);
			append_string(todo_description);

			MemHandleUnlock(todo_descriptionHandle);
			MemHandleResize(todo_descriptionHandle,m+1);
			todo_description=MemHandleLock(todo_descriptionHandle);

			if ((todoRecPtr->dueDate).month<=12) {
				append_string("  ( ");
				DateToAscii((todoRecPtr->dueDate).month,
					(todoRecPtr->dueDate).month,(todoRecPtr->dueDate).year+1904,dfMDYLongWithComma,todo_description);
				append_string(todo_description);
				append_string(" ) ");
			}
			rtf_newline();
		
			MemHandleUnlock(todo_descriptionHandle);
		}
		MemHandleUnlock(recordH);
		DmReleaseRecord(todoDB,n, false);
	}
	write_rtf_end();

}
