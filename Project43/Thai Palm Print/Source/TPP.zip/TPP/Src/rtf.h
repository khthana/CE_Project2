extern int write_rtf_header();
extern int append_char();
extern int write_rtf_end();
extern int rtf_newline();
extern void append_string();
extern void set_fontsize();
extern void set_fonttype();