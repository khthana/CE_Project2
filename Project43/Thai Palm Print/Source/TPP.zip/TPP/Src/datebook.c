#include "datebook.h"
#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <DataMgr.h>
#include "rtf.h"
#include "StarterRSC.h"
#include <DateTime.h>
#include <PalmTypes.h>

#define  Date_str_len  12

extern Word CurrentView,LastView;
Int16 	from_month,from_year,from_day,to_month,to_year,to_day;
DateType fromdate,todate;

Boolean DateBeyond();

/************************************************************
 *
 *  FUNCTION: ApptUnpack
 *
 *  DESCRIPTION: Fills in the ApptDBRecord structure
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the record unpacked
 *
 *  CREATED: 1/25/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
void ApptUnpack(ApptPackedDBRecordPtr src, ApptDBRecordPtr dest)
{
	ApptDBRecordFlags	flags;
	char *p;

	
	flags = src->flags;
	p = &src->firstField;

	dest->when = (ApptDateTimeType *) src;
	
	if (flags.alarm) 
		{
		dest->alarm = (AlarmInfoType *) p;
		p += sizeof (AlarmInfoType);
		}
	else
		dest->alarm = NULL;

	
	if (flags.repeat)
		{
		dest->repeat = (RepeatInfoType *) p;
		p += sizeof (RepeatInfoType);
		}
	else
		dest->repeat = NULL;
	
	
	if (flags.exceptions)
		{
		dest->exceptions = (ExceptionsListType *) p;
		p += sizeof (UInt16) + 
			(((ExceptionsListType *) p)->numExceptions * sizeof (DateType));
		}
	else
		dest->exceptions = NULL;
		
	
	if (flags.description)
		{
		dest->description = p;
		p += StrLen(p) + 1;
		}
	else
		dest->description = NULL;
		
	
	if (flags.note)
		{
		dest->note = p;
		}
	else
		dest->note = NULL;
	
}


Err ApptGetRecord (DmOpenRef dbP, UInt16 index, ApptDBRecordPtr r, 
	MemHandle * handleP)
{
	MemHandle handle;
	ApptPackedDBRecordPtr src;
	

	handle = DmQueryRecord(dbP, index);
	ErrFatalDisplayIf(DmGetLastErr(), "Error Querying record");
	
	src = (ApptPackedDBRecordPtr) MemHandleLock (handle);

	if (DmGetLastErr())
		{
		*handleP = 0;
		return DmGetLastErr();
		}
	
	ApptUnpack(src, r);
	
	*handleP = handle;
	return 0;
}

void render_datebook_db(Int16 from_day,Int16 from_month,Int16 from_year,
						Int16 to_day,Int16 to_month,Int16 to_year){
	UInt32 				n,count=0;
	UInt				mode;
	
	DmOpenRef 			datebookDB;
   	MemHandle			recordH,TimeStrH;
	ApptDBRecordPtr		datebookRecPtr;
	
	UInt16				numRecords;
	MemPtr				TimeStrPtr;
	
	Int16				month,day,year;
	
	
	mode = dmModeReadOnly;
	

	
	datebookDB = DmOpenDatabaseByTypeCreator(DBType, datebookAppType,mode);
	

	numRecords = DmNumRecordsInCategory(datebookDB,dmAllCategories);
	
	write_rtf_header();
	
	set_fontsize("32");
	set_fonttype("18");
	append_string("DateBook");
	rtf_newline();
	
	set_fontsize("20");
	set_fonttype("18");
	
	recordH=MemHandleNew(sizeof(ApptDBRecordType));
	datebookRecPtr=MemHandleLock(recordH);
	
	TimeStrH=MemHandleNew(30);
	TimeStrPtr=MemHandleLock(TimeStrH);

	for(n=0;n<numRecords;n++) {

		ApptGetRecord (datebookDB,n,datebookRecPtr, &recordH);

		if ((DateBeyond(((datebookRecPtr->when)->date),fromdate)) && (todate,DateBeyond(((datebookRecPtr->when)->date))) )
			{

			DateToAscii (((datebookRecPtr->when)->date).month,((datebookRecPtr->when)->date).day,((datebookRecPtr->when)->date).year+1904,
				dfMDYLongWithComma,TimeStrPtr);
			append_string(TimeStrPtr);
			append_string(" : ");
			
			TimeToAscii (((datebookRecPtr->when)->startTime).hours,((datebookRecPtr->when)->startTime).minutes,
					false,TimeStrPtr);
			append_string(TimeStrPtr);
			append_string(" - ");
			
			TimeToAscii (((datebookRecPtr->when)->endTime).hours,((datebookRecPtr->when)->endTime).minutes,
					false,TimeStrPtr);
			append_string(TimeStrPtr);

			append_string(" : ");
			append_string(datebookRecPtr->description);
			rtf_newline();

		}
		DmReleaseRecord(datebookDB, n, false);
		count++;
	}
	MemHandleUnlock(TimeStrH);
	MemHandleUnlock(recordH);

	write_rtf_end();
}


void SelectDateBookFormInit(FormPtr frm){
   DateTimeType dateTime;

	TimSecondsToDateTime (TimGetSeconds (),&dateTime);
	from_year = dateTime.year;
	from_month = dateTime.month;
	from_day = dateTime.day;
				
	TimSecondsToDateTime (TimGetSeconds (),&dateTime);
	to_year = dateTime.year;
	to_month = dateTime.month;
	to_day = dateTime.day;
}

void SelectDateBookFormDeInit(FormPtr frm){
	
}


Boolean SelectDateBookFormHandleEvent(EventPtr eventP)
{
   Boolean handled = false;
   FormPtr frmP;
   Word		CurrentRecord;
   ControlType CheckBox_control;

   CharPtr  Date_str;
   MemHandle Date_strHandle;
   ControlType *ButtomControl;
   
   Boolean 	Date_ok;

	switch (eventP->eType) {
	case frmOpenEvent:

			frmP = FrmGetActiveForm();
			SelectDateBookFormInit( frmP);
			FrmDrawForm ( frmP);
			handled = true;
			break;
			
	case frmCloseEvent:
			frmP = FrmGetActiveForm();
			SelectDateBookFormDeInit(frmP);
			break;

	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// If the done button is pressed, go back to the main form.
	   	if (eventP->data.ctlEnter.controlID == SelectDateBookAboutButton)
	  		 	{
	  		 	LastView=CurrentView;
				CurrentView=AboutForm;
				FrmGotoForm(CurrentView);
				handled = true;
				}
				
	   	if (eventP->data.ctlEnter.controlID == SelectDateBookBackButton)
	  		 	{
				CurrentView=SelectDOCForm;
				FrmGotoForm(CurrentView);
				handled = true;
				}
				

	   	if (eventP->data.ctlEnter.controlID == SelectDateBookNextButton)
	  		 	{

	  		 	Date_ok = true;
	  		 	if (!DateBeyond(todate,fromdate)){
	  		 		FrmCustomAlert( DateAlert, "End is beyond Start","", "");
	  		 		Date_ok = false;
	  		 	}
	  		 	
	  		 	if (Date_ok) {
	  		 	render_datebook_db(from_day,from_month,from_year,to_day,to_month,to_year);
	  		 	LastView=CurrentView;
	  		 	CurrentView=SerialConfigForm;
				FrmGotoForm(CurrentView);
				}

				handled = true;
	  		 	}
	   	// If the done button is pressed, go back to the main form.

	   	if (eventP->data.ctlEnter.controlID == SelectDateBookFromButton)
	  		 	{
//				SelectDay(selectDayByDay,&(fromdate.month),&from_day,&from_year,"Select day to print");
				SelectDay(selectDayByDay,&from_month,&from_day,&from_year,"Select day to print");
				
				fromdate.year=from_year-1904;
				fromdate.day=from_day;
				fromdate.month=from_month;				

				Date_strHandle=MemHandleNew(Date_str_len);
				Date_str=MemHandleLock(Date_strHandle);
				DateToAscii (from_month,from_day,from_year,dfMDYLongWithComma,Date_str);

				frmP = FrmGetActiveForm();
				ButtomControl=FrmGetObjectPtr(frmP,FrmGetObjectIndex(frmP,SelectDateBookFromButton));
				CtlSetLabel(ButtomControl,Date_str);

				MemHandleUnlock(Date_strHandle);

				handled = true;
				}
				
				
			if (eventP->data.ctlEnter.controlID == SelectDateBookToButton)
	  		 	{
				SelectDay(selectDayByDay,&to_month,&to_day,&to_year,"Select day to print");

				todate.year=to_year-1904;
				todate.day=to_day;
				todate.month=to_month;				

				Date_strHandle=MemHandleNew(Date_str_len);
				Date_str=MemHandleLock(Date_strHandle);
				DateToAscii (to_month,to_day,to_year,dfMDYLongWithComma,Date_str);
				
				frmP = FrmGetActiveForm();
				ButtomControl=FrmGetObjectPtr(frmP,FrmGetObjectIndex(frmP,SelectDateBookToButton));
				CtlSetLabel(ButtomControl,Date_str);
				
				MemHandleUnlock(Date_strHandle);

				handled = true;
				}



			break;
			
			default:
				break;
		
		}
	
	return handled;
}