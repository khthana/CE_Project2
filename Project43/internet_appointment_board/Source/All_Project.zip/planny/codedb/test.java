import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.net.*;
public class ToDo extends HttpServlet
{   protected  void  doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {    HttpSession session = req.getSession(true);
         Object UserID =  session.getValue("login.username");	
         Connection theConnection;
          String Title      = req.getParameter("textfield");
          String Freqdate      = req.getParameter("dateToDo");
          String FreqMonth      = req.getParameter("MonthToDo");
          String FreqYear      = req.getParameter("YearToDo");
          String Priority      = req.getParameter("radiobutton");
          String Note      = req.getParameter("NoteToDo");
          PrintWriter out = res.getWriter();
           try{
                                               //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                               //if (Note.equals(""))
                                                out.println("OK");
                                                    theStatement.executeQuery(
                                                        "INSERT INTO test"
                                                           + "(name)"
                                                           //+"values( to_date(' "+Freqdate+"/"+FreqMonth+"/" +FreqYear+"',"
                                                          // +" 'dd/mm/yyyy'))");
                                                          +"values('kate')");
                                                              theStatement.close();//Close statement
                                               theConnection.close();                                         
                             }   catch (Exception e)  
                                               {  
                                                  out.println(e.getMessage()); 
                                               }  
                         }
               }