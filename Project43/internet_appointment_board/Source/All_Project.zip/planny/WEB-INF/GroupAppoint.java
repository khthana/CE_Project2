import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.lang.String;
public class GroupAppoint  extends HttpServlet
    {   String DefaultURL="http://161.246.5.233:8080/planny"; 
         Connection theConnection;
         protected void doPost(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException
         {   HttpSession session = req.getSession(true);
              String UserID = (String)session.getValue("login.username");	
              if ( UserID==null  ) {  res.sendRedirect(DefaultURL);  }
              else session.putValue("lgoin.username",UserID);
              int GASelect = Integer.parseInt(req.getParameter("GASelect"));
              int  [ ]no = req.getParameterValues("GASelect"); 
              String GATitle = req.getParameter("GATitle");
              String GAPlace = req.getParameter("GAPlace");
              String GAType = req.getParameter("GAType");
              int GADay    = Integer.parseInt(req.getParameter("GADay"));
              int GAMonth = Integer.parseInt(req.getParameter("GAMonth"));
              int GAYear   = Integer.parseInt(req.getParameter("GAYear"));
              int GAHour   = Integer.parseInt(req.getParameter("GAHour"));
              int GAMin     = Integer.parseInt(req.getParameter("GAMin"));
              String GANote = req.getParameter("GANote");
              String GAForm = req.getParameter("GAFrom");
              String NoNum = req.getParameter("HiddenNo");
              String Submit = req.getParameter("Submit");
              String Another = req.getParameter("SubmitAnother");
              String Cancel = req.getParameter("Cancel");
              int No = 0;
              String MemID="";
              Calendar GCalendar = new GregorianCalendar(GAYear,GAMonth,GADay,GAHour,GAMin);
              int GDay = GCalendar.get(GCalendar.DAY_OF_MONTH);
              int GMonth = GCalendar.get(GCalendar.MONTH)+1;
              int GYear = GCalendar.get(GCalendar.YEAR);
              int GHour = GCalendar.get(GCalendar.HOUR_OF_DAY);
              int GMin = GCalendar.get(GCalendar.MINUTE);
                if (GATitle.equals("")) GATitle= "No Title";
                if (GAType.equals("")) GAType = "other";  
                  if (GAPlace.equals(""))GAPlace= "No Place";
                 if (GANote.equals("")) GANote = "other";  
              
               try{    Class.forName("oracle.jdbc.driver.OracleDriver");
                                     theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                 }  catch (Exception e) {    res.setContentType("text/html");
                                                                                  PrintWriter out = res.getWriter();
                                 	                                       out.println(e.getMessage()); }
                             
               
               /* res.setContentType("text/html");
                        PrintWriter out = res.getWriter();
                        out.println(GASelect);*/
              
               try{    Statement  theStatement=theConnection.createStatement();
                                               theStatement.executeQuery(
                                               "insert into groupcal values(no_group.nextval,"+GASelect+",' "+UserID+"')");
                         theStatement.close();//Close statement
                      }   catch (Exception e)   
                                               {  res.setContentType("text/html");
                                                   PrintWriter out = res.getWriter();
                                                   out.println(e.getMessage()); } 
             try{    Statement  theStatement=theConnection.createStatement();      
                         ResultSet theResult = theStatement.executeQuery(    
                           "select no_group from groupcal");
                           while (theResult.next()) No= theResult.getInt(1);     
                         theStatement.close();//Close statement
                     }   catch (Exception e)   
                                        {  res.setContentType("text/html");
                                           PrintWriter out = res.getWriter();
                                            out.println(e.getMessage()); } 
                                            
            try{    Statement  theStatement=theConnection.createStatement();      
                         ResultSet theResult = theStatement.executeQuery(    
                         " select  idmem from member where no_mem="+GASelect);
                           while (theResult.next()) MemID= theResult.getString(1);     
                         theStatement.close();//Close statement
                     }   catch (Exception e)   
                                        { res.setContentType("text/html");
                                           PrintWriter out = res.getWriter();
                                            out.println(e.getMessage()); } 
           /* res.setContentType("text/html");
               PrintWriter out = res.getWriter();
               out.println("b"+No+"b<br/>");                               
               out.println("b"+MemID+"b<br/>");*/                                                                           
          try{    Statement  theStatement=theConnection.createStatement();
                                               theStatement.executeQuery(
                         "INSERT INTO calendar"
                                                           + "(no_cal,time,id,to_time,title,type,place,note,no_rep,no_rem,no_group,from_gr,check_mode,freq_rep)"
                                                           + "values( no_cal.nextval, to_date('"+GDay+"/" +GMonth+"/"+GYear+"  "
                                                           +GHour+":"+GMin+ "','dd/mm/yyyy hh24:mi'),' "+UserID+"'"+
                                                           ",to_date('"+GDay+"/"+GMonth+"/"+GYear+ " "+ GHour+":"+GMin+" ','dd/mm/yyyy hh24:mi'),' "
                                                           +GATitle+"','"+GAType+"','"+GAPlace+"','"+GANote+"',1,1,"+No+",'"+GAForm+"',2"
                                                           +", to_date('"+GDay+"/" +GMonth+"/"+GYear+"  "
                                                           +GHour+":"+GMin+ "','dd/mm/yyyy hh24:mi'))");
                                    theStatement.close();//Close statement
                                    }   catch (Exception e)   
                                               { res.setContentType("text/html");
                                                   PrintWriter out = res.getWriter();
                                                   out.println(e.getMessage()); } 
                                                   
              try{    Statement  theStatement=theConnection.createStatement();
                                               theStatement.executeQuery(
                         "INSERT INTO calendar"
                                                           + "(no_cal,time,id,to_time,title,type,place,note,no_rep,no_rem,no_group,from_gr,check_mode,freq_rep)"
                                                           + "values( no_cal.nextval, to_date('"+GDay+"/" +GMonth+"/"+GYear+"  "
                                                           +GHour+":"+GMin+ "','dd/mm/yyyy hh24:mi'),'"+MemID+"'"+
                                                           ",to_date('"+GDay+"/"+GMonth+"/"+GYear+ " "+ GHour+":"+GMin+" ','dd/mm/yyyy hh24:mi'),' "
                                                           +GATitle+"','"+GAType+"','"+GAPlace+"','"+GANote+"',1,1,"+No+",'"+GAForm+"',2"
                                                            +", to_date('"+GDay+"/" +GMonth+"/"+GYear+"  "
                                                           +GHour+":"+GMin+ "','dd/mm/yyyy hh24:mi'))");
                                    theStatement.close();//Close statement
                                   theConnection.close(); 
                             }   catch (Exception e)   
                                               { res.setContentType("text/html");
                                                   PrintWriter out = res.getWriter();
                                                   out.println(e.getMessage()); } 
           if(  Submit != null  )  {res.sendRedirect(DefaultURL+"/servlet/gCalendar");}
               else if (Another != null) { res.sendRedirect(DefaultURL+"/servlet/ShowUpdateGroup?m="+NoNum);}
                       else if (Cancel != null)res.sendRedirect(DefaultURL+"/servlet/gCalendar");       
                       
          }
     } 