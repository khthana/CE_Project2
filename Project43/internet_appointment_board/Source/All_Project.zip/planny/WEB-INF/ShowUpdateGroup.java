import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ShowUpdateGroup extends HttpServlet
 {   String DefaultURL="http://161.246.5.233:8080/planny"; 
      Connection theConnection;
      static final int  CurDate      =  Calendar.getInstance().get(Calendar.DAY_OF_MONTH); 
      static final int  CurMonth   =  Calendar.getInstance().get(Calendar.MONTH); 
      static final int  CurYear      =  Calendar.getInstance().get(Calendar.YEAR); 
      static final int  CurHour      =  Calendar.getInstance().get(Calendar.HOUR_OF_DAY); 
      
      static final  String [] MonthName = {"January","February","March","April","May", "June","July","August","September","October","November","December"};
      protected void doGet(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException
       {     HttpSession session = req.getSession(true);
             String UserID = (String)session.getValue("login.username");
              String title ="";
              String type ="";
              String note="";
              boolean check = false;
              if ( UserID==null  ) {  res.sendRedirect(DefaultURL);  }
               else session.putValue("lgoin.username",UserID);
             int NoNum = Integer.parseInt(req.getParameter("m")); 
             res.setContentType("text/html");
             PrintWriter out = res.getWriter(); 
             out.println("<HTML><HEAD><TITLE>Planny Organizer</TITLE>");
             out.println("<META content=\"text/html; charset=windows-874\" http-equiv=Content-Type>");
             out.println("<STYLE type=text/css>BODY {MARGIN: 0px; PADDING-BOTTOM: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; PADDING-TOP: 0px}");
             out.println("A:link {Color: #005ca2; TEXT-DECORATION: none}");
             out.println("A:visited {Color: #005ca2; TEXT-DECORATION: none}");
             out.println("A:active {Color: #0099ff; TEXT-DECORATION: underline}");
             out.println("A:hover {Color: #0099ff; TEXT-DECORATION: underline}");
            out.println("</STYLE><META content=\"MSHTML 5.00.2614.3500\" name=GENERATOR></HEAD>");
            out.println("<BODY bgColor=#ffffff>");
            out.println("<TABLE border=0 height=\"100%\" width=\"100%\"><TBODY>");
            out.println("<TR><TD bgColor=#49b0fc height=84 rowSpan=3 width=\"19%\">&nbsp;</TD>");
            out.println("<TD height=25 width=\"17%\">&nbsp;</TD>");
            out.println("<TD height=25 width=\"64%\">&nbsp;</TD></TR>");
            out.println("<TR><TD align=middle colSpan=2 height=57 vAlign=center><IMG height=51 src=\"/planny/picture/logo4.jpg\" width=360></TD></TR>");
             out.println("<TR><TD colSpan=2 height=365 vAlign=top>");
             
             out.println("<FORM action="+DefaultURL+"/servlet/UpdateGroup  method=post>");
             out.println("<TABLE border=0 width=\"100%\"><TBODY>");
             out.println("<TR><TD height=25 width=65>&nbsp;</TD>");
             out.println("<TD height=25 width=165>&nbsp;</TD>");
             out.println("<TD height=25 width=155>&nbsp;</TD>");
             out.println("<TD height=25 width=174>&nbsp;</TD>");
             out.println("<TD height=25 width=58>&nbsp;</TD></TR>");
             out.println("<TR><TD height=25 width=65>&nbsp;</TD>");
             out.println("<TD bgColor=#94b7f1 colSpan=3 height=25>"); 
             out.println("<TABLE border=0 width=\"100%\"><TBODY>");
             out.println("<TR><TD bgColor=#ccffff height=23 vAlign=center>&nbsp; <Font  face=Arial size=2>&nbsp;<B>Edit Group </B></FONT></TD>");
             out.println("</TR></TBODY></TABLE></TD><TD height=25 width=58>&nbsp;</TD></TR><TR><TD height=25 width=65>&nbsp;</TD>");
             out.println("<TD align=middle bgColor=#49b0fc colSpan=3 rowSpan=3 height=178><table width=\"100%\" border=\"0\">");
             out.println("<tr><td width=\"7%\">&nbsp;</td><td width=\"18%\" valign=\"bottom\"><b><font size=\"2\">Group Name</font></b></td>");
                 try{  Class.forName("oracle.jdbc.driver.OracleDriver");
                          theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                          Statement  theStatement=theConnection.createStatement();
                          ResultSet theResult = theStatement.executeQuery(  "select groupname,grouptype,notegr from member where no_mem="+NoNum);
                          while (theResult.next()){
                          	title=theResult.getString(1);
                          	type=theResult.getString(2);
             out.println("<td width=\"75%\" valign=\"bottom\"><input type=\"text\" name=\"EGName\" size=\"30\" value=\""+theResult.getString(1)+"\"></td></tr><tr> <td width=\"7%\">&nbsp;</td> ");
             out.println("<td valign=\"bottom\" width=\"18%\"><b><font size=\"2\">Group Type</font></b></td><td valign=\"bottom\" width=\"75%\">");
             out.println("<select name=\"EGType\" size=\"1\">");
             out.print("<option value=\"Other\" selected");
             if(theResult.getString(2).equals("Other")) out.print("selected");
             out.println(">Other</option>");
             out.print("<option value=\"Chat\""); 
             if(theResult.getString(2).equals("Chat")) out.print("selected");
             out.println(">Chat</option>");
             out.print("<option value=\"Clubs\"");
             if(theResult.getString(2).equals("Clubs")) out.print("selected");
             out.println(">Clubs</option>");
             out.print("<option value=\"Games\"");
             if(theResult.getString(2).equals("Games")) out.print("selected");
             out.println(">Games</option>");
             out.print("<option value=\"Friends\"");
             if(theResult.getString(2).equals("Friends")) out.print("selected");
             out.println(">Friends</option>");
             out.print("<option value=\"Sports\"");
             if(theResult.getString(2).equals("Sports")) out.print("selected");
             out.println(">Sports</option>");
             out.println("</select></td></tr>");
               }//while
               theStatement.close();//Close statement
               theConnection.close();
                   }   catch (Exception e)   {
                       out.println(e.getMessage()); } 
             out.println("<tr><td width=\"7%\">&nbsp;</td><td width=\"18%\" valign=\"bottom\">");
             out.println("<font size=\"2\"><b>Member</b></font></td><td width=\"75%\" valign=\"bottom\">");
             out.println("<select name=\"EGMember\" size=\"1\">");        
                try{     Class.forName("oracle.jdbc.driver.OracleDriver");
                            theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                            Statement  theStatement=theConnection.createStatement();
                            ResultSet theResult = theStatement.executeQuery(  "select groupname,grouptype,membername,no_mem,notegr  from member "+
                                  "where id <> idmem and id = ' "+UserID+"' order  by groupname , grouptype");
                               while (theResult.next()){ 
                                             if (title.equals(theResult.getString(1)) && type.equals(theResult.getString(2))  )
                                             { out.println("<option value=\""+theResult.getInt(4)+"\">"+theResult.getString(3)+"</option>");
                                                note=theResult.getString(5);
                                                check = true; } 
                                          }//while
                    theStatement.close();//Close statement
                    theConnection.close();
                   }   catch (Exception e)   {
              out.println(e.getMessage()); }   
              if (!check)   out.println("<option value=\"0\">-</option>");                                            
             out.println("</select></td>");
             out.println("</tr><tr><td width=\"7%\">&nbsp;</td><td valign=\"top\" width=\"18%\"><font size=\"2\"><b>Note</b></font></td><td width=\"75%\">"); 
             if (note!=null) {
             out.println("<TextArea name=\"EGNote\" rows=\"2\" cols=\"30\">"+note+"</textarea></td></tr><tr valign=\"bottom\"><td width=\"7%\" height=\"35\">&nbsp;</td>");}
             else{ out.println("<TextArea name=\"EGNote\" rows=\"2\" cols=\"30\"></textarea></td></tr><tr valign=\"bottom\"><td width=\"7%\" height=\"35\">&nbsp;</td>");}
             out.println("<td colspan=\"2\" align=\"right\" height=\"35\"><input type=\"hidden\" name=\"HiddenTitle\" value=\""+title+"\">");
             out.println("<input type=\"hidden\" name=\"HiddenType\" value=\""+type+"\">");
             out.println("<input name=EGUpdate type=submit value=\"  Update   \">&nbsp;<input name=EGDelete type=submit value=\"  Delete   \">");
             out.println("<input name=EGCancel type=submit value=\"  Cancel  \"></td></tr></table></TD><TD height=25 width=58>&nbsp;</TD></TR>");
             out.println("<TR><TD height=25 width=65>&nbsp;</TD><TD height=25 width=58>&nbsp;</TD></TR><TR><TD height=25 width=65>&nbsp;</TD>");
             out.println("<TD height=25 width=58>&nbsp;</TD></TR></TBODY></TABLE></FORM>");
             
             out.println("<FORM action=\""+DefaultURL+"/servlet/UpdateMemberG\"  method=post>");
             out.println("<TABLE border=0 width=\"100%\"><TBODY><TR><TD height=25 width=60>&nbsp;</TD>");
             out.println("<TD bgColor=#94b7f1 colSpan=3 height=25><TABLE border=0 width=\"100%\"><TBODY>"); 
             out.println("<TR><TD bgColor=#ccffff height=23 vAlign=center>&nbsp; <FONT face=Arial size=2>&nbsp;<B>Edit Member</B></FONT></TD>");
             out.println("</TR></TBODY></TABLE></TD><TD height=25 width=56>&nbsp;</TD></TR>");
             check = false;
             
              try{     Class.forName("oracle.jdbc.driver.OracleDriver");
                            theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                            Statement  theStatement=theConnection.createStatement();
                            ResultSet theResult = theStatement.executeQuery(  "select groupname,grouptype,membername,no_mem,note,idmem,status  from member "+
                                  "where id <> idmem and id = ' "+UserID+"' order  by groupname , grouptype");
                               while (theResult.next()){ 
                                             if (title.equals(theResult.getString(1)) && type.equals(theResult.getString(2))  )
                                             { out.println("<TR> <TD height=25 width=60>&nbsp;</TD><TD colSpan=3><table border=0 width=\"100%\"><tbody><tr><td bgcolor=#49b0fc height=100 valign=top>");
                                                out.println("<table border=0 width=\"100%\">");
                                                out.println("<tbody><tr><td align=right height=30><font size=2></font></td><td height=25 valign=bottom width=\"38%\"><font size=2>"); 
                                                out.print("<input name=MemberRadio type=\"radio\" value=\""+theResult.getInt(4)+"\"");
                                                 out.println("><b>Planny ID : </b>"+theResult.getString(6)+"</font></td>");
                                                out.println("<td height=25 valign=bottom width=\"2%\">&nbsp;</td><td height=25 valign=bottom width=\"54%\"><font  size=2><b>Member Name</b><br>");
                                                out.println("<input name=EMName size=28  value=\""+theResult.getString(3)+"\"></font></td></tr><tr> <td align=right><font size=2></font></td>");
                                                out.println("<td height=25 valign=bottom width=\"38%\"><font size=2><b>Status</b><br><input name=EMStatus size=28  value=\""+theResult.getString(7)+"\">");
                                                out.println("</font></td><td height=25 valign=bottom width=\"2%\">&nbsp;</td>");
                                                out.println("<input type=\"hidden\" name=\"HiddenTitle\" value=\""+title+"\"><input type=\"hidden\" name=\"HiddenType\" value=\""+type+"\">");
                                                if (theResult.getString(5) != null) {
                                                out.println("<td height=25 valign=bottom width=\"54%\"><font size=2><b>Note<br>");
                                                out.println("</b><input name=EMNote size=28  value=\""+theResult.getString(5)+"\"></font></td></tr></tbody></table></td></tr></tbody></table>");
                                                                                                        }
                                                else {
                                                	out.println("<td height=25 valign=bottom width=\"54%\"><font size=2><b>Note<br>");
                                                                out.println("</b><input name=EMNote size=28  ></font></td></tr></tbody></table></td></tr></tbody></table>");
                                                          }
                                                check = true; } //if
                                                  }//while
                    theStatement.close();//Close statement
                    theConnection.close();
                   }   catch (Exception e)   {
              out.println(e.getMessage()); }   
              if (!check)  { out.println("<TR align=center><TD height=28 width=60>&nbsp;</TD>");
                                     out.println("<TD colSpan=3 height=\"28\" bgcolor=\"#49b0fc\"><font size=2>- No Member Data -</font></TD>");
                                     out.println("<TD height=28 width=56>&nbsp;</TD></TR></TBODY></TABLE></FORM>");
                                   }
             else { out.println("<table border=0 width=\"100%\"><tbody><tr><td align=right colspan=2><font face=Arial size=2>");
                         out.println("<input name=EMUpdate type=submit value=\"  Update   \">");
                         out.println("<input name=EMDelete type=submit value=\"  Delete   \">");
                         out.println("<input name=Cancel type=reset  value=\"  Cancel  \">");
                         out.println("</font></td></tr></tbody></table>");  
                         out.println("</TD><TD height=25 width=56>&nbsp;</TD></TR></TBODY></TABLE></FORM>"); 
                      }           

                 out.println("<FORM action=\""+DefaultURL+"/servlet/GroupAppoint\" method=post>");
                 out.println("<TABLE border=0 width=\"100%\"><TBODY><TR><TD height=25 width=60>&nbsp;</TD>");
                 out.println("<TD bgColor=#94b7f1 colSpan=3 height=25><TABLE border=0 width=\"100%\"><TBODY>"); 
                 out.println("<TR><TD bgColor=#ccffff height=23 vAlign=center>&nbsp; <FONT  face=Arial size=2>&nbsp;<B>Group Appointment</B></FONT></TD>");
                 out.println("</TR></TBODY></TABLE></TD><TD height=25 width=56>&nbsp;</TD></TR>");
                 /*");
                 out.println("");*/
                 
                 check = false;
                  try{     Class.forName("oracle.jdbc.driver.OracleDriver");
                              theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                     }   catch (Exception e)   {  out.println(e.getMessage()); }   
                 try{  Statement  theStatement=theConnection.createStatement();
                              ResultSet theResult = theStatement.executeQuery(  "select groupname  from member "+
                                  "where id <> idmem and groupname='"+title+"' and grouptype='"+type+"' and id = ' "+UserID+"'");
                               while (theResult.next()){  check=true;}
                                 theStatement.close();             
                      }   catch (Exception e)   {  out.println(e.getMessage()); }   
                  
                  if (check) {
                  	         out.println("<TR><TD height=25 width=65>&nbsp;</TD><TD colSpan=3 bgColor=#49b0fc><table border=0 width=\"100%\"><tbody><tr><td align=right width=\"6%\"><font size=2></font></td>");
                              out.println("<td width=\"21%\"><font size=2><b>Select Member</b></font></td><td width=\"73%\">");
                              out.println("<select name=\"GASelect\" size=\"1\">");
                   try{           
                              Statement  theStatement=theConnection.createStatement();
                              ResultSet theResult = theStatement.executeQuery(  "select groupname,grouptype,membername,no_mem,notegr  from member "+
                                  "where id <> idmem and id=' "+UserID+"' order  by groupname , grouptype");
                               while (theResult.next()){ 
                                             if (title.equals(theResult.getString(1)) && type.equals(theResult.getString(2))  )
                                             { out.println("<option value=\""+theResult.getInt(4)+"\"> "+theResult.getString(3)+" </option>");   } 
                                          }//while
                              theStatement.close();//Close statement
                              theConnection.close();
                         }   catch (Exception e)   {  out.println(e.getMessage()); }   
                 out.println("</select>");
                 out.println("</td></tr><tr><td width=\"6%\">&nbsp;</td><td valign=bottom width=\"21%\"><b><font size=2>Title</font></b></td>");
                 out.println("<td valign=bottom width=\"73%\"><input name=GATitle size=30></td></tr><tr><td width=\"6%\">&nbsp;</td><td valign=bottom width=\"21%\"><b><font size=2>Place</font></b></td>");
                 out.println("<td width=\"73%\"><input name=GAPlace size=30></td></tr><tr><td width=\"6%\">&nbsp;</td><td valign=bottom width=\"21%\"><b><font  size=2>Type</font></b></td>");
                 out.println("<td valign=bottom width=\"73%\"><select name=GAType size=1>");
                  out.println("<option value=\"Anniversary\">Anniversary</option>");
                 out.println("<option value=\"Appointment\" selected>Appointment</option>");
                 out.println("<option value=\"BillPayment\">Bill Payment</option>");
                 out.println("<option value=\"Birthday\">Birthday</option>");
                 out.println("<option value=\"Breakfast\">Breakfast</option>");
                 out.println("<option value=\"Call\">Call</option>");
                 out.println("<option value=\"Chat\">Chat</option>");
                 out.println("<option value=\"Class\">Class</option>");
                 out.println("<option value=\"ClubEvent\">Club Event</option>");
                 out.println("<option value=\"Concert\">Concert</option>");
                 out.println("<option value=\"Date\">Date</option>");
                 out.println("<option value=\"Dinner\">Dinner</option>");
                 out.println("<option value=\"Graduation\">Graduation</option>");
                 out.println("<option value=\"HappyHour\">Happy Hour</option>");
                 out.println("<option value=\"Holiday\">Holiday</option>");
                 out.println("<option value=\"Interview\">Interview</option>");
                 out.println("<option value=\"Lunch\">Lunch</option>");
                 out.println("<option value=\"Meeting\">Meeting</option>");
                 out.println("<option value=\"Movie\">Movie</option>");
                 out.println("<option value=\"NetEvent\">Net Event</option>");
                 out.println("<option value=\"Other\">Other</option>");
                 out.println("<option value=\"Party\">Party</option>");
                 out.println("<option value=\"Performance\">Performance</option>");
                 out.println("<option value=\"Reunion\">Reunion</option>");
                 out.println("<option value=\"SportsEvent\">Sports Event</option>");
                 out.println("<option value=\"Travel\">Travel</option>");
                 out.println("<option value=\"TVShow\">TV Show</option>");
                 out.println("<option value=\"Vacation\">Vacation</option>");
                 out.println("<option value=\"Wedding\">Wedding</option>");                     
                 out.println("</select></td></tr><tr><td width=\"6%\">&nbsp;</td><td valign=bottom width=\"21%\"><font size=2><b>Start Date</b></font></td>");
                  out.println("<td valign=bottom width=\"73%\"><select name=GADay>");
                  for (int i=1;i<=31;i++)   {
                  out.print("<option value="+i);
                  if (CurDate==i) out.print(" selected");
                  out.print(">");
                  if (i<10)out.print("0");
                  out.println(i+"</option>");  }
                  out.println("</select><select name=GAMonth>");
                  for (int i=0;i<=11;i++) { out.print("<option value="+i);
                   if (CurMonth==i)out.print(" selected");
                  out.println(">"+MonthName[i]+"</option>"); }
                  out.println("</select> <select name=GAYear>");
                  for (int i=2001;i<=2003;i++)
                  {out.print("<option  value="+i);
                    if (CurYear==i)out.print(" selected"); 
                    out.println(">"+i+"</option>"); }
                    out.println("</select></td></tr><tr>");
                    out.println("<td width=\"6%\">&nbsp;</td><td valign=bottom width=\"21%\"><b><font size=2>Start Time</font></b></td>");
                    out.println("<td width=\"73%\"><select name=GAHour>");
                     for (int i=0;i<=23;i++){
                     out.print("<option value="+i);
                     if (CurHour==i)out.print(" selected"); 
                     out.print(">");
                     if (i<10) out.print("0");
                     out.println(i+"</option>");  }
                     out.println("</select><font size=2><b> : </b></font><select name=GAMin>");  
                     out.println("<option selected value=0>00</option>");
                     out.println("<option  value=15>15</option>");
                     out.println("<option  value=30>30</option>");
                     out.println("<option  value=45>45</option>");
                     out.println("</select></td></tr><tr><td width=\"6%\">&nbsp;</td><td valign=top width=\"21%\"><font size=2><b>Note</b></font></td>");
                     out.println("<td width=\"73%\"><textarea cols=30 name=GANote></textarea></td></tr><tr><td width=\"6%\">&nbsp;</td>");
                     out.println("<td valign=bottom width=\"21%\"><b><font size=2>From</font></b></td><td width=\"73%\"><input name=GAFrom size=30>");
                     out.println("</td></tr><tr><td height=35 width=\"6%\">&nbsp;</td><td align=right colspan=2 height=35 valign=bottom>");
                     out.println("<input type=\"hidden\" name=\"HiddenNo\" value=\""+NoNum+"\">");
                     out.println("<input name=Submit type=submit value=\"  Submit   \">");
                     out.println("<input name=SubmitAnother type=submit value=\"Submit And Add Another\">");
                     out.println("<input name=Cancel type=submit value=\"  Cancel  \">");
                     out.println("</td></tr></tbody></table>");
                     out.println("</TD><TD height=25 width=58>&nbsp;</TD></TR>");
                     }//if
                     if (!check) {
                     out.println("<TR><TD height=28 width=60>&nbsp;</TD>");
                     out.println("<TD colSpan=3 bgColor=#49b0fc height=28 align=\"center\"><font size=\"2\">- No Member Data -</font></TD>");
                     out.println("<TD height=28 width=56>&nbsp;</TD></TR>");  }
                     
                     out.println("</TBODY></TABLE></FORM>");
                     out.println("</TD></TR></TBODY></TABLE></BODY></HTML>");
        
        }//DoPost
  }//ShowUpdateGroup
  
  
   