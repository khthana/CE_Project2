import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class test1 extends HttpServlet
 {    Connection ConnectDatabase;
       public  void  doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {      
            try{    Class.forName("oracle.jdbc.driver.OracleDriver");
           ConnectDatabase = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                  }  catch (Exception e) {  res.setContentType("text/html");
                                                                PrintWriter out = res.getWriter();
              	                                          out.println(e.getMessage()); 
                                 	                                 }
          try{  Statement  theStatement=ConnectDatabase.createStatement();
                              theStatement.executeQuery("select * from calendar");
                              theStatement.close();
                      }   catch (Exception e)   
                                               {  res.setContentType("text/html");
                                                   PrintWriter out = res.getWriter();
                                                  out.println(e.getMessage());   }                     
     
          }
       }
