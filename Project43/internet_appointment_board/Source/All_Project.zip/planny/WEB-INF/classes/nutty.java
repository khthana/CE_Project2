import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.servlet.*;
import javax.servlet.http.*;

public class nutty extends HttpServlet
 { protected void doGet(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException
       {    res.setContentType("text/html");
             PrintWriter out = res.getWriter(); 
       	
       	
out.println("<html><head><title>Planny Organizer</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-874\">"); 
out.println("<head>");
out.println("<SCRIPT LANGUAGE=\"JavaScript1.2\">");

out.println("<!-- ");
out.println("neonBaseColor = \"white\";");
out.println("neonColor = \"Red\";");
out.println("num = 0;");
out.println("num2 = 0;");
out.println("num3 = 0;");
out.println("num4 = neonColor;");
out.println("function startNeon() {");
out.println("message = neon.innerText;");
out.println("neon.innerText = \"\";");
out.println("for(i = 0; i != message.length; i++) {");
out.println("neon.innerHTML += \"<span id=\\\"neond\\\" style=\\\"color:\"+neonBaseColor+\"\\\">\"+message.charAt(i)+\"<\\/span>\"};");
out.println("neon2();");
out.println("}");
out.println("function neon2() {");
out.println("if(num != message.length) {");
out.println("document.all.neond[num].style.color = neonColor;");
out.println("num++;");
out.println("setTimeout(\"neon2()\", 100);");
out.println("}");
out.println("else {");
out.println("num = 0;");
out.println("num2 = message.length;");
out.println("setTimeout(\"neon4onev()\", 2000);");
out.println("}}");
out.println("function neon4onev() {");
out.println("document.all.neond[num].style.color = neonBaseColor;");
out.println("document.all.neond[num2-1].style.color = neonBaseColor;");
out.println("if(Math.floor(message.length / 2) + 1 != num2) {");
out.println("num++;");
out.println("num2--;");
out.println("setTimeout(\"neon4onev()\", 50);");
out.println("}");
out.println("else {");
out.println("setTimeout(\"neon5()\", 50);");
out.println("}}");
out.println("function neon5() {");
out.println("if(num3 != message.length && num3 != message.length+1) {");
out.println("document.all.neond[num3].style.color = neonColor;");
out.println("num3 = num3 + 2;");
out.println("setTimeout(\"neon5()\",100);");
out.println("}");
out.println("else {");
out.println("setTimeout(\"neon52()\", 50);");
out.println("}}");
out.println("function neon52() {");
out.println("if(num3 == message.length) {");
out.println("num3++;");
out.println("neon52a();");
out.println("}");
out.println("else {");
out.println("num3--;");
out.println("neon52a();");
out.println("}}");
out.println("function neon52a() {");
out.println("if(num3 != 1) {");
out.println("num3 = num3 - 2;");
out.println("document.all.neond[num3].style.color = neonColor;");
out.println("setTimeout(\"neon52a()\", 100);");
out.println("}");
out.println("else {");
out.println("if(num4 == neonColor) {");
out.println("num3 = 0;");
out.println("neonColor = neonBaseColor;");
out.println("setTimeout(\"neon5()\", 2000);");
out.println("}");
out.println("else {");
out.println("neonColor = num4;");
out.println("num3 = 0;");
out.println("setTimeout(\"neon4onev2()\", 50);");
out.println("} }}");
out.println("function neon4onev2() {");
out.println("document.all.neond[num].style.color = neonColor;");
out.println("document.all.neond[num2 - 1].style.color = neonColor;");
out.println("if(message.length != num2) {");
out.println("num--;");
out.println("num2++;");
out.println("setTimeout(\"neon4onev2()\", 50);");
out.println("}");
out.println("else {");
out.println("num = 0;");
out.println("num2 = 0;");
out.println("setTimeout(\"neon3()\", 2000);");
out.println("}}");
out.println("function neon3() {");
out.println("if(num != message.length) {");
out.println("document.all.neond[num].style.color = neonBaseColor;");
out.println("num++;");
out.println("setTimeout(\"neon3()\", 100);");
out.println("}");
out.println("else {");
out.println("num = 0;");
out.println("neon2();");
out.println("}}");
out.println("//  End -->");
out.println("</script>");
out.println("</head><BODY onLoad=\"startNeon()\"");

out.println("<a name=\"tickpos\"> </a>");
out.println("<font size=2><span id=\"neon\">You Got Appointment</span></font>");

out.println("</BODY></html>"); 


}}
       











