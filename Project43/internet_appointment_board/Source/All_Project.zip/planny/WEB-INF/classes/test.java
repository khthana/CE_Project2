import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.net.*;
import java.util.*;
public class test extends HttpServlet{
  protected  void  doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
  {  Connection theConnection;
      //String Title                    = req.getParameter("TitleToDo");
     try{                               // if (Title==null) Title="No Title";
                                                //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                                theStatement.executeQuery(
                                              "INSERT INTO todo"
                                                           + "(no_todo,id,title)"
                                                           + "values( no_todo.nextval,' Elmo','"+Title+"')");
                                                
                                               theStatement.close();//Close statement
                                               theConnection.close();                                         
                             }   catch (Exception e)  
                                               {    res.setContentType("text/html");
                                                    PrintWriter out = res.getWriter();
                                                    out.println(e.getMessage()); 
                                               }  
              }
         }