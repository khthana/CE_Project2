import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ShowSession2 extends HttpServlet { public void doGet(HttpServletRequest req,HttpServletResponse res)
                         throws ServletException, IOException {

                         PrintWriter out = res.getWriter();
                         res.setContentType("text/html");
                         HttpSession session = req.getSession(true);
                          
                out.println("<HTML><TITLE> Session</TITLE></HTML>");
                out.println( "<BODY>" );
                out.println("<CENTER><H2>Information on Your Session:</H2></CENTER><BR>" );
                out.println(session.getValue("login.username") );
                out.println("<BR>"+session.getValue("test.target") );
                out.println("<BR>"+session.getValue("test.name") );
                out.println("</BODY></HTML>");

  }
 
}