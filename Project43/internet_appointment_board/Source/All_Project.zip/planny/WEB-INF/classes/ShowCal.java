import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class ShowCal extends HttpServlet
 {  protected void service (HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException
       {    int Month =  0;
             int   Year =  2001;
             Calendar GCalendar = new GregorianCalendar(Year, Month,1);
                         
             long second2 = GCalendar.getTime().getTime();
             int Dayofweek = GCalendar.get(GCalendar.DAY_OF_WEEK);
             int Dayofmonth = GCalendar.get(GCalendar.DAY_OF_MONTH);
             int Dayofweekinmonth = GCalendar.get(GCalendar.DAY_OF_WEEK_IN_MONTH);
             int Dayofyear = GCalendar.get(GCalendar.DAY_OF_YEAR);
             GCalendar.add(GCalendar.DATE,-(Dayofweek-1));
             int Dayofweek2 = GCalendar.get(GCalendar.DAY_OF_WEEK);
             int Dayofmonth2 = GCalendar.get(GCalendar.DAY_OF_MONTH);
             int Dayofweekinmonth2 = GCalendar.get(GCalendar.DAY_OF_WEEK_IN_MONTH);
             int Dayofyear2 = GCalendar.get(GCalendar.DAY_OF_YEAR);
             res.setContentType("text/html");
             PrintWriter out = res.getWriter(); 
              out.println("<html><title>Calendar</title>");
              out.println("<body>");
              out.println("Time In MilliSecond = "+second2+"<br>");
              out.println("DAY_OF_WEEK = "+Dayofweek+"<br>");
              out.println("DAY_OF_MONTH ="+Dayofmonth+"<br>");
              out.println("DAY_OF_WEEK_IN_MONTH = "+Dayofweekinmonth+"<br>");
              out.println("DAY_OF_YEAR = "+Dayofyear+"<br>");
              out.println("DAY_OF_WEEK = "+Dayofweek2+"<br>");
              out.println("DAY_OF_MONTH ="+Dayofmonth2+"<br>");
              out.println("DAY_OF_WEEK_IN_MONTH = "+Dayofweekinmonth2+"<br>");
              out.println("DAY_OF_YEAR = "+Dayofyear2+"<br>");
              
              int Startdate = GCalendar.get(GCalendar.DATE);
              for (int i=1;i<=(Dayofweek-1);i++)    {   out.println (Startdate+"<br>"); 
                                                                                Startdate++;       }
              out.println("--------------------------------------<br>");
              for(int tdate=1;tdate<35;tdate++)
                 {     out.println("date ="+GCalendar.get(GCalendar.DATE)+" : Time In Second  "+GCalendar.getTime().getTime()+"<br>");
                       GCalendar.add(GCalendar.DATE,1);                  
                 }
              //long test = GCalendar.getTime().getTime();
              String kate = "980701200000";
              Date testD = new Date();
              testD.setTime(Long.parseLong(kate));
              GCalendar.setTime(testD);
              out.println(" Date : "+GCalendar.get(GCalendar.DAY_OF_MONTH)+"    in Mili"+kate);
              //String nut = "981046800000";
              
              out.println("<br>"+GCalendar.getTime().getTime());
              long nut=Long.parseLong("981133200000");
              out.println("<br>Convert Form String"+nut);
              String Gtime = "981133200000";
                         
              
              out.println("</body></html>");
       }
  }            
