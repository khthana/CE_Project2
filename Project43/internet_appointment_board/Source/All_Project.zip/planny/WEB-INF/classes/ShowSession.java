import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ShowSession extends HttpServlet { public void doGet(HttpServletRequest req,HttpServletResponse res)
                         throws ServletException, IOException {
                        
                                             
                         HttpSession session = req.getSession(true);
                         session.putValue("test.username", "counter" );
                         session.putValue("test.target", "161.246.5.231" );
                         session.putValue("test.name", "nut" );
                          res.setContentType("text/html");
	    PrintWriter out = res.getWriter();
                         out.println("ok");
                         
                        }} 
                         
                         
