import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.net.*; 
public class registerwap extends HttpServlet 
{       Connection theConnection;
         String DefaultURL= "http://161.246.5.233:8080/planny";
          public void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
		res.setContentType("text/vnd.wap.wml");
		PrintWriter out = res.getWriter();
		String login = req.getParameter("id");
		String passwd= req.getParameter("password");
		String repasswd=req.getParameter("repassword");
		String firstname= req.getParameter("firstname");
		String lastname= req.getParameter("lastname");
		String sex = req.getParameter("sex");
                                          boolean  check = true;
	                     boolean  Clogin =false;
	                     boolean  Cpasswd=false;
	                     boolean  Cfirstname=false;
	                     boolean  Clastname=false;
                                          boolean  CrepeatID   = true;
                                          String Message2="Someone has already chosen that ID Name. Please choose another ID name, be imaginative, try adding a number to the end of the name that you might remember. ";
                                          String Message3="<font color=red><b>Planny ID</b></font>: Begin with a letter and use only letters (a-z,A-Z), numbers (0-9), the underscore (_), and no spaces.";
	                     String Message4="<font color=red><b>Password</b></font>: Your Password may contain numbers (0-9) and upper and lowercase letters (A-Z, a-z), but no spaces. ";
	                     String Message5="Please specify your ";
	                     String Message6="You didn't specify an understandable";
	                     String Message7="Your new password entries did not match.";
                                           if (login.equals("") ||  !(Checkinput.Checkbegin(login)) ||  !(Checkinput.CheckJava(login))  )
                                              { Clogin = true;
                                                check  = false;
                                               }
                                           if ( passwd.equals("") || repasswd.equals("") ||  !(passwd.equals(repasswd)) 
                                                  ||  ! Checkinput.CheckChar(passwd) || ( passwd.length() < 3 ))
                                               { Cpasswd = true;
                                               check  = false; }          
                                          if ( firstname.equals("") )
                                              { Cfirstname = true;
                                                 check  = false; }          
                                          if ( lastname.equals("") )
                                           { Clastname = true;
                                             check  = false; }          
                                          if (check)  // all right put data to database 
                                   {      
                                   	try{
                                               //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                               ResultSet theResult=theStatement.executeQuery("select id  from  userdata");
                                               while(theResult.next() && check  ){
                                               	    if ( theResult.getString(1).substring(1).equals(login) )
                                                               {  Clogin = true;
                                                                   check  = false;
                                                                   CrepeatID = false;
                                                                }
                                                                                                                }
                                                  if(CrepeatID) {  
                                                      theStatement.executeQuery(
                                                        "INSERT INTO userdata "
                                                     + "(id,pwd,firstname,lastname,sex)"
                                                     + "VALUES ( ' "+ login +"' ," + "'" + passwd +"', '" + firstname + "'," + "'" + lastname + "'  ,"
                                                     + "'" +sex + "')");
     	                          HttpSession session = req.getSession(true);
                              	     session.putValue("login.username",login);     // put user ID 
                                   	         	                                   }
                                   	    theStatement.close();//Close statement
                                               theConnection.close();                                         
                                                      }   catch (Exception e)  
                                               {  res.setContentType("text/html");
	                             PrintWriter out = res.getWriter();
                                                  out.println(e.getMessage()); 
                                               }  
                                    res.sendRedirect(DefaultURL+"/servlet/mainwap");
                                    }  
                                    
         }
    }
        