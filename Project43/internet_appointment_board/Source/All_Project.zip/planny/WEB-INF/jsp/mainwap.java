import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class mainwap extends HttpServlet 
{    Connection theConnection;
      String DefaultURL="http://161.246.5.233:8080/planny";
      static final int  CurDate      =  Calendar.getInstance().get(Calendar.DAY_OF_MONTH); 
      static final int  CurMonth   =  Calendar.getInstance().get(Calendar.MONTH); 
      static final int  CurYear      =  Calendar.getInstance().get(Calendar.YEAR); 
      static final int  CurHour      =  Calendar.getInstance().get(Calendar.HOUR_OF_DAY); 
     static final String []DayName={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"} ;
     static final  String [] MonthName = {"January","February","March","April","May", "June","July","August","September","October","November","December"};
     static final  String [] MonthAbr = {"Jan","Feb","Mar","Apr","May", "Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
     static final  String [] DayAbr = {"","Sun","Mon","Tue","Wed","Thu","Fri", "Sat"};
   public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException         
          {   HttpSession session = req.getSession(true);
               String UserID = (String)session.getValue("login.username");	
               if ( UserID==null  ) {  res.sendRedirect(DefaultURL+"/wap/login.wml");  }
               else session.putValue("login.username",UserID);
             String ch = req.getParameter("s");
             String GiveTime = req.getParameter("t");
             int GDate= CurDate;
             int GMonth=CurMonth;
             int GYear=CurYear;
             if (GiveTime!=null) {
             Date MakeDate = new Date(Long.parseLong(GiveTime));
             Calendar GCalendar = new GregorianCalendar();
             GCalendar.setTime(MakeDate);
             GDate = GCalendar.get(GCalendar.DAY_OF_MONTH); 
             GMonth = GCalendar.get(GCalendar.MONTH);
             GYear = GCalendar.get(GCalendar.YEAR);
                        }
               if (ch==null) ch="1";
               res.setContentType("text/vnd.wap.wml");
               PrintWriter out = res.getWriter();
                 try{    Class.forName("oracle.jdbc.driver.OracleDriver");
                                     theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                 }  catch (Exception e) { out.println(e.getMessage()); }
               if(ch.equals("1")) { Main(out); }
                  else if (ch.equals("2")) {WapMonth(GDate,GMonth,GYear,out);}                  	
                         else if(ch.equals("3")) {ToDowap(DefaultURL,theConnection,UserID,out,GDate,GMonth,GYear,MonthName);}     	
                               else if(ch.equals("6")) {WapDay(GDate,GMonth,GYear,MonthName,DefaultURL,out);}     	 
                 try { theConnection.close(); }
                                 catch (Exception e)  {out.println(e.getMessage()); }  
           }
      
   public void Main (PrintWriter out)
	{  out.println("<?xml version=\"1.0\"?>");
                         out.println("<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1_1.xml\">"); 
                         out.println("<wml> <card id=\"card1\" title=\"Please Select Funct\" >");
                        
                         out.println("<p><a  href=\"http://161.246.5.233:8080/planny/servlet/mainwap?s=2\">My Calendar</a><br/>");
                         out.println("<a href=\"http://161.246.5.233:8080/planny/servlet/mainwap?s=3\"> Todo </a><br/>");
                         out.println("<a href=\"http://161.246.5.233:8080/planny/servlet/mainwap?s=4\"> QuickAdd</a><br/>");
                         out.println("<a href=\"http://161.246.5.233:8080/planny/servlet/mainwap?s=5\"> Find</a><br/>");
                         out.println("<a href=\"http://161.246.5.233:8080/planny/servlet/mainwap?s=6\">Group Calendar</a><br/></p>");
                         out.println("<do type =\"prev\"><prev/></do></card></wml> ");
                        }
    
  public void WapMonth(int GDate,int GMonth,int GYear,PrintWriter out)
      {
        out.println("<?xml version=\"1.0\"?>");
        out.println("<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1_1.xml\">");
        out.println("<wml><card title=\"Planny Calendar\"><p mode=\"nowrap\" align=\"center\">");
        Calendar GCalendar = new GregorianCalendar(GYear,GMonth,GDate); 
        out.print("<a href=\""+DefaultURL+"/servlet/mainwap?t="+Calendar.getInstance().getTime().getTime()+"&amp;s=6\">");
        out.println(Calendar.getInstance().get(Calendar.DATE)+" "+MonthName[Calendar.getInstance().get(GCalendar.MONTH)]+" "+Calendar.getInstance().get(GCalendar.YEAR)+"</a>");
        out.println("<small><table columns=\"7\" align=\"CCCCCCC\">");
        out.println("<tr><td>Su</td>");
        out.println("<td>Mo</td>");
        out.println("<td>Tu</td>");
        out.println("<td>We</td>");
        out.println("<td>Th</td>");
        out.println("<td>Fr</td>");
        out.println("<td>Sa</td></tr>");
        GCalendar = new GregorianCalendar(GYear,GMonth,1);
        int DayOfWeek = GCalendar.get(GCalendar.DAY_OF_WEEK);
        GCalendar.add(GCalendar.DATE,-(DayOfWeek-1));
        out.println("<tr>");
        for (int i=1;i<=(DayOfWeek-1);i++)   
            {  out.println("<td><a href=\""+DefaultURL+"/servlet/mainwap?t="+GCalendar.getTime().getTime()+"&amp;s=6\">"+GCalendar.get(GCalendar.DATE)+"</a></td>");
               GCalendar.add(GCalendar.DATE,1);
             }
                         int date=1;
                         int Days=DayOfWeek;
                         GCalendar=new GregorianCalendar(GYear,GMonth,1);
                         for ( int weeks=0; weeks<6 ;weeks++)
	        {   for (; Days<=7 ; Days++)
	            {    out.print("<td><a href=\""+DefaultURL+"/servlet/mainwap?t="+GCalendar.getTime().getTime()+"&amp;s=6\">");
	                    if (GCalendar.get(GCalendar.DATE) < 10 ) {out.print(" "); }
	                 out.println(GCalendar.get(GCalendar.DATE)+"</a></td>");  
                                       GCalendar.add(GCalendar.DATE,1);
                                  }   
	               if (GCalendar.get(GCalendar.MONTH) != GMonth )
	                 { out.println("</tr>");
	                    weeks=8; 
	                    continue;  } else
	                 {  Days=1; 
	                    out.println("</tr><tr>");  }
	        }//For       
                     out.println("</table></small>");
       out.println("</p><do type =\"prev\">");
       out.println("<prev/></do>");
       out.println("<do type =\"accept\" label=\"View Calendar\">");
       out.println("<go href=\""+DefaultURL+"/servlet/mainwap\"/></do>");
       out.println("</card></wml>");
       }//WCalendar          
public void WapWeek(int GDate,int GMonth,int GYear,String []DayAbr,String []MonthAbr,PrintWriter out)
      {  out.println("<?xml version=\"1.0\"?>");
          out.println("<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1_1.xml\">");
          out.println("<wml><card title=\"Calendar Week\"><p align =\"center\" mode=\"nowrap\">");
          Calendar GCalendar    = new GregorianCalendar(GYear,GMonth,GDate); 
          out.print("<a href=\"Calendar\">"+GCalendar.get(GCalendar.DATE)+" - ");
          GCalendar.add(GCalendar.DATE,6);
          out.print(GCalendar.get(GCalendar.DATE)+" ");
          GCalendar.add(GCalendar.DATE,-6);
          out.print(MonthAbr[GCalendar.get(GCalendar.MONTH)]+" "+GCalendar.get(GCalendar.YEAR));
          out.println("</a></p><p><small><table columns=\"2\">");
          for(int i=1;i<=7;i++)
            { out.println("<tr>");
               out.print("<td><a href=\""+DefaultURL+"/servlet/WCalendar\">");
               out.print(DayAbr[GCalendar.get(GCalendar.DAY_OF_WEEK)]);
               out.print(" "+GCalendar.get(GCalendar.DATE));
               out.print(" "+MonthAbr[GCalendar.get(GCalendar.MONTH)]);
               out.print(" "+GCalendar.get(GCalendar.YEAR));
               out.println("</a></td>"); 
               out.println("<td><a href=\""+DefaultURL+"/servlet/WCalendar\"> Meeting </a> </td>");
               out.println("</tr>");
               GCalendar.add(GCalendar.DATE,1);   }
         out.println("</table></small>");
         out.println("</p><do type =\"prev\"><prev/>");
         out.println("</do><do type=\"accept\" label =\"view calendar\">");
         out.println("<go href=\""+DefaultURL+"/servlet/WCalendar\"/></do>");
         out.println("</card></wml>");
      }//WapWeek 
 public void WapDay(int GDate,int GMonth,int GYear,String []MonthAbr,String DefaultURL,PrintWriter out)      
     {  out.println("<?xml version=\"1.0\"?>");
        out.println("<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1_1.xml\">");
        out.println("<wml><card  title=\"Calendar Day\"><p align =\"center\" mode=\"nowrap\">");
        Calendar GCalendar = new GregorianCalendar(GYear,GMonth,GDate,0,0); 
        out.print("<a href=\""+DefaultURL+"/servlet/mainwap?t="+GCalendar.getTime().getTime()+"\">");
        out.print(GCalendar.get(GCalendar.DATE)+" "+MonthAbr[GCalendar.get(GCalendar.MONTH)]+" "+GCalendar.get(GCalendar.YEAR));
        out.println("</a></p><p align =\"center\"><small><table columns=\"4\">");
        for(int i=1;i<=6;i++) {
        out.println("<tr>");
            for(int j=1;j<=4;j++) { 	
        out.print("<td><a href=\""+DefaultURL+"/servlet/mainwap?t="+GCalendar.getTime().getTime()+"\">");
            if (GCalendar.get(GCalendar.HOUR_OF_DAY) < 10 ) out.print("0");
        out.println(GCalendar.get(GCalendar.HOUR_OF_DAY)+".00</a></td>");
        GCalendar.add(GCalendar.HOUR_OF_DAY,1);   }  
        out.println("</tr>");  }
        out.println("</table></small>");
        out.println("</p><do type =\"prev\"><prev/>");
        out.println("</do><do type=\"accept\" label =\"view calendar\">");
        out.println("<go href=\""+DefaultURL+"/servlet/mainwap\"/></do>");
        out.println("</card></wml>");
      }//WapDay
 
 public void ToDowap(String DefaultURL,Connection theConnection,String UserID,PrintWriter out,int CDate,int CMonth,int CYear,String []MonthName)
    {     
         try{  Statement theStatement = theConnection.createStatement (ResultSet.TYPE_SCROLL_SENSITIVE, 
                 ResultSet.CONCUR_UPDATABLE);
                ResultSet theResult=theStatement.executeQuery("select  no_todo,timeout,priority,title,note,id  from  todo where id = ' "+UserID+"'");
                //removetodo(theResult,CDate,CMonth,CYear,MonthName);
                while (theResult.next())
               {   Calendar DBCalendar = new GregorianCalendar();
                    DBCalendar.setTime(theResult.getDate(2));
                
                if(DBCalendar.get(DBCalendar.YEAR) < CYear) {theResult.deleteRow();}
                     else if(DBCalendar.get(DBCalendar.YEAR) == CYear)
                                 {  if(DBCalendar.get(DBCalendar.MONTH)<CMonth) {theResult.deleteRow();}
                                         else if(DBCalendar.get(DBCalendar.MONTH)==CMonth)
                                                      if(DBCalendar.get(DBCalendar.DATE)<CDate)  { theResult.deleteRow();}
                                 }
                
               }//while
               theResult.close();
               theStatement.close();  } 
               catch (Exception e) {out.println(e.getMessage());}
               out.println("<?xml version=\"1.0\"?>");
               out.println("<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1_1.xml\">");
               out.println(" <wml><card id = \"viewToDo\" title=\"View ToDo\"><p align=\"center\">");
               out.println("<a href=\""+DefaultURL+"/wap/todo.wml\">Add ToDo</a>");
               out.println("<table columns=\"2\"><tr><td><b>Title</b></td><td><b>Priority</b></td></tr>");
                try{     Statement theStatement=theConnection.createStatement();
                           ResultSet  theResult=theStatement.executeQuery("select priority,timeout,title,no_todo  from  todo where id = ' Elmo' order by priority desc");
                           while (theResult.next())
                             {             Calendar ShowCalendar = new GregorianCalendar();
                                            ShowCalendar.setTime(theResult.getDate(2));
                                            int ShowDate = ShowCalendar.get(ShowCalendar.DATE);
                                            int ShowMonth = ShowCalendar.get(ShowCalendar.MONTH);
                                            int ShowYear = ShowCalendar.get(ShowCalendar.YEAR);
                                            int no = theResult.getInt(4);
                                            out.println("<tr><td><a href=\""+DefaultURL+"/servlet/ShowUpdateToDowap?n="+no+"\">"+theResult.getString(3)+"</a></td>");
                                             if (theResult.getInt(1)==4)   out.print("<td>Most</td>");
                                             if (theResult.getInt(1)==3)   out.print("<td>Medium</td>");
                                             if (theResult.getInt(1)==2)   out.print("<td>Less</td>");
                                             if (theResult.getInt(1)==1)   out.print("<td>No Identify</td>");
                                             out.println("</tr>");
                              }
                           theResult.close();
                           theStatement.close();
                            } catch (Exception e) { out.println(e.getMessage()); }
                            out.println("</table></p><do type =\"prev\"><prev/></do></card></wml> ");
                            }	
             
     }//class
     
