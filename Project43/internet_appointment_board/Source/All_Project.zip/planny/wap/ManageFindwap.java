import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class ManageFindwap extends HttpServlet
 {   String DefaultURL="http://161.246.5.233:8080/planny";
       static final  String [] MonthName = {"January","February","March","April","May", "June","July","August","September","October","November","December"};
      Connection theConnection;
      protected void doGet(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException
       {    HttpSession session = req.getSession(true);
             String UserID = (String)session.getValue("login.username");	
             if ( UserID==null  ) {  res.sendRedirect(DefaultURL);  }
             else session.putValue("login.username",UserID);
             res.setContentType("text/vnd.wap.wml");
               PrintWriter out = res.getWriter();
            Calendar FindCalendar = new GregorianCalendar();
             int Num =1;
             try{    Class.forName("oracle.jdbc.driver.OracleDriver");
                       theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                       Statement theStatement=theConnection.createStatement();
                       ResultSet  theResult;
                       if (Type.equals("null") && (Title.equals(""))  )
                          {  Title="No Title"; 
                              theResult=theStatement.executeQuery("select  time,title,type, no_cal  from calendar where id=' "+UserID+"' and  title= ' "+Title+"' order by time");   }
                      else if (Title.equals("") && (!(Type.equals("null")))  ) {  theResult=theStatement.executeQuery("select  time,title,type, no_cal  from calendar where id=' "+UserID+"' and ( type= '"+Type+"' ) order by time"); }
                      else if ((!Title.equals("")) && (Type.equals("null"))  ) {  theResult=theStatement.executeQuery("select  time,title,type, no_cal  from calendar where id=' "+UserID+"' and ( title= ' "+Title+"' ) order by time"); }
                      else {  theResult=theStatement.executeQuery("select  time,title,type, no_cal  from calendar where id=' "+UserID+"' and ( title= ' "+Title+"'  or type= '"+Type+"') order by time"); }
                      
                        while (theResult.next()) {
                                                             FindCalendar.setTime(theResult.getDate(1));
                                                            int FindDate = FindCalendar.get(FindCalendar.DATE);
                                                            int FindMonth = FindCalendar.get(FindCalendar.MONTH);
                                                            int FindYear = FindCalendar.get(FindCalendar.YEAR);
                                                            FindCalendar.setTime(theResult.getTime(1));
                                                             int FindHour = FindCalendar.get(FindCalendar.HOUR_OF_DAY);
                                                            int FindMin = FindCalendar.get(FindCalendar.MINUTE);
                               Num++;                          
                                               }//while
                        theResult.close();
                        theStatement.close();
                }  catch (Exception e) { out.println(e.getMessage()); }
            }
       }