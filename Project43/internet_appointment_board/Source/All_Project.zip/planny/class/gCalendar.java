import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class gCalendar extends HttpServlet
 {   String DefaultURL="http://161.246.5.231"; 
      static final int  CurDate      =  Calendar.getInstance().get(Calendar.DAY_OF_MONTH); 
      static final int  CurMonth   =  Calendar.getInstance().get(Calendar.MONTH); 
      static final int  CurYear      =  Calendar.getInstance().get(Calendar.YEAR); 
      static final int  CurHour      =  Calendar.getInstance().get(Calendar.HOUR_OF_DAY); 
      static final String []DayName={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"} ;
      static final  String [] MonthName = {"January","February","March","April","May", "June","July","August","September","October","November","December"};
      Connection theConnection;
      protected void doGet(HttpServletRequest req , HttpServletResponse res) throws ServletException, IOException
       {    HttpSession session = req.getSession(true);
             String UserID = (String)session.getValue("login.username");	
             if ( UserID==null  ) {  res.sendRedirect(DefaultURL);  }
               else session.putValue("lgoin.username",UserID);
            // String UserID="nut";
             String GiveTime = req.getParameter("t");
             int GDate= CurDate;
             int GMonth=CurMonth;
             int GYear=CurYear;
             if (GiveTime!=null) {
             Date MakeDate = new Date(Long.parseLong(GiveTime));
             Calendar GCalendar = new GregorianCalendar();
             GCalendar.setTime(MakeDate);
             GDate = GCalendar.get(GCalendar.DAY_OF_MONTH); 
             GMonth = GCalendar.get(GCalendar.MONTH);
             GYear = GCalendar.get(GCalendar.YEAR);
                             }
             res.setContentType("text/html");
             PrintWriter out = res.getWriter(); 
             out.println("<html><head><title>Planny Organizer</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-874\">");           
             out.println("<body bgcolor=\"#FFFFFF\" VLINK=blue LINK=blue><table width=\"100%\" border=\"0\" height=\"69\">");
             out.println("<tbody><tr><td  width=\"34%\" align=\"center\" rowspan=\"3\"><img src=\"/planny/picture/logo3.jpg\" width=\"219\" height=\"69\"></td>");	
             out.println("<td colspan=\"4\"><hr color=\"#49B0FC\" size=\"3\" noshade></td></tr>");
             out.println("<tr><td width=\"14%\">&nbsp;</td><td width=\"41%\" align=\"right\"><b><font size=\"3\" color=\"#49B0FC\" face=\"Georgia\">Welcome : &nbsp;"+UserID+"</font></b></td>");	
             out.println("<td width=\"2%\"></td><td width=\"9%\" valign=\"bottom\"></td></tr>");		
             out.println("<tr><td colspan=\"4\"><hr color=\"#49B0FC\" size=\"3\" noshade></td></tr></tbody></table>");	
             out.println("<table width=\"100%\" border=\"0\" align=\"center\"><tr><td height=\"25\" >&nbsp;</td><td height=\"25\" width=\"555\">&nbsp;</td></tr>");
              Object  ErGr = session.getValue("login.messagegroup");
             if( ErGr!=null ) {
             out.println("<tr><td height=\"25\" >&nbsp;</td><td height=\"25\" width=\"555\">"+ErGr+"</td></tr>");	
             session.removeValue("login.messagegroup");    
                 } else { out.println("<tr><td height=\"25\" >&nbsp;</td><td height=\"25\" width=\"555\">&nbsp;</td></tr>"); }	
             
             out.println("<tr><td  valign=\"top\">"); 
             PrintGroupCalendar.MakeCalendar(DefaultURL,MonthName,GDate,GMonth,GYear,out);
             CreateNewGroup(DefaultURL,out);
             AddNewMember(DefaultURL,out);
             //PrintGroupFind.MakeFind(DefaultURL,GiveTime,out);
             out.println("<TD align=center  vAlign=top> ");
             MainGroup.PrintMainGroup(theConnection,out,DefaultURL,GDate,GMonth,GYear,MonthName,DayName);
             out.println("</tbody></table></body></html>");
             out.flush();
             out.close();
        }//MainMethod     
        public  void CreateNewGroup(String DefaultURL,PrintWriter out)      
            {  out.println("<table border=1 height=123 width=\"100%\"><tbody><tr bgcolor=#ffffcc>");
                out.println("<td height=23><b><font size=-1>&nbsp;&nbsp;Create Group</font></b></td></tr>");
                out.println("<form method=\"post\" action=\"NewGroup\"><tr><td height=84 valign=top><font size=-1><b></b></font>"); 
                out.println("<table border=0 height=43 width=\"100%\"><tbody><tr> ");
                out.println("<td height=54><font size=-1><b>&nbsp;&nbsp;Type&nbsp; &nbsp;");
                out.println("<select name=\"CreateGType\">");
                out.println("<option value=\"Chat\" selected>Chat</option>");
                out.println("<option value=\"Clubs\">Clubs</option>");
                out.println("<option value=\"Games\">Games</option>");
                out.println("<option value=\"Friends\">Friends</option>");
                out.println("<option value=\"Sports\">Sports</option></select>");
                out.println("<br>&nbsp; Name&nbsp;&nbsp;");
                out.println("<input type=\"text\" name=\"CreateGName\" size=\"16\"><br>&nbsp;&nbsp;Note&nbsp;&nbsp;&nbsp; ");
                out.println("<input type=\"text\" name=\"CreateGNote\" size=\"16\">");
                out.println("</b></font></td></tr></tbody></table>");
                out.println("&nbsp;<input name=Submit22 type=submit value=\" Create \"></td></tr></form></tbody></table>");
            }//CreateNewGroup
        public   void AddNewMember(String DefaultURL,PrintWriter out)              
             {  out.println("<table border=1 height=123 width=\"100%\"><tbody><tr bgcolor=#ffffcc>"); 
                out.println("<td height=23><b><font size=-1>&nbsp;&nbsp;Add Member</font></b></td></tr>");
                out.println("<form method=\"post\" action=\"NewMember\"><tr><td height=84 valign=top><font size=-1><b></b></font>"); 
                out.println("<table border=0 height=43 width=\"100%\">");
                out.println("<tbody><tr>"); 
                out.println("<td height=54><font size=-1><b>&nbsp;&nbsp;Name&nbsp;&nbsp;");
                out.println("<input  maxlength=25 name=AddMName size=16><br>");
                out.println("&nbsp; Group&nbsp;&nbsp;<INPUT name=AddMGroup size=16><br>");
                 out.println("&nbsp; Type&nbsp; &nbsp;&nbsp;<select name=AddMType>");
                out.println("<option selected  value=Chat><font size=\"-1\"><b>Chat</b></font></option>");
                out.println("<option value=Clubs><font size=\"-1\"><b>Clubs</b></font></option>");
                out.println("<option value=Games><font size=\"-1\"><b>Games</b></font></option>");
                out.println("<option value=Friends><font size=\"-1\"><b>Friends</b></font></option>");
                out.println("<option value=Sports><font size=\"-1\"><b>Sports</b></font><b></b></option></select><BR>&nbsp; Status");
                out.println("<input type=\"text\" name=\"AddMStatus\" size=\"16\"><br>&nbsp;");
                out.println("Planny ID&nbsp;<input type=\"text\" name=\"AddMID\" size=\"13\"><br>&nbsp;&nbsp;Note &nbsp;&nbsp;");
                out.println("<input type=\"text\" name=\"AddMNote\" size=\"16\">");
                out.println("</b></font></td></tr></tbody></table>");
                out.println("&nbsp;<input name=Submit222 type=submit value=\" Add \"></td></tr></form></tbody></table>");
             }//AddNewMember  
      
 }
 class PrintGroupCalendar {
  public static  void MakeCalendar(String DefaultURL,String []MonthName/*,int CDate,int CMonth,int CYear*/,int GDate,int GMonth,int GYear,PrintWriter out)
                   {   
                   	Calendar GCalendar    = new GregorianCalendar(GYear,GMonth,GDate);  //Calendar  Object For MakeTime
                   	out.println("<TR> <TD vAlign=top ><TABLE border=1 height=\"32%\" width=\"100%\"><TBODY>  ");
                   	out.println("<tr valign=\"center\" align=\"center\" bgcolor=\"#FFFFCC\">");
                     GCalendar = new GregorianCalendar(GYear,GMonth-1,GDate);
                     out.println("<td colspan=\"8\" height=\"28\"><font size=\"2\"><a href =\""+DefaultURL+"/servlet/gCalendar?t="+GCalendar.getTime().getTime()+"\"><b>&lt;&lt;</b></a>");
                     out.println("<b>"+MonthName[GMonth]+" "+GYear+"</b>");
                     GCalendar = new GregorianCalendar(GYear,GMonth+1,GDate);
                     out.println("<a href =\""+DefaultURL+"/servlet/gCalendar?t="+GCalendar.getTime().getTime()+"\"><b> &gt;&gt;</b></font></a></td></tr>"); 
                     out.println("<tr valign=\"top\"><td colspan=\"8\" height=\"144\"><table width=\"90%\" border=\"0\" height=\"142\" align=\"center\"><tbody>");
                     out.println("<tr valign=\"bottom\" align=\"center\">");
                     out.println("<td height=\"20\"><font size=\"2\"><b>Su</b></font></td>");
                     out.println("<td height=\"20\"><b><font size=\"2\">Mo</font></b></td>");
                     out.println("<td height=\"20\"><b><font size=\"2\">Tu</font></b></td>");
                     out.println("<td height=\"20\"><b><font size=\"2\">We</font></b></td>");
                     out.println("<td height=\"20\"><b><font size=\"2\">Th</font></b></td>");
                     out.println("<td height=\"20\"><b><font size=\"2\">Fr</font></b></td>");
                     out.println("<td height=\"20\"><b><font size=\"2\">Sa</font></b></td></tr>");
                     out.println("<tr valign=\"middle\" align=\"center\">"); 
                     //get first day from 1
                     GCalendar = new GregorianCalendar(GYear,GMonth,1);
                   	int DayOfWeek = GCalendar.get(GCalendar.DAY_OF_WEEK);
                     GCalendar.add(GCalendar.DATE,-(DayOfWeek-1));
                     //int Startdate = GDate;
                     for (int i=1;i<=(DayOfWeek-1);i++)   
                           {   out.println ("<td><a href=\""+DefaultURL+"/servlet/mCalendar?t="+GCalendar.getTime().getTime()+"&s=0\">");
                                out.println("<font size=\"2\" color=\"#999999\"><b>"+GCalendar.get(GCalendar.DATE)+"</b></font></a></td>"); 
                                GCalendar.add(GCalendar.DATE,1);
                            }
                     int date=1;
                     int Days=DayOfWeek;
                     for ( int weeks=0; weeks<6 ;weeks++)
	     {      for (; Days<=7 ; Days++)
                                     {    GCalendar = new GregorianCalendar(GYear,GMonth,date,0,0);
                                           if  (date>28)
	                          { if (GCalendar.get(GCalendar.MONTH)==GMonth)
		          {  if (GDate != date) 
		                { out.println ("<td><a href =\""+DefaultURL+"/servlet/mCalendar?t="+GCalendar.getTime().getTime()+"&s=0\">");
		                   out.print("<font size=\"2\"");
		                    if (Days== 1) out.print("color=\"#FF0000\">"+date+"</b></font></a></td>");
		                    else out.println(">"+date+"</font></a></td>");  
		                 }//if 139
		            else { out.println ("<td><a href =\""+DefaultURL+"/servlet/mCalendar?t="+GCalendar.getTime().getTime()+"&s=0\">");
		            out.println("<font size=\"2\" color=\"BLACK\"><b>"+date+"</b></font></a></td>"); 
		                       } // else 146
		          }//if 138     
		    else  {  if (Days !=1)	{                      	
		                      out.println("<td><a href =\""+DefaultURL+"/servlet/mCalendar?t="+GCalendar.getTime().getTime()+"&s=0\">");
		                      out.println("<font size=\"2\" color=\"#999999\"><b>"+GCalendar.get(GCalendar.DATE)+"</b></font></a></td>");
		                      GCalendar.add(GCalendar.DATE,1);
		                                                                }   else Days=7;
		                  }//else 152                               
		    }//if 137
	                   else
		              {    if (GDate != date)
		                          {  out.print("<td><a href =\""+DefaultURL+"/servlet/mCalendar?t="+GCalendar.getTime().getTime()+"&s=0\"><font size=\"2\"");
		                              if (Days == 1 )  out.print("color=\"#FF0000\">"+date+"</font></a></td>");
		                               else  out.println(">"+date+"</font></a></td>");  
		                           }//if 162
		                   else { out.println ("<td><a href =\""+DefaultURL+"/servlet/mCalendar?t="+GCalendar.getTime().getTime()+"&s=0\">");
		                                out.println("<font size=\"2\" color=\"BLACK\"><b>"+date+"</b></font></a></td>"); 
		                       }
		               }  
		            date++;
	                   }             if (date>31) continue;
                                                       Days=1;
	                                  out.println("</TR><tr valign=\"bottom\" align=\"center\">");
	          }//for     
                     out.println("</tbody></table></td></tr><tr valign=\"middle\" align=\"center\" bgcolor=\"#FFFFCC\"> ");
                     out.println("<td colspan=\"8\" height=\"25\">");
                     out.println("<font size=\"2\"><a href =\""+DefaultURL+"/servlet/gCalendar?t="+Calendar.getInstance().getTime().getTime()+"\">Today</a>");
                     out.println(" is : <b> "+Calendar.getInstance().get(Calendar.DATE)+" "+MonthName[Calendar.getInstance().get(Calendar.MONTH)]+" "+Calendar.getInstance().get(Calendar.YEAR)+"</b></font></td>");
                     out.println("</tr></tbody></table>");
                     
          }//MakeCalendar
}//Class  PrintGroupCalendar        

class MainGroup
{ public static void PrintMainGroup(Connection theConnection,PrintWriter out,String DefaultURL,int GDate,int GMonth,int GYear,String []MonthName,String []DayName)
       {     int Num = 1;
              String title ="";
              String type ="";
              boolean check = true;
             out.println("<table width=\"100%\" border=\"0\"><tr><td colspan=\"2\"><TBODY><tr bgcolor=\"#6699FF\">");
             out.println("<TD align=middle bgColor=\"#cccccc\" colspan=\"2\">");
             out.println("<table width=\"100%\" border=\"0\" height=\"28\"><tbody><tr> ");
             out.println("<td align=\"right\" bgcolor=\"#FFFFCC\"><font >");
              Calendar GCalendar = new GregorianCalendar(GYear,GMonth,GDate);
              GCalendar = new GregorianCalendar(GYear,GMonth,GDate-1);
              out.print("<a href =\""+DefaultURL+"/servlet/gCalendar?t="+GCalendar.getTime().getTime()+"&s=0\"><b>&lt;&lt;</b></a><font size=2>");
              out.print("  <b>"+DayName[GCalendar.get(GCalendar.DAY_OF_WEEK)-1]+" "+GDate+" "+MonthName[GMonth]+" "+GYear+" </b></font>");
              GCalendar = new GregorianCalendar(GYear,GMonth,GDate+1);
              out.println("<a href =\""+DefaultURL+"/servlet/gCalendar?t="+GCalendar.getTime().getTime()+"&s=0\"><b>&gt;&gt;</b></a>&nbsp;&nbsp;");
              out.println("</td></tr></tbody></table></td></tr><tr><TD vAlign=middle height=\"30\" width=\"62%\">");      
              out.println("<font size=\"2\"> &nbsp;<a href=\""+DefaultURL+"/servlet/mCalendar\"><b>My Calendar</b></a> |<b>");
              out.println("Groups Calendar</b></font>");
              out.println("<TD height=30 vAlign=center width=\"38%\">&nbsp;<font size=\"2\">");
              out.println("<a href=\""+DefaultURL+"\">View Group</a> &nbsp;&nbsp;");
              out.println("<a href=\""+DefaultURL+"\">Group Appointment</a></font>");
              
              out.println("<tr><td colspan=\"2\"><table border=0 height=29 width=\"100%\" bgcolor=\"#FFFFFF\"><tbody>");
              out.println("<tr bgcolor=\"#D0D0D0\">"); 
              out.println("<td width=\"8%\" align=\"center\" height=\"25\"><b><font size=\"2\">No.</font></b></td>");
              out.println("<td align=\"center\" width=\"32%\" height=\"25\"><b><font size=\"2\">Type</font></b></td>");
              out.println("<td align=\"center\" width=\"32%\" height=\"25\"><b><font size=\"2\">Group Name</font></b></td>");
              out.println("<td width=\"28%\" align=\"center\" height=\"25\"><b><font size=\"2\">Member</font></b></td></tr>");
              
               try{                            
                                                //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                               ResultSet theResult = theStatement.executeQuery(  "select groupname,grouptype,membername,no_mem  from member "+
                                               "where idmem <> id order  by groupname , grouptype");
                                               while (theResult.next()){ 
                                               	if  (title.equals(""))  {   title=theResult.getString(1);  }
                                                                if (title.equals(theResult.getString(1))) 
                                                              	{  if  (type.equals("")) { type = theResult.getString(2);}
                                                              	   if (type.equals(theResult.getString(2)) && (check) ) {
                                                                          out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                          out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(2)+"</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+theResult.getString(4)+"\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(1)+"</a></font></b></td>");
                                                                          out.println("<td width=\"28%\" height=\"23\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println("<select name=\"select\">");
                                                                          out.println("<option value=\""+theResult.getString(3)+"\">"+theResult.getString(3)+"</option>");
                                                                           check = false;
                                                                          Num++;
                                                                    }//if type1
                                                                   if (type.equals(theResult.getString(2)) && (!check) ) { out.println("<option value=\""+theResult.getString(3)+"\">"+theResult.getString(3)+"</option>");}
                                                             
                                                               if ( !(type.equals(theResult.getString(2))))  {
                                                               	          out.println("</select></td></tr>");
                                                            	          type = theResult.getString(2) ;
                                                                          out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                          out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(2)+"</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+theResult.getString(4)+"\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(1)+"</a></font></b></td>");
                                                                          out.println("<td width=\"28%\" height=\"23\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println("<select name=\"select\">");
                                                                          out.println("<option value=\""+theResult.getString(3)+"\">"+theResult.getString(3)+"</option>");
                                                                           check = false;
                                                                          Num++;
                                                                    }//if type
                                                              }//if title
                                                  if  ( !(title.equals(theResult.getString(1))) ) {
                                                  	title= theResult.getString(1) ;
                                                  	 if (type.equals(theResult.getString(2)) ) {
                                                                          out.println("</select></td></tr>");
                                                                          out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                          out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                           out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(2)+"</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+theResult.getString(4)+"\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(1)+"</a></font></b></td>");
                                                                          out.println("<td width=\"28%\" height=\"23\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println("<select name=\"select\">");
                                                                          out.println("<option value=\""+theResult.getString(3)+"\">"+theResult.getString(3)+"</option>");
                                                                           check = false;
                                                                          Num++;
                                                                    }//if type1
                                                                 
                                                                    if ( !(type.equals(theResult.getString(2))) ) {
                                                               	          out.println("</select></td></tr>");
                                                            	          type = theResult.getString(2) ;
                                                                          out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                          out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(2)+"</font></b></td>");
                                                                          out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+theResult.getString(4)+"\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println(theResult.getString(1)+"</a></font></b></td>");
                                                                          out.println("<td width=\"28%\" height=\"23\">");
                                                                          out.println("&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                          out.println("<select name=\"select\">");
                                                                          out.println("<option value=\""+theResult.getString(3)+"\">"+theResult.getString(3)+"</option>");
                                                                           check = false;
                                                                          Num++;
                                                                    }//if type
                                                     }//title
                                            }//while
                                       out.println("</select></td></tr>");
                                       theStatement.close();
                                       theConnection.close(); 
                                           }   catch (Exception e)  
                                    {  out.println(e.getMessage());  }
                                 
               title="";
               type="";
               int N=1;
               int no_mem = 0;
               boolean c = false;
                try{                            
                                                //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                               ResultSet theResult = theStatement.executeQuery(  "select groupname,grouptype,no_mem  from member "+
                                               "order  by groupname , grouptype");
                                               while (theResult.next())
                                                  {
                                                      if  (title.equals(""))  {   title=theResult.getString(1);  }
                                                      if (title.equals(theResult.getString(1))) 
                                                          {  if  (type.equals("")) { type = theResult.getString(2);}
                                                             if (no_mem==0) no_mem = theResult.getInt(3);
                                                             if (type.equals(theResult.getString(2)) && (c) ){N++;}
                                                              if (type.equals(theResult.getString(2)) && (!c) ){ c = true; }
                                                              if ( !(type.equals(theResult.getString(2)))) 
                                                                  {  if (N==1) {
                                                                               out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                               out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                               out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                               out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                               out.println(type+"</font></b></td>");
                                                                               out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+no_mem+"\">");
                                                                               out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                               out.println(title+"</a></font></b></td>");
                                                                               out.println("<td width=\"28%\" height=\"23\"><font size=\"2\">- No Member -</font></td></tr>");
                                                                               Num++;
                                                                                }
                                                                       N=1;
                                                                       c = true; 
                                                                        type = theResult.getString(2) ; 
                                                                       no_mem = theResult.getInt(3);
                                                                    }//type
                                                          }//title.equals
                                                       if  ( !(title.equals(theResult.getString(1))) )
                                                        {       if (N==1) {
                                                                               out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                               out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                               out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                               out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                               out.println(type+"</font></b></td>");
                                                                               out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+no_mem+"\">");
                                                                               out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                               out.println(title+"</a></font></b></td>");
                                                                               out.println("<td width=\"28%\" height=\"23\"><font size=\"2\">- No Member -</font></td></tr>");
                                                                               Num++;
                                                                                }
                                                        	N=1;
                                                                c=true;
                                                  	title= theResult.getString(1) ;
                                                  	no_mem = theResult.getInt(3);
                                                                if ( !(type.equals(theResult.getString(2)))) 
                                                                   {  type = theResult.getString(2) ;      }
                                                        }//title
                                          }//while
                              theStatement.close();
                              theConnection.close(); 
                      }   catch (Exception e)  
                                    {  out.println(e.getMessage());  }          
               if ( (N==1)&&(c)   ) {
                                                                               out.println("<tr valign=\"middle\"  bgcolor=\"#99CCFF\">"); 
                                                                               out.println("<td width=\"8%\" height=\"23\" align=\"center\"><b><font size=\"2\">"+Num+".</font></b></td>");
                                                                               out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\">");
                                                                               out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                               out.println(type+"</font></b></td>");
                                                                               out.println("<td width=\"32%\" height=\"23\"><b><font size=\"2\"><a href=\""+DefaultURL+"/servlet/ShowUpdateGroup?m="+no_mem+"\">");
                                                                               out.println("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                                                                               out.println(title+"</a></font></b></td>");
                                                                               out.println("<td width=\"28%\" height=\"23\"><font size=\"2\">- No Member -</font></td></tr>");
                                 }                      
              out.println(" </tbody></table></td></tr></TD></TR></tbody></TABLE>");
                
                   }
 }
 
