import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Cal  extends HttpServlet
{   
	
static final String [] MonthName = {"January","February","March","April","May", "June","July","August","September","October","November","December"};
	//static final String background = new String("background.jpg");
	//static final String email = new String("maillogo.jpg");
	
protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{  int Month = Integer.parseInt(req.getParameter("Month"));
	   int    Year = Integer.parseInt(req.getParameter("Year"));
                        Calendar GCalendar = new GregorianCalendar(Year, Month, 1);
	   // first of the requested month
	   int StartDay = GCalendar.get(GCalendar.DAY_OF_WEEK);
		res.setContentType ("text/html");
		PrintWriter out = res.getWriter();
/*		if (Year<1900 || Year>2050)
		{
			out.println ("<html><title>Error</title>");
			out.println ("<body><h1 font size='+2'>The Year You Entered Is Illegal !!!</h1>");
			out.println ("</body></html>");
		}
		else
{*/
     	 out.println("<html><title>Calendar</title>");
	 out.println("<body>");
	 out.println("<br><br><h1 align='CENTER'><u>The Calendar</u></h1><br>");
	 out.println("<table border=1 width='60%' ALIGN='CENTER'>");
	 out.println("<caption><font color='GREEN' font size='+2'><b>"+ MonthName[Month]+" "+Year+"</b></caption>");
	 out.println("<tr><th>Sun</th><th>Mon</th>");
	 out.println("<th>Tue</th><th>Wed</th>");
	 out.println("<th>Thu</th><th>Fri</th><th>Sat</th></tr><tr>");					
	  for (int i=1; i<StartDay; i++)
	  out.println ("<td align='CENTER'>&nbsp</td>");
	  int days = StartDay;
	  int date = 1;		// date and days start from 1 for compatiblity
	// with real days and dates. no substaction is required.
	  for (int weeks=0; weeks<6 ;weeks++)
	        {  for (; days<=7 ; days++)
	            { if (date>28)
		{
		GCalendar = new GregorianCalendar(Year, Month,date);
		if (GCalendar.get(GCalendar.MONTH)== Month)
		out.println ("<td align='CENTER'>"+date+"</td>");
		else
		out.println("<td>&nbsp</td>");
		}//if
	               else
		out.println("<td align='CENTER'>"+date+"</td>");
		date++;
                                  }//if
		if (date>31)
		continue;
		days = 1;
		out.println ("</tr><tr>");
	        }// for
	        out.println("</table></body></html>");
             }//do post
}//Cal   class

