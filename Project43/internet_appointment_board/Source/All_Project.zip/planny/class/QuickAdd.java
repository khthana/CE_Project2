import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.net.*;
public class QuickAdd extends HttpServlet
{   protected  void  doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
 {          HttpSession session = req.getSession(true);
            String  UserID = session.getValue("login.username").toString();	
             if ( UserID==null  ) {  res.sendRedirect("http://127.0.0.1:8080/examples");  }
                Connection theConnection;
                 String Title      = req.getParameter("TitleQA");
                 String Type      = req.getParameter("TypeQA");
                 String StartMon      = req.getParameter("StartMonQA");
                 String StartDay      = req.getParameter("StartDayQA");
                 String StartHour      = req.getParameter("StartHourQA");
                 String StartMin      = req.getParameter("StartMinQA");
                 String FinalMonth      = req.getParameter("FinalMonthQA");
                 String FinalDay      = req.getParameter("FinalDayQA");
                 String FinalHour      = req.getParameter("FinalHourQA");
                 String FinalMin      = req.getParameter("FinalMinQA");
                 if (FinalHour.equals("")) FinalHour = StartHour;
                 if (FinalMin.equals("")) FinalMin = StartMin;
                 if (FinalDay.equals("")) FinalDay = StartDay;
                 if (FinalMonth.equals("")) FinalMonth = StartMon;
                 if (Title.equals("")) Title= "No Title";
                 if (Type.equals("")) Type = "No Type";             
                   try{
                                                //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                                  theStatement.executeQuery(
                                                       "INSERT INTO calendar"
                                                           + "(no_cal,time,id,to_time,title,type,no_rep,no_rem,no_appoint)"
                                                           + "values( no_cal.nextval, to_date(' "+StartDay+"/"
                                                           +StartMon+"/2001 "+StartHour+":"+StartMin+"','dd/mm/yyyy hh24:mi'),' "
                                                           +UserID+"',to_date(' "+FinalDay+"/"+FinalMonth+"/2001 "
                                                           +FinalHour+"."+FinalMin+"','dd/mm/yyyy hh24:mi'),' "
                                                           +Title+" ',' "+Type+" ',1,1,1)");
                                                          session.putValue("login.title",Title);
                                                          session.putValue("login.day",StartDay+"/"+StartMon+"/2001");      
                                                     }   catch (Exception e)  
                                               {  res.setContentType("text/html");
                                                  PrintWriter out = res.getWriter();
                                                  out.println(e.getMessage()); 
                                               }
                     String CheckQA = "Add";
                    session.putValue("login.done",CheckQA); 	
                   res.sendRedirect("http://127.0.0.1:8080/examples/servlet/mCalendar");
                     }
}