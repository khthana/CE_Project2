import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class calendar1 extends HttpServlet
{
         private int[] monthDays = {31,28,31,30,31,30,31,31,30,31,30,31};
         private static final String[] yearMonths ={"January","February","March","April","May","June","July","Augaust","September","October","November","December"};
         protected void service (HttpServletRequest req , HttpServletResponse res)	throws ServletException, IOException
	{   res.setContentType("text/html");
	     PrintWriter out = res.getWriter();
	     out.println("<html><head>");
	     out.println("<title>Eliad & Ran Calendar</title>");
	     out.println("</head><body>");
                          out.println("<form method = \"get\" action =\"http://mars.netanya.ac.il:8080/~u2549596/servlet/calendar\" >");
                          int  currYear = new Date().getYear() + 1900 ;
	     boolean flag = false ;
	     if (req.getQueryString()== null)
		{   out.println("<p><b> Insert year : </b> <input type = \"text\" name =\"year\" value=" + currYear + ">");
		     out.println("<p> <input type = \"submit\" value=\"Submit \">");
		     out.println("<P>&nbsp;</P>");
		     printCalender(currYear,out,req);
		     out.println("</body></html>");
		}
		else
		{
			String requestedYear = req.getParameter("year");

			if (!requestedYear.equals(""))
		    	out.println("<p><b> Insert year : </b> <input type = \"text\" name =\"year\" value=" + requestedYear + ">");
            else 
			{
				flag = true ;
		    	out.println("<p><b> Insert year : </b> <input type = \"text\" name =\"year\">");
			}	
		    out.println("<p> <input type = \"submit\" value=\"Submit \" id=submit1 name=submit1 >");
            
			if(!flag)
			{
				// Incase parseInt will throw an exception
				try {
					currYear = Integer.parseInt(requestedYear);
				}
				catch (Exception e) {
					printError(out,req) ;
				}
				// Eleagal parameters
				if (currYear < 0 || currYear > 9999)
				{
					printError(out,req) ;
					printCalender(2000,out,req);			
				}
				else
					printCalender(currYear,out,req);
			}
			else
			{
				printCalender(2000,out,req);			
			}	
		}
	}	

	private void printError(PrintWriter out,HttpServletRequest req)
	{
		out.println("<p><font size=5><strong>Wrong Parameters (Only 0 - 9999)</strong></font></p>") ;

	}
	
	private void printCalender(int currYear,PrintWriter out,HttpServletRequest req)
	{		    
		out.println("<p align=center><font color=#000000 size=7><em><strong>calendar: year " + currYear + "</strong></em></font></p>");
		out.print("<p align=center>&nbsp;</p>");

		String str = "" ;
		int j = 0 ;
		
		for(int month = 1 ; month <= 12 ; month++)
		{
			out.println("<p>&nbsp;</p>");

			out.println("<table border=1 cellpadding=2 width=100% bgcolor=#008080>");
			out.println("<tr>");
			out.println("<hr>") ;
			out.println("<p><font size=5>" + yearMonths[month-1]) ;
			out.println("<align=center><center><table border=4 cellpadding=3 width=10 bgcolor=#008080");
			out.println("bordercolor=#008080 bordercolordark=#000000 bordercolorlight=#080080 >");
				
			out.println("<tr>");
			out.println("<td><font face=Times New Roman>SUN</font></td>");
			out.println("<td><font face=Times New Roman>MON</font></td>");
			out.println("<td><font face=Times New Roman>TUE</font></td>");
			out.println("<td><font face=Times New Roman>WEN</font></td>");
			out.println("<td><font face=Times New Roman>THU</font></td>");
			out.println("<td><font face=Times New Roman>FRI</font></td>");
			out.println("<td><font face=Times New Roman>SAT</font></td>");
			out.println("</tr>");	
															
			int day = new Date(currYear-1900,month-1,1).getDay()+1;
	    
			j = day ;
		
			for (int space = 1 ; space < day ; space++)
			{
					out.println("<td>&nbsp;</td>");
			}
				
			if ((currYear % 4 )==0)
				monthDays[1] = 29 ;
				    
			for ( int i = 1 ; i <= monthDays[month-1] ; i++,j++)
			{
				out.println("<td> ");
				out.println( + i);
				out.println("</td>");

				if (((j)%7) == 0)
				{
				    out.println("</tr>");           
					out.println("<tr>");
				}
			}
    		monthDays[1]=28;
		
		}
	}


}
