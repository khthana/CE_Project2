  import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.*;

public class ManageToDo extends HttpServlet
{   static final  String [] MonthName = {"January","February","March","April","May", "June","July","August","September","October","November","December"};
     String DefaultURL="http://161.246.5.231";
     protected  void  doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {    HttpSession session = req.getSession(true);
         String UserID =session.getValue("login.username").toString();
           if ( UserID==null  ) {  res.sendRedirect(DefaultURL);  }
          Connection theConnection;
          if (req.getParameter("Cancel") != null ) {res.sendRedirect(DefaultURL+"/servlet/mCalendar");} else  {
          String Title                    = req.getParameter("TitleToDo");
          int Freqdate          = Integer.parseInt(req.getParameter("dateToDo"));
          int FreqMonth       = Integer.parseInt(req.getParameter("MonthToDo"));
          int FreqYear          = Integer.parseInt(req.getParameter("YearToDo"));
          String Priority               = req.getParameter("radiobutton");
          String Note                   = req.getParameter("NoteToDo");
         String Save                  = req.getParameter("SubmitSave");
          String SaveAnother  = req.getParameter("SubmitSaveAnother");
          Calendar DBCalendar = new GregorianCalendar(FreqYear,FreqMonth-1,Freqdate);
          Freqdate = DBCalendar.get(DBCalendar.DAY_OF_MONTH);
          FreqMonth = DBCalendar.get(DBCalendar.MONTH)+1;
          FreqYear = DBCalendar.get(DBCalendar.YEAR);
          
                     try{                   if (Title.equals("") )Title="No Title";
                                              Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                                theStatement.executeQuery(
                                                "INSERT INTO todo"
                                                           + "(no_todo,timeout,id,title,note,priority)"
                                                           + "values( no_todo.nextval, to_date(' "+Freqdate+"/"+FreqMonth+"/" +FreqYear+"',"
                                                           +" 'dd/mm/yyyy'),' "+UserID+"','"+Title+"','"+ Note+" ',' "+Priority+"')");
                                                theStatement.close();//Close statement
                                                theConnection.close();                                         
                             }   catch (Exception e)  
                                               {    res.setContentType("text/html");
                                                    PrintWriter out = res.getWriter();
                                                    out.println(e.getMessage());  }  
if (Save != null ) { res.sendRedirect(DefaultURL+"/servlet/mCalendar"); }   
   else if (SaveAnother != null ) { res.sendRedirect(DefaultURL+"/servlet/ToDo"); }
    }//Cancel                               
}
}