import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.net.*;
import java.util.*;
public class Deletetodo extends HttpServlet
{
  protected  void  doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {    HttpSession session = req.getSession(true);
         String UserID =session.getValue("login.username").toString();
         Connection theConnection;
         String [ ]no = req.getParameterValues("check");    
       //  String no = req.getParameter("check");    
       
         try{                             
                                               //Loading Sun's JDBC ODBC Driver   
                                               Class.forName("oracle.jdbc.driver.OracleDriver");
                                               //Connect to emaildb Data source
                                               theConnection = DriverManager.getConnection("jdbc:oracle:thin:@kate:1521:kate","scott","tiger");
                                               //Select all records from emaillists table.
                                               Statement  theStatement=theConnection.createStatement();
                                                if (no != null)  {
                                                     for (int i = 0; i < no.length; i++) 
                                                    {
                                                         theStatement.executeQuery("delete from todo where no_todo = "+no[i]);
                                                    }
                                                }
                                                   theStatement.close();//Close statement
                                               theConnection.close();   
                   }   catch (Exception e) {
                   	                       PrintWriter out = res.getWriter(); 
                                            res.setContentType("text/html");
                    	                      out.println(e.getMessage()); 
                                        
                                                }
                 res.sendRedirect("http://127.0.0.1:8080/examples/servlet/mCalendar");                                
                              }
        }