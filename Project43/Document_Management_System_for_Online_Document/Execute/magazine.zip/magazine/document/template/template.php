<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<table width="95%" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF" height="992">
     <tr> 
          <td height="60" colspan="4" align="left" background="../../../document/image/t02.jpg">
		<img src="../../../document/image/magazine.gif" width="513" height="59">
	  </td>
  </tr>
  <tr align="center" valign="middle" bgcolor="#006699"> 
    <td height="25" colspan="4"><font color="#FFFFFF" face="MS Sans Serif, Microsoft Sans Serif" size="1">|| 
      Home || Articles || Calendar || Search || Help ||</font></td>
  </tr>
  <tr> 
          <td align="left" colspan="4" valign="top" height="903"> 
               <table width="100%" cellspacing="0" cellpadding="0" height="92%" align="center">
        <tr align="center" valign="top"> 
          <td> 
            <table width="100%" cellspacing="0" cellpadding="2" align="center">
              <tr> 
                                        <td width="1%" align="center" height="1048" valign="top" background="../../../document/image/vline.gif" rowspan="2"> 
                                             <p>&nbsp;</p>
                                             <p>&nbsp;</p>
                </td>
                                        <td width="68%" height="836" align="center" valign="top"> 
                                             <table width="95%" cellspacing="0" cellpadding="20">
                    <tr align="left" valign="top"> 
                      <td height="543"> 


                            <p><font color="#006699" face="MS Sans Serif, Microsoft Sans Serif" size="2"><b>article name</b></font></p>
    <p>
<?
	$source = fopen("../../$location","r");
	if ($source) {
		while (!feof($source)) {
			 $buffer = fgets($source, 4096);
			 echo $buffer;
		}
	}
	fclose ($source);
?>
	</p>			<hr>
   <p><font color="#ff0000" size="2" face="MS Sans Serif, Microsoft Sans Serif" color="#FF0000"><b>�Ӷ�����º�����</b></font></p>

<?
	$id_link = mysql_connect('localhost','magazine','magazine');
	if(!$id_link){
		affy_message(" The connection to the local database has failed.
		Please enter a username and password so a connection can be made." );
	}
?> 
<?

//====================SELECT question =========================== 
	$str_sql= "	select  * 
			from   	opinion
			where	art_id = '$article_id'
			";
	$result_question = mysql_db_query (magazine,$str_sql,$id_link);
	$nf=mysql_num_rows($result_question);

	for ($num_question = 1; $num_question <= $nf; $num_question++){

		$row=mysql_fetch_array($result_question);
		$op_id = $row[0];
		$op_question = $row[1];
		echo "<font color=\"#ff0000\" size=\"2\" face=\"MS Sans Serif, Microsoft Sans Serif\" color=\"#FF0000\"> \n";
		echo "<a href = \"../../../create_document/opinion/page_question.php?op_id=$op_id\" target=$op_id><font color = #0000FF > $op_question</font> </a> <br>\n ";
		echo "</font> \n";
	}		

?>

                                                            <table width="149" border="0" cellspacing="0" cellpadding="0">
                                                                 <tr align="center" valign="bottom"> 
                                                                      <td colspan="4"><img src="../../../document/image/contents.gif" width="154" height="57"></td>
                                                                 </tr>
                                                                 <tr> 
                                                                      <td width="12" background="../../../document/image/verline.gif" align="center" valign="top" rowspan="2">&nbsp;</td>
                                                                      <td width="21" align="center" valign="top" rowspan="2"> 
                                                                           <p>&nbsp;</p>
                                                                      </td>
                                                                      <td width="116" align="left" valign="top" height="28"> 
                                                                           <p><font size="2" face="MS Sans Serif, Microsoft Sans Serif"> 
                                                                                <? //show column
	if ($id_col == "")
		$id_col = "0";	//***
   $hostname = "localhost";
   $username = "magazine";
   $password = "magazine";
   $dbName = "magazine";
   mysql_connect($hostname,$username,$password) or die("can not connect!");
	$sql = "select * from col where col_id = $id_col ";
	$SQLresult = mysql_db_query($dbName,$sql);
   if ($SQLresult)
      $num = mysql_numrows($SQLresult);
   if ($num) {
      for ($i=1;$i<=$num;$i++) {
			$row = mysql_fetch_array($SQLresult);
			echo "<font color=\"#006699\">$row[col_name]</font>";
			echo "<font color=\"#006699\"><a href=\"index.php?id_col=$row[parent_col_id]\">|Up|</a></font>";
		}
	}
	else {
		echo "<font color=\"#006699\">Document online</font>";
	}
?></font></p>
                                                                      </td>
                                                                      <td width="12" background="../../../document/image/verline.gif" rowspan="2"></td>
                                                                 </tr>
                                                                 <tr> 
                                                                      <td width="116" align="left" valign="top" height="28"> 
                                                                           <?
	$sql = "select * from col where parent_col_id = $id_col order by col_name";
	$SQLresult = mysql_db_query($dbName,$sql);
	if ($SQLresult)
		$num = mysql_numrows($SQLresult);
	if ($num) {
      for ($i=1;$i<=$num;$i++) {
  	      $row = mysql_fetch_array($SQLresult);
   		echo "<img src=\"../../../document/image/icon_menu.gif\" width=\"14\" height=\"14\"> ";
		echo "&nbsp &nbsp <a href=\"index.php?id_col=$row[col_id]\"> ";
		echo " <font color=\"#ff0000\" size=\"2\" face=\"MS Sans Serif, Microsoft Sans Serif\"> ";
		echo "$row[col_name]</a><br>";
		echo "</font>";
		}
	}

?> </td>
                                                                 </tr>
                                                                 <tr align="center" valign="top"> 
                                                                      <td colspan="4" height="53"><img src="../../../document/image/buttom.gif" width="154" height="41"></td>
                                                                 </tr>
                                                            </table>
                                                       </td>
                    </tr>
                  </table>
                                             <p>&nbsp; </p>
                </td>
                                        <td width="31%" height="836" valign="top" align="right"> 
                                             <table width="81%" cellspacing="0" cellpadding="15" bordercolor="#DED7D6" border="1" height="825">
                                                  <tr align="left" valign="top" bordercolor="#ffffff"> 
                                                       <td height="818"> 
                                                            <div align="left"> 
                                                                 <form name="form1" method="post" action="../../../search/searchBasicReader.php">
                                                                      <table cellspacing=0 cellpadding=0 width="123" 
                  bgcolor=#dcedf5 border=0>
                                                                           <tr> 
                                                                                <td align=center width=67><img height=10 
                        src="../../../image/my/search_text.gif" 
                        width=57 border=0></td>
                                                                                <td align=left width=147> 
                                                                                     <input size=20 name=keyword>
                                                                                </td>
                                                                                <td align=center width=10> 
                                                                                     <input type=image height=23 
                        width=29 
                        src="../../../image/my/btn_gotosearch.gif" 
                        border=0 name="image">
                                                                                </td>
                                                                           </tr>
                                                                           <tbody> 
                                                                           <tr> 
                                                                                <td align=center width=67><br>
                                                                                </td>
                                                                                <td align=left width=147><a href="search.php"><img 
                        height=8 alt="" 
                        src="../../../image/my/search_advanced.gif" 
                        width=52 border=0 align="middle"></a> <a 
                        href="http://www.vstore.com/cgi-bin/pagegen/vstorelibrary/hodgepodgebooks/page.html?mode=home&amp;file=/page/search/search_tips.spl"><img 
                        height=10 
                        src="image/my/search_tips.gif" 
                        width=59 
              border=0 align="middle"></a></td>
                                                                                <td align=center width=10> 
                                                                                     <br>
                                                                                </td>
                                                                           </tr>
                                                                           </tbody> 
                                                                      </table>
                                                                 </form>
                                                                 <p>&nbsp;</p>
                                                                 <p><img src="../../../document/image/relate.gif" width="180" height="40"><?

$str_sql = "		select		relate.relate_art_id
			from		article,relate
			where		article.art_id = relate.art_id
			and		relate.art_id = '$article_id'
					
	    ";
	$result = mysql_db_query (magazine,$str_sql,$id_link);
	$nf=mysql_num_rows($result);
                echo "<ul>\n";
	for($line=1; $line<=$nf; $line++) {
		$row=mysql_fetch_array($result);
		//echo "$row[0] \t";
		$str_sql = "	select		* 
				from		article
				where		art_id = '$row[0]'
				group by	col_id
			   ";
		$result_relate = mysql_db_query (magazine,$str_sql,$id_link);
		$relate_article = mysql_fetch_array($result_relate);
		echo "<font color=\"#000000\" face=\"MS Sans Serif, Microsoft Sans Serif\" size=\"1\"> \n";
		echo "<li><a href  = \"../../../$relate_article[location]\"><font color = #0000FF>$relate_article[art_name]</font></a> </li><br>\n";
		echo "</font> \n";
	}
               echo "</ul>\n";
	
?></p>
                                                            </div>
                                                            <table width="180" border="0" cellspacing="0" cellpadding="0">
                                                                 <tr> 
                                                                      <td colspan="2"><img src="../../../document/image/vote.gif" width="180" height="40"></td>
                                                                 </tr>
                                                                 <tr> 
                                                                      <td colspan="2"><?

//====================SELECT POLL =========================== 
	$str_sql= "	select  * 
			from   	poll
			where	art_id = '$article_id'
			";
	$result_poll = mysql_db_query (magazine,$str_sql,$id_link);
	$nf=mysql_num_rows($result_poll);
	echo "<br>";
	for ($poll = 1; $poll <= $nf; $poll++){
		
		$row=mysql_fetch_array($result_poll);
		$poll_id       = $row[0];
		$poll_question = $row[1];
		echo "<form method=\"post\" action=\"../../../create_document/vote/poll_ans.php\" target = $poll_id> \n ";
		echo "<table width=\"150\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">  \n";
    		
		
		echo "<tr> \n";
		echo " <td colspan=\"0\" align=\"left\"> \n";
		echo "<font color=\"#FF0000\" face=\"MS Sans Serif, Microsoft Sans Serif\" size=\"1\"> \n";
		echo "  $poll_question <br>\n ";
		echo "</font> \n";
		echo "  </td> \n";
		echo "</tr> \n";
//==========================SELECT CHOICE ===========================
		$str_sql= "	select  * 
				from   	choice
				where	poll_id = '$poll_id'
				";
		$result_choice = mysql_db_query (magazine,$str_sql,$id_link);
		$num_choice = mysql_num_rows($result_choice);
		echo "<tr> \n";
		echo " <td colspan=\"0\" align=\"left\"> \n";
		for ($number_choice = 1; $number_choice <= $num_choice; $number_choice++)
		{
			$row=mysql_fetch_array($result_choice);
			$choice = $row[1];
                                                
                        echo " <font color=\"#000000\" face=\"MS Sans Serif, Microsoft Sans Serif\" size=\"1\"> \n";
			echo " <input type=\"radio\" name=\"poll_ans\" value=\"$choice\">$choice <br>\n";
			echo "</font> \n";
		}
		 echo "<input type=\"hidden\" name=\"poll_id\" value=\"$poll_id\"> \n";

		echo "  </td> \n";
		echo "</tr> \n";

		echo "<tr> \n";
		echo " <td colspan=\"0\" align=\"left\"> \n";
		echo "<center><input type=\"submit\" value=\"VOTE\" name=\"VOTE\"></center> \n";
		echo "  </td> \n";
		echo "</tr> \n";

		echo "</table> \n";
		echo "</form> \n";
	}

?></td>
                                                                 </tr>
                                                            </table>
                                                       </td>
                                                  </tr>
                                                  <tr align="left" valign="top" bordercolor="#ffffff">
                                                       <td height="818">&nbsp;</td>
                                                  </tr>
                                                  <tr align="left" valign="top" bordercolor="#ffffff"> 
                                                       <td height="818">&nbsp;</td>
                                                  </tr>
                                             </table>
                  
                </td>
              </tr>
              <tr> 
                <td colspan="2" align="center" valign="top" bgcolor="#00659C"><font color="#FFFFFF" size="1" face="MS Sans Serif, Microsoft Sans Serif">Copyright 
                  2000 King Mongkut's Institute of Technology Ladkragang</font> 
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
